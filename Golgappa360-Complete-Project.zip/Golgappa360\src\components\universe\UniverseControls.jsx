import React from 'react';

/**
 * UniverseControls — Floating minimal observatory HUD controls
 * 
 * Features:
 * - Zoom In (+)
 * - Zoom Out (−)
 * - Reset View (⟳)
 * - Center Selected Object (◎)
 * - Discover Something (✦ Discover)
 */
export default function UniverseControls({
  onZoomIn,
  onZoomOut,
  onResetView,
  onCenterSelected,
  onDiscoverRandom,
  onOpenCompare = null,
  onOpenTimeline = null,
  hasSelectedStar,
}) {
  return (
    <div className="flex flex-wrap items-center gap-2 select-none">
      {/* Zoom In & Out Pill */}
      <div className="flex items-center rounded-lg bg-[#020308]/80 backdrop-blur-md border border-white/10 shadow-[0_4px_20px_rgba(0,0,0,0.6)] p-0.5">
        <button
          type="button"
          onClick={onZoomIn}
          aria-label="Zoom in universe map"
          title="Zoom In"
          className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 rounded active:scale-95 transition-all text-base font-semibold focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400"
        >
          +
        </button>
        <span className="w-px h-4 bg-white/10" aria-hidden="true" />
        <button
          type="button"
          onClick={onZoomOut}
          aria-label="Zoom out universe map"
          title="Zoom Out"
          className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 rounded active:scale-95 transition-all text-base font-semibold focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400"
        >
          −
        </button>
      </div>

      {/* Reset View Button */}
      <button
        type="button"
        onClick={onResetView}
        aria-label="Reset map view to origin"
        title="Reset Map View"
        className="h-8 px-2.5 flex items-center gap-1.5 rounded-lg bg-[#020308]/80 backdrop-blur-md border border-white/10 hover:border-cyan-500/40 hover:bg-white/5 text-slate-300 hover:text-white shadow-[0_4px_20px_rgba(0,0,0,0.6)] active:scale-95 transition-all text-xs font-mono focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400"
      >
        <svg
          className="w-3.5 h-3.5 text-cyan-400"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
          />
        </svg>
        <span className="hidden sm:inline">Reset</span>
      </button>

      {/* Center Selected Button (conditionally enabled) */}
      {hasSelectedStar && (
        <button
          type="button"
          onClick={onCenterSelected}
          aria-label="Center camera on selected star"
          title="Center Selected Star"
          className="h-8 px-2.5 flex items-center gap-1.5 rounded-lg bg-[#020308]/80 backdrop-blur-md border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/20 text-cyan-300 hover:text-cyan-100 shadow-[0_4px_20px_rgba(0,0,0,0.6)] active:scale-95 transition-all text-xs font-mono focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400"
        >
          <span className="text-cyan-400 text-sm leading-none">◎</span>
          <span className="hidden sm:inline">Center</span>
        </button>
      )}

      {/* Discover Something Action */}
      <button
        type="button"
        onClick={onDiscoverRandom}
        aria-label="Discover a random star in the universe"
        title="Discover a random star"
        className="h-8 px-3 flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-cyan-950/40 to-blue-950/40 hover:from-cyan-900/60 hover:to-blue-900/60 backdrop-blur-md border border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white shadow-[0_0_15px_rgba(6,182,212,0.15)] active:scale-95 transition-all text-xs font-mono focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400"
      >
        <span className="text-amber-300 text-xs">✦</span>
        <span>Discover Something</span>
      </button>

      {/* Cosmic Compare Action (Phase U12) */}
      {onOpenCompare && (
        <button
          type="button"
          onClick={onOpenCompare}
          aria-label="Open Cosmic Compare Mode"
          title="Compare Celestial Objects"
          className="h-8 px-3 flex items-center gap-1.5 rounded-lg bg-purple-950/40 hover:bg-purple-900/60 backdrop-blur-md border border-purple-500/40 hover:border-purple-400 text-purple-200 hover:text-white shadow-[0_0_15px_rgba(168,85,247,0.15)] active:scale-95 transition-all text-xs font-mono focus:outline-none focus-visible:ring-1 focus-visible:ring-purple-400 cursor-pointer"
        >
          <span>⚖️</span>
          <span>Compare</span>
        </button>
      )}

      {/* Cosmic Timeline Action (Phase U13) */}
      {onOpenTimeline && (
        <button
          type="button"
          onClick={onOpenTimeline}
          aria-label="Open Cosmic Timeline"
          title="Explore Cosmic History Timeline"
          className="h-8 px-3 flex items-center gap-1.5 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 backdrop-blur-md border border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white shadow-[0_0_15px_rgba(6,182,212,0.15)] active:scale-95 transition-all text-xs font-mono focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400 cursor-pointer"
        >
          <span>⏳</span>
          <span>Timeline</span>
        </button>
      )}
    </div>
  );
}
