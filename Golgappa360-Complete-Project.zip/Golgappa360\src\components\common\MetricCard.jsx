import React from 'react';

export const MetricCard = ({
  label,
  value,
  unit = '',
  icon: Icon,
  trend,
  color = 'default', // 'default', 'primary', 'cyan', 'warning'
  className = '',
}) => {
  const colorMap = {
    default: {
      text: 'text-white',
      iconBg: 'bg-white/5 text-slate-300',
      border: 'border-white/10',
    },
    primary: {
      text: 'text-[#00F5A0]',
      iconBg: 'bg-[#00F5A0]/10 text-[#00F5A0]',
      border: 'border-[#00F5A0]/20',
    },
    cyan: {
      text: 'text-[#00E5FF]',
      iconBg: 'bg-[#00E5FF]/10 text-[#00E5FF]',
      border: 'border-[#00E5FF]/20',
    },
    warning: {
      text: 'text-amber-400',
      iconBg: 'bg-amber-400/10 text-amber-400',
      border: 'border-amber-400/20',
    },
  };

  const scheme = colorMap[color] || colorMap.default;

  return (
    <div
      className={`
        bg-[#0D1527]/90 rounded-2xl p-3.5 border ${scheme.border}
        flex flex-col justify-between transition-all duration-200 hover:border-white/20
        ${className}
      `}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-medium tracking-wide uppercase text-slate-400">
          {label}
        </span>
        {Icon && (
          <div className={`p-1.5 rounded-lg ${scheme.iconBg}`}>
            <Icon className="w-3.5 h-3.5" />
          </div>
        )}
      </div>

      <div className="flex items-baseline gap-1">
        <span className={`text-xl font-bold tracking-tight ${scheme.text} font-mono`}>
          {value}
        </span>
        {unit && (
          <span className="text-xs font-semibold text-slate-400">{unit}</span>
        )}
      </div>

      {trend && (
        <span className="text-[10px] text-slate-500 mt-1">{trend}</span>
      )}
    </div>
  );
};
