import * as THREE from 'three';

/**
 * Energy Waves Preset
 * Animated undulating 3D cyber terrain and ribbon geometry
 * with real-time audio FFT spectral displacement and dual-hand interactions.
 */
export class EnergyWaves {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;
    this.group = new THREE.Group();

    this.gridWidth = 80;
    this.gridHeight = 80;
    this.segmentsX = 90;
    this.segmentsY = 90;

    this.mesh = null;
    this.material = null;
    this.geometry = null;

    this.init();
    this.scene.add(this.group);
  }

  init() {
    this.geometry = new THREE.PlaneGeometry(
      this.gridWidth,
      this.gridHeight,
      this.segmentsX,
      this.segmentsY
    );
    this.geometry.rotateX(-Math.PI / 2.2);

    this.material = new THREE.ShaderMaterial({
      wireframe: true,
      vertexShader: `
        uniform float uTime;
        uniform float uSpeed;
        uniform float uAudioBass;
        uniform float uAudioMid;
        uniform float uAudioTreble;
        uniform float uSensitivity;
        
        uniform vec2 uHand1Pos;
        uniform float uHand1Active;
        uniform vec2 uHand2Pos;
        uniform float uHand2Active;

        varying vec3 vWorldPos;
        varying float vElevation;
        varying float vDistance;

        float calculateWave(vec2 p) {
          float w1 = sin(p.x * 0.15 + uTime * 1.8 * uSpeed) * cos(p.y * 0.12 + uTime * 1.4 * uSpeed) * 3.5;
          float w2 = sin(p.x * 0.28 - uTime * 2.2 * uSpeed + p.y * 0.22) * 1.8;
          float w3 = cos(length(p) * 0.2 - uTime * 3.0 * uSpeed) * 1.2;

          // Audio Bass surge
          float bassWave = sin(p.y * 0.1 + uTime * 2.0) * (uAudioBass * uSensitivity * 6.5);

          // Audio Mid harmonics
          float midRipple = sin(p.x * 0.5 + p.y * 0.5 + uTime * 4.0) * (uAudioMid * uSensitivity * 2.8);

          // Hand 1 / Mouse interaction force
          float hand1Force = 0.0;
          if (uHand1Active > 0.5) {
            float dist1 = length(p.xy - uHand1Pos);
            hand1Force = exp(-dist1 * 0.15) * 6.0;
          }

          // Hand 2 interaction force
          float hand2Force = 0.0;
          if (uHand2Active > 0.5) {
            float dist2 = length(p.xy - uHand2Pos);
            hand2Force = exp(-dist2 * 0.15) * 6.0;
          }

          return w1 + w2 + w3 + bassWave + midRipple + hand1Force + hand2Force;
        }

        void main() {
          vec3 pos = position;
          float elevation = calculateWave(pos.xy);
          pos.z += elevation;

          vElevation = elevation;
          vWorldPos = (modelMatrix * vec4(pos, 1.0)).xyz;
          vDistance = - (modelViewMatrix * vec4(pos, 1.0)).z;

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uColorIntensity;
        uniform float uAudioTreble;
        varying vec3 vWorldPos;
        varying float vElevation;
        varying float vDistance;

        void main() {
          vec3 colorLow = vec3(0.05, 0.2, 0.65);
          vec3 colorMid = vec3(0.0, 0.95, 0.85);
          vec3 colorHigh = vec3(0.75, 0.1, 0.95);
          vec3 colorPeak = vec3(1.0, 0.9, 1.0);

          float normElev = clamp((vElevation + 4.0) / 12.0, 0.0, 1.0);
          vec3 baseColor;
          if (normElev < 0.45) {
            baseColor = mix(colorLow, colorMid, normElev / 0.45);
          } else if (normElev < 0.85) {
            baseColor = mix(colorMid, colorHigh, (normElev - 0.45) / 0.4);
          } else {
            baseColor = mix(colorHigh, colorPeak, (normElev - 0.85) / 0.15);
          }

          baseColor += vec3(0.3, 0.5, 0.6) * (uAudioTreble * 1.2);
          float fog = smoothstep(110.0, 25.0, vDistance);

          gl_FragColor = vec4(baseColor * uColorIntensity, fog * 0.9);
        }
      `,
      uniforms: {
        uTime: { value: 0 },
        uSpeed: { value: 1.0 },
        uAudioBass: { value: 0 },
        uAudioMid: { value: 0 },
        uAudioTreble: { value: 0 },
        uSensitivity: { value: 1.0 },
        uColorIntensity: { value: 1.3 },
        uHand1Pos: { value: new THREE.Vector2(0, 0) },
        uHand1Active: { value: 0.0 },
        uHand2Pos: { value: new THREE.Vector2(0, 0) },
        uHand2Active: { value: 0.0 },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.position.set(0, -6, -10);
    this.group.add(this.mesh);

    this.camera.position.set(0, 6, 26);
    this.camera.lookAt(0, -1, -12);
  }

  update(delta, time, audioData, settings, mouse, hand1, hand2) {
    if (!this.material) return;

    const u = this.material.uniforms;
    u.uTime.value = time;
    u.uSpeed.value = settings.speed;
    u.uAudioBass.value = audioData.bass;
    u.uAudioMid.value = audioData.mid;
    u.uAudioTreble.value = audioData.treble;
    u.uSensitivity.value = settings.sensitivity;
    u.uColorIntensity.value = settings.colorIntensity;

    let steerX = mouse.x;
    let steerY = mouse.y;

    if (hand1 && hand1.active) {
      u.uHand1Active.value = 1.0;
      u.uHand1Pos.value.set(hand1.x * 32.0, hand1.y * 32.0);
      steerX = hand1.x;
      steerY = hand1.y;
    } else {
      u.uHand1Active.value = 1.0;
      u.uHand1Pos.value.set(mouse.x * 30.0, mouse.y * 30.0);
    }

    if (hand2 && hand2.active) {
      u.uHand2Active.value = 1.0;
      u.uHand2Pos.value.set(hand2.x * 32.0, hand2.y * 32.0);
    } else {
      u.uHand2Active.value = 0.0;
    }

    this.mesh.rotation.z = Math.sin(time * 0.4) * 0.05 + (steerX * 0.12);
    this.mesh.rotation.x = -Math.PI / 2.3 + (steerY * 0.15);

    const targetCamX = steerX * 6.0;
    const targetCamY = 6.0 + steerY * 4.0 + (audioData.bass * 2.5 * settings.sensitivity);
    this.camera.position.x += (targetCamX - this.camera.position.x) * 0.05;
    this.camera.position.y += (targetCamY - this.camera.position.y) * 0.05;
    this.camera.lookAt(0, -1, -16);
  }

  setDensity(densityPercent) {}

  dispose() {
    if (this.mesh) {
      this.group.remove(this.mesh);
    }
    if (this.geometry) {
      this.geometry.dispose();
      this.geometry = null;
    }
    if (this.material) {
      this.material.dispose();
      this.material = null;
    }
    this.scene.remove(this.group);
  }
}
