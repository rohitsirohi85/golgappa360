import { AnalyticsService } from '../services/analyticsService.js';

export async function getSales(req, res, next) {
  try {
    const { page = 1, limit = 50, startDate, endDate, productId = 'all', paymentMethod } = req.query;
    const result = await AnalyticsService.getSalesList({ page, limit, startDate, endDate, productId, paymentMethod });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}

export async function getProductPerformance(req, res, next) {
  try {
    const { range = '180d', startDate, endDate } = req.query;
    const result = await AnalyticsService.getProductPerformance({ range, startDate, endDate });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}

export async function getPaymentBreakdown(req, res, next) {
  try {
    const { range = '30d', startDate, endDate } = req.query;
    const result = await AnalyticsService.getPaymentBreakdown({ range, startDate, endDate });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}
