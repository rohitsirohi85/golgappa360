import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../components/AdminLayout';
import { analyticsService } from '../services/analyticsService';
import { adminService } from '../services/adminService';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Zap,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  ShieldCheck,
  Activity,
  Clock,
  CheckCircle2,
  ChevronDown,
  Download,
  RefreshCw,
  Info,
  Calendar,
  Filter,
  Building2,
  BatteryCharging,
  ArrowUpRight,
  Cpu,
  HelpCircle,
  Flame,
} from 'lucide-react';

const COLORS = ['#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b'];

export const AdminAnalyticsScreen = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  // Filters State
  const [datePreset, setDatePreset] = useState('30days');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedStation, setSelectedStation] = useState('all');
  const [selectedCharger, setSelectedCharger] = useState('all');

  // Filter options
  const [stationList, setStationList] = useState([]);
  const [chargerList, setChargerList] = useState([]);

  // Analytics Data States
  const [overviewData, setOverviewData] = useState(null);
  const [energyData, setEnergyData] = useState(null);
  const [chargingData, setChargingData] = useState(null);
  const [stationData, setStationData] = useState(null);
  const [chargerData, setChargerData] = useState(null);
  const [revenueData, setRevenueData] = useState(null);
  const [faultData, setFaultData] = useState(null);
  const [utilizationData, setUtilizationData] = useState(null);

  // Tooltip / Modal state for formulas
  const [showFormulaInfo, setShowFormulaInfo] = useState(false);

  // Compute date strings from preset
  const computeDatesFromPreset = (preset) => {
    const end = new Date();
    let start = new Date();

    if (preset === 'today') {
      start.setHours(0, 0, 0, 0);
    } else if (preset === '7days') {
      start.setDate(end.getDate() - 7);
    } else if (preset === '30days') {
      start.setDate(end.getDate() - 30);
    } else if (preset === 'month') {
      start = new Date(end.getFullYear(), end.getMonth(), 1);
    } else {
      return { start: startDate, end: endDate };
    }

    return {
      start: start.toISOString().slice(0, 10),
      end: end.toISOString().slice(0, 10),
    };
  };

  // Load initial dropdowns
  useEffect(() => {
    const loadDropdowns = async () => {
      try {
        const [stRes, chRes] = await Promise.all([
          adminService.getStations(),
          adminService.getChargers(),
        ]);
        if (stRes?.data) setStationList(stRes.data);
        if (chRes?.data) setChargerList(chRes.data);
      } catch (err) {
        console.warn('Error loading filter options:', err.message);
      }
    };
    loadDropdowns();
  }, []);

  // Fetch Analytics Data based on active tab and filters
  const fetchData = async () => {
    try {
      setError(null);
      const { start, end } = computeDatesFromPreset(datePreset);
      const filters = {
        startDate: start,
        endDate: end,
        stationId: selectedStation,
        chargerId: selectedCharger,
      };

      if (activeTab === 'overview') {
        const data = await analyticsService.getOverview(filters);
        setOverviewData(data);
      } else if (activeTab === 'energy') {
        const data = await analyticsService.getEnergy(filters);
        setEnergyData(data);
      } else if (activeTab === 'charging') {
        const data = await analyticsService.getCharging(filters);
        setChargingData(data);
      } else if (activeTab === 'stations') {
        const [st, ch, ut] = await Promise.all([
          analyticsService.getStations(filters),
          analyticsService.getChargers(filters),
          analyticsService.getUtilization(filters),
        ]);
        setStationData(st);
        setChargerData(ch);
        setUtilizationData(ut);
      } else if (activeTab === 'revenue') {
        const data = await analyticsService.getRevenue(filters);
        setRevenueData(data);
      } else if (activeTab === 'faults') {
        const data = await analyticsService.getFaults(filters);
        setFaultData(data);
      }
    } catch (err) {
      console.error('Failed to load analytics:', err);
      setError(err.message || 'Error loading analytics dataset');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchData();
  }, [activeTab, datePreset, selectedStation, selectedCharger]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  // CSV Exporters
  const exportCurrentTabCsv = () => {
    const { start, end } = computeDatesFromPreset(datePreset);
    if (activeTab === 'overview' && overviewData) {
      const rows = [
        { Metric: 'Total Energy Delivered (kWh)', Value: overviewData.summaryCards.totalEnergyDeliveredKwh },
        { Metric: 'Total Sessions', Value: overviewData.summaryCards.totalSessions },
        { Metric: 'Total Revenue (INR)', Value: overviewData.summaryCards.totalRevenue },
        { Metric: 'Fleet Utilization Rate (%)', Value: overviewData.summaryCards.fleetUtilizationRate },
        { Metric: 'Fleet Availability Rate (%)', Value: overviewData.summaryCards.fleetAvailabilityRate },
        { Metric: 'Historical Peak Demand Window', Value: overviewData.summaryCards.historicalPeakWindow },
        { Metric: 'Energy Efficiency (%)', Value: overviewData.summaryCards.energyEfficiencyPercent },
        { Metric: 'Active Alerts', Value: overviewData.summaryCards.activeAlertsCount },
        { Metric: 'Hardware Reliability (%)', Value: overviewData.summaryCards.hardwareReliabilityPercent },
      ];
      analyticsService.exportToCsv('Overview_Executive_KPIs', rows, [
        { label: 'Metric', key: 'Metric' },
        { label: 'Value', key: 'Value' },
      ]);
    } else if (activeTab === 'energy' && energyData) {
      analyticsService.exportToCsv('Energy_Daily_Trend', energyData.dailyEnergy, [
        { label: 'Date', key: 'date' },
        { label: 'Day', key: 'day' },
        { label: 'Energy (kWh)', key: 'energy' },
        { label: 'Sessions Count', key: 'sessions' },
        { label: 'Average Energy/Session (kWh)', key: 'avgEnergy' },
      ]);
    } else if (activeTab === 'charging' && chargingData) {
      analyticsService.exportToCsv('Session_Duration_Buckets', chargingData.durationStats.durationBuckets, [
        { label: 'Duration Range', key: 'range' },
        { label: 'Session Count', key: 'count' },
        { label: 'Total Energy (kWh)', key: 'energy' },
      ]);
    } else if (activeTab === 'stations' && stationData) {
      analyticsService.exportToCsv('Station_Performance_Report', stationData.stations, [
        { label: 'Station Name', key: 'name' },
        { label: 'City', key: 'city' },
        { label: 'Total Bays', key: 'totalChargers' },
        { label: 'Energy Delivered (kWh)', key: 'energyDelivered' },
        { label: 'Load Contribution (%)', key: 'percentageContribution' },
        { label: 'Sessions Count', key: 'sessionsCount' },
        { label: 'Utilization (%)', key: 'utilizationPercent' },
        { label: 'Availability (%)', key: 'availabilityRate' },
        { label: 'Revenue (INR)', key: 'revenueGenerated' },
      ]);
    } else if (activeTab === 'revenue' && revenueData) {
      analyticsService.exportToCsv('Revenue_Daily_Report', revenueData.dailyRevenue, [
        { label: 'Date', key: 'date' },
        { label: 'Revenue (INR)', key: 'revenue' },
        { label: 'Energy (kWh)', key: 'energy' },
        { label: 'Sessions', key: 'sessions' },
        { label: 'Average Ticket (INR)', key: 'avgTicket' },
      ]);
    } else if (activeTab === 'faults' && faultData) {
      analyticsService.exportToCsv('Device_Reliability_Report', faultData.devices, [
        { label: 'Hardware Device ID', key: 'deviceId' },
        { label: 'Charger Bay', key: 'chargerId' },
        { label: 'Operational Status', key: 'status' },
        { label: 'WiFi RSSI (dBm)', key: 'rssi' },
        { label: 'Firmware Version', key: 'firmwareVersion' },
        { label: 'Fault Count', key: 'faultCount' },
        { label: 'Reliability Score (%)', key: 'reliabilityScore' },
      ]);
    }
  };

  const filteredChargers = selectedStation === 'all'
    ? chargerList
    : chargerList.filter((c) => c.stationId?._id === selectedStation || c.stationId === selectedStation);

  return (
    <AdminLayout
      pageTitle="Fleet & Energy Analytics"
      subtitle="Operational Intelligence, Historical Peak Demand & Hardware Performance"
    >
      <div className="space-y-6">
        {/* TOP BAR: Controls & Exports */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 backdrop-blur-md">
          {/* Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800">
            {[
              { id: 'overview', label: 'Executive KPIs', icon: Activity },
              { id: 'energy', label: 'Energy & Demand', icon: Zap },
              { id: 'charging', label: 'Charging Patterns', icon: BatteryCharging },
              { id: 'stations', label: 'Station Utilization', icon: Building2 },
              { id: 'revenue', label: 'Revenue & Tariff', icon: DollarSign },
              { id: 'faults', label: 'Faults & Reliability', icon: AlertTriangle },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 font-bold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setShowFormulaInfo(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 transition-colors"
              title="View Utilization & Availability Formula Standards"
            >
              <HelpCircle className="w-3.5 h-3.5 text-teal-400" />
              <span>Formulas</span>
            </button>

            <button
              onClick={exportCurrentTabCsv}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 transition-colors"
              title="Download CSV export for this section"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition-colors"
              title="Refresh Analytics Dataset"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-emerald-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* GLOBAL FILTER BAR */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-slate-900/40 p-3.5 rounded-2xl border border-slate-800/60 text-xs">
          {/* Preset Picker */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>Timeframe Preset</span>
            </label>
            <select
              value={datePreset}
              onChange={(e) => setDatePreset(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-medium focus:outline-none focus:border-emerald-500/50"
            >
              <option value="today">Today (Live 24h)</option>
              <option value="7days">Last 7 Days</option>
              <option value="30days">Last 30 Days (Standard)</option>
              <option value="month">Current Calendar Month</option>
              <option value="custom">Custom Date Range</option>
            </select>
          </div>

          {/* Custom Date Inputs if Custom selected */}
          {datePreset === 'custom' ? (
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Start Date</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="flex-1">
                <label className="block text-[11px] font-medium text-slate-400 mb-1">End Date</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                <span>Observed Date Scope</span>
              </label>
              <div className="px-3 py-2 bg-slate-950/60 rounded-xl border border-slate-800/80 text-slate-300 font-mono text-[11px]">
                {computeDatesFromPreset(datePreset).start} → {computeDatesFromPreset(datePreset).end}
              </div>
            </div>
          )}

          {/* Station Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-purple-400" />
              <span>Station Filter</span>
            </label>
            <select
              value={selectedStation}
              onChange={(e) => {
                setSelectedStation(e.target.value);
                setSelectedCharger('all');
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-medium focus:outline-none focus:border-purple-500/50"
            >
              <option value="all">All Stations (Network-Wide)</option>
              {stationList.map((st) => (
                <option key={st._id} value={st._id}>
                  {st.name} ({st.city || 'Hub'})
                </option>
              ))}
            </select>
          </div>

          {/* Charger Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Charger Bay</span>
            </label>
            <select
              value={selectedCharger}
              onChange={(e) => setSelectedCharger(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-medium focus:outline-none focus:border-amber-500/50"
            >
              <option value="all">All Charger Bays</option>
              {filteredChargers.map((ch) => (
                <option key={ch._id} value={ch._id}>
                  {ch.chargerNumber} ({ch.chargerType || 'Fast'})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* LOADING & ERROR STATES */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20 bg-slate-900/30 rounded-2xl border border-slate-800/60">
            <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin mb-3" />
            <p className="text-sm font-semibold text-slate-300">Computing MongoDB Fleet Aggregations...</p>
            <p className="text-xs text-slate-500 mt-1">Aggregating telemetry, durations, energy delivered & revenue</p>
          </div>
        )}

        {error && !loading && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 1: EXECUTIVE OVERVIEW                                      */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'overview' && overviewData && (
          <div className="space-y-6">
            {/* Top 4 Primary KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Card 1: Total Energy Delivered */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-emerald-500/40 transition-all">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Energy Delivered</span>
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <Zap className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white tracking-tight">
                    {overviewData.summaryCards.totalEnergyDeliveredKwh.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-emerald-400">kWh</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5 flex items-center gap-1.5">
                  <span className="text-emerald-400 font-semibold">{overviewData.summaryCards.totalSessions}</span>
                  <span>completed sessions</span>
                </p>
              </div>

              {/* Card 2: Fleet Utilization Rate */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-cyan-500/40 transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Fleet Utilization</span>
                    <button
                      onClick={() => setShowFormulaInfo(true)}
                      className="text-slate-500 hover:text-cyan-400"
                      title="Charging Time / Operating Time"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white tracking-tight">
                    {overviewData.summaryCards.fleetUtilizationRate}%
                  </span>
                  <span className="text-xs font-bold text-cyan-400">Occupancy</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">Active charging time vs capacity</p>
              </div>

              {/* Card 3: Fleet Availability Rate */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-teal-500/40 transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Fleet Availability</span>
                    <button
                      onClick={() => setShowFormulaInfo(true)}
                      className="text-slate-500 hover:text-teal-400"
                      title="Ready Operational Time / Total Time"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white tracking-tight">
                    {overviewData.summaryCards.fleetAvailabilityRate}%
                  </span>
                  <span className="text-xs font-bold text-teal-400">Ready</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">
                  {overviewData.summaryCards.activeChargers} of {overviewData.summaryCards.totalChargers} bays operational
                </p>
              </div>

              {/* Card 4: Total Revenue Generated */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-amber-500/40 transition-all">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Revenue Generated</span>
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                    <DollarSign className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white tracking-tight">
                    ₹{overviewData.summaryCards.totalRevenue.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-amber-400">INR</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">
                  Avg ticket: ₹{overviewData.revenueOverview.avgRevenuePerSession} / session
                </p>
              </div>
            </div>

            {/* Secondary 4 KPI Indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Historical Peak Window */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 flex-shrink-0">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Historical Observed Peak
                  </span>
                  <p className="text-sm font-bold text-white mt-0.5">
                    {overviewData.summaryCards.historicalPeakWindow}
                  </p>
                  <p className="text-[11px] text-rose-400 font-medium">
                    {overviewData.summaryCards.historicalPeakConsumptionKwh} kWh measured
                  </p>
                </div>
              </div>

              {/* Energy Conversion Efficiency */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 flex-shrink-0">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Inverter Efficiency
                  </span>
                  <p className="text-sm font-bold text-white mt-0.5">
                    {overviewData.summaryCards.energyEfficiencyPercent}%
                  </p>
                  <p className="text-[11px] text-indigo-400 font-medium">Delivered vs Grid Input</p>
                </div>
              </div>

              {/* Hardware Reliability Uptime */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 flex-shrink-0">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    ESP32 Reliability
                  </span>
                  <p className="text-sm font-bold text-white mt-0.5">
                    {overviewData.summaryCards.hardwareReliabilityPercent}%
                  </p>
                  <p className="text-[11px] text-emerald-400 font-medium">Hardware heartbeat uptime</p>
                </div>
              </div>

              {/* Active Alerts */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 flex-shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Safety & Alerts
                  </span>
                  <p className="text-sm font-bold text-white mt-0.5">
                    {overviewData.summaryCards.activeAlertsCount} Active / {overviewData.summaryCards.totalFaults} Total
                  </p>
                  <p className="text-[11px] text-amber-400 font-medium">
                    {overviewData.recentAlertsSummary.criticalCount} Critical
                  </p>
                </div>
              </div>
            </div>

            {/* Charts Row: Recent Daily Energy & Top Stations */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Daily Energy Consumption Chart */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Daily Energy Delivered (Recent Days)</h3>
                    <p className="text-xs text-slate-400">Total electrical power supplied to EVs</p>
                  </div>
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                    kWh / Day
                  </span>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={overviewData.energyOverview.dailyTrend}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="day" stroke="#64748b" textAnchor="end" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                        formatter={(val) => [`${val} kWh`, 'Energy Delivered']}
                      />
                      <Bar dataKey="energy" fill="#10b981" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Top Performing Stations Table */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-sm font-bold text-white">Top Performing Stations</h3>
                      <p className="text-xs text-slate-400">Ranked by total energy delivered</p>
                    </div>
                    <button
                      onClick={() => setActiveTab('stations')}
                      className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
                    >
                      <span>View All</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-3">
                    {overviewData.topStations.map((st, i) => (
                      <div
                        key={st.stationId || i}
                        className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-xs text-emerald-400 border border-slate-700">
                            #{i + 1}
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-white">{st.name}</p>
                            <p className="text-[11px] text-slate-400">{st.city} • {st.totalChargers} Bays</p>
                          </div>
                        </div>

                        <div className="text-right">
                          <p className="text-xs font-bold text-emerald-400">{st.energyDelivered} kWh</p>
                          <p className="text-[11px] text-slate-400">{st.percentageContribution}% of fleet</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>Network Fleet Capacity: {overviewData.summaryCards.totalChargers} Chargers</span>
                  <span className="text-emerald-400 font-semibold">100% Real Mongo Aggregations</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 2: ADVANCED ENERGY & DEMAND                                */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'energy' && energyData && (
          <div className="space-y-6">
            {/* Historical Observed Peak Demand Banner */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-rose-950/40 via-slate-900 to-amber-950/30 border border-rose-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 flex-shrink-0">
                  <Flame className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold uppercase px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                      Historical observed peak
                    </span>
                    <span className="text-xs text-slate-400">Measured from database sessions</span>
                  </div>
                  <h3 className="text-lg font-black text-white mt-1">
                    Peak Demand Window: {energyData.historicalObservedPeak.time}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Highest aggregate energy recorded: <span className="font-bold text-rose-300">{energyData.historicalObservedPeak.energy} kWh</span>. Avoids predictive phrasing; strictly derived from observed historical load.
                  </p>
                </div>
              </div>

              <div className="text-right flex-shrink-0">
                <p className="text-xs text-slate-400">Avg Daily Consumption</p>
                <p className="text-xl font-black text-emerald-400">{energyData.summary.avgDailyEnergy} kWh</p>
              </div>
            </div>

            {/* 24-Hour Energy Consumption Profile */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white">24-Hour Hourly Consumption Profile (00:00 – 23:00)</h3>
                  <p className="text-xs text-slate-400">Aggregated charging energy consumed across all hours of the day</p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block" />
                    Off-Peak
                  </span>
                  <span className="flex items-center gap-1.5 text-rose-400 font-semibold">
                    <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block" />
                    Historical Peak
                  </span>
                </div>
              </div>

              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={energyData.hourlyEnergy}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="hour" stroke="#64748b" fontSize={10} interval={1} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      formatter={(val, name, item) => [
                        `${val} kWh (${item.payload.sessions} sessions)`,
                        item.payload.hour === energyData.historicalObservedPeak.time.split('–')[0]
                          ? 'Historical Observed Peak'
                          : 'Delivered Energy',
                      ]}
                    />
                    <Bar
                      dataKey="energy"
                      radius={[6, 6, 0, 0]}
                      fill="#10b981"
                    >
                      {energyData.hourlyEnergy.map((entry, index) => {
                        const isPeak = entry.energy === energyData.historicalObservedPeak.energy && entry.energy > 0;
                        return <Cell key={`cell-${index}`} fill={isPeak ? '#f43f5e' : '#10b981'} />;
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* IoT Sensor Telemetry & Inverter Efficiency */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Sensor Telemetry Stats */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">IoT Sensor Readings & Voltage/Current Stability</h3>
                    <p className="text-xs text-slate-400">Live readings from ESP32 ADS1115 & ACS712 sensors</p>
                  </div>
                  <span className="text-[11px] font-bold text-teal-400 px-2 py-0.5 rounded bg-teal-500/10 border border-teal-500/20">
                    {energyData.sensorTelemetry.temperature.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-[11px] text-slate-400">Avg Voltage</p>
                    <p className="text-lg font-bold text-white mt-0.5">{energyData.sensorTelemetry.voltage.average} V</p>
                    <p className="text-[10px] text-slate-500">Range: {energyData.sensorTelemetry.voltage.min}V - {energyData.sensorTelemetry.voltage.max}V</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-[11px] text-slate-400">Avg Current</p>
                    <p className="text-lg font-bold text-white mt-0.5">{energyData.sensorTelemetry.current.average} A</p>
                    <p className="text-[10px] text-slate-500">Max: {energyData.sensorTelemetry.current.max} A</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-[11px] text-slate-400">Avg Power</p>
                    <p className="text-lg font-bold text-white mt-0.5">{energyData.sensorTelemetry.power.average} kW</p>
                    <p className="text-[10px] text-slate-500">Peak: {energyData.sensorTelemetry.power.peakRecorded} kW</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-[11px] text-slate-400">Avg Temperature</p>
                    <p className="text-lg font-bold text-white mt-0.5">{energyData.sensorTelemetry.temperature.average} °C</p>
                    <p className="text-[10px] text-slate-500">Safety Limit: {energyData.sensorTelemetry.temperature.safetyThreshold} °C</p>
                  </div>
                </div>

                {/* Telemetry Curves Chart */}
                <div className="h-52 mt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={energyData.sensorTelemetry.timeSeries}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={10} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      />
                      <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                      <Line type="monotone" dataKey="voltage" stroke="#38bdf8" name="Voltage (V)" dot={false} strokeWidth={2} />
                      <Line type="monotone" dataKey="current" stroke="#f59e0b" name="Current (A)" dot={false} strokeWidth={2} />
                      <Line type="monotone" dataKey="temperature" stroke="#f43f5e" name="Temp (°C)" dot={false} strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Energy Efficiency & Conversion Card */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white mb-1">Energy Conversion & Losses</h3>
                  <p className="text-xs text-slate-400 mb-4">Grid AC input vs Vehicle Battery DC delivery</p>

                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center mb-4">
                    <span className="text-xs text-slate-400">Measured Inverter Efficiency</span>
                    <p className="text-4xl font-black text-emerald-400 mt-1">
                      {energyData.energyEfficiency.efficiencyPercent}%
                    </p>
                    <span className="text-[11px] text-slate-400">Evaluated across {energyData.energyEfficiency.evaluatedSessions} sessions</span>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Total Grid Input Energy:</span>
                      <span className="font-bold text-white">{energyData.energyEfficiency.totalInputEnergy} kWh</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Total Delivered to EV:</span>
                      <span className="font-bold text-emerald-400">{energyData.energyEfficiency.totalDeliveredEnergy} kWh</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Inverter Thermal Loss:</span>
                      <span className="font-bold text-rose-400">{energyData.energyEfficiency.conversionLoss} kWh</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400">
                  ⚡ High-efficiency GaN switching modules retain 93%+ under nominal thermal dissipation.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 3: CHARGING PATTERNS & BEHAVIOR                            */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'charging' && chargingData && (
          <div className="space-y-6">
            {/* Row 1: Duration Distribution & Energy Distribution */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Session Duration Buckets */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Session Duration Distribution</h3>
                    <p className="text-xs text-slate-400">
                      Avg: {chargingData.durationStats.averageDuration} min • Median: {chargingData.durationStats.medianDuration} min
                    </p>
                  </div>
                  <span className="text-xs text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    Minutes Buckets
                  </span>
                </div>

                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chargingData.durationStats.durationBuckets}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                        formatter={(val) => [`${val} sessions`, 'Count']}
                      />
                      <Bar dataKey="count" fill="#06b6d4" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Energy Per Session Buckets */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Energy Delivered Per Session</h3>
                    <p className="text-xs text-slate-400">
                      Avg: {chargingData.durationStats.averageEnergyPerSession} kWh / session
                    </p>
                  </div>
                  <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    kWh Range
                  </span>
                </div>

                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chargingData.energyDistribution}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                        formatter={(val) => [`${val} sessions`, 'Count']}
                      />
                      <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Row 2: Time of Day & Day of Week */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Time of Day Distribution */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Time-of-Day Charging Breakdown</h3>
                    <p className="text-xs text-slate-400">Morning, Afternoon, Evening, and Night intervals</p>
                  </div>
                </div>

                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chargingData.timeOfDayDistribution}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="interval" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                        formatter={(val, name, item) => [`${val} sessions (${item.payload.energy} kWh)`, 'Volume']}
                      />
                      <Bar dataKey="sessions" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Day of Week Distribution */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Day-of-Week Activity Curve</h3>
                    <p className="text-xs text-slate-400">Weekly operational demand distribution (Mon – Sun)</p>
                  </div>
                </div>

                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chargingData.dayOfWeekDistribution}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                        formatter={(val, name, item) => [`${val} sessions (${item.payload.energy} kWh)`, 'Sessions']}
                      />
                      <Bar dataKey="sessions" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Row 3: Connector Types & Booking Cancellation Analysis */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Connector Share */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-1">Connector Standard Share</h3>
                <p className="text-xs text-slate-400 mb-4">CCS2, Type 2, and CHAdeMO usage</p>

                <div className="space-y-3">
                  {chargingData.connectorAnalytics.map((c, i) => (
                    <div key={c.connectorType} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                        <span className="text-xs font-bold text-white">{c.connectorType}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold text-emerald-400">{c.energy} kWh</p>
                        <p className="text-[10px] text-slate-400">{c.sessions} sessions • avg {c.averageDuration}m</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Booking Cancellation & No-Show */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 lg:col-span-2">
                <h3 className="text-sm font-bold text-white mb-1">Booking Fulfillment vs Cancellation & No-Show</h3>
                <p className="text-xs text-slate-400 mb-4">Operational slot adherence metrics</p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <p className="text-[11px] text-slate-400">Total Bookings</p>
                    <p className="text-xl font-black text-white mt-1">{chargingData.bookingAnalytics.totalBookings}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <p className="text-[11px] text-slate-400">Completed Slots</p>
                    <p className="text-xl font-black text-emerald-400 mt-1">{chargingData.bookingAnalytics.completedBookings}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <p className="text-[11px] text-slate-400">Cancellation Rate</p>
                    <p className="text-xl font-black text-amber-400 mt-1">{chargingData.bookingAnalytics.cancellationRate}%</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <p className="text-[11px] text-slate-400">No-Show (Expired)</p>
                    <p className="text-xl font-black text-rose-400 mt-1">{chargingData.bookingAnalytics.noShowCount}</p>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Overall Slot Fulfillment Rate: <strong>{chargingData.bookingAnalytics.fulfillmentRate}%</strong></span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 4: STATIONS & CHARGER UTILIZATION                          */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'stations' && stationData && (
          <div className="space-y-6">
            {/* Station Load Contribution Bar Chart */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white">Station Energy Contribution (%)</h3>
                  <p className="text-xs text-slate-400">Percentage share of total network electrical load</p>
                </div>
                <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-semibold">
                  Network Total: {stationData.totalEnergyDelivered} kWh
                </span>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stationData.stations} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis type="number" stroke="#64748b" fontSize={11} domain={[0, 100]} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} width={140} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      formatter={(val, name, item) => [`${val}% (${item.payload.energyDelivered} kWh)`, 'Contribution']}
                    />
                    <Bar dataKey="percentageContribution" fill="#10b981" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Station Performance Detailed Table */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white">Station Performance & Utilization Breakdown</h3>
                  <p className="text-xs text-slate-400">Comparing energy delivered, occupancy rate and technical availability</p>
                </div>
              </div>

              <div className="overflow-x-auto custom-scrollbar">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="py-3 px-3">Station Name</th>
                      <th className="py-3 px-3">City</th>
                      <th className="py-3 px-3">Bays</th>
                      <th className="py-3 px-3">Energy (kWh)</th>
                      <th className="py-3 px-3">Load Share</th>
                      <th className="py-3 px-3">Sessions</th>
                      <th className="py-3 px-3">Utilization %</th>
                      <th className="py-3 px-3">Availability %</th>
                      <th className="py-3 px-3">Revenue (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-medium">
                    {stationData.stations.map((s) => (
                      <tr key={s.stationId} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 font-semibold text-white">{s.name}</td>
                        <td className="py-3 px-3 text-slate-400">{s.city}</td>
                        <td className="py-3 px-3 text-slate-300">{s.totalChargers}</td>
                        <td className="py-3 px-3 font-bold text-emerald-400">{s.energyDelivered}</td>
                        <td className="py-3 px-3 text-slate-300">{s.percentageContribution}%</td>
                        <td className="py-3 px-3 text-slate-300">{s.sessionsCount}</td>
                        <td className="py-3 px-3 font-semibold text-cyan-400">{s.utilizationPercent}%</td>
                        <td className="py-3 px-3 font-semibold text-teal-400">{s.availabilityRate}%</td>
                        <td className="py-3 px-3 font-bold text-amber-400">₹{s.revenueGenerated.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Individual Charger Bay Activity Ranking */}
            {chargerData && (
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Individual Charger Bay Utilization & Activity</h3>
                    <p className="text-xs text-slate-400">Sorted by highest energy delivered</p>
                  </div>
                </div>

                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                      <tr>
                        <th className="py-3 px-3">Bay #</th>
                        <th className="py-3 px-3">Station</th>
                        <th className="py-3 px-3">Type</th>
                        <th className="py-3 px-3">Rating</th>
                        <th className="py-3 px-3">Status</th>
                        <th className="py-3 px-3">Energy (kWh)</th>
                        <th className="py-3 px-3">Sessions</th>
                        <th className="py-3 px-3">Utilization %</th>
                        <th className="py-3 px-3">Faults</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-medium">
                      {chargerData.chargers.map((c) => (
                        <tr key={c.chargerId} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-3 font-bold text-white">{c.chargerNumber}</td>
                          <td className="py-3 px-3 text-slate-400">{c.stationName}</td>
                          <td className="py-3 px-3 text-slate-300">{c.chargerType}</td>
                          <td className="py-3 px-3 text-slate-300">{c.powerRating}</td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                c.status === 'charging'
                                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                  : c.status === 'available'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {c.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-bold text-emerald-400">{c.energyDelivered}</td>
                          <td className="py-3 px-3 text-slate-300">{c.sessionsCount}</td>
                          <td className="py-3 px-3 font-bold text-cyan-400">{c.utilizationPercent}%</td>
                          <td className="py-3 px-3 text-slate-400">
                            {c.faultCount > 0 ? (
                              <span className="text-amber-400 font-bold">{c.faultCount}</span>
                            ) : (
                              '0'
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 5: COMMERCIAL REVENUE & BILLING                            */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'revenue' && revenueData && (
          <div className="space-y-6">
            {/* Top Revenue Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Revenue</p>
                <p className="text-2xl font-black text-white mt-1">₹{revenueData.summary.totalRevenue.toLocaleString()}</p>
                <p className="text-[11px] text-emerald-400 mt-0.5">{revenueData.summary.totalTransactions} Invoices Billed</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Billed Energy</p>
                <p className="text-2xl font-black text-white mt-1">{revenueData.summary.totalEnergyBilled.toLocaleString()} kWh</p>
                <p className="text-[11px] text-cyan-400 mt-0.5">Average: ₹{revenueData.summary.avgRevenuePerKwh} / kWh</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Average Ticket</p>
                <p className="text-2xl font-black text-amber-400 mt-1">₹{revenueData.summary.avgRevenuePerSession}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Revenue per completed session</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Payment Realization</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">
                  ₹{revenueData.paymentBreakdown.paid.amount.toLocaleString()}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">{revenueData.paymentBreakdown.paid.count} Paid Transactions</p>
              </div>
            </div>

            {/* Daily Revenue Trend Chart */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white">Daily Revenue Generation (₹)</h3>
                  <p className="text-xs text-slate-400">Day-by-day commercial revenue billed to EV drivers</p>
                </div>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData.dailyRevenue}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      formatter={(val) => [`₹${val}`, 'Revenue']}
                    />
                    <Area type="monotone" dataKey="revenue" stroke="#f59e0b" fillOpacity={1} fill="url(#colorRev)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Revenue by Station Table */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-1">Station Revenue & Tariff Breakdown</h3>
              <p className="text-xs text-slate-400 mb-4">Commercial performance per location</p>

              <div className="overflow-x-auto custom-scrollbar">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="py-3 px-3">Station Name</th>
                      <th className="py-3 px-3">City</th>
                      <th className="py-3 px-3">Revenue (₹)</th>
                      <th className="py-3 px-3">Share %</th>
                      <th className="py-3 px-3">Energy (kWh)</th>
                      <th className="py-3 px-3">Sessions</th>
                      <th className="py-3 px-3">Base Tariff (₹/kWh)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-medium">
                    {revenueData.revenueByStation.map((s) => (
                      <tr key={s.stationId} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 font-semibold text-white">{s.stationName}</td>
                        <td className="py-3 px-3 text-slate-400">{s.city}</td>
                        <td className="py-3 px-3 font-bold text-amber-400">₹{s.revenue.toLocaleString()}</td>
                        <td className="py-3 px-3 text-slate-300">{s.percentage}%</td>
                        <td className="py-3 px-3 text-emerald-400">{s.energy}</td>
                        <td className="py-3 px-3 text-slate-300">{s.sessions}</td>
                        <td className="py-3 px-3 text-slate-300">₹{s.avgTariff}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 6: FAULTS & HARDWARE RELIABILITY                           */}
        {/* ============================================================== */}
        {!loading && !error && activeTab === 'faults' && faultData && (
          <div className="space-y-6">
            {/* Fault Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Fault Alerts</p>
                <p className="text-2xl font-black text-white mt-1">{faultData.summary.totalFaults}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{faultData.summary.resolvedFaults} Resolved</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Active Faults</p>
                <p className="text-2xl font-black text-rose-400 mt-1">{faultData.summary.activeFaults}</p>
                <p className="text-[11px] text-rose-400/80 mt-0.5">{faultData.summary.criticalFaults} Critical Severity</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Avg Resolution Time</p>
                <p className="text-2xl font-black text-teal-400 mt-1">{faultData.summary.avgResolutionTimeMin} min</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Mean time to repair/reset</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">ESP32 Fleet Reliability</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{faultData.summary.avgDeviceReliability}%</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Hardware uptime rate</p>
              </div>
            </div>

            {/* Faults by Type & Faults by Severity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Faults by Type */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-1">Fault Occurrence by Category</h3>
                <p className="text-xs text-slate-400 mb-4">Hardware trip alarms and communication timeouts</p>

                <div className="space-y-3">
                  {faultData.faultsByType.map((f, i) => (
                    <div key={f.type} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-300">{f.label}</span>
                        <span className="text-slate-400">{f.count} events ({f.percentage}%)</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${f.percentage}%`,
                            backgroundColor: COLORS[i % COLORS.length],
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Charger Fault Ranking */}
              <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-1">Charger Fault Frequency Ranking</h3>
                <p className="text-xs text-slate-400 mb-4">Identifies bays requiring physical hardware servicing</p>

                <div className="space-y-2.5">
                  {faultData.chargerFaultRanking.slice(0, 5).map((ch) => (
                    <div
                      key={ch.chargerId}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <p className="text-xs font-bold text-white">{ch.chargerId}</p>
                        <p className="text-[11px] text-slate-400">{ch.stationName}</p>
                      </div>

                      <div className="text-right">
                        <p className="text-xs font-bold text-rose-400">{ch.totalFaults} Faults</p>
                        <p className="text-[10px] text-slate-400">{ch.critical} Critical</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* ESP32 Hardware Devices Table */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-1">ESP32 Hardware Controllers Status & Reliability</h3>
              <p className="text-xs text-slate-400 mb-4">Embedded hardware watchdog and signal strength telemetry</p>

              <div className="overflow-x-auto custom-scrollbar">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="py-3 px-3">Device ID</th>
                      <th className="py-3 px-3">Charger Bay</th>
                      <th className="py-3 px-3">Firmware</th>
                      <th className="py-3 px-3">WiFi RSSI</th>
                      <th className="py-3 px-3">Relay</th>
                      <th className="py-3 px-3">Uptime Status</th>
                      <th className="py-3 px-3">Faults Logged</th>
                      <th className="py-3 px-3">Reliability Score</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-medium">
                    {faultData.devices.map((d) => (
                      <tr key={d.deviceId} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 font-mono font-bold text-teal-400">{d.deviceId}</td>
                        <td className="py-3 px-3 text-white font-semibold">{d.chargerId}</td>
                        <td className="py-3 px-3 text-slate-400">{d.firmwareVersion}</td>
                        <td className="py-3 px-3 text-slate-300 font-mono">{d.rssi} dBm</td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              d.relayState === 'ON'
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {d.relayState}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              d.isAlive
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            }`}
                          >
                            {d.isAlive ? 'ONLINE' : 'OFFLINE'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-300">{d.faultCount}</td>
                        <td className="py-3 px-3 font-bold text-emerald-400">{d.reliabilityScore}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* MODAL: FORMULA DEFINITIONS & TECHNICAL STANDARDS               */}
        {/* ============================================================== */}
        {showFormulaInfo && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-teal-400" />
                  <h3 className="text-base font-bold text-white">Analytics Metric Formulations</h3>
                </div>
                <button
                  onClick={() => setShowFormulaInfo(false)}
                  className="text-slate-400 hover:text-white text-sm"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-cyan-400 uppercase tracking-wider text-[11px]">
                    1. Charger Utilization Rate (%)
                  </span>
                  <div className="p-2 rounded bg-slate-900 font-mono text-[11px] text-white">
                    Utilization = (Active Charging Time) / (Available Operating Time) × 100
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Quantifies the proportion of scheduled operating minutes that the charger is actively delivering electrical energy to a connected vehicle battery.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-teal-400 uppercase tracking-wider text-[11px]">
                    2. Fleet Availability Rate (%)
                  </span>
                  <div className="p-2 rounded bg-slate-900 font-mono text-[11px] text-white">
                    Availability = (Operational Non-Fault Time) / (Total Time) × 100
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Measures the percentage of time chargers are healthy, online on WiFi/Modbus, and fully ready for driver arrival without hardware trip faults.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                    3. Key Distinction
                  </span>
                  <p className="text-slate-400 leading-relaxed">
                    <strong>Availability</strong> reflects hardware uptime and system readiness.
                    <strong>Utilization</strong> reflects actual consumer demand and commercial occupancy. A charger can have 99% availability with 40% utilization.
                  </p>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setShowFormulaInfo(false)}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors"
                >
                  Close Reference
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminAnalyticsScreen;
