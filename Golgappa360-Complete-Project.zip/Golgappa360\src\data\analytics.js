export const userProfileData = {
  username: "Sumanth",
  handle: "@sumanth_lens",
  avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80",
  bio: "Audiophile hunting for songs half-remembered from college days and rainy night car rides.",
  memberSince: "January 2024",
  favoriteGenre: "Indie Folk & Synthwave",
  favoriteArtists: ["Aarav Sen", "The Midnight Echoes", "Luna Vance"],
  stats: {
    songsSearched: 184,
    songsSaved: 42,
    playlistsCreated: 6,
    searchStreakDays: 14
  },
  searchBreakdown: [
    { method: "Lyrics Fragment", percentage: 52, count: 96, icon: "FileText" },
    { method: "AI Natural Language", percentage: 28, count: 52, icon: "Sparkles" },
    { method: "Voice / Humming", percentage: 12, count: 22, icon: "Mic" },
    { method: "Artist / Title Direct", percentage: 8, count: 14, icon: "Music" }
  ],
  moodDistribution: [
    { mood: "Sad & Melancholy", value: 38 },
    { mood: "Chill & Ambient", value: 27 },
    { mood: "Romantic", value: 18 },
    { mood: "Energetic / Party", value: 17 }
  ],
  monthlyActivity: [
    { month: "Apr", searches: 22 },
    { month: "May", searches: 35 },
    { month: "Jun", searches: 48 },
    { month: "Jul", searches: 62 },
    { month: "Aug", searches: 58 },
    { month: "Sep", searches: 84 }
  ]
};

export const adminAnalyticsData = {
  overviewCards: [
    { id: "stat-1", title: "Total Catalog Songs", value: "14,820", change: "+12.4%", trend: "up", period: "vs last month" },
    { id: "stat-2", title: "Verified Artists", value: "1,940", change: "+8.1%", trend: "up", period: "vs last month" },
    { id: "stat-3", title: "Monthly Searches", value: "542,800", change: "+24.5%", trend: "up", period: "vs last month" },
    { id: "stat-4", title: "Active Discoverers", value: "38,210", change: "+19.2%", trend: "up", period: "vs last month" }
  ],
  searchVolumeTimeline: [
    { time: "00:00", volume: 1200 },
    { time: "04:00", volume: 600 },
    { time: "08:00", volume: 3400 },
    { time: "12:00", volume: 7200 },
    { time: "16:00", volume: 8900 },
    { time: "20:00", volume: 11400 },
    { time: "23:00", volume: 6800 }
  ],
  recentSearchesLog: [
    { id: "log-1", query: "remember the chorus but not song", type: "AI Semantic", success: true, match: "Midnight Highway Drive", timestamp: "Just now" },
    { id: "log-2", query: "bheegi shaam boondon se baatein", type: "Lyric Match", success: true, match: "Bheegi Baarish Ki Dhun", timestamp: "1 min ago" },
    { id: "log-3", query: "red balloon whistle song 2014", type: "Natural Lang", success: false, match: "No direct match", timestamp: "3 mins ago" },
    { id: "log-4", query: "Kabir Dhillon new track", type: "Artist Query", success: true, match: "Chandigarh De Raah", timestamp: "5 mins ago" },
    { id: "log-5", query: "velvet shadows ghost on floor", type: "Lyric Match", success: true, match: "Electric Mirage", timestamp: "7 mins ago" }
  ]
};
