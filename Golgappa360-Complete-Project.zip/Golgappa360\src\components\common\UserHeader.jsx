import React from 'react';
import { Header } from './Header';

export const UserHeader = (props) => {
  return <Header {...props} />;
};

export default UserHeader;
