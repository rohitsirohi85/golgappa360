import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  Timer,
  Search,
  Filter,
  Zap,
  DollarSign,
  Clock,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  X,
} from 'lucide-react';

export const AdminSessionsScreen = () => {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedSession, setSelectedSession] = useState(null);

  const fetchSessions = async () => {
    try {
      setLoading(true);
      const data = await adminService.getSessions();
      if (Array.isArray(data)) {
        setSessions(data);
      }
    } catch (err) {
      console.error('Error fetching sessions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const filteredSessions = sessions.filter((s) => {
    const matchesSearch =
      s.userId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.chargerId?.chargerNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.stationId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s._id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalKwh = sessions.reduce((acc, s) => acc + (s.energyConsumed || 0), 0);
  const totalRevenue = sessions.reduce((acc, s) => acc + (s.cost || 0), 0);
  const activeCount = sessions.filter((s) => s.status === 'charging' || s.status === 'active').length;

  return (
    <AdminLayout
      pageTitle="Charging Sessions Ledger"
      subtitle="Comprehensive audit trail of energy dispensed, duration & transaction settlement"
    >
      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Active Charging</span>
          <div className="text-2xl font-black text-sky-400 font-mono">{activeCount}</div>
          <span className="text-xs text-slate-400">Concurrent sessions</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Energy Delivered</span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {Math.round(totalKwh * 10) / 10} kWh
          </div>
          <span className="text-xs text-slate-400">Total fleet throughput</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Gross Invoiced</span>
          <div className="text-2xl font-black text-white font-mono">₹{totalRevenue}</div>
          <span className="text-xs text-slate-400">Completed session billing</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search driver, session ID, charger..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            {['all', 'completed', 'charging', 'interrupted'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg capitalize font-semibold transition-colors ${
                  statusFilter === st
                    ? 'bg-emerald-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchSessions}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Sessions Table */}
      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading sessions ledger...</p>
        </div>
      ) : filteredSessions.length === 0 ? (
        <div className="h-64 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-slate-500 text-xs">
          <Timer className="w-10 h-10 mb-2 text-slate-700" />
          <p>No charging sessions found.</p>
        </div>
      ) : (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                  <th className="py-4 px-6 font-bold">Session ID</th>
                  <th className="py-4 px-6 font-bold">Driver Name</th>
                  <th className="py-4 px-6 font-bold">Station & Bay</th>
                  <th className="py-4 px-6 font-bold text-center">Energy (kWh)</th>
                  <th className="py-4 px-6 font-bold text-center">Duration</th>
                  <th className="py-4 px-6 font-bold">Status</th>
                  <th className="py-4 px-6 font-bold text-right">Cost</th>
                  <th className="py-4 px-6 font-bold text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredSessions.map((s) => {
                  const isCharging = s.status === 'charging' || s.status === 'active';

                  return (
                    <tr
                      key={s._id}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                      onClick={() => setSelectedSession(s)}
                    >
                      <td className="py-4 px-6 font-mono text-slate-400">
                        {s._id.slice(-6).toUpperCase()}
                      </td>
                      <td className="py-4 px-6 font-bold text-white">
                        {s.userId?.name || 'EV Driver'}
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-semibold text-white block">
                          {s.chargerId?.chargerNumber || 'CH-01'}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {s.stationId?.name || 'EV Station'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-center font-mono font-bold text-emerald-400">
                        {s.energyConsumed || 0} kWh
                      </td>
                      <td className="py-4 px-6 text-center text-slate-400 font-mono">
                        {s.duration || 45} mins
                      </td>
                      <td className="py-4 px-6">
                        <span
                          className={`text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${
                            isCharging
                              ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30 animate-pulse'
                              : s.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right font-mono font-bold text-white">
                        ₹{s.cost || 0}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedSession(s);
                          }}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Session Detail Modal */}
      {selectedSession && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Session Audit Breakdown</h3>
                  <p className="text-xs text-slate-400 font-mono">ID: {selectedSession._id}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedSession(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Customer</span>
                <span className="font-bold text-white">{selectedSession.userId?.name || 'EV Driver'}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Station</span>
                <span className="font-semibold text-white">{selectedSession.stationId?.name || 'EV Hub'}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Charger Bay</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {selectedSession.chargerId?.chargerNumber || 'CH-01'}
                </span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Energy Dispensed</span>
                <span className="font-mono text-white font-bold">{selectedSession.energyConsumed || 0} kWh</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Duration</span>
                <span className="font-mono text-slate-300">{selectedSession.duration || 45} minutes</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-800/80">
                <span className="text-slate-400">Total Billed</span>
                <span className="font-mono text-emerald-400 font-extrabold text-sm">
                  ₹{selectedSession.cost || 0}
                </span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-400">Created At</span>
                <span className="text-slate-500 font-mono">
                  {new Date(selectedSession.createdAt).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedSession(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
              >
                Close Audit View
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminSessionsScreen;
