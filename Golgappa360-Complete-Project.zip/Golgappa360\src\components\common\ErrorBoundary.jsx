import React from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an unhandled error:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#070B19] flex flex-col items-center justify-center p-6 text-white text-center">
          <div className="w-16 h-16 rounded-3xl bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>

          <h2 className="text-xl font-bold mb-2">Something went wrong</h2>
          <p className="text-sm text-red-400 font-mono max-w-sm mb-2">
            {this.state.error?.message || 'An unexpected rendering error occurred.'}
          </p>
          {this.state.error?.stack && (
            <pre className="text-[10px] text-slate-400 bg-black/60 p-2 rounded max-h-32 overflow-auto text-left w-full max-w-sm mb-4 select-text">
              {this.state.error.stack}
            </pre>
          )}

          <div className="flex flex-col w-full max-w-xs gap-3">
            <button
              onClick={this.handleReload}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#00F5A0] text-[#050811] font-semibold text-sm shadow-[0_0_20px_rgba(0,245,160,0.3)] hover:opacity-95 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reload App</span>
            </button>

            <button
              onClick={this.handleGoHome}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/10 text-white font-medium text-sm hover:bg-white/15 active:scale-95 transition-all cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Go to Overview Dashboard</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
