import React from 'react';

/**
 * Reusable Button component for STELLAR
 * Variants: 'primary' | 'secondary' | 'ghost' | 'outline'
 */
export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  className = '',
  disabled = false,
  icon = null,
  ...props
}) {
  const baseStyles =
    'relative inline-flex items-center justify-center font-sans font-medium select-none transition-all duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#020308] disabled:opacity-50 disabled:pointer-events-none group overflow-hidden cursor-pointer';

  const sizeStyles = {
    sm: 'text-xs px-3.5 py-1.5 rounded-full gap-1.5 tracking-wide',
    md: 'text-sm px-6 py-2.5 rounded-full gap-2 tracking-wide',
    lg: 'text-base px-8 py-3.5 rounded-full gap-2.5 tracking-wide',
  };

  const variantStyles = {
    primary:
      'bg-[#080d1e] text-white border border-cyan-500/40 hover:border-cyan-400/80 hover:bg-[#0c142c] shadow-[0_0_15px_rgba(34,211,238,0.12)] hover:shadow-[0_0_22px_rgba(34,211,238,0.22)] hover:-translate-y-0.5 active:translate-y-0',
    secondary:
      'bg-white/[0.025] backdrop-blur-md text-slate-200 border border-white/10 hover:bg-white/[0.05] hover:border-white/20 hover:text-white hover:-translate-y-0.5 active:translate-y-0',
    stellar:
      'bg-[#140d05] text-amber-200 border border-amber-500/40 hover:border-amber-400/80 hover:bg-[#1f1508] shadow-[0_0_15px_rgba(245,158,11,0.12)] hover:shadow-[0_0_22px_rgba(245,158,11,0.22)] hover:-translate-y-0.5 active:translate-y-0',
    ghost:
      'bg-transparent text-slate-300 hover:text-white hover:bg-white/[0.03] border border-transparent hover:border-white/10',
    outline:
      'bg-transparent border border-white/15 text-slate-200 hover:border-cyan-400/40 hover:text-white hover:bg-white/[0.02] hover:-translate-y-0.5 active:translate-y-0',
  };

  const combinedClasses = `${baseStyles} ${sizeStyles[size] || sizeStyles.md} ${variantStyles[variant] || variantStyles.primary} ${className}`;

  // Content with optional subtle shimmer highlight
  const content = (
    <>
      {/* Light sheen effect on hover */}
      <span
        aria-hidden="true"
        className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent group-hover:translate-x-full transition-transform duration-1000 ease-in-out pointer-events-none"
      />
      <span className="relative z-10 flex items-center gap-2">
        {children}
        {icon && <span className="transition-transform duration-300 group-hover:translate-x-0.5">{icon}</span>}
      </span>
    </>
  );

  if (href) {
    return (
      <a href={href} onClick={onClick} className={combinedClasses} {...props}>
        {content}
      </a>
    );
  }

  return (
    <button type="button" onClick={onClick} disabled={disabled} className={combinedClasses} {...props}>
      {content}
    </button>
  );
}
