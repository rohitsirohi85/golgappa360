import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { mockStore } from '../data/mockStore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const exportDir = path.resolve(__dirname, '../../../data/exports');

if (!fs.existsSync(exportDir)) {
  fs.mkdirSync(exportDir, { recursive: true });
}

function writeCSV(filename, headers, rows) {
  const headerLine = headers.map(h => `"${h.replace(/"/g, '""')}"`).join(',');
  const rowLines = rows.map(row => 
    row.map(val => {
      if (val === null || val === undefined) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );
  const content = [headerLine, ...rowLines].join('\r\n');
  const filePath = path.join(exportDir, filename);
  fs.writeFileSync(filePath, content, 'utf-8');
  console.log(`[Export] Wrote ${rows.length} records to ${filename}`);
}

console.log('Generating Tableau & Excel ready CSV datasets...');

// 1. Daily Sales Summary
writeCSV(
  'golgappa_daily_sales_summary.csv',
  [
    'Date', 'Day_Of_Week', 'Total_Orders', 'Total_Plates_Sold', 
    'Gross_Revenue_INR', 'Total_COGS_INR', 'Gross_Profit_INR', 
    'Gross_Margin_Pct', 'Daily_Waste_Cost_INR', 'Net_Estimated_Profit_INR', 
    'Waste_Rate_Pct', 'UPI_Revenue_INR', 'Cash_Revenue_INR', 'AOV_INR'
  ],
  mockStore.dailySummaries.map(d => [
    d.date, d.dayOfWeek, d.totalOrders, d.totalPlates,
    d.grossRevenue, d.totalCogs, d.grossProfit,
    d.grossMarginPct, d.dailyWasteCost, d.netEstimatedProfit,
    d.wasteRatePct, d.upiRevenue, d.cashRevenue, d.aov
  ])
);

// 2. Sales Transactions
writeCSV(
  'golgappa_sales_transactions.csv',
  [
    'Transaction_ID', 'Timestamp', 'Time', 'Customer_Type',
    'Items_Summary', 'Total_Plates', 'Gross_Amount_INR',
    'Cost_INR', 'Profit_INR', 'Payment_Method', 'Status'
  ],
  mockStore.transactions.map(t => [
    t.id, t.timestamp, t.time, t.customerType,
    t.itemsSummary, t.totalPlates, t.amount,
    t.cost, t.profit, t.paymentMethod, t.status
  ])
);

// 3. Menu Items & Margins
writeCSV(
  'golgappa_menu_and_margins.csv',
  [
    'Item_Code', 'Name', 'Category', 'Flavour_Profile',
    'Pieces_Per_Plate', 'Selling_Price_INR', 'Cost_Price_INR',
    'Unit_Margin_INR', 'Gross_Margin_Pct'
  ],
  mockStore.menuItems.map(m => [
    m.item_code, m.name, m.category_name, m.flavour_profile,
    m.pieces_per_plate, m.selling_price, m.cost_price,
    (m.selling_price - m.cost_price).toFixed(2), m.margin_pct
  ])
);

// 4. Inventory
writeCSV(
  'golgappa_inventory_stock.csv',
  [
    'Ingredient_Code', 'Name', 'Category', 'Unit',
    'Current_Stock', 'Minimum_Threshold', 'Reorder_Level',
    'Unit_Cost_INR', 'Daily_Avg_Consumption', 'Status'
  ],
  mockStore.ingredients.map(i => [
    i.code, i.name, i.category, i.unit,
    i.current_stock, i.minimum_threshold, i.reorder_level,
    i.unit_cost, i.daily_consumption_avg, i.status
  ])
);

// 5. Food Waste Logs
writeCSV(
  'golgappa_food_waste_log.csv',
  [
    'Log_ID', 'Date', 'Ingredient_Name', 'Quantity_Wasted',
    'Unit', 'Unit_Cost_INR', 'Estimated_Waste_Cost_INR',
    'Reason', 'Severity', 'Recommended_Action'
  ],
  mockStore.wasteLogs.map(w => [
    w.id, w.date, w.ingredient_name, w.quantity,
    w.unit, w.unit_cost, w.estimated_cost,
    w.reason, w.severity, w.recommendation
  ])
);

// 6. Hourly Rush Patterns
writeCSV(
  'golgappa_hourly_footfall_patterns.csv',
  [
    'Hour_24', 'Hour_Label', 'Order_Count', 'Plates_Served',
    'Revenue_Collected_INR', 'COGS_INR', 'Rush_Intensity'
  ],
  mockStore.hourlySalesProfile.map(h => [
    h.hour24, h.hour, h.orders, h.plates,
    h.revenue, h.cogs, h.footfallIntensity
  ])
);

console.log('All CSV datasets successfully generated in data/exports/');
