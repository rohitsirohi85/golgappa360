import { songs } from "../data/songs.js";

export const songService = {
  async getAllSongs() {
    return [...songs];
  },

  async getSongById(id) {
    return songs.find((s) => s.id === id) || null;
  },

  async getTrendingSongs() {
    return songs.slice(0, 8);
  },

  /**
   * Multi-factor similarity algorithm for "Songs You Might Like"
   * Evaluates genre, mood category, language, release year, and tempo.
   * Returns 6 to 8 songs with an assigned similarityReason.
   */
  async getSimilarSongs(id, limit = 8) {
    const current = songs.find((s) => s.id === id);
    if (!current) return songs.slice(0, limit);

    const scored = songs
      .filter((s) => s.id !== id)
      .map((s) => {
        let score = 0;
        let reasons = [];

        // 1. Same Genre (+35)
        if (s.genre.toLowerCase() === current.genre.toLowerCase()) {
          score += 35;
          reasons.push(s.genre);
        }

        // 2. Same Mood (+30)
        if (s.moodCategory.toLowerCase() === current.moodCategory.toLowerCase()) {
          score += 30;
          reasons.push(s.moodCategory);
        }

        // 3. Same Language (+15)
        if (s.language.toLowerCase() === current.language.toLowerCase()) {
          score += 15;
        }

        // 4. Release Era within 2 years (+10)
        if (Math.abs(s.year - current.year) <= 2) {
          score += 10;
        }

        // 5. Energy alignment (+10)
        if (s.songDNA && current.songDNA) {
          const energyDiff = Math.abs(s.songDNA.energy - current.songDNA.energy);
          if (energyDiff <= 15) {
            score += 10;
          }
        }

        let similarityReason = "Similar Track";
        if (reasons.length >= 2) {
          similarityReason = `${reasons[0]} • ${reasons[1]}`;
        } else if (reasons.length === 1) {
          similarityReason = `${reasons[0]} Vibe`;
        }

        return {
          song: s,
          score,
          similarityReason
        };
      });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit).map((item) => ({
      ...item.song,
      similarityReason: item.similarityReason
    }));
  },

  /**
   * Get all other songs by the same artist
   */
  async getSongsByArtist(artistId, excludeSongId = null) {
    return songs.filter(
      (s) => s.artistId === artistId && (!excludeSongId || s.id !== excludeSongId)
    );
  },

  /**
   * Get all tracks belonging to the same album
   */
  async getSongsByAlbum(albumId, excludeSongId = null) {
    return songs.filter(
      (s) => s.albumId === albumId && (!excludeSongId || s.id !== excludeSongId)
    );
  },

  async getSongsByMood(mood) {
    const normalized = (mood || "").toLowerCase();
    return songs.filter(
      (s) =>
        s.moodCategory.toLowerCase() === normalized ||
        s.songDNA?.mood.toLowerCase().includes(normalized)
    );
  }
};
