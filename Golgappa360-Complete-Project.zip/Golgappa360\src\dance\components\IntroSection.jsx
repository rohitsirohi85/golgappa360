import React from 'react';
import { ArrowUpRight, Sparkles, Disc, Flame, Layers } from 'lucide-react';
import { ACADEMY_CONFIG } from '../data/danceData';

export const IntroSection = ({ onOpenTrial }) => {
  const pillars = [
    {
      number: '01',
      title: 'Micro-Mechanics & Anatomy',
      description: 'We do not teach dancers to mimic surface shapes. We deconstruct the physics of weight transfer, thoracic rotation, joint suspension, and deceleration. When you understand your body’s skeletal lever systems, any choreography becomes accessible.',
      tag: 'Physical Architecture'
    },
    {
      number: '02',
      title: 'Artistic Identity Over Uniformity',
      description: 'Commercial studios often homogenize dancers into identical robotic clones. At MOTION IS ART, your natural idiosyncrasies, limb proportions, and personal rhythm are treated as your core artistic advantage. Find your signature voice in the pocket.',
      tag: 'Expressive Agency'
    },
    {
      number: '03',
      title: 'The Cypher as Sacred Laboratory',
      description: 'The cypher is where fear dissolves and innovation occurs in real time. We train dancers to listen to sub-frequencies, read live room energy, and improvise with unflinching confidence before audiences, judges, and cameras.',
      tag: 'Street Culture'
    }
  ];

  return (
    <section
      id="about"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="Academy Philosophy & Introduction"
    >
      {/* Background ambient lighting */}
      <div className="pointer-events-none absolute top-1/4 left-0 w-96 h-96 bg-[#8B5CF6]/10 rounded-full blur-[120px]" />
      
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/[0.08]">
          <div className="max-w-2xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ 02 // MANIFESTO & ORIGIN ]
            </span>
            <h2 className="editorial-headline text-3xl sm:text-5xl lg:text-6xl text-[#F5F3F8] uppercase">
              "EVERY MOVEMENT <br />
              <span className="text-[#A78BFA]">TELLS A STORY."</span>
            </h2>
          </div>
          <p className="font-sans text-sm sm:text-base text-[#A5A1B2] max-w-md leading-relaxed">
            MOTION IS ART was founded at the intersection of underground street culture and avant-garde performance art. We train the body as an instrument of deliberate artistic rebellion.
          </p>
        </div>

        {/* Editorial Pull Quote & Narrative Layout */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#14141B]">
              <img
                src="/images/dance/space-2.jpg"
                alt="Dance studio interior with dramatic atmospheric tungsten beam lighting"
                loading="lazy"
                className="w-full h-full object-cover filter brightness-[0.88] contrast-[1.1]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-80" />
              <div className="film-grain absolute inset-0 pointer-events-none" />
              
              <div className="absolute bottom-6 left-6 right-6">
                <span className="font-mono text-[10px] text-[#A78BFA] uppercase tracking-wider block mb-1">
                  STUDIO PERSPECTIVE
                </span>
                <p className="font-display font-bold text-lg text-[#F5F3F8] leading-snug">
                  The studio floor is a blank canvas. Your footwork is the ink.
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-col justify-between">
            <div className="space-y-8">
              {pillars.map((pillar) => (
                <div
                  key={pillar.number}
                  className="group p-6 sm:p-7 rounded-sm bg-[#14141B] hover:bg-[#1B1B26] border border-white/[0.07] hover:border-[#8B5CF6]/40 transition-all duration-300"
                >
                  <div className="flex items-center justify-between gap-4 mb-3">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold text-[#8B5CF6]">
                        {pillar.number} //
                      </span>
                      <h3 className="font-display font-bold text-lg sm:text-xl text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors">
                        {pillar.title}
                      </h3>
                    </div>
                    <span className="font-mono text-[10px] uppercase text-[#A5A1B2] bg-white/[0.04] px-2.5 py-1 rounded border border-white/5">
                      {pillar.tag}
                    </span>
                  </div>
                  <p className="font-sans text-sm text-[#A5A1B2] leading-relaxed">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Bottom Quick Trigger */}
            <div className="mt-8 pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <span className="text-xs font-mono text-[#A5A1B2]">
                WANT TO FEEL THE DIFFERENCE IN PERSON?
              </span>
              <button
                onClick={onOpenTrial}
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#8B5CF6] hover:text-[#A78BFA] transition-colors group focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6]"
              >
                <span>REQUEST GUEST ACCESS</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
