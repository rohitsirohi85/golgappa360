import React from 'react';
import { PackageOpen } from 'lucide-react';

export function EmptyState({ 
  icon: Icon = PackageOpen, 
  title = 'No records found', 
  description = 'No data matching your current filters or search query.',
  actionLabel,
  onAction
}) {
  return (
    <div className="flex flex-col items-center justify-center p-10 text-center glass-card border border-dashed border-white/15 my-4 rounded-2xl">
      <div className="w-12 h-12 rounded-2xl bg-white/[0.08] text-[#A7D78A] flex items-center justify-center mb-3 border border-white/10">
        <Icon className="w-6 h-6" />
      </div>
      <h4 className="text-base font-bold text-[#F5F4F1]">{title}</h4>
      <p className="text-xs text-[#929195] max-w-sm mt-1 mb-4">{description}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-4 py-2 bg-[#A7D78A]/20 text-[#A7D78A] border border-[#A7D78A]/30 text-xs font-semibold rounded-xl hover:bg-[#A7D78A]/30 transition-colors shadow-xs cursor-pointer"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
