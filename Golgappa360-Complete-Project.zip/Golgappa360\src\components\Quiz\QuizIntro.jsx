import React from 'react';
import SectionHeading from '../SectionHeading';

/**
 * QuizIntro — Observatory Challenge Launch Screen
 * Allows user to pick difficulty (Easy, Intermediate, Expert) and start the mission.
 */
export default function QuizIntro({
  selectedDifficulty,
  onSelectDifficulty,
  onStartMission,
  bestScore,
  onResetBestScore,
}) {
  const difficulties = [
    {
      id: 'easy',
      name: 'EASY',
      subtitle: 'Begin your journey.',
      description: 'Foundational concepts covering prominent stars, basic colors, and common asterisms.',
      color: '#38bdf8',
      glow: 'rgba(56, 189, 248, 0.3)',
      badge: 'CADET',
    },
    {
      id: 'intermediate',
      name: 'INTERMEDIATE',
      subtitle: 'Put your knowledge to the test.',
      description: 'Stellar evolution, spectral classification sequences, and deep sky structures.',
      color: '#818cf8',
      glow: 'rgba(129, 140, 248, 0.3)',
      badge: 'EXPLORER',
    },
    {
      id: 'expert',
      name: 'EXPERT',
      subtitle: 'For serious stargazers.',
      description: 'Astrophysical limits, relativistic phenomena, nucleosynthesis, and binary mechanics.',
      color: '#c084fc',
      glow: 'rgba(192, 132, 252, 0.3)',
      badge: 'NAVIGATOR',
    },
  ];

  return (
    <div className="flex flex-col items-center text-center max-w-4xl mx-auto relative">
      {/* Background Glowing Celestial Halo */}
      <div
        aria-hidden="true"
        className="absolute -top-10 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-cyan-500/15 blur-[120px] pointer-events-none"
      />

      {/* Top Telemetry Badge */}
      <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/30 text-xs font-mono uppercase tracking-[0.25em] text-cyan-300 mb-6 backdrop-blur-md shadow-sm">
        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]" />
        <span>STELLAR OBSERVATORY // SIMULATION TERMINAL</span>
      </div>

      {/* Section Heading */}
      <SectionHeading
        eyebrow="OBSERVATORY CHALLENGE"
        title="HOW WELL DO YOU KNOW THE COSMOS?"
        subtitle="Test what you've learned about stars, stellar evolution and the night sky."
        align="center"
      />

      {/* Persistent Best Score Pill if Available */}
      {bestScore !== null && (
        <div className="mt-4 flex items-center gap-3 px-4 py-1.5 rounded-full bg-[#020308]/70 border border-white/8 text-xs font-mono">
          <span className="text-amber-400 font-bold">★ BEST SCORE:</span>
          <span className="text-white font-bold">{bestScore} / 10 ({bestScore * 10}%)</span>
          <button
            type="button"
            onClick={onResetBestScore}
            className="text-[10px] text-slate-500 hover:text-rose-400 ml-2 underline cursor-pointer"
            title="Reset best score"
          >
            Reset
          </button>
        </div>
      )}

      {/* Difficulty Selection Grid */}
      <div className="w-full mt-12 grid grid-cols-1 md:grid-cols-3 gap-5 text-left">
        {difficulties.map((diff) => {
          const isSelected = selectedDifficulty === diff.id;

          return (
            <div
              key={diff.id}
              onClick={() => onSelectDifficulty(diff.id)}
              className={`group relative rounded-3xl p-6 sm:p-7 glass-surface transition-all duration-300 cursor-pointer flex flex-col justify-between border ${
                isSelected
                  ? 'border-cyan-400/90 bg-cyan-950/40 shadow-[0_0_30px_rgba(6,182,212,0.25)] -translate-y-1'
                  : 'border-white/10 hover:border-white/25 hover:bg-white/5 hover:-translate-y-0.5'
              }`}
              role="radio"
              aria-checked={isSelected}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectDifficulty(diff.id);
                }
              }}
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between mb-4">
                  <span
                    className="text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: `${diff.color}20`,
                      color: diff.color,
                      border: `1px solid ${diff.color}40`,
                    }}
                  >
                    {diff.badge}
                  </span>

                  <span className="text-[11px] font-mono text-slate-400">
                    10 QUESTIONS
                  </span>
                </div>

                {/* Difficulty Title & Subtitle */}
                <h4 className="font-display text-2xl font-semibold text-white mb-1">
                  {diff.name}
                </h4>
                <p className="text-xs font-mono tracking-wider uppercase text-amber-300/90 font-medium mb-3">
                  “{diff.subtitle}”
                </p>

                {/* Description */}
                <p className="font-sans text-xs text-slate-300 leading-relaxed font-normal">
                  {diff.description}
                </p>
              </div>

              {/* Selection Indicator */}
              <div className="mt-6 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                <span
                  className={
                    isSelected
                      ? 'text-cyan-300 font-semibold flex items-center gap-1.5'
                      : 'text-slate-500 group-hover:text-slate-300'
                  }
                >
                  {isSelected ? '✓ SELECTED MODE' : 'SELECT MODE'}
                </span>
                <span
                  className="w-3.5 h-3.5 rounded-full border flex items-center justify-center"
                  style={{
                    borderColor: isSelected ? diff.color : 'rgba(255,255,255,0.2)',
                    backgroundColor: isSelected ? diff.color : 'transparent',
                  }}
                >
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Start Button & Helper Strip */}
      <div className="mt-10 flex flex-col items-center gap-3">
        <button
          type="button"
          onClick={onStartMission}
          className="px-10 py-4 rounded-full bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-display font-semibold text-base tracking-wider uppercase transition-all duration-300 shadow-[0_0_20px_rgba(6,182,212,0.35)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:scale-105 cursor-pointer flex items-center gap-3"
        >
          <span>START MISSION</span>
          <span>→</span>
        </button>

        <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
          10 QUESTIONS · 3 DIFFICULTY LEVELS
        </span>
      </div>
    </div>
  );
}
