# SmartMess AI — Synthetic Dataset Quality & Validation Report

> **Academic Evaluation Disclaimer**: This dataset consists entirely of **synthetic benchmark data** generated for the SmartMess AI (MCA Major Project). It is mathematically modeled to simulate institutional hostel mess operations and does not represent real student or institutional metrics.

## Executive Status: ✅ PASSED
- **Validation Run Timestamp**: `2026-10-28T20:10:23.009196`
- **Source File**: `data/smartmess_sample.csv`
- **Total Validated Records**: `1,000`
- **Checks Executed**: `19` | **Passed**: `19` | **Failed**: `0`
- **Date Range Covered**: `2025-11-01` to `2026-09-30`

---

## 1. Quality & Consistency Checks Audit

| Check Name | Target Domain | Result | Detail |
| :--- | :--- | :---: | :--- |
| **Row Count Integrity** | Volume >= 1,000 | ✅ PASS | Exactly 1000 valid meal entries verified |
| **Mandatory Schema** | 10 required features | ✅ PASS | All required columns present |
| **Null / Missing Values** | 0 nulls across dataset | ✅ PASS | Zero null, NaN, or undefined values |
| **Record & Slot Uniqueness** | Date + Meal Primary Key | ✅ PASS | Zero duplicate service slots |
| **Category Vocabularies** | Meal, Menu, Weather, Weekday | ✅ PASS | All entries match permitted vocabularies |
| **Physical Weight Boundaries** | 0 < Waste <= Prepared | ✅ PASS | Food waste never negative and never exceeds preparation |
| **Financial Accounting** | Prepared Cost = Prep Kg * Cost/Kg | ✅ PASS | 100% mathematical consistency across all rows |
| **Percentage Boundaries** | Waste % between 0% and 100% | ✅ PASS | Waste ratios span realistically from 2.52% to 33.45% |
| **Absence of Target Leakage** | Pre-decision vs Post-outcome | ✅ PASS | No pre-service feature possesses deterministic correlation (|r| < 0.98) |
| **Categorical Representation** | Full domain coverage | ✅ PASS | All 3 meals, 5 menus, 5 weathers, and 7 weekdays active |

---

## 2. Descriptive Telemetry Statistics

| Metric | Minimum | Mean | Maximum | Total Aggregate |
| :--- | :---: | :---: | :---: | :---: |
| **Food Prepared (kg)** | 164.98 kg | 438.84 kg | 750.0 kg | **438,839.50 kg** |
| **Food Waste (kg)** | 6.92 kg | 66.1 kg | 213.4 kg | **66,096.92 kg** |
| **Waste Percentage (%)** | 2.52% | **15.0%** | 33.45% | *Institutional Avg: ~15%* |
| **Expected Attendance** | 400 students | 760.2 students | 1050 students | *Hostel Capacity: 1,000* |
| **Ingredient Cost / kg** | — | ₹82.13 | — | — |
| **Total Prepared Cost** | — | — | — | **₹37,396,525.07** |

---

## 3. Categorical Distributions & Stratification

### Meal Type Distribution
| Meal Type | Record Count |
| :--- | :---|
| breakfast | 334 |
| lunch | 333 |
| dinner | 333 |

### Menu Category Distribution
| Menu Category | Record Count |
| :--- | :---|
| roti_breads | 280 |
| rice_grains | 251 |
| continental_light | 217 |
| curry_dal | 202 |
| special_feast | 50 |

### Weather Condition Distribution
| Weather | Record Count |
| :--- | :---|
| clear | 456 |
| overcast | 204 |
| rainy | 201 |
| extreme_heat | 88 |
| cold | 51 |

---

## 4. Feature Correlations with Food Waste (Target)

| Feature | Pearson Correlation (r) with `food_waste_kg` | Interpretation |
| :--- | :---: | :--- |
| `food_prepared_kg` | `+0.62` | Strong realistic scaling (larger batches yield higher surplus) |
| `expected_attendance` | `+0.481` | Positive relationship with kitchen prep demand |
| `cost_per_kg` | `0.241` | Neutral (ingredient cost does not dictate volume) |
| `is_weekend` | `+-0.123` | Positive waste tendency due to sudden student absenteeism |

---

## 5. Validation Outcome Summary
All **19 quality checks passed successfully**. The synthetic dataset `data/smartmess_sample.csv` satisfies all physical, mathematical, and machine learning integrity constraints for Phase 2.
