import React, { useState, useRef } from 'react';
import { 
  Camera, 
  CameraOff, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Video, 
  Radio, 
  Cpu, 
  Layers,
  ShieldCheck,
  Zap
} from 'lucide-react';

export const GestureStatusModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl mb-panel-elevated rounded-2xl overflow-hidden border border-white/15 p-6 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-mono tracking-wide flex items-center gap-2">
                <span>HAND TRACKING SYSTEM</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Phase 2 Active
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                Real-time MediaPipe Hand Landmarker integration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-4 space-y-4">
          {/* Status Alert Banner */}
          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <span className="font-semibold text-emerald-200 block">
                Real-Time Hand Tracking Fully Integrated
              </span>
              <p className="text-slate-300 leading-relaxed">
                MotionBeat now tracks up to <strong>two hands simultaneously</strong> using MediaPipe's latest 21-point 3D Landmarker model. The 3D particle field, wave terrain, and neon tunnel react live to your hand positions, swirls, and pinch gestures.
              </p>
            </div>
          </div>

          {/* Core Features Overview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
            <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                <Video className="w-3.5 h-3.5" />
                <span>Dual Hand Tracking</span>
              </div>
              <p className="text-slate-400 text-[10px]">
                Tracks Left and Right hands independently as two interaction points in 3D WebGL space.
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <div className="flex items-center gap-1.5 text-purple-300 font-semibold">
                <Zap className="w-3.5 h-3.5" />
                <span>Pinch Gesture Physics</span>
              </div>
              <p className="text-slate-400 text-[10px]">
                Pinching index and thumb creates gravitational attraction and hyperspace acceleration.
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Local Privacy First</span>
              </div>
              <p className="text-slate-400 text-[10px]">
                Inference runs entirely in your browser via WebAssembly & WebGL. No video is uploaded.
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 space-y-1">
              <div className="flex items-center gap-1.5 text-blue-400 font-semibold">
                <Radio className="w-3.5 h-3.5" />
                <span>Mouse Fallback</span>
              </div>
              <p className="text-slate-400 text-[10px]">
                When the camera is disabled or hands leave the frame, the engine smoothly falls back to mouse tracking.
              </p>
            </div>
          </div>

          {/* How to use */}
          <div className="bg-black/50 rounded-xl p-3.5 border border-white/5 space-y-1.5 text-xs text-slate-300">
            <span className="font-mono font-bold text-white text-[11px] block">
              HOW TO OPERATE:
            </span>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-400">
              <li>Click <strong>Enable Camera</strong> in the camera preview window.</li>
              <li>Allow browser camera permission when prompted.</li>
              <li>Show one or both hands to the webcam to modulate particle vortices and 3D camera angles.</li>
              <li>Pinch your thumb and index finger to trigger gravitational clustering.</li>
              <li>Click <strong>Disable Camera</strong> anytime to stop the webcam and release hardware resources.</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            Package: @mediapipe/tasks-vision
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-mono text-xs font-semibold hover:opacity-90 transition-opacity"
          >
            Ready to Perform
          </button>
        </div>
      </div>
    </div>
  );
};
