import React from 'react';
import { SPECTRAL_CLASSES } from '../../data/spectralClasses';

/**
 * SpectralSpectrum — Large horizontal stellar spectrum selector
 * Shows O B A F G K M sequence with:
 * HOTTER ←————————————→ COOLER
 * BLUE ←————————————→ RED
 * Interactive hover and click selection with individual spectral glows.
 */
export default function SpectralSpectrum({
  selectedClassId = 'G',
  onSelectClass,
}) {
  return (
    <div className="w-full flex flex-col items-center select-none">
      {/* Top Telemetry Header */}
      <div className="flex items-center justify-between w-full max-w-4xl px-2 mb-3 text-[11px] font-mono text-slate-400">
        <span className="flex items-center gap-2 text-cyan-400">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span>HARVARD SPECTRAL SEQUENCE</span>
        </span>
        <span className="text-slate-500 hidden sm:inline">
          INTERACTIVE TEMPERATURE SELECTOR
        </span>
      </div>

      {/* Main Spectrum Bar Container */}
      <div className="w-full max-w-4xl p-2 sm:p-3 rounded-2xl glass-surface border border-white/10 shadow-[0_10px_35px_rgba(0,0,0,0.5)]">
        {/* Spectrum Buttons Row */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-3">
          {SPECTRAL_CLASSES.map((cls) => {
            const isSelected = selectedClassId === cls.id;
            return (
              <button
                key={cls.id}
                type="button"
                onClick={() => onSelectClass(cls.id)}
                className={`relative flex flex-col items-center justify-center py-3 sm:py-4 px-1 rounded-xl transition-all duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                  isSelected
                    ? 'scale-[1.04] bg-white/[0.08] shadow-[0_0_25px_-5px_var(--glow)] z-10'
                    : 'hover:bg-white/[0.04] hover:scale-[1.02] opacity-75 hover:opacity-100'
                }`}
                style={{
                  '--glow': cls.glowColor,
                  border: isSelected
                    ? `1px solid ${cls.colorHex}`
                    : '1px solid rgba(255, 255, 255, 0.06)',
                }}
              >
                {/* Spectral Class Letter */}
                <span
                  className="font-display text-2xl sm:text-3xl font-semibold tracking-tight"
                  style={{
                    color: isSelected ? cls.colorHex : '#f1f5f9',
                    textShadow: isSelected ? `0 0 15px ${cls.glowColor}` : 'none',
                  }}
                >
                  {cls.id}
                </span>

                {/* Star Color Indicator Dot */}
                <div
                  className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full mt-1.5 transition-transform duration-300"
                  style={{
                    backgroundColor: cls.colorHex,
                    boxShadow: `0 0 8px ${cls.colorHex}`,
                    transform: isSelected ? 'scale(1.3)' : 'scale(1)',
                  }}
                />

                {/* Short Temperature Subtitle */}
                <span className="text-[9px] sm:text-[10px] font-mono text-slate-400 mt-1 truncate max-w-full hidden md:inline">
                  {cls.temperatureRange.split(' ')[0]}
                </span>

                {/* Active Indicator Chevron */}
                {isSelected && (
                  <div
                    aria-hidden="true"
                    className="absolute -bottom-1.5 w-3 h-1.5 rounded-t-sm"
                    style={{ backgroundColor: cls.colorHex }}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Continuous Gradient Line */}
        <div className="mt-3 relative h-1.5 w-full rounded-full overflow-hidden bg-gradient-to-r from-[#00d2ff] via-[#38bdf8] via-[#f8fafc] via-[#fef08a] via-[#fbbf24] via-[#fb923c] to-[#ef4444] shadow-[0_0_12px_rgba(255,255,255,0.2)]" />

        {/* Directional Scale Guides */}
        <div className="mt-3.5 flex flex-col sm:flex-row items-center justify-between gap-1 sm:gap-4 px-1 text-[10px] sm:text-[11px] font-mono text-slate-400 tracking-wider">
          <div className="flex items-center gap-1.5">
            <span className="text-cyan-400 font-bold">HOTTER</span>
            <span className="text-slate-600">←————————————————</span>
            <span className="text-slate-500">————————————————→</span>
            <span className="text-rose-400 font-bold">COOLER</span>
          </div>

          <div className="flex items-center gap-1.5 text-slate-500">
            <span className="text-cyan-300">BLUE</span>
            <span className="text-slate-600">←——————————————→</span>
            <span className="text-rose-400">RED</span>
          </div>
        </div>
      </div>
    </div>
  );
}
