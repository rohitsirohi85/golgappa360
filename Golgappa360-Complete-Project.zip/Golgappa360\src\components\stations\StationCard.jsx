import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Zap, Star, ChevronRight } from 'lucide-react';
import { Card } from '../common/Card';
import { StatusBadge } from '../common/StatusBadge';
import { Button } from '../common/Button';
import { useEV } from '../../context/EVContext';

export const StationCard = ({ station, onSelect, compact = false }) => {
  const navigate = useNavigate();
  const { setSelectedStation } = useEV();

  const handleView = () => {
    setSelectedStation(station);
    if (onSelect) {
      onSelect(station);
    } else {
      navigate(`/station/${station.id}`);
    }
  };

  return (
    <Card hoverable className="relative overflow-hidden group">
      {/* Accent left highlight */}
      <div className="absolute top-0 left-0 bottom-0 w-1 bg-gradient-to-b from-[#00F5A0] to-[#00E5FF] opacity-80" />

      <div className="flex items-start justify-between gap-3 mb-2.5">
        <div>
          <h3 className="font-bold text-base text-white group-hover:text-[#00F5A0] transition-colors">
            {station.name}
          </h3>
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span>{station.distance} away</span>
            <span className="text-slate-600">•</span>
            <span>{station.openHours}</span>
          </div>
        </div>

        {station.rating && (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-semibold shrink-0">
            <Star className="w-3 h-3 fill-amber-400" />
            <span>{station.rating}</span>
          </div>
        )}
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-3 gap-2 py-2.5 px-3 rounded-xl bg-[#0D1527]/80 border border-white/5 my-3">
        <div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
            Availability
          </span>
          <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            {station.availableChargers}/{station.totalChargers} Available
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
            Speed
          </span>
          <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1 mt-0.5">
            <Zap className="w-3 h-3 text-[#00E5FF]" />
            {station.maxPower}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
            Price
          </span>
          <span className="text-xs font-semibold text-white mt-0.5 block">
            ₹{station.ratePerKwh}/kWh
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between mt-2 pt-1 border-t border-white/5">
        <span className="text-[11px] text-slate-400 truncate max-w-[190px]">
          {station.chargingSpeed}
        </span>
        <Button
          size="sm"
          variant="outline"
          onClick={handleView}
          icon={ChevronRight}
          iconPosition="right"
        >
          View Station
        </Button>
      </div>
    </Card>
  );
};
