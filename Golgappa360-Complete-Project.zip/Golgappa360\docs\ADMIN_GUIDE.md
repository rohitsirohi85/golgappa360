# EV SMART — Fleet Operations & Admin Management Guide

**Document Version:** `1.0.0-RC1`  
**Target Roles:** Fleet Managers, Charging Station Operators (CSOs), Site Engineers  
**Classification:** Administration & Operations Manual  

---

## 1. System Overview

The **EV SMART Admin Web Dashboard** is a commercial-grade fleet management console engineered to monitor, control, and optimize multi-station EV charging networks in real time.

It provides centralized oversight across four functional domains:
1. **Fleet Topology & Hardware Control:** Station and bay-level provisioning and status overrides.
2. **Real-Time IoT Telemetry:** Live sensor monitoring, thermal safety watchdogs, and emergency cutoff controls.
3. **AI/ML Energy Intelligence:** Grid demand forecasting, predictive maintenance indicators, and dynamic tariff optimization.
4. **Business Analytics & Audit Trails:** Energy consumption patterns, financial reconciliations, and compliance logs.

---

## 2. Access & Authentication

- **URL:** Navigable directly via the dashboard toggle on the desktop interface or `http://localhost:5173` (or production admin domain).
- **Default Operator Account:**
  - **Email:** `admin@evsmart.com`
  - **Password:** `admin123`
- **Role-Based Permissions:** Admin privileges enforce access guards on all `/api/admin/*` endpoints via JWT bearer token validation.

---

## 3. Fleet Operations & Status Management

### 3.1 Network Topology & Station Cards
The Fleet Management screen presents a hierarchal view of all physical infrastructure:
- **Station Overview:** Name, physical location, total bays, grid power allocation (kW), and network health status.
- **Bay / Charger Level:** Individual chargers (e.g., `CH-01`, `CH-02`, `CH-03`) displaying live state chips:
  - 🟢 **Available:** Ready to accept customer check-in.
  - ⚡ **Charging:** Active vehicle connected; transmitting live telemetry.
  - 🟡 **Reserved:** Booked by customer; waiting for vehicle arrival.
  - 🟠 **Maintenance:** Temporarily deactivated for service.
  - ⚪ **Offline:** Hardware heartbeat silent (`> 30s`); flagged by watchdog.

### 3.2 Administrative Overrides
Operators can manually override charger states during maintenance or safety incidents:
1. Click on the target charger card.
2. Select **"Status Action"** from the action dropdown.
3. Choose desired state: **Force Available**, **Put in Maintenance**, or **Decommission**.
4. The backend immediately logs the override into the immutable audit trail and publishes the new state to all connected mobile clients.

---

## 4. Real-Time Telemetry & Thermal Safety Controls

```
┌─────────────────────────────────────────────────────────────────┐
│                 LIVE CHARGER TELEMETRY CONSOLE                  │
│                                                                 │
│  [ Voltage: 398.2 V ]     [ Current: 78.4 A ]     [ Power: 31.2 kW ]
│                                                                 │
│  [ Temperature: 39.4°C ]  [ Session Energy: 14.2 kWh ]          │
│                                                                 │
│            [ ⚠️ TRIGGER EMERGENCY HARDWARE SHUTDOWN ]            │
└─────────────────────────────────────────────────────────────────┘
```

1. **Hardware Telemetry Feeds:** Live updates stream every 2 seconds via Socket.IO from the IoT ESP32 controllers.
2. **Threshold Guardrails:**
   - **Voltage Warning:** Triggers alert if $V < 190\text{V}$ or $V > 430\text{V}$.
   - **Overcurrent Trip:** Triggers warning if $I > 90\text{A}$ on fast DC chargers.
   - **Thermal Cutoff:** Flashes high-temperature alarm if cable temperature exceeds $65^\circ\text{C}$; automatic thermal throttler engages if $T > 75^\circ\text{C}$.
3. **Emergency Stop (Remote E-Stop):**
   - Red button on the charger detail card sends an immediate `stop_emergency` payload via MQTT to the ESP32 relay, instantly interrupting current flow and notifying the connected driver.

---

## 5. AI Energy Optimization & Predictive Maintenance

The AI intelligence suite transforms raw sensor telemetry into actionable operational recommendations:

### 5.1 AI Demand Forecasting
- **Visual:** 24-hour demand prediction curve showing anticipated hourly power demand (kW) compared to historical baseline.
- **Model:** Random Forest Regressor & Multi-Layer Perceptron trained on time-of-day, day-of-week, station location, and historical booking frequencies.
- **Operational Action:** Use demand curves to schedule battery storage discharge during peak hours and negotiate optimal utility tariffs.

### 5.2 Dynamic Tariff Engine
- Automatically proposes dynamic pricing multipliers based on predicted grid congestion:
  - **Off-Peak (00:00 - 06:00):** Base tariff discount (incentivizes overnight fleet charging).
  - **Solar Peak (11:00 - 15:00):** Green energy discount (absorbs rooftop solar generation).
  - **Grid Evening Peak (18:00 - 22:00):** Surge multiplier (mitigates transformer strain).

### 5.3 Predictive Maintenance & Health Scores
- **Charger Health Score (0 - 100):** Synthesizes operating temperatures, voltage ripple, relay cycling count, and fault history.
- **Failure Risk Probability (%):** High risk (`> 70%`) flags the charger for preemptive component inspection before unexpected downtime occurs.
- **Remaining Useful Life (RUL):** Estimates days remaining before relay contactor replacement is recommended.

---

## 6. Financial Analytics & Data Export

1. **Revenue Dashboard:** Aggregates billing records across customized timeframes (Today, Last 7 Days, Month-to-Date).
2. **Utilization Rates:** Calculates bay utilization percentage:
   $$\text{Utilization \%} = \frac{\text{Total Charging Minutes}}{\text{Total Available Minutes in Period}} \times 100$$
3. **Exporting Reports:** Click **"Export CSV / PDF"** to generate audit-ready financial and energy compliance summaries.

---

## 7. Security Auditing & Operations Checklist

- **Reviewing Audit Trails:** Navigate to **Admin -> Audit Logs** to verify all administrative overrides, pricing adjustments, and user promotions with exact timestamps and IP addresses.
- **Watchdog Status:** Confirm the offline watchdog interval is running continuously (`interval: 10000ms`).
- **Demo Mode Safety:** Ensure `DEMO_MODE=false` in production environments to enforce live cryptographic payment validation and disable simulated telemetry injection.
