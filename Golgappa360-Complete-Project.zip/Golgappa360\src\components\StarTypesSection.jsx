import React, { useState } from 'react';
import SectionHeading from './SectionHeading';
import SpectralSpectrum from './StarTypes/SpectralSpectrum';
import ClassificationPanel from './StarTypes/ClassificationPanel';
import StellarFamilyCards from './StarTypes/StellarFamilyCards';
import SizeComparison from './StarTypes/SizeComparison';
import TemperatureColorGuide from './StarTypes/TemperatureColorGuide';
import LifetimeComparison from './StarTypes/LifetimeComparison';
import RealStarsExamples from './StarTypes/RealStarsExamples';
import SunCallout from './StarTypes/SunCallout';
import { SPECTRAL_CLASSES } from '../data/spectralClasses';
import { STARS_DATA } from '../data/stars';

/**
 * StarTypesSection — Comprehensive Stellar Classification & Star Types Experience
 * Orchestrates:
 * 1. Intro Spectrum Selector (O B A F G K M)
 * 2. Interactive Classification Panel (Dynamic Left Star & Right Dossier)
 * 3. The Stellar Family Cards (Evolutionary structures vs. spectral classes)
 * 4. Size Comparison (Relative scale: White dwarf -> Sun -> Red giant -> Supergiant)
 * 5. Temperature to Color (Wien's law thermal radiation guide)
 * 6. Lifetime Comparison (Hotter doesn't mean longer paradox)
 * 7. Real Catalog Exemplars (Linked to Stars Explorer)
 * 8. Cinematic Sun Perspective Callout
 */
export default function StarTypesSection({ onSelectStarFromTypes }) {
  // Selected spectral class state (default: G — Yellow Stars)
  const [selectedClassId, setSelectedClassId] = useState('G');

  const selectedClass =
    SPECTRAL_CLASSES.find((c) => c.id === selectedClassId) || SPECTRAL_CLASSES[4];

  // Callback to jump to a star in the explorer
  const handleJumpToStar = (starOrClass) => {
    let targetStar = starOrClass;

    // If a spectral class object was passed, find a matching star from catalog
    if (starOrClass?.id && !starOrClass?.spectralClass) {
      targetStar =
        STARS_DATA.find((s) => s.spectralClass.startsWith(starOrClass.id)) ||
        STARS_DATA[0];
    }

    if (onSelectStarFromTypes) {
      onSelectStarFromTypes(targetStar);
    } else {
      const explorer = document.getElementById('stars');
      if (explorer) {
        explorer.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleExploreSun = () => {
    const sun = STARS_DATA.find((s) => s.id === 'sun') || STARS_DATA[0];
    handleJumpToStar(sun);
  };

  return (
    <section
      id="star-types"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Subtle Galactic Nebulae */}
      <div
        aria-hidden="true"
        className="absolute top-1/4 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-950/20 blur-[150px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-1/3 -left-40 w-[650px] h-[650px] rounded-full bg-indigo-950/25 blur-[150px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-10 right-10 w-[500px] h-[500px] rounded-full bg-amber-950/15 blur-[130px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-24 sm:space-y-32">
        {/* 1. Section Header & Spectral Sequence Introduction */}
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          <SectionHeading
            eyebrow="STELLAR CLASSIFICATION"
            title="WHAT KIND OF STAR IS IT?"
            subtitle="Stars come in extraordinary sizes, colors and temperatures. Their mass determines how they shine, how long they live, and how they eventually die."
            align="center"
          />

          {/* Horizontal Stellar Spectrum Selector */}
          <div className="w-full mt-10">
            <SpectralSpectrum
              selectedClassId={selectedClassId}
              onSelectClass={setSelectedClassId}
            />
          </div>
        </div>

        {/* 2. Interactive Classification Panel (Dynamic Left Star + Right Dossier) */}
        <div>
          <ClassificationPanel
            selectedClass={selectedClass}
            onSelectExampleStar={handleJumpToStar}
          />
        </div>

        {/* 3. The Stellar Family (Evolutionary Types vs. Spectral Classes) */}
        <div>
          <StellarFamilyCards onExploreStar={handleJumpToStar} />
        </div>

        {/* 4. Relative Size Comparison ("SIZE IS EVERYTHING") */}
        <div>
          <SizeComparison />
        </div>

        {/* 5. Temperature to Color Guide ("WHY ARE STARS DIFFERENT COLORS?") */}
        <div>
          <TemperatureColorGuide />
        </div>

        {/* 6. Lifetime Paradox Comparison ("HOTTER DOESN'T MEAN LONGER") */}
        <div>
          <LifetimeComparison />
        </div>

        {/* 7. Catalog Exemplars ("MEET THE REAL STARS") */}
        <div>
          <RealStarsExamples onSelectStar={handleJumpToStar} />
        </div>

        {/* 8. Cinematic Solar Perspective Callout */}
        <div>
          <SunCallout onExploreSun={handleExploreSun} />
        </div>
      </div>
    </section>
  );
}
