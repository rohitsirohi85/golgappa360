// =====================================================================
// Golgappa360 - Database Connection Manager (MySQL 8.0+ Connection Pool)
// =====================================================================

import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

let pool = null;
let isConnected = false;
let lastError = null;

export const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'golgappa360',
  port: Number(process.env.DB_PORT) || 3306,
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT) || 10,
  queueLimit: 0,
  connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT) || 4000
};

/**
 * Tests MySQL authentication and checks if database exists
 */
export async function testConnection(customConfig = null) {
  const config = customConfig ? { ...dbConfig, ...customConfig } : dbConfig;
  try {
    const tempConn = await mysql.createConnection({
      host: config.host,
      port: config.port,
      user: config.user,
      password: config.password,
      connectTimeout: 3000
    });

    const [dbs] = await tempConn.query('SHOW DATABASES LIKE ?', [config.database]);
    const dbExists = dbs.length > 0;
    await tempConn.end();

    return {
      success: true,
      serverAccessible: true,
      databaseExists: dbExists,
      databaseName: config.database,
      host: config.host,
      port: config.port,
      user: config.user,
      message: dbExists
        ? `Successfully authenticated with MySQL 8.0 on ${config.host}:${config.port}. Database '${config.database}' is ready.`
        : `Connected to MySQL 8.0 on ${config.host}:${config.port}. Notice: Database '${config.database}' is not created yet. Run schema.sql to initialize.`
    };
  } catch (err) {
    return {
      success: false,
      serverAccessible: false,
      error: err.message,
      errorCode: err.code,
      message: `MySQL connection failed: ${err.message}. Operating in resilient High-Fidelity Synthetic Store mode.`
    };
  }
}

/**
 * Initializes the MySQL connection pool
 */
export async function initDbPool() {
  try {
    pool = mysql.createPool(dbConfig);
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();
    isConnected = true;
    lastError = null;
    console.log(`[MySQL] Connected successfully to ${dbConfig.host}:${dbConfig.port}/${dbConfig.database}`);
    return true;
  } catch (err) {
    isConnected = false;
    lastError = err.message;
    console.warn(`[MySQL] Note: Could not connect to MySQL (${err.message}). Golgappa360 will operate with its built-in synthetic analytics engine.`);
    return false;
  }
}

/**
 * Returns connection pool status & active driver info
 */
export function getDbStatus() {
  return {
    isConnected,
    mode: isConnected ? 'MySQL 8.0 Active' : 'Synthetic In-Memory Store Active',
    activeDataSource: isConnected ? 'mysql' : 'synthetic_csv',
    lastError,
    config: {
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      database: dbConfig.database,
      passwordConfigured: Boolean(dbConfig.password)
    }
  };
}

/**
 * Safe parameterized query execution helper
 */
export async function executeQuery(sql, params = []) {
  if (!isConnected || !pool) {
    throw new Error('MySQL connection pool is not active');
  }
  const [rows] = await pool.execute(sql, params);
  return rows;
}

export function getPool() {
  return pool;
}
