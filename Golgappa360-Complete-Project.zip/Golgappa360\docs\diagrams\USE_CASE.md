# EV SMART: Unified Use Case Specifications
## Detailed Actor-System Interactions, Boundaries, and Use Case Diagrams

---

## 1. System Use Case Diagram

```mermaid
graph LR
    subgraph Actors
        Driver["🚗 EV Driver"]
        Admin["👨‍💼 Fleet Admin / Operator"]
        ESP32["🔌 ESP32 IoT Node"]
        AI["🧠 AI Microservice"]
        Billing["💳 Payment Gateway"]
    end

    subgraph "EV SMART Platform"
        %% Driver Use Cases
        UC1["UC-01: Register & Authenticate"]
        UC2["UC-02: Discover Nearby Stations"]
        UC3["UC-03: Reserve Charging Slot"]
        UC4["UC-04: Start Session via QR Code"]
        UC5["UC-05: Monitor Live Telemetry Cockpit"]
        UC6["UC-06: Stop Session & View Receipt"]
        UC7["UC-07: Manage Wallet & Top-Up"]

        %% Admin Use Cases
        UC8["UC-08: Manage Fleet Stations & Chargers"]
        UC9["UC-09: Monitor Fleet Live Grid"]
        UC10["UC-10: Execute Remote Emergency Override"]
        UC11["UC-11: Configure Dynamic Tariff Rules"]
        UC12["UC-12: Inspect Energy & Revenue Analytics"]
        UC13["UC-13: Review Security Audit Trails"]

        %% IoT Node Use Cases
        UC14["UC-14: Sample Sensor Telemetry (1Hz)"]
        UC15["UC-15: Execute Autonomous Edge Cutoff"]
        UC16["UC-16: Ring-Buffer Telemetry During Outage"]

        %% AI Engine Use Cases
        UC17["UC-17: Generate 24h Ahead Demand Forecast"]
        UC18["UC-18: Screen Telemetry for Anomalies"]

        %% Billing Use Cases
        UC19["UC-19: Process Wallet Settlement & Invoicing"]
    end

    %% Actor Connections
    Driver --> UC1
    Driver --> UC2
    Driver --> UC3
    Driver --> UC4
    Driver --> UC5
    Driver --> UC6
    Driver --> UC7

    Admin --> UC1
    Admin --> UC8
    Admin --> UC9
    Admin --> UC10
    Admin --> UC11
    Admin --> UC12
    Admin --> UC13

    ESP32 --> UC14
    ESP32 --> UC15
    ESP32 --> UC16

    AI --> UC17
    AI --> UC18

    Billing --> UC19
    UC6 -.->|triggers| UC19
    UC7 -.->|interacts with| Billing
    UC14 -.->|streams into| UC5
    UC14 -.->|evaluated by| UC18
    UC17 -.->|informs| UC11
```

---

## 2. Core Use Case Specifications

### Use Case UC-04: Start Session via QR Code
- **Primary Actor:** EV Driver
- **Preconditions:** Driver is authenticated; vehicle plugged into physical connector; charger status is `AVAILABLE` or matching active reservation.
- **Main Success Scenario:**
  1. Driver opens mobile app and taps "Scan to Charge".
  2. Camera scans QR code attached to charger station body.
  3. App extracts `stationId` and `chargerId` and dispatches `POST /api/sessions/start`.
  4. Backend verifies charger availability and wallet reserve (minimum ₹100).
  5. Backend updates charger state to `CHARGING` and publishes start command over MQTT.
  6. ESP32 receives command and engages 30A optocoupled relay.
  7. AC contact closes; vehicle begins drawing current; LCD displays active charging metrics.
  8. App transitions UI to Live Cockpit streaming real-time telemetry at 1Hz.
- **Postconditions:** Charging session record created in MongoDB; relay energized; 1Hz telemetry streaming active.

---

### Use Case UC-10: Execute Remote Emergency Override
- **Primary Actor:** Fleet Admin / Operator
- **Preconditions:** Admin authenticated with `admin` or `operator` role.
- **Main Success Scenario:**
  1. Admin inspects live charger diagnostics and observes abnormal electrical behavior.
  2. Admin clicks "Emergency Disconnect" button for affected charger.
  3. Admin confirms high-priority modal prompt.
  4. Backend dispatches immediate high-priority MQTT command to topic `ev/station/{sId}/charger/{cId}/command` with payload `{"action": "EMERGENCY_STOP"}`.
  5. ESP32 FreeRTOS Core 1 receives command and interrupts relay coil power in $<50\text{ms}$.
  6. Backend terminates active session, transitions charger status to `FAULTED`, and records an entry in the immutable `AuditLogs` collection.
  7. WebSocket emits emergency alert to admin portal and active driver app.
- **Postconditions:** Physical contactor opened; charger locked; audit trail recorded.

---

### Use Case UC-15: Execute Autonomous Edge Cutoff
- **Primary Actor:** ESP32 IoT Node (Edge Autonomous Task)
- **Preconditions:** Active charging session ongoing; FreeRTOS Core 0 safety loop running.
- **Trigger:** DHT22 temperature sensor measures $T_{\text{enc}} > 60^\circ\text{C}$ OR PZEM-004T measures $I_{\text{rms}} > 32\text{A}$.
- **Main Success Scenario:**
  1. FreeRTOS Core 0 safety task detects threshold breach during periodic 100ms evaluation.
  2. Task immediately asserts GPIO 26 HIGH (active-low open), cutting control current to 30A relay in $<50\text{ms}$.
  3. Local 16x2 LCD immediately displays error message: `ERR: OVER-TEMP TRIP!`.
  4. Local audible buzzer sounds emergency alarm pattern.
  5. Task enqueues high-priority emergency packet to FreeRTOS queue for Core 1.
  6. Core 1 publishes emergency fault event to MQTT broker: `{"status": "FAULTED", "reason": "THERMAL_CUTOFF", "temp": 64.2}`.
  7. Node.js backend receives fault, marks session as aborted, and notifies operator dashboard.
- **Postconditions:** Physical circuit opened with zero reliance on cloud availability.
