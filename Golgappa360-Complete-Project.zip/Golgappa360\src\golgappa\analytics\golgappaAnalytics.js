/**
 * Golgappa360 - Centralized Analytics Engine (Frontend & Client Module)
 * 
 * Reusable, pure calculation functions implementing standardized business formulas:
 * 
 * - Net revenue = Gross sales − Discounts
 * - Gross profit = Net revenue − Cost of goods sold (COGS)
 * - Gross margin (%) = (Gross profit ÷ Net revenue) × 100
 * - Estimated operating profit = Gross profit − Operating expenses
 * 
 * Guarantees:
 * - Safe division with zero denominators
 * - No double-counting between ingredient ledger and product BOM
 * - Purchases are NEVER counted as consumption or waste
 * - Exact dates with inclusive boundary filtering
 */

export function safeDivide(numerator, denominator, fallback = 0) {
  if (!denominator || isNaN(denominator) || denominator === 0) return fallback;
  const res = numerator / denominator;
  return isNaN(res) || !isFinite(res) ? fallback : res;
}

export function toDateStr(d) {
  if (!d) return '';
  if (typeof d === 'string') {
    if (d.includes('T')) return d.split('T')[0];
    if (d.includes(' ')) return d.split(' ')[0];
    return d;
  }
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export function resolveDateRange(rangeKey = '30d', anchorDateStr = '2026-10-29') {
  const anchor = new Date(`${anchorDateStr}T23:59:59+05:30`);
  const anchorEndStr = toDateStr(anchor);

  if (rangeKey === 'today') {
    return { startDate: anchorEndStr, endDate: anchorEndStr, label: 'Today (Oct 29)' };
  }
  if (rangeKey === '7d') {
    const d = new Date(anchor);
    d.setDate(d.getDate() - 6);
    return { startDate: toDateStr(d), endDate: anchorEndStr, label: 'Last 7 Days' };
  }
  if (rangeKey === '30d') {
    const d = new Date(anchor);
    d.setDate(d.getDate() - 29);
    return { startDate: toDateStr(d), endDate: anchorEndStr, label: 'Last 30 Days' };
  }
  if (rangeKey === '90d' || rangeKey === '3m') {
    const d = new Date(anchor);
    d.setDate(d.getDate() - 89);
    return { startDate: toDateStr(d), endDate: anchorEndStr, label: 'Last 90 Days' };
  }
  if (rangeKey === '180d' || rangeKey === '6m' || rangeKey === 'all') {
    return { startDate: '2026-05-01', endDate: anchorEndStr, label: 'Entire 6 Months (May - Oct 2026)' };
  }

  if (typeof rangeKey === 'object' && rangeKey.startDate && rangeKey.endDate) {
    return { startDate: rangeKey.startDate, endDate: rangeKey.endDate, label: `${rangeKey.startDate} to ${rangeKey.endDate}` };
  }
  if (typeof rangeKey === 'string' && rangeKey.includes(':')) {
    const [s, e] = rangeKey.split(':');
    return { startDate: s, endDate: e, label: `${s} to ${e}` };
  }

  const d = new Date(anchor);
  d.setDate(d.getDate() - 29);
  return { startDate: toDateStr(d), endDate: anchorEndStr, label: 'Last 30 Days' };
}

export function filterSales(sales, { startDate, endDate, productId }) {
  const sStr = startDate ? toDateStr(startDate) : '0000-00-00';
  const eStr = endDate ? toDateStr(endDate) : '9999-99-99';
  const checkProduct = productId && productId !== 'all';

  return sales.filter(s => {
    const saleDate = toDateStr(s.sale_datetime);
    if (saleDate < sStr || saleDate > eStr) return false;
    if (checkProduct && s.product_id !== productId) return false;
    return true;
  });
}

export function filterExpenses(expenses, { startDate, endDate }) {
  const sStr = startDate ? toDateStr(startDate) : '0000-00-00';
  const eStr = endDate ? toDateStr(endDate) : '9999-99-99';

  return expenses.filter(e => {
    const expDate = toDateStr(e.expense_date);
    return expDate >= sStr && expDate <= eStr;
  });
}

export function filterInventoryTransactions(transactions, { startDate, endDate, types }) {
  const sStr = startDate ? toDateStr(startDate) : '0000-00-00';
  const eStr = endDate ? toDateStr(endDate) : '9999-99-99';
  const typesSet = types ? new Set(Array.isArray(types) ? types : [types]) : null;

  return transactions.filter(tx => {
    const txDate = toDateStr(tx.transaction_date);
    if (txDate < sStr || txDate > eStr) return false;
    if (typesSet && !typesSet.has(tx.transaction_type)) return false;
    return true;
  });
}

export function calculateKpis({ sales, expenses, wasteTransactions, productsMap, ingredientsMap }) {
  let grossRevenue = 0;
  let totalDiscounts = 0;
  let netRevenue = 0;
  let totalPlatesSold = 0;
  let cogs = 0;

  for (let i = 0; i < sales.length; i++) {
    const s = sales[i];
    const qty = Number(s.quantity_plates) || 0;
    const price = Number(s.unit_price) || 0;
    const discount = Number(s.discount) || 0;
    const prod = productsMap.get ? productsMap.get(s.product_id) : productsMap[s.product_id];
    const costPerPlate = prod ? Number(prod.ingredient_cost_per_plate) : 0;

    const lineGross = qty * price;
    const lineNet = Math.max(0, lineGross - discount);
    const lineCOGS = qty * costPerPlate;

    grossRevenue += lineGross;
    totalDiscounts += discount;
    netRevenue += lineNet;
    totalPlatesSold += qty;
    cogs += lineCOGS;
  }

  const grossProfit = netRevenue - cogs;
  const grossMarginPct = safeDivide(grossProfit, netRevenue) * 100;
  const totalOrders = sales.length;
  const aov = safeDivide(netRevenue, totalOrders);
  const asp = safeDivide(netRevenue, totalPlatesSold);

  let operatingExpenses = 0;
  for (let i = 0; i < (expenses || []).length; i++) {
    operatingExpenses += Number(expenses[i].amount) || 0;
  }

  const operatingProfit = grossProfit - operatingExpenses;
  const operatingMarginPct = safeDivide(operatingProfit, netRevenue) * 100;

  let totalWasteCost = 0;
  let totalWasteQty = 0;
  for (let i = 0; i < (wasteTransactions || []).length; i++) {
    const tx = wasteTransactions[i];
    const qty = Number(tx.quantity) || 0;
    const ing = ingredientsMap.get ? ingredientsMap.get(tx.ingredient_id) : ingredientsMap[tx.ingredient_id];
    const unitCost = ing ? Number(ing.unit_cost) : 0;
    totalWasteQty += qty;
    totalWasteCost += qty * unitCost;
  }

  const wasteRatePct = safeDivide(totalWasteCost, netRevenue) * 100;

  return {
    grossRevenue: Number(grossRevenue.toFixed(2)),
    totalDiscounts: Number(totalDiscounts.toFixed(2)),
    totalRevenue: Number(netRevenue.toFixed(2)),
    totalPlatesSold,
    totalOrders,
    aov: Number(aov.toFixed(2)),
    asp: Number(asp.toFixed(2)),
    cogs: Number(cogs.toFixed(2)),
    grossProfit: Number(grossProfit.toFixed(2)),
    grossMarginPct: Number(grossMarginPct.toFixed(1)),
    operatingExpenses: Number(operatingExpenses.toFixed(2)),
    operatingProfit: Number(operatingProfit.toFixed(2)),
    operatingMarginPct: Number(operatingMarginPct.toFixed(1)),
    totalWasteCost: Number(totalWasteCost.toFixed(2)),
    totalWasteQty: Number(totalWasteQty.toFixed(1)),
    wasteRatePct: Number(wasteRatePct.toFixed(1))
  };
}

export function calculateDailyTrend(sales, expenses, wasteTransactions, productsMap, ingredientsMap) {
  const dailyMap = new Map();

  for (let i = 0; i < sales.length; i++) {
    const s = sales[i];
    const dateStr = toDateStr(s.sale_datetime);
    const qty = Number(s.quantity_plates) || 0;
    const price = Number(s.unit_price) || 0;
    const discount = Number(s.discount) || 0;
    const prod = productsMap.get ? productsMap.get(s.product_id) : productsMap[s.product_id];
    const costPerPlate = prod ? Number(prod.ingredient_cost_per_plate) : 0;

    const netRev = Math.max(0, qty * price - discount);
    const cogs = qty * costPerPlate;

    if (!dailyMap.has(dateStr)) {
      dailyMap.set(dateStr, {
        date: dateStr.slice(5),
        fullDate: dateStr,
        dayOfWeek: new Date(`${dateStr}T12:00:00+05:30`).toLocaleDateString('en-US', { weekday: 'short' }),
        revenue: 0,
        cogs: 0,
        grossProfit: 0,
        wasteCost: 0,
        expenses: 0,
        operatingProfit: 0,
        plates: 0,
        orders: 0
      });
    }

    const row = dailyMap.get(dateStr);
    row.revenue += netRev;
    row.cogs += cogs;
    row.grossProfit += (netRev - cogs);
    row.plates += qty;
    row.orders += 1;
  }

  for (let i = 0; i < (wasteTransactions || []).length; i++) {
    const tx = wasteTransactions[i];
    const dateStr = toDateStr(tx.transaction_date);
    const qty = Number(tx.quantity) || 0;
    const ing = ingredientsMap.get ? ingredientsMap.get(tx.ingredient_id) : ingredientsMap[tx.ingredient_id];
    const cost = qty * (ing ? Number(ing.unit_cost) : 0);

    if (dailyMap.has(dateStr)) {
      dailyMap.get(dateStr).wasteCost += cost;
    }
  }

  for (let i = 0; i < (expenses || []).length; i++) {
    const exp = expenses[i];
    const dateStr = toDateStr(exp.expense_date);
    const amt = Number(exp.amount) || 0;

    if (dailyMap.has(dateStr)) {
      dailyMap.get(dateStr).expenses += amt;
    }
  }

  const sortedDays = Array.from(dailyMap.values()).sort((a, b) => a.fullDate.localeCompare(b.fullDate));
  sortedDays.forEach(d => {
    d.revenue = Number(d.revenue.toFixed(2));
    d.cogs = Number(d.cogs.toFixed(2));
    d.grossProfit = Number(d.grossProfit.toFixed(2));
    d.wasteCost = Number(d.wasteCost.toFixed(2));
    d.expenses = Number(d.expenses.toFixed(2));
    d.operatingProfit = Number((d.grossProfit - d.expenses).toFixed(2));
  });

  return sortedDays;
}

export function calculateMonthlyTrend(dailyTrend) {
  const monthMap = new Map();
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  dailyTrend.forEach(d => {
    const [yyyy, mm] = d.fullDate.split('-');
    const mKey = `${yyyy}-${mm}`;
    const mLabel = `${monthNames[parseInt(mm, 10) - 1]} ${yyyy}`;

    if (!monthMap.has(mKey)) {
      monthMap.set(mKey, {
        month: mKey,
        monthLabel: mLabel,
        revenue: 0,
        cogs: 0,
        grossProfit: 0,
        expenses: 0,
        operatingProfit: 0,
        wasteCost: 0,
        plates: 0,
        orders: 0,
        daysCount: 0
      });
    }

    const row = monthMap.get(mKey);
    row.revenue += d.revenue;
    row.cogs += d.cogs;
    row.grossProfit += d.grossProfit;
    row.expenses += d.expenses;
    row.operatingProfit += d.operatingProfit;
    row.wasteCost += d.wasteCost;
    row.plates += d.plates;
    row.orders += d.orders;
    row.daysCount += 1;
  });

  return Array.from(monthMap.values()).map(m => ({
    ...m,
    revenue: Number(m.revenue.toFixed(2)),
    cogs: Number(m.cogs.toFixed(2)),
    grossProfit: Number(m.grossProfit.toFixed(2)),
    expenses: Number(m.expenses.toFixed(2)),
    operatingProfit: Number(m.operatingProfit.toFixed(2)),
    wasteCost: Number(m.wasteCost.toFixed(2)),
    grossMarginPct: Number((safeDivide(m.grossProfit, m.revenue) * 100).toFixed(1)),
    operatingMarginPct: Number((safeDivide(m.operatingProfit, m.revenue) * 100).toFixed(1))
  }));
}

export function calculateHourlyProfile(sales, productsMap) {
  const hourMap = new Map();

  for (let h = 15; h <= 22; h++) {
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h > 12 ? h - 12 : h;
    let footfallIntensity = 'Standard Footfall';
    if (h === 18) footfallIntensity = 'Peak Commuter Rush';
    else if (h === 19) footfallIntensity = 'Peak Family Chaat';
    else if (h === 20) footfallIntensity = 'Evening Dinner Rush';
    else if (h === 17) footfallIntensity = 'Evening Rush Kickoff';
    else if (h === 15 || h === 16) footfallIntensity = 'Afternoon Opening';
    else if (h === 22) footfallIntensity = 'Late Wrap & Sukha Puri';

    hourMap.set(h, {
      hour: `${displayH}:00 ${period}`,
      hour24: h,
      orders: 0,
      plates: 0,
      revenue: 0,
      cogs: 0,
      footfallIntensity
    });
  }

  sales.forEach(s => {
    let hour = 18;
    if (s.sale_datetime) {
      const parts = s.sale_datetime.split(' ');
      if (parts[1]) {
        hour = parseInt(parts[1].split(':')[0], 10);
      }
    }

    if (hourMap.has(hour)) {
      const row = hourMap.get(hour);
      const qty = Number(s.quantity_plates) || 0;
      const price = Number(s.unit_price) || 0;
      const discount = Number(s.discount) || 0;
      const prod = productsMap.get ? productsMap.get(s.product_id) : productsMap[s.product_id];
      const costPerPlate = prod ? Number(prod.ingredient_cost_per_plate) : 0;

      const netRev = Math.max(0, qty * price - discount);
      row.orders += 1;
      row.plates += qty;
      row.revenue += netRev;
      row.cogs += qty * costPerPlate;
    }
  });

  return Array.from(hourMap.values()).map(h => ({
    ...h,
    revenue: Number(h.revenue.toFixed(2)),
    cogs: Number(h.cogs.toFixed(2))
  }));
}

export function calculateWeekdayProfile(sales) {
  const days = [
    { day: 'Sun', dayFull: 'Sunday', dayIndex: 0, revenue: 0, plates: 0, orders: 0 },
    { day: 'Mon', dayFull: 'Monday', dayIndex: 1, revenue: 0, plates: 0, orders: 0 },
    { day: 'Tue', dayFull: 'Tuesday', dayIndex: 2, revenue: 0, plates: 0, orders: 0 },
    { day: 'Wed', dayFull: 'Wednesday', dayIndex: 3, revenue: 0, plates: 0, orders: 0 },
    { day: 'Thu', dayFull: 'Thursday', dayIndex: 4, revenue: 0, plates: 0, orders: 0 },
    { day: 'Fri', dayFull: 'Friday', dayIndex: 5, revenue: 0, plates: 0, orders: 0 },
    { day: 'Sat', dayFull: 'Saturday', dayIndex: 6, revenue: 0, plates: 0, orders: 0 }
  ];

  sales.forEach(s => {
    const dt = new Date(`${toDateStr(s.sale_datetime)}T12:00:00+05:30`);
    const dayIdx = dt.getDay();
    const qty = Number(s.quantity_plates) || 0;
    const price = Number(s.unit_price) || 0;
    const discount = Number(s.discount) || 0;
    const netRev = Math.max(0, qty * price - discount);

    if (days[dayIdx]) {
      days[dayIdx].revenue += netRev;
      days[dayIdx].plates += qty;
      days[dayIdx].orders += 1;
    }
  });

  return days.map(d => ({
    ...d,
    revenue: Number(d.revenue.toFixed(2))
  }));
}

export function calculateProductPerformance(sales, productsList) {
  const prodStats = new Map();
  const themeColors = ['#A7D78A', '#EAB64B', '#D98768', '#7BC0C0', '#A594F9'];

  productsList.forEach((p, idx) => {
    prodStats.set(p.product_id, {
      product_id: p.product_id,
      product_name: p.product_name,
      category: p.category,
      selling_price: Number(p.selling_price),
      ingredient_cost_per_plate: Number(p.ingredient_cost_per_plate),
      unit_margin: Number((p.selling_price - p.ingredient_cost_per_plate).toFixed(2)),
      color: themeColors[idx % themeColors.length],
      plates_sold: 0,
      gross_revenue: 0,
      discounts: 0,
      net_revenue: 0,
      cogs: 0,
      gross_profit: 0,
      orders_count: 0
    });
  });

  let grandNetRevenue = 0;
  let grandPlates = 0;

  sales.forEach(s => {
    if (prodStats.has(s.product_id)) {
      const stat = prodStats.get(s.product_id);
      const qty = Number(s.quantity_plates) || 0;
      const price = Number(s.unit_price) || 0;
      const discount = Number(s.discount) || 0;
      const lineGross = qty * price;
      const lineNet = Math.max(0, lineGross - discount);
      const lineCogs = qty * stat.ingredient_cost_per_plate;

      stat.plates_sold += qty;
      stat.gross_revenue += lineGross;
      stat.discounts += discount;
      stat.net_revenue += lineNet;
      stat.cogs += lineCogs;
      stat.gross_profit += (lineNet - lineCogs);
      stat.orders_count += 1;

      grandNetRevenue += lineNet;
      grandPlates += qty;
    }
  });

  const ranked = Array.from(prodStats.values()).map(p => {
    const revShare = safeDivide(p.net_revenue, grandNetRevenue) * 100;
    const volShare = safeDivide(p.plates_sold, grandPlates) * 100;
    const marginPct = safeDivide(p.gross_profit, p.net_revenue) * 100;

    return {
      ...p,
      gross_revenue: Number(p.gross_revenue.toFixed(2)),
      discounts: Number(p.discounts.toFixed(2)),
      net_revenue: Number(p.net_revenue.toFixed(2)),
      cogs: Number(p.cogs.toFixed(2)),
      gross_profit: Number(p.gross_profit.toFixed(2)),
      revenue_share_pct: Number(revShare.toFixed(1)),
      volume_share_pct: Number(volShare.toFixed(1)),
      gross_margin_pct: Number(marginPct.toFixed(1)),
      name: p.product_name,
      plates: p.plates_sold,
      revenue: Number(p.net_revenue.toFixed(2)),
      share: Number(volShare.toFixed(1))
    };
  });

  return ranked.sort((a, b) => b.net_revenue - a.net_revenue);
}

export function calculatePaymentMethods(sales) {
  let upiCount = 0;
  let upiRevenue = 0;
  let cashCount = 0;
  let cashRevenue = 0;

  sales.forEach(s => {
    const qty = Number(s.quantity_plates) || 0;
    const price = Number(s.unit_price) || 0;
    const discount = Number(s.discount) || 0;
    const netRev = Math.max(0, qty * price - discount);

    if (s.payment_method === 'UPI') {
      upiCount += 1;
      upiRevenue += netRev;
    } else {
      cashCount += 1;
      cashRevenue += netRev;
    }
  });

  const totalSales = sales.length;
  const totalRev = upiRevenue + cashRevenue;

  return [
    {
      method: 'UPI (QR & Apps)',
      rawMethod: 'UPI',
      count: upiCount,
      revenue: Number(upiRevenue.toFixed(2)),
      countSharePct: Number((safeDivide(upiCount, totalSales) * 100).toFixed(1)),
      revenueSharePct: Number((safeDivide(upiRevenue, totalRev) * 100).toFixed(1)),
      color: '#A7D78A'
    },
    {
      method: 'Cash Payment',
      rawMethod: 'Cash',
      count: cashCount,
      revenue: Number(cashRevenue.toFixed(2)),
      countSharePct: Number((safeDivide(cashCount, totalSales) * 100).toFixed(1)),
      revenueSharePct: Number((safeDivide(cashRevenue, totalRev) * 100).toFixed(1)),
      color: '#EAB64B'
    }
  ];
}

export function calculateInventoryStatus(ingredientsList, inventoryTransactions, upToDate = null) {
  const stockMap = new Map();

  ingredientsList.forEach(ing => {
    stockMap.set(ing.ingredient_id, {
      id: ing.ingredient_id,
      code: ing.ingredient_id,
      name: ing.ingredient_name,
      unit: ing.unit,
      cost_per_unit: Number(ing.unit_cost),
      minimum_threshold: Number(ing.reorder_level),
      total_purchased: 0,
      total_consumed: 0,
      total_wasted: 0,
      current_stock: 0,
      recentDailyAvgConsumption: 0
    });
  });

  const maxDateStr = upToDate ? toDateStr(upToDate) : '9999-99-99';

  inventoryTransactions.forEach(tx => {
    const txDate = toDateStr(tx.transaction_date);
    if (txDate > maxDateStr) return;

    if (stockMap.has(tx.ingredient_id)) {
      const item = stockMap.get(tx.ingredient_id);
      const qty = Number(tx.quantity) || 0;

      if (tx.transaction_type === 'PURCHASE') {
        item.total_purchased += qty;
      } else if (tx.transaction_type === 'CONSUMPTION') {
        item.total_consumed += qty;
      } else if (tx.transaction_type === 'WASTE') {
        item.total_wasted += qty;
      }
    }
  });

  let totalInventoryValue = 0;
  let lowStockCount = 0;

  const result = Array.from(stockMap.values()).map(item => {
    const curStock = Number((item.total_purchased - item.total_consumed - item.total_wasted).toFixed(2));
    const invValue = Number((curStock * item.cost_per_unit).toFixed(2));
    totalInventoryValue += invValue;

    const avgDailyUsage = safeDivide(item.total_consumed, 182);
    const runwayDays = Math.max(1, Math.round(safeDivide(curStock, avgDailyUsage)));

    let status = 'Healthy';
    if (curStock <= item.minimum_threshold * 0.5) {
      status = 'Critical';
      lowStockCount++;
    } else if (curStock <= item.minimum_threshold) {
      status = 'Low';
      lowStockCount++;
    }

    return {
      ...item,
      current_stock: curStock,
      total_purchased: Number(item.total_purchased.toFixed(2)),
      total_consumed: Number(item.total_consumed.toFixed(2)),
      total_wasted: Number(item.total_wasted.toFixed(2)),
      inventory_value: invValue,
      status,
      daysRunway: runwayDays
    };
  });

  return {
    ingredients: result,
    totalInventoryValue: Number(totalInventoryValue.toFixed(2)),
    lowStockCount
  };
}

export function calculateWasteAnalytics(wasteTransactions, ingredientsMap, totalNetRevenue = 0) {
  const ingWasteMap = new Map();
  let totalWasteCost = 0;
  let totalWasteIncidents = wasteTransactions.length;

  wasteTransactions.forEach(tx => {
    const ing = ingredientsMap.get ? ingredientsMap.get(tx.ingredient_id) : ingredientsMap[tx.ingredient_id];
    const qty = Number(tx.quantity) || 0;
    const unitCost = ing ? Number(ing.unit_cost) : 0;
    const cost = qty * unitCost;
    totalWasteCost += cost;

    if (!ingWasteMap.has(tx.ingredient_id)) {
      ingWasteMap.set(tx.ingredient_id, {
        ingredient_id: tx.ingredient_id,
        ingredient: ing ? ing.ingredient_name : tx.ingredient_id,
        quantity: 0,
        unit: ing ? ing.unit : '',
        cost: 0
      });
    }

    const row = ingWasteMap.get(tx.ingredient_id);
    row.quantity += qty;
    row.cost += cost;
  });

  const wasteByIngredient = Array.from(ingWasteMap.values()).map(w => ({
    ...w,
    quantity: Number(w.quantity.toFixed(1)),
    cost: Number(w.cost.toFixed(2)),
    share: Number((safeDivide(w.cost, totalWasteCost) * 100).toFixed(1))
  })).sort((a, b) => b.cost - a.cost);

  const puriWaste = wasteByIngredient.find(w => w.ingredient_id === 'ING-001');
  const mintPaniWaste = wasteByIngredient.find(w => w.ingredient_id === 'ING-004');
  const potatoWaste = wasteByIngredient.find(w => w.ingredient_id === 'ING-002');
  const dahiWaste = wasteByIngredient.find(w => w.ingredient_id === 'ING-008');

  const wasteByReason = [
    {
      reason: 'Broken Puris (Transit & Handling Damage)',
      totalCost: puriWaste ? puriWaste.cost : 0,
      percentage: puriWaste ? puriWaste.share : 0,
      color: '#D98768'
    },
    {
      reason: 'Leftover Oxidized Pani & Souring Mint',
      totalCost: mintPaniWaste ? mintPaniWaste.cost : 0,
      percentage: mintPaniWaste ? mintPaniWaste.share : 0,
      color: '#A7D78A'
    },
    {
      reason: 'Excess Boiled Potato Mash Souring',
      totalCost: potatoWaste ? potatoWaste.cost : 0,
      percentage: potatoWaste ? potatoWaste.share : 0,
      color: '#EAB64B'
    },
    {
      reason: 'Curd & Dairy Temperature Spoilage',
      totalCost: dahiWaste ? dahiWaste.cost : 0,
      percentage: dahiWaste ? dahiWaste.share : 0,
      color: '#7BC0C0'
    }
  ].filter(r => r.totalCost > 0);

  return {
    kpis: {
      totalWasteCost: Number(totalWasteCost.toFixed(2)),
      totalIncidents: totalWasteIncidents,
      avgDailyWaste: Number((safeDivide(totalWasteCost, 182)).toFixed(2)),
      wasteRatePct: Number((safeDivide(totalWasteCost, totalNetRevenue) * 100).toFixed(1))
    },
    wasteByIngredient,
    wasteByReason
  };
}
