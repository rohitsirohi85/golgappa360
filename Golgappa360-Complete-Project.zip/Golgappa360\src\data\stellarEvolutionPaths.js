/**
 * STELLAR — Stellar Evolution Branching Pathways & Cosmic Lore
 * Compares Low-Mass, Sun-Like (Medium Mass), and High-Mass evolutionary tracks.
 */

export const EVOLUTION_PATHS = {
  'low-mass': {
    id: 'low-mass',
    name: 'Low Mass',
    massRange: '< 0.5 M☉ (Red Dwarfs)',
    lifespan: '≈ 1 to 10+ Trillion Years',
    exampleStar: 'Proxima Centauri',
    colorHex: '#ef4444',
    summary:
      'Fully convective interior circulates hydrogen from surface to core, burning fuel at an extraordinarily frugal pace without ever expanding into a giant.',
    stages: ['molecular-cloud', 'protostar', 'main-sequence', 'white-dwarf'],
    destinyNote:
      'Never becomes a red giant; slowly contracts into a theoretical blue dwarf and then a cold degenerate helium white dwarf over trillions of years.',
  },
  'sun-like': {
    id: 'sun-like',
    name: 'Sun-Like (Medium)',
    massRange: '≈ 0.5 to 8 M☉ (Yellow & Orange Dwarfs)',
    lifespan: '≈ 9 to 12 Billion Years',
    exampleStar: 'Sun, Sirius A, Vega',
    colorHex: '#fbbf24',
    summary:
      'Spends roughly 10 billion years on the main sequence, swells into a red giant, sheds its outer envelope as a planetary nebula, and leaves an Earth-sized white dwarf.',
    stages: [
      'molecular-cloud',
      'protostar',
      'main-sequence',
      'red-giant',
      'planetary-nebula',
      'white-dwarf',
    ],
    destinyNote:
      'Leaves a dense carbon-oxygen White Dwarf that slowly radiates its residual heat over hundreds of billions of years.',
  },
  'high-mass': {
    id: 'high-mass',
    name: 'High Mass',
    massRange: '> 8 M☉ (Blue Giants & Supergiants)',
    lifespan: '≈ 3 to 30 Million Years',
    exampleStar: 'Betelgeuse, Rigel, Antares',
    colorHex: '#38bdf8',
    summary:
      'Burns through thermonuclear fuel at furious rates, expands into a colossal supergiant, synthesizes elements up to iron, and detonates as a Type II core-collapse supernova.',
    stages: [
      'molecular-cloud',
      'protostar',
      'main-sequence',
      'supergiant',
      'supernova',
      'neutron-star',
      'black-hole',
    ],
    destinyNote:
      'If the remnant core is 1.4–3 M☉, it freezes as a Neutron Star (pulsar). If greater than 3 M☉, it collapses into a Black Hole.',
  },
};

export const LIFETIME_SCALE_DATA = [
  {
    name: 'High Mass Star (≈ 20 M☉)',
    example: 'Rigel, Spica',
    duration: '≈ 10 Million Years',
    relativeWidth: '3%',
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.4)',
    barLabel: '10 Myr',
    description: 'A cosmological blink. Consumes nuclear fuel with extreme ferocious power.',
  },
  {
    name: 'Sun-Like Star (1.0 M☉)',
    example: 'Sun, Alpha Centauri A',
    duration: '≈ 10 Billion Years',
    relativeWidth: '28%',
    color: '#fbbf24',
    glow: 'rgba(251, 191, 36, 0.4)',
    barLabel: '10 Gyr',
    description: 'Stable multi-billion-year plateau allowing planetary climates and biology to evolve.',
  },
  {
    name: 'Low Mass Red Dwarf (≈ 0.2 M☉)',
    example: 'Proxima Centauri',
    duration: '≈ 1 to 10+ Trillion Years',
    relativeWidth: '100%',
    color: '#ef4444',
    glow: 'rgba(239, 68, 68, 0.4)',
    barLabel: '1–10+ Trillion Years',
    description: 'Fully convective interior sips fuel; outlives the current age of the Universe by 100×.',
  },
];

export const COSMIC_FACTS = [
  {
    id: 1,
    title: 'STELLAR CRADLES',
    fact: 'Stars are born inside massive clouds of gas and dust called giant molecular clouds or stellar nurseries, spanning dozens of light-years across.',
    icon: '✦',
    accent: '#a855f7',
  },
  {
    id: 2,
    title: 'THE 90% RULE',
    fact: 'Over 90% of a star’s total lifespan is spent quietly in the main sequence, stably fusing hydrogen into helium in perfect hydrostatic equilibrium.',
    icon: '☉',
    accent: '#fbbf24',
  },
  {
    id: 3,
    title: 'LIVE FAST, DIE YOUNG',
    fact: 'Because a star’s luminosity increases with the 3.5th power of its mass, a star with 20 times the Sun’s mass burns through its fuel 35,000 times faster.',
    icon: '⚡',
    accent: '#38bdf8',
  },
  {
    id: 4,
    title: 'WE ARE STARDUST',
    fact: 'All elements heavier than helium—including the calcium in your bones and iron in your blood—were created in the hearts and explosions of dying stars.',
    icon: '✨',
    accent: '#f43f5e',
  },
  {
    id: 5,
    title: 'COSMIC RECYCLING',
    fact: 'Supernovae and planetary nebulae blast enriched gas back into interstellar space, seeding the next generation of solar systems and rocky planets.',
    icon: '🌀',
    accent: '#00d2ff',
  },
];
