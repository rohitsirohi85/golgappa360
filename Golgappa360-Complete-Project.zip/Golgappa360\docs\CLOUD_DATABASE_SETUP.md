# EV SMART — Cloud Database Configuration & Migration Guide (MongoDB Atlas)

**Document Version:** `1.0.0-RC1`  
**Database Engine:** MongoDB 7.0+ (WiredTiger Storage Engine)  
**Cloud Platform:** MongoDB Atlas Cloud Service  
**Classification:** Database Administration & Infrastructure Specification  

---

## 1. Overview

EV SMART is designed to run seamlessly with both local **MongoDB Community Server** (for development and offline testing) and **MongoDB Atlas Cloud Database Clusters** (for staging, production, and distributed cloud deployments).

This document provides complete instructions for provisioning, securing, connecting, and indexing a MongoDB Atlas cloud cluster for EV SMART.

---

## 2. Cloud Database Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│ MongoDB Atlas Cloud (Multi-AZ Replica Set)                             │
│                                                                        │
│   ┌──────────────────────┐              ┌──────────────────────┐       │
│   │ Primary Node (Read/  │  Replication │ Secondary Node (Read)│       │
│   │ Write) - AZ 1        │ ◄──────────► │ AZ 2                 │       │
│   └──────────┬───────────┘              └──────────────────────┘       │
│              │                                     ▲                   │
│              │           Replication               │                   │
│              └─────────────────────────────────────┘                   │
│                                 ▲                                      │
│                                 │ Heartbeat / Quorum                   │
│                     ┌───────────┴──────────┐                           │
│                     │ Secondary Node (Read)│                           │
│                     │ AZ 3                 │                           │
│                     └──────────────────────┘                           │
└─────────────────────────────────▲──────────────────────────────────────┘
                                  │ TLS 1.3 / SRV Connection
                                  │ mongodb+srv://...
                    ┌─────────────┴─────────────┐
                    │  EV SMART Node.js Backend │
                    │  (Mongoose 8.x Pool)      │
                    └───────────────────────────┘
```

---

## 3. Provisioning a Cloud Cluster (Step-by-Step)

### Step 1: Create MongoDB Atlas Account & Project
1. Navigate to [mongodb.com/atlas](https://www.mongodb.com/atlas) and sign in.
2. Create a new Project named `EV-SMART-PROJECT`.

### Step 2: Deploy Cluster
1. Click **Create Deployment**.
2. **Cluster Tier:**
   - **For Academic Demo / Staging:** Select **Shared M0** (Free, 512MB storage, multi-tenant).
   - **For Enterprise Production:** Select **Dedicated M10** (10GB storage, 2GB RAM, automated snapshots).
3. **Cloud Provider & Region:**
   - Select **AWS** or **Google Cloud**.
   - Choose a low-latency region closest to your application server (e.g., `ap-south-1` Mumbai or `us-east-1` N. Virginia).
4. Name the cluster: `evsmart-cluster`.
5. Click **Create Cluster** (takes ~1-3 minutes to provision).

---

## 4. Security & Network Configuration

### 4.1 Database User Provisioning (Least-Privilege)
1. In the Atlas sidebar, navigate to **Security -> Database Access**.
2. Click **Add New Database User**.
3. **Authentication Method:** Password.
4. **Username:** `evsmart_app_user`.
5. **Password:** Generate a strong 32-character alphanumeric password (avoid special characters like `@`, `/`, `?` or URL-encode them).
6. **Database User Privileges:**
   - Select **Built-in Role** -> **Read and write to any database** (or restrict to `evsmart` database).
7. Click **Add User**.

### 4.2 Network IP Access Whitelist
1. In the sidebar, navigate to **Security -> Network Access**.
2. Click **Add IP Address**.
3. **For Staging / Testing:**
   - Choose **Allow Access from Anywhere** (`0.0.0.0/0`) if deploying to serverless platforms or dynamic developer IPs.
4. **For Strict Production:**
   - Add only the static Elastic IP(s) or NAT Gateway addresses of your production application servers.
5. Click **Confirm**.

---

## 5. Connection String Configuration

### 5.1 Connection String Anatomy
Atlas provides a modern DNS SRV connection string:
```text
mongodb+srv://<username>:<password>@evsmart-cluster.xxxxx.mongodb.net/<database>?retryWrites=true&w=majority
```

| Parameter | Meaning | Recommended Value |
| :--- | :--- | :--- |
| `mongodb+srv://` | DNS SRV protocol (automatic replica discovery) | Standard |
| `<username>` | Atlas database username | `evsmart_app_user` |
| `<password>` | URL-encoded user password | *Secure Random String* |
| `evsmart-cluster.xxxxx.mongodb.net` | Cluster DNS hostname | Provided by Atlas |
| `<database>` | Target application database | `evsmart` |
| `retryWrites=true` | Automatic retry on transient network writes | `true` |
| `w=majority` | Write acknowledgment on majority of replica nodes | `majority` |

### 5.2 Configuring Backend Environment
In `backend/.env`:
```bash
# Atlas Remote Cloud Database Connection
MONGODB_URI=mongodb+srv://evsmart_app_user:YourStrongPassword123@evsmart-cluster.abcde.mongodb.net/evsmart?retryWrites=true&w=majority
MONGO_URI=mongodb+srv://evsmart_app_user:YourStrongPassword123@evsmart-cluster.abcde.mongodb.net/evsmart?retryWrites=true&w=majority
```

### 5.3 Mongoose Connection Pool Configuration (`backend/src/config/database.js`)
The application is pre-configured with resilient connection options:
```javascript
const options = {
  maxPoolSize: 50,             // Maintain up to 50 socket connections
  minPoolSize: 5,              // Minimum active connections
  serverSelectionTimeoutMS: 5000, // Fail fast if cluster is unreachable (5s)
  socketTimeoutMS: 45000,      // Close sockets after 45s of inactivity
  family: 4                    // Use IPv4
};
```

---

## 6. Schema Index Verification & Performance Tuning

To ensure sub-millisecond query performance on remote cloud clusters, EV SMART schemas declare indexes on high-frequency query paths:

| Collection | Indexed Fields | Index Type | Query Optimization Target |
| :--- | :--- | :--- | :--- |
| `chargers` | `stationId`, `status` | Compound Index | Station charger listing & availability |
| `chargers` | `chargerId` | Unique Index | Real-time telemetry ingestion lookup |
| `chargingsessions` | `userId`, `createdAt` | Compound Desc | User history queries |
| `chargingsessions` | `chargerId`, `status` | Compound Index | Active session watchdog tracking |
| `sensorreadings` | `chargerId`, `timestamp` | Compound Desc | Time-series telemetry charting |
| `sensorreadings` | `timestamp` | TTL / Desc Index | Historical analytics aggregation |
| `bookings` | `userId`, `slotStartTime` | Compound Index | Slot collision prevention |
| `auditlogs` | `createdAt` | Descending Index | Security log inspection |

---

## 7. Migration, Seed & Backup Procedures

### 7.1 Seeding Cloud Database
Once connected to Atlas, seed the initial network of stations and chargers:
```powershell
cd d:\antigravty\backend
npm run seed-demo-data
```

### 7.2 Database Backup (mongodump)
Create a full binary snapshot of the cloud database:
```powershell
mongodump --uri="mongodb+srv://evsmart_app_user:YourStrongPassword123@evsmart-cluster.abcde.mongodb.net/evsmart" --out=./backups/$(Get-Date -Format "yyyy-MM-dd")
```

### 7.3 Database Restore (mongorestore)
Restore from a previous backup:
```powershell
mongorestore --uri="mongodb+srv://evsmart_app_user:YourStrongPassword123@evsmart-cluster.abcde.mongodb.net/evsmart" --drop ./backups/2026-09-25/evsmart
```

### 7.4 Atlas Automated Snapshots
On M10+ tiers, Atlas performs continuous automated snapshots every 6 hours with 35-day point-in-time restore capability directly in the Atlas web console.

---

## 8. Verification & Diagnostic Commands

Run this one-line Node.js diagnostic to verify cloud database connectivity:
```powershell
node -e "const mongoose = require('mongoose'); mongoose.connect(process.env.MONGODB_URI).then(() => { console.log('Successfully connected to MongoDB Atlas!'); process.exit(0); }).catch(e => { console.error('Connection failed:', e.message); process.exit(1); });"
```
