/**
 * STELLAR 2.0 — High-Performance Canvas Celestial Object & Atlas Renderer
 * 
 * Renders multi-layer astronomical depth with authentic visual signatures:
 * - Layer 1: Deep cosmic background & faint nebula gas clouds
 * - Layer 2: Distant parallax micro-starfield
 * - Layer 3: Constellation connection geometry & regional labels
 * - Layer 4: Celestial Objects:
 *     - Stars (Main Sequence, Red Giants, Supergiants, Red Dwarfs)
 *     - White Dwarfs (Compact diamond-white with violet aura)
 *     - Neutron Stars (Ultra-dense thermal pinpoints)
 *     - Pulsars (Spinning synchrotron beam cones & pulse rings)
 *     - Black Holes (Pitch-black event horizon, Doppler accretion disk & photon ring)
 *     - Nebulae (Diffuse billowing clouds, reflection haze & Ring Nebula donut)
 *     - Star Clusters (Collective haze with embedded member stars)
 *     - Galaxies (Tilted spiral discs with bright bulges & dust lanes)
 * - Layer 5: Target reticle & scientific HUD brackets for selected objects
 */

import {
  CONSTELLATION_LINES,
  CONSTELLATION_REGIONS,
  NEBULA_REGIONS,
  BACKGROUND_STARS,
} from '../../utils/mapCoordinates.js';
import { worldToScreen } from '../../utils/mapScale.js';
import { CELESTIAL_CATEGORIES } from '../../data/celestialObjects.js';

/**
 * Safely sets or overrides the alpha channel of any CSS color string
 * (hex, rgb, or rgba) to prevent canvas gradient parsing errors.
 */
function setAlpha(colorStr, alpha) {
  if (!colorStr) return `rgba(255, 255, 255, ${alpha})`;
  const trimmed = colorStr.trim();
  // rgba(r, g, b, a)
  if (trimmed.startsWith('rgba')) {
    return trimmed.replace(/,\s*[\d.]+\s*\)$/, `, ${alpha})`);
  }
  // rgb(r, g, b)
  if (trimmed.startsWith('rgb(')) {
    return trimmed.replace('rgb(', 'rgba(').replace(/\)$/, `, ${alpha})`);
  }
  // 6-digit hex (#rrggbb)
  if (trimmed.startsWith('#') && (trimmed.length === 7 || trimmed.length === 9)) {
    const r = parseInt(trimmed.slice(1, 3), 16);
    const g = parseInt(trimmed.slice(3, 5), 16);
    const b = parseInt(trimmed.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  return trimmed;
}

/**
 * Draws the deep-space void and atmospheric cosmic nebulae.
 */
export function drawBackground(ctx, width, height, camera) {
  // Deep space base void
  ctx.fillStyle = '#020308';
  ctx.fillRect(0, 0, width, height);

  // Subtle vignette
  const grad = ctx.createRadialGradient(
    width / 2,
    height / 2,
    Math.min(width, height) * 0.2,
    width / 2,
    height / 2,
    Math.max(width, height) * 0.8
  );
  grad.addColorStop(0, 'rgba(4, 7, 20, 0.4)');
  grad.addColorStop(1, 'rgba(1, 2, 5, 0.95)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Faint celestial dust / nebula regions with parallax
  for (const neb of NEBULA_REGIONS) {
    const screenPos = worldToScreen(neb.x, neb.y, camera, width, height);
    const radius = neb.radius * camera.zoom;

    // Viewport cull check
    if (
      screenPos.x + radius < 0 ||
      screenPos.x - radius > width ||
      screenPos.y + radius < 0 ||
      screenPos.y - radius > height
    ) {
      continue;
    }

    const nebGrad = ctx.createRadialGradient(
      screenPos.x,
      screenPos.y,
      0,
      screenPos.x,
      screenPos.y,
      radius
    );
    nebGrad.addColorStop(0, neb.color);
    nebGrad.addColorStop(0.55, setAlpha(neb.color, 0.025));
    nebGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = nebGrad;
    ctx.beginPath();
    ctx.arc(screenPos.x, screenPos.y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
}

/**
 * Draws 300+ distant background stars with smooth parallax depth.
 */
export function drawBackgroundStars(ctx, width, height, camera, time) {
  const parallaxCamera = {
    x: camera.x * 0.25,
    y: camera.y * 0.25,
    zoom: 1.0,
  };

  for (let i = 0; i < BACKGROUND_STARS.length; i++) {
    const s = BACKGROUND_STARS[i];
    const screenPos = worldToScreen(s.x, s.y, parallaxCamera, width, height);

    if (screenPos.x < -10 || screenPos.x > width + 10 || screenPos.y < -10 || screenPos.y > height + 10) {
      continue;
    }

    const twinkle = 0.75 + Math.sin(time * s.twinkleSpeed + s.phase) * 0.25;
    const alpha = s.baseAlpha * twinkle;

    ctx.fillStyle = `rgba(226, 232, 240, ${alpha})`;
    ctx.beginPath();
    ctx.arc(screenPos.x, screenPos.y, s.radius, 0, Math.PI * 2);
    ctx.fill();
  }
}

/**
 * Draws constellation lines with zoom-dependent opacity and active selection highlighting.
 */
export function drawConstellationLines(
  ctx,
  width,
  height,
  camera,
  starMap,
  activeCategoryFilter,
  selectedConstellationId = null
) {
  const zoom = camera.zoom;

  // Zoom LOD: faint at level 1, clearer at level 2+
  let baseAlpha = 0.18;
  if (zoom >= 1.2 && zoom < 2.5) {
    baseAlpha = 0.38;
  } else if (zoom >= 2.5) {
    baseAlpha = 0.48;
  }

  // Dim slightly if a non-star filter is active
  if (activeCategoryFilter && activeCategoryFilter !== CELESTIAL_CATEGORIES.STAR && activeCategoryFilter !== 'ALL') {
    baseAlpha *= 0.35;
  }

  for (const line of CONSTELLATION_LINES) {
    const starA = starMap[line.from];
    const starB = starMap[line.to];
    if (!starA || !starB) continue;

    const posA = worldToScreen(starA.x, starA.y, camera, width, height);
    const posB = worldToScreen(starB.x, starB.y, camera, width, height);

    if (
      (posA.x < 0 && posB.x < 0) ||
      (posA.x > width && posB.x > width) ||
      (posA.y < 0 && posB.y < 0) ||
      (posA.y > height && posB.y > height)
    ) {
      continue;
    }

    const isLineActive =
      selectedConstellationId &&
      (line.constellationId === selectedConstellationId ||
        line.constellation?.toLowerCase() === selectedConstellationId.toLowerCase() ||
        line.constellation?.toLowerCase().replace(/\s+/g, '-') === selectedConstellationId.toLowerCase());

    ctx.save();

    if (isLineActive) {
      // High-intensity highlight for active constellation lines
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.95)';
      ctx.shadowColor = 'rgba(56, 189, 248, 0.7)';
      ctx.shadowBlur = 8;
      ctx.setLineDash([]);
    } else {
      ctx.lineWidth = 1;
      const dimmedMultiplier = selectedConstellationId ? 0.22 : 1.0;
      const alpha = (line.isFaintHint ? baseAlpha * 0.5 : baseAlpha) * dimmedMultiplier;

      ctx.strokeStyle = line.isFaintHint
        ? `rgba(148, 163, 184, ${alpha})`
        : `rgba(56, 189, 248, ${alpha})`;

      if (line.isFaintHint) {
        ctx.setLineDash([4, 6]);
      } else {
        ctx.setLineDash([]);
      }
    }

    ctx.beginPath();
    ctx.moveTo(posA.x, posA.y);
    ctx.lineTo(posB.x, posB.y);
    ctx.stroke();

    ctx.restore();
  }
}

/**
 * Draws soft glowing region boundary and cosmic aura for the selected constellation.
 */
export function drawConstellationRegionAura(ctx, width, height, camera, selectedConstellation, time) {
  if (!selectedConstellation) return;

  const reg =
    CONSTELLATION_REGIONS.find(
      (r) =>
        r.id === selectedConstellation.id ||
        r.name.toLowerCase() === selectedConstellation.name?.toLowerCase() ||
        r.id === selectedConstellation.constellationId
    ) || selectedConstellation;

  if (!reg || typeof reg.x !== 'number') return;

  const pos = worldToScreen(reg.x, reg.y, camera, width, height);
  const zoom = camera.zoom;
  const radius = (reg.radius || 180) * zoom;

  // Viewport bounds check
  if (
    pos.x + radius < 0 ||
    pos.x - radius > width ||
    pos.y + radius < 0 ||
    pos.y - radius > height
  ) {
    return;
  }

  ctx.save();

  // 1. Soft glowing cosmic boundary nebula
  const grad = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, radius);
  const accentColor = selectedConstellation.colorHex || selectedConstellation.accentColor || '#38bdf8';
  grad.addColorStop(0, setAlpha(accentColor, 0.08));
  grad.addColorStop(0.65, setAlpha(accentColor, 0.02));
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
  ctx.fill();

  // 2. Delicate dashed celestial region boundary ring
  ctx.strokeStyle = setAlpha(accentColor, 0.25);
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 8]);
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, radius * 0.95, 0, Math.PI * 2);
  ctx.stroke();

  // 3. Constellation Header Callout at the top of boundary
  const tagY = pos.y - radius * 0.95 - 12;
  if (tagY > 20 && tagY < height - 20) {
    ctx.font = '600 10px "Space Grotesk", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = setAlpha(accentColor, 0.85);
    ctx.letterSpacing = '2.5px';
    const titleText = `✦ REGION: ${(selectedConstellation.name || reg.name || 'CONSTELLATION').toUpperCase()} ✦`;
    ctx.fillText(titleText, pos.x, tagY);
  }

  ctx.restore();
}

/**
 * Draws constellation region watermark labels.
 */
export function drawConstellationLabels(ctx, width, height, camera, selectedConstellationId = null) {
  const zoom = camera.zoom;

  for (const region of CONSTELLATION_REGIONS) {
    const isSelected =
      selectedConstellationId &&
      (region.id === selectedConstellationId ||
        region.name.toLowerCase() === selectedConstellationId.toLowerCase() ||
        region.label?.toLowerCase() === selectedConstellationId.toLowerCase());

    if (!isSelected && zoom < region.zoomMin) continue;

    const pos = worldToScreen(region.x, region.y, camera, width, height);
    if (pos.x < -100 || pos.x > width + 100 || pos.y < -50 || pos.y > height + 50) {
      continue;
    }

    let alpha = Math.min(0.35, (zoom - region.zoomMin) * 0.4);
    if (isSelected) {
      alpha = 0.95;
    }

    if (alpha <= 0.02) continue;

    ctx.save();
    if (isSelected) {
      ctx.font = '700 13px "Space Grotesk", sans-serif';
      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = 'rgba(56, 189, 248, 0.8)';
      ctx.shadowBlur = 10;
      ctx.textAlign = 'center';
      ctx.letterSpacing = '4px';
      ctx.fillText(`✦ ${region.name} ✦`, pos.x, pos.y);
    } else {
      ctx.font = '600 11px "Space Grotesk", sans-serif';
      ctx.fillStyle = `rgba(148, 163, 184, ${alpha})`;
      ctx.textAlign = 'center';
      ctx.letterSpacing = '3px';
      ctx.fillText(`— ${region.name} —`, pos.x, pos.y);
    }
    ctx.restore();
  }
}

// ============================================================================
// SPECIALIZED CATEGORY DRAWING ROUTINES
// ============================================================================

/**
 * Draws Black Holes: Event Horizon, Doppler Accretion Disk, & Photon Ring
 */
function drawBlackHole(ctx, pos, obj, zoom, isSelected, isHovered, time) {
  const baseR = (obj.baseRadius || 9) * Math.pow(zoom, 0.4);

  ctx.save();
  ctx.translate(pos.x, pos.y);

  // 1. Relativistic Lensing Outer Halo
  const outerHaloR = baseR * (isSelected ? 5.2 : isHovered ? 4.4 : 3.8);
  const haloGrad = ctx.createRadialGradient(0, 0, baseR * 1.2, 0, 0, outerHaloR);
  haloGrad.addColorStop(0, 'rgba(251, 191, 36, 0.35)');
  haloGrad.addColorStop(0.5, 'rgba(245, 158, 11, 0.12)');
  haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.arc(0, 0, outerHaloR, 0, Math.PI * 2);
  ctx.fill();

  // 2. Accretion Disk (Tilted glowing ellipse with Doppler brightening & precession)
  ctx.save();
  const precession = Math.sin(time * 0.0006) * 0.04;
  ctx.rotate(0.35 + precession);
  const diskR = baseR * 2.8;

  const diskGrad = ctx.createRadialGradient(0, 0, baseR * 0.9, 0, 0, diskR);
  diskGrad.addColorStop(0, 'rgba(254, 240, 138, 0.9)'); // Hot inner edge
  diskGrad.addColorStop(0.35, 'rgba(245, 158, 11, 0.7)');
  diskGrad.addColorStop(0.75, 'rgba(239, 68, 68, 0.4)');
  diskGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = diskGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, diskR, diskR * 0.38, 0, 0, Math.PI * 2);
  ctx.fill();

  // Doppler brightening highlight on approaching side (left side)
  const dopplerGrad = ctx.createRadialGradient(-diskR * 0.4, 0, 0, -diskR * 0.4, 0, diskR * 0.7);
  dopplerGrad.addColorStop(0, 'rgba(255, 255, 255, 0.55)');
  dopplerGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = dopplerGrad;
  ctx.beginPath();
  ctx.ellipse(-diskR * 0.4, 0, diskR * 0.6, diskR * 0.28, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();

  // 3. Gravitational Lensing Photon Ring
  ctx.save();
  ctx.strokeStyle = 'rgba(254, 240, 138, 0.85)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(0, 0, baseR * 1.15, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // 4. Pitch-Black Event Horizon (Pure absorption void)
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(0, 0, baseR, 0, Math.PI * 2);
  ctx.fill();

  // Sharp inner shadow rim
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
  ctx.lineWidth = 0.8;
  ctx.stroke();

  ctx.restore();
}

/**
 * Draws Pulsars: Compact Magnetized Core, Rotating Relativistic Radiation Beams & Pulse Rings
 */
function drawPulsar(ctx, pos, obj, zoom, isSelected, isHovered, time) {
  const baseR = (obj.baseRadius || 4) * Math.pow(zoom, 0.4);
  const rot = time * 0.0035;

  ctx.save();
  ctx.translate(pos.x, pos.y);

  // 1. Concentric Magnetic Pulse Waves (Radio emission ripple)
  const pulseR = ((time * 0.03) % 40) + baseR;
  const pulseAlpha = Math.max(0, 1 - pulseR / 45) * 0.4;
  ctx.strokeStyle = `rgba(34, 211, 238, ${pulseAlpha})`;
  ctx.lineWidth = 1;
  ctx.setLineDash([2, 4]);
  ctx.beginPath();
  ctx.arc(0, 0, pulseR, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // 2. Twin Rotating Synchrotron Radiation Beams (Lighthouse effect)
  const beamLength = 45 * Math.pow(zoom, 0.3);
  const beamAngle = 0.35; // Cone spread

  for (let sign = -1; sign <= 1; sign += 2) {
    const angle = rot + (sign === 1 ? 0 : Math.PI);
    ctx.save();
    ctx.rotate(angle);

    const beamGrad = ctx.createRadialGradient(0, 0, baseR, beamLength, 0, beamLength);
    beamGrad.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
    beamGrad.addColorStop(0.3, 'rgba(34, 211, 238, 0.6)');
    beamGrad.addColorStop(0.7, 'rgba(129, 140, 248, 0.2)');
    beamGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = beamGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(beamLength, Math.tan(beamAngle / 2) * beamLength);
    ctx.arc(0, 0, beamLength, beamAngle / 2, -beamAngle / 2, true);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  // 3. Dense Core Atmosphere & White-Hot Center
  const coreGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, baseR * 3);
  coreGlow.addColorStop(0, '#ffffff');
  coreGlow.addColorStop(0.4, '#22d3ee');
  coreGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = coreGlow;
  ctx.beginPath();
  ctx.arc(0, 0, baseR * 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, 0, baseR, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Draws Isolated Neutron Stars: Ultra-Dense Thermal Pinpoint
 */
function drawNeutronStar(ctx, pos, obj, zoom) {
  const baseR = (obj.baseRadius || 3.2) * Math.pow(zoom, 0.35);

  ctx.save();
  // Blistering thermal corona
  const coronaR = baseR * 4;
  const corona = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, coronaR);
  corona.addColorStop(0, 'rgba(192, 132, 252, 0.7)');
  corona.addColorStop(0.4, 'rgba(168, 85, 247, 0.25)');
  corona.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = corona;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, coronaR, 0, Math.PI * 2);
  ctx.fill();

  // Ultra-dense pinpoint core
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, baseR, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Draws Nebulae: Large Diffuse Organic Cloud Regions
 */
function drawNebula(ctx, pos, obj, zoom, isSelected, isHovered, time) {
  const baseR = (obj.baseRadius || 15) * Math.pow(zoom, 0.55);
  const pulse = Math.sin(time * 0.001 + obj.x) * 2;

  ctx.save();

  if (obj.id === 'ring-nebula') {
    // Hollow Donut-shaped Planetary Nebula
    const rOuter = baseR * 2.2 + pulse;
    const rInner = baseR * 0.7;

    const ringGrad = ctx.createRadialGradient(pos.x, pos.y, rInner, pos.x, pos.y, rOuter);
    ringGrad.addColorStop(0, 'rgba(52, 211, 153, 0.1)');
    ringGrad.addColorStop(0.35, 'rgba(52, 211, 153, 0.6)');
    ringGrad.addColorStop(0.7, 'rgba(56, 189, 248, 0.5)');
    ringGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = ringGrad;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, rOuter, 0, Math.PI * 2);
    ctx.fill();

    // Central White Dwarf Remnant
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 1.8, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Diffuse Multi-Lobe Stellar Nursery (Orion, Crab, Carina)
    const cloudR = baseR * 2.5 + pulse;
    const cloudGrad = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, cloudR);
    cloudGrad.addColorStop(0, obj.colorHex || 'rgba(56, 189, 248, 0.5)');
    cloudGrad.addColorStop(0.4, setAlpha(obj.glowColor || 'rgba(56, 189, 248, 0.35)', 0.25));
    cloudGrad.addColorStop(0.75, setAlpha(obj.glowColor || 'rgba(56, 189, 248, 0.15)', 0.08));
    cloudGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = cloudGrad;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, cloudR, 0, Math.PI * 2);
    ctx.fill();

    // Secondary offset cloud lobe for organic interstellar feel
    const lobeX = pos.x + baseR * 0.6;
    const lobeY = pos.y - baseR * 0.4;
    const lobeR = baseR * 1.8;
    const lobeGrad = ctx.createRadialGradient(lobeX, lobeY, 0, lobeX, lobeY, lobeR);
    lobeGrad.addColorStop(0, setAlpha(obj.colorHex || 'rgba(168, 85, 247, 0.3)', 0.3));
    lobeGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = lobeGrad;
    ctx.beginPath();
    ctx.arc(lobeX, lobeY, lobeR, 0, Math.PI * 2);
    ctx.fill();

    // Embedded proto-stars (Trapezium in Orion)
    if (obj.id === 'orion-nebula' && zoom >= 1.4) {
      const protoOffsets = [
        { dx: -2, dy: -2 },
        { dx: 3, dy: -1 },
        { dx: -1, dy: 3 },
        { dx: 2, dy: 2 },
      ];
      ctx.fillStyle = '#ffffff';
      for (const p of protoOffsets) {
        ctx.beginPath();
        ctx.arc(pos.x + p.dx * zoom * 0.6, pos.y + p.dy * zoom * 0.6, 1.6, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  ctx.restore();
}

/**
 * Draws Star Clusters: Collective Luminous Cloud + Embedded Member Stars
 */
function drawCluster(ctx, pos, obj, zoom, isSelected, isHovered, time) {
  const baseR = (obj.baseRadius || 12) * Math.pow(zoom, 0.5);

  ctx.save();

  // 1. Collective Cluster Reflection Cloud
  const clusterHaze = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, baseR * 2.2);
  clusterHaze.addColorStop(0, 'rgba(96, 165, 250, 0.35)');
  clusterHaze.addColorStop(0.5, 'rgba(96, 165, 250, 0.12)');
  clusterHaze.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = clusterHaze;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, baseR * 2.2, 0, Math.PI * 2);
  ctx.fill();

  // 2. Embedded Member Stars
  if (obj.id === 'pleiades') {
    // The Seven Sisters geometry
    const sisters = [
      { dx: 0, dy: -2, r: 2.4 },   // Alcyone
      { dx: -5, dy: 3, r: 2.0 },  // Atlas
      { dx: 6, dy: -1, r: 1.8 },  // Electra
      { dx: -3, dy: -6, r: 1.8 }, // Maia
      { dx: 4, dy: 4, r: 1.7 },   // Merope
      { dx: -8, dy: -2, r: 1.5 }, // Taygeta
      { dx: -7, dy: -6, r: 1.4 }, // Celaeno
    ];

    const starScale = Math.min(1.6, Math.max(0.7, zoom * 0.8));
    for (const s of sisters) {
      const sx = pos.x + s.dx * starScale * 1.5;
      const sy = pos.y + s.dy * starScale * 1.5;

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(sx, sy, s.r * starScale, 0, Math.PI * 2);
      ctx.fill();

      // Mini diffraction on Alcyone
      if (s.r >= 2.2 && zoom >= 1.5) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(sx - 4, sy);
        ctx.lineTo(sx + 4, sy);
        ctx.moveTo(sx, sy - 4);
        ctx.lineTo(sx, sy + 4);
        ctx.stroke();
      }
    }
  } else {
    // Generic Globular / Open cluster sparkles (Hercules, Hyades)
    const count = obj.id === 'hercules-cluster' ? 14 : 9;
    ctx.fillStyle = '#ffffff';
    for (let i = 0; i < count; i++) {
      const angle = (i * 2.39996) + time * 0.0001; // Golden angle
      const dist = (Math.sqrt(i / count) * baseR * 1.3);
      const sx = pos.x + Math.cos(angle) * dist;
      const sy = pos.y + Math.sin(angle) * dist;
      ctx.beginPath();
      ctx.arc(sx, sy, 1.2 + (i % 2) * 0.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

/**
 * Draws Galaxies: Tilted Spiral Discs, Bright Galactic Bulge & Dust Lanes
 */
function drawGalaxy(ctx, pos, obj, zoom, _isSelected, _isHovered, _time) {
  const baseR = (obj.baseRadius || 20) * Math.pow(zoom, 0.55);

  ctx.save();
  ctx.translate(pos.x, pos.y);

  // Tilt galaxy disk (e.g. Andromeda inclined at -35 deg)
  const tilt = obj.id === 'andromeda-galaxy' ? -0.65 : 0.4;
  ctx.rotate(tilt);

  // 1. Outer Spiral Arms Disc
  const discX = baseR * 2.8;
  const discY = baseR * 1.1;

  const armGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, discX);
  armGrad.addColorStop(0, 'rgba(254, 240, 138, 0.8)'); // Core bulge
  armGrad.addColorStop(0.3, obj.glowColor || 'rgba(147, 197, 253, 0.45)');
  armGrad.addColorStop(0.7, 'rgba(99, 102, 241, 0.2)');
  armGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = armGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, discX, discY, 0, 0, Math.PI * 2);
  ctx.fill();

  // 2. Dark Interstellar Dust Lane cutting across disc
  if (zoom >= 1.1) {
    ctx.fillStyle = 'rgba(2, 3, 8, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, discY * 0.2, discX * 0.85, discY * 0.15, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // 3. Dense Galactic Bulge / Core
  const coreGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, baseR * 0.8);
  coreGrad.addColorStop(0, '#ffffff');
  coreGrad.addColorStop(0.5, '#fef08a');
  coreGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
  ctx.fillStyle = coreGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, baseR * 0.8, baseR * 0.6, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Draws Catalog Stars (Main Sequence, Red Giants, Supergiants, Red Dwarfs)
 */
function drawStar(ctx, pos, star, zoom, isSelected, isHovered) {
  const zoomScale = Math.min(1.8, Math.max(0.85, Math.pow(zoom, 0.45)));
  const radius = star.baseRadius * zoomScale;
  const colorHex = star.colorHex || '#ffffff';

  // 1. Outer atmospheric coronal glow
  const isSupergiant = star.sizeClass === 'supergiant' || star.type === 'Supergiant';
  const isGiant = star.sizeClass === 'giant' || star.type === 'Giant';

  const glowMult = isSelected ? 5.5 : isHovered ? 4.5 : isSupergiant ? 4.2 : isGiant ? 3.6 : 3.0;
  const glowRadius = radius * glowMult;

  const glowGrad = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, glowRadius);
  glowGrad.addColorStop(0, star.glowColor || 'rgba(255, 255, 255, 0.5)');
  glowGrad.addColorStop(0.35, setAlpha(star.glowColor || 'rgba(255, 255, 255, 0.15)', 0.15));
  glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, glowRadius, 0, Math.PI * 2);
  ctx.fill();

  // 2. Diffraction spikes on prominent stars or when selected
  if ((star.hasDiffraction && zoom >= 0.9) || isSelected) {
    const spikeLen = radius * (isSelected ? 3.8 : 2.6);
    ctx.strokeStyle = star.glowColor || 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pos.x - spikeLen, pos.y);
    ctx.lineTo(pos.x + spikeLen, pos.y);
    ctx.moveTo(pos.x, pos.y - spikeLen);
    ctx.lineTo(pos.x, pos.y + spikeLen);
    ctx.stroke();
  }

  // 3. Dense core
  const coreGrad = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, radius);
  coreGrad.addColorStop(0, '#ffffff');
  coreGrad.addColorStop(0.65, colorHex);
  coreGrad.addColorStop(1, colorHex);

  ctx.fillStyle = coreGrad;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
  ctx.fill();

  // 4. Companion orbit line (e.g. Sirius B orbiting Sirius)
  if (star.id === 'sirius-b' && zoom >= 2.0) {
    ctx.save();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
    ctx.setLineDash([2, 4]);
    ctx.beginPath();
    ctx.arc(pos.x - 18, pos.y - 12, 22, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

// ============================================================================
// MAIN UNIFIED CELESTIAL OBJECT DISPATCHER
// ============================================================================

/**
 * Draws all celestial objects (Stars, White Dwarfs, Neutron Stars, Pulsars,
 * Black Holes, Nebulae, Clusters, Galaxies) with LOD and category filtering.
 */
export function drawCelestialObjects(
  ctx,
  width,
  height,
  camera,
  objects,
  selectedId,
  hoveredId,
  activeCategoryFilter,
  time,
  selectedConstellationId = null
) {
  const zoom = camera.zoom;

  for (const obj of objects) {
    const pos = worldToScreen(obj.x, obj.y, camera, width, height);

    // Dynamic Frustum Cull Margin based on object type
    const margin = obj.category === CELESTIAL_CATEGORIES.GALAXY || obj.category === CELESTIAL_CATEGORIES.NEBULA
      ? 180
      : 80;

    if (pos.x < -margin || pos.x > width + margin || pos.y < -margin || pos.y > height + margin) {
      continue;
    }

    const isSelected = selectedId === obj.id;
    const isHovered = hoveredId === obj.id;

    // Constellation Member Check
    const isConstellationMember = Boolean(
      selectedConstellationId &&
      (obj.constellation?.toLowerCase() === selectedConstellationId.toLowerCase() ||
        obj.constellation?.toLowerCase().replace(/\s+/g, '-') === selectedConstellationId.toLowerCase() ||
        obj.relatedConstellation?.toLowerCase() === selectedConstellationId.toLowerCase())
    );

    // Filter Emphasis & Dimming
    const matchesFilter =
      !activeCategoryFilter ||
      activeCategoryFilter === 'ALL' ||
      obj.category === activeCategoryFilter;

    // Level-of-Detail Visibility Rules
    const isMajorObject =
      obj.tier === 1 ||
      obj.category === CELESTIAL_CATEGORIES.GALAXY ||
      obj.id === 'orion-nebula' ||
      obj.id === 'pleiades' ||
      obj.id === 'sagittarius-a-star';

    let isVisible = false;
    if (isSelected || isHovered || isConstellationMember || (activeCategoryFilter && activeCategoryFilter !== 'ALL' && matchesFilter)) {
      isVisible = true;
    } else if (zoom < 1.2) {
      // Cosmic View
      isVisible = isMajorObject;
    } else if (zoom < 2.2) {
      // Regional View
      isVisible = isMajorObject || obj.tier <= 2;
    } else {
      // Deep View & Object View
      isVisible = true;
    }

    if (!isVisible) continue;

    // Apply Opacity based on category filter and constellation focus
    ctx.save();
    if (!matchesFilter) {
      ctx.globalAlpha = 0.2; // Subtly dimmed for context
    } else if (selectedConstellationId && !isConstellationMember && !isSelected && !isHovered) {
      ctx.globalAlpha = 0.38; // Dim other stars when a constellation is active
    }

    // If constellation member, draw subtle active pulse beacon aura
    if (isConstellationMember && !isSelected) {
      ctx.save();
      const pulse = 0.75 + Math.sin(time * 3 + pos.x) * 0.25;
      ctx.strokeStyle = `rgba(56, 189, 248, ${0.45 * pulse})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, (obj.baseRadius || 6) * Math.pow(zoom, 0.45) * 2.1, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // Dispatch by category
    switch (obj.category) {
      case CELESTIAL_CATEGORIES.BLACK_HOLE:
        drawBlackHole(ctx, pos, obj, zoom, isSelected, isHovered, time);
        break;

      case CELESTIAL_CATEGORIES.PULSAR:
        drawPulsar(ctx, pos, obj, zoom, isSelected, isHovered, time);
        break;

      case CELESTIAL_CATEGORIES.NEUTRON_STAR:
        drawNeutronStar(ctx, pos, obj, zoom);
        break;

      case CELESTIAL_CATEGORIES.NEBULA:
        drawNebula(ctx, pos, obj, zoom, isSelected, isHovered, time);
        break;

      case CELESTIAL_CATEGORIES.STAR_CLUSTER:
        drawCluster(ctx, pos, obj, zoom, isSelected, isHovered, time);
        break;

      case CELESTIAL_CATEGORIES.GALAXY:
        drawGalaxy(ctx, pos, obj, zoom, isSelected, isHovered, time);
        break;

      case CELESTIAL_CATEGORIES.WHITE_DWARF:
      case CELESTIAL_CATEGORIES.STAR:
      default:
        drawStar(ctx, pos, obj, zoom, isSelected, isHovered);
        break;
    }

    // Object Name & Category Tag Labels (LOD dependent)
    const showLabel =
      isSelected ||
      isHovered ||
      isConstellationMember ||
      (activeCategoryFilter && activeCategoryFilter !== 'ALL' && matchesFilter) ||
      zoom >= 2.0 ||
      (zoom >= 1.2 && obj.tier <= 2) ||
      (zoom < 1.2 && isMajorObject);

    if (showLabel) {
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';

      const baseR = (obj.baseRadius || 6) * Math.pow(zoom, 0.45);
      const labelY = pos.y + baseR + (isHovered || isSelected ? 8 : 6);

      ctx.font = isSelected || isHovered || isConstellationMember
        ? '600 12px "Space Grotesk", sans-serif'
        : '500 11px "Space Grotesk", sans-serif';

      // Drop shadow for crisp readability
      ctx.fillStyle = '#020308';
      ctx.fillText(obj.name, pos.x + 1, labelY + 1);

      ctx.fillStyle = isSelected
        ? '#38bdf8'
        : isHovered
        ? '#ffffff'
        : isConstellationMember
        ? '#38bdf8'
        : obj.category === CELESTIAL_CATEGORIES.BLACK_HOLE
        ? '#fbbf24'
        : obj.category === CELESTIAL_CATEGORIES.PULSAR
        ? '#22d3ee'
        : obj.category === CELESTIAL_CATEGORIES.NEBULA
        ? '#7dd3fc'
        : obj.category === CELESTIAL_CATEGORIES.GALAXY
        ? '#c7d2fe'
        : obj.tier === 1
        ? '#f1f5f9'
        : '#cbd5e1';

      ctx.fillText(obj.name, pos.x, labelY);

      // Sub-label (Subtype or Spectral Tag)
      if (zoom >= 2.0 || isSelected || isHovered) {
        ctx.font = '400 9px "IBM Plex Mono", monospace';
        const subLabelY = labelY + 13;
        const subText = obj.spectralClass || obj.subtype || obj.category;

        ctx.fillStyle = '#020308';
        ctx.fillText(subText, pos.x + 1, subLabelY + 1);
        ctx.fillStyle = isSelected ? '#7dd3fc' : '#94a3b8';
        ctx.fillText(subText, pos.x, subLabelY);
      }

      ctx.restore();
    }

    ctx.restore();
  }
}

/**
 * Draws high-tech scientific telemetry reticle around the selected celestial object.
 */
export function drawSelectionReticle(ctx, width, height, camera, selectedObj, time) {
  if (!selectedObj) return;

  const pos = worldToScreen(selectedObj.x, selectedObj.y, camera, width, height);

  ctx.save();
  const radius = (selectedObj.baseRadius * Math.pow(camera.zoom, 0.45) || 8) + 16;
  const pulse = Math.sin(time * 0.004) * 2;
  const rot = time * 0.001;

  // Outer dashed ring
  const reticleColor =
    selectedObj.category === CELESTIAL_CATEGORIES.BLACK_HOLE
      ? '#f59e0b'
      : selectedObj.category === CELESTIAL_CATEGORIES.PULSAR
      ? '#22d3ee'
      : '#38bdf8';

  ctx.strokeStyle = reticleColor;
  ctx.lineWidth = 1.2;
  ctx.save();
  ctx.translate(pos.x, pos.y);
  ctx.rotate(rot);
  ctx.beginPath();
  ctx.setLineDash([6, 6]);
  ctx.arc(0, 0, radius + pulse, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // 4 Targeting corner brackets
  const bracketSize = 7;
  const bDist = radius + pulse + 4;
  ctx.strokeStyle = reticleColor;
  ctx.lineWidth = 1.5;

  // Top-Left
  ctx.beginPath();
  ctx.moveTo(pos.x - bDist, pos.y - bDist + bracketSize);
  ctx.lineTo(pos.x - bDist, pos.y - bDist);
  ctx.lineTo(pos.x - bDist + bracketSize, pos.y - bDist);
  ctx.stroke();

  // Top-Right
  ctx.beginPath();
  ctx.moveTo(pos.x + bDist - bracketSize, pos.y - bDist);
  ctx.lineTo(pos.x + bDist, pos.y - bDist);
  ctx.lineTo(pos.x + bDist, pos.y - bDist + bracketSize);
  ctx.stroke();

  // Bottom-Left
  ctx.beginPath();
  ctx.moveTo(pos.x - bDist, pos.y + bDist - bracketSize);
  ctx.lineTo(pos.x - bDist, pos.y + bDist);
  ctx.lineTo(pos.x - bDist + bracketSize, pos.y + bDist);
  ctx.stroke();

  // Bottom-Right
  ctx.beginPath();
  ctx.moveTo(pos.x + bDist - bracketSize, pos.y + bDist);
  ctx.lineTo(pos.x + bDist, pos.y + bDist);
  ctx.lineTo(pos.x + bDist, pos.y + bDist - bracketSize);
  ctx.stroke();

  ctx.restore();
}

/**
 * Draws hover indicator ring over object.
 */
export function drawHoverRing(ctx, width, height, camera, hoveredObj) {
  if (!hoveredObj) return;
  const pos = worldToScreen(hoveredObj.x, hoveredObj.y, camera, width, height);

  ctx.save();
  const radius = (hoveredObj.baseRadius * Math.pow(camera.zoom, 0.45) || 6) + 10;
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.setLineDash([3, 3]);
  ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}
