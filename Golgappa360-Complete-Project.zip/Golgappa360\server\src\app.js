// =====================================================================
// Golgappa360 - Express Application Configuration
// =====================================================================

import express from 'express';
import cors from 'cors';
import { getDbStatus } from './config/db.js';

// Phase 3 Route Handlers
import dashboardRoutes from './routes/dashboard.routes.js';
import salesRoutes from './routes/sales.routes.js';
import productsRoutes from './routes/products.routes.js';
import inventoryRoutes from './routes/inventory.routes.js';
import wasteRoutes from './routes/waste.routes.js';
import reportsRoutes from './routes/reports.routes.js';

// Backward compatibility routes
import overviewRoutes from './routes/overview.js';
import menuRoutes from './routes/menu.js';
import settingsRoutes from './routes/settings.js';

import { errorHandler } from './middleware/errorHandler.js';

const app = express();

// Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging in development
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.path.startsWith('/api')) {
      console.log(`[API] ${req.method} ${req.path} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// System Health Check Endpoint (Required: GET /api/health)
app.get('/api/health', (req, res) => {
  const dbStatus = getDbStatus();
  res.json({
    status: 'healthy',
    system: 'Golgappa360 - Golgappa Business Intelligence & Sales Analytics System',
    timestamp: new Date().toISOString(),
    database: {
      connected: dbStatus.isConnected,
      mode: dbStatus.mode,
      activeDataSource: dbStatus.activeDataSource,
      host: dbStatus.config.host,
      port: dbStatus.config.port,
      database: dbStatus.config.database
    }
  });
});

// Phase 3 Canonical REST API Endpoints
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/waste', wasteRoutes);
app.use('/api/reports', reportsRoutes);

// Backward Compatibility Aliases for Phase 1 & 2
app.use('/api/overview', overviewRoutes);
app.use('/api/menu', menuRoutes);
app.use('/api/settings', settingsRoutes);

// Root route
app.get('/', (req, res) => {
  res.send('<h1>Golgappa360 API Server (Phase 3)</h1><p>Visit <a href="/api/health">/api/health</a> for server health status.</p>');
});

// Global Error Handler Middleware
app.use(errorHandler);

export default app;
