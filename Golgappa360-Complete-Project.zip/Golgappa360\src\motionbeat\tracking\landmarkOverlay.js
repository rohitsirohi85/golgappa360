/**
 * LandmarkOverlay
 * High-performance 2D Canvas renderer that draws mirrored cybernetic
 * skeletal connections, glowing joints, pinch arcs, and tracking telemetry.
 */

export const HAND_CONNECTIONS = [
  // Thumb
  [0, 1], [1, 2], [2, 3], [3, 4],
  // Index finger
  [0, 5], [5, 6], [6, 7], [7, 8],
  // Middle finger
  [9, 10], [10, 11], [11, 12],
  // Ring finger
  [13, 14], [14, 15], [15, 16],
  // Pinky finger
  [0, 17], [17, 18], [18, 19], [19, 20],
  // Palm bridges
  [5, 9], [9, 13], [13, 17],
];

export class LandmarkOverlay {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas ? canvas.getContext('2d') : null;
  }

  setCanvas(canvas) {
    this.canvas = canvas;
    this.ctx = canvas ? canvas.getContext('2d') : null;
  }

  clear() {
    if (!this.ctx || !this.canvas) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  draw(trackingData) {
    if (!this.ctx || !this.canvas) return;

    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;

    ctx.clearRect(0, 0, width, height);

    if (!trackingData || !trackingData.hands || trackingData.hands.length === 0) {
      return;
    }

    // Color styles for Hand 0 (Cyan) and Hand 1 (Purple)
    const handStyles = [
      {
        primary: '#06b6d4',
        glow: 'rgba(6, 182, 212, 0.8)',
        secondary: '#22d3ee',
        jointColor: '#ffffff',
        accent: '#38bdf8',
      },
      {
        primary: '#c084fc',
        glow: 'rgba(192, 132, 252, 0.8)',
        secondary: '#e879f9',
        jointColor: '#ffffff',
        accent: '#f43f5e',
      },
    ];

    trackingData.hands.forEach((hand, hIndex) => {
      const style = handStyles[hIndex % handStyles.length];
      const landmarks = hand.landmarks;
      if (!landmarks || landmarks.length < 21) return;

      // Coordinate converter (Mirrored selfie mapping)
      const toScreen = (lm) => ({
        x: (1.0 - lm.x) * width,
        y: lm.y * height,
      });

      // 1. Draw Connecting Bones
      ctx.save();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = style.primary;
      ctx.shadowColor = style.glow;
      ctx.shadowBlur = 8;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      for (const [startIdx, endIdx] of HAND_CONNECTIONS) {
        const p1 = toScreen(landmarks[startIdx]);
        const p2 = toScreen(landmarks[endIdx]);

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
      ctx.restore();

      // 2. Draw Joints (Nodes)
      landmarks.forEach((lm, index) => {
        const pt = toScreen(lm);
        const isFingertip = [4, 8, 12, 16, 20].includes(index);
        const radius = isFingertip ? 4.5 : 2.5;

        ctx.save();
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);

        if (isFingertip) {
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = style.glow;
          ctx.shadowBlur = 10;
          ctx.fill();

          // Outer pulse ring
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, radius + 2.5, 0, Math.PI * 2);
          ctx.strokeStyle = style.primary;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        } else {
          ctx.fillStyle = style.secondary;
          ctx.fill();
        }
        ctx.restore();
      });

      // 3. Pinch Indicator Arc
      const thumbPt = toScreen(landmarks[4]);
      const indexPt = toScreen(landmarks[8]);
      if (hand.isPinching) {
        ctx.save();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#06b6d4';
        ctx.shadowBlur = 16;
        ctx.setLineDash([4, 4]);

        ctx.beginPath();
        ctx.moveTo(thumbPt.x, thumbPt.y);
        ctx.lineTo(indexPt.x, indexPt.y);
        ctx.stroke();

        // Pinch burst ring
        const midX = (thumbPt.x + indexPt.x) * 0.5;
        const midY = (thumbPt.y + indexPt.y) * 0.5;
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.beginPath();
        ctx.arc(midX, midY, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.font = 'bold 9px monospace';
        ctx.fillStyle = '#38bdf8';
        ctx.fillText('PINCH', midX + 8, midY - 6);
        ctx.restore();
      }

      // 4. Palm Telemetry Tag
      const wristPt = toScreen(landmarks[0]);
      ctx.save();
      ctx.font = '10px monospace';
      ctx.fillStyle = style.primary;
      ctx.shadowColor = style.glow;
      ctx.shadowBlur = 4;
      const confidence = Math.round((hand.score || 0.95) * 100);
      const label = `${hand.handedness.toUpperCase()} (${confidence}%)`;
      ctx.fillText(label, wristPt.x - 24, wristPt.y + 18);
      ctx.restore();
    });
  }
}
