import React from 'react';

export const StatusBadge = ({
  status, // 'Available', 'Charging', 'Fault', 'Confirmed', 'Completed', 'Cancelled'
  text,
  size = 'md', // 'sm', 'md'
  showDot = true,
  className = '',
}) => {
  const norm = (status || '').toLowerCase();
  let colorStyle = 'bg-slate-500/15 text-slate-300 border-slate-500/30';
  let dotColor = 'bg-slate-400';

  if (norm.includes('avail') || norm.includes('confirm') || norm.includes('active')) {
    colorStyle = 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 shadow-[0_0_12px_-3px_rgba(16,185,129,0.3)]';
    dotColor = 'bg-emerald-400 animate-pulse';
  } else if (norm.includes('charg') || norm.includes('progress') || norm.includes('blue')) {
    colorStyle = 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30 shadow-[0_0_12px_-3px_rgba(0,229,255,0.3)]';
    dotColor = 'bg-cyan-400 animate-pulse';
  } else if (norm.includes('fault') || norm.includes('cancel') || norm.includes('error')) {
    colorStyle = 'bg-rose-500/15 text-rose-400 border-rose-500/30';
    dotColor = 'bg-rose-400';
  } else if (norm.includes('complete') || norm.includes('done')) {
    colorStyle = 'bg-teal-500/15 text-[#00F5A0] border-[#00F5A0]/30';
    dotColor = 'bg-[#00F5A0]';
  } else if (norm.includes('wait') || norm.includes('pend') || norm.includes('warn')) {
    colorStyle = 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    dotColor = 'bg-amber-400';
  }

  const displayText = text || status;

  return (
    <span
      className={`
        inline-flex items-center gap-1.5 font-medium border rounded-full
        ${size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1'}
        ${colorStyle}
        ${className}
      `}
    >
      {showDot && (
        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${dotColor}`} />
      )}
      <span className="capitalize">{displayText}</span>
    </span>
  );
};
