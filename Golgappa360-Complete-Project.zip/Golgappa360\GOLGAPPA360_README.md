# Golgappa360 — Golgappa Business Intelligence & Sales Analytics System

> **MCA Major Project — Business Intelligence & Data Analytics Capstone**  
> **Target Enterprise:** Local Indian Golgappa / Pani Puri Business Operations (Sharma Ji Golgappa Center)  
> **Tech Stack:** React 19 + Vite, Dark Glassmorphism Tailwind CSS, Node.js + Express, MySQL 8.0, Tableau Desktop/Public, Microsoft Excel  
> **Dataset Scope:** 6 Months Calibrated Synthetic Operations (2026-05-01 to 2026-10-29; 31,938 Orders, ₹17.6L Turnover)

---

## 1. System Overview & Architecture

**Golgappa360** is a full-stack, enterprise-grade business intelligence and analytics platform engineered to help Indian street-food entrepreneurs transition from gut-feel intuition to data-driven operational decision making.

The system tracks:
1. **Sales & Gross Revenue:** Peak commuter rush hours, plate volumes, and payment trends (UPI QR vs. Cash).
2. **Menu Engineering & Margins:** Unit contribution margins, product elasticity, and variety popularity.
3. **Food Waste & Spoilage Auditing:** Daily souring of mint pani, crushed suji puris, and curd spoilage losses.
4. **Inventory Control & Safety Stock:** Raw ingredient balance tracking with automated reorder urgency flags.
5. **Full Executive P&L:** Net turnover, ingredient COGS, stall overhead vouchers, and estimated operating profit.

```
                      ┌────────────────────────────────────────────────────────┐
                      │          React 19 + Vite Dark Glassmorphism UI         │
                      │   (#171717 canvas, rgba glass cards, sage & saffron)   │
                      └───────────────────────────┬────────────────────────────┘
                                                  │ HTTP / JSON API
                                                  ▼
                      ┌────────────────────────────────────────────────────────┐
                      │                 Node.js / Express API                  │
                      │     (Port 5000, 19 Canonical REST Routes & CORS)       │
                      └─────────────┬────────────────────────────┬─────────────┘
                                    │                            │
                    [MySQL Available & Auth'd]       [MySQL Offline / Fallback]
                                    ▼                            ▼
                      ┌───────────────────────────┐┌───────────────────────────┐
                      │       MySQL 8.0 Engine    ││   Synthetic Data Engine   │
                      │  - 3NF Relational Schema  ││  - 6-Month In-Memory Store │
                      │  - Normalized Views (x4)  ││  - Exact Accounting Logic  │
                      │  - Parameterized Queries  ││  - Zero-Config Resilience │
                      └─────────────┬─────────────┘└─────────────┬─────────────┘
                                    │                            │
                                    └──────────────┬─────────────┘
                                                   │
                                                   ▼
                      ┌────────────────────────────────────────────────────────┐
                      │              Tableau & Excel BI Export Tier            │
                      │     6 Verified RFC 4180 CSVs (100% Zero-Variance)      │
                      │    (tableau_sales, products, inventory, daily, exp)    │
                      └────────────────────────────────────────────────────────┘
```

---

## 2. Project Phases & Capabilities

### Phase 1: Dark Glassmorphism UI & Reusable Components
- Deep charcoal canvas (`#171717`), dark grey translucent containers (`rgba(48, 48, 50, 0.88)`), soft glass card borders (`rgba(255, 255, 255, 0.12)`), and backdrop blur.
- Color system: Sage-green primary (`#A7D78A`), saffron orange highlights (`#EAB64B`), warm terracotta alerts (`#D98768`), and clean typography.
- Seven distinct dashboard views: Overview, Sales Analytics, Menu & Margins, Inventory Control, Food Waste Analysis, Reports & Data Hub, and Settings.

### Phase 2: Reproducible Synthetic Dataset & Analytics Layer
- Fixed-seed generator producing a 6-month calibrated operating dataset:
  - `sales.csv`: 31,938 granular orders.
  - `products.csv`: 5 menu varieties with BOM ingredient recipes.
  - `ingredients.csv`: 8 raw materials (puris, aloo, chana, mint, coriander, curd, spices).
  - `inventory_transactions.csv`: 2,391 stock movements (purchases, consumption, waste).
  - `daily_expenses.csv`: 845 stall operating expense vouchers.
- Mathematical invariants enforced across client and server:
  - Net Revenue = Gross Sales − Discounts.
  - COGS = Quantity Plates × Unit Ingredient BOM Cost.
  - Gross Profit = Net Revenue − COGS.
  - Estimated Operating Profit = Gross Profit − Operating Expenses.

### Phase 3: MySQL Relational Schema & Express REST APIs
- 3NF relational schema in [server/sql/schema.sql](file:///D:/antigravty/server/sql/schema.sql) with cascade deletes, check constraints, foreign keys, and 4 pre-aggregated views:
  - `vw_dashboard_kpis`
  - `vw_product_performance`
  - `vw_daily_financial_summary`
  - `vw_inventory_status`
- Master query library in [server/sql/analytics_queries.sql](file:///D:/antigravty/server/sql/analytics_queries.sql) containing **30 pedagogical MySQL 8.0 queries** across 20 MCA curriculum categories.
- Dual-engine Node/Express backend on port 5000 with 19 verified endpoints, query validation middleware (`validateQuery.js`), and safe error handling.

### Phase 4: Tableau Integration, BI Exports & Excel Workflows
- **Six Tableau-Ready RFC 4180 CSV Exports** generated in `tableau/exports/` and served via `/api/reports/export/tableau/:filename`:
  1. `tableau_sales.csv` (Primary Fact, 31,938 rows, 21 cols, 5.57 MB)
  2. `tableau_products.csv` (Dimension Catalog, 5 rows, 10 cols)
  3. `tableau_inventory.csv` (Operational Fact, 2,391 rows, 13 cols)
  4. `tableau_daily_summary.csv` (Aggregated Fact, 182 rows, 17 cols)
  5. `tableau_expenses.csv` (Overhead Fact, 845 rows, 7 cols)
  6. `tableau_data_dictionary.csv` (Semantic Catalog, 54 rows, 8 cols)
- **100% Reconciliation Audit:** Automated script [tableau/validate_tableau_exports.js](file:///D:/antigravty/tableau/validate_tableau_exports.js) confirms exact numerical match across all 15 financial metrics with **zero variance**.
- **Master Documentation Suite:**
  - [tableau/data_model_guide.md](file:///D:/antigravty/tableau/data_model_guide.md): Tableau Relationships architecture, avoiding fan traps and Cartesian explosions.
  - [tableau/calculated_fields.md](file:///D:/antigravty/tableau/calculated_fields.md): 18 validated Tableau formulas with aggregation safeguards.
  - [tableau/dashboard_build_guide.md](file:///D:/antigravty/tableau/dashboard_build_guide.md): Step-by-step build tutorial for 4 interactive dark glassmorphism dashboards.
  - [tableau/excel_workflow_guide.md](file:///D:/antigravty/tableau/excel_workflow_guide.md): Power Query import, Pivot Tables, SUMIFS, and XLOOKUP verification.
  - [tableau/export_validation_report.md](file:///D:/antigravty/tableau/export_validation_report.md): Formal reconciliation sign-off report.

---

## 3. Financial Reconciliation Benchmark (Ground Truth)

All layers of the platform (MySQL, Synthetic Memory Store, REST APIs, Tableau CSVs, and Excel models) produce these audited numbers:

| Financial Metric | Verified Value | Definition & Formula |
|:---|:---:|:---|
| **Operational Days** | 182 days | 2026-05-01 through 2026-10-29 |
| **Sales Orders Count** | 31,938 | Total unique order transactions |
| **Plates Sold Volume** | 47,658 plates | Total portions served |
| **Gross Turnover** | ₹1,765,505.00 | $\sum(\text{plates} \times \text{unit price})$ |
| **Promotional Discounts** | ₹5,540.00 | Direct loyalty discounts |
| **Net Collected Revenue** | ₹1,759,965.00 | Gross Sales − Discounts |
| **Cost of Goods Sold (COGS)** | ₹492,957.90 | $\sum(\text{plates} \times \text{ingredient BOM cost})$ |
| **Gross Profit** | ₹1,267,007.10 | Net Revenue − COGS |
| **Gross Margin %** | 71.99% (72.0%) | Gross Profit ÷ Net Revenue |
| **Total Operating Expenses** | ₹126,540.06 | Rent, utilities, gas, dona packaging, sanitation |
| **Food Waste Cost Loss** | ₹11,626.98 | Crushed puris, sour pani, and fermented curd |
| **Estimated Operating Profit**| ₹1,140,467.04 | Gross Profit − Operating Expenses |
| **Operating Margin %** | 64.80% | Operating Profit ÷ Net Revenue |
| **Average Order Value (AOV)**| ₹55.11 | Net Revenue ÷ Orders Count |
| **Average Selling Price (ASP)**| ₹36.93 | Net Revenue ÷ Plates Sold |

---

## 4. How to Run the Platform

### Prerequisites
- Node.js 18+ (tested on Node v24.14.0)
- MySQL 8.0+ (optional; system automatically runs in high-fidelity fallback if MySQL is unconfigured)

### 1. Start the Backend API Server
```bash
cd d:/antigravty
node server/src/index.js
```
*API will start on `http://localhost:5000`.*  
*Health Check: `http://localhost:5000/api/health`.*

### 2. Start the Frontend Application
```bash
cd d:/antigravty
npm run dev
```
*Vite will launch the dashboard on `http://localhost:5173`.*

### 3. Generate or Re-generate Tableau CSV Exports
```bash
node server/src/scripts/exportTableauData.js
```

### 4. Execute the Tableau Reconciliation Audit
```bash
node tableau/validate_tableau_exports.js
```

### 5. Execute API Endpoint Integration Tests
```bash
node server/test_phase3_endpoints.js
```

---

## 5. Connecting Exports in Tableau Desktop / Public

1. Open Tableau Desktop or Tableau Public.
2. Under **Connect > To a File**, choose **Text file**.
3. Select `tableau/exports/tableau_sales.csv`.
4. Drag `tableau_products.csv` to the canvas to form a **Relationship** on `[product_id] = [product_id]`.
5. Open any worksheet and use the pre-built calculated fields documented in [tableau/calculated_fields.md](file:///D:/antigravty/tableau/calculated_fields.md).
