import React from 'react';
import { ArrowUpRight, Sparkles, CheckCircle2, Shield } from 'lucide-react';
import { ACADEMY_CONFIG } from '../data/danceData';

export const TrialCTA = ({ onOpenTrial }) => {
  return (
    <section
      id="trial"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="Book a Trial Session"
    >
      {/* Centered electric violet radial spotlight */}
      <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#8B5CF6]/15 rounded-full blur-[140px]" />

      <div className="relative z-10 max-w-5xl mx-auto px-5 sm:px-8 text-center">
        
        {/* Editorial Subheader */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#14141B] border border-white/[0.08] mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
          <span className="font-mono text-[11px] font-semibold tracking-wider uppercase text-[#A78BFA]">
            COMPLIMENTARY FIRST SESSION
          </span>
        </div>

        {/* Banner Headline */}
        <h2 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase tracking-tight">
          THE FLOOR <br />
          <span className="text-[#A78BFA]">IS CALLING.</span>
        </h2>

        {/* Narrative */}
        <p className="mt-6 text-base sm:text-lg text-[#A5A1B2] max-w-xl mx-auto font-normal leading-relaxed">
          Step into our 4,200 sq ft sprung timber studio. Feel the sub-bass in the acoustic room, meet the resident faculty, and experience your rhythm without judgment.
        </p>

        {/* Guarantee Pills */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-xs text-[#A5A1B2] font-mono">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B5CF6]" />
            <span>Zero Long-Term Obligation</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B5CF6]" />
            <span>Sprung Timber Joint Protection</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B5CF6]" />
            <span>Foundations to Masterclass Levels</span>
          </div>
        </div>

        {/* Prominent Action Button */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => onOpenTrial()}
            className="group inline-flex items-center justify-center gap-3 px-9 py-5 text-sm font-semibold tracking-widest uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all duration-200 rounded-sm shadow-[0_0_35px_-5px_rgba(139,92,246,0.6)] hover:shadow-[0_0_45px_0_rgba(167,139,250,0.7)] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#8B5CF6] focus-visible:ring-offset-[#0B0B0F]"
          >
            <span>RESERVE YOUR TRIAL PASS</span>
            <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>

        <p className="mt-4 text-[11px] font-mono text-[#A5A1B2] opacity-70">
          Limited to 6 guest trial spots per session to preserve class density.
        </p>
      </div>
    </section>
  );
};
