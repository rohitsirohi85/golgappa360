import React, { useState } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  UtensilsCrossed,
  Boxes,
  Trash2,
  FileSpreadsheet,
  Settings,
  Database,
  Store,
  ChevronRight,
  Flame,
  X,
  Bell,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { useGolgappa } from '../../context/GolgappaContext';

export function Sidebar({ mobileOpen, setMobileOpen }) {
  const {
    activeTab,
    setActiveTab,
    inventoryData,
    wasteData,
    backendOnline,
    dbStatus,
    stallSettings,
    notifications
  } = useGolgappa();

  const [expanded, setExpanded] = useState(false);

  const navItems = [
    {
      id: 'overview',
      label: 'Overview',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'sales',
      label: 'Sales Analytics',
      icon: TrendingUp,
      badge: 'Peak'
    },
    {
      id: 'menu',
      label: 'Products',
      icon: UtensilsCrossed,
      badge: '6'
    },
    {
      id: 'inventory',
      label: 'Inventory',
      icon: Boxes,
      badge: inventoryData?.lowStockCount > 0 ? `${inventoryData.lowStockCount}` : null,
      badgeAlert: inventoryData?.lowStockCount > 0
    },
    {
      id: 'waste',
      label: 'Waste Analysis',
      icon: Trash2,
      badge: '4.8%',
      badgeAlert: false
    },
    {
      id: 'reports',
      label: 'Reports & Data',
      icon: FileSpreadsheet,
      badge: 'CSV'
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      badge: null
    }
  ];

  const handleNavClick = (tabId) => {
    setActiveTab(tabId);
    if (setMobileOpen) setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/80 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar Rail: Translucent dark background matching reference image */}
      <aside
        onMouseEnter={() => setExpanded(true)}
        onMouseLeave={() => setExpanded(false)}
        className={`
          fixed top-0 bottom-0 left-0 z-50
          lg:static lg:my-3 lg:ml-3 lg:h-[calc(100vh-2.5rem)]
          bg-[rgba(20,20,22,0.92)] backdrop-blur-2xl
          border border-white/10 rounded-3xl
          flex flex-col justify-between
          transition-all duration-300 ease-in-out shadow-2xl
          ${expanded ? 'w-64' : 'w-20'}
          ${mobileOpen ? 'translate-x-0 w-64' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Top: Logo Squircle */}
        <div>
          <div className="h-20 flex items-center justify-between px-4 border-b border-white/[0.08]">
            <div className="flex items-center gap-3 overflow-hidden">
              {/* Reference-style squircle logo */}
              <div className="w-11 h-11 rounded-2xl bg-white/[0.08] border border-white/15 flex items-center justify-center shrink-0 shadow-inner group cursor-pointer hover:border-[#A7D78A]/40 transition-colors">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-[#A7D78A] to-[#EAB64B] flex items-center justify-center shadow-xs">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#171717]" />
                </div>
              </div>

              {(expanded || mobileOpen) && (
                <div className="truncate animate-in fade-in duration-200">
                  <h1 className="text-sm font-bold tracking-tight text-[#F5F4F1] font-sans">
                    Golgappa<span className="text-[#A7D78A]">360</span>
                  </h1>
                  <p className="text-[10px] text-[#929195] font-medium tracking-tight">
                    Business Intelligence
                  </p>
                </div>
              )}
            </div>

            {/* Mobile close */}
            {mobileOpen && (
              <button
                onClick={() => setMobileOpen(false)}
                className="lg:hidden p-1.5 rounded-xl text-[#929195] hover:text-white hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Navigation Items (Icon-first vertically stacked) */}
          <nav className="p-3 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  title={!expanded ? item.label : undefined}
                  className={`
                    w-full flex items-center gap-3.5 px-3 py-2.5 rounded-2xl transition-all duration-200 cursor-pointer relative group
                    ${
                      isActive
                        ? 'bg-white/[0.14] text-[#F5F4F1] border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.3)]'
                        : 'text-[#929195] hover:text-[#F5F4F1] hover:bg-white/[0.07]'
                    }
                  `}
                >
                  {/* Subtle active pip */}
                  {isActive && (
                    <span className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-[#EAB64B] shadow-[0_0_8px_#EAB64B]" />
                  )}

                  <div className="w-5 h-5 flex items-center justify-center shrink-0">
                    <Icon
                      className={`w-4.5 h-4.5 transition-colors ${
                        isActive
                          ? 'text-[#A7D78A]'
                          : 'text-[#B8B7B9] group-hover:text-[#F5F4F1]'
                      }`}
                    />
                  </div>

                  {(expanded || mobileOpen) && (
                    <div className="flex-1 flex items-center justify-between min-w-0 text-left animate-in fade-in duration-200">
                      <span className="text-xs font-semibold tracking-tight truncate">
                        {item.label}
                      </span>
                      {item.badge && (
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                            item.badgeAlert
                              ? 'bg-[#EAB64B]/20 text-[#EAB64B] border border-[#EAB64B]/30'
                              : isActive
                              ? 'bg-white/20 text-white'
                              : 'bg-white/10 text-[#929195]'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </div>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Section: Rush hour indicator, Notifications, and Settings */}
        <div className="p-3 border-t border-white/[0.08] space-y-2">
          {/* Rush Hour pill when expanded */}
          {(expanded || mobileOpen) ? (
            <div className="bg-white/[0.05] border border-white/10 rounded-2xl p-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-[#EAB64B] flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-[#EAB64B]" />
                  Evening Rush
                </span>
                <span className="text-[10px] text-[#B8B7B9]">5 - 8:30 PM</span>
              </div>
              <p className="text-[10px] text-[#929195] mt-1 leading-snug line-clamp-1">
                Teekha water at 74% stock
              </p>
            </div>
          ) : (
            <div className="w-full flex justify-center py-1">
              <div className="w-2 h-2 rounded-full bg-[#EAB64B] animate-pulse" title="Evening Rush Window" />
            </div>
          )}

          {/* User / Stall Quick Item */}
          <div
            onClick={() => handleNavClick('settings')}
            className="w-full flex items-center gap-3 p-2 rounded-2xl hover:bg-white/[0.08] transition-colors cursor-pointer"
            title={stallSettings.stallName}
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#193D20] to-[#EAB64B]/40 border border-white/15 flex items-center justify-center font-bold text-xs text-[#F5F4F1] shrink-0 shadow-inner">
              RS
            </div>
            {(expanded || mobileOpen) && (
              <div className="truncate text-left min-w-0 animate-in fade-in duration-200">
                <p className="text-xs font-bold text-[#F5F4F1] truncate">
                  {stallSettings.stallName}
                </p>
                <p className="text-[10px] text-[#929195] truncate">
                  {stallSettings.ownerName}
                </p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}
