import React, { useEffect, useRef, useState, useMemo } from 'react';
import ObjectVisualRenderer from './universe/ObjectVisualRenderer';
import {
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
  CELESTIAL_CATEGORIES,
  getRelatedObjects,
} from '../data/celestialObjects.js';

/**
 * Universal Object Details System (StarModal) — STELLAR 2.0 (Phase U4)
 * 
 * Reusable astronomical observatory dossier supporting all celestial object categories:
 * - Star (Main Sequence, Red Giant, Supergiant, Red Dwarf)
 * - White Dwarf
 * - Neutron Star
 * - Pulsar
 * - Black Hole
 * - Nebula
 * - Star Cluster
 * - Galaxy
 * 
 * Features:
 * - Category-adaptive visual simulation
 * - Breadcrumb navigation (Universe → Category → Object)
 * - Dynamic scientific telemetry grid (only verified known fields)
 * - "Locate on Universe Map" direct camera navigation
 * - "Copy Object Name" clipboard action
 * - Related objects navigation network
 * - Keyboard shortcuts (Escape, Left/Right arrow) & accessible focus trapping
 */
export default function StarModal({
  star,
  object,
  isOpen,
  onClose,
  onPrevious,
  onNext,
  onSelectCompanion,
  onSelectObject,
  onLocateOnMap,
  onExploreEarth,
  onExploreMoon,
  onExploreBlackHole,
  onExploreConstellation,
  onCompare = null,
  currentIndex = 0,
  totalCount = 31,
}) {
  const currentItem = object || star;
  const modalRef = useRef(null);
  const closeButtonRef = useRef(null);
  const [copied, setCopied] = useState(false);

  // Lock body scroll, handle keyboard shortcuts & initial focus
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    if (closeButtonRef.current) {
      closeButtonRef.current.focus();
    }

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft' && onPrevious) {
        onPrevious();
      } else if (e.key === 'ArrowRight' && onNext) {
        onNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose, onPrevious, onNext]);

  // Related objects network lookup
  const relatedObjects = useMemo(() => {
    if (!currentItem) return [];
    return getRelatedObjects(currentItem.id);
  }, [currentItem]);

  // Copy name to clipboard
  const handleCopyName = () => {
    if (!currentItem) return;
    navigator.clipboard.writeText(currentItem.name).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {});
  };

  // Locate on map trigger
  const handleLocateOnMap = () => {
    if (onLocateOnMap) {
      onLocateOnMap(currentItem);
    } else {
      onClose();
      const mapElem = document.getElementById('universe-map');
      if (mapElem) {
        mapElem.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  // Handle switching to a related object
  const handleSwitchObject = (relObj) => {
    if (onSelectObject) {
      onSelectObject(relObj);
    } else if (onSelectCompanion && relObj.companionId) {
      onSelectCompanion(relObj.id);
    }
  };

  if (!isOpen || !currentItem) return null;

  const category = currentItem.category || CELESTIAL_CATEGORIES.STAR;
  const categoryLabel = CATEGORY_LABELS[category] || 'Stars';
  const categorySymbol = CATEGORY_SYMBOLS[category] || '●';
  const isBlackHole = category === CELESTIAL_CATEGORIES.BLACK_HOLE;

  const isPlanet = category === CELESTIAL_CATEGORIES.PLANET;
  const isMoon = currentItem.id === 'moon' || category === CELESTIAL_CATEGORIES.NATURAL_SATELLITE;
  const isEarth = currentItem.id === 'earth';
  const isSolarSystemObject = isPlanet || isMoon || currentItem.isSun || currentItem.id === 'sun';

  // Format counter (e.g. "03 / 46")
  const formattedCurrent = String(currentIndex + 1).padStart(2, '0');
  const formattedTotal = String(totalCount).padStart(2, '0');

  // Build verified scientific telemetry grid
  const telemetry = [];
  if (isMoon) {
    if (currentItem.distanceFromEarth) telemetry.push({ label: 'DIST FROM EARTH', value: currentItem.distanceFromEarth });
    if (currentItem.orbitalPeriod) telemetry.push({ label: 'ORBITAL PERIOD', value: currentItem.orbitalPeriod, highlight: true });
    if (currentItem.gravity) telemetry.push({ label: 'SURFACE GRAVITY', value: currentItem.gravity, highlight: true });
    if (currentItem.temperature) telemetry.push({ label: 'SURFACE TEMP', value: currentItem.temperature, amber: true });
    if (currentItem.radius) telemetry.push({ label: 'MEAN RADIUS', value: currentItem.radius });
    if (currentItem.mass) telemetry.push({ label: 'LUNAR MASS', value: currentItem.mass });
    telemetry.push({ label: 'PARENT BODY', value: 'Earth (Terra)', amber: true });
  } else if (isPlanet) {
    if (currentItem.distanceFromSun) telemetry.push({ label: 'DIST FROM SUN', value: currentItem.distanceFromSun });
    if (currentItem.orbitalPeriod) telemetry.push({ label: 'ORBITAL PERIOD', value: currentItem.orbitalPeriod, highlight: true });
    if (currentItem.rotationPeriod) telemetry.push({ label: 'ROTATION PERIOD', value: currentItem.rotationPeriod });
    if (currentItem.temperature) telemetry.push({ label: 'SURFACE TEMP', value: currentItem.temperature, amber: true });
    if (currentItem.moons !== undefined) telemetry.push({ label: 'KNOWN MOONS', value: String(currentItem.moons), highlight: true });
    if (currentItem.radius) telemetry.push({ label: 'MEAN RADIUS', value: currentItem.radius });
    if (currentItem.mass) telemetry.push({ label: 'PLANETARY MASS', value: currentItem.mass });
    if (currentItem.axialTilt) telemetry.push({ label: 'AXIAL TILT', value: currentItem.axialTilt });
  } else {
    if (currentItem.distance) telemetry.push({ label: 'DISTANCE', value: currentItem.distance });
    if (currentItem.mass) telemetry.push({ label: 'MASS', value: currentItem.mass });
    if (currentItem.hostGalaxy) telemetry.push({ label: 'HOST GALAXY', value: currentItem.hostGalaxy, amber: true });
    if (currentItem.temperature) telemetry.push({ label: 'TEMPERATURE', value: currentItem.temperature, highlight: true });
    if (currentItem.eventHorizonRadius) telemetry.push({ label: 'EVENT HORIZON', value: currentItem.eventHorizonRadius, highlight: true });
    if (currentItem.spinParameter) telemetry.push({ label: 'SPIN PARAMETER', value: currentItem.spinParameter, highlight: true });
    if (currentItem.accretionDiskTemp) telemetry.push({ label: 'ACCRETION TEMP', value: currentItem.accretionDiskTemp, amber: true });
    if (currentItem.radius) telemetry.push({ label: 'RADIUS', value: currentItem.radius });
    if (currentItem.rotationPeriod) telemetry.push({ label: 'ROTATION PERIOD', value: currentItem.rotationPeriod, highlight: true });
    if (currentItem.diameter) telemetry.push({ label: 'SPAN / DIAMETER', value: currentItem.diameter });
    if (currentItem.starCount) telemetry.push({ label: 'STELLAR COUNT', value: currentItem.starCount });
    if (currentItem.age) telemetry.push({ label: 'ESTIMATED AGE', value: currentItem.age });
    if (currentItem.magnitude) telemetry.push({ label: 'APPARENT MAG', value: currentItem.magnitude });
    if (currentItem.constellation || currentItem.relatedConstellation) {
      telemetry.push({
        label: 'CONSTELLATION',
        value: currentItem.constellation || currentItem.relatedConstellation,
        amber: true,
      });
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-object-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 md:p-8 bg-black/80 backdrop-blur-xl animate-in fade-in duration-300 overflow-y-auto"
    >
      {/* Modal Dialog Shell */}
      <div
        ref={modalRef}
        className="relative w-full max-w-5xl my-auto rounded-3xl bg-[#050711]/95 border border-white/10 shadow-[0_25px_70px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[92vh] backdrop-blur-2xl"
      >
        {/* Top Header Bar & Breadcrumb Navigation */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/8 bg-[#020308]/80 backdrop-blur-md z-20">
          <div className="flex items-center gap-2 sm:gap-3 text-xs font-mono">
            {/* Breadcrumb Navigation */}
            <span className="text-slate-500">Universe</span>
            <span className="text-slate-600">/</span>
            {isMoon ? (
              <>
                <span className="text-amber-400/90">Solar System</span>
                <span className="text-slate-600">/</span>
                <span className="text-sky-300">Earth</span>
                <span className="text-slate-600">/</span>
              </>
            ) : isSolarSystemObject ? (
              <>
                <span className="text-amber-400/90">Solar System</span>
                <span className="text-slate-600">/</span>
              </>
            ) : (
              <>
                <span className="text-cyan-400/90">{categoryLabel}</span>
                <span className="text-slate-600">/</span>
              </>
            )}
            <span className="text-white font-semibold truncate max-w-[120px] sm:max-w-none">
              {currentItem.name}
            </span>
          </div>

          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            aria-label="Close celestial object details"
            className="w-9 h-9 rounded-full bg-white/[0.03] border border-white/10 text-slate-300 hover:text-white hover:border-cyan-400/50 hover:bg-white/10 flex items-center justify-center transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 lg:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Visual Simulation & Telemetry Ring */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center relative min-h-[260px] sm:min-h-[340px]">
              {/* Backlight Ambient Glow */}
              <div
                aria-hidden="true"
                className="absolute inset-0 rounded-full blur-[90px] opacity-35 pointer-events-none"
                style={{ backgroundColor: currentItem.colorHex || '#38bdf8' }}
              />

              {/* Dynamic Category Visual Representation */}
              <ObjectVisualRenderer object={currentItem} size="modal" />

              {/* Reticle Telemetry Ring Labels */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-2 sm:gap-3 px-3.5 py-1.5 rounded-full bg-white/[0.03] border border-white/8 text-xs font-mono text-slate-400">
                {currentItem.magnitude && <span>MAG {currentItem.magnitude}</span>}
                {currentItem.magnitude && <span className="text-slate-600">//</span>}
                <span className="text-cyan-300">
                  {currentItem.spectralClass || currentItem.subtype || categoryLabel}
                </span>
                <span className="text-slate-600">//</span>
                <span>{currentItem.constellation || currentItem.relatedConstellation || 'Deep Space'}</span>
              </div>

              {/* Scientific Simulation Disclaimer */}
              <p className="mt-3 text-[10px] font-mono text-slate-500 text-center tracking-tight">
                Scientific visualization — not to physical scale.
              </p>
            </div>

            {/* Right Column: Information Hierarchy & Actions */}
            <div className="lg:col-span-7 flex flex-col text-left">
              {/* 1. Header Information & Actions */}
              <div>
                <div className="flex flex-wrap items-baseline justify-between gap-3 mb-1">
                  <h2
                    id="modal-object-title"
                    className="font-display text-4xl sm:text-5xl font-semibold tracking-tight text-white"
                  >
                    {currentItem.name}
                  </h2>
                </div>

                {currentItem.commonName && (
                  <p className="text-sm sm:text-base font-sans tracking-wide text-amber-300/90 font-medium mb-3">
                    “{currentItem.commonName}”
                  </p>
                )}

                {/* Category, Subtype & Actions Bar */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Category Pill with Symbol */}
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 font-mono text-xs uppercase tracking-wider">
                    <span className="font-bold">{categorySymbol}</span>
                    <span>{currentItem.subtype || categoryLabel}</span>
                  </span>

                  {currentItem.systemName && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/35 text-amber-300 font-mono text-xs tracking-wider">
                      <span>✦</span>
                      <span>{currentItem.systemRelationship || currentItem.systemName.toUpperCase()}</span>
                    </span>
                  )}

                  {/* Locate on Universe Map Action Button */}
                  <button
                    type="button"
                    onClick={handleLocateOnMap}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-400/60 text-cyan-200 text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.25)] group"
                    title={`Locate ${currentItem.name} on the interactive map`}
                  >
                    <span className="text-cyan-400 text-sm leading-none">◎</span>
                    <span className="group-hover:text-white">
                      {isMoon ? 'View Moon' : isPlanet ? 'View in Solar System' : 'Locate on Map'}
                    </span>
                    <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform">↗</span>
                  </button>

                  {/* Constellation Region Exploration Button */}
                  {(currentItem.constellation || currentItem.relatedConstellation) &&
                    currentItem.constellation !== 'Solar System' &&
                    onExploreConstellation && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onExploreConstellation(currentItem.constellation || currentItem.relatedConstellation);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.2)] group"
                        title={`Explore ${currentItem.constellation || currentItem.relatedConstellation} constellation region on the interactive map`}
                      >
                        <span className="text-cyan-400 text-sm leading-none">✨</span>
                        <span className="group-hover:text-white">
                          Constellation: {currentItem.constellation || currentItem.relatedConstellation}
                        </span>
                        <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform">↗</span>
                      </button>
                    )}

                  {/* Cosmic Compare Action (Phase U12) */}
                  {onCompare && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onCompare(currentItem);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/70 hover:bg-purple-900/80 border border-purple-400/60 text-purple-200 text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_12px_rgba(168,85,247,0.25)] group"
                      title={`Compare ${currentItem.name} with another celestial target`}
                    >
                      <span className="text-purple-400 text-sm leading-none">⚖️</span>
                      <span className="group-hover:text-white">Compare</span>
                      <span className="text-purple-400 group-hover:translate-x-0.5 transition-transform">↗</span>
                    </button>
                  )}

                  {/* Copy Object Name Button */}
                  <button
                    type="button"
                    onClick={handleCopyName}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer"
                    title="Copy celestial object name"
                  >
                    <span>{copied ? '✓' : '⧉'}</span>
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Earth Exploration Banner & Direct Action */}
              {isEarth && onExploreEarth && (
                <div className="mt-4 p-3 rounded-xl bg-cyan-950/50 border border-cyan-400/50 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-cyan-200 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="font-semibold uppercase tracking-wider text-cyan-300">
                      Earth & Moon System (Phase U6)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onExploreEarth();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-400 to-sky-300 hover:from-cyan-300 hover:to-sky-200 text-cyan-950 font-sans font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(34,211,238,0.3)] cursor-pointer"
                  >
                    Explore Earth →
                  </button>
                </div>
              )}

              {/* Moon Exploration Banner & Direct Action */}
              {isMoon && onExploreMoon && (
                <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-400/40 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-200 shadow-[0_0_20px_rgba(226,232,240,0.15)]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                    <span className="font-semibold uppercase tracking-wider text-white">
                      Luna Lunar Observatory (Phase U6)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onExploreMoon();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-slate-200 via-slate-300 to-zinc-300 hover:from-white hover:to-slate-200 text-slate-950 font-sans font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(226,232,240,0.3)] cursor-pointer"
                  >
                    Explore Moon →
                  </button>
                </div>
              )}

              {/* Black Hole Exploration Banner & Direct Action (Phase U7) */}
              {isBlackHole && (
                <div className="mt-4 p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-amber-200 shadow-[0_0_20px_rgba(245,158,11,0.2)]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span className="font-semibold uppercase tracking-wider text-amber-300">
                      Black Hole Simulation (Phase U7)
                    </span>
                  </div>
                  {onExploreBlackHole && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onExploreBlackHole(currentItem);
                      }}
                      className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 hover:from-amber-300 hover:to-orange-300 text-amber-950 font-sans font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(245,158,11,0.35)] cursor-pointer"
                    >
                      🕳️ Explore Black Hole →
                    </button>
                  )}
                </div>
              )}

              {/* Horizontal Divider */}
              <div className="h-[1px] bg-white/10 my-5" />

              {/* 2. Key Information / Telemetry Grid */}
              {telemetry.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3 p-4 rounded-2xl bg-[#020308]/60 border border-white/8">
                  {telemetry.map((t) => (
                    <div key={t.label} className="p-2">
                      <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1 truncate">
                        {t.label}
                      </div>
                      <div
                        className={`text-xs sm:text-sm font-mono font-medium truncate ${
                          t.highlight
                            ? 'text-cyan-300'
                            : t.amber
                            ? 'text-amber-300'
                            : 'text-white'
                        }`}
                      >
                        {t.value}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Horizontal Divider */}
              <div className="h-[1px] bg-white/8 my-5" />

              {/* 3. Scientific Description Narrative */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-[0.2em] text-cyan-400 mb-2 font-semibold">
                  ABOUT THIS CELESTIAL TARGET
                </h4>
                <p className="text-sm sm:text-base font-sans text-slate-300 leading-relaxed font-normal">
                  {currentItem.description}
                </p>
              </div>

              {/* 4. DID YOU KNOW? Fact Card */}
              {currentItem.interestingFact && (
                <div className="mt-5 p-4 rounded-xl bg-amber-500/[0.04] border border-amber-500/20">
                  <div className="flex items-center gap-2 mb-1.5 text-xs font-mono uppercase tracking-widest text-amber-300 font-semibold">
                    <span>✦</span>
                    <span>DID YOU KNOW?</span>
                  </div>
                  <p className="text-xs sm:text-sm font-sans text-amber-200/90 leading-relaxed">
                    {currentItem.interestingFact}
                  </p>
                </div>
              )}

              {/* 5. RELATED CELESTIAL OBJECTS */}
              {relatedObjects.length > 0 && (
                <div className="mt-5 pt-5 border-t border-white/8">
                  <h4 className="text-[11px] font-mono uppercase tracking-[0.2em] text-slate-400 mb-2.5 font-semibold flex items-center gap-1.5">
                    <span>🔗 RELATED OBJECTS & CORRIDORS</span>
                  </h4>
                  <div className="flex flex-wrap items-center gap-2">
                    {relatedObjects.map((rel) => {
                      const relSymbol = CATEGORY_SYMBOLS[rel.category] || '●';
                      return (
                        <button
                          key={rel.id}
                          type="button"
                          onClick={() => handleSwitchObject(rel)}
                          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.03] hover:bg-cyan-950/40 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-300 hover:text-cyan-200 transition-all cursor-pointer group shadow-sm"
                          title={`Explore related target ${rel.name}`}
                        >
                          <span style={{ color: rel.colorHex || '#38bdf8' }} className="font-bold">
                            {relSymbol}
                          </span>
                          <span className="font-semibold text-white group-hover:text-cyan-200">
                            {rel.name}
                          </span>
                          <span className="text-[10px] text-slate-500 group-hover:text-cyan-400">
                            ({rel.subtype || rel.type || rel.category})
                          </span>
                          <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform text-xs">
                            →
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Navigation Footer */}
        <div className="px-6 py-4 border-t border-white/8 bg-[#020308]/80 backdrop-blur-md flex items-center justify-between z-20">
          {/* Previous Target Button */}
          {onPrevious ? (
            <button
              type="button"
              onClick={onPrevious}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/[0.03] border border-white/10 text-xs sm:text-sm font-mono text-slate-300 hover:text-white hover:border-cyan-400/50 hover:bg-white/10 transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
            >
              <span>←</span>
              <span>Previous Target</span>
            </button>
          ) : (
            <div />
          )}

          {/* Formatted Counter */}
          <div className="flex items-center gap-2 font-mono text-xs sm:text-sm tracking-widest text-slate-300 px-3.5 py-1.5 rounded-full bg-white/[0.03] border border-white/10">
            <span className="text-cyan-300 font-semibold">{formattedCurrent}</span>
            <span className="text-slate-500">/</span>
            <span>{formattedTotal}</span>
          </div>

          {/* Next Target Button */}
          {onNext ? (
            <button
              type="button"
              onClick={onNext}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/[0.03] border border-white/10 text-xs sm:text-sm font-mono text-slate-300 hover:text-white hover:border-cyan-400/50 hover:bg-white/10 transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
            >
              <span>Next Target</span>
              <span>→</span>
            </button>
          ) : (
            <div />
          )}
        </div>
      </div>
    </div>
  );
}

// Named alias for clean architecture imports
export { StarModal as UniversalObjectDetails };
