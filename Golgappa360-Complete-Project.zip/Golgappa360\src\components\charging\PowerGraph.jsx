import React, { useState } from 'react';
import { Activity, Gauge, Thermometer } from 'lucide-react';

export const PowerGraph = ({
  pointsData = [],
  data = [
    { time: '00:00', power: 0.0, current: 0.0, temperature: 28 },
    { time: '05:00', power: 2.15, current: 9.4, temperature: 30 },
    { time: '10:00', power: 2.24, current: 9.6, temperature: 32 },
    { time: '15:00', power: 2.25, current: 9.65, temperature: 34 },
    { time: '20:00', power: 2.22, current: 9.55, temperature: 35 },
    { time: '25:00', power: 2.23, current: 9.6, temperature: 36 },
    { time: '30:00', power: 2.24, current: 9.65, temperature: 37 },
  ],
}) => {
  const [activeTab, setActiveTab] = useState('power'); // 'power' | 'current' | 'temperature'

  // Use dynamic real-time pointsData if provided, else fallback to data
  const rawList = Array.isArray(pointsData) && pointsData.length >= 2 
    ? pointsData 
    : (Array.isArray(data) && data.length > 0 ? data : []);
  // Keep fallback points if rawList is empty
  const safeList = rawList.length > 0 ? rawList : [
    { time: '00:00', power: 0.0, current: 0.0, temperature: 28 },
    { time: '05:00', power: 2.15, current: 9.4, temperature: 30 },
  ];
  // Keep last 25 points in memory
  const activeSeries = safeList.slice(-25);

  const [hoveredIndex, setHoveredIndex] = useState(null);

  const height = 135;
  const width = 360;
  const paddingX = 25;
  const paddingY = 22;

  const powerValues = activeSeries.map((d) => (Number(d?.power) || 0) * 1.15);
  const currentValues = activeSeries.map((d) => (Number(d?.current) || 0) * 1.2);
  const tempValues = activeSeries.map((d) => (Number(d?.temperature) || 0) * 1.1);

  // Configuration per tab
  const tabConfig = {
    power: {
      label: 'Power',
      unit: 'kW',
      color: '#00F5A0',
      gradId: 'powerGrad',
      min: 0.0,
      max: Math.max(3.5, ...(powerValues.length > 0 ? powerValues : [0])),
      icon: Activity,
      getValue: (d) => Number(d?.power || 0),
    },
    current: {
      label: 'Current',
      unit: 'A',
      color: '#00E5FF',
      gradId: 'currentGrad',
      min: 0.0,
      max: Math.max(15.0, ...(currentValues.length > 0 ? currentValues : [0])),
      icon: Gauge,
      getValue: (d) => Number(d?.current || 0),
    },
    temperature: {
      label: 'Temperature',
      unit: '°C',
      color: '#FB923C',
      gradId: 'tempGrad',
      min: 20.0,
      max: Math.max(70.0, ...(tempValues.length > 0 ? tempValues : [0])),
      icon: Thermometer,
      getValue: (d) => Number(d?.temperature || 25),
    },
  };

  const currentCfg = tabConfig[activeTab] || tabConfig.power;
  const latestItem = activeSeries[activeSeries.length - 1] || {};
  const displayItem = hoveredIndex !== null && activeSeries[hoveredIndex] ? activeSeries[hoveredIndex] : latestItem;
  const currentValue = currentCfg.getValue(displayItem);

  // Calculate points for SVG path
  const points = activeSeries.map((d, index) => {
    const val = currentCfg.getValue(d);
    const x = paddingX + (index / Math.max(1, activeSeries.length - 1)) * (width - 2 * paddingX);
    const normalizedY = (val - currentCfg.min) / Math.max(0.1, currentCfg.max - currentCfg.min);
    const y = height - paddingY - normalizedY * (height - 2 * paddingY);
    return { ...d, x, y, value: val };
  });

  const pathD = points.reduce((acc, curr, idx) => {
    if (idx === 0) return `M ${curr.x} ${curr.y}`;
    const prev = points[idx - 1];
    const cpX = (prev.x + curr.x) / 2;
    return `${acc} C ${cpX} ${prev.y}, ${cpX} ${curr.y}, ${curr.x} ${curr.y}`;
  }, '');

  const areaD =
    points.length > 0
      ? `${pathD} L ${points[points.length - 1].x} ${height - paddingY} L ${points[0].x} ${height - paddingY} Z`
      : '';

  return (
    <div className="bg-[#0D1527] rounded-2xl p-4 border border-white/10 select-none">
      {/* Header & Metric Selector Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3">
        <div className="flex items-center gap-1.5 p-0.5 rounded-xl bg-black/40 border border-white/5 w-fit">
          <button
            onClick={() => {
              setActiveTab('power');
              setHoveredIndex(null);
            }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
              activeTab === 'power'
                ? 'bg-[#00F5A0]/20 text-[#00F5A0] shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-3 h-3" />
            <span>Power</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('current');
              setHoveredIndex(null);
            }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
              activeTab === 'current'
                ? 'bg-[#00E5FF]/20 text-[#00E5FF] shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Gauge className="w-3 h-3" />
            <span>Current</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('temperature');
              setHoveredIndex(null);
            }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
              activeTab === 'temperature'
                ? 'bg-amber-500/20 text-amber-400 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Thermometer className="w-3 h-3" />
            <span>Temp</span>
          </button>
        </div>

        {/* Current Value readout */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">Live:</span>
          <span
            className="font-mono font-bold text-sm transition-all"
            style={{ color: currentCfg.color }}
          >
            {currentValue.toFixed(1)} {currentCfg.unit}
          </span>
          <span className="text-slate-500 font-mono text-[10px]">
            ({displayItem?.time || 'Now'})
          </span>
        </div>
      </div>

      {/* SVG Live Waveform */}
      <div className="relative w-full">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-32 overflow-visible">
          <defs>
            <linearGradient id={currentCfg.gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={currentCfg.color} stopOpacity="0.32" />
              <stop offset="100%" stopColor={currentCfg.color} stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1={paddingX}
            y1={paddingY}
            x2={width - paddingX}
            y2={paddingY}
            stroke="rgba(255,255,255,0.06)"
            strokeDasharray="4 4"
          />
          <line
            x1={paddingX}
            y1={height / 2}
            x2={width - paddingX}
            y2={height / 2}
            stroke="rgba(255,255,255,0.06)"
            strokeDasharray="4 4"
          />
          <line
            x1={paddingX}
            y1={height - paddingY}
            x2={width - paddingX}
            y2={height - paddingY}
            stroke="rgba(255,255,255,0.12)"
          />

          {/* Area Fill */}
          {areaD && <path d={areaD} fill={`url(#${currentCfg.gradId})`} />}

          {/* Main Line */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke={currentCfg.color}
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          )}

          {/* Interactive Points */}
          {points.map((pt, idx) => (
            <g
              key={idx}
              className="cursor-pointer"
              onMouseEnter={() => setHoveredIndex(idx)}
              onMouseLeave={() => setHoveredIndex(null)}
              onClick={() => setHoveredIndex(idx)}
            >
              <circle
                cx={pt.x}
                cy={pt.y}
                r={hoveredIndex === idx || (!hoveredIndex && idx === points.length - 1) ? 4.5 : 2.5}
                fill={hoveredIndex === idx || (!hoveredIndex && idx === points.length - 1) ? currentCfg.color : '#0D1527'}
                stroke={currentCfg.color}
                strokeWidth="1.8"
                className="transition-all duration-150"
              />
            </g>
          ))}
        </svg>

        {/* X Axis Time Labels */}
        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1 px-1">
          <span>{activeSeries[0]?.time || '00:00'}</span>
          <span>{activeSeries[Math.floor(activeSeries.length / 2)]?.time || 'Rolling'}</span>
          <span>{activeSeries[activeSeries.length - 1]?.time || 'Now'} (Live)</span>
        </div>
      </div>
    </div>
  );
};
