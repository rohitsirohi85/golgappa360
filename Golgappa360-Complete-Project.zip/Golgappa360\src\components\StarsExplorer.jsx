import React, { useState, useMemo } from 'react';
import SectionHeading from './SectionHeading';
import StarCard from './StarCard';
import StarModal from './StarModal';
import StarStats from './StarStats';
import StarEmptyState from './StarEmptyState';
import {
  STARS_DATA,
  STAR_TYPES,
  CONSTELLATIONS,
  getDynamicMetrics,
} from '../data/stars';

/**
 * StarsExplorer — Interactive astronomical observatory catalog
 * Quality refined in Phase 2.5:
 * - Dynamic counts directly computed from dataset
 * - Advanced multi-criteria search (name, common moniker, system, constellation, type, spectralClass)
 * - Clear button & Escape key integration in search input
 * - Synchronized type + constellation filters
 * - Conditional "Reset Filters" action only visible when active filters exist
 * - Equal height card grid with normalized typography hierarchy
 * - Detailed observation panel modal
 */
export default function StarsExplorer({ externalSelectedStar = null, onClearExternalStar }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedConstellation, setSelectedConstellation] = useState('All Constellations');
  const [selectedStar, setSelectedStar] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [prevExternalStar, setPrevExternalStar] = useState(externalSelectedStar);

  // Synchronize when an external star inspection is triggered from Star Types
  if (externalSelectedStar !== prevExternalStar) {
    setPrevExternalStar(externalSelectedStar);
    if (externalSelectedStar) {
      setSelectedStar(externalSelectedStar);
      setIsModalOpen(true);
    }
  }

  // Dynamic system metrics computed directly from dataset (never hardcoded)
  const metrics = useMemo(() => getDynamicMetrics(STARS_DATA), []);

  // Is any filter or search active?
  const isFilterActive = useMemo(() => {
    return (
      searchQuery.trim() !== '' ||
      selectedType !== 'All' ||
      selectedConstellation !== 'All Constellations'
    );
  }, [searchQuery, selectedType, selectedConstellation]);

  // Compute filtered star list
  const filteredStars = useMemo(() => {
    return STARS_DATA.filter((star) => {
      // 1. Star Type Filter
      if (selectedType !== 'All' && star.type !== selectedType) {
        return false;
      }

      // 2. Constellation Filter
      if (
        selectedConstellation !== 'All Constellations' &&
        star.constellation !== selectedConstellation
      ) {
        return false;
      }

      // 3. Search query filter (Case-insensitive, supports partial names & common names)
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = star.name.toLowerCase().includes(query);
        const matchesCommon = star.commonName?.toLowerCase().includes(query) || false;
        const matchesSystem = star.systemName?.toLowerCase().includes(query) || false;
        const matchesConstellation = star.constellation.toLowerCase().includes(query);
        const matchesType = star.type.toLowerCase().includes(query);
        const matchesSpectral = star.spectralClass.toLowerCase().includes(query);

        return (
          matchesName ||
          matchesCommon ||
          matchesSystem ||
          matchesConstellation ||
          matchesType ||
          matchesSpectral
        );
      }

      return true;
    });
  }, [searchQuery, selectedType, selectedConstellation]);

  // Current modal index in filtered dataset
  const currentModalIndex = useMemo(() => {
    if (!selectedStar) return 0;
    const index = filteredStars.findIndex((s) => s.id === selectedStar.id);
    return index !== -1 ? index : 0;
  }, [selectedStar, filteredStars]);

  const handleOpenModal = (star) => {
    setSelectedStar(star);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    if (onClearExternalStar) onClearExternalStar();
  };

  const handlePreviousStar = () => {
    if (filteredStars.length <= 1) return;
    const prevIndex = (currentModalIndex - 1 + filteredStars.length) % filteredStars.length;
    setSelectedStar(filteredStars[prevIndex]);
  };

  const handleNextStar = () => {
    if (filteredStars.length <= 1) return;
    const nextIndex = (currentModalIndex + 1) % filteredStars.length;
    setSelectedStar(filteredStars[nextIndex]);
  };

  const handleSelectCompanion = (companionId) => {
    const companion = STARS_DATA.find((s) => s.id === companionId);
    if (companion) {
      setSelectedStar(companion);
    }
  };

  const handleSelectObject = (obj) => {
    if (obj) {
      setSelectedStar(obj);
    }
  };

  const handleLocateOnMap = (obj) => {
    setIsModalOpen(false);
    const universeSection = document.getElementById('universe-map');
    if (universeSection) {
      universeSection.scrollIntoView({ behavior: 'smooth' });
    }
    window.dispatchEvent(new CustomEvent('stellar:locate-object', { detail: obj }));
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedType('All');
    setSelectedConstellation('All Constellations');
  };

  return (
    <section
      id="stars"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Anchor alias so any link to #explore-stars works seamlessly */}
      <div id="explore-stars" className="absolute top-0 pointer-events-none" />

      {/* Atmospheric Background Nebulae */}
      <div
        aria-hidden="true"
        className="absolute top-1/4 -left-40 w-[600px] h-[600px] rounded-full bg-indigo-950/20 blur-[140px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-10 right-0 w-[550px] h-[550px] rounded-full bg-cyan-950/25 blur-[140px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <SectionHeading
            eyebrow="STELLAR CATALOG"
            title="MEET THE STARS"
            subtitle="Explore remarkable stars across the night sky — from nearby stellar neighbors to enormous supergiants."
            align="center"
          />
        </div>

        {/* Dynamic Observatory Statistics Strip */}
        <div className="mb-12">
          <StarStats
            catalogCount={metrics.catalogCount}
            typesCount={metrics.starTypesCount}
            constellationsCount={metrics.constellationsCount}
            classesCount={metrics.spectralClassesCount}
          />
        </div>

        {/* Search & Filter Controls Panel */}
        <div className="mb-10 sm:mb-12 space-y-4 sm:space-y-6">
          {/* Top Controls: Search Input + Constellation Dropdown */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            {/* Search Input Bar (Enhanced with focus glow, clear button, and ESC support) */}
            <div className="relative flex-1 max-w-xl group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-cyan-400 transition-colors">
                <svg
                  className="w-5 h-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>

              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setSearchQuery('');
                }}
                placeholder="Search a star..."
                className="w-full pl-11 pr-10 py-3.5 rounded-2xl glass-surface text-sm sm:text-base text-white placeholder-slate-400/70 border border-white/10 focus:border-cyan-400/60 focus:bg-slate-900/80 focus:shadow-[0_0_25px_rgba(56,189,248,0.25)] focus:outline-none transition-all"
              />

              {/* Clear button when query exists */}
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  aria-label="Clear search input"
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>

            {/* Constellation Filter Dropdown */}
            <div className="flex items-center gap-3">
              <label
                htmlFor="constellation-select"
                className="text-xs font-mono text-slate-400 uppercase tracking-wider whitespace-nowrap hidden sm:inline"
              >
                CONSTELLATION:
              </label>
              <div className="relative min-w-[210px] w-full sm:w-auto">
                <select
                  id="constellation-select"
                  value={selectedConstellation}
                  onChange={(e) => setSelectedConstellation(e.target.value)}
                  className="w-full appearance-none pl-4 pr-10 py-3.5 rounded-2xl glass-surface text-xs sm:text-sm text-slate-200 border border-white/10 focus:border-cyan-400/60 focus:outline-none focus:shadow-[0_0_20px_rgba(56,189,248,0.2)] transition-all cursor-pointer bg-slate-950/80"
                >
                  {CONSTELLATIONS.map((c) => (
                    <option key={c} value={c} className="bg-slate-950 text-slate-200">
                      {c}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Star Type Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar select-none">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-widest mr-2 hidden md:inline">
              TYPE:
            </span>
            {STAR_TYPES.map((type) => {
              const isActive = selectedType === type;
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => setSelectedType(type)}
                  className={`px-4 py-2 rounded-full text-xs font-mono tracking-wider transition-all duration-200 whitespace-nowrap cursor-pointer select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/60 shadow-[0_0_15px_rgba(56,189,248,0.3)] font-semibold'
                      : 'glass-surface text-slate-400 hover:text-white hover:border-white/20 hover:bg-white/5 border border-white/10'
                  }`}
                >
                  {type}
                </button>
              );
            })}
          </div>

          {/* Dynamic Result Counter & Conditional Reset Filters Action */}
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1 pt-1">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>
                SHOWING <strong className="text-white">{filteredStars.length}</strong> OF{' '}
                <strong className="text-white">{metrics.catalogCount}</strong> STARS
              </span>
            </div>

            {/* Display Reset Filters ONLY when search or filter is active */}
            {isFilterActive && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 underline underline-offset-4 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
              >
                <span>↺</span>
                <span>Reset Filters</span>
              </button>
            )}
          </div>
        </div>

        {/* Stars Grid or Empty State */}
        {filteredStars.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 items-stretch">
            {filteredStars.map((star) => (
              <StarCard
                key={star.id}
                star={star}
                onExplore={handleOpenModal}
              />
            ))}
          </div>
        ) : (
          <StarEmptyState onReset={handleResetFilters} />
        )}
      </div>

      {/* Deep Telemetry Modal */}
      <StarModal
        star={selectedStar}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onPrevious={handlePreviousStar}
        onNext={handleNextStar}
        onSelectCompanion={handleSelectCompanion}
        onSelectObject={handleSelectObject}
        onLocateOnMap={handleLocateOnMap}
        currentIndex={currentModalIndex}
        totalCount={filteredStars.length || metrics.catalogCount}
      />
    </section>
  );
}
