import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Zap,
  Activity,
  Clock,
  Thermometer,
  Gauge,
  Flame,
  Power,
  AlertTriangle,
  Radio,
  Sparkles,
  WifiOff,
  ShieldAlert,
  CheckCircle,
  Wifi,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { StatusBadge } from '../components/common/StatusBadge';
import { MetricCard } from '../components/common/MetricCard';
import { CircularProgress } from '../components/charging/CircularProgress';
import { PowerGraph } from '../components/charging/PowerGraph';
import { ChargingTargetSlider } from '../components/charging/ChargingTargetSlider';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';
import { socketService } from '../services/socketService';
import { sensorService } from '../services/sensorService';

export const LiveChargingScreen = () => {
  const navigate = useNavigate();
  const {
    isCharging,
    chargingSession,
    stopCharging,
    startCharging,
    updateChargingTarget,
    socketStatus,
  } = useEV();
  const { showToast } = useUI();

  const [isStopModalOpen, setIsStopModalOpen] = useState(false);
  const [telemetry, setTelemetry] = useState(null);
  const [chargerStatus, setChargerStatus] = useState(isCharging ? 'charging' : 'available');
  const [lastUpdateTime, setLastUpdateTime] = useState(Date.now());
  const [secondsAgo, setSecondsAgo] = useState(0);
  const [isHardwareOnline, setIsHardwareOnline] = useState(true);
  const [lastSeenSeconds, setLastSeenSeconds] = useState(0);
  const [faultAlert, setFaultAlert] = useState(null);

  // Real-time rolling chart history
  const [chartSeries, setChartSeries] = useState([
    { time: '00:00', power: 0.0, current: 0.0, temperature: 28 },
    { time: '05:00', power: 2.15, current: 9.4, temperature: 30 },
    { time: '10:00', power: 2.22, current: 9.6, temperature: 32 },
    { time: '15:00', power: 2.24, current: 9.62, temperature: 34 },
    { time: '20:00', power: 2.23, current: 9.6, temperature: 35 },
  ]);

  const chargerId = chargingSession?.chargerId || 'CH-01';

  // Format seconds to mm:ss
  const formatTime = (totalSeconds) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const getClockString = () => {
    const d = new Date();
    return `${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
  };

  // 1. Subscribe to Real-Time Socket.IO Events for this Charger
  useEffect(() => {
    const unsubscribe = socketService.subscribeToCharger(chargerId, {
      onUpdate: (data) => {
        setTelemetry(data);
        setLastUpdateTime(Date.now());
        setSecondsAgo(0);
        setIsHardwareOnline(true);
        if (data.status) setChargerStatus(data.status);

        // Append to rolling chart series
        setChartSeries((prev) => {
          const safePrev = Array.isArray(prev) ? prev : [];
          const newPoint = {
            time: getClockString(),
            power: data.power || 0,
            current: data.current || 0,
            temperature: data.temperature || 25,
          };
          const next = [...safePrev, newPoint];
          return next.slice(-25); // Keep last 25 points in memory
        });
      },
      onStatus: (data) => {
        if (data.status) {
          setChargerStatus(data.status);
          showToast(`Charger ${chargerId} is now ${data.status.toUpperCase()}`, 'info');
        }
      },
      onFault: (fault) => {
        setFaultAlert(fault);
        setChargerStatus('fault');
        showToast(`🚨 Safety Cutoff: ${fault.message}`, 'error');
      },
      onOnline: () => {
        setIsHardwareOnline(true);
        setFaultAlert(null);
        showToast(`🟢 Charger ${chargerId} is now Online`, 'success');
      },
      onOffline: (data) => {
        setIsHardwareOnline(false);
        setChargerStatus('offline');
        setLastSeenSeconds(data.secondsSinceLastSeen || 30);
      },
    });

    return () => {
      unsubscribe();
    };
  }, [chargerId]);

  // 2. Real-Time API Fallback: If socket is disconnected, poll REST API
  useEffect(() => {
    if (socketStatus === 'connected') return;

    const fallbackPoll = async () => {
      try {
        const reading = await sensorService.getLatestReading(chargerId);
        if (reading) {
          setTelemetry(reading);
          setLastUpdateTime(Date.now());
          setIsHardwareOnline(reading.isOnline ?? true);
          if (reading.chargerStatus) setChargerStatus(reading.chargerStatus);
        }
      } catch (err) {
        console.warn('Fallback poll error:', err);
      }
    };

    fallbackPoll();
    const interval = setInterval(fallbackPoll, 3000);
    return () => clearInterval(interval);
  }, [socketStatus, chargerId]);

  // 3. Dynamic "Last updated X seconds ago" ticker
  useEffect(() => {
    const ticker = setInterval(() => {
      const diff = Math.floor((Date.now() - lastUpdateTime) / 1000);
      setSecondsAgo(diff);
    }, 1000);
    return () => clearInterval(ticker);
  }, [lastUpdateTime]);

  // Metrics (Live WebSocket or Fallback)
  const voltage = telemetry?.voltage ?? chargingSession.voltage ?? 233.0;
  const current = telemetry?.current ?? (isCharging ? (chargingSession.current ?? 9.6) : 0.0);
  const power = telemetry?.power ?? (isCharging ? (chargingSession.power ?? 2.24) : 0.0);
  const energy = telemetry?.energy ?? chargingSession.energyDelivered ?? 15.2;
  const temperature = telemetry?.temperature ?? chargingSession.temperature ?? 38.0;
  const batteryPct = telemetry?.batteryPercentage ?? chargingSession.currentBattery ?? 78;

  const isOverheat = temperature > 60.0 || faultAlert !== null;
  const isOffline = !isHardwareOnline || chargerStatus === 'offline' || secondsAgo > 45;

  const handleStopCharging = () => {
    setIsStopModalOpen(false);
    stopCharging();
    showToast('Charging session concluded. Bill generated.', 'success');
    navigate('/charging-complete');
  };

  // Status Badge Helper
  const getDisplayStatusBadge = () => {
    if (faultAlert || isOverheat) return { text: 'Fault', status: 'Fault', color: 'red' };
    if (isOffline) return { text: 'Offline', status: 'Offline', color: 'gray' };
    if (isCharging || chargerStatus === 'charging') return { text: 'Charging', status: 'Charging', color: 'blue' };
    if (chargerStatus === 'reserved') return { text: 'Reserved', status: 'Reserved', color: 'yellow' };
    return { text: 'Available', status: 'Available', color: 'green' };
  };

  const badgeInfo = getDisplayStatusBadge();

  return (
    <div className="flex flex-col min-h-full pb-6 select-none bg-gradient-to-b from-[#060B18] via-[#070D20] to-[#040813]">
      {/* Header with Real-Time Charger Status */}
      <Header
        title={chargingSession?.chargerName || 'Charger 01'}
        subtitle={chargingSession?.stationName || 'Green Valley EV Hub'}
        rightAction={
          <StatusBadge
            status={badgeInfo.status}
            text={badgeInfo.text}
          />
        }
      />

      <div className="px-4 py-3 space-y-4">
        {/* Real-time Socket Connection Status Bar (Requirement 25) */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-[#0D1527] border border-white/10 text-xs">
          <div className="flex items-center gap-2">
            {socketStatus === 'connected' ? (
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px]">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block -ml-3.5" />
                🟢 LIVE
              </span>
            ) : socketStatus === 'reconnecting' ? (
              <span className="flex items-center gap-1.5 text-amber-400 font-semibold text-[11px]">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                🟡 Reconnecting...
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-rose-400 font-semibold text-[11px]">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                🔴 OFFLINE
              </span>
            )}

            <span className="text-slate-400 text-[11px]">
              • {isOffline ? 'Hardware disconnected' : 'Continuous stream active'}
            </span>
          </div>

          <span className="text-slate-400 font-mono text-[10px]">
            Last updated: {secondsAgo <= 1 ? '1 second ago' : `${secondsAgo} seconds ago`}
          </span>
        </div>

        {/* Real-Time Fallback Mode Alert (Requirement 24) */}
        {socketStatus !== 'connected' && (
          <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300">
            <Wifi className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
            <span>🟡 Realtime connection unavailable • Fallback polling active</span>
          </div>
        )}

        {/* Offline Warning Banner (Requirement 15) */}
        {isOffline && (
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300">
            <WifiOff className="w-5 h-5 text-rose-400 shrink-0" />
            <div className="text-xs">
              <span className="font-bold block">🔴 Charger Offline</span>
              <span className="text-rose-200/80 text-[11px]">
                ESP32 controller disconnected. Last seen {lastSeenSeconds || secondsAgo}s ago. Telemetry stream paused.
              </span>
            </div>
          </div>
        )}

        {/* Safety Over-Temperature Alert Banner (Requirement 12 & 13) */}
        {isOverheat && (
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-rose-600/25 border border-rose-500/50 text-rose-200 animate-pulse">
            <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0" />
            <div className="text-xs">
              <span className="font-bold block text-sm">⚠️ Charging Stopped</span>
              <span className="text-rose-200/90 text-[11px]">
                High temperature detected ({temperature}°C &gt; 60°C). Relay hardware shutdown executed automatically.
              </span>
            </div>
          </div>
        )}

        {/* Hero Battery Gauge with Smooth Real-time Progress (Requirement 8) */}
        <div className="flex flex-col items-center justify-center pt-1">
          <CircularProgress
            percentage={Math.round(batteryPct)}
            targetPercentage={chargingSession.targetBattery || 80}
            power={power}
            isCharging={isCharging && !isOffline && !isOverheat}
            size={220}
          />
        </div>

        {/* Charging Time & Estimated Remaining Row */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-[#0D1527] rounded-2xl p-3 border border-white/10 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/5 text-slate-300">
              <Clock className="w-4 h-4 text-[#00F5A0]" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-semibold">
                Charging Time
              </span>
              <span className="text-base font-bold font-mono text-white">
                {formatTime(chargingSession.chargingTimeSec || 1935)}
              </span>
            </div>
          </div>

          <div className="bg-[#0D1527] rounded-2xl p-3 border border-white/10 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/5 text-slate-300">
              <Sparkles className="w-4 h-4 text-[#00E5FF]" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-semibold">
                Estimated Remaining
              </span>
              <span className="text-base font-bold font-mono text-[#00E5FF]">
                {chargingSession.estimatedRemainingMin || 18} min
              </span>
            </div>
          </div>
        </div>

        {/* Real-time Sensor Metrics Grid (Requirement 2 & 6) */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Real-Time Sensor Telemetry
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Continuous Stream</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <MetricCard
              label="Grid Voltage"
              value={voltage}
              unit="V"
              icon={Zap}
              color="cyan"
              trend="230V AC Single Phase"
            />

            <MetricCard
              label="Current Draw"
              value={current}
              unit="A"
              icon={Gauge}
              color="default"
              trend={isCharging ? 'Active Load' : 'Zero Flow'}
            />

            <MetricCard
              label="Active Power"
              value={power}
              unit="kW"
              icon={Activity}
              color="primary"
              trend="Instantaneous P = V × I"
            />

            <MetricCard
              label="Energy Delivered"
              value={typeof energy === 'number' ? energy.toFixed(2) : energy}
              unit="kWh"
              icon={Flame}
              color="warning"
              trend={`Est: ₹${Math.round((Number(energy) || 0) * (chargingSession.ratePerKwh || 10))}`}
            />
          </div>

          {/* Temperature Row */}
          <div className="mt-2.5 flex items-center justify-between p-3 rounded-2xl bg-[#0D1527] border border-white/10 text-xs">
            <div className="flex items-center gap-2">
              <Thermometer className={`w-4 h-4 ${isOverheat ? 'text-rose-400 animate-bounce' : 'text-emerald-400'}`} />
              <span className="text-slate-300 font-medium">Pack & Cable Temperature</span>
            </div>
            <span className="font-mono font-bold text-white text-sm">
              {temperature}°C{' '}
              <span className={isOverheat ? 'text-rose-400 text-xs font-normal' : 'text-emerald-400 text-xs font-normal'}>
                {isOverheat ? '(OVERHEAT TRIP)' : '(Normal)'}
              </span>
            </span>
          </div>
        </div>

        {/* Real-Time Live Multi-Metric Chart with Tabs (Requirement 7) */}
        <div>
          <PowerGraph pointsData={chartSeries} />
        </div>

        {/* Charging Target Slider (20% to 100%) */}
        <div>
          <ChargingTargetSlider
            target={chargingSession.targetBattery || 80}
            onChange={(val) => {
              updateChargingTarget(val);
              showToast(`Target set to ${val}%`, 'info');
            }}
          />
        </div>

        {/* Start / Stop Charging Command Buttons (Requirement 10 & 11) */}
        <div className="pt-2">
          {isCharging ? (
            <Button
              size="lg"
              variant="danger"
              fullWidth
              onClick={() => setIsStopModalOpen(true)}
              icon={Power}
            >
              Stop Charging
            </Button>
          ) : (
            <Button
              size="lg"
              variant="primary"
              fullWidth
              onClick={() => {
                startCharging();
                showToast('Start command dispatched via real-time stream', 'success');
              }}
              icon={Zap}
            >
              Start Charging
            </Button>
          )}
        </div>
      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={isStopModalOpen}
        onClose={() => setIsStopModalOpen(false)}
        title="Stop Charging Session?"
        subtitle="Confirm to terminate power delivery, open relay, and generate bill."
      >
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Current Battery: {Math.round(batteryPct)}%</p>
              <p className="text-[11px] text-amber-200/80 mt-0.5">
                Energy delivered: {typeof energy === 'number' ? energy.toFixed(2) : energy} kWh. Final invoice will be calculated and digital bill recorded.
              </p>
            </div>
          </div>

          <div className="flex gap-2.5 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => setIsStopModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleStopCharging}
            >
              Stop Charging
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
