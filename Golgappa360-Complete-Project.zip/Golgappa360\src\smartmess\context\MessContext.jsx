import React, { createContext, useContext, useState, useEffect } from 'react';

const MessContext = createContext(null);

export const NAV_ITEMS = [
  { id: 'overview', label: 'Overview', icon: 'LayoutDashboard', path: '/' },
  { id: 'predict', label: 'Predict Waste', icon: 'Sparkles', path: '/predict' },
  { id: 'dataset', label: 'Dataset Explorer', icon: 'Database', path: '/dataset' },
  { id: 'models', label: 'Model Laboratory', icon: 'FlaskConical', path: '/models' },
  { id: 'insights', label: 'Waste Insights', icon: 'TrendingDown', path: '/insights' },
  { id: 'history', label: 'Prediction History', icon: 'History', path: '/history' },
  { id: 'about', label: 'About Project', icon: 'Info', path: '/about' },
];

export const MessProvider = ({ children }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // UI State toggles for demonstration: normal | loading | empty | error
  const [simulationState, setSimulationState] = useState('normal');
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);
  const [selectedMealTypeFilter, setSelectedMealTypeFilter] = useState('All');

  // Sync route from pathname if URL changed
  useEffect(() => {
    const path = window.location.pathname.replace('/', '') || 'overview';
    const found = NAV_ITEMS.find((item) => item.id === path);
    if (found) {
      setActiveTab(found.id);
    }
  }, []);

  const navigateTo = (tabId) => {
    setActiveTab(tabId);
    setIsMobileMenuOpen(false);
    window.history.pushState(null, '', tabId === 'overview' ? '/' : `/${tabId}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  return (
    <MessContext.Provider
      value={{
        activeTab,
        navigateTo,
        isSidebarCollapsed,
        toggleSidebar,
        isMobileMenuOpen,
        toggleMobileMenu,
        setIsMobileMenuOpen,
        simulationState,
        setSimulationState,
        isDemoModalOpen,
        setIsDemoModalOpen,
        selectedMealTypeFilter,
        setSelectedMealTypeFilter,
      }}
    >
      {children}
    </MessContext.Provider>
  );
};

export const useMess = () => {
  const context = useContext(MessContext);
  if (!context) {
    console.warn('useMess was called outside of a MessProvider, returning safe fallback defaults.');
    return {
      activeTab: 'overview',
      navigateTo: () => {},
      isSidebarCollapsed: false,
      toggleSidebar: () => {},
      isMobileMenuOpen: false,
      toggleMobileMenu: () => {},
      setIsMobileMenuOpen: () => {},
      simulationState: 'normal',
      setSimulationState: () => {},
      isDemoModalOpen: false,
      setIsDemoModalOpen: () => {},
      selectedMealTypeFilter: 'All',
      setSelectedMealTypeFilter: () => {},
    };
  }
  return context;
};
