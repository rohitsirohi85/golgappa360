import api from '../../services/api';

export const adminService = {
  // 1. Dashboard Stats
  getStats: async () => {
    return api.get('/admin/stats');
  },

  // 2. Energy & Revenue Analytics
  getEnergyAnalytics: async () => {
    return api.get('/admin/analytics/energy');
  },

  getRevenueAnalytics: async () => {
    return api.get('/admin/analytics/revenue');
  },

  // 3. Charger Fleet Management
  getChargers: async (status, stationId) => {
    const params = new URLSearchParams();
    if (status && status !== 'all') params.append('status', status);
    if (stationId && stationId !== 'all') params.append('stationId', stationId);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return api.get(`/admin/chargers${qs}`);
  },

  getChargerDetails: async (id) => {
    return api.get(`/admin/chargers/${id}`);
  },

  controlCharger: async (id, action, params = {}) => {
    return api.post(`/admin/chargers/${id}/control`, { action, ...params });
  },

  // 4. Station Management
  getStations: async () => {
    return api.get('/admin/stations');
  },

  createStation: async (data) => {
    return api.post('/admin/stations', data);
  },

  updateStation: async (id, data) => {
    return api.put(`/admin/stations/${id}`, data);
  },

  deactivateStation: async (id) => {
    return api.patch(`/admin/stations/${id}/deactivate`);
  },

  // 5. User Management (Admin Only)
  getUsers: async () => {
    return api.get('/admin/users');
  },

  getUserDetails: async (id) => {
    return api.get(`/admin/users/${id}`);
  },

  updateUserStatus: async (id, accountStatus) => {
    return api.patch(`/admin/users/${id}/status`, { accountStatus });
  },

  // 6. Bookings & Sessions
  getBookings: async () => {
    return api.get('/admin/bookings');
  },

  getSessions: async () => {
    return api.get('/admin/sessions');
  },

  // 7. System Alerts & Faults
  getAlerts: async (severity, status) => {
    const params = new URLSearchParams();
    if (severity && severity !== 'all') params.append('severity', severity);
    if (status && status !== 'all') params.append('status', status);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return api.get(`/admin/alerts${qs}`);
  },

  acknowledgeAlert: async (id) => {
    return api.patch(`/admin/alerts/${id}/acknowledge`);
  },

  resolveAlert: async (id, resolutionNotes) => {
    return api.patch(`/admin/alerts/${id}/resolve`, { resolutionNotes });
  },

  // 8. System Devices (ESP32)
  getDevices: async () => {
    return api.get('/devices');
  },

  // 9. Audit Logs (Admin Only)
  getAuditLogs: async (limit = 100) => {
    return api.get(`/admin/audit-logs?limit=${limit}`);
  },

  // 10. System Settings (Admin Only to write)
  getSettings: async () => {
    return api.get('/admin/settings');
  },

  updateSettings: async (settingsObj) => {
    return api.put('/admin/settings', settingsObj);
  },
};

export default adminService;
