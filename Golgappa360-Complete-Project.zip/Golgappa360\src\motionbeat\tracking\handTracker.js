import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

/**
 * HandTracker (High-Performance Throttled Architecture)
 * - Independent 320x240 inference resolution
 * - Throttled 12-15 FPS inference (prevents main thread & audio starvation)
 * - Real measured inference FPS & latency metrics
 * - Low-latency jitter smoothing filter
 * - Reusable landmark structures (low GC overhead)
 */
export class HandTracker {
  constructor() {
    this.landmarker = null;
    this.status = 'uninitialized'; // 'uninitialized' | 'loading' | 'ready' | 'error'
    this.error = null;
    this.onStatusChange = null;

    // Rate limiting: Target ~14 FPS (70ms interval) to leave main thread free for 60fps rendering and audio
    this.targetIntervalMs = 70;
    this.lastInferenceTime = 0;
    this.lastVideoTime = -1;

    // Metrics
    this.lastInferenceMs = 0;
    this.measuredInferenceFps = 0;
    this.inferenceFrameCount = 0;
    this.lastFpsCalcTime = 0;

    // Dedicated offscreen downscaling canvas (320x240)
    this.downscaleCanvas = document.createElement('canvas');
    this.downscaleCanvas.width = 320;
    this.downscaleCanvas.height = 240;
    this.downscaleCtx = this.downscaleCanvas.getContext('2d', { willReadFrequently: true });

    // Smoothed hand state storage (prevents jitter while keeping zero perceptual lag)
    this.smoothedHands = [
      { x: 0, y: 0, z: 0, pinch: 1.0, active: false },
      { x: 0, y: 0, z: 0, pinch: 1.0, active: false },
    ];
    this.smoothingAlpha = 0.45; // Fast responsive smoothing

    // Cached result for throttled calls
    this.cachedResult = {
      handCount: 0,
      hands: [],
      inferenceTimeMs: 0,
      inferenceFps: 0,
    };
  }

  setStatus(status, error = null) {
    this.status = status;
    this.error = error;
    if (this.onStatusChange) {
      this.onStatusChange(status, error);
    }
  }

  async init() {
    if (this.landmarker || this.status === 'loading') return;

    this.setStatus('loading');

    try {
      const vision = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm'
      );

      const modelAssetPath =
        'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

      const createOptions = (delegate) => ({
        baseOptions: {
          modelAssetPath,
          delegate,
        },
        runningMode: 'VIDEO',
        numHands: 2,
        minHandDetectionConfidence: 0.5,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      try {
        this.landmarker = await HandLandmarker.createFromOptions(vision, createOptions('GPU'));
      } catch (gpuError) {
        console.warn('GPU delegate failed for HandLandmarker, falling back to CPU:', gpuError);
        this.landmarker = await HandLandmarker.createFromOptions(vision, createOptions('CPU'));
      }

      this.setStatus('ready');
      return true;
    } catch (err) {
      console.error('Failed to initialize MediaPipe HandLandmarker:', err);
      const msg = err.message || 'Failed to download or load MediaPipe vision model.';
      this.setStatus('error', msg);
      throw err;
    }
  }

  /**
   * Run throttled inference on downscaled frame
   * Enforces 12-15 FPS max inference rate
   */
  detectVideo(videoElement, timestamp = performance.now()) {
    if (!this.landmarker || this.status !== 'ready') return this.cachedResult;
    if (!videoElement || videoElement.readyState < 2) return this.cachedResult;

    // Rate limiter: return cached result if interval hasn't elapsed
    if (timestamp - this.lastInferenceTime < this.targetIntervalMs) {
      return this.cachedResult;
    }

    // Skip duplicate video frames
    if (videoElement.currentTime === this.lastVideoTime) {
      return this.cachedResult;
    }
    this.lastVideoTime = videoElement.currentTime;

    const start = performance.now();

    // 1. Downscale video frame to 320x240 for 4x faster GPU/CPU inference
    this.downscaleCtx.drawImage(videoElement, 0, 0, 320, 240);

    // 2. Run MediaPipe inference on the downscaled canvas
    let rawResults;
    try {
      rawResults = this.landmarker.detectForVideo(this.downscaleCanvas, timestamp);
    } catch (err) {
      console.warn('Inference error:', err);
      return this.cachedResult;
    }

    const end = performance.now();
    this.lastInferenceMs = Math.round(end - start);
    this.lastInferenceTime = timestamp;

    // 3. Track real measured inference FPS
    this.inferenceFrameCount++;
    if (timestamp - this.lastFpsCalcTime >= 500) {
      this.measuredInferenceFps = Math.round((this.inferenceFrameCount * 1000) / (timestamp - this.lastFpsCalcTime));
      this.inferenceFrameCount = 0;
      this.lastFpsCalcTime = timestamp;
    }

    // 4. Process landmarks and update cache
    this.cachedResult = this.processResults(rawResults);
    return this.cachedResult;
  }

  processResults(results) {
    if (!results || !results.landmarks || results.landmarks.length === 0) {
      this.smoothedHands.forEach((h) => (h.active = false));
      return {
        handCount: 0,
        hands: [],
        inferenceTimeMs: this.lastInferenceMs,
        inferenceFps: this.measuredInferenceFps,
      };
    }

    const processedHands = [];

    for (let i = 0; i < Math.min(2, results.landmarks.length); i++) {
      const raw = results.landmarks[i];
      const handedness = results.handednesses && results.handednesses[i] && results.handednesses[i][0]
        ? results.handednesses[i][0].categoryName
        : (i === 0 ? 'Right' : 'Left');

      const score = results.handednesses && results.handednesses[i] && results.handednesses[i][0]
        ? results.handednesses[i][0].score
        : 0.95;

      // Palm Center: midpoint of wrist (0) and middle MCP (9)
      const wrist = raw[0];
      const middleMcp = raw[9];
      const rawPalmX = (wrist.x + middleMcp.x) * 0.5;
      const rawPalmY = (wrist.y + middleMcp.y) * 0.5;
      const rawPalmZ = (wrist.z + middleMcp.z) * 0.5;

      // Mirrored X for natural selfie perspective
      const mirroredX = 1.0 - rawPalmX;
      const mirroredY = rawPalmY;

      // Normalized coordinates (-1 to 1 for Three.js 3D space)
      const ndcX = mirroredX * 2.0 - 1.0;
      const ndcY = -(mirroredY * 2.0 - 1.0);

      // Pinch detection (Thumb tip 4 to Index tip 8)
      const thumbTip = raw[4];
      const indexTip = raw[8];
      const dx = thumbTip.x - indexTip.x;
      const dy = thumbTip.y - indexTip.y;
      const dz = thumbTip.z - indexTip.z;
      const pinchDist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const isPinching = pinchDist < 0.085;

      // Jitter Smoothing with Exponential Moving Average (EMA)
      const prev = this.smoothedHands[i];
      let smoothX = ndcX;
      let smoothY = ndcY;
      let smoothPinch = pinchDist;

      if (prev.active) {
        smoothX = this.smoothingAlpha * ndcX + (1 - this.smoothingAlpha) * prev.x;
        smoothY = this.smoothingAlpha * ndcY + (1 - this.smoothingAlpha) * prev.y;
        smoothPinch = this.smoothingAlpha * pinchDist + (1 - this.smoothingAlpha) * prev.pinch;
      }

      this.smoothedHands[i] = {
        x: smoothX,
        y: smoothY,
        z: rawPalmZ,
        pinch: smoothPinch,
        active: true,
      };

      processedHands.push({
        id: `hand_${i}`,
        index: i,
        handedness,
        score,
        landmarks: raw,
        position: { x: smoothX, y: smoothY, z: rawPalmZ },
        pinchDistance: smoothPinch,
        isPinching,
      });
    }

    return {
      handCount: processedHands.length,
      hands: processedHands,
      inferenceTimeMs: this.lastInferenceMs,
      inferenceFps: this.measuredInferenceFps,
    };
  }

  dispose() {
    if (this.landmarker) {
      try {
        this.landmarker.close();
      } catch (e) {
        // ignore
      }
      this.landmarker = null;
    }
    this.status = 'uninitialized';
    this.smoothedHands.forEach((h) => (h.active = false));
  }
}

export const handTracker = new HandTracker();
