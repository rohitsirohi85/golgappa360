import React from 'react';
import {
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
  CELESTIAL_CATEGORIES,
} from '../../data/celestialObjects.js';

/**
 * ObjectInspector — Universal Celestial Inspector Panel
 * 
 * Dynamically adapts to any celestial object category:
 * Stars, White Dwarfs, Neutron Stars, Pulsars, Black Holes, Nebulae, Clusters, Galaxies.
 * Only displays verified astronomical properties known for that object.
 */
export default function ObjectInspector({
  object,
  onClose,
  onOpenFullModal,
  onEnterSolarSystem,
  onExploreEarth,
  onExploreMoon,
  onExploreBlackHole,
  onExploreConstellation,
  onLocateOnMap,
  onDiscoverAnother = null,
  onCompare = null,
  viewMode = 'universe',
  className = '',
}) {
  if (!object) return null;

  const categorySymbol = object.category
    ? CATEGORY_SYMBOLS[object.category] || '●'
    : '●';
  const categoryLabel = object.category
    ? CATEGORY_LABELS[object.category] || object.category
    : 'Celestial Object';

  const isBlackHole = object.category === CELESTIAL_CATEGORIES.BLACK_HOLE;
  const isPlanet = object.category === CELESTIAL_CATEGORIES.PLANET;
  const isMoon = object.id === 'moon' || object.category === CELESTIAL_CATEGORIES.NATURAL_SATELLITE;
  const isEarth = object.id === 'earth';
  const isSun = object.isSun || object.id === 'sun';

  // Build list of active scientific metrics for this object
  const metrics = [];
  if (isMoon) {
    if (object.distanceFromEarth) {
      metrics.push({ label: 'Dist from Earth', value: object.distanceFromEarth });
    }
    if (object.orbitalPeriod) {
      metrics.push({ label: 'Orbital Period', value: object.orbitalPeriod, highlight: true });
    }
    if (object.gravity) {
      metrics.push({ label: 'Surface Gravity', value: object.gravity });
    }
    if (object.temperature) {
      metrics.push({ label: 'Surface Temp', value: object.temperature, highlight: true });
    }
    if (object.radius) {
      metrics.push({ label: 'Mean Radius', value: object.radius });
    }
    if (object.mass) {
      metrics.push({ label: 'Lunar Mass', value: object.mass });
    }
  } else if (isPlanet) {
    if (object.distanceFromSun) {
      metrics.push({ label: 'Dist from Sun', value: object.distanceFromSun });
    }
    if (object.orbitalPeriod) {
      metrics.push({ label: 'Orbital Period', value: object.orbitalPeriod, highlight: true });
    }
    if (object.rotationPeriod) {
      metrics.push({ label: 'Rotation', value: object.rotationPeriod });
    }
    if (object.temperature) {
      metrics.push({ label: 'Temperature', value: object.temperature, highlight: true });
    }
    if (object.moons !== undefined) {
      metrics.push({ label: 'Known Moons', value: String(object.moons) });
    }
    if (object.radius) {
      metrics.push({ label: 'Mean Radius', value: object.radius });
    }
  } else {
    if (object.distance) {
      metrics.push({ label: 'Distance', value: object.distance });
    }
    if (object.mass) {
      metrics.push({ label: 'Mass', value: object.mass });
    }
    if (object.hostGalaxy) {
      metrics.push({ label: 'Host Galaxy', value: object.hostGalaxy });
    }
    if (object.temperature) {
      metrics.push({ label: 'Temperature', value: object.temperature, highlight: true });
    }
    if (object.diameter) {
      metrics.push({ label: 'Span / Diameter', value: object.diameter });
    }
    if (object.eventHorizonRadius) {
      metrics.push({ label: 'Event Horizon', value: object.eventHorizonRadius, highlight: true });
    }
    if (object.spinParameter) {
      metrics.push({ label: 'Spin Parameter', value: object.spinParameter, highlight: true });
    }
    if (object.accretionDiskTemp) {
      metrics.push({ label: 'Accretion Temp', value: object.accretionDiskTemp, highlight: true });
    }
    if (object.rotationPeriod) {
      metrics.push({ label: 'Rotation Period', value: object.rotationPeriod, highlight: true });
    }
    if (object.starCount) {
      metrics.push({ label: 'Stellar Population', value: object.starCount });
    }
    if (object.magnitude) {
      metrics.push({ label: 'Apparent Mag', value: object.magnitude });
    }
    if (object.age) {
      metrics.push({ label: 'Estimated Age', value: object.age });
    }
  }

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      <div
        className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Inspector Container */}
      <aside
        className={`fixed md:absolute bottom-0 left-0 right-0 md:bottom-auto md:left-auto md:top-4 md:right-4 z-40 md:w-80 lg:w-96 bg-[#030612]/92 md:bg-[#030612]/90 backdrop-blur-2xl border-t md:border border-white/15 rounded-t-2xl md:rounded-2xl shadow-[0_-10px_40px_rgba(0,0,0,0.85)] md:shadow-[0_20px_50px_rgba(0,0,0,0.85)] max-h-[85vh] md:max-h-[calc(100%-2rem)] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 md:slide-in-from-right-6 duration-200 select-none ${className}`}
        aria-label={`Object inspector for ${object.name}`}
      >
        {/* Mobile Swipe / Drag Handle Indicator */}
        <div className="md:hidden flex justify-center pt-2 pb-1" onClick={onClose}>
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Header Telemetry Bar */}
        <div className="px-4 sm:px-5 pt-3 pb-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="font-bold text-xs shadow-[0_0_8px_currentColor]"
              style={{ color: object.colorHex || '#38bdf8' }}
            >
              {categorySymbol}
            </span>
            <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase truncate">
              {categoryLabel} // {object.spectralClass || object.subtype || 'ASTRONOMICAL TARGET'}
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close object inspector"
            className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Object Title & Moniker */}
          <div>
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="text-xl sm:text-2xl font-display font-bold text-white tracking-tight">
                {object.name}
              </h2>
              {(object.constellation || object.relatedConstellation) && (
                onExploreConstellation && object.constellation !== 'Solar System' ? (
                  <button
                    type="button"
                    onClick={() => onExploreConstellation(object.constellation || object.relatedConstellation)}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-400/40 text-cyan-300 hover:text-white transition-all cursor-pointer flex items-center gap-1 group shadow-[0_0_8px_rgba(6,182,212,0.15)]"
                    title={`Explore ${object.constellation || object.relatedConstellation} Constellation`}
                  >
                    <span>✨ {object.constellation || object.relatedConstellation}</span>
                    <span className="group-hover:translate-x-0.5 transition-transform text-cyan-400">→</span>
                  </button>
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-cyan-300">
                    {object.constellation || object.relatedConstellation}
                  </span>
                )
              )}
            </div>
            {object.commonName && (
              <p className="text-xs text-amber-200/80 font-sans mt-0.5 italic">
                {object.commonName}
              </p>
            )}
          </div>

          {/* Subtype & Category Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 text-slate-200">
              {object.subtype || object.type || categoryLabel}
            </span>
            {object.spectralClass && (
              <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-cyan-950/40 border border-cyan-500/30 text-cyan-300">
                Class {object.spectralClass}
              </span>
            )}
            {object.companionName && (
              <span className="text-[10px] font-mono px-2 py-1 rounded-md bg-purple-950/40 border border-purple-500/30 text-purple-300">
                Binary System
              </span>
            )}
          </div>

          {/* Scientific Disclaimer for Black Holes */}
          {isBlackHole && (
            <div className="p-2 rounded-lg bg-amber-500/[0.06] border border-amber-500/25 text-[10px] font-mono text-amber-200 flex items-center gap-1.5">
              <span className="text-amber-400">ℹ</span>
              <span>Scientific visualization — not to scale.</span>
            </div>
          )}

          {/* Dynamic Telemetry Grid (only displaying known fields) */}
          {metrics.length > 0 && (
            <div className="grid grid-cols-2 gap-2 text-xs">
              {metrics.slice(0, 4).map((m) => (
                <div key={m.label} className="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
                  <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider truncate">
                    {m.label}
                  </span>
                  <span
                    className={`font-semibold font-sans mt-0.5 block truncate ${
                      m.highlight ? 'text-amber-300' : 'text-slate-100'
                    }`}
                  >
                    {m.value}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Description Excerpt */}
          {object.description && (
            <p className="text-xs text-slate-300/85 leading-relaxed line-clamp-3">
              {object.description}
            </p>
          )}

          {/* Interesting Fact Teaser */}
          {object.interestingFact && (
            <div className="p-2.5 rounded-lg bg-amber-500/[0.04] border border-amber-500/20 text-[11px] text-amber-200/90 leading-snug">
              <span className="font-semibold text-amber-300 mr-1">✦ Fact:</span>
              <span className="line-clamp-2">{object.interestingFact}</span>
            </div>
          )}

          {/* Actions Container */}
          <div className="pt-1 space-y-2">
            {/* Primary Action 1: Explore Earth Portal */}
            {isEarth && onExploreEarth && (
              <button
                type="button"
                onClick={() => onExploreEarth()}
                className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-cyan-950 bg-gradient-to-r from-cyan-300 via-sky-300 to-blue-300 hover:from-cyan-200 hover:to-sky-200 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>🌍 Explore Earth</span>
                <span className="text-cyan-950 group-hover:translate-x-1 transition-transform">→</span>
              </button>
            )}

            {/* Primary Action 2: Explore Moon Portal */}
            {isMoon && onExploreMoon && (
              <button
                type="button"
                onClick={() => onExploreMoon()}
                className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-slate-950 bg-gradient-to-r from-slate-200 via-slate-300 to-zinc-300 hover:from-white hover:to-slate-200 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(226,232,240,0.3)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>🌕 Explore Moon</span>
                <span className="text-slate-950 group-hover:translate-x-1 transition-transform">→</span>
              </button>
            )}

            {/* Primary Action 3: Explore Black Hole Portal */}
            {isBlackHole && onExploreBlackHole && (
              <button
                type="button"
                onClick={() => onExploreBlackHole(object)}
                className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-amber-950 bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 hover:from-amber-300 hover:to-orange-300 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(245,158,11,0.35)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>🕳️ Explore Black Hole</span>
                <span className="text-amber-950 group-hover:translate-x-1 transition-transform">→</span>
              </button>
            )}

            {/* Primary Action 4: Explore Solar System (For Sun and Other Planets) */}
            {(isSun || (isPlanet && !isEarth)) && onEnterSolarSystem && (
              <button
                type="button"
                onClick={() => onEnterSolarSystem(object)}
                className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-amber-950 bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-400 hover:from-amber-200 hover:to-yellow-300 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(251,191,36,0.25)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>{viewMode === 'solar-system' ? 'Focus In System' : '🪐 Explore Solar System'}</span>
                <span className="text-amber-950 group-hover:translate-x-1 transition-transform">→</span>
              </button>
            )}

            {/* Optional Locate on Map button (when in deep views or on request) */}
            {onLocateOnMap && viewMode !== 'universe' && (
              <button
                type="button"
                onClick={() => onLocateOnMap(object)}
                className="w-full py-2 px-4 rounded-xl font-mono font-medium text-xs tracking-wider text-slate-300 bg-white/[0.04] hover:bg-white/10 hover:text-white border border-white/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📍 Locate On Map</span>
              </button>
            )}

            {/* Primary Action 5: Explore Constellation Portal */}
            {!isPlanet && !isMoon && !isSun && (object.constellation || object.relatedConstellation) && onExploreConstellation && object.constellation !== 'Solar System' && (
              <button
                type="button"
                onClick={() => onExploreConstellation(object.constellation || object.relatedConstellation)}
                className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-cyan-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 hover:from-cyan-300 hover:to-sky-200 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(6,182,212,0.25)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>✨ Explore {object.constellation || object.relatedConstellation} Constellation</span>
                <span className="text-cyan-950 group-hover:translate-x-1 transition-transform">→</span>
              </button>
            )}

            {/* Discover Another Action (Phase U11) */}
            {onDiscoverAnother && (
              <button
                type="button"
                onClick={onDiscoverAnother}
                className="w-full py-2 px-4 rounded-xl font-mono font-medium text-xs tracking-wider text-cyan-200 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 hover:border-cyan-400 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <span className="text-amber-300">✦</span>
                <span>DISCOVER ANOTHER</span>
              </button>
            )}

            {/* Cosmic Compare Action (Phase U12) */}
            {onCompare && (
              <button
                type="button"
                onClick={() => onCompare(object)}
                className="w-full py-2.5 px-4 rounded-xl font-mono font-medium text-xs tracking-wider text-purple-200 bg-purple-950/40 hover:bg-purple-900/60 border border-purple-500/30 hover:border-purple-400 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm group"
                title={`Compare ${object.name} with another celestial target`}
              >
                <span>⚖️</span>
                <span>COMPARE WITH ANOTHER</span>
                <span className="text-purple-400 group-hover:translate-x-0.5 transition-transform">→</span>
              </button>
            )}

            {/* View Full Details Button */}
            <button
              type="button"
              onClick={() => onOpenFullModal(object)}
              className="w-full py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-cyan-950 bg-gradient-to-r from-cyan-400 to-sky-300 hover:from-cyan-300 hover:to-sky-200 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(34,211,238,0.25)] flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>View Full Details</span>
              <svg
                className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2.5"
                  d="M14 5l7 7m0 0l-7 7m7-7H3"
                />
              </svg>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
