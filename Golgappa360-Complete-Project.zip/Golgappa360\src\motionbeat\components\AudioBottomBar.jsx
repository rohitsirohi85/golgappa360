import React, { useEffect, useRef, useState } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Activity, 
  Plus, 
  Minus 
} from 'lucide-react';

export const AudioBottomBar = ({
  audioEngine,
  isPlaying,
  onTogglePlay,
  bpm,
  onBpmChange,
  volume,
  onVolumeChange,
  currentPattern,
  onPatternChange,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const canvasRef = useRef(null);
  const animRef = useRef(null);

  // Direct DOM refs for zero-re-render meters
  const bassBarRef = useRef(null);
  const midBarRef = useRef(null);
  const trebleBarRef = useRef(null);

  const patterns = [
    { id: 'cyber-pulse', name: 'Cyber Pulse', bpm: 124, genre: 'Cyberpunk Drive' },
    { id: 'deep-hyperspace', name: 'Deep Hyperspace', bpm: 96, genre: 'Atmospheric Void' },
    { id: 'glitch-matrix', name: 'Glitch Matrix', bpm: 138, genre: 'Fast Neuro Break' },
  ];

  // Tap tempo state
  const lastTapRef = useRef(0);
  const tapDiffsRef = useRef([]);

  const handleTapTempo = () => {
    const now = performance.now();
    if (lastTapRef.current > 0) {
      const diff = now - lastTapRef.current;
      if (diff > 250 && diff < 2000) {
        tapDiffsRef.current.push(diff);
        if (tapDiffsRef.current.length > 4) tapDiffsRef.current.shift();
        const avgDiff = tapDiffsRef.current.reduce((a, b) => a + b, 0) / tapDiffsRef.current.length;
        const calcBpm = Math.round(60000 / avgDiff);
        onBpmChange(calcBpm);
      } else {
        tapDiffsRef.current = [];
      }
    }
    lastTapRef.current = now;
  };

  const handleMuteToggle = () => {
    if (audioEngine) {
      const muted = audioEngine.toggleMute();
      setIsMuted(muted);
    }
  };

  // High-performance direct Canvas & DOM renderer (Zero React re-renders)
  useEffect(() => {
    let active = true;

    const renderSpectrum = () => {
      if (!active) return;

      if (audioEngine && canvasRef.current) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        const data = audioEngine.getAudioData();

        // Update DOM meter bars directly (no React state re-rendering!)
        if (bassBarRef.current) {
          bassBarRef.current.style.width = `${Math.min(100, Math.round(data.bass * 100))}%`;
        }
        if (midBarRef.current) {
          midBarRef.current.style.width = `${Math.min(100, Math.round(data.mid * 100))}%`;
        }
        if (trebleBarRef.current) {
          trebleBarRef.current.style.width = `${Math.min(100, Math.round(data.treble * 100))}%`;
        }

        // Draw real spectral bars
        const width = canvas.width;
        const height = canvas.height;
        ctx.clearRect(0, 0, width, height);

        const freq = data.rawFrequency;
        const barCount = 36;
        const barWidth = (width / barCount) - 1.5;

        const gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, '#06b6d4');
        gradient.addColorStop(0.55, '#3b82f6');
        gradient.addColorStop(1, '#c084fc');

        for (let i = 0; i < barCount; i++) {
          const binIndex = Math.min(freq.length - 1, Math.floor(Math.pow(i / barCount, 1.4) * (freq.length * 0.75)));
          const rawVal = freq[binIndex] || 0;
          const barHeight = Math.max(2, (rawVal / 255.0) * height);

          ctx.fillStyle = gradient;
          ctx.fillRect(i * (barWidth + 1.5), height - barHeight, barWidth, barHeight);

          if (barHeight > 6) {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(i * (barWidth + 1.5), height - barHeight - 1, barWidth, 1.5);
          }
        }
      }

      animRef.current = requestAnimationFrame(renderSpectrum);
    };

    renderSpectrum();

    return () => {
      active = false;
      if (animRef.current) {
        cancelAnimationFrame(animRef.current);
      }
    };
  }, [audioEngine, isPlaying]);

  return (
    <footer className="border-t border-white/10 mb-panel px-4 py-3 z-30 select-none">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-3 md:gap-4 max-w-7xl mx-auto">
        
        {/* Left: Play/Pause, Pattern Selector */}
        <div className="flex items-center gap-3 w-full lg:w-auto justify-between lg:justify-start">
          <button
            onClick={onTogglePlay}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider transition-all duration-300 shadow-lg ${
              isPlaying
                ? 'bg-cyan-500 text-black border border-cyan-300 mb-glow-cyan animate-pulse'
                : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-500 hover:to-blue-500 border border-purple-400/30'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-black text-black" />
                <span>PAUSE BEAT</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white text-white" />
                <span>START BEAT</span>
              </>
            )}
          </button>

          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
            {patterns.map((p) => {
              const active = currentPattern === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => onPatternChange(p.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                    active
                      ? 'bg-purple-600/30 text-purple-200 border border-purple-500/50 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                  title={`${p.genre} (${p.bpm} BPM)`}
                >
                  <span className="font-semibold">{p.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center: BPM Controls & Real Spectrum Visualizer */}
        <div className="flex items-center gap-4 w-full lg:w-auto justify-center">
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
            <span className="text-[11px] font-mono text-slate-400 uppercase">BPM</span>
            <span className="text-sm font-mono font-bold text-cyan-300 w-10 text-center">
              {bpm}
            </span>
            <div className="flex items-center gap-0.5">
              <button
                onClick={() => onBpmChange(bpm - 1)}
                className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white"
                title="Decrease BPM"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onBpmChange(bpm + 1)}
                className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white"
                title="Increase BPM"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
            <button
              onClick={handleTapTempo}
              className="text-[10px] font-mono px-2 py-1 rounded bg-white/5 hover:bg-white/15 text-slate-300 border border-white/10 active:scale-95 transition-transform"
              title="Click repeatedly to tap tempo"
            >
              TAP
            </button>
          </div>

          {/* Real Audio FFT Spectrum Canvas */}
          <div className="hidden sm:flex flex-col items-center gap-1 bg-black/50 px-3 py-1.5 rounded-xl border border-white/10">
            <div className="flex items-center justify-between w-full text-[9px] font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <Activity className="w-2.5 h-2.5 text-cyan-400" />
                <span>REAL FFT ANALYSER</span>
              </span>
              <span className={isPlaying ? 'text-cyan-400' : 'text-slate-500'}>
                {isPlaying ? 'ACTIVE 512-PT' : 'IDLE'}
              </span>
            </div>
            <canvas
              ref={canvasRef}
              width={160}
              height={26}
              className="w-40 h-6.5 rounded"
            />
          </div>
        </div>

        {/* Right: Audio Reactivity Gauges & Master Volume */}
        <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-[10px] font-mono">
            {/* Bass Gauge */}
            <div className="flex flex-col items-center">
              <span className="text-purple-300">BASS</span>
              <div className="w-10 h-1.5 bg-white/10 rounded-full overflow-hidden mt-0.5">
                <div
                  ref={bassBarRef}
                  className="h-full bg-gradient-to-r from-purple-500 to-purple-300 transition-all duration-75"
                  style={{ width: '0%' }}
                />
              </div>
            </div>

            {/* Mid Gauge */}
            <div className="flex flex-col items-center">
              <span className="text-blue-300">MID</span>
              <div className="w-10 h-1.5 bg-white/10 rounded-full overflow-hidden mt-0.5">
                <div
                  ref={midBarRef}
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-300 transition-all duration-75"
                  style={{ width: '0%' }}
                />
              </div>
            </div>

            {/* Treble Gauge */}
            <div className="flex flex-col items-center">
              <span className="text-cyan-300">TREB</span>
              <div className="w-10 h-1.5 bg-white/10 rounded-full overflow-hidden mt-0.5">
                <div
                  ref={trebleBarRef}
                  className="h-full bg-gradient-to-r from-cyan-500 to-cyan-300 transition-all duration-75"
                  style={{ width: '0%' }}
                />
              </div>
            </div>
          </div>

          {/* Master Volume */}
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
            <button
              onClick={handleMuteToggle}
              className="text-slate-400 hover:text-white transition-colors"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-cyan-400" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                setIsMuted(false);
                onVolumeChange(parseFloat(e.target.value));
              }}
              className="w-20 mb-slider"
              title={`Master Volume: ${Math.round(volume * 100)}%`}
            />
            <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
              {isMuted ? '0%' : `${Math.round(volume * 100)}%`}
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
