import React from 'react';
import { MessProvider, useMess } from './context/MessContext';
import { MainLayout } from './components/layout/MainLayout';
import { OverviewPage } from './pages/OverviewPage';
import { PredictWastePage } from './pages/PredictWastePage';
import { DatasetExplorerPage } from './pages/DatasetExplorerPage';
import { ModelLabPage } from './pages/ModelLabPage';
import { WasteInsightsPage } from './pages/WasteInsightsPage';
import { PredictionHistoryPage } from './pages/PredictionHistoryPage';
import { AboutProjectPage } from './pages/AboutProjectPage';

const AppContent = () => {
  const { activeTab } = useMess();

  const renderActivePage = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewPage />;
      case 'predict':
        return <PredictWastePage />;
      case 'dataset':
        return <DatasetExplorerPage />;
      case 'models':
        return <ModelLabPage />;
      case 'insights':
        return <WasteInsightsPage />;
      case 'history':
        return <PredictionHistoryPage />;
      case 'about':
        return <AboutProjectPage />;
      default:
        return <OverviewPage />;
    }
  };

  return <MainLayout>{renderActivePage()}</MainLayout>;
};

export const SmartMessApp = () => {
  return (
    <MessProvider>
      <AppContent />
    </MessProvider>
  );
};

export default SmartMessApp;
