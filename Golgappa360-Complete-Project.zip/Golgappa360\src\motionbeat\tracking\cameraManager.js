/**
 * CameraManager
 * Manages webcam lifecycle, permission requests, video streaming,
 * device disconnection listeners, and clean resource teardown.
 */
export class CameraManager {
  constructor() {
    this.stream = null;
    this.videoElement = null;
    this.status = 'off'; // 'off' | 'requesting' | 'active' | 'error'
    this.error = null;
    this.onStatusChange = null;
    this.isMuted = true;
  }

  setVideoElement(video) {
    this.videoElement = video;
  }

  setStatus(status, error = null) {
    this.status = status;
    this.error = error;
    if (this.onStatusChange) {
      this.onStatusChange(status, error);
    }
  }

  async startCamera(videoElement = null) {
    if (videoElement) {
      this.videoElement = videoElement;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      const err = new Error('Camera access is not supported by this browser.');
      this.setStatus('error', err.message);
      throw err;
    }

    // Stop any existing stream first
    this.stopCamera();

    this.setStatus('requesting');

    try {
      const constraints = {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
          frameRate: { ideal: 30, max: 60 },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.stream = stream;

      // Handle external stream cutoff (e.g. unplugged webcam)
      stream.getVideoTracks().forEach((track) => {
        track.onended = () => {
          this.stopCamera();
          this.setStatus('off');
        };
      });

      if (this.videoElement) {
        this.videoElement.srcObject = stream;
        this.videoElement.muted = true;
        this.videoElement.playsInline = true;

        await new Promise((resolve, reject) => {
          this.videoElement.onloadedmetadata = () => {
            this.videoElement.play()
              .then(resolve)
              .catch(reject);
          };
          this.videoElement.onerror = (e) => reject(new Error('Video element failed to load stream.'));
        });
      }

      this.setStatus('active');
      return stream;
    } catch (err) {
      let friendlyMessage = 'Unable to access camera.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        friendlyMessage = 'Camera permission denied. Please allow camera access in your browser settings.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        friendlyMessage = 'No camera device found on this system.';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        friendlyMessage = 'Camera is already in use by another application.';
      } else if (err.name === 'OverconstrainedError') {
        friendlyMessage = 'Requested camera resolution is not supported.';
      } else {
        friendlyMessage = err.message || friendlyMessage;
      }

      this.stopCamera();
      this.setStatus('error', friendlyMessage);
      throw new Error(friendlyMessage);
    }
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {
          // ignore track stop error
        }
      });
      this.stream = null;
    }

    if (this.videoElement) {
      try {
        this.videoElement.pause();
        this.videoElement.srcObject = null;
      } catch (e) {
        // ignore video pause error
      }
    }

    this.setStatus('off');
  }

  isActive() {
    return this.status === 'active' && !!this.stream && this.stream.active;
  }

  dispose() {
    this.stopCamera();
    this.videoElement = null;
    this.onStatusChange = null;
  }
}

export const cameraManager = new CameraManager();
