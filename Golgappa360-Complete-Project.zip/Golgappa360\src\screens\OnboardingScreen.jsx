import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Calendar, Activity, ChevronRight, Zap, CheckCircle2 } from 'lucide-react';
import { Button } from '../components/common/Button';

export const OnboardingScreen = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'Find Charging Stations',
      description: 'Discover nearby EV charging stations and check availability in real time.',
      badge: 'Real-Time Availability',
      icon: MapPin,
      renderVisual: () => (
        <div className="relative w-64 h-52 mx-auto flex items-center justify-center">
          {/* Map & EV Illustration */}
          <div className="absolute inset-0 bg-[#0D162B] rounded-3xl border border-white/10 overflow-hidden shadow-2xl flex items-center justify-center">
            {/* Grid Lines */}
            <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#00F5A0_1px,transparent_1px)] [background-size:16px_16px]" />

            {/* Simulated route road */}
            <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 opacity-40">
              <path
                d="M 20,80 Q 40,20 80,40"
                fill="none"
                stroke="#00F5A0"
                strokeWidth="4"
                strokeDasharray="4 2"
              />
            </svg>

            {/* EV Car Graphic */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="p-4 rounded-2xl bg-[#142345] border border-[#00F5A0]/40 shadow-[0_0_25px_rgba(0,245,160,0.25)] text-center">
                <span className="text-3xl">🚗</span>
                <span className="text-[10px] font-mono text-white block mt-1 font-bold">Tesla Model 3</span>
              </div>
            </div>

            {/* Station Pin */}
            <div className="absolute top-6 right-8 p-2.5 rounded-full bg-[#00F5A0] text-[#050811] shadow-[0_0_15px_#00F5A0] flex items-center justify-center">
              <Zap className="w-4 h-4 fill-[#050811]" />
            </div>

            {/* Distance pill */}
            <div className="absolute bottom-3 left-4 px-2 py-1 rounded-lg bg-[#070B19]/90 border border-white/15 text-[10px] text-white flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#00F5A0]" />
              <span>1.2 km away</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Book Your Charging Slot',
      description: 'Reserve your preferred charger before you arrive and avoid waiting lines.',
      badge: 'Zero Waiting Queue',
      icon: Calendar,
      renderVisual: () => (
        <div className="relative w-64 h-52 mx-auto flex items-center justify-center">
          <div className="w-full h-full bg-[#0D162B] rounded-3xl border border-white/10 p-4 shadow-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#00F5A0]" />
                <span className="text-xs font-bold text-white">24 Sep 2026</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-semibold border border-emerald-500/30">
                Slot Confirmed
              </span>
            </div>

            {/* Time Slot Chips */}
            <div className="space-y-2 py-1">
              <div className="flex items-center justify-between p-2 rounded-xl bg-[#00F5A0]/15 border border-[#00F5A0]/40 text-xs">
                <span className="font-semibold text-white">04:00 PM – 05:00 PM</span>
                <span className="text-[#00F5A0] font-bold text-[10px]">RESERVED</span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-[#131E35] border border-white/5 text-xs text-slate-400">
                <span>05:00 PM – 06:00 PM</span>
                <span className="text-emerald-400 text-[10px]">AVAILABLE</span>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 text-center bg-white/5 py-1.5 rounded-lg">
              ⚡ Charger 01 (60 kW Fast)
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Monitor Your Charging',
      description: 'Track battery, energy, power and charging status in real time right from your phone.',
      badge: 'IoT Connected Dashboard',
      icon: Activity,
      renderVisual: () => (
        <div className="relative w-64 h-52 mx-auto flex items-center justify-center">
          <div className="w-full h-full bg-[#0D162B] rounded-3xl border border-white/10 p-4 shadow-2xl flex flex-col items-center justify-between">
            {/* Header */}
            <div className="w-full flex items-center justify-between text-xs">
              <span className="text-slate-400">Telemetry Live</span>
              <span className="text-[#00F5A0] font-mono font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00F5A0] animate-pulse" />
                2.23 kW
              </span>
            </div>

            {/* Center Battery */}
            <div className="relative flex items-center justify-center">
              <div className="w-20 h-20 rounded-full border-4 border-[#00F5A0] border-t-transparent animate-spin" />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold font-mono text-white">78%</span>
                <span className="text-[9px] text-[#00F5A0] uppercase font-bold">Charging</span>
              </div>
            </div>

            {/* Mini Metrics */}
            <div className="w-full grid grid-cols-3 gap-1 text-center bg-[#070B19]/80 py-1.5 px-2 rounded-xl border border-white/5 text-[10px]">
              <div>
                <span className="text-slate-500 block">Voltage</span>
                <span className="text-white font-mono font-semibold">233 V</span>
              </div>
              <div>
                <span className="text-slate-500 block">Energy</span>
                <span className="text-white font-mono font-semibold">15.2 kWh</span>
              </div>
              <div>
                <span className="text-slate-500 block">Temp</span>
                <span className="text-white font-mono font-semibold">38°C</span>
              </div>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      navigate('/login');
    }
  };

  const current = steps[currentStep];

  return (
    <div className="min-h-[100dvh] w-full flex flex-col justify-between p-6 select-none bg-gradient-to-b from-[#070B19] via-[#091122] to-[#050811]">
      {/* Top Bar with Skip */}
      <div className="flex items-center justify-between pt-2">
        <span className="text-[11px] font-mono tracking-wider text-[#00F5A0] font-semibold">
          STEP 0{currentStep + 1} / 03
        </span>

        {currentStep < steps.length - 1 ? (
          <button
            onClick={() => navigate('/login')}
            className="text-xs font-semibold text-slate-400 hover:text-white px-3 py-1 rounded-lg hover:bg-white/5 transition-colors"
          >
            Skip
          </button>
        ) : (
          <div className="w-12" />
        )}
      </div>

      {/* Visual Illustration Area */}
      <div className="my-6">
        <div className="inline-block mx-auto mb-4 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-semibold text-slate-300">
          {current.badge}
        </div>
        {current.renderVisual()}
      </div>

      {/* Text Info */}
      <div className="text-center px-4">
        <h2 className="text-2xl font-bold text-white mb-2.5 tracking-tight">
          {current.title}
        </h2>
        <p className="text-sm text-slate-400 leading-relaxed max-w-xs mx-auto">
          {current.description}
        </p>
      </div>

      {/* Bottom Step Dots & Navigation */}
      <div className="space-y-5 pt-4">
        {/* Step dots */}
        <div className="flex items-center justify-center gap-2">
          {steps.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentStep
                  ? 'w-8 bg-[#00F5A0] shadow-[0_0_8px_#00F5A0]'
                  : 'w-2 bg-slate-700 hover:bg-slate-500'
              }`}
            />
          ))}
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          {currentStep === steps.length - 1 ? (
            <Button
              size="lg"
              fullWidth
              onClick={() => navigate('/login')}
              icon={CheckCircle2}
              iconPosition="right"
            >
              Get Started
            </Button>
          ) : (
            <Button
              size="lg"
              fullWidth
              onClick={handleNext}
              icon={ChevronRight}
              iconPosition="right"
            >
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
