import React from 'react';

/**
 * LifetimeComparison — "HOTTER DOESN'T MEAN LONGER"
 * Illustrates the core astrophysical paradox:
 * Massive hot stars consume hydrogen with ferocity and die in millions of years,
 * whereas quiet red dwarfs sip fuel for trillions of years.
 */
export default function LifetimeComparison() {
  const comparisons = [
    {
      type: 'Massive Blue Star',
      subtitle: 'Class O / B Supergiants (≈ 20 M☉)',
      lifetime: '≈ 10 Million Years',
      scalePercent: '4%',
      colorHex: '#38bdf8',
      glowColor: 'rgba(56, 189, 248, 0.4)',
      analogy: 'A high-powered racing engine burning its entire tank in minutes.',
      fate: 'Violent core-collapse supernova leaving a black hole or neutron star.',
    },
    {
      type: 'Sun-Like Star',
      subtitle: 'Class G Yellow Dwarfs (≈ 1.0 M☉)',
      lifetime: '≈ 10 Billion Years',
      scalePercent: '30%',
      colorHex: '#fbbf24',
      glowColor: 'rgba(251, 191, 36, 0.4)',
      analogy: 'A balanced commuter vehicle traveling reliably across billions of miles.',
      fate: 'Expands into a red giant, sheds a planetary nebula, and leaves a white dwarf.',
    },
    {
      type: 'Red Dwarf',
      subtitle: 'Class M Dwarfs (≈ 0.2 M☉)',
      lifetime: '≈ 1 to 10+ Trillion Years',
      scalePercent: '100%',
      colorHex: '#ef4444',
      glowColor: 'rgba(239, 68, 68, 0.4)',
      analogy: 'An ultra-efficient hybrid sipping fuel drop-by-drop for an eternity.',
      fate: 'Fully convective interior burns 100% of hydrogen; outlives the current Universe by 100×.',
    },
  ];

  return (
    <div className="w-full flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-white/10 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>STELLAR LIFESPAN PARADOX</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          HOTTER DOESN'T MEAN LONGER
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/85 leading-relaxed max-w-2xl mx-auto">
          Massive stars have vastly more fuel, but because luminosity scales as <strong className="text-cyan-300">L ∝ M<sup>3.5</sup></strong>,
          they burn through their reserves with terrifying speed. Less massive stars sip fuel with extreme frugality.
        </p>
      </div>

      {/* Main Comparison Container */}
      <div className="w-full p-6 sm:p-8 lg:p-10 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
        {/* Timeline Reference Flag */}
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-white/10 text-xs font-mono text-slate-400">
          <span>COSMOLOGICAL BENCHMARK:</span>
          <span className="text-amber-300 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            Current Age of the Universe ≈ 13.8 Billion Years
          </span>
        </div>

        {/* Visual Comparison Bars */}
        <div className="space-y-6 sm:space-y-8">
          {comparisons.map((item) => (
            <div key={item.type} className="flex flex-col gap-2 group">
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-sm font-mono">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: item.colorHex, boxShadow: `0 0 10px ${item.colorHex}` }}
                  />
                  <span className="font-display font-semibold text-base sm:text-lg text-white">
                    {item.type}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:inline">
                    ({item.subtitle})
                  </span>
                </div>
                <div className="font-bold text-base sm:text-lg" style={{ color: item.colorHex }}>
                  {item.lifetime}
                </div>
              </div>

              {/* Progress Bar Track */}
              <div className="relative h-6 sm:h-7 w-full rounded-xl bg-[#020308]/60 border border-white/8 p-1 overflow-hidden">
                <div
                  className="h-full rounded-lg transition-all duration-1000 ease-out flex items-center justify-end pr-2"
                  style={{
                    width: item.scalePercent,
                    backgroundColor: item.colorHex,
                    boxShadow: `0 0 20px ${item.glowColor}`,
                  }}
                >
                  <span className="text-[10px] font-mono text-black font-bold uppercase tracking-wider hidden sm:inline select-none">
                    {item.lifetime}
                  </span>
                </div>
              </div>

              {/* Contextual Narrative */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs text-slate-400 px-1">
                <span>{item.analogy}</span>
                <span className="text-slate-500 sm:text-right">{item.fate}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Key Takeaway Note */}
        <div className="mt-8 pt-6 border-t border-white/10 p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 flex items-start gap-3">
          <span className="text-cyan-400 text-lg">💡</span>
          <p className="text-xs sm:text-sm text-cyan-200/90 leading-relaxed font-normal">
            <strong>Key Astrobiological Takeaway:</strong> High-mass blue stars explode too quickly for complex planetary systems or biological life to develop. Stable G and K stars, and possibly quiet red dwarfs, provide the multi-billion-year stability necessary for evolution.
          </p>
        </div>
      </div>
    </div>
  );
}
