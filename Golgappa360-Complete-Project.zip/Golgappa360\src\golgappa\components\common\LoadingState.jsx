import React from 'react';

export function LoadingState({ rows = 4 }) {
  return (
    <div className="w-full space-y-4 animate-pulse p-4">
      <div className="h-8 bg-white/10 rounded-xl w-1/4"></div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-28 glass-card border border-white/10 rounded-2xl"></div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
        <div className="lg:col-span-2 h-72 glass-card border border-white/10 rounded-2xl"></div>
        <div className="h-72 glass-card border border-white/10 rounded-2xl"></div>
      </div>
    </div>
  );
}
