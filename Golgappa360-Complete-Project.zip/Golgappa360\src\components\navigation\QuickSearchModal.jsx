import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Sparkles, Music, Mic, ArrowRight } from "lucide-react";
import { searchService } from "../../services/searchService";
import { Modal } from "../common/Modal";

export const QuickSearchModal = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    if (query.trim().length > 1) {
      searchService.search({ query, type: "all" }).then((res) => {
        if (active) setResults(res.songs.slice(0, 5));
      });
    } else {
      setResults([]);
    }
    return () => {
      active = false;
    };
  }, [query]);

  const handleSelect = (url) => {
    onClose();
    navigate(url);
  };

  const handleFullSearch = () => {
    if (!query.trim()) return;
    onClose();
    navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Quick Find & Jump" maxWidth="max-w-xl">
      <div className="space-y-4">
        {/* Search input inside modal */}
        <div className="flex items-center gap-3 px-3.5 py-3 rounded-xl bg-white/[0.05] border border-white/10 focus-within:border-purple-500/80">
          <Search className="w-5 h-5 text-purple-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleFullSearch()}
            autoFocus
            placeholder="Type lyrics, song title, or artist..."
            className="w-full bg-transparent text-white placeholder-slate-400 focus:outline-none text-sm"
          />
          {query && (
            <button
              onClick={handleFullSearch}
              className="px-2.5 py-1 rounded-lg bg-purple-600 text-xs font-semibold text-white hover:bg-purple-500"
            >
              Search
            </button>
          )}
        </div>

        {/* Dynamic results list */}
        {results.length > 0 ? (
          <div className="space-y-1 max-h-60 overflow-y-auto">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2">
              Songs matching lyrics / title
            </span>
            {results.map((song) => (
              <div
                key={song.id}
                onClick={() => handleSelect(`/song/${song.id}`)}
                className="flex items-center justify-between p-2.5 rounded-xl hover:bg-white/[0.08] cursor-pointer group transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={song.coverUrl}
                    alt={song.title}
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate group-hover:text-purple-300">
                      {song.title}
                    </p>
                    <p className="text-xs text-slate-400 truncate">{song.artist}</p>
                  </div>
                </div>
                <span className="text-[11px] text-emerald-400 font-mono shrink-0 ml-2">
                  {song.matchPercentage}% match
                </span>
              </div>
            ))}
          </div>
        ) : query.trim() ? (
          <div className="py-6 text-center text-xs text-slate-400">
            No instant matches found. Press Enter to perform a deeper catalog search.
          </div>
        ) : (
          /* Quick Jump Shortcuts */
          <div className="space-y-2 pt-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-1">
              Explore Shortcuts
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleSelect("/ai-search")}
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white/[0.03] hover:bg-purple-500/10 border border-white/[0.06] text-left text-xs text-slate-200 transition-colors"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>AI Natural Language Search</span>
              </button>
              <button
                onClick={() => handleSelect("/trending")}
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white/[0.03] hover:bg-purple-500/10 border border-white/[0.06] text-left text-xs text-slate-200 transition-colors"
              >
                <Music className="w-4 h-4 text-purple-400" />
                <span>Trending Hits & Charts</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
