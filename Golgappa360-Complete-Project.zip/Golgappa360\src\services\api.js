// Central API Client for connecting Mobile Frontend to Node.js + Express + MongoDB Backend
const getDefaultBaseUrl = () => {
  if (typeof window !== 'undefined' && window.location && window.location.hostname && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
    return `${window.location.protocol}//${window.location.hostname}:5000/api`;
  }
  return 'http://localhost:5000/api';
};

const API_BASE_URL = import.meta.env.VITE_API_URL || getDefaultBaseUrl();

const getAuthHeaders = () => {
  const token = localStorage.getItem('ev_smart_token');
  const headers = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

export const api = {
  get: async (endpoint) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'GET',
        headers: getAuthHeaders(),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `GET ${endpoint} failed: ${response.status}`);
      }
      return data;
    } catch (err) {
      console.warn(`[API Client GET Error] ${endpoint}:`, err.message);
      throw err;
    }
  },

  post: async (endpoint, body) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `POST ${endpoint} failed: ${response.status}`);
      }
      return data;
    } catch (err) {
      console.warn(`[API Client POST Error] ${endpoint}:`, err.message);
      throw err;
    }
  },

  put: async (endpoint, body = {}) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `PUT ${endpoint} failed: ${response.status}`);
      }
      return data;
    } catch (err) {
      console.warn(`[API Client PUT Error] ${endpoint}:`, err.message);
      throw err;
    }
  },

  patch: async (endpoint, body = {}) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `PATCH ${endpoint} failed: ${response.status}`);
      }
      return data;
    } catch (err) {
      console.warn(`[API Client PATCH Error] ${endpoint}:`, err.message);
      throw err;
    }
  },

  delete: async (endpoint) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `DELETE ${endpoint} failed: ${response.status}`);
      }
      return data;
    } catch (err) {
      console.warn(`[API Client DELETE Error] ${endpoint}:`, err.message);
      throw err;
    }
  },
};

export default api;
