import { albums } from "../data/albums.js";
import { songs } from "../data/songs.js";
import { artists } from "../data/artists.js";

export const albumService = {
  async getAllAlbums() {
    return [...albums];
  },

  async getAlbumById(id) {
    const album = albums.find((a) => a.id === id);
    if (!album) return null;

    const albumSongs = songs.filter((s) => s.albumId === id);
    const artist = artists.find((a) => a.id === album.artistId);

    // Calculate Album Insights
    const totalDurationSec = albumSongs.reduce((acc, s) => acc + (s.durationSec || 200), 0);
    const avgSec = albumSongs.length ? Math.round(totalDurationSec / albumSongs.length) : 210;
    const avgMins = Math.floor(avgSec / 60);
    const avgSecs = avgSec % 60;
    const formattedAvgDuration = `${avgMins}:${avgSecs < 10 ? "0" : ""}${avgSecs}`;

    // Compute dominant language
    const langCounts = {};
    albumSongs.forEach((s) => {
      langCounts[s.language] = (langCounts[s.language] || 0) + 1;
    });
    const primaryLanguage = Object.keys(langCounts).length
      ? Object.entries(langCounts).sort((a, b) => b[1] - a[1])[0][0]
      : "Multi-language";

    const insights = {
      releaseYear: album.year,
      totalTracks: albumSongs.length || album.trackCount,
      averagePopularity: "3.8M plays avg",
      mainGenre: album.genres?.[0] || "Contemporary",
      primaryLanguage,
      averageDuration: formattedAvgDuration,
      totalDuration: album.duration || `${Math.round(totalDurationSec / 60)} min`
    };

    return {
      ...album,
      artistData: artist,
      tracks: albumSongs,
      insights
    };
  },

  async getSimilarAlbums(albumId, limit = 4) {
    const current = albums.find((a) => a.id === albumId);
    if (!current) return albums.slice(0, limit);

    const scored = albums
      .filter((a) => a.id !== albumId)
      .map((alb) => {
        let score = 0;
        const sharedGenres = alb.genres?.filter((g) => current.genres?.includes(g)) || [];
        score += sharedGenres.length * 40;
        if (Math.abs(alb.year - current.year) <= 2) score += 20;
        if (alb.artistId === current.artistId) score += 30;
        return { album: alb, score };
      });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit).map((item) => item.album);
  }
};
