-- =====================================================================
-- Golgappa360 — Advanced SQL Analytics Query Library
-- Database: MySQL 8.0+
-- Project: Golgappa Business Intelligence & Sales Analytics System
-- Description: 30 Master Analytics Queries covering MCA Curriculum,
--              Financial Accounting, Inventory Control, and Tableau BI.
-- =====================================================================

USE golgappa360;

-- =====================================================================
-- CATEGORY 1: Basic SELECT, WHERE and ORDER BY
-- =====================================================================

-- Query 01: Recent High-Value Orders
-- Purpose: Retrieves recent customer transactions where total plates >= 3,
-- sorted by transaction timestamp in descending order.
SELECT 
    s.sale_id,
    s.sale_datetime,
    s.payment_method,
    s.discount,
    si.product_id,
    si.quantity_plates,
    si.unit_price,
    ROUND((si.quantity_plates * si.unit_price) - s.discount, 2) AS net_order_amount
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
WHERE si.quantity_plates >= 3
ORDER BY s.sale_datetime DESC
LIMIT 20;


-- =====================================================================
-- CATEGORY 2: Aggregate Functions (SUM, AVG, MIN, MAX, COUNT)
-- =====================================================================

-- Query 02: Cumulative System-Wide Financial Totals
-- Purpose: Computes total gross turnover, promotional discounts, net revenue,
-- average order value (AOV), average selling price (ASP), and plates count.
SELECT 
    COUNT(DISTINCT s.sale_id) AS total_orders_count,
    SUM(si.quantity_plates) AS total_plates_served,
    ROUND(SUM(si.quantity_plates * si.unit_price), 2) AS gross_turnover_inr,
    ROUND(SUM(s.discount), 2) AS total_discounts_inr,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS net_revenue_inr,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) / COUNT(DISTINCT s.sale_id), 2) AS average_order_value_inr,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) / SUM(si.quantity_plates), 2) AS average_selling_price_per_plate_inr
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id;


-- =====================================================================
-- CATEGORY 3: GROUP BY and HAVING
-- =====================================================================

-- Query 03: High-Volume Operational Days (Surge Auditing)
-- Purpose: Groups sales by calendar date and filters for days where net revenue
-- exceeded ₹12,000 using the HAVING clause.
SELECT 
    DATE(s.sale_datetime) AS operational_date,
    DAYNAME(s.sale_datetime) AS day_of_week,
    COUNT(DISTINCT s.sale_id) AS total_orders,
    SUM(si.quantity_plates) AS total_plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS daily_net_revenue
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY DATE(s.sale_datetime), DAYNAME(s.sale_datetime)
HAVING daily_net_revenue > 12000.00
ORDER BY daily_net_revenue DESC;


-- =====================================================================
-- CATEGORY 4: INNER JOIN (Multi-Table Relational Linkage)
-- =====================================================================

-- Query 04: Order Itemization with Product BOM Cost
-- Purpose: Joins sales, sale_items, and products to evaluate the unit gross margin
-- contribution of individual order line items.
SELECT 
    s.sale_id,
    s.sale_datetime,
    p.product_id,
    p.product_name,
    p.category,
    si.quantity_plates,
    si.unit_price,
    ROUND(si.quantity_plates * si.unit_price, 2) AS line_gross_sales,
    ROUND(si.quantity_plates * p.ingredient_cost_per_plate, 2) AS line_cogs,
    ROUND((si.quantity_plates * si.unit_price) - (si.quantity_plates * p.ingredient_cost_per_plate), 2) AS line_gross_profit,
    ROUND(
        (((si.quantity_plates * si.unit_price) - (si.quantity_plates * p.ingredient_cost_per_plate)) / 
        (si.quantity_plates * si.unit_price)) * 100, 1
    ) AS line_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id
ORDER BY s.sale_datetime DESC
LIMIT 25;


-- =====================================================================
-- CATEGORY 5: LEFT JOIN (Comprehensive Catalog Analysis)
-- =====================================================================

-- Query 05: Product Master Sales Coverage
-- Purpose: Employs LEFT JOIN to inspect sales volume for every product in the master table,
-- ensuring no catalog SKUs are omitted even if unserved.
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2), 0.00) AS net_revenue_generated
FROM products p
LEFT JOIN sale_items si ON p.product_id = si.product_id
LEFT JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate
ORDER BY net_revenue_generated DESC;


-- =====================================================================
-- CATEGORY 6: Subqueries (Scalar & Correlated)
-- =====================================================================

-- Query 06: Orders Exceeding System Average Ticket Size (Scalar Subquery)
-- Purpose: Filters orders whose net value is higher than the overall average order value.
SELECT 
    s.sale_id,
    s.sale_datetime,
    s.payment_method,
    ROUND((si.quantity_plates * si.unit_price) - s.discount, 2) AS order_total
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
WHERE ((si.quantity_plates * si.unit_price) - s.discount) > (
    SELECT AVG((si2.quantity_plates * si2.unit_price) - s2.discount)
    FROM sales s2
    JOIN sale_items si2 ON s2.sale_id = si2.sale_id
)
ORDER BY order_total DESC
LIMIT 20;

-- Query 07: Product Share within its Category (Correlated Subquery)
-- Purpose: Uses a correlated subquery to determine each variety's percentage of total category turnover.
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS product_net_revenue,
    ROUND(
        ((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) / 
        (
            SELECT SUM(si_cat.quantity_plates * si_cat.unit_price) - SUM(s_cat.discount)
            FROM products p_cat
            JOIN sale_items si_cat ON p_cat.product_id = si_cat.product_id
            JOIN sales s_cat ON si_cat.sale_id = s_cat.sale_id
            WHERE p_cat.category = p.category
        )) * 100, 1
    ) AS category_revenue_share_pct
FROM products p
JOIN sale_items si ON p.product_id = si.product_id
JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY p.category, product_net_revenue DESC;


-- =====================================================================
-- CATEGORY 7: CASE Expressions (Conditional Categorization)
-- =====================================================================

-- Query 08: Operational Surge Window Classification
-- Purpose: Classifies operational hours into descriptive footfall intensity tiers for prep staff.
SELECT 
    EXTRACT(HOUR FROM s.sale_datetime) AS operational_hour,
    CASE 
        WHEN EXTRACT(HOUR FROM s.sale_datetime) IN (15, 16) THEN 'Afternoon Opening & Warmup'
        WHEN EXTRACT(HOUR FROM s.sale_datetime) = 17 THEN 'Commuter Surge Kickoff'
        WHEN EXTRACT(HOUR FROM s.sale_datetime) IN (18, 19) THEN 'Peak Family & Chaat Rush'
        WHEN EXTRACT(HOUR FROM s.sale_datetime) = 20 THEN 'Post-Dinner Walk-in Traffic'
        ELSE 'Late Evening Wrap & Sukha Puri'
    END AS operational_window_label,
    COUNT(DISTINCT s.sale_id) AS orders_served,
    SUM(si.quantity_plates) AS plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS window_revenue
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY operational_hour, operational_window_label
ORDER BY operational_hour ASC;

-- Query 09: Gross Margin Health Segmentation
-- Purpose: Categorizes menu items into margin health tiers based on gross margin percentage.
SELECT 
    p.product_name,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(((p.selling_price - p.ingredient_cost_per_plate) / p.selling_price) * 100, 1) AS gross_margin_pct,
    CASE 
        WHEN ((p.selling_price - p.ingredient_cost_per_plate) / p.selling_price) >= 0.73 THEN 'High Yield (Tier 1)'
        WHEN ((p.selling_price - p.ingredient_cost_per_plate) / p.selling_price) >= 0.70 THEN 'Healthy Margin (Tier 2)'
        ELSE 'Margin Review Required (Tier 3)'
    END AS margin_health_status
FROM products p
ORDER BY gross_margin_pct DESC;


-- =====================================================================
-- CATEGORY 8: Date Functions (EXTRACT, DAYNAME, DATE_FORMAT, DATEDIFF)
-- =====================================================================

-- Query 10: Day of Week Performance Profiling
-- Purpose: Aggregates historical volume and revenue across weekdays to identify weekend surges.
SELECT 
    DAYNAME(s.sale_datetime) AS day_of_the_week,
    DAYOFWEEK(s.sale_datetime) AS day_index, -- 1 = Sunday, 7 = Saturday
    COUNT(DISTINCT s.sale_id) AS total_orders,
    SUM(si.quantity_plates) AS total_plates,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS total_revenue,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) / COUNT(DISTINCT DATE(s.sale_datetime)), 2) AS avg_daily_turnover
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY DAYNAME(s.sale_datetime), DAYOFWEEK(s.sale_datetime)
ORDER BY day_index ASC;

-- Query 11: 30-Day Moving Window Performance
-- Purpose: Filters transactions from the last 30 operational days relative to anchor date.
SELECT 
    DATE(s.sale_datetime) AS sale_date,
    COUNT(DISTINCT s.sale_id) AS orders_count,
    SUM(si.quantity_plates) AS plates_count,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS daily_revenue
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
WHERE s.sale_datetime >= '2026-09-30'
GROUP BY DATE(s.sale_datetime)
ORDER BY sale_date ASC;


-- =====================================================================
-- CATEGORY 9: Top-Selling Products
-- =====================================================================

-- Query 12: Variety Popularity & Volume Ranking
-- Purpose: Ranks products by total plates sold and calculates their percentage volume share.
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    SUM(si.quantity_plates) AS plates_sold,
    ROUND((SUM(si.quantity_plates) / (SELECT SUM(quantity_plates) FROM sale_items)) * 100, 1) AS volume_share_pct,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS total_net_revenue,
    DENSE_RANK() OVER (ORDER BY SUM(si.quantity_plates) DESC) AS popularity_rank
FROM products p
JOIN sale_items si ON p.product_id = si.product_id
JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price
ORDER BY popularity_rank ASC;


-- =====================================================================
-- CATEGORY 10: Products with No Sales or Bottom Performers
-- =====================================================================

-- Query 13: Bottom Performing Varieties Analysis
-- Purpose: Identifies the lowest volume contributors in the menu for potential recipe reformulation.
SELECT 
    p.product_id,
    p.product_name,
    p.selling_price,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2), 0.00) AS total_turnover
FROM products p
LEFT JOIN sale_items si ON p.product_id = si.product_id
LEFT JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.selling_price
ORDER BY total_plates_sold ASC
LIMIT 3;


-- =====================================================================
-- CATEGORY 11: Daily and Monthly Revenue Trends
-- =====================================================================

-- Query 14: Daily Financial Trajectory
-- Purpose: Full daily revenue, COGS, gross profit, and gross margin % across operational history.
SELECT 
    DATE(s.sale_datetime) AS order_date,
    COUNT(DISTINCT s.sale_id) AS orders_count,
    SUM(si.quantity_plates) AS plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS net_revenue,
    ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS cogs,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS gross_profit,
    ROUND(
        (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount))) * 100, 1
    ) AS daily_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id
GROUP BY DATE(s.sale_datetime)
ORDER BY order_date ASC;

-- Query 15: Monthly Executive P&L Overview
-- Purpose: Aggregates revenue, ingredient COGS, gross profit, and margin % by calendar month.
SELECT 
    DATE_FORMAT(s.sale_datetime, '%Y-%m') AS operational_month,
    DATE_FORMAT(s.sale_datetime, '%M %Y') AS month_label,
    COUNT(DISTINCT s.sale_id) AS total_orders,
    SUM(si.quantity_plates) AS total_plates,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS monthly_net_revenue,
    ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS monthly_cogs,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS monthly_gross_profit,
    ROUND(
        (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount))) * 100, 1
    ) AS monthly_gross_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id
GROUP BY DATE_FORMAT(s.sale_datetime, '%Y-%m'), DATE_FORMAT(s.sale_datetime, '%M %Y')
ORDER BY operational_month ASC;


-- =====================================================================
-- CATEGORY 12: Gross Profit by Product
-- =====================================================================

-- Query 16: Menu Item Unit Economics & Margin Matrix
-- Purpose: Evaluates each variety's absolute gross profit contribution and ranking.
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_margin_inr,
    SUM(si.quantity_plates) AS total_plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS net_revenue,
    ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_cogs,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_gross_profit,
    ROUND(
        (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount))) * 100, 1
    ) AS gross_margin_pct
FROM products p
JOIN sale_items si ON p.product_id = si.product_id
JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate
ORDER BY total_gross_profit DESC;


-- =====================================================================
-- CATEGORY 13: Payment Method Comparison (UPI vs Cash)
-- =====================================================================

-- Query 17: Digital Adoption & Settlement Breakdown
-- Purpose: Compares UPI QR code transactions against physical cash transactions.
SELECT 
    s.payment_method,
    COUNT(s.sale_id) AS transaction_count,
    ROUND((COUNT(s.sale_id) / (SELECT COUNT(*) FROM sales)) * 100, 1) AS transaction_count_share_pct,
    ROUND(SUM((si.quantity_plates * si.unit_price) - s.discount), 2) AS total_turnover_inr,
    ROUND((SUM((si.quantity_plates * si.unit_price) - s.discount) / (
        SELECT SUM((si2.quantity_plates * si2.unit_price) - s2.discount)
        FROM sales s2 JOIN sale_items si2 ON s2.sale_id = si2.sale_id
    )) * 100, 1) AS revenue_share_pct,
    ROUND(AVG((si.quantity_plates * si.unit_price) - s.discount), 2) AS avg_ticket_size_inr
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY s.payment_method
ORDER BY total_turnover_inr DESC;


-- =====================================================================
-- CATEGORY 14: Hourly Sales Trends
-- =====================================================================

-- Query 18: Peak Commuter Surge Analysis by Hour
-- Purpose: Identifies hourly sales distribution between 3:00 PM and 10:00 PM to schedule fresh pani refills.
SELECT 
    EXTRACT(HOUR FROM s.sale_datetime) AS hour_24,
    CONCAT(
        CASE WHEN EXTRACT(HOUR FROM s.sale_datetime) > 12 THEN EXTRACT(HOUR FROM s.sale_datetime) - 12 ELSE EXTRACT(HOUR FROM s.sale_datetime) END,
        ':00 ',
        CASE WHEN EXTRACT(HOUR FROM s.sale_datetime) >= 12 THEN 'PM' ELSE 'AM' END
    ) AS display_hour,
    COUNT(DISTINCT s.sale_id) AS orders_count,
    SUM(si.quantity_plates) AS plates_sold,
    ROUND(SUM((si.quantity_plates * si.unit_price) - s.discount), 2) AS total_revenue,
    ROUND(
        (SUM((si.quantity_plates * si.unit_price) - s.discount) / (
            SELECT SUM((si2.quantity_plates * si2.unit_price) - s2.discount)
            FROM sales s2 JOIN sale_items si2 ON s2.sale_id = si2.sale_id
        )) * 100, 1
    ) AS pct_of_daily_sales
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY EXTRACT(HOUR FROM s.sale_datetime)
ORDER BY hour_24 ASC;


-- =====================================================================
-- CATEGORY 15: Low-Stock Ingredients (Procurement Warning)
-- =====================================================================

-- Query 19: Raw Material Inventory Reorder Alert
-- Purpose: Computes ending stock on hand and flags raw materials that breached safety reorder levels.
WITH CurrentStockCTE AS (
    SELECT 
        ingredient_id,
        SUM(CASE WHEN transaction_type = 'PURCHASE' THEN quantity ELSE 0 END) AS total_purchased,
        SUM(CASE WHEN transaction_type = 'CONSUMPTION' THEN quantity ELSE 0 END) AS total_consumed,
        SUM(CASE WHEN transaction_type = 'WASTE' THEN quantity ELSE 0 END) AS total_wasted
    FROM inventory_transactions
    GROUP BY ingredient_id
)
SELECT 
    i.ingredient_id,
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    i.reorder_level,
    ROUND(cs.total_purchased - cs.total_consumed - cs.total_wasted, 2) AS on_hand_stock,
    CASE 
        WHEN (cs.total_purchased - cs.total_consumed - cs.total_wasted) <= (i.reorder_level * 0.5) THEN 'CRITICAL ALERT'
        WHEN (cs.total_purchased - cs.total_consumed - cs.total_wasted) <= i.reorder_level THEN 'REORDER REQUIRED'
        ELSE 'OPTIMAL STOCK'
    END AS procurement_urgency
FROM ingredients i
JOIN CurrentStockCTE cs ON i.ingredient_id = cs.ingredient_id
ORDER BY on_hand_stock ASC;


-- =====================================================================
-- CATEGORY 16: Inventory Transaction History
-- =====================================================================

-- Query 20: Raw Material Stock Ledger Audit
-- Purpose: Tracks the last 25 inventory movements categorized into PURCHASE, CONSUMPTION, or WASTE.
SELECT 
    t.transaction_id,
    t.transaction_date,
    i.ingredient_name,
    t.transaction_type,
    t.quantity,
    i.unit,
    ROUND(t.quantity * i.unit_cost, 2) AS transaction_cost_value_inr,
    t.reference_id
FROM inventory_transactions t
JOIN ingredients i ON t.ingredient_id = i.ingredient_id
ORDER BY t.transaction_date DESC, t.transaction_id DESC
LIMIT 25;


-- =====================================================================
-- CATEGORY 17: Recorded Waste Cost & Shrinkage
-- =====================================================================

-- Query 21: Food Spoilage & Financial Shrinkage by Ingredient
-- Purpose: Calculates financial loss from broken puris, souring pani, and fermented potato mash.
SELECT 
    i.ingredient_id,
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    SUM(t.quantity) AS total_wasted_units,
    ROUND(SUM(t.quantity * i.unit_cost), 2) AS total_waste_financial_impact_inr,
    ROUND(
        (SUM(t.quantity * i.unit_cost) / (
            SELECT SUM(t2.quantity * i2.unit_cost)
            FROM inventory_transactions t2 JOIN ingredients i2 ON t2.ingredient_id = i2.ingredient_id
            WHERE t2.transaction_type = 'WASTE'
        )) * 100, 1
    ) AS waste_cost_share_pct
FROM inventory_transactions t
JOIN ingredients i ON t.ingredient_id = i.ingredient_id
WHERE t.transaction_type = 'WASTE'
GROUP BY i.ingredient_id, i.ingredient_name, i.unit, i.unit_cost
ORDER BY total_waste_financial_impact_inr DESC;


-- =====================================================================
-- CATEGORY 18: Expenses by Category
-- =====================================================================

-- Query 22: Operating Overhead Breakdown
-- Purpose: Analyzes stall operating expenses (rent, packaging dona, power/ice, LPG gas, rickshaw freight).
SELECT 
    expense_category,
    COUNT(expense_id) AS recorded_days,
    ROUND(SUM(amount), 2) AS total_expense_inr,
    ROUND((SUM(amount) / (SELECT SUM(amount) FROM daily_expenses)) * 100, 1) AS category_share_pct,
    ROUND(AVG(amount), 2) AS avg_daily_cost_inr
FROM daily_expenses
GROUP BY expense_category
ORDER BY total_expense_inr DESC;


-- =====================================================================
-- CATEGORY 19: Data-Quality Checks & Integrity Auditing
-- =====================================================================

-- Query 23: Data Quality Check 1 — Orphaned Sale Items (Referential Integrity)
-- Purpose: Ensures every sale_item references a valid existing sale header. Should return 0 rows.
SELECT si.sale_item_id, si.sale_id, si.product_id
FROM sale_items si
LEFT JOIN sales s ON si.sale_id = s.sale_id
WHERE s.sale_id IS NULL;

-- Query 24: Data Quality Check 2 — Pricing & Discount Validity
-- Purpose: Flags any record with negative quantities, zero unit price, or discount > gross order. Should return 0 rows.
SELECT 
    s.sale_id,
    si.quantity_plates,
    si.unit_price,
    s.discount,
    (si.quantity_plates * si.unit_price) AS gross_amount
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
WHERE si.quantity_plates <= 0 
   OR si.unit_price <= 0 
   OR s.discount < 0 
   OR s.discount >= (si.quantity_plates * si.unit_price);

-- Query 25: Data Quality Check 3 — Inventory Ledger Non-Negativity Verification
-- Purpose: Asserts that total purchases >= total consumption + total waste for each ingredient.
WITH InventoryAudit AS (
    SELECT 
        ingredient_id,
        SUM(CASE WHEN transaction_type = 'PURCHASE' THEN quantity ELSE 0 END) AS total_purchased,
        SUM(CASE WHEN transaction_type IN ('CONSUMPTION', 'WASTE') THEN quantity ELSE 0 END) AS total_deducted
    FROM inventory_transactions
    GROUP BY ingredient_id
)
SELECT 
    i.ingredient_name,
    ia.total_purchased,
    ia.total_deducted,
    (ia.total_purchased - ia.total_deducted) AS ending_balance,
    CASE WHEN (ia.total_purchased - ia.total_deducted) >= 0 THEN 'PASSED' ELSE 'FAILED - NEGATIVE STOCK' END AS integrity_status
FROM InventoryAudit ia
JOIN ingredients i ON ia.ingredient_id = i.ingredient_id;


-- =====================================================================
-- CATEGORY 20: Analytical Views & Tableau BI Blueprints
-- =====================================================================

-- Query 26: Full 6-Month P&L Statement (Executive Profitability)
-- Purpose: Synthesizes Net Revenue, COGS, Gross Profit, Operating Expenses, and Estimated Operating Profit.
SELECT 
    (SELECT net_revenue FROM vw_dashboard_kpis) AS net_revenue_inr,
    (SELECT total_cogs FROM vw_dashboard_kpis) AS cogs_inr,
    (SELECT gross_profit FROM vw_dashboard_kpis) AS gross_profit_inr,
    (SELECT gross_margin_pct FROM vw_dashboard_kpis) AS gross_margin_pct,
    ROUND((SELECT SUM(amount) FROM daily_expenses), 2) AS operating_expenses_inr,
    ROUND((SELECT gross_profit FROM vw_dashboard_kpis) - (SELECT SUM(amount) FROM daily_expenses), 2) AS estimated_operating_profit_inr,
    ROUND(
        (((SELECT gross_profit FROM vw_dashboard_kpis) - (SELECT SUM(amount) FROM daily_expenses)) / 
        (SELECT net_revenue FROM vw_dashboard_kpis)) * 100, 1
    ) AS operating_margin_pct;

-- Query 27: Top Varieties by Profit Contribution (Tableau Source)
-- Purpose: Queries View vw_product_performance for Tableau Pareto chart.
SELECT 
    product_name,
    category,
    total_plates_sold,
    net_revenue,
    gross_profit,
    gross_margin_pct
FROM vw_product_performance
ORDER BY gross_profit DESC;

-- Query 28: Daily Business Health (Tableau Area Chart Feed)
-- Purpose: Queries View vw_daily_financial_summary for time-series visualization.
SELECT 
    sale_date,
    day_of_week,
    orders_count,
    plates_sold,
    net_revenue,
    gross_profit,
    operating_expenses,
    estimated_operating_profit
FROM vw_daily_financial_summary
ORDER BY sale_date ASC;

-- Query 29: Ingredient Runway & Reorder Urgency (Tableau Alert Feed)
-- Purpose: Queries View vw_inventory_status for inventory gauge charts.
SELECT 
    ingredient_name,
    unit,
    current_stock,
    reorder_level,
    inventory_value,
    stock_status
FROM vw_inventory_status
ORDER BY current_stock ASC;

-- Query 30: 7-Day Rolling Moving Average of Net Turnover (Window Function)
-- Purpose: Computes rolling 7-day average using OVER (ROWS BETWEEN 6 PRECEDING AND CURRENT ROW).
WITH DailySeries AS (
    SELECT 
        DATE(s.sale_datetime) AS order_date,
        SUM((si.quantity_plates * si.unit_price) - s.discount) AS daily_revenue
    FROM sales s
    JOIN sale_items si ON s.sale_id = si.sale_id
    GROUP BY DATE(s.sale_datetime)
)
SELECT 
    order_date,
    ROUND(daily_revenue, 2) AS daily_net_revenue,
    ROUND(AVG(daily_revenue) OVER (
        ORDER BY order_date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_7day_avg_revenue
FROM DailySeries
ORDER BY order_date ASC;
