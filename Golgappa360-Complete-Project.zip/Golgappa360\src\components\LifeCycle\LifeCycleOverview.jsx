import React from 'react';
import { PRIMARY_OVERVIEW_STAGES } from '../../data/lifeCycleStages';

/**
 * LifeCycleOverview — Interactive 5-stage milestone track
 * 1. MOLECULAR CLOUD
 * 2. PROTOSTAR
 * 3. MAIN SEQUENCE
 * 4. RED GIANT / SUPERGIANT
 * 5. FINAL STAGE
 * Connected with glowing animated path lines and HUD observation nodes.
 */
export default function LifeCycleOverview({ activeStageId, onSelectStage }) {
  // Map stage to one of the 5 overview steps
  const getStepIndex = (id) => {
    if (id === 'molecular-cloud') return 0;
    if (id === 'protostar') return 1;
    if (id === 'main-sequence') return 2;
    if (id === 'red-giant' || id === 'supergiant') return 3;
    return 4; // planetary-nebula, supernova, white-dwarf, neutron-star, black-hole
  };

  const currentStep = getStepIndex(activeStageId);

  return (
    <div className="w-full flex flex-col items-center select-none">
      {/* Telemetry Header */}
      <div className="flex items-center justify-between w-full max-w-5xl px-2 mb-3 text-[11px] font-mono text-slate-400">
        <span className="flex items-center gap-2 text-cyan-400">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span>PRIMARY CHRONOLOGICAL SEQUENCE</span>
        </span>
        <span className="text-slate-500 hidden sm:inline">
          INTERACTIVE OBSERVATION TRACK
        </span>
      </div>

      {/* Main Track Container */}
      <div className="w-full max-w-5xl p-4 sm:p-6 rounded-3xl glass-surface border border-white/10 shadow-[0_15px_40px_rgba(0,0,0,0.6)] relative">
        {/* Connecting Glowing Line (Desktop / Tablet) */}
        <div
          aria-hidden="true"
          className="hidden md:block absolute top-[44px] left-[10%] right-[10%] h-[2px] bg-white/10 -z-0"
        >
          {/* Animated active progress fill */}
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-amber-400 via-rose-500 to-cyan-400 transition-all duration-700 ease-out shadow-[0_0_12px_#38bdf8]"
            style={{ width: `${(currentStep / 4) * 100}%` }}
          />
        </div>

        {/* 5 Interactive Milestone Nodes */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 sm:gap-2 relative z-10">
          {PRIMARY_OVERVIEW_STAGES.map((stage, index) => {
            const isSelected = currentStep === index;
            const isPassed = currentStep >= index;

            return (
              <button
                key={stage.id}
                type="button"
                onClick={() => onSelectStage(stage.id)}
                className={`flex flex-row sm:flex-col items-center justify-between sm:justify-center p-3 sm:p-4 rounded-2xl transition-all duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 text-left sm:text-center ${
                  isSelected
                    ? 'bg-white/10 border border-cyan-400/60 shadow-[0_0_25px_rgba(56,189,248,0.3)] scale-[1.02]'
                    : isPassed
                    ? 'hover:bg-white/5 border border-white/10 opacity-90'
                    : 'hover:bg-white/5 border border-transparent opacity-60 hover:opacity-100'
                }`}
              >
                {/* Node Sphere & Step Indicator */}
                <div className="flex items-center gap-3 sm:flex-col sm:gap-2 mb-0 sm:mb-2">
                  <div
                    className={`relative w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition-all duration-300 font-mono text-xs font-bold ${
                      isSelected
                        ? 'text-slate-950 scale-110'
                        : isPassed
                        ? 'text-white'
                        : 'text-slate-400'
                    }`}
                    style={{
                      backgroundColor: isSelected ? stage.color : isPassed ? '#1e293b' : '#0f172a',
                      border: `2px solid ${isPassed ? stage.color : 'rgba(255,255,255,0.1)'}`,
                      boxShadow: isSelected ? `0 0 20px ${stage.color}` : 'none',
                    }}
                  >
                    <span>0{index + 1}</span>
                    {isSelected && (
                      <span
                        aria-hidden="true"
                        className="absolute -inset-1 rounded-full border border-cyan-400/60 animate-ping pointer-events-none"
                        style={{ animationDuration: '2.5s' }}
                      />
                    )}
                  </div>

                  <div className="sm:hidden text-left">
                    <span className="font-display font-semibold text-sm text-white block">
                      {stage.shortName}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      Phase 0{index + 1}
                    </span>
                  </div>
                </div>

                {/* Node Label (Desktop / Tablet) */}
                <div className="hidden sm:flex flex-col items-center">
                  <span
                    className={`font-display text-xs sm:text-sm font-semibold tracking-tight transition-colors ${
                      isSelected ? 'text-white' : 'text-slate-300'
                    }`}
                  >
                    {stage.shortName}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 mt-0.5">
                    Phase 0{index + 1}
                  </span>
                </div>

                {/* Mobile Active Arrow */}
                <span className="sm:hidden font-mono text-cyan-400 text-xs">
                  {isSelected ? 'Active ▾' : 'Select ▸'}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
