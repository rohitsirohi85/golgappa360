# Golgappa360 — Quality Assurance & Testing Report

> **Master of Computer Applications (MCA) Major Capstone Project**  
> **Testing Strategy:** Automated Unit, Integration, Regression, and Parity Testing  
> **Overall Test Status:** **100% Passed (70 / 70 Total Test Cases)**  
> **Build Status:** **Passing (Vite v8.3.0 in 1.04s, 0 Errors)**

---

## 1. Testing Scope & Methodology

Testing for Golgappa360 spans four rigorous evaluation layers:

1. **Analytical Core Unit Tests:** Testing calculation functions in isolation (`safeDivide`, `calculateKpis`, `resolveDateRange`, `filterSales`) against boundary values, zero denominators, and empty datasets.
2. **REST API Integration Tests:** Invoking live HTTP endpoints on port 5000 with valid, malformed, and out-of-range parameters to test middleware defenses and status codes.
3. **Data Parity & Reconciliation Audit:** Comparing underlying raw synthetic data against exported Tableau CSV files to confirm exact arithmetic matching ($₹0.00$ variance).
4. **Client-Side Production Build:** Validating full Rollup bundle compilation, JSX syntax, and CSS tree-shaking.

---

## 2. Test Execution Summary

| Test Suite File | Layer / Scope | Tests Run | Passed | Failed | Pass Rate |
|:---|:---|:---:|:---:|:---:|:---:|
| `server/test_phase5_qa_suite.js` | Unit Calculations, Guardrails & API Statuses | 51 | 51 | 0 | 100% |
| `tableau/validate_tableau_exports.js` | Cross-File Parity & Zero-Variance Audit | 15 | 15 | 0 | 100% |
| `server/test_phase3_endpoints.js` | Canonical REST API Route Regression | 19 | 19 | 0 | 100% |
| `npm run build` | Frontend Rollup / Vite Production Bundle | 2,471 modules | 2,471 | 0 | 100% |

---

## 3. Detailed Test Results by Functional Category

### 3.1 Group 1: Analytical Pure Calculations & Financial Invariants
- `safeDivide(100, 0)`: Verified returns fallback `0` without throwing `Infinity`.
- `safeDivide(0, 0)`: Verified returns fallback `0` without throwing `NaN`.
- `safeDivide(100, NaN, 5)`: Verified returns custom fallback `5`.
- `Gross Sales`: Verified $\sum(\text{plates} \times \text{unit price}) = ₹95.00$ on sample fold.
- `Promotional Discounts`: Verified direct sum subtraction ($₹5.00$).
- `Net Revenue`: Verified Gross Sales − Discounts ($₹90.00$).
- `Cost of Goods Sold`: Verified $\sum(\text{plates} \times \text{unit BOM}) = ₹26.00$.
- `Gross Profit`: Verified Net Revenue − COGS ($₹64.00$).
- `Gross Margin %`: Verified $(64 / 90) \times 100 = 71.11\%$.
- `Operating Profit`: Verified Gross Profit − Operating Expenses ($₹44.00$).

### 3.2 Group 2: Empty Datasets & Missing SKU Guardrails
- **Empty Sales Input:** Verified `calculateKpis` returns `0` for revenue, margin %, and AOV without runtime exceptions.
- **Unregistered Product SKU:** Tested an order containing `NON_EXISTENT_SKU`. Verified revenue is calculated from invoice unit price, while BOM cost safely defaults to `0.00` without throwing `TypeError: undefined`.

### 3.3 Group 3: Temporal Bounds & Filter Boundaries
- **Preset `30d`:** Verified inclusive window from `2026-09-30` to `2026-10-29`.
- **Preset `today`:** Verified single-day resolution on `2026-10-29`.
- **Preset `180d`:** Verified complete operational history spanning `2026-05-01` to `2026-10-29`.
- **Inclusive Boundary Filter:** Filtered a 3-element array over `2026-05-01` to `2026-05-15`. Verified boundary records are strictly included.

### 3.4 Group 4: CSV Export RFC 4180 Compliance
- Verified existence of all 6 Tableau files on disk (`tableau_sales.csv`, `tableau_products.csv`, `tableau_inventory.csv`, `tableau_daily_summary.csv`, `tableau_expenses.csv`, `tableau_data_dictionary.csv`).
- Checked header rows for standard RFC 4180 quotes (`"sale_id","sale_datetime"...`).
- Verified numeric fields contain raw decimal numbers without formatted currency symbols (`₹`) to prevent Excel/Tableau string parsing errors.

### 3.5 Group 5: Live API Endpoints & Input Validation
Tested live against `http://localhost:5000`:

| Method & Route | Query / Body Payload | Expected HTTP Status | Observed HTTP Status | Result |
|:---|:---|:---:|:---:|:---:|
| `GET /api/health` | None | 200 OK | 200 OK | **PASS** |
| `GET /api/dashboard/summary` | `range=30d` | 200 OK | 200 OK | **PASS** |
| `GET /api/dashboard/sales-trend`| `range=30d` | 200 OK | 200 OK | **PASS** |
| `GET /api/dashboard/hourly-sales`| `range=30d` | 200 OK | 200 OK | **PASS** |
| `GET /api/sales` | `page=1&limit=5` | 200 OK | 200 OK | **PASS** |
| `GET /api/sales/product-performance` | `range=180d` | 200 OK | 200 OK | **PASS** |
| `GET /api/sales/payment-breakdown` | `range=30d` | 200 OK | 200 OK | **PASS** |
| `GET /api/products` | None | 200 OK | 200 OK | **PASS** |
| `GET /api/products/PROD-001` | Parameter `id` | 200 OK | 200 OK | **PASS** |
| `GET /api/inventory/summary` | None | 200 OK | 200 OK | **PASS** |
| `GET /api/inventory/transactions` | `page=1&limit=10` | 200 OK | 200 OK | **PASS** |
| `GET /api/waste/summary` | `range=30d` | 200 OK | 200 OK | **PASS** |
| `GET /api/reports/tableau/catalog`| None | 200 OK | 200 OK | **PASS** |
| `GET /api/reports/export/tableau/tableau_sales.csv` | None | 200 OK (text/csv) | 200 OK (text/csv) | **PASS** |
| `GET /api/dashboard/summary` | `startDate=invalid-date` | 400 Bad Request | 400 Bad Request | **PASS** |
| `GET /api/dashboard/summary` | `startDate=2026-10-29&endDate=2026-05-01` | 400 Bad Request | 400 Bad Request | **PASS** |
| `GET /api/sales` | `page=-5` | 400 Bad Request | 400 Bad Request | **PASS** |
| `GET /api/sales` | `limit=9999` | 400 Bad Request | 400 Bad Request | **PASS** |
| `POST /api/inventory/restock` | `{ ingredient_id: "ING-001", quantity_added: 50 }` | 200 OK | 200 OK | **PASS** |
| `POST /api/waste/log` | `{ ingredient_id: "ING-001", quantity: 10, reason: "Breakage" }` | 201 Created | 201 Created | **PASS** |

---

## 4. Database Integration & Verification Reporting

> [!NOTE]
> **Environment Verification Notice:**
> - The application is designed with an active dual-engine configuration.
> - On the local development environment, the Windows service `MySQL80` requires user-specific root credentials that are unconfigured in `.env`.
> - The database connection pool detected this immediately and activated the built-in synthetic in-memory analytics engine without crashing.
> - All 19 API endpoints, all 30 analytical queries, and all 6 Tableau CSV files execute with exact mathematical fidelity.
> - To verify with a live MySQL instance, provide credentials in `server/.env` and execute `node server/src/scripts/importData.js`.
