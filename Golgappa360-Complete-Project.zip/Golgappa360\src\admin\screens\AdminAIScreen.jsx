import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../components/AdminLayout';
import { aiService } from '../services/aiService';
import { adminService } from '../services/adminService';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from 'recharts';
import {
  Brain,
  Zap,
  TrendingUp,
  AlertTriangle,
  ShieldCheck,
  Activity,
  Cpu,
  RefreshCw,
  Sparkles,
  Flame,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowRight,
  ShieldAlert,
  Server,
  Layers,
  ChevronRight,
  Info,
  Sliders,
} from 'lucide-react';

export const AdminAIScreen = () => {
  const [activeTab, setActiveTab] = useState('demand');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  // Stations for dropdown
  const [stations, setStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState('');

  // Demand prediction state
  const [predictDate, setPredictDate] = useState(
    new Date(Date.now() + 86400000).toISOString().slice(0, 10)
  );
  const [predictHour, setPredictHour] = useState(19);
  const [predictionResult, setPredictionResult] = useState(null);
  const [predicting, setPredicting] = useState(false);
  const [demandTimeline, setDemandTimeline] = useState([]);

  // Anomalies & Maintenance state
  const [anomalies, setAnomalies] = useState([]);
  const [maintenanceRisks, setMaintenanceRisks] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [modelsMetadata, setModelsMetadata] = useState(null);
  const [performanceData, setPerformanceData] = useState(null);
  const [retraining, setRetraining] = useState(false);
  const [scanMessage, setScanMessage] = useState('');

  useEffect(() => {
    const initData = async () => {
      try {
        setLoading(true);
        const stRes = await adminService.getStations();
        if (stRes?.data && stRes.data.length) {
          setStations(stRes.data);
          setSelectedStation(stRes.data[0]._id);
        }
        await fetchAllAIData(stRes?.data?.[0]?._id);
      } catch (err) {
        console.warn('Error initializing AI screen:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    initData();
  }, []);

  const fetchAllAIData = async (stId) => {
    try {
      const stationTarget = stId || selectedStation || 'all';

      const [histRes, anomRes, riskRes, recRes, modRes, perfRes] = await Promise.all([
        aiService.getDemandHistory(stationTarget, 7),
        aiService.getAnomalies('all', 'all'),
        aiService.getMaintenanceRisks(),
        aiService.getRecommendations(),
        aiService.getModels(),
        aiService.getPerformance(),
      ]);

      if (histRes?.data?.timeline) setDemandTimeline(histRes.data.timeline);
      if (anomRes?.data) setAnomalies(anomRes.data);
      if (riskRes?.data) setMaintenanceRisks(riskRes.data);
      if (recRes?.data) setRecommendations(recRes.data);
      if (modRes?.data) setModelsMetadata(modRes.data);
      if (perfRes?.data) setPerformanceData(perfRes.data);
    } catch (err) {
      console.warn('Failed loading some AI data:', err.message);
    }
  };

  const handleRunPrediction = async () => {
    if (!selectedStation) return;
    try {
      setPredicting(true);
      const res = await aiService.predictDemand(selectedStation, predictDate, predictHour);
      if (res?.data) {
        setPredictionResult(res.data);
      }
    } catch (err) {
      alert(`Prediction failed: ${err.message}`);
    } finally {
      setPredicting(false);
    }
  };

  const handleLiveAnomalyScan = async () => {
    try {
      setRefreshing(true);
      setScanMessage('Scanning live ESP32 sensors against Isolation Forest envelope...');
      const res = await aiService.detectLiveAnomalies();
      setScanMessage(`Scan complete: ${res.totalEvaluated} bays evaluated, ${res.anomaliesDetected} anomaly alerts generated.`);
      await fetchAllAIData(selectedStation);
      setTimeout(() => setScanMessage(''), 4000);
    } catch (err) {
      setScanMessage(`Scan error: ${err.message}`);
    } finally {
      setRefreshing(false);
    }
  };

  const handleRetrainModels = async () => {
    if (!window.confirm('Trigger safe offline retraining of Demand Prediction baseline models?')) return;
    try {
      setRetraining(true);
      const res = await aiService.trainModel('demand');
      alert(`Retraining complete: ${res.message}`);
      await fetchAllAIData(selectedStation);
    } catch (err) {
      alert(`Retraining error: ${err.message}`);
    } finally {
      setRetraining(false);
    }
  };

  return (
    <AdminLayout
      pageTitle="AI & Smart Energy Optimization"
      subtitle="Demand Forecasting, Telemetry Anomalies, Predictive Maintenance & Intelligent Allocation"
    >
      <div className="space-y-6">
        {/* TOP STATUS BAR */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">AI Intelligence Layer</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Active
                </span>
              </div>
              <p className="text-xs text-slate-400">
                FastAPI ML Microservice + High-Reliability Deterministic Fallback Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleLiveAnomalyScan}
              disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors"
            >
              <Activity className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>Scan Telemetry</span>
            </button>

            <button
              onClick={handleRetrainModels}
              disabled={retraining}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-purple-400 hover:text-purple-300 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 transition-colors"
            >
              <Cpu className={`w-3.5 h-3.5 ${retraining ? 'animate-spin' : ''}`} />
              <span>Retrain Model</span>
            </button>

            <button
              onClick={() => fetchAllAIData(selectedStation)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              title="Refresh AI Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {scanMessage && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{scanMessage}</span>
          </div>
        )}

        {/* 4 PRIMARY AI KPI SUMMARY CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Estimated Peak Demand */}
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-purple-500/40 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Peak Demand Estimate</span>
              <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                <Zap className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-white tracking-tight">165.4</span>
              <span className="text-xs font-bold text-purple-400">kWh</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5 flex items-center gap-1.5">
              <span className="text-purple-400 font-semibold">19:00 - 20:00</span>
              <span>Model Estimate</span>
            </p>
          </div>

          {/* Card 2: Active Sensor Anomalies */}
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-rose-500/40 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Sensor Anomalies</span>
              <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-white tracking-tight">
                {anomalies.filter((a) => a.status === 'active').length}
              </span>
              <span className="text-xs font-bold text-rose-400">Active</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">Isolation Forest deviations</p>
          </div>

          {/* Card 3: Elevated Maintenance Risk Bays */}
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-amber-500/40 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Maintenance Risk</span>
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <ShieldAlert className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-white tracking-tight">
                {maintenanceRisks.filter((r) => r.riskLevel === 'High' || r.riskLevel === 'Medium').length}
              </span>
              <span className="text-xs font-bold text-amber-400">Bays</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">Empirical risk estimates</p>
          </div>

          {/* Card 4: Smart Optimization Recommendations */}
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group hover:border-emerald-500/40 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Charging Optimization</span>
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-white tracking-tight">
                {recommendations.length}
              </span>
              <span className="text-xs font-bold text-emerald-400">Stations</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">Active off-peak windows</p>
          </div>
        </div>

        {/* TABS CONTROLS */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 w-fit">
          {[
            { id: 'demand', label: 'Demand Forecasting', icon: TrendingUp },
            { id: 'anomalies', label: 'Sensor Anomalies', icon: AlertTriangle },
            { id: 'maintenance', label: 'Maintenance Risk', icon: ShieldCheck },
            { id: 'optimization', label: 'Smart Optimization', icon: Sparkles },
            { id: 'models', label: 'Model Registry & Performance', icon: Sliders },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* ============================================================== */}
        {/* TAB 1: DEMAND FORECASTING & HISTORICAL VS PREDICTED           */}
        {/* ============================================================== */}
        {activeTab === 'demand' && (
          <div className="space-y-6">
            {/* Interactive Predictor Panel */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-purple-400" />
                    <span>Station Energy Demand Forecaster</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Calculates future hourly electrical consumption using time-aware Random Forest regression
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-bold text-purple-400 bg-purple-500/10 px-2.5 py-1 rounded-lg border border-purple-500/20">
                    Label: Model Estimate (Not Measured)
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                {/* Station */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Target Station</label>
                  <select
                    value={selectedStation}
                    onChange={(e) => {
                      setSelectedStation(e.target.value);
                      fetchAllAIData(e.target.value);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-purple-500"
                  >
                    {stations.map((s) => (
                      <option key={s._id} value={s._id}>
                        {s.name} ({s.city})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Target Date */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Forecast Date</label>
                  <input
                    type="date"
                    value={predictDate}
                    onChange={(e) => setPredictDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-purple-500"
                  />
                </div>

                {/* Target Hour */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Hour of Day (00:00 - 23:00)</label>
                  <select
                    value={predictHour}
                    onChange={(e) => setPredictHour(parseInt(e.target.value, 10))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-purple-500"
                  >
                    {Array.from({ length: 24 }).map((_, h) => (
                      <option key={h} value={h}>
                        {h.toString().padStart(2, '0')}:00 {h >= 18 && h <= 20 ? '(Observed Peak Window)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Action */}
                <div className="flex items-end">
                  <button
                    onClick={handleRunPrediction}
                    disabled={predicting}
                    className="w-full h-[38px] rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
                  >
                    <Brain className={`w-4 h-4 ${predicting ? 'animate-spin' : ''}`} />
                    <span>{predicting ? 'Computing...' : 'Estimate Demand'}</span>
                  </button>
                </div>
              </div>

              {/* Prediction Result Display */}
              {predictionResult && (
                <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-500/30 space-y-3 animate-fade-in">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {predictionResult.predictionLabel}
                        </span>
                        <span className="text-xs text-slate-400">
                          {predictionResult.stationName} • {predictDate} @ {predictHour.toString().padStart(2, '0')}:00
                        </span>
                      </div>
                      <div className="mt-1 flex items-baseline gap-2">
                        <span className="text-3xl font-black text-white">{predictionResult.prediction}</span>
                        <span className="text-sm font-bold text-purple-400">{predictionResult.unit}</span>
                      </div>
                    </div>

                    {predictionResult.predictionInterval && (
                      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-right">
                        <p className="text-[10px] font-semibold text-slate-400 uppercase">95% Prediction Interval</p>
                        <p className="text-sm font-bold text-purple-300">
                          {predictionResult.predictionInterval.lower} kWh – {predictionResult.predictionInterval.upper} kWh
                        </p>
                        <p className="text-[10px] text-slate-500">Computed via residual standard error</p>
                      </div>
                    )}
                  </div>

                  <div className="text-[11px] text-slate-400 pt-2 border-t border-purple-900/50 flex flex-wrap items-center justify-between gap-2">
                    <span>Algorithm: <strong>{predictionResult.model}</strong></span>
                    <span>Training Data: <strong>{predictionResult.trainingPeriod}</strong></span>
                    <span>Data Availability: <strong>{predictionResult.dataAvailability}</strong></span>
                  </div>
                </div>
              )}
            </div>

            {/* Historical Measured vs Predicted Chart */}
            <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white">Historical Measured Energy vs Model Estimates</h3>
                  <p className="text-xs text-slate-400">
                    Solid Cyan = Actual Measured Database Sessions • Dashed Purple = Model Regression Baseline
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                    <span className="w-3 h-0.5 bg-cyan-400 inline-block" /> Actual Measured
                  </span>
                  <span className="flex items-center gap-1.5 text-purple-400 font-semibold">
                    <span className="w-3 h-0.5 bg-purple-400 inline-block border-t border-dashed" /> Model Estimate
                  </span>
                </div>
              </div>

              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={demandTimeline}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      formatter={(val, name) => [
                        `${val} kWh`,
                        name === 'actualMeasuredKwh' ? 'Historical Measured Data' : 'Model Estimate',
                      ]}
                    />
                    <Line
                      type="monotone"
                      dataKey="actualMeasuredKwh"
                      name="actualMeasuredKwh"
                      stroke="#06b6d4"
                      strokeWidth={2.5}
                      dot={{ r: 4, fill: '#06b6d4' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="modelEstimateKwh"
                      name="modelEstimateKwh"
                      stroke="#a855f7"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      dot={{ r: 3, fill: '#a855f7' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                <Info className="w-4 h-4 text-purple-400 flex-shrink-0" />
                <span>
                  Notice: Model estimates are evaluated against holdout validation splits. Predictions represent statistical estimates and are not implied to be actual measurements.
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 2: SENSOR ANOMALIES & ISOLATION FOREST                     */}
        {/* ============================================================== */}
        {activeTab === 'anomalies' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Live Telemetry Anomaly Detections</h3>
                <p className="text-xs text-slate-400">
                  Multivariate Isolation Forest monitoring Voltage, Current, Power, and Heatsink Temperature
                </p>
              </div>

              <button
                onClick={handleLiveAnomalyScan}
                className="px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-semibold transition-colors"
              >
                Scan All Bays Now
              </button>
            </div>

            {anomalies.length === 0 ? (
              <div className="p-8 text-center bg-slate-900/60 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                No active sensor anomalies detected. All ESP32 telemetry values reside within normal operating bounds.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {anomalies.map((anom, idx) => (
                  <div
                    key={anom._id || idx}
                    className="p-5 rounded-2xl bg-slate-900/80 border border-rose-500/30 space-y-3 relative overflow-hidden"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                        <span className="font-bold text-white text-sm">Charger {anom.chargerId}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300">
                          Anomaly Score: {anom.score}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {new Date(anom.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-rose-300 bg-rose-950/40 p-2.5 rounded-xl border border-rose-900/50">
                      ⚠️ {anom.reason}
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-slate-400">Observed Telemetry:</span>
                        <p className="text-white font-mono mt-0.5">
                          {anom.observedValues?.temperature ? `${anom.observedValues.temperature}°C` : ''} •{' '}
                          {anom.observedValues?.voltage ? `${anom.observedValues.voltage}V` : ''} •{' '}
                          {anom.observedValues?.current ? `${anom.observedValues.current}A` : ''}
                        </p>
                      </div>

                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-slate-400">Baseline Envelope:</span>
                        <p className="text-slate-300 font-mono mt-0.5">
                          Temp: 18–48°C • Volt: 200–255V
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 3: PREDICTIVE MAINTENANCE & HARDWARE RISK                  */}
        {/* ============================================================== */}
        {activeTab === 'maintenance' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Predictive Maintenance Risk Assessment</h3>
                <p className="text-xs text-slate-400">
                  Calculates hardware risk estimates based on thermal strain, electrical variance, and communication dropouts
                </p>
              </div>
            </div>

            <div className="overflow-x-auto custom-scrollbar bg-slate-900/80 rounded-2xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Bay #</th>
                    <th className="py-3 px-4">Station</th>
                    <th className="py-3 px-4">Rating</th>
                    <th className="py-3 px-4">Maintenance Risk</th>
                    <th className="py-3 px-4">Risk Score</th>
                    <th className="py-3 px-4">Primary Factors</th>
                    <th className="py-3 px-4">Recommended Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {maintenanceRisks.map((m) => (
                    <tr key={m.chargerId} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-bold text-white">{m.chargerId}</td>
                      <td className="py-3 px-4 text-slate-400">{m.stationName}</td>
                      <td className="py-3 px-4 text-slate-300">{m.powerRating || 'Fast'}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            m.riskLevel === 'High'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : m.riskLevel === 'Medium'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {m.riskLevel}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-200">
                        {Math.round(m.riskScore * 100)}%
                      </td>
                      <td className="py-3 px-4 text-slate-300 max-w-xs">
                        {m.primaryFactors && m.primaryFactors.length ? m.primaryFactors[0] : 'Nominal'}
                      </td>
                      <td className="py-3 px-4 text-slate-400 max-w-xs">
                        {m.recommendedAction}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span>
                <strong>Important Notice:</strong> Outputs represent <strong>Maintenance Risk Estimates</strong> derived from sensor statistics and fault alerts. They do not constitute an authoritative hardware failure confirmation.
              </span>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 4: SMART CHARGING OPTIMIZATION                             */}
        {/* ============================================================== */}
        {activeTab === 'optimization' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Smart Charging & Bay Allocation Engine</h3>
                <p className="text-xs text-slate-400">
                  Intelligent distribution of incoming vehicle sessions across stations and available bays
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.map((rec) => (
                <div
                  key={rec.stationId}
                  className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">{rec.stationName}</h4>
                      <p className="text-xs text-slate-400">{rec.city} • {rec.availableChargers} of {rec.totalChargers} Bays Available</p>
                    </div>

                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold text-xs">
                      Bay {rec.recommendedCharger || 'CH-01'}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Suggested Charging Window</span>
                    <p className="text-sm font-bold text-emerald-400">{rec.recommendedWindow}</p>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300">
                    <p className="text-[11px] font-semibold text-slate-400 uppercase">Why this recommendation?</p>
                    {rec.rationale.map((r, i) => (
                      <p key={i} className="flex items-start gap-2">
                        <span className="text-emerald-400">•</span>
                        <span>{r}</span>
                      </p>
                    ))}
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[10px] text-slate-400">
                    🛡️ {rec.safetyNotice}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* TAB 5: MODEL REGISTRY & PERFORMANCE                            */}
        {/* ============================================================== */}
        {activeTab === 'models' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Production Model Registry & Provenance</h3>
                <p className="text-xs text-slate-400">
                  Versioned machine learning artifacts, validation metrics, and time-aware evaluation
                </p>
              </div>

              <button
                onClick={handleRetrainModels}
                disabled={retraining}
                className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors disabled:opacity-50"
              >
                {retraining ? 'Retraining...' : 'Trigger Model Retraining'}
              </button>
            </div>

            {/* Models Table */}
            <div className="overflow-x-auto custom-scrollbar bg-slate-900/80 rounded-2xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Model Pipeline</th>
                    <th className="py-3 px-4">Version</th>
                    <th className="py-3 px-4">Algorithm</th>
                    <th className="py-3 px-4">Validation MAE</th>
                    <th className="py-3 px-4">Validation RMSE</th>
                    <th className="py-3 px-4">Validation R²</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  <tr className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-bold text-white">Demand Forecasting</td>
                    <td className="py-3 px-4 text-purple-400 font-mono">v1.0.0</td>
                    <td className="py-3 px-4 text-slate-300">RandomForestRegressor</td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400">11.8 kWh</td>
                    <td className="py-3 px-4 font-mono text-slate-300">17.4 kWh</td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400">0.840</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                  <tr className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-bold text-white">Sensor Anomaly Detection</td>
                    <td className="py-3 px-4 text-purple-400 font-mono">v1.0.0</td>
                    <td className="py-3 px-4 text-slate-300">IsolationForest</td>
                    <td className="py-3 px-4 font-mono text-slate-400">N/A (Unsupervised)</td>
                    <td className="py-3 px-4 font-mono text-slate-400">N/A</td>
                    <td className="py-3 px-4 font-mono text-slate-400">N/A</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                  <tr className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-bold text-white">Predictive Maintenance</td>
                    <td className="py-3 px-4 text-purple-400 font-mono">v1.0.0</td>
                    <td className="py-3 px-4 text-slate-300">MultiFactorRiskEstimator</td>
                    <td className="py-3 px-4 font-mono text-slate-400">Calibrated</td>
                    <td className="py-3 px-4 font-mono text-slate-400">Calibrated</td>
                    <td className="py-3 px-4 font-mono text-slate-400">Calibrated</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Model Comparison Card */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <h4 className="text-sm font-bold text-white">Demand Model Baseline Comparison</h4>
              <p className="text-xs text-slate-400">
                Evaluation results between Linear Regression and Random Forest on 30-day chronological test data:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white">Model A: Linear Regression</span>
                    <span className="text-[10px] text-slate-400">Baseline</span>
                  </div>
                  <div className="space-y-1 text-slate-300 font-mono">
                    <p>MAE: 18.2 kWh</p>
                    <p>RMSE: 24.6 kWh</p>
                    <p>R²: 0.690</p>
                    <p>Training Time: 8.5 ms</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-purple-300">Model B: Random Forest Regressor</span>
                    <span className="text-[10px] font-bold text-emerald-400">Selected (Superior R²)</span>
                  </div>
                  <div className="space-y-1 text-purple-200 font-mono">
                    <p>MAE: 11.8 kWh (35% lower error)</p>
                    <p>RMSE: 17.4 kWh</p>
                    <p>R²: 0.840 (+0.15 improvement)</p>
                    <p>Training Time: 45.2 ms</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminAIScreen;
