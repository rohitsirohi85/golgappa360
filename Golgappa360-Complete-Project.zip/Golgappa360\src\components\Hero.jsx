import React from 'react';
import CelestialObject from './CelestialObject';
import Button from './Button';
import ScrollIndicator from './ScrollIndicator';

/**
 * Hero Section — Full-screen cinematic landing hero
 * Features:
 * - Huge cinematic typography ("EXPLORE THE STARS")
 * - Eyebrow: "THE UNIVERSE IS WAITING"
 * - Micro details: "RA 06h 45m", "DEC −16° 42′", "STELLAR EXPLORATION SYSTEM"
 * - Reusable Button triggers: "Explore Stars →", "Discover the Universe"
 * - 3D Celestial star sphere with coronal halos
 * - Animated scroll prompt
 */
export default function Hero() {
  const handleScrollToUniverse = (e) => {
    e.preventDefault();
    const universeSection = document.getElementById('universe-map');
    if (universeSection) {
      universeSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToExplore = (e) => {
    e.preventDefault();
    const exploreSection = document.getElementById('stars') || document.getElementById('explore-stars');
    if (exploreSection) {
      exploreSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-center items-center pt-28 pb-16 lg:py-0 overflow-hidden"
    >
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 my-auto">
        {/* Top Micro-Telemetry Header Banner */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-8 sm:mb-12 border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#38bdf8]" />
            <span className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.25em] text-slate-400">
              STELLAR EXPLORATION SYSTEM
            </span>
          </div>

          <div className="flex items-center gap-4 text-[10px] sm:text-[11px] font-mono text-slate-400 tracking-wider">
            <span className="glass-surface px-2.5 py-0.5 rounded border border-white/5">
              RA 06h 45m
            </span>
            <span className="glass-surface px-2.5 py-0.5 rounded border border-white/5">
              DEC −16° 42′
            </span>
            <span className="hidden sm:inline text-cyan-400/80">
              EPOCH J2026.5
            </span>
          </div>
        </div>

        {/* Two-Column Responsive Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Hero Content */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-20">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 mb-6 rounded-full glass-surface border border-cyan-500/25 shadow-[0_0_20px_rgba(6,182,212,0.15)] animate-in fade-in duration-700">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_10px_#22d3ee]" />
              <span className="text-[11px] sm:text-xs font-mono font-medium tracking-[0.25em] text-cyan-300 uppercase">
                THE UNIVERSE IS WAITING
              </span>
            </div>

            {/* Main Heading */}
            <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl font-semibold tracking-tight text-white leading-[1.05] mb-6 sm:mb-8">
              EXPLORE <br />
              THE{' '}
              <span className="relative inline-block">
                <span className="bg-gradient-to-r from-amber-200 via-yellow-100 to-white bg-clip-text text-transparent font-bold">
                  STARS
                </span>
                {/* Subtle underline flare */}
                <span
                  aria-hidden="true"
                  className="absolute -bottom-1 left-0 right-0 h-[2px] bg-gradient-to-r from-amber-400/0 via-amber-300/40 to-cyan-400/0 blur-[1px]"
                />
              </span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-300/90 leading-relaxed max-w-xl mb-8 sm:mb-10 font-normal">
              Discover the stars that illuminate our universe — their origins, properties,
              life cycles, and incredible stories.
            </p>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <Button
                href="#stars"
                variant="primary"
                size="lg"
                onClick={handleScrollToExplore}
                icon={
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2.5"
                      d="M14 5l7 7m0 0l-7 7m7-7H3"
                    />
                  </svg>
                }
              >
                Explore Stars
              </Button>

              <Button
                href="#universe-map"
                variant="secondary"
                size="lg"
                onClick={handleScrollToUniverse}
              >
                Discover the Universe
              </Button>

              <a
                href="#timeline"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full text-xs font-mono text-cyan-300 hover:text-white bg-white/[0.03] hover:bg-white/[0.08] border border-cyan-500/30 hover:border-cyan-400 transition-all cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.15)] active:scale-95"
              >
                <span>⏳</span>
                <span>Cosmic Timeline</span>
              </a>
            </div>

            {/* Micro Observatory Telemetry Ticker */}
            <div className="mt-10 sm:mt-12 flex flex-wrap items-center gap-4 sm:gap-6 pt-6 border-t border-white/5 text-[11px] font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>CATALOG: 8 PROMINENT TARGETS</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-600">//</span>
                <span>SPECTRAL CLASS: O B A F G K M</span>
              </div>
              <div className="hidden sm:flex items-center gap-2">
                <span className="text-slate-600">//</span>
                <span>INTERFEROMETRY: 0.05 mas</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual (Celestial Star Object) */}
          <div className="lg:col-span-5 flex items-center justify-center relative mt-6 lg:mt-0">
            {/* Ambient Lighting Backing */}
            <div
              aria-hidden="true"
              className="absolute w-[300px] sm:w-[450px] h-[300px] sm:h-[450px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none"
            />
            {/* The Cinematic Celestial Star */}
            <CelestialObject />
          </div>
        </div>
      </div>

      {/* Bottom Scroll Indicator */}
      <div className="relative lg:absolute lg:bottom-6 left-0 right-0 z-20 flex justify-center mt-12 lg:mt-0">
        <ScrollIndicator targetId="#universe-map" />
      </div>
    </section>
  );
}
