import React from 'react';

export const HorizontalDateSelector = ({
  selectedDate,
  onSelectDate,
}) => {
  // Generate 7 days starting from today (23 Sep 2026 as per project context)
  const dates = [
    { day: 'Wed', date: '23', full: '23 Sep 2026', label: 'Today' },
    { day: 'Thu', date: '24', full: '24 Sep 2026', label: 'Tomorrow' },
    { day: 'Fri', date: '25', full: '25 Sep 2026' },
    { day: 'Sat', date: '26', full: '26 Sep 2026' },
    { day: 'Sun', date: '27', full: '27 Sep 2026' },
    { day: 'Mon', date: '28', full: '28 Sep 2026' },
    { day: 'Tue', date: '29', full: '29 Sep 2026' },
  ];

  return (
    <div className="flex gap-2.5 overflow-x-auto pb-2 no-scrollbar select-none">
      {dates.map((item) => {
        const isSelected = selectedDate === item.full;

        return (
          <button
            key={item.full}
            type="button"
            onClick={() => onSelectDate(item.full)}
            className={`
              flex flex-col items-center justify-center min-w-[62px] py-3 px-2 rounded-2xl border transition-all duration-200 shrink-0
              ${
                isSelected
                  ? 'bg-[#00F5A0] text-[#050811] border-[#00F5A0] shadow-[0_0_15px_rgba(0,245,160,0.35)] scale-105 font-bold'
                  : 'bg-[#0D1527] text-slate-300 border-white/10 hover:border-white/20 hover:bg-[#131E35]'
              }
            `}
          >
            <span
              className={`text-[10px] uppercase tracking-wider ${
                isSelected ? 'text-[#050811]/80 font-bold' : 'text-slate-400'
              }`}
            >
              {item.label || item.day}
            </span>
            <span className="text-lg font-mono font-bold mt-0.5 leading-none">
              {item.date}
            </span>
            <span
              className={`text-[9px] mt-1 ${
                isSelected ? 'text-[#050811]/90 font-medium' : 'text-slate-500'
              }`}
            >
              Sep
            </span>
          </button>
        );
      })}
    </div>
  );
};
