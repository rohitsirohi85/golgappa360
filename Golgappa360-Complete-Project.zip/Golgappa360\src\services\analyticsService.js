import { userProfileData } from "../data/analytics";
import { trendingStats } from "../data/trending";

export const analyticsService = {
  async getUserAnalytics() {
    return {
      searchBreakdown: userProfileData.searchBreakdown,
      moodDistribution: userProfileData.moodDistribution,
      monthlyActivity: userProfileData.monthlyActivity,
      stats: userProfileData.stats
    };
  },

  async getTrendingBreakdown() {
    return {
      genres: trendingStats.mostSearchedGenres,
      dailyVolume: trendingStats.dailySearchVolume,
      artists: trendingStats.mostSearchedArtists
    };
  }
};
