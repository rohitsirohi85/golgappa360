/**
 * SmartMess AI - Backend API Client Service
 * ==========================================
 * Connects the React frontend to the FastAPI + SQLite backend.
 * Uses VITE_API_BASE_URL (defaults to http://localhost:8000).
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

class MessApiService {
  constructor(baseUrl = API_BASE_URL) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
  }

  async _fetch(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...options.headers,
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        let errorDetail = `HTTP ${response.status} ${response.statusText}`;
        try {
          const errorJson = await response.json();
          if (errorJson.detail) {
            errorDetail = typeof errorJson.detail === 'string'
              ? errorJson.detail
              : JSON.stringify(errorJson.detail);
          }
        } catch (_) {}
        throw new Error(errorDetail);
      }

      return await response.json();
    } catch (err) {
      console.error(`[API ERROR] ${options.method || 'GET'} ${endpoint}:`, err);
      throw err;
    }
  }

  /**
   * GET /api/health
   */
  async getHealth() {
    return this._fetch('/api/health');
  }

  /**
   * GET /api/dashboard/summary
   */
  async getDashboardSummary() {
    return this._fetch('/api/dashboard/summary');
  }

  /**
   * GET /api/data/records
   */
  async getDataRecords(params = {}) {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page);
    if (params.page_size) query.set('page_size', params.page_size);
    if (params.meal_type && params.meal_type !== 'All') query.set('meal_type', params.meal_type.toLowerCase());
    if (params.menu_category && params.menu_category !== 'All') query.set('menu_category', params.menu_category);
    if (params.weather_condition && params.weather_condition !== 'All') query.set('weather_condition', params.weather_condition);
    if (params.weekday && params.weekday !== 'All') query.set('weekday', params.weekday);
    if (params.search && params.search.trim()) query.set('search', params.search.trim());
    if (params.sort_by) query.set('sort_by', params.sort_by);
    if (params.sort_order) query.set('sort_order', params.sort_order);

    const queryString = query.toString();
    const endpoint = `/api/data/records${queryString ? `?${queryString}` : ''}`;
    return this._fetch(endpoint);
  }

  /**
   * GET /api/models/metrics
   */
  async getModelMetrics() {
    return this._fetch('/api/models/metrics');
  }

  /**
   * GET /api/insights/patterns
   */
  async getWastePatterns() {
    return this._fetch('/api/insights/patterns');
  }

  /**
   * POST /api/predict
   */
  async predictWaste(payload) {
    return this._fetch('/api/predict', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  /**
   * GET /api/predictions/history
   */
  async getPredictionHistory(params = {}) {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page);
    if (params.page_size) query.set('page_size', params.page_size);
    if (params.meal_type && params.meal_type !== 'All') query.set('meal_type', params.meal_type.toLowerCase());
    if (params.high_risk_only !== undefined && params.high_risk_only !== null) {
      query.set('high_risk_only', params.high_risk_only);
    }

    const queryString = query.toString();
    const endpoint = `/api/predictions/history${queryString ? `?${queryString}` : ''}`;
    return this._fetch(endpoint);
  }

  /**
   * DELETE /api/predictions/{id}
   */
  async deletePrediction(predictionId) {
    return this._fetch(`/api/predictions/${encodeURIComponent(predictionId)}`, {
      method: 'DELETE',
    });
  }
}

export const messApi = new MessApiService();
export default messApi;
