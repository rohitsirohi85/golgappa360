import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  TrendingUp,
  Zap,
  Building2,
  Activity,
  Gauge,
  RefreshCw,
  Calendar,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const AdminEnergyScreen = () => {
  const [data, setData] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchEnergyData = async () => {
    try {
      setLoading(true);
      const [energyRes, statsRes] = await Promise.all([
        adminService.getEnergyAnalytics(),
        adminService.getStats(),
      ]);
      setData(energyRes);
      setStats(statsRes);
    } catch (err) {
      console.error('Error fetching energy analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEnergyData();
  }, []);

  const dailyEnergy = data?.dailyEnergy || [];
  const stationEnergy = data?.stationEnergy || [];
  const chargerUtilization = data?.chargerUtilization || [];

  return (
    <AdminLayout
      pageTitle="Energy Monitoring Analytics"
      subtitle="Fleet-wide power consumption telemetry, station load profiles & bay utilization rates"
    >
      {/* 4 Summary Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Energy Today</span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {stats?.energy?.today || 0} kWh
          </div>
          <span className="text-xs text-slate-400">Current 24h consumption</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">This Week</span>
          <div className="text-2xl font-black text-white font-mono">
            {stats?.energy?.thisWeek || 0} kWh
          </div>
          <span className="text-xs text-slate-400">Past 7 days throughput</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">This Month</span>
          <div className="text-2xl font-black text-white font-mono">
            {stats?.energy?.thisMonth || 0} kWh
          </div>
          <span className="text-xs text-slate-400">Monthly cumulative</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Avg Session</span>
          <div className="text-2xl font-black text-sky-400 font-mono">
            {stats?.energy?.averagePerSession || 18.4} kWh
          </div>
          <span className="text-xs text-slate-400">Per vehicle connection</span>
        </div>
      </div>

      {/* Row 1: 7-Day Energy Chart */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-base font-bold text-white">Daily Energy Consumption (kWh)</h3>
              <p className="text-xs text-slate-500">Fleet-wide power delivered over the last 7 calendar days</p>
            </div>
          </div>
          <button
            onClick={fetchEnergyData}
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-4 h-4 text-emerald-400" />
          </button>
        </div>

        <div className="h-72 w-full">
          {dailyEnergy.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyEnergy}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit=" kWh" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar
                  dataKey="energy"
                  fill="#10b981"
                  radius={[6, 6, 0, 0]}
                  name="Energy Delivered (kWh)"
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              Loading energy metrics...
            </div>
          )}
        </div>
      </div>

      {/* Row 2: Station Breakdown & Charger Utilization */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Station Energy Breakdown */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Station Energy Contribution</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">kWh Delivered</span>
          </div>

          <div className="space-y-4">
            {stationEnergy.map((st) => (
              <div key={st.stationId} className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">{st.name}</span>
                  <span className="font-mono text-emerald-400 font-bold">{st.energy} kWh</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, Math.max(10, (st.energy / (stats?.energy?.total || 1)) * 100))}%`,
                    }}
                  />
                </div>
                <span className="text-[10px] text-slate-500 block">{st.sessions} sessions logged</span>
              </div>
            ))}
          </div>
        </div>

        {/* Charger Utilization */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-sky-400" />
              <h3 className="text-sm font-bold text-white">Charger Bay Utilization (%)</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Operational Density</span>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {chargerUtilization.map((ch, idx) => (
              <div key={idx} className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white">{ch.chargerNumber}</span>
                    <span className="text-[10px] text-slate-500">{ch.stationName}</span>
                  </div>
                  <span className="font-mono font-bold text-sky-400">{ch.utilization}%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-sky-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${ch.utilization}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminEnergyScreen;
