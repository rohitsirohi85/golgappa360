import React from 'react';
import { Layers, Volume2, Sun, Wind, ArrowUpRight } from 'lucide-react';
import { STUDIO_FEATURES, ACADEMY_CONFIG } from '../data/danceData';

export const StudioSection = ({ onOpenTrial }) => {
  const getIcon = (id) => {
    switch (id) {
      case 'flooring':
        return <Layers className="w-5 h-5 text-[#8B5CF6]" />;
      case 'acoustics':
        return <Volume2 className="w-5 h-5 text-[#8B5CF6]" />;
      case 'lighting':
        return <Sun className="w-5 h-5 text-[#8B5CF6]" />;
      case 'environment':
        return <Wind className="w-5 h-5 text-[#8B5CF6]" />;
      default:
        return <Layers className="w-5 h-5 text-[#8B5CF6]" />;
    }
  };

  return (
    <section
      id="space"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="Studio Facility and Atmosphere"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/[0.08]">
          <div>
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ 05 // THE SANCTUARY ]
            </span>
            <h2 className="editorial-headline text-3xl sm:text-5xl lg:text-6xl text-[#F5F3F8] uppercase">
              ENGINEERED FOR <br />
              <span className="text-[#A78BFA]">MAXIMUM IMPACT.</span>
            </h2>
          </div>
          <p className="font-sans text-sm sm:text-base text-[#A5A1B2] max-w-md leading-relaxed">
            A dancer's environment dictates their boundaries. Our facility was architected from the floorboards up to protect joints, amplify musical perception, and inspire fearless creative experimentation.
          </p>
        </div>

        {/* Hero Architectural Space Visual */}
        <div className="mt-12 relative w-full aspect-[16/9] sm:aspect-[21/9] rounded-sm overflow-hidden border border-white/[0.1] bg-[#14141B]">
          <img
            src="/images/dance/space-1.jpg"
            alt="Wide architectural perspective of the dance studio showing sprung timber floors and ambient lighting"
            loading="lazy"
            className="w-full h-full object-cover filter contrast-[1.08] brightness-[0.88]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-90 pointer-events-none" />
          <div className="film-grain absolute inset-0 pointer-events-none" />

          {/* Overlay architectural specs badge */}
          <div className="absolute top-6 left-6 z-10 pointer-events-none hidden sm:block">
            <span className="font-mono text-xs text-white/90 bg-black/75 backdrop-blur-md px-3.5 py-1.5 rounded-sm border border-white/10 uppercase tracking-widest">
              FACILITY SCHEMATIC // 4,200 SQ FT MAIN STAGE
            </span>
          </div>

          <div className="absolute bottom-6 left-6 right-6 z-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4 pointer-events-none">
            <div className="max-w-lg">
              <span className="font-mono text-[10px] text-[#8B5CF6] uppercase tracking-widest block mb-1">
                ACOUSTIC PRECISION & FLOOR PRESERVATION
              </span>
              <p className="font-display font-bold text-xl sm:text-2xl text-white">
                "Where raw energy meets clinical architectural discipline."
              </p>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-ping" />
              <span className="font-mono text-xs text-white/80 uppercase">
                STUDIO BAY 04
              </span>
            </div>
          </div>
        </div>

        {/* 4 Architectural Specifications Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {STUDIO_FEATURES.map((feature, idx) => (
            <div
              key={feature.id}
              className="p-6 rounded-sm bg-[#14141B] border border-white/[0.07] hover:border-[#8B5CF6]/40 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2.5 rounded-sm bg-white/[0.03] border border-white/5">
                    {getIcon(feature.id)}
                  </div>
                  <span className="font-mono text-[10px] text-[#8B5CF6] uppercase tracking-wider font-semibold">
                    {feature.metric}
                  </span>
                </div>

                <span className="font-mono text-[9px] uppercase tracking-widest text-[#A5A1B2] block mb-1">
                  SPEC // 0{idx + 1}
                </span>
                <h3 className="font-display font-bold text-lg text-[#F5F3F8] mb-2">
                  {feature.title}
                </h3>
                <p className="text-xs text-[#A5A1B2] leading-relaxed">
                  {feature.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-white/[0.06]">
                <span className="font-mono text-[10px] text-[#A5A1B2] uppercase">
                  {feature.category}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
