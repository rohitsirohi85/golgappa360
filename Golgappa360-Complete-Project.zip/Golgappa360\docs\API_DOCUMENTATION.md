# EV Smart — Unified REST & Real-Time API Specification

**Document Version:** `1.0.0-RC1`  
**Classification:** Interface & API Specification  

> **Prototype Disclaimer**: This API specification governs communication for the academic prototype EV charging platform. High-voltage hardware interfaces require isolated secondary protections.

---

## 1. Network Environments & Base Endpoints

All client requests must target the appropriate base URI for the deployed environment:

| Deployment Tier | Base API URI | WebSocket Protocol & Host | Security & Notes |
| :--- | :--- | :--- | :--- |
| **Cloud Production** | `https://YOUR-DOMAIN/api` *(e.g. https://api.evsmart.com/api)* | `wss://YOUR-DOMAIN/socket.io/` | TLS 1.3, Strict CORS, Edge Rate Limiting |
| **Cloud Staging** | `https://staging-api.evsmart.app/api` | `wss://staging-api.evsmart.app/socket.io/` | Staging sandbox, mock payment credentials |
| **Physical iPhone (LAN)** | `http://192.168.29.23:5000/api` | `ws://192.168.29.23:5000/socket.io/` | Zero-config direct Wi-Fi LAN testing |
| **Localhost Development** | `http://localhost:5000/api` | `ws://localhost:5000/socket.io/` | Default local developer machine loopback |

---

## 2. Authentication & Authorization Headers

All secured endpoints require an HTTP `Authorization` header containing a valid JSON Web Token:

```http
Authorization: Bearer <your_jwt_token>
```

### Rate Limiting Limits
- **Authentication**: 30 requests / 15 minutes (`/api/auth/login`, `/api/auth/register`)
- **Machine Learning Inference**: 60 requests / minute (`/api/ai/predict-demand`)
- **Payment Operations**: 50 requests / 15 minutes (`/api/bills/webhook`, `/api/bills`)
- **General API**: 600 requests / 15 minutes

---

## 3. System Status & Health Diagnostics

### `GET /api/health`
- **Access**: Public
- **Description**: Fast liveness and readiness probe for load balancers.
- **Response**:
```json
{
  "status": "OK",
  "app": "EV Smart Backend API",
  "phase": "Phase 8: Production Ready",
  "API": "OK",
  "MongoDB": "OK",
  "database": "Connected",
  "IoT": "OK",
  "ML": "OK",
  "realtime": "Socket.IO Active",
  "uptime": 1420
}
```

### `GET /api/health/full`
- **Access**: Public / Diagnostics
- **Description**: Comprehensive subsystem and resource utilization probe.

### `GET /api/system-status`
- **Access**: Public / Monitoring
- **Description**: Subsystem health status and live fleet counts.

---

## 4. Authentication Endpoints

### `POST /api/auth/register`
- **Access**: Public
- **Payload**: `{ "name": "Jane Driver", "email": "driver@evsmart.com", "password": "password123", "role": "driver" }`
- **Response**: `{ "success": true, "token": "...", "user": { ... } }`

### `POST /api/auth/login`
- **Access**: Public
- **Payload**: `{ "email": "driver@evsmart.com", "password": "password123" }`
- **Response**: `{ "success": true, "token": "...", "user": { ... } }`

### `GET /api/auth/me`
- **Access**: Private (Authenticated)
- **Response**: Current authenticated user profile object.

---

## 5. Stations & Chargers

### `GET /api/stations`
- **Access**: Public
- **Description**: Returns all charging stations with nested active chargers and availability counts.

### `GET /api/stations/:id`
- **Access**: Public
- **Description**: Detailed station object with connector types, power limits, and geo-coordinates.

### `GET /api/stations/qr/:code`
- **Access**: Public
- **Description**: Resolves station details from a scanned QR string.

### `GET /api/chargers/qr/:code`
- **Access**: Public
- **Description**: Resolves specific bay status, type, power, and parent station from a scanned charger QR.

### `GET /api/chargers/:id/telemetry`
- **Access**: Public / Authenticated
- **Description**: Returns recent telemetry data points for charting.

---

## 6. Bookings & Reservations

### `POST /api/bookings`
- **Access**: Private (Driver)
- **Payload**: `{ "stationId": "...", "chargerId": "...", "slotStartTime": "...", "slotEndTime": "..." }`
- **Response**: Booking confirmation with reservation status.

### `GET /api/bookings/my`
- **Access**: Private (Driver)
- **Description**: User's active and historical reservations.

### `DELETE /api/bookings/:id`
- **Access**: Private (Driver)
- **Description**: Cancels pending booking and restores charger state to available.

---

## 7. Charging Sessions & Telemetry

### `POST /api/charging/start`
- **Access**: Private (Driver)
- **Payload**: `{ "chargerId": "CH-01", "vehicleId": "..." }`
- **Response**: Initiates session; transitions charger to `charging`.

### `POST /api/charging/stop`
- **Access**: Private (Driver / Admin)
- **Payload**: `{ "sessionId": "...", "chargerId": "CH-01" }`
- **Response**: Concludes session; generates bill.

### `POST /api/sensors/telemetry`
- **Access**: IoT / Backend
- **Payload**: `{ "chargerId": "CH-01", "voltage": 230.5, "current": 32.1, "power": 7.4, "energy": 12.8, "temperature": 34.2 }`
- **Validation**: Enforces strict physical bounds ($V \le 450\text{V}$, $I \le 100\text{A}$, $T \in [-40, 120]^\circ\text{C}$, $P \ge 0$, $E \ge 0$).

---

## 8. Billing, Invoicing & Receipts

### `GET /api/bills`
- **Access**: Private (Driver)
- **Description**: Returns user's billing records with IDOR protection.

### `GET /api/bills/:id`
- **Access**: Private (Owner or Admin)
- **Description**: Detailed invoice breakdown.

### `GET /api/bills/:id/receipt`
- **Access**: Private (Owner or Admin)
- **Description**: Returns styled HTML invoice with Tax Invoice formatting and security watermark.

### `POST /api/bills/webhook`
- **Access**: Protected by `x-webhook-secret` or `x-payment-webhook-secret`
- **Description**: Idempotent payment gateway webhook receiver.

---

## 9. AI & Machine Learning Endpoints

### `POST /api/ai/predict-demand`
- **Access**: Private (Authenticated)
- **Payload**: `{ "stationId": "...", "timestamp": "...", "historicalLoad": [...] }`
- **Response**: 24-hour demand forecast with peak load window and confidence interval.

### `GET /api/ai/charger-health/:id`
- **Access**: Private (Admin)
- **Description**: Charger health score, failure probability %, and remaining useful life (RUL).

---

## 10. Multi-Channel Notifications

### `GET /api/notifications`
- **Access**: Private (Driver)
- **Description**: Returns notification feed with `unreadCount`.

### `PUT /api/notifications/:id/read`
- **Access**: Private (Owner only)
- **Description**: Marks notification as read.

### `PUT /api/notifications/preferences`
- **Access**: Private
- **Description**: Updates delivery channel preferences. Safety fault alerts remain locked ON.

---

## 11. Controlled Presentation Demo Cycle

### `POST /api/demo/run-cycle`
- **Access**: Private (Admin / Operator)
- **Description**: Runs an end-to-end simulated charging cycle in software without requiring high-voltage hardware.
- **Request Body**: `{ "energyConsumed": 5.25 }`
- **Response**: Complete lifecycle object: booking, active session, telemetry trace, bill, and AI demand evaluation.
