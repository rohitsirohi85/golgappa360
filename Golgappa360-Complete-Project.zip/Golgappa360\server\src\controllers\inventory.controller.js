import { AnalyticsService } from '../services/analyticsService.js';

export async function getSummary(req, res, next) {
  try {
    const result = await AnalyticsService.getInventorySummary();
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}

export async function getTransactions(req, res, next) {
  try {
    const { page = 1, limit = 50, ingredientId, type, startDate, endDate } = req.query;
    const result = await AnalyticsService.getInventoryTransactions({ page, limit, ingredientId, type, startDate, endDate });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}
