import React, { useState, useEffect } from 'react';
import { getDiscoveryExplanation } from '../../services/discoveryService.js';
import { CATEGORY_LABELS, CATEGORY_SYMBOLS } from '../../data/celestialObjects.js';

/**
 * CosmicDiscoveryCard — STELLAR 2.0 (Phase U11: Cosmic Discovery Mode)
 * 
 * Cinematic, guided discovery overlay:
 * - Scanning radar state ("SEARCHING THE COSMOS...")
 * - Destination reveal ("DESTINATION FOUND")
 * - Curated "Why this object?" rationale
 * - Category filter chips (ALL, STARS, PLANETS, BLACK HOLES, NEBULAE, GALAXIES, CONSTELLATIONS)
 * - Actions: "EXPLORE DESTINATION →" and "DISCOVER ANOTHER ✦"
 */
export default function CosmicDiscoveryCard({
  isOpen = false,
  isScanning = false,
  discoveredObject = null,
  activeCategory = 'ALL',
  onSelectCategory = null,
  onDiscoverAnother = null,
  onExplore = null,
  onClose = null,
  discoveryCount = 1,
  className = '',
}) {
  const [explanation, setExplanation] = useState('');

  useEffect(() => {
    if (discoveredObject) {
      setExplanation(getDiscoveryExplanation(discoveredObject));
    }
  }, [discoveredObject]);

  if (!isOpen) return null;

  const categories = [
    { id: 'ALL', label: 'Anything' },
    { id: 'BLACK_HOLES', label: 'Black Holes' },
    { id: 'NEBULAE', label: 'Nebulae' },
    { id: 'GALAXIES', label: 'Galaxies' },
    { id: 'PLANETS', label: 'Planets' },
    { id: 'STARS', label: 'Stars' },
    { id: 'CONSTELLATIONS', label: 'Constellations' },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Cosmic Discovery Mode"
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020308]/75 backdrop-blur-md animate-in fade-in duration-200 ${className}`}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-[#030612]/95 border border-cyan-500/30 rounded-2xl p-5 sm:p-6 shadow-[0_20px_60px_rgba(0,0,0,0.95)] shadow-cyan-950/40 text-slate-100 flex flex-col gap-4 animate-in zoom-in-95 duration-150"
      >
        {/* Top Header & Dismiss */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-cyan-300 font-semibold">
              ✦ COSMIC DISCOVERY MODE
            </span>
          </div>

          <div className="flex items-center gap-2">
            {discoveryCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-mono text-slate-400">
                #{discoveryCount} DISCOVERED
              </span>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Discovery Dialog"
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider flex-shrink-0 mr-1">
            SEEK:
          </span>
          {categories.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory && onSelectCategory(cat.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_10px_rgba(56,189,248,0.25)]'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* -------------------------------------------------------------
            STATE 1: SCANNING THE COSMOS (Cinematic radar transition)
            ------------------------------------------------------------- */}
        {isScanning ? (
          <div className="py-10 sm:py-12 flex flex-col items-center justify-center text-center gap-4">
            {/* Pulsing Cosmic Reticle */}
            <div className="relative w-20 h-20 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-ping duration-1000" />
              <div className="absolute inset-2 rounded-full border border-cyan-400/50 animate-spin duration-700" />
              <div className="absolute inset-4 rounded-full bg-cyan-500/10 backdrop-blur-sm" />
              <span className="text-2xl text-cyan-300 animate-pulse font-mono">✦</span>
            </div>

            <div className="flex flex-col gap-1">
              <h3 className="font-display font-semibold text-lg text-white tracking-wide animate-pulse">
                SEARCHING THE COSMOS...
              </h3>
              <p className="text-xs font-mono text-slate-400 max-w-xs">
                Scanning astronomical catalog for an extraordinary destination...
              </p>
            </div>
          </div>
        ) : discoveredObject ? (
          /* -------------------------------------------------------------
             STATE 2: DESTINATION FOUND (Reveal Card)
             ------------------------------------------------------------- */
          <div className="flex flex-col gap-4 py-1">
            {/* Discovered Object Presentation */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-white/[0.04] to-transparent border border-white/10 flex flex-col gap-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span
                    className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg bg-white/5 border border-white/15 flex-shrink-0 shadow-inner"
                    style={{ color: discoveredObject.colorHex || '#38bdf8' }}
                  >
                    {CATEGORY_SYMBOLS[discoveredObject.category] || '●'}
                  </span>
                  <div>
                    <h3 className="text-xl sm:text-2xl font-display font-bold text-white tracking-tight leading-tight">
                      {discoveredObject.name}
                    </h3>
                    <div className="text-xs font-mono text-slate-400">
                      {discoveredObject.commonName && discoveredObject.commonName !== discoveredObject.name
                        ? `“${discoveredObject.commonName}” · `
                        : ''}
                      {discoveredObject.isConstellation
                        ? 'Constellation Pattern'
                        : `${discoveredObject.constellation || discoveredObject.relatedConstellation || 'Deep Space'}`}
                    </div>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-md text-[10px] font-mono font-semibold uppercase tracking-wider bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 flex-shrink-0">
                  {CATEGORY_LABELS[discoveredObject.category] || discoveredObject.subtype || 'Celestial Object'}
                </span>
              </div>

              {/* Distance & Subtype Chips */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/5 text-[11px] font-mono text-slate-300">
                {discoveredObject.distance && (
                  <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10">
                    📍 {discoveredObject.distance}
                  </span>
                )}
                {discoveredObject.subtype && (
                  <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300">
                    {discoveredObject.subtype}
                  </span>
                )}
                {discoveredObject.temperature && (
                  <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-amber-300">
                    🔥 {discoveredObject.temperature}
                  </span>
                )}
              </div>

              {/* "Why this object?" Educational Explanation */}
              <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-500/20 text-xs font-sans leading-relaxed">
                <div className="text-[10px] font-mono uppercase tracking-wider text-cyan-300 font-semibold mb-1 flex items-center gap-1.5">
                  <span>💡</span> WHY THIS OBJECT?
                </div>
                <p className="text-slate-200">{explanation}</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-1">
              <button
                type="button"
                onClick={onDiscoverAnother}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-cyan-400/40 text-slate-300 hover:text-white transition-all text-xs font-mono font-semibold flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>✦</span>
                <span>DISCOVER ANOTHER</span>
              </button>

              <button
                type="button"
                onClick={onExplore}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white transition-all text-xs font-sans font-semibold shadow-[0_0_20px_rgba(56,189,248,0.4)] flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>EXPLORE DESTINATION</span>
                <span>→</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="py-8 text-center text-slate-400 text-xs font-mono">
            More cosmic destinations are coming soon.
          </div>
        )}

        {/* Footer Disclaimer */}
        <div className="text-[10px] font-mono text-slate-500 text-center border-t border-white/5 pt-2">
          Curated educational discovery — destinations selected from existing astronomical catalog.
        </div>
      </div>
    </div>
  );
}
