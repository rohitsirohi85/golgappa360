import api from '../../services/api';

/**
 * Build URL search query string from filter object
 */
const buildQueryString = (filters = {}) => {
  const params = new URLSearchParams();
  if (filters.startDate) params.append('startDate', filters.startDate);
  if (filters.endDate) params.append('endDate', filters.endDate);
  if (filters.stationId && filters.stationId !== 'all') params.append('stationId', filters.stationId);
  if (filters.chargerId && filters.chargerId !== 'all') params.append('chargerId', filters.chargerId);

  const qs = params.toString();
  return qs ? `?${qs}` : '';
};

export const analyticsService = {
  // 1. Executive Fleet KPI Overview
  getOverview: async (filters = {}) => {
    const res = await api.get(`/analytics/overview${buildQueryString(filters)}`);
    return res.data;
  },

  // 2. Advanced Energy Consumption & Telemetry
  getEnergy: async (filters = {}) => {
    const res = await api.get(`/analytics/energy${buildQueryString(filters)}`);
    return res.data;
  },

  // 3. Charging Behavior & Distributions
  getCharging: async (filters = {}) => {
    const res = await api.get(`/analytics/charging${buildQueryString(filters)}`);
    return res.data;
  },

  // 4. Station Performance & Load Contribution
  getStations: async (filters = {}) => {
    const res = await api.get(`/analytics/stations${buildQueryString(filters)}`);
    return res.data;
  },

  // 5. Individual Charger Activity & Utilization
  getChargers: async (filters = {}) => {
    const res = await api.get(`/analytics/chargers${buildQueryString(filters)}`);
    return res.data;
  },

  // 6. Commercial Revenue, Tariff & Billing
  getRevenue: async (filters = {}) => {
    const res = await api.get(`/analytics/revenue${buildQueryString(filters)}`);
    return res.data;
  },

  // 7. Faults, Hardware Reliability & Alert Ranking
  getFaults: async (filters = {}) => {
    const res = await api.get(`/analytics/faults${buildQueryString(filters)}`);
    return res.data;
  },

  // 8. In-Depth Fleet Utilization & Formulas
  getUtilization: async (filters = {}) => {
    const res = await api.get(`/analytics/utilization${buildQueryString(filters)}`);
    return res.data;
  },

  // Client-Side CSV Export Utility
  exportToCsv: (filename, rows, headers) => {
    if (!rows || !rows.length) return;

    const escapeField = (val) => {
      if (val === null || val === undefined) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const headerKeys = headers.map((h) => h.key);
    const headerLabels = headers.map((h) => escapeField(h.label)).join(',');

    const csvRows = rows.map((row) =>
      headerKeys.map((k) => escapeField(row[k])).join(',')
    );

    const csvContent = 'data:text/csv;charset=utf-8,' + [headerLabels, ...csvRows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },
};

export default analyticsService;
