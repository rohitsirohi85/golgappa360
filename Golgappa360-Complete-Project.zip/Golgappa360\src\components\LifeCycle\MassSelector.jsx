import React from 'react';
import { EVOLUTION_PATHS } from '../../data/stellarEvolutionPaths';

/**
 * MassSelector — "CHOOSE A STAR"
 * Switches between LOW MASS (< 0.5 M☉), SUN-LIKE (≈ 1 M☉), and HIGH MASS (> 8 M☉)
 * to dynamically highlight the star's evolutionary journey.
 */
export default function MassSelector({ selectedMassTrack, onSelectTrack }) {
  const tracks = [
    {
      id: 'low-mass',
      label: 'LOW MASS',
      sublabel: '< 0.5 M☉ (Red Dwarf)',
      accent: '#ef4444',
      badge: 'Trillions of Years',
    },
    {
      id: 'sun-like',
      label: 'SUN-LIKE',
      sublabel: '≈ 1 M☉ (Yellow Dwarf)',
      accent: '#fbbf24',
      badge: '≈ 10 Billion Years',
    },
    {
      id: 'high-mass',
      label: 'HIGH MASS',
      sublabel: '> 8 M☉ (Supergiant)',
      accent: '#38bdf8',
      badge: '≈ 10 Million Years',
    },
  ];

  return (
    <div className="w-full flex flex-col items-center select-none">
      <div className="flex items-center gap-2 mb-3 text-[11px] font-mono uppercase tracking-[0.25em] text-slate-400">
        <span>CHOOSE A STAR STELLAR MASS:</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-3xl p-1.5 rounded-2xl glass-surface border border-white/10 shadow-lg">
        {tracks.map((track) => {
          const isSelected = selectedMassTrack === track.id;
          return (
            <button
              key={track.id}
              type="button"
              onClick={() => onSelectTrack(track.id)}
              className={`flex flex-col items-center justify-center p-3.5 sm:p-4 rounded-xl transition-all duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                isSelected
                  ? 'bg-white/10 border shadow-[0_0_20px_-5px_var(--glow)] scale-[1.02]'
                  : 'hover:bg-white/5 border border-transparent opacity-70 hover:opacity-100'
              }`}
              style={{
                '--glow': track.accent,
                borderColor: isSelected ? track.accent : 'transparent',
              }}
            >
              <div className="flex items-center gap-2 mb-1">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{
                    backgroundColor: track.accent,
                    boxShadow: isSelected ? `0 0 8px ${track.accent}` : 'none',
                  }}
                />
                <span
                  className="font-display text-sm sm:text-base font-semibold tracking-tight"
                  style={{ color: isSelected ? track.accent : '#f1f5f9' }}
                >
                  {track.label}
                </span>
              </div>

              <span className="text-[10px] font-mono text-slate-400">
                {track.sublabel}
              </span>

              <span className="mt-2 text-[9px] font-mono px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300">
                {track.badge}
              </span>
            </button>
          );
        })}
      </div>

      {/* Narrative Summary of Selected Track */}
      {selectedMassTrack && EVOLUTION_PATHS[selectedMassTrack] && (
        <p className="mt-4 text-xs sm:text-sm text-slate-300/80 max-w-xl text-center leading-relaxed font-mono">
          {EVOLUTION_PATHS[selectedMassTrack].summary}
        </p>
      )}
    </div>
  );
}
