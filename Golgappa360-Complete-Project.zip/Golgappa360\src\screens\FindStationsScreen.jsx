import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, SlidersHorizontal, MapPin } from 'lucide-react';
import { Input } from '../components/common/Input';
import { InteractiveMap } from '../components/stations/InteractiveMap';
import { StationCard } from '../components/stations/StationCard';
import { EmptyState } from '../components/common/EmptyState';
import { useEV } from '../context/EVContext';

export const FindStationsScreen = () => {
  const navigate = useNavigate();
  const { stations, selectedStation, setSelectedStation } = useEV();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all'); // 'all', 'distance', 'price', 'fast', 'available'

  // Filter chips
  const filters = [
    { id: 'all', label: 'All Stations' },
    { id: 'distance', label: 'Nearest (< 3 km)' },
    { id: 'fast', label: '⚡ Fast Charging' },
    { id: 'available', label: '🟢 Available Now' },
    { id: 'price', label: 'Best Price (≤ ₹10)' },
  ];

  // Filter and search logic
  const filteredStations = useMemo(() => {
    return stations.filter((station) => {
      // Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = station.name.toLowerCase().includes(q);
        const matchesAddr = station.address.toLowerCase().includes(q);
        if (!matchesName && !matchesAddr) return false;
      }

      // Filter tags
      if (activeFilter === 'distance') {
        return station.distanceNum <= 3.0;
      }
      if (activeFilter === 'fast') {
        return (
          station.chargingSpeed.toLowerCase().includes('fast') ||
          station.maxPower.includes('60') ||
          station.maxPower.includes('120') ||
          station.maxPower.includes('150')
        );
      }
      if (activeFilter === 'available') {
        return station.availableChargers > 0;
      }
      if (activeFilter === 'price') {
        return station.ratePerKwh <= 10;
      }

      return true;
    });
  }, [stations, searchQuery, activeFilter]);

  const handleStationSelect = (st) => {
    setSelectedStation(st);
  };

  return (
    <div className="flex flex-col gap-4 px-4 pt-3 select-none">
      {/* Search Bar Header */}
      <div>
        <Input
          placeholder="Search charging station..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          icon={Search}
          rightElement={
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
          }
        />
      </div>

      {/* Filter Chips Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {filters.map((f) => {
          const isActive = activeFilter === f.id;
          return (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`
                px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition-all duration-200 shrink-0
                ${
                  isActive
                    ? 'bg-[#00F5A0] text-[#050811] border-[#00F5A0] shadow-[0_0_10px_rgba(0,245,160,0.3)]'
                    : 'bg-[#0D1527] text-slate-300 border-white/10 hover:border-white/20'
                }
              `}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {/* Realistic Interactive Map */}
      <div>
        <InteractiveMap
          stations={stations}
          selectedStation={selectedStation}
          onStationSelect={handleStationSelect}
        />
      </div>

      {/* Stations List Header */}
      <div className="flex items-center justify-between pt-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Stations Found ({filteredStations.length})
        </h2>
        <span className="text-[11px] text-slate-500">Sorted by distance</span>
      </div>

      {/* Station Cards */}
      <div className="space-y-3 pb-4">
        {filteredStations.length > 0 ? (
          filteredStations.map((station) => (
            <StationCard
              key={station.id}
              station={station}
              onSelect={(st) => {
                setSelectedStation(st);
                navigate(`/station/${st.id}`);
              }}
            />
          ))
        ) : (
          <EmptyState
            icon={MapPin}
            title="No Charging Stations Found"
            description="Try loosening your search query or removing active filter chips."
            actionLabel="Reset Filters"
            onAction={() => {
              setSearchQuery('');
              setActiveFilter('all');
            }}
          />
        )}
      </div>
    </div>
  );
};
