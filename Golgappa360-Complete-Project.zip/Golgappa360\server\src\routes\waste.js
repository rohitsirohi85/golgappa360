import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const range = req.query.range || '180d';
    const wasteData = syntheticStore.getWasteData(range);

    res.json({
      success: true,
      data: wasteData
    });
  } catch (error) {
    console.error('[API /api/waste Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/log', (req, res) => {
  try {
    const { ingredient_id, quantity, reason } = req.body;
    if (!ingredient_id || !quantity || !reason) {
      return res.status(400).json({ success: false, error: 'Ingredient, quantity, and reason are required.' });
    }

    const wasteData = syntheticStore.getWasteData('180d');
    res.status(201).json({ success: true, data: { logged: true, wasteData } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
