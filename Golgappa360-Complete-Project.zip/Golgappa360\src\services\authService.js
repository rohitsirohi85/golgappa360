import { api } from './api';
import { DEFAULT_USER } from '../data/mockUsers';
import { DEFAULT_VEHICLE } from '../data/mockVehicles';

export const authService = {
  login: async (email, password) => {
    try {
      const data = await api.post('/auth/login', {
        email: email || DEFAULT_USER.email,
        password: password || 'password123',
      });
      if (data.token) {
        localStorage.setItem('ev_smart_token', data.token);
      }
      return {
        token: data.token,
        user: {
          id: data._id,
          name: data.name,
          email: data.email,
          phone: data.phone,
          role: data.role,
          avatar: data.profileImage || DEFAULT_USER.avatar,
        },
      };
    } catch (err) {
      console.warn('Backend login fallback to local credentials:', err.message);
      return {
        token: 'local_token_mock',
        user: { ...DEFAULT_USER, email: email || DEFAULT_USER.email },
      };
    }
  },

  register: async (userData) => {
    try {
      const data = await api.post('/auth/register', {
        name: userData.fullName || userData.name || 'Suman',
        email: userData.email,
        phone: userData.phone || '9876543210',
        password: userData.password || 'password123',
      });
      if (data.token) {
        localStorage.setItem('ev_smart_token', data.token);
      }
      return {
        token: data.token,
        user: {
          id: data._id,
          name: data.name,
          email: data.email,
          phone: data.phone,
          role: data.role,
          avatar: data.profileImage || DEFAULT_USER.avatar,
        },
      };
    } catch (err) {
      console.warn('Backend register fallback to local state:', err.message);
      return {
        token: 'local_token_mock',
        user: {
          ...DEFAULT_USER,
          name: userData.fullName || DEFAULT_USER.name,
          email: userData.email || DEFAULT_USER.email,
          phone: userData.phone || DEFAULT_USER.phone,
        },
      };
    }
  },

  getMe: async () => {
    try {
      const data = await api.get('/auth/me');
      return {
        id: data._id,
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: data.role,
        avatar: data.profileImage || DEFAULT_USER.avatar,
      };
    } catch (err) {
      return DEFAULT_USER;
    }
  },
};
