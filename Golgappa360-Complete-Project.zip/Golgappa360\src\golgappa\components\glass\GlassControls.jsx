import React from 'react';

export function GlassButton({
  children,
  variant = 'default', // 'default', 'primary', 'saffron', 'danger', 'ghost'
  size = 'md', // 'sm', 'md', 'lg'
  icon: Icon,
  className = '',
  disabled = false,
  onClick,
  ...props
}) {
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-xs rounded-xl gap-1.5',
    md: 'px-4 py-2 text-xs font-semibold rounded-xl gap-2',
    lg: 'px-5 py-2.5 text-sm font-semibold rounded-2xl gap-2.5'
  };

  const variantClasses = {
    default: 'bg-white/[0.08] hover:bg-white/[0.14] text-[#F5F4F1] border border-white/15 shadow-xs',
    primary: 'bg-[#A7D78A]/20 hover:bg-[#A7D78A]/30 text-[#A7D78A] border border-[#A7D78A]/40 shadow-[0_0_20px_rgba(167,215,138,0.15)]',
    saffron: 'bg-[#EAB64B] hover:bg-[#D4A33E] text-[#171717] font-bold border border-[#EAB64B]/60 shadow-[0_0_20px_rgba(234,182,75,0.25)]',
    solidWhite: 'bg-white hover:bg-white/90 text-[#171717] font-bold shadow-lg',
    danger: 'bg-[#E58B79]/20 hover:bg-[#E58B79]/30 text-[#E58B79] border border-[#E58B79]/40',
    ghost: 'hover:bg-white/[0.08] text-[#B8B7B9] hover:text-[#F5F4F1]'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        inline-flex items-center justify-center font-sans tracking-tight transition-all duration-150 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed
        ${sizeClasses[size]}
        ${variantClasses[variant]}
        ${className}
      `}
      {...props}
    >
      {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
      {children}
    </button>
  );
}

export function GlassInput({
  icon: Icon,
  className = '',
  ...props
}) {
  return (
    <div className="relative w-full">
      {Icon && (
        <Icon className="w-4 h-4 text-[#929195] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
      )}
      <input
        className={`
          w-full bg-white/[0.06] text-[#F5F4F1] placeholder-[#929195] text-xs rounded-xl py-2 border border-white/12
          focus:border-[#A7D78A]/60 focus:bg-white/[0.10] focus:outline-hidden transition-all duration-150
          ${Icon ? 'pl-9.5 pr-4' : 'px-3.5'}
          ${className}
        `}
        {...props}
      />
    </div>
  );
}
