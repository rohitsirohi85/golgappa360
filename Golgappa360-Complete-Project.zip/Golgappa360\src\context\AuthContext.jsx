import React, { createContext, useContext, useState, useEffect } from 'react';
import { DEFAULT_USER } from '../data/mockUsers';
import { DEFAULT_VEHICLE } from '../data/mockVehicles';
import { authService } from '../services/authService';
import { vehicleService } from '../services/vehicleService';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(DEFAULT_USER);
  const [vehicle, setVehicle] = useState(DEFAULT_VEHICLE);
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [loading, setLoading] = useState(false);

  // Hydrate user and vehicle from MongoDB on initial mount
  useEffect(() => {
    const initAuth = async () => {
      try {
        const token = localStorage.getItem('ev_smart_token');
        if (token) {
          const profile = await authService.getMe();
          if (profile && profile.id) {
            setUser(profile);
            setIsAuthenticated(true);
            const vehicles = await vehicleService.getVehicles();
            if (vehicles && vehicles.length > 0) {
              setVehicle(vehicles[0]);
            }
          }
        }
      } catch (err) {
        console.warn('Initial auth hydration error:', err);
      }
    };
    initAuth();
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await authService.login(email, password);
      setUser(res.user);
      setIsAuthenticated(true);
      const vehicles = await vehicleService.getVehicles();
      if (vehicles && vehicles.length > 0) {
        setVehicle(vehicles[0]);
      }
      return true;
    } finally {
      setLoading(false);
    }
  };

  const demoLogin = async () => {
    return login('suman@example.com', 'password123');
  };

  const register = async (registrationData) => {
    setLoading(true);
    try {
      const res = await authService.register(registrationData);
      setUser(res.user);
      setIsAuthenticated(true);

      if (registrationData.vehicleModel) {
        const createdVeh = await vehicleService.createVehicle({
          make: 'Tesla',
          model: registrationData.vehicleModel,
          batteryCapacity: Number(registrationData.batteryCapacity) || 60,
          licensePlate: 'KA 01 EV 2026',
          connector: 'CCS2',
        });
        setVehicle(createdVeh);
      }
      return true;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('ev_smart_token');
    setIsAuthenticated(false);
    setUser(DEFAULT_USER);
    setVehicle(DEFAULT_VEHICLE);
  };

  const updateVehicle = async (updated) => {
    setVehicle((prev) => ({ ...prev, ...updated }));
    if (vehicle.id) {
      await vehicleService.updateVehicle(vehicle.id, updated);
    }
  };

  const updateUser = (updated) => {
    setUser((prev) => ({ ...prev, ...updated }));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        vehicle,
        isAuthenticated,
        loading,
        login,
        demoLogin,
        register,
        logout,
        updateVehicle,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
