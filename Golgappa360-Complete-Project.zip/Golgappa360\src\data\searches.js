export const heroSuggestions = [
  "Sad songs about missing someone",
  "Punjabi romantic songs",
  "Songs from 2020",
  "I remember the chorus but not the song",
  "Neon lights windshield glass lyrics",
  "Acoustic rainy evening chai"
];

export const trendingSearchTags = [
  "Arijit Singh",
  "Punjabi Songs",
  "Love Songs",
  "2026 Bollywood",
  "Sad Songs",
  "Neon Highway",
  "Acoustic Rain",
  "Taylor Swift",
  "Bad Bunny",
  "Diljit Dosanjh"
];

export const initialSearchHistory = [
  {
    id: "hist-1",
    query: "neon lights reflected in windshield",
    type: "lyrics",
    matchedSong: "Midnight Highway Drive",
    songId: "song-1",
    timestamp: "10 minutes ago"
  },
  {
    id: "hist-2",
    query: "ek bheegi shaam mein jab tum yaad aate ho",
    type: "lyrics",
    matchedSong: "Bheegi Baarish Ki Dhun",
    songId: "song-2",
    timestamp: "2 hours ago"
  },
  {
    id: "hist-3",
    query: "sad indie breakup song with acoustic guitar 2022",
    type: "ai_natural_language",
    matchedSong: "Tears in the Coffee Cup",
    songId: "song-7",
    timestamp: "Yesterday"
  },
  {
    id: "hist-4",
    query: "Luna Vance",
    type: "artist",
    matchedSong: "Electric Mirage",
    songId: "song-3",
    timestamp: "2 days ago"
  },
  {
    id: "hist-5",
    query: "fast driving punjabi bass 808 song",
    type: "mood_prompt",
    matchedSong: "Chandigarh De Raah",
    songId: "song-4",
    timestamp: "3 days ago"
  }
];

export const aiSearchExamples = [
  {
    prompt: "A sad Hindi song about missing someone after a breakup. Acoustic guitar, rain, probably released around 2022.",
    title: "Breakup & Monsoon Nostalgia",
    suggestedSongId: "song-2",
    confidence: 96,
    reason: "Direct semantic match on melancholy emotional theme, rain/monsoon imagery in the chorus, and 2022 acoustic folk instrumentation."
  },
  {
    prompt: "Retro 80s synthwave vibe song for late night highway drive. Lyrics talk about windshield glass and neon lights.",
    title: "Late Night Neon Drive",
    suggestedSongId: "song-1",
    confidence: 98,
    reason: "Exact match on windshield/neon imagery in chorus lyrics, synthwave genre markers, and night driving theme."
  },
  {
    prompt: "Upbeat energetic Punjabi club song with dhol beats and Chandigarh highway mention.",
    title: "Punjabi Road Trip Anthem",
    suggestedSongId: "song-4",
    confidence: 94,
    reason: "Identified 'Chandigarh de raah' lyric hook and high-tempo trap Punjabi percussion elements."
  },
  {
    prompt: "Soft piano instrumental to fall asleep to, sounds like winter snow and delicate film soundtrack.",
    title: "Winter Melancholic Piano",
    suggestedSongId: "song-5",
    confidence: 91,
    reason: "Acoustic signature match: delicate felt piano in minor key with ambient tape room noise."
  }
];

export const zeroResultSearches = [
  { query: "whistle song from commercial in 2014 with red balloon", count: 84, lastSearched: "42 min ago" },
  { query: "spanish guitar rap about old grandfather clock", count: 62, lastSearched: "2 hours ago" },
  { query: "la la la humming chorus french cafe accordion", count: 51, lastSearched: "5 hours ago" },
  { query: "electro swing sample of 1920s jazz saxophone", count: 39, lastSearched: "1 day ago" }
];
