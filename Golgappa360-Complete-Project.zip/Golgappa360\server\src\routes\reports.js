import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';
import * as analytics from '../analytics/golgappaAnalytics.js';

const router = express.Router();

function toCSV(headers, rows) {
  const headerLine = headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(',');
  const rowLines = rows.map(row =>
    headers.map(h => {
      const val = row[h];
      if (val === null || val === undefined) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );
  return [headerLine, ...rowLines].join('\r\n');
}

// SQL Query Library Metadata for MCA Data Analysts
const sqlQueries = [
  {
    id: 'Q01',
    title: 'Executive Financial Summary (Net Revenue, COGS, Gross Profit, Operating Margin)',
    category: 'Executive & Financial',
    description: 'Computes overall gross turnover, promotional discounts, net revenue, BOM cost of goods sold, gross margin %, operating expenses, and estimated operating profit.',
    sql: `SELECT 
    COUNT(s.sale_id) AS total_sales_orders,
    SUM(s.quantity_plates) AS total_plates_sold,
    ROUND(SUM(s.quantity_plates * s.unit_price), 2) AS gross_sales_turnover,
    ROUND(SUM(s.discount), 2) AS total_promotional_discounts,
    ROUND(SUM((s.quantity_plates * s.unit_price) - s.discount), 2) AS net_revenue,
    ROUND(SUM(s.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_cogs,
    ROUND(SUM((s.quantity_plates * s.unit_price) - s.discount) - SUM(s.quantity_plates * p.ingredient_cost_per_plate), 2) AS gross_profit,
    ROUND(((SUM((s.quantity_plates * s.unit_price) - s.discount) - SUM(s.quantity_plates * p.ingredient_cost_per_plate)) / SUM((s.quantity_plates * s.unit_price) - s.discount)) * 100, 2) AS gross_margin_pct,
    ROUND(COALESCE(e.total_expenses, 0), 2) AS total_operating_expenses,
    ROUND((SUM((s.quantity_plates * s.unit_price) - s.discount) - SUM(s.quantity_plates * p.ingredient_cost_per_plate)) - COALESCE(e.total_expenses, 0), 2) AS estimated_operating_profit
FROM sales s
JOIN products p ON s.product_id = p.product_id
CROSS JOIN (
    SELECT SUM(amount) AS total_expenses FROM daily_expenses
) e;`
  },
  {
    id: 'Q02',
    title: 'Product Unit Economics & Margin Matrix',
    category: 'Product & Menu',
    description: 'Ranks each golgappa variety by gross margin contribution, quantity sold, net revenue, and profitability.',
    sql: `SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_contribution_margin,
    ROUND(((p.selling_price - p.ingredient_cost_per_plate) / p.selling_price) * 100, 1) AS gross_margin_percentage,
    SUM(s.quantity_plates) AS total_plates_sold,
    ROUND(SUM((s.quantity_plates * s.unit_price) - s.discount), 2) AS total_net_revenue,
    ROUND(SUM(s.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_cogs,
    ROUND(SUM((s.quantity_plates * s.unit_price) - s.discount) - SUM(s.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_gross_profit
FROM products p
LEFT JOIN sales s ON p.product_id = s.product_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate
ORDER BY total_net_revenue DESC;`
  },
  {
    id: 'Q03',
    title: 'Peak Selling Hours & Evening Rush Concentration',
    category: 'Operations & Timing',
    description: 'Analyzes hourly plate volumes and turnover from 3:00 PM to 10:00 PM to optimize pani batch preparation.',
    sql: `SELECT 
    EXTRACT(HOUR FROM s.sale_datetime) AS operational_hour,
    COUNT(s.sale_id) AS total_orders,
    SUM(s.quantity_plates) AS plates_sold,
    ROUND(SUM((s.quantity_plates * s.unit_price) - s.discount), 2) AS hourly_turnover_inr,
    ROUND((SUM((s.quantity_plates * s.unit_price) - s.discount) / (SELECT SUM((quantity_plates * unit_price) - discount) FROM sales)) * 100, 2) AS pct_of_day_turnover
FROM sales s
GROUP BY EXTRACT(HOUR FROM s.sale_datetime)
ORDER BY operational_hour ASC;`
  },
  {
    id: 'Q04',
    title: 'Inventory Ledger Balance & Raw Material Waste Shrinkage',
    category: 'Waste & Cost Control',
    description: 'Calculates purchases, consumption, and waste per ingredient, identifying financial shrinkage.',
    sql: `SELECT 
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    ROUND(SUM(CASE WHEN t.transaction_type = 'PURCHASE' THEN t.quantity ELSE 0 END), 2) AS total_purchased,
    ROUND(SUM(CASE WHEN t.transaction_type = 'CONSUMPTION' THEN t.quantity ELSE 0 END), 2) AS total_consumed,
    ROUND(SUM(CASE WHEN t.transaction_type = 'WASTE' THEN t.quantity ELSE 0 END), 2) AS total_wasted,
    ROUND(SUM(CASE WHEN t.transaction_type = 'PURCHASE' THEN t.quantity ELSE -t.quantity END), 2) AS ending_stock_balance,
    ROUND(SUM(CASE WHEN t.transaction_type = 'WASTE' THEN t.quantity * i.unit_cost ELSE 0 END), 2) AS total_waste_financial_impact_inr
FROM ingredients i
JOIN inventory_transactions t ON i.ingredient_id = t.ingredient_id
GROUP BY i.ingredient_id, i.ingredient_name, i.unit, i.unit_cost
ORDER BY total_waste_financial_impact_inr DESC;`
  },
  {
    id: 'Q05',
    title: 'Payment Channel Breakdown (UPI Digital Adoption vs Cash)',
    category: 'Financial & Banking',
    description: 'Analyzes digital QR adoption vs cash turnover for stall reconciliation.',
    sql: `SELECT 
    payment_method,
    COUNT(sale_id) AS transaction_count,
    ROUND((COUNT(sale_id) / (SELECT COUNT(*) FROM sales)) * 100, 2) AS transaction_share_pct,
    ROUND(SUM((quantity_plates * unit_price) - discount), 2) AS total_turnover_inr,
    ROUND((SUM((quantity_plates * unit_price) - discount) / (SELECT SUM((quantity_plates * unit_price) - discount) FROM sales)) * 100, 2) AS revenue_share_pct,
    ROUND(AVG((quantity_plates * unit_price) - discount), 2) AS avg_ticket_inr
FROM sales
GROUP BY payment_method
ORDER BY total_turnover_inr DESC;`
  }
];

// Summary Endpoint
router.get('/summary', (req, res) => {
  try {
    const raw = syntheticStore.getRawDatasets();

    const datasets = [
      {
        id: 'sales',
        name: 'Sales Transactions (sales.csv)',
        filename: 'sales.csv',
        records: raw.sales.length,
        columns: 7,
        description: 'Complete 6-month sales history: sale ID, timestamps, product ID, plates sold, unit price, discounts, and payment method.',
        tableauReady: true,
        primaryKey: 'sale_id',
        fields: ['sale_id', 'sale_datetime', 'product_id', 'quantity_plates', 'unit_price', 'discount', 'payment_method']
      },
      {
        id: 'products',
        name: 'Menu Products Master (products.csv)',
        filename: 'products.csv',
        records: raw.products.length,
        columns: 5,
        description: 'Product definitions, category grouping, customer selling price, and ingredient BOM cost per plate.',
        tableauReady: true,
        primaryKey: 'product_id',
        fields: ['product_id', 'product_name', 'category', 'selling_price', 'ingredient_cost_per_plate']
      },
      {
        id: 'ingredients',
        name: 'Raw Ingredients Master (ingredients.csv)',
        filename: 'ingredients.csv',
        records: raw.ingredients.length,
        columns: 5,
        description: 'Puris, potatoes, chickpeas, herbs, spices, curd: units of measurement, unit costs, and reorder levels.',
        tableauReady: true,
        primaryKey: 'ingredient_id',
        fields: ['ingredient_id', 'ingredient_name', 'unit', 'unit_cost', 'reorder_level']
      },
      {
        id: 'inventory_transactions',
        name: 'Inventory Movement Ledger (inventory_transactions.csv)',
        filename: 'inventory_transactions.csv',
        records: raw.inventoryTransactions.length,
        columns: 6,
        description: 'Every stock movement: PURCHASES, daily CONSUMPTION, and logged food WASTAGE with audit reference IDs.',
        tableauReady: true,
        primaryKey: 'transaction_id',
        fields: ['transaction_id', 'transaction_date', 'ingredient_id', 'transaction_type', 'quantity', 'reference_id']
      },
      {
        id: 'daily_expenses',
        name: 'Operating Expenses Ledger (daily_expenses.csv)',
        filename: 'daily_expenses.csv',
        records: raw.dailyExpenses.length,
        columns: 4,
        description: 'Stall rent, dona/packaging, utility power/ice, LPG cylinders, transport freight, and sanitation.',
        tableauReady: true,
        primaryKey: 'expense_id',
        fields: ['expense_id', 'expense_date', 'expense_category', 'amount']
      },
      {
        id: 'daily_sales_summary',
        name: 'Daily Sales & Financial Summary',
        filename: 'golgappa360_daily_sales_summary.csv',
        records: 182,
        columns: 10,
        description: 'Daily aggregated business performance: Net Revenue, COGS, Gross Profit, Food Waste, Expenses, and Operating Profit.',
        tableauReady: true,
        primaryKey: 'fullDate',
        fields: ['date', 'dayOfWeek', 'revenue', 'cogs', 'grossProfit', 'wasteCost', 'expenses', 'operatingProfit', 'plates', 'orders']
      }
    ];

    res.json({
      success: true,
      data: {
        datasets,
        sqlQueries,
        tableauInstructions: {
          guide: 'Importing Golgappa360 Datasets into Tableau Desktop / Tableau Public',
          steps: [
            'Download sales.csv, products.csv, and daily_expenses.csv using the export buttons below.',
            'In Tableau, click "To a File" -> "Text File", then select sales.csv as your base fact table.',
            'Drag products.csv into the data canvas and relate on [product_id] = [product_id].',
            'Create Calculated Field [Net Revenue] = ([quantity_plates] * [unit_price]) - [discount].',
            'Create Calculated Field [COGS] = [quantity_plates] * [ingredient_cost_per_plate].',
            'Create Calculated Field [Gross Margin %] = ([Net Revenue] - [COGS]) / [Net Revenue] * 100.',
            'Build an interactive dashboard tracking Sales by Hour, Weekday Seasonality, and Flavour Contribution.'
          ]
        }
      }
    });
  } catch (error) {
    console.error('[API /api/reports/summary Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// CSV Export Download Route
router.get('/export/:datasetId', (req, res) => {
  try {
    const { datasetId } = req.params;
    const { range = 'all', startDate, endDate, productId } = req.query;
    const raw = syntheticStore.getRawDatasets();

    let csvContent = '';
    let filename = `${datasetId}.csv`;

    if (datasetId === 'sales') {
      const filtered = analytics.filterSales(raw.sales, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null),
        productId
      });
      csvContent = toCSV(
        ['sale_id', 'sale_datetime', 'product_id', 'quantity_plates', 'unit_price', 'discount', 'payment_method'],
        filtered
      );
      filename = `golgappa360_sales_${range}.csv`;
    } else if (datasetId === 'products') {
      csvContent = toCSV(
        ['product_id', 'product_name', 'category', 'selling_price', 'ingredient_cost_per_plate'],
        raw.products
      );
      filename = `golgappa360_products.csv`;
    } else if (datasetId === 'ingredients') {
      csvContent = toCSV(
        ['ingredient_id', 'ingredient_name', 'unit', 'unit_cost', 'reorder_level'],
        raw.ingredients
      );
      filename = `golgappa360_ingredients.csv`;
    } else if (datasetId === 'inventory_transactions' || datasetId === 'inventory') {
      const filtered = analytics.filterInventoryTransactions(raw.inventoryTransactions, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null)
      });
      csvContent = toCSV(
        ['transaction_id', 'transaction_date', 'ingredient_id', 'transaction_type', 'quantity', 'reference_id'],
        filtered
      );
      filename = `golgappa360_inventory_transactions.csv`;
    } else if (datasetId === 'daily_expenses' || datasetId === 'expenses') {
      const filtered = analytics.filterExpenses(raw.dailyExpenses, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null)
      });
      csvContent = toCSV(
        ['expense_id', 'expense_date', 'expense_category', 'amount'],
        filtered
      );
      filename = `golgappa360_daily_expenses.csv`;
    } else if (datasetId === 'daily_sales_summary' || datasetId === 'daily_sales') {
      const overview = syntheticStore.getOverviewMetrics(range || '180d');
      csvContent = toCSV(
        ['fullDate', 'dayOfWeek', 'revenue', 'cogs', 'grossProfit', 'wasteCost', 'expenses', 'operatingProfit', 'plates', 'orders'],
        overview.dailySalesChart
      );
      filename = `golgappa360_daily_sales_summary_${range}.csv`;
    } else {
      return res.status(404).json({ success: false, error: `Dataset ${datasetId} not found` });
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csvContent);
  } catch (error) {
    console.error('[API /api/reports/export Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
