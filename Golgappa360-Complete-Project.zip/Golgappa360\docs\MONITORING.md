# EV SMART — System Monitoring, Health Checks & Observability Runbook

**Document Version:** `1.0.0-RC1`  
**Classification:** DevOps / Site Reliability Engineering (SRE) Specification  

---

## 1. Overview

Observability in EV SMART is built across three primary pillars:
1. **Automated Health Probes:** REST endpoints providing instant status of database, microservices, and IoT subsystems.
2. **Watchdogs & Event Logging:** Active background tasks tracking charger heartbeat health and recording security audit trails.
3. **Threshold Alerts & Incident Runbooks:** Defined escalation procedures for operational anomalies.

---

## 2. Health Check Endpoints

The backend provides layered health endpoints designed for container orchestrators (Kubernetes / Docker Compose), load balancers (ALB / Nginx), and external uptime monitors.

### 2.1 Standard Health Probe (`GET /api/health`)
- **Purpose:** Fast liveness and readiness probe for load balancers.
- **Access:** Public (no authentication required).
- **Latency Target:** `< 10ms`.
- **Response Format:**
```json
{
  "status": "OK",
  "app": "EV Smart Backend API",
  "tagline": "Charge Smarter. Drive Further.",
  "phase": "Phase 8: Production Ready",
  "API": "OK",
  "MongoDB": "OK",
  "database": "Connected",
  "IoT": "OK",
  "ML": "OK",
  "NotificationService": "OK",
  "PaymentService": "OK",
  "realtime": "Socket.IO Active",
  "aiLayer": "Active (FastAPI Microservice Port 8000)",
  "uptime": 3600,
  "timestamp": "2026-09-25T01:00:00.000Z"
}
```

### 2.2 Deep Diagnostics Health Probe (`GET /api/health/full`)
- **Purpose:** Comprehensive subsystem audit reporting resource utilization and live fleet metrics.
- **Access:** Public / Diagnostic.
- **Response Format:**
```json
{
  "status": "OK",
  "uptime": 3600,
  "database": {
    "status": "Connected",
    "host": "127.0.0.1",
    "name": "evsmart"
  },
  "subsystems": {
    "chargersTotal": 16,
    "activeSessions": 2,
    "onlineDevices": 4,
    "mlService": {
      "status": "Online",
      "endpoint": "http://127.0.0.1:8000"
    }
  },
  "process": {
    "nodeVersion": "v20.18.0",
    "memoryRSS_MB": 84.5,
    "heapUsed_MB": 42.1
  },
  "timestamp": "2026-09-25T01:00:00.000Z"
}
```

### 2.3 ML Service Health Probe (`GET http://127.0.0.1:8000/health`)
- **Direct Python FastAPI endpoint:**
```json
{
  "status": "healthy",
  "service": "EV Smart ML Microservice",
  "version": "1.0.0",
  "models_loaded": {
    "demand_forecast": true,
    "anomaly_detector": true,
    "predictive_maintenance": true
  }
}
```

---

## 3. Background Watchdogs & Audit Logging

### 3.1 Offline Hardware Watchdog
- **File:** `backend/src/services/offlineWatchdog.js`
- **Execution Interval:** Every 10 seconds.
- **Logic:** Queries all active devices where `status === 'online'` and `lastHeartbeat < (Date.now() - 30000)`.
- **Action:**
  1. Updates device status to `offline`.
  2. Sets corresponding charger status to `offline`.
  3. Emits real-time `charger:status` and `device:status` events over Socket.IO.
  4. Triggers admin notification.

### 3.2 Audit Log Tracing
- **Endpoint:** `GET /api/admin/audit-logs`
- **Tracked Operations:**
  - Administrative charger status overrides (e.g., forcing charger into maintenance).
  - Tariff rate updates.
  - Emergency station shutdowns.
  - User role promotions.

---

## 4. Alert Thresholds & Service Level Indicators (SLIs)

| Metric | Target / Normal | Warning Threshold | Critical Alert | SRE Action |
| :--- | :--- | :--- | :--- | :--- |
| **API Availability** | `99.9%` | `< 99.5%` | `< 99.0%` | Check Nginx and process logs |
| **P95 API Response Time** | `< 200ms` | `> 500ms` | `> 1500ms` | Inspect slow DB queries / Atlas CPU |
| **Database Connection** | `Connected (1)` | Transient retries | `Disconnected (0)` | Verify Atlas network access & IP whitelist |
| **Node.js RSS Memory** | `< 250MB` | `> 500MB` | `> 1000MB` | Container restart / memory leak trace |
| **ML Microservice** | `Online` | Fallback Active | `Unreachable > 5m` | Restart FastAPI Uvicorn process |
| **Charger Offline Count** | `0 - 1 units` | `> 25% of fleet` | `> 50% of fleet` | Check MQTT broker and local Wi-Fi router |

---

## 5. External Uptime Monitor Setup Guide

### Setting up UptimeRobot / Better Uptime (Free Tier):
1. **Monitor Type:** HTTP(s).
2. **Friendly Name:** `EV SMART Core API`.
3. **URL:** `https://api.yourdomain.com/api/health` (or staging URL).
4. **Monitoring Interval:** 5 minutes (or 1 minute for production).
5. **HTTP Method:** `GET`.
6. **Expected Response Code:** `200`.
7. **Keyword to check in response body:** `"status":"OK"`.
8. **Alert Contacts:** Add email / Slack / Discord webhook.

---

## 6. Incident Response Runbook

### Case 1: Database Disconnected (`MongoDB: DEGRADED`)
1. Log into MongoDB Atlas dashboard.
2. Check cluster metrics: CPU, RAM, and disk utilization.
3. Check Network Access tab: verify application IP address has not changed.
4. Test connectivity from backend host:
   ```powershell
   node -e "require('mongoose').connect(process.env.MONGODB_URI).then(() => console.log('OK')).catch(console.error)"
   ```
5. Check `backend/.env` for correct credentials and URL encoding.

### Case 2: ML Service Fallback Active (`ML: Fallback Active`)
- **System Impact:** Non-disruptive. The backend automatically switches to algorithmic heuristic predictions.
- **Resolution:**
  1. Check if the Python process is alive:
     ```powershell
     curl http://127.0.0.1:8000/health
     ```
  2. If down, restart the ML microservice:
     ```powershell
     cd d:\antigravty\ml-service
     python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
     ```

### Case 3: Chargers Reporting "Offline" Falsely
1. Verify the local Mosquitto / Cloud MQTT broker is running:
   ```powershell
   Get-Service mosquitto # (Windows)
   ```
2. Verify broker accessibility:
   ```powershell
   mqtt sub -h 127.0.0.1 -p 1883 -t "chargers/+/telemetry"
   ```
3. Check if ESP32 microcontrollers are receiving power and connected to Wi-Fi.
