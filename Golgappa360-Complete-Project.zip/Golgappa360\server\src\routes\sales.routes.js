import express from 'express';
import * as salesController from '../controllers/sales.controller.js';
import { validateDateRange, validatePagination } from '../middleware/validateQuery.js';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

// Required Phase 3 endpoints
router.get('/', validateDateRange, validatePagination, salesController.getSales);
router.get('/product-performance', validateDateRange, salesController.getProductPerformance);
router.get('/payment-breakdown', validateDateRange, salesController.getPaymentBreakdown);

// Preserved Phase 1 & 2 endpoint for backwards compatibility
router.get('/analytics', (req, res, next) => {
  try {
    const range = req.query.range || '30d';
    const productId = req.query.product_id || req.query.productId || 'all';
    const salesData = syntheticStore.getSalesAnalytics(range, productId);
    res.json({
      success: true,
      data: salesData
    });
  } catch (err) {
    next(err);
  }
});

export default router;
