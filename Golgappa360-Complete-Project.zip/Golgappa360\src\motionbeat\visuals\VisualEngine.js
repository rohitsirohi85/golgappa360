import * as THREE from 'three';
import { ParticleUniverse } from './presets/ParticleUniverse';
import { EnergyWaves } from './presets/EnergyWaves';
import { NeonTunnel } from './presets/NeonTunnel';

/**
 * VisualEngine (High-Performance Three.js Architecture)
 * - Capped DPR (1.5 max) for laptop performance
 * - Graphics Quality Presets: High, Balanced, Low
 * - Smooth 60 FPS interpolation of 15 FPS hand tracking
 * - Automatic frame-time adaptation
 * - Real measured FPS & frame-time telemetry
 */
export class VisualEngine {
  constructor(canvasContainer) {
    this.container = canvasContainer;
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.clock = new THREE.Clock();
    this.animationFrameId = null;

    // Presets
    this.currentPresetId = 'particle-universe';
    this.currentPreset = null;

    // Graphics Quality ('high' | 'balanced' | 'low')
    this.graphicsQuality = 'high';

    // Visual Settings
    this.settings = {
      density: 1.0,         // 0.1 to 1.0
      speed: 1.0,           // 0.2 to 3.0
      colorIntensity: 1.25, // 0.5 to 2.5
      sensitivity: 1.2,     // 0.2 to 2.5
      cameraFov: 60,
    };

    // Mouse / Cursor
    this.mouse = { x: 0, y: 0 };
    this.targetMouse = { x: 0, y: 0 };

    // Gesture Tracking State (Smoothly lerped at 60 FPS)
    this.gestureEnabled = true;
    this.targetHand1 = { active: false, x: 0, y: 0, z: 0, isPinching: false };
    this.targetHand2 = { active: false, x: 0, y: 0, z: 0, isPinching: false };
    this.hand1 = { active: false, x: 0, y: 0, z: 0, isPinching: false, pinchDist: 1.0 };
    this.hand2 = { active: false, x: 0, y: 0, z: 0, isPinching: false, pinchDist: 1.0 };

    // Performance Monitoring & Auto-Adaptation
    this.fps = 60;
    this.frameCount = 0;
    this.lastFpsUpdate = 0;
    this.lowFpsDuration = 0;
    this.onTelemetryUpdate = null;

    // Bindings
    this.handleResize = this.handleResize.bind(this);
    this.handleMouseMove = this.handleMouseMove.bind(this);
    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.renderLoop = this.renderLoop.bind(this);

    this.init();
  }

  init() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#030308');
    this.scene.fog = new THREE.FogExp2(0x030308, 0.012);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(this.settings.cameraFov, width / height, 0.1, 1000);
    this.camera.position.set(0, 5, 25);

    // 3. WebGL Renderer with performance optimizations
    this.renderer = new THREE.WebGLRenderer({
      powerPreference: 'high-performance',
      antialias: true,
      alpha: false,
      stencil: false,
      depth: true,
    });
    this.renderer.setSize(width, height);
    this.applyQualityDpr();

    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    this.container.appendChild(this.renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0x181828, 0.6);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x9333ea, 1.2);
    dirLight1.position.set(20, 20, 20);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x06b6d4, 1.0);
    dirLight2.position.set(-20, -10, -15);
    this.scene.add(dirLight2);

    // 5. Initial Preset
    this.loadPreset(this.currentPresetId);

    // 6. Event Listeners
    window.addEventListener('resize', this.handleResize);
    this.resizeObserver = new ResizeObserver(this.handleResize);
    this.resizeObserver.observe(this.container);

    this.container.addEventListener('mousemove', this.handleMouseMove);
    this.container.addEventListener('touchmove', this.handleTouchMove, { passive: true });

    // 7. Start render loop
    this.clock.start();
    this.renderLoop();
  }

  applyQualityDpr() {
    if (!this.renderer) return;
    const nativeDpr = window.devicePixelRatio || 1;
    let maxDpr = 1.5;
    if (this.graphicsQuality === 'balanced') maxDpr = 1.25;
    if (this.graphicsQuality === 'low') maxDpr = 1.0;
    this.renderer.setPixelRatio(Math.min(nativeDpr, maxDpr));
  }

  setGraphicsQuality(level) {
    if (level !== 'high' && level !== 'balanced' && level !== 'low') return;
    this.graphicsQuality = level;
    this.applyQualityDpr();
    if (this.currentPreset && this.currentPreset.setQuality) {
      this.currentPreset.setQuality(level);
    }
  }

  loadPreset(presetId) {
    if (this.currentPreset) {
      this.currentPreset.dispose();
      this.currentPreset = null;
    }

    this.currentPresetId = presetId;

    switch (presetId) {
      case 'particle-universe':
        this.currentPreset = new ParticleUniverse(this.scene, this.camera);
        break;
      case 'energy-waves':
        this.currentPreset = new EnergyWaves(this.scene, this.camera);
        break;
      case 'neon-tunnel':
        this.currentPreset = new NeonTunnel(this.scene, this.camera);
        break;
      default:
        this.currentPreset = new ParticleUniverse(this.scene, this.camera);
        break;
    }

    if (this.currentPreset && this.currentPreset.setQuality) {
      this.currentPreset.setQuality(this.graphicsQuality);
    }
    if (this.currentPreset && this.currentPreset.setDensity) {
      this.currentPreset.setDensity(this.settings.density);
    }
  }

  setPreset(presetId) {
    if (this.currentPresetId === presetId) return;
    this.loadPreset(presetId);
  }

  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };

    if (newSettings.density !== undefined && this.currentPreset && this.currentPreset.setDensity) {
      this.currentPreset.setDensity(this.settings.density);
    }

    if (newSettings.cameraFov !== undefined && this.camera) {
      this.camera.fov = this.settings.cameraFov;
      this.camera.updateProjectionMatrix();
    }
  }

  setGestureEnabled(enabled) {
    this.gestureEnabled = !!enabled;
  }

  /**
   * Dual Hand Gesture Data Hook
   * Receives target hand coordinates from HandTracker (12-15 FPS),
   * which are then smoothly lerped at 60 FPS in renderLoop.
   */
  updateGestureData(gestureContract) {
    if (
      this.gestureEnabled &&
      gestureContract &&
      gestureContract.isTracking &&
      gestureContract.mode === 'hands' &&
      gestureContract.handCount > 0
    ) {
      const pHand = gestureContract.primaryHand;
      const sHand = gestureContract.secondaryHand;

      if (pHand) {
        this.targetHand1.active = true;
        this.targetHand1.x = pHand.position.x;
        this.targetHand1.y = pHand.position.y;
        this.targetHand1.z = pHand.position.z || 0;
        this.targetHand1.isPinching = pHand.isPinching;
      } else {
        this.targetHand1.active = false;
      }

      if (sHand) {
        this.targetHand2.active = true;
        this.targetHand2.x = sHand.position.x;
        this.targetHand2.y = sHand.position.y;
        this.targetHand2.z = sHand.position.z || 0;
        this.targetHand2.isPinching = sHand.isPinching;
      } else {
        this.targetHand2.active = false;
      }
    } else {
      // Fallback: mouse acts as Hand 1, Hand 2 inactive
      this.targetHand1.active = true;
      this.targetHand1.x = this.mouse.x;
      this.targetHand1.y = this.mouse.y;
      this.targetHand1.z = 0;
      this.targetHand1.isPinching = false;
      this.targetHand2.active = false;
    }
  }

  handleMouseMove(event) {
    const rect = this.container.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);

    this.targetMouse.x = Math.max(-1, Math.min(1, x));
    this.targetMouse.y = Math.max(-1, Math.min(1, y));
  }

  handleTouchMove(event) {
    if (!event.touches || event.touches.length === 0) return;
    const touch = event.touches[0];
    const rect = this.container.getBoundingClientRect();
    const x = ((touch.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -(((touch.clientY - rect.top) / rect.height) * 2 - 1);

    this.targetMouse.x = Math.max(-1, Math.min(1, x));
    this.targetMouse.y = Math.max(-1, Math.min(1, y));
  }

  handleResize() {
    if (!this.container || !this.renderer || !this.camera) return;

    const width = this.container.clientWidth;
    const height = this.container.clientHeight;

    if (width === 0 || height === 0) return;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
  }

  renderLoop() {
    this.animationFrameId = requestAnimationFrame(this.renderLoop);

    const delta = Math.min(this.clock.getDelta(), 0.1);
    const elapsedTime = this.clock.getElapsedTime();

    // 1. Smooth mouse lerping
    this.mouse.x += (this.targetMouse.x - this.mouse.x) * 0.1;
    this.mouse.y += (this.targetMouse.y - this.mouse.y) * 0.1;

    // 2. Smooth 60 FPS interpolation of target hand coordinates
    const lerpRate = 0.22;
    this.hand1.active = this.targetHand1.active;
    this.hand1.isPinching = this.targetHand1.isPinching;
    this.hand1.x += (this.targetHand1.x - this.hand1.x) * lerpRate;
    this.hand1.y += (this.targetHand1.y - this.hand1.y) * lerpRate;
    this.hand1.z += (this.targetHand1.z - this.hand1.z) * lerpRate;

    this.hand2.active = this.targetHand2.active;
    this.hand2.isPinching = this.targetHand2.isPinching;
    this.hand2.x += (this.targetHand2.x - this.hand2.x) * lerpRate;
    this.hand2.y += (this.targetHand2.y - this.hand2.y) * lerpRate;
    this.hand2.z += (this.targetHand2.z - this.hand2.z) * lerpRate;

    // 3. Query real audio data
    const audioData = this.getAudioData ? this.getAudioData() : {
      bass: 0,
      mid: 0,
      treble: 0,
      energy: 0,
      kickBeat: false,
      isPlaying: false,
    };

    // 4. Update active preset
    if (this.currentPreset) {
      this.currentPreset.update(
        delta,
        elapsedTime,
        audioData,
        this.settings,
        this.mouse,
        this.hand1,
        this.hand2
      );
    }

    // 5. Render WebGL frame
    this.renderer.render(this.scene, this.camera);

    // 6. Telemetry & Dynamic Quality Adaptation
    this.frameCount++;
    const now = performance.now();
    if (now - this.lastFpsUpdate >= 500) {
      this.fps = Math.round((this.frameCount * 1000) / (now - this.lastFpsUpdate));
      this.frameCount = 0;
      this.lastFpsUpdate = now;

      // Auto-adaptation: drop quality if FPS is consistently below 32 for over 3 seconds
      if (this.fps < 32 && this.fps > 0) {
        this.lowFpsDuration += 0.5;
        if (this.lowFpsDuration >= 3.0) {
          if (this.graphicsQuality === 'high') {
            this.setGraphicsQuality('balanced');
          } else if (this.graphicsQuality === 'balanced') {
            this.setGraphicsQuality('low');
          }
          this.lowFpsDuration = 0;
        }
      } else {
        this.lowFpsDuration = 0;
      }

      if (this.onTelemetryUpdate) {
        this.onTelemetryUpdate({
          fps: this.fps,
          preset: this.currentPresetId,
          triangles: this.renderer.info.render.triangles,
          points: this.renderer.info.render.points,
          calls: this.renderer.info.render.calls,
          quality: this.graphicsQuality,
        });
      }
    }
  }

  setAudioDataProvider(fn) {
    this.getAudioData = fn;
  }

  dispose() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    window.removeEventListener('resize', this.handleResize);
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }

    if (this.container) {
      this.container.removeEventListener('mousemove', this.handleMouseMove);
      this.container.removeEventListener('touchmove', this.handleTouchMove);
    }

    if (this.currentPreset) {
      this.currentPreset.dispose();
      this.currentPreset = null;
    }

    if (this.renderer) {
      this.renderer.dispose();
      if (this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      }
      this.renderer = null;
    }

    this.scene = null;
    this.camera = null;
  }
}
