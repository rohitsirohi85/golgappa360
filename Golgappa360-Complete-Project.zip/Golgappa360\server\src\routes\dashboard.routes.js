import express from 'express';
import * as dashboardController from '../controllers/dashboard.controller.js';
import { validateDateRange } from '../middleware/validateQuery.js';

const router = express.Router();

router.get('/summary', validateDateRange, dashboardController.getSummary);
router.get('/sales-trend', validateDateRange, dashboardController.getSalesTrend);
router.get('/hourly-sales', validateDateRange, dashboardController.getHourlySales);

export default router;
