import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AdminRoutes } from '../admin/routes/AdminRoutes';
import { UserRoutes } from './UserRoutes';

// Optional code-split dance pages if accessed via /dance/*
const DanceLayout = lazy(() =>
  import('../components/layout/DanceLayout').then((m) => ({ default: m.DanceLayout }))
);
const HomePage = lazy(() =>
  import('../pages/dance/HomePage').then((m) => ({ default: m.HomePage }))
);
const ClassesPage = lazy(() =>
  import('../pages/dance/ClassesPage').then((m) => ({ default: m.ClassesPage }))
);
const AboutPage = lazy(() =>
  import('../pages/dance/AboutPage').then((m) => ({ default: m.AboutPage }))
);
const InstructorsPage = lazy(() =>
  import('../pages/dance/InstructorsPage').then((m) => ({ default: m.InstructorsPage }))
);
const SchedulePage = lazy(() =>
  import('../pages/dance/SchedulePage').then((m) => ({ default: m.SchedulePage }))
);
const GalleryPage = lazy(() =>
  import('../pages/dance/GalleryPage').then((m) => ({ default: m.GalleryPage }))
);
const ContactPage = lazy(() =>
  import('../pages/dance/ContactPage').then((m) => ({ default: m.ContactPage }))
);

export const AppRoutes = () => {
  return (
    <Routes>
      {/* 💻 Dedicated Admin Portal Routes - completely isolated from User UI */}
      <Route path="/admin/*" element={<AdminRoutes />} />

      {/* 🎭 Optional Dance Studio Routes kept under /dance/* */}
      <Route
        path="/dance/*"
        element={
          <Suspense fallback={<div className="min-h-screen bg-[#0B0B0F] flex items-center justify-center text-[#8B5CF6]">Loading...</div>}>
            <Routes>
              <Route element={<DanceLayout />}>
                <Route path="" element={<HomePage />} />
                <Route path="classes" element={<ClassesPage />} />
                <Route path="about" element={<AboutPage />} />
                <Route path="instructors" element={<InstructorsPage />} />
                <Route path="schedule" element={<SchedulePage />} />
                <Route path="gallery" element={<GalleryPage />} />
                <Route path="contact" element={<ContactPage />} />
              </Route>
            </Routes>
          </Suspense>
        }
      />

      {/* 📱 EV SMART User Mobile Application Routes (Root / and all EV Smart paths) */}
      <Route path="/*" element={<UserRoutes />} />
    </Routes>
  );
};

export default AppRoutes;
