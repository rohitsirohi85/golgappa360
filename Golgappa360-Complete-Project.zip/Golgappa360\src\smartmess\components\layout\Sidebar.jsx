import React from 'react';
import { useMess, NAV_ITEMS } from '../../context/MessContext';
import {
  LayoutDashboard,
  Sparkles,
  Database,
  FlaskConical,
  TrendingDown,
  History,
  Info,
  ChevronLeft,
  ChevronRight,
  Leaf,
  GraduationCap,
} from 'lucide-react';

const iconMap = {
  LayoutDashboard,
  Sparkles,
  Database,
  FlaskConical,
  TrendingDown,
  History,
  Info,
};

export const Sidebar = () => {
  const { activeTab, navigateTo, isSidebarCollapsed, toggleSidebar } = useMess();

  return (
    <aside
      className={`fixed top-0 left-0 bottom-0 z-40 bg-white border-r border-[#E4EAE5] transition-all duration-300 flex flex-col justify-between ${
        isSidebarCollapsed ? 'w-16' : 'w-60'
      } hidden md:flex`}
    >
      {/* Top Header / Logo Section */}
      <div>
        <div className="h-16 flex items-center px-4 border-b border-[#E4EAE5] justify-between">
          <div
            onClick={() => navigateTo('overview')}
            className="flex items-center gap-2.5 cursor-pointer overflow-hidden select-none"
          >
            <div className="w-8 h-8 rounded-lg bg-[#E9F6EE] text-[#16865B] flex items-center justify-center shrink-0">
              <Leaf className="w-4 h-4" />
            </div>

            {!isSidebarCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="font-semibold text-[#25332D] text-sm tracking-tight truncate flex items-center gap-1">
                  SmartMess <span className="text-[#16865B] font-mono text-xs font-bold">AI</span>
                </span>
                <span className="text-[10px] text-[#77847C] truncate font-medium">
                  Food Waste Intelligence
                </span>
              </div>
            )}
          </div>

          <button
            onClick={toggleSidebar}
            className="p-1 rounded-md text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8] transition-colors cursor-pointer"
            title={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = iconMap[item.icon] || LayoutDashboard;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                title={isSidebarCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#E9F6EE] text-[#16865B] font-semibold'
                    : 'text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8]'
                } ${isSidebarCollapsed ? 'justify-center px-0' : ''}`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-[#16865B]' : 'text-[#77847C]'
                  }`}
                />

                {!isSidebarCollapsed && (
                  <span className="truncate text-xs">{item.label}</span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Product / Sustainability Note */}
      <div className="p-3 border-t border-[#E4EAE5]">
        {!isSidebarCollapsed ? (
          <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-xs text-[#77847C] space-y-1">
            <div className="flex items-center gap-1.5 text-[#16865B] font-medium text-[11px]">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>MCA Major Project 2026</span>
            </div>
            <p className="text-[10px] text-[#77847C] leading-tight">
              Predictive kitchen waste prevention
            </p>
          </div>
        ) : (
          <div className="flex justify-center py-1" title="SmartMess AI — MCA Major Project">
            <GraduationCap className="w-4 h-4 text-[#77847C]" />
          </div>
        )}
      </div>
    </aside>
  );
};
