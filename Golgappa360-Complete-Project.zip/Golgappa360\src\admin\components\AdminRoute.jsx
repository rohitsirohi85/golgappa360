import React from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { ShieldAlert, ArrowLeft, Lock } from 'lucide-react';

export const AdminRoute = ({ children, requiredRole }) => {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <div className="w-10 h-10 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4" />
        <p className="text-sm font-medium">Verifying Administrative Privileges...</p>
      </div>
    );
  }

  const token = localStorage.getItem('ev_smart_token');
  if (!isAuthenticated || !token) {
    return <Navigate to="/admin/login" replace />;
  }

  // Check if role is admin or operator
  const role = user?.role;
  if (role !== 'admin' && role !== 'operator') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mb-6 text-rose-400">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">403 Forbidden</h1>
        <p className="text-slate-400 max-w-md text-sm mb-6 leading-relaxed">
          Access Denied. Your current account ({user?.email}) does not have administrative or fleet operator privileges to view the EV Smart Management Portal.
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link
            to="/admin/login"
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-sm transition-colors flex items-center gap-2"
          >
            <Lock className="w-4 h-4" />
            Login as Admin / Operator
          </Link>
          <Link
            to="/home"
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-medium text-sm transition-colors flex items-center gap-2 border border-slate-800"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Mobile App
          </Link>
        </div>
      </div>
    );
  }

  // Check strict admin-only routes (e.g., User Management, Settings, Audit Logs)
  if (requiredRole === 'admin' && role !== 'admin') {
    return (
      <div className="p-8 text-center bg-slate-900/50 rounded-2xl border border-slate-800 my-10 max-w-xl mx-auto">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto mb-4 text-amber-400">
          <Lock className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold text-white mb-2">Super Admin Privileges Required</h2>
        <p className="text-slate-400 text-xs mb-6">
          This management section contains restricted operations accessible only to system administrators. As a Fleet Operator, you have monitoring and operational dispatch permissions.
        </p>
        <Link
          to="/admin/dashboard"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Admin Dashboard
        </Link>
      </div>
    );
  }

  return children;
};

export default AdminRoute;
