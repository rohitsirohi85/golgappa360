# Golgappa360 — Relational Database Design & Schema Documentation

> **Master of Computer Applications (MCA) Major Capstone Project**  
> **Database Management System:** MySQL 8.0+  
> **Database Name:** `golgappa360`  
> **Design Normalization:** Third Normal Form (3NF) with Analytical Materialization Views

---

## 1. Entity-Relationship (E-R) Diagram

```mermaid
erDiagram
    products ||--o{ sale_items : "contains"
    sales ||--|{ sale_items : "itemized by"
    ingredients ||--o{ inventory_transactions : "audited in"
    
    products {
        varchar(30) product_id PK
        varchar(100) product_name
        varchar(60) category
        decimal(10,2) selling_price
        decimal(10,2) ingredient_cost_per_plate
        timestamp created_at
        timestamp updated_at
    }

    sales {
        varchar(30) sale_id PK
        datetime sale_datetime
        enum payment_method
        decimal(10,2) discount
        timestamp created_at
    }

    sale_items {
        varchar(40) sale_item_id PK
        varchar(30) sale_id FK
        varchar(30) product_id FK
        int quantity_plates
        decimal(10,2) unit_price
        timestamp created_at
    }

    ingredients {
        varchar(30) ingredient_id PK
        varchar(100) ingredient_name
        varchar(20) unit
        decimal(10,2) unit_cost
        decimal(10,2) reorder_level
        timestamp created_at
    }

    inventory_transactions {
        varchar(40) transaction_id PK
        date transaction_date
        varchar(30) ingredient_id FK
        enum transaction_type
        decimal(10,2) quantity
        varchar(50) reference_id
        timestamp created_at
    }

    daily_expenses {
        varchar(40) expense_id PK
        date expense_date
        varchar(60) expense_category
        decimal(10,2) amount
        timestamp created_at
    }
```

---

## 2. Normalization Process & Relational Proofs

The database was engineered from initial flat transaction logs through progressive normalization stages into **Third Normal Form (3NF)**:

### 2.1 First Normal Form (1NF)
- **Rule:** Every column contains atomic (indivisible) values, and each record is identified by a primary key.
- **Implementation:**
  - Flat orders containing comma-separated varieties (e.g. `Classic Golgappa, Sweet Pani Puri`) were decomposed into discrete rows within `sale_items`.
  - Date and time were unified into standard ISO `DATETIME` format (`YYYY-MM-DD HH:mm:ss`).
  - No repeating groups or array attributes exist in any relation.

### 2.2 Second Normal Form (2NF)
- **Rule:** Relation must be in 1NF, and all non-key attributes must be fully functionally dependent on the entire primary key (elimination of partial dependencies).
- **Implementation:**
  - In a composite sales-line relationship `(sale_id, product_id)`, storing the product name or category in the line-item table would violate 2NF because `product_name` depends only on `product_id`.
  - Master entity `products` was isolated. `sale_items` references `product_id` as a foreign key with line-specific measures (`quantity_plates`, `unit_price`).

### 2.3 Third Normal Form (3NF)
- **Rule:** Relation must be in 2NF, and no transitive dependencies exist (non-key attribute depends on another non-key attribute).
- **Implementation:**
  - In `inventory_transactions`, storing the ingredient's unit cost or reorder level alongside stock movements would create a transitive dependency:
    $$\text{transaction\_id} \to \text{ingredient\_id} \to \text{unit\_cost}$$
  - Master entity `ingredients` holds unit costs and safety thresholds. `inventory_transactions` records only the movement quantity and audit transaction type.

---

## 3. Physical Table DDL Specifications

```sql
CREATE DATABASE IF NOT EXISTS golgappa360
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE golgappa360;

-- 1. products
CREATE TABLE products (
    product_id VARCHAR(30) NOT NULL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(60) NOT NULL,
    selling_price DECIMAL(10, 2) NOT NULL,
    ingredient_cost_per_plate DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_selling_price CHECK (selling_price > 0),
    CONSTRAINT chk_ingredient_cost CHECK (ingredient_cost_per_plate > 0)
) ENGINE=InnoDB;

-- 2. sales (Header)
CREATE TABLE sales (
    sale_id VARCHAR(30) NOT NULL PRIMARY KEY,
    sale_datetime DATETIME NOT NULL,
    payment_method ENUM('UPI', 'Cash', 'Card') NOT NULL DEFAULT 'UPI',
    discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_discount CHECK (discount >= 0),
    INDEX idx_sale_datetime (sale_datetime),
    INDEX idx_payment_method (payment_method)
) ENGINE=InnoDB;

-- 3. sale_items (Line Items)
CREATE TABLE sale_items (
    sale_item_id VARCHAR(40) NOT NULL PRIMARY KEY,
    sale_id VARCHAR(30) NOT NULL,
    product_id VARCHAR(30) NOT NULL,
    quantity_plates INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_quantity CHECK (quantity_plates > 0),
    CONSTRAINT chk_unit_price CHECK (unit_price > 0),
    CONSTRAINT fk_sale_items_sale FOREIGN KEY (sale_id)
        REFERENCES sales(sale_id) ON DELETE CASCADE,
    CONSTRAINT fk_sale_items_product FOREIGN KEY (product_id)
        REFERENCES products(product_id) ON DELETE RESTRICT,
    INDEX idx_sale_items_product (product_id),
    INDEX idx_sale_items_sale (sale_id)
) ENGINE=InnoDB;

-- 4. ingredients
CREATE TABLE ingredients (
    ingredient_id VARCHAR(30) NOT NULL PRIMARY KEY,
    ingredient_name VARCHAR(100) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    unit_cost DECIMAL(10, 2) NOT NULL,
    reorder_level DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_unit_cost CHECK (unit_cost > 0),
    CONSTRAINT chk_reorder_level CHECK (reorder_level >= 0)
) ENGINE=InnoDB;

-- 5. inventory_transactions
CREATE TABLE inventory_transactions (
    transaction_id VARCHAR(40) NOT NULL PRIMARY KEY,
    transaction_date DATE NOT NULL,
    ingredient_id VARCHAR(30) NOT NULL,
    transaction_type ENUM('PURCHASE', 'CONSUMPTION', 'WASTE') NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    reference_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_quantity_pos CHECK (quantity > 0),
    CONSTRAINT fk_inv_ingredient FOREIGN KEY (ingredient_id)
        REFERENCES ingredients(ingredient_id) ON DELETE RESTRICT,
    INDEX idx_tx_date (transaction_date),
    INDEX idx_tx_type (transaction_type),
    INDEX idx_tx_ingredient (ingredient_id)
) ENGINE=InnoDB;

-- 6. daily_expenses
CREATE TABLE daily_expenses (
    expense_id VARCHAR(40) NOT NULL PRIMARY KEY,
    expense_date DATE NOT NULL,
    expense_category VARCHAR(60) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_expense_amount CHECK (amount > 0),
    INDEX idx_expense_date (expense_date),
    INDEX idx_expense_cat (expense_category)
) ENGINE=InnoDB;
```

---

## 4. Pre-Aggregated Analytical SQL Views

Four normalized views materialize complex multi-table joins for zero-latency dashboard queries and direct Tableau MySQL connectivity:

### View 1: `vw_dashboard_kpis`
Calculates platform-wide aggregate performance metrics:
```sql
CREATE OR REPLACE VIEW vw_dashboard_kpis AS
SELECT
    COUNT(DISTINCT s.sale_id) AS total_orders,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(SUM(si.quantity_plates * si.unit_price), 0.00) AS gross_revenue,
    COALESCE(SUM(s.discount), 0.00) AS total_discounts,
    COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0.00) AS net_revenue,
    COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00) AS total_cogs,
    COALESCE(
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - 
        SUM(si.quantity_plates * p.ingredient_cost_per_plate), 
        0.00
    ) AS gross_profit,
    ROUND(
        COALESCE(
            ((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) / 
            NULLIF(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0)) * 100, 
            0.0
        ), 1
    ) AS gross_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id;
```

### View 2: `vw_product_performance`
Ranks variety margins, unit economics, and revenue shares for menu engineering:
```sql
CREATE OR REPLACE VIEW vw_product_performance AS
SELECT
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_margin,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(SUM(si.quantity_plates * si.unit_price), 0.00) AS gross_revenue,
    COALESCE(SUM(s.discount), 0.00) AS allocated_discounts,
    COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0.00) AS net_revenue,
    COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00) AS total_cogs,
    COALESCE(
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - 
        SUM(si.quantity_plates * p.ingredient_cost_per_plate), 
        0.00
    ) AS gross_profit,
    ROUND(
        COALESCE(
            (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
            NULLIF(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0)) * 100,
            0.0
        ), 1
    ) AS gross_margin_pct
FROM products p
LEFT JOIN sale_items si ON p.product_id = si.product_id
LEFT JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate;
```

### View 3: `vw_daily_financial_summary`
Aggregates sales, COGS, waste loss, and overhead vouchers at the calendar-day grain:
```sql
CREATE OR REPLACE VIEW vw_daily_financial_summary AS
WITH DailySalesAgg AS (
    SELECT
        DATE(s.sale_datetime) AS sale_date,
        COUNT(DISTINCT s.sale_id) AS orders_count,
        SUM(si.quantity_plates) AS plates_sold,
        SUM(si.quantity_plates * si.unit_price) - SUM(s.discount) AS net_revenue,
        SUM(si.quantity_plates * p.ingredient_cost_per_plate) AS cogs,
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate) AS gross_profit
    FROM sales s
    JOIN sale_items si ON s.sale_id = si.sale_id
    JOIN products p ON si.product_id = p.product_id
    GROUP BY DATE(s.sale_datetime)
),
DailyExpensesAgg AS (
    SELECT
        expense_date,
        SUM(amount) AS total_expenses
    FROM daily_expenses
    GROUP BY expense_date
),
DailyWasteAgg AS (
    SELECT
        t.transaction_date,
        SUM(t.quantity * i.unit_cost) AS total_waste_cost
    FROM inventory_transactions t
    JOIN ingredients i ON t.ingredient_id = i.ingredient_id
    WHERE t.transaction_type = 'WASTE'
    GROUP BY t.transaction_date
)
SELECT
    ds.sale_date,
    DAYNAME(ds.sale_date) AS day_of_week,
    ds.orders_count,
    ds.plates_sold,
    ROUND(ds.net_revenue, 2) AS net_revenue,
    ROUND(ds.cogs, 2) AS cogs,
    ROUND(ds.gross_profit, 2) AS gross_profit,
    ROUND(COALESCE(dw.total_waste_cost, 0.00), 2) AS waste_cost,
    ROUND(COALESCE(de.total_expenses, 0.00), 2) AS operating_expenses,
    ROUND(ds.gross_profit - COALESCE(de.total_expenses, 0.00), 2) AS estimated_operating_profit
FROM DailySalesAgg ds
LEFT JOIN DailyExpensesAgg de ON ds.sale_date = de.expense_date
LEFT JOIN DailyWasteAgg dw ON ds.sale_date = dw.transaction_date;
```

### View 4: `vw_inventory_status`
Computes on-hand inventory balances and assigns real-time stock alert statuses:
```sql
CREATE OR REPLACE VIEW vw_inventory_status AS
WITH StockLedger AS (
    SELECT
        ingredient_id,
        SUM(CASE WHEN transaction_type = 'PURCHASE' THEN quantity ELSE 0 END) AS total_purchased,
        SUM(CASE WHEN transaction_type = 'CONSUMPTION' THEN quantity ELSE 0 END) AS total_consumed,
        SUM(CASE WHEN transaction_type = 'WASTE' THEN quantity ELSE 0 END) AS total_wasted
    FROM inventory_transactions
    GROUP BY ingredient_id
)
SELECT
    i.ingredient_id,
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    i.reorder_level,
    COALESCE(sl.total_purchased, 0.00) AS total_purchased,
    COALESCE(sl.total_consumed, 0.00) AS total_consumed,
    COALESCE(sl.total_wasted, 0.00) AS total_wasted,
    ROUND(
        COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00),
        2
    ) AS current_stock,
    ROUND(
        (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) * i.unit_cost,
        2
    ) AS inventory_value,
    CASE
        WHEN (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) <= (i.reorder_level * 0.5) THEN 'Critical'
        WHEN (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) <= i.reorder_level THEN 'Low'
        ELSE 'Healthy'
    END AS stock_status
FROM ingredients i
LEFT JOIN StockLedger sl ON i.ingredient_id = sl.ingredient_id;
```
