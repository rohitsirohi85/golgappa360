import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Zap, ArrowRight, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';

export const LoginScreen = () => {
  const navigate = useNavigate();
  const { login, demoLogin } = useAuth();
  const { showToast } = useUI();

  const [identifier, setIdentifier] = useState('suman@example.com');
  const [password, setPassword] = useState('password123');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const handleLogin = async (e) => {
    e?.preventDefault();
    if (!identifier) {
      showToast('Please enter your email or mobile number', 'error');
      return;
    }
    const passToSend = password === '••••••••' ? 'password123' : password;
    try {
      await login(identifier, passToSend);
      showToast('Welcome back, Suman!', 'success');
      navigate('/home');
    } catch (err) {
      showToast(err.message || 'Login failed', 'error');
    }
  };

  const handleDemoLogin = () => {
    demoLogin();
    showToast('Logged in as Demo User (Suman)', 'success');
    navigate('/home');
  };

  const handleResetPassword = () => {
    setIsForgotModalOpen(false);
    showToast('Reset link sent to ' + (resetEmail || 'your email'), 'success');
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-6 select-none">
      {/* Brand Header */}
      <div className="pt-4">
        <div className="flex items-center gap-2 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-[#00F5A0]/15 border border-[#00F5A0]/30 flex items-center justify-center shadow-[0_0_15px_rgba(0,245,160,0.3)]">
            <Zap className="w-5 h-5 text-[#00F5A0] fill-[#00F5A0]" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold tracking-tight text-white leading-tight">
              EV <span className="text-[#00F5A0]">Smart</span>
            </h2>
            <p className="text-[11px] text-slate-400">Charge Smarter. Drive Further.</p>
          </div>
        </div>

        <h1 className="text-2xl font-bold text-white tracking-tight">
          Welcome Back 👋
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Login to manage your EV charging slots and monitor real-time energy.
        </p>
      </div>

      {/* Form Area */}
      <form onSubmit={handleLogin} className="space-y-4 my-6">
        <Input
          label="Email or Mobile Number"
          placeholder="name@example.com or +91..."
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          icon={Mail}
          required
        />

        <Input
          label="Password"
          type={showPassword ? 'text' : 'password'}
          placeholder="Enter your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          icon={Lock}
          required
          rightElement={
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-slate-400 hover:text-slate-200"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          }
        />

        {/* Options */}
        <div className="flex items-center justify-between text-xs pt-1">
          <label className="flex items-center gap-2 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 rounded bg-[#0D1527] border-white/20 text-[#00F5A0] focus:ring-0 accent-[#00F5A0]"
            />
            <span>Remember Me</span>
          </label>

          <button
            type="button"
            onClick={() => setIsForgotModalOpen(true)}
            className="text-xs font-semibold text-[#00F5A0] hover:underline"
          >
            Forgot Password?
          </button>
        </div>

        {/* Primary Login Button */}
        <div className="pt-2">
          <Button type="submit" size="lg" fullWidth>
            Login
          </Button>
        </div>
      </form>

      {/* Demo User High-Visibility Shortcut */}
      <div className="space-y-3 pb-2">
        <div className="relative flex items-center justify-center my-2">
          <div className="border-t border-white/10 w-full" />
          <span className="bg-[#070B19] px-3 text-[11px] text-slate-500 uppercase tracking-wider shrink-0 font-medium">
            Quick Testing Access
          </span>
          <div className="border-t border-white/10 w-full" />
        </div>

        {/* Continue as Demo User Button */}
        <button
          type="button"
          onClick={handleDemoLogin}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#00F5A0]/15 via-[#00E5FF]/15 to-[#00F5A0]/15 border border-[#00F5A0]/40 hover:border-[#00F5A0] text-[#00F5A0] hover:text-white font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,245,160,0.15)] active:scale-[0.98]"
        >
          <ShieldCheck className="w-4 h-4 text-[#00F5A0]" />
          <span>Continue as Demo User</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        {/* Secondary Register */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-400">
            Don't have an account?{' '}
            <button
              type="button"
              onClick={() => navigate('/register')}
              className="text-[#00F5A0] font-semibold hover:underline"
            >
              Create Account
            </button>
          </p>
        </div>

        {/* Switch to Commercial Admin Portal */}
        <div className="pt-1 text-center">
          <button
            type="button"
            onClick={() => navigate('/admin/login')}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition-colors"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Switch to Commercial Fleet Admin Portal</span>
          </button>
        </div>
      </div>

      {/* Forgot Password Modal */}
      <Modal
        isOpen={isForgotModalOpen}
        onClose={() => setIsForgotModalOpen(false)}
        title="Reset Password"
        subtitle="Enter your email to receive recovery instructions."
      >
        <div className="space-y-4">
          <Input
            label="Registered Email"
            placeholder="suman@example.com"
            value={resetEmail}
            onChange={(e) => setResetEmail(e.target.value)}
            icon={Mail}
          />
          <div className="flex gap-2.5 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => setIsForgotModalOpen(false)}
            >
              Cancel
            </Button>
            <Button fullWidth onClick={handleResetPassword}>
              Send Link
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
