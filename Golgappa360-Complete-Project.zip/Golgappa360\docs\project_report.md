# Golgappa360 — Golgappa Business Intelligence & Sales Analytics System
## Comprehensive MCA Major Capstone Project Report

---

```
                       PROJECT REPORT ON
                  Golgappa360: Golgappa Business
             Intelligence & Sales Analytics System

      Submitted in partial fulfillment of the requirements for the
                      award of the degree of
               MASTER OF COMPUTER APPLICATIONS (MCA)

                              By:
                  [Candidate Name Placeholder]
                [Roll / Registration Number Placeholder]

                       Under the Guidance of:
                   [Faculty Advisor Name Placeholder]
                     [Department & Designation]

             [DEPARTMENT OF COMPUTER SCIENCE & APPLICATIONS]
                  [INSTITUTE / UNIVERSITY NAME]
                            [CITY, STATE]
                           [YEAR: 2026]
```

---

## Certificate & Declaration Placeholders

### Certificate of the Head of Department & Guide
*This is to certify that the project report entitled **"Golgappa360 — Golgappa Business Intelligence & Sales Analytics System"**, submitted by **[Candidate Name Placeholder]** (Roll No: **[Roll Number Placeholder]**), in partial fulfillment of the requirements for the award of the Degree of Master of Computer Applications, is an authentic record of the work carried out under our supervision and guidance.*

---

## Abstract

Micro, Small, and Medium Enterprises (MSMEs) in the Indian unorganized food and street-vending sector process billions of rupees in cash and digital micro-transactions annually. Despite high footfall and substantial turnover, street-food stalls (specifically golgappa and pani puri vendors) face significant profitability challenges due to reliance on intuition-based operations. Stall operators lack visibility into portion recipe Bill of Materials (BOM) costing, ingredient price volatility, rush-hour service bottlenecks, food spoilage, and payment method shifts.

**Golgappa360** is a full-stack, enterprise-grade business intelligence and analytics system designed to empower street-food entrepreneurs with data-driven decision support. The platform implements a **Multi-Tiered Dual-Engine Architecture** pairing an indexed MySQL 8.0 relational database with a resilient, in-memory analytical engine. The system provides:
1. An executive dashboard built with React 19, Vite, and Tailwind CSS adhering to an editorial dark glassmorphism design aesthetic (`#171717` canvas with translucent cards).
2. A 6-month calibrated operating dataset ($N = 31,938$ orders, 47,658 plates sold, ₹1,759,965.00 net revenue).
3. A normalized Third Normal Form (3NF) relational database schema with four pre-aggregated analytical views and 30 documented SQL queries.
4. Six RFC 4180 compliant CSV exports for Tableau Desktop/Public and Microsoft Excel, connected via logical relationships to prevent Cartesian product fan traps.
5. Automated validation confirming mathematical parity ($₹0.00$ variance) across all tiers.

---

## Table of Contents
1. Introduction & Background
2. Problem Statement
3. Project Objectives & Scope
4. Comparison of Existing vs. Proposed System
5. Software & Hardware Requirements
6. System Architecture & Dual-Engine Strategy
7. Relational Database Design & 3NF Schema
8. Dataset Description & Semantic Catalog
9. Microsoft Excel Analytical Workflow
10. SQL Analytics Library & Pedagogical Queries
11. Tableau Dashboard Methodology & Calculations
12. Comprehensive Results from the Verified Dataset
13. Limitations & Constraints
14. Future Scope & Roadmap
15. Conclusion
16. References

---

## 1. Introduction & Background

The street-food economy in India represents an essential pillar of urban retail commerce, generating livelihoods for millions and providing accessible dining for daily commuters. Among all street-food categories, *golgappa* (alternatively known as *pani puri*, *puchka*, or *batasha*) is uniquely characterized by high volume, low ticket size (averaging ₹30–₹40 per plate), rapid table turnover (under 5 minutes per customer), and perishable ingredients (mint-coriander water, boiled potatoes, sprouted legumes, and curd).

Traditionally, stall operators have tracked operations through mental arithmetic or paper diary logs. However, the rapid nationwide adoption of Unified Payments Interface (UPI) QR codes, combined with raw material inflation (suji, edible oil, and vegetables), has increased operational complexity. Vendors now face digital liquidity delays, stockouts during evening commuter surges, and food wastage due to over-preparation on slow afternoons.

Golgappa360 addresses these challenges by introducing modern enterprise business intelligence principles into a micro-retail context.

---

## 2. Problem Statement

Street-food vendors face four acute operational challenges:
1. **Lack of Recipe Bill of Materials (BOM) Costing:** Vendors do not know their precise cost per plate, preventing them from knowing whether an item (e.g. Dahi Puri vs. Classic Golgappa) is generating healthy margins or eroding profit.
2. **Unmonitored Food Waste & Shrinkage:** Puris crushed in transit and souring flavoured mint water at day's end are written off as unavoidable losses rather than measured, manageable expenses.
3. **Capacity & Footfall Mismatches:** Evening commuter rushes (5:30 PM to 8:30 PM) create long queues and stockouts if preparations are delayed, while over-prepping on slow weekday afternoons results in discarded spiced water.
4. **Disjointed Accounting:** Differences in accounting definitions between cash collections, discounts, raw material purchases, and stall overheads lead to confusion between gross turnover and net take-home profit.

---

## 3. Project Objectives & Scope

### 3.1 Primary Objectives
1. **Develop an Interactive Analytics Dashboard:** Build a responsive, accessible React 19 interface providing real-time visibility into sales, menu variety contributions, inventory runway, and food waste.
2. **Implement a Dual-Engine Data Architecture:** Ensure 100% platform availability by uniting a normalized MySQL 8.0 database with an automatic in-memory fallback engine.
3. **Establish Unified Accounting Standards:** Enforce strict financial invariants across frontend calculations, backend APIs, SQL views, Excel models, and Tableau workbooks:
   $$\text{Net Revenue} = \text{Gross Sales} - \text{Discounts}$$
   $$\text{Gross Profit} = \text{Net Revenue} - \text{COGS}$$
   $$\text{Operating Profit} = \text{Gross Profit} - \text{Operating Expenses}$$
4. **Mitigate Food Spoilage:** Analyze root causes of waste and generate actionable prep guidelines.
5. **Deliver Production BI Exports:** Produce certified RFC 4180 CSV exports and step-by-step build guides for Tableau Desktop and Microsoft Excel.

### 3.2 Project Scope & Boundaries
- **Enterprise Scope:** Single high-velocity urban street-food stall (*Sharma Ji Golgappa Center*, Karol Bagh, New Delhi).
- **Temporal Scope:** 6 Months of continuous operations (2026-05-01 through 2026-10-29; 182 operational days).
- **Data Source:** Calibrated synthetic dataset based on empirical stall operating benchmarks.

---

## 4. Comparison of Existing vs. Proposed System

| Operational Dimension | Existing Intuitive Approach | Proposed Golgappa360 System |
|:---|:---|:---|
| **Sales Tracking** | Mental estimation; manual cash counting at night | Granular order-level invoice tracking with timestamps and payment tenders |
| **Recipe Costing** | Guessed margins; flat pricing | Dynamic Bill of Materials (BOM) costing per plate with margin contribution ranking |
| **Inventory Control** | Reactive purchasing after running out | Proactive stock runway monitoring with automated low-stock and critical reorder alerts |
| **Food Waste Management** | Discarded unmeasured; treated as unavoidable loss | Measured tracking by ingredient and root cause (transit breakage vs. oxidation) |
| **Financial Reporting** | Cash in drawer confused with true net profit | Clear distinction between Gross Sales, Net Revenue, COGS, Gross Profit, and Operating Profit |
| **Business Intelligence** | None | Full Tableau Star-Schema models, 30 production SQL queries, and Excel Pivot models |

---

## 5. Software & Hardware Requirements

### 5.1 Software Requirements
- **Operating System:** Windows 10/11, macOS, or Ubuntu Linux 22.04 LTS.
- **Client Runtime & Framework:** React 19.0.0, Vite 8.3.0, Tailwind CSS v4, Recharts 2.15, Lucide React.
- **Server Runtime & Framework:** Node.js v18.0+ to v24.14.0, Express 4.21.
- **Database Management System:** MySQL Server 8.0+ with InnoDB storage engine; `mysql2/promise` connection pooling.
- **BI & Analytics Software:** Tableau Desktop 2020.2+ / Tableau Public, Microsoft Excel 2016 / 2019 / 365.

### 5.2 Hardware Requirements
- **Processor:** Intel Core i3 / AMD Ryzen 3 or higher (Quad-core recommended).
- **Memory (RAM):** 8 GB minimum (16 GB recommended for local MySQL + Vite + Tableau concurrent sessions).
- **Storage:** 500 MB free disk space for application files and CSV exports.

---

## 6. System Architecture & Dual-Engine Strategy

Golgappa360 employs a multi-tiered architecture with four distinct layers:

1. **Presentation Tier:** React 19 single-page application styled with dark glassmorphism design tokens (`#171717` canvas, translucent glass cards with backdrop blur, sage-green `#A7D78A` highlights, and saffron `#EAB64B` accents).
2. **Service Tier:** Node.js and Express REST API listening on port 5000, enforcing input validation (`validateDateRange`, `validatePagination`) and sanitizing error output.
3. **Data Tier (Dual-Engine):**
   - *Primary:* MySQL 8.0 relational schema with connection pooling, 6 tables in 3NF, and 4 pre-aggregated views.
   - *Fallback:* High-fidelity in-memory synthetic analytics store (`syntheticStore.js`) ensuring seamless operation when MySQL is unconfigured.
4. **BI & Export Tier:** Pre-computed star-schema RFC 4180 CSV exports for Tableau Desktop and Microsoft Excel.

---

## 7. Relational Database Design & 3NF Schema

The database `golgappa360` contains six normalized tables in Third Normal Form (3NF):
1. `products`: Master variety catalog with selling prices and standard BOM ingredient costs.
2. `sales`: Customer order header recording timestamp, payment method, and discounts.
3. `sale_items`: Normalized line items linking products to parent orders with quantities and unit prices.
4. `ingredients`: Raw material master with wholesale unit costs and safety reorder thresholds.
5. `inventory_transactions`: Stock ledger tracking purchases, kitchen consumption, and recorded food waste.
6. `daily_expenses`: Stall overhead vouchers (rent, packaging, gas, electricity, sanitation).

Four analytical views materialize multi-table aggregations:
- `vw_dashboard_kpis`: High-level turnover and margins.
- `vw_product_performance`: Variety contribution ranking.
- `vw_daily_financial_summary`: Daily Net Revenue, COGS, Waste, and Operating Profit.
- `vw_inventory_status`: Real-time stock runway and alert classification.

---

## 8. Dataset Description & Semantic Catalog

The 6-month operational dataset covers 182 days (2026-05-01 to 2026-10-29):
- **Sales Transactions:** 31,938 order items across 5 varieties.
- **Portion Volume:** 47,658 plates served.
- **Inventory Ledger:** 2,391 stock movements across 8 raw ingredients.
- **Operating Overheads:** 845 expense vouchers across 5 overhead categories.

---

## 9. Microsoft Excel Analytical Workflow

The exported files are formatted in RFC 4180 UTF-8 standard, enabling direct analysis in Microsoft Excel:
- **Ingestion via Power Query:** Preserves ISO date formatting and numeric decimals.
- **Pivot Tables:**
  1. Monthly Product Revenue & Margin Matrix.
  2. Hourly Footfall Heatmap Matrix (`day_of_week` vs. `sale_hour`).
  3. UPI vs. Cash Tender Adoption.
  4. Raw Ingredient Consumption vs. Food Waste.
- **Verification Formulas:** Cross-checked with `SUMIFS`, `COUNTIFS`, and `XLOOKUP` to match SQL benchmarks.

---

## 10. SQL Analytics Library & Pedagogical Queries

The project includes 30 documented queries in `server/sql/analytics_queries.sql` covering 20 pedagogical categories:
- Basic SELECT, WHERE, and ORDER BY.
- Aggregates (`SUM`, `AVG`, `MIN`, `MAX`, `COUNT`, `AOV`, `ASP`).
- `GROUP BY` and `HAVING` (filtering high-volume operational days > ₹12,000).
- Multi-table INNER and LEFT JOINs.
- Common Table Expressions (CTEs) for customer basket size and ingredient shrinkage.
- Window functions for cumulative running totals and 7-day rolling moving averages.
- Window ranking functions (`RANK()`, `DENSE_RANK()`).
- Data quality reconciliation checks (orphan order items, negative inventory balances).

---

## 11. Tableau Dashboard Methodology & Calculations

### 11.1 Logical Relationships (The "Noodle") vs. Physical Joins
To prevent Cartesian explosion fan traps (which would inflate 31,938 orders and 2,391 inventory rows into over 76 million records), tables are connected in Tableau using Logical Relationships on `product_id` and `sale_date`.

### 11.2 Four Interactive Dashboards
1. **Business Overview:** 5 KPI cards, daily revenue dual-axis area chart with 7-day MA, weekday bar chart, and UPI/Cash donut.
2. **Sales Analytics:** 8-hour commuter footfall heatmap (3 PM to 10 PM), quantity vs. revenue scatter plot, and dynamic granularity parameter.
3. **Inventory & Waste:** Stock runway bullet chart, threshold status, and food waste cost breakdown.
4. **Expenses & Profitability:** Bottom-line stall viability waterfall, monthly P&L, and variety margin comparison.

---

## 12. Comprehensive Results from the Verified Dataset

All analytical tiers produce verified, identical figures ($₹0.00$ variance):

| Metric | Verified Value | Percentage |
|:---|:---:|:---:|
| **Gross Turnover** | ₹1,765,505.00 | 100.31% of Net |
| **Promotional Discounts** | ₹5,540.00 | 0.31% of Net |
| **Net Collected Revenue** | ₹1,759,965.00 | 100.00% |
| **Cost of Goods Sold (COGS)** | ₹492,957.90 | 28.01% |
| **Gross Profit** | ₹1,267,007.10 | **71.99%** |
| **Operating Overheads** | ₹126,540.06 | 7.19% |
| **Food Waste Financial Loss** | ₹11,626.98 | 0.66% |
| **Estimated Operating Profit** | ₹1,140,467.04 | **64.80%** |
| **Total Plates Sold** | 47,658 plates | — |
| **Total Orders Served** | 31,938 orders | — |
| **Average Order Value (AOV)** | ₹55.11 | — |
| **Average Selling Price (ASP)** | ₹36.93 | — |
| **Digital Payments Adoption** | 64.6% of orders | 65.5% of revenue |

### Operational Findings
1. **Evening Commuter Surge:** The 3-hour window between 5:30 PM and 8:30 PM generates **58.4% of total daily revenue**.
2. **Food Waste Breakdown:** Transit and storage breakage of puris represents **42.0% of total waste loss**, followed by souring mint water (**35.3%**) and fermented potato-vatana mash (**22.7%**).

---

## 13. Limitations & Constraints

1. **Synthetic Data Calibration:** The current dataset is calibrated from empirical stall benchmarks rather than live IoT scale telemetry.
2. **Single-Stall Scope:** The system currently models a single stall location rather than a multi-franchise chain.
3. **Manual Entry for Restocks:** Ingredient restocking currently relies on manual form entries rather than optical invoice scanning.

---

## 14. Future Scope & Roadmap

1. **IoT Scale Integration:** Connecting digital weighing scales to automate ingredient consumption and waste logging.
2. **Automated WhatsApp Purchase Orders:** Triggering automated supplier restock messages via WhatsApp Business API when ingredients reach reorder thresholds.
3. **Predictive Machine Learning Forecasting:** Implementing weather-adjusted footfall models to forecast preparation batches dynamically.
4. **Franchise Multi-Tenant Architecture:** Extending the database schema to support multi-stall chains with centralized headquarters analytics.

---

## 15. Conclusion

Golgappa360 demonstrates how modern business intelligence, database normalization, and web engineering principles can be applied to micro-retail food enterprises in India. By establishing unified accounting standards, providing an active dual-engine backend, and delivering reconciled Tableau CSV exports, the platform proves that data-driven operational decision making can reduce food waste, optimize prep schedules, and protect small business profit margins.

---

## 16. References

1. Date, C. J. (2003). *An Introduction to Database Systems* (8th ed.). Addison-Wesley.
2. Silberschatz, A., Korth, H. F., & Sudarshan, S. (2019). *Database System Concepts* (7th ed.). McGraw-Hill.
3. Few, S. (2006). *Information Dashboard Design: The Effective Visual Communication of Data*. O'Reilly Media.
4. Tableau Software. (2020). *The Tableau Data Model: Logical Relationships vs Physical Joins*. Official Whitepaper.
5. National Restaurant Association of India (NRAI). (2024). *India Food Services Report: Street Food & Micro-Enterprise Analytics*.
6. Express.js Documentation. *Production Best Practices: Performance and Reliability*. https://expressjs.com/
7. React Documentation. *React 19 Hooks and Component Architecture*. https://react.dev/
