import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import { DAILY_WASTE_TREND } from '../../data/mockWasteData';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="rounded-lg bg-white border border-[#E4EAE5] p-3 shadow-lg text-xs space-y-1.5 min-w-[180px]">
        <div className="font-semibold text-[#25332D] border-b border-[#EEF2EF] pb-1 flex items-center justify-between">
          <span>{label}</span>
          <span className="text-[10px] font-mono text-[#16865B]">Att: {data.attendance}</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Total Prepared:</span>
          <span className="font-mono font-medium text-[#25332D]">{data.preparedKg} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Food Wasted:</span>
          <span className="font-mono font-bold text-[#B91C1C]">{data.wasteKg} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Waste Rate:</span>
          <span className="font-mono font-semibold text-[#D97706]">{data.wastePct}%</span>
        </div>
        <div className="pt-1 text-[10px] text-[#77847C] font-mono flex items-center justify-between border-t border-[#EEF2EF]">
          <span>Tolerance Cap:</span>
          <span>{data.threshold} kg</span>
        </div>
      </div>
    );
  }
  return null;
};

export const DailyWasteTrendChart = () => {
  const [metricView, setMetricView] = useState('kg'); // 'kg' | 'percentage'

  return (
    <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
              Daily Waste Trend
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                14-Day Cycle
              </span>
            </h3>
          </div>
          <p className="text-xs text-[#77847C] mt-0.5">
            Measured daily kitchen prep residue and plate waste telemetry (kg)
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="bg-[#F8FAF8] p-0.5 rounded-lg border border-[#E4EAE5] flex text-xs">
            <button
              onClick={() => setMetricView('kg')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                metricView === 'kg'
                  ? 'bg-white text-[#16865B] border border-[#C5E5D0] shadow-xs'
                  : 'text-[#77847C] hover:text-[#25332D]'
              }`}
            >
              Volume (kg)
            </button>
            <button
              onClick={() => setMetricView('percentage')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                metricView === 'percentage'
                  ? 'bg-white text-[#16865B] border border-[#C5E5D0] shadow-xs'
                  : 'text-[#77847C] hover:text-[#25332D]'
              }`}
            >
              Rate (%)
            </button>
          </div>
        </div>
      </div>

      <div className="h-64 sm:h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {metricView === 'kg' ? (
            <AreaChart data={DAILY_WASTE_TREND} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="wasteKgGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#16865B" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#16865B" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
              <XAxis
                dataKey="date"
                stroke="#D2DDD4"
                tick={{ fill: '#77847C', fontSize: 11 }}
                axisLine={{ stroke: '#E4EAE5' }}
                tickLine={false}
              />
              <YAxis
                stroke="#D2DDD4"
                tick={{ fill: '#77847C', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={220} stroke="#EF4444" strokeDasharray="4 4" label={{ value: 'Target Limit (220 kg)', fill: '#DC2626', fontSize: 10, position: 'insideTopRight' }} />
              <Area
                type="monotone"
                dataKey="wasteKg"
                name="Waste Recorded (kg)"
                stroke="#16865B"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#wasteKgGradient)"
                activeDot={{ r: 5, fill: '#16865B', stroke: '#FFFFFF', strokeWidth: 2 }}
              />
            </AreaChart>
          ) : (
            <AreaChart data={DAILY_WASTE_TREND} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="wastePctGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#D97706" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#D97706" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
              <XAxis
                dataKey="date"
                stroke="#D2DDD4"
                tick={{ fill: '#77847C', fontSize: 11 }}
                axisLine={{ stroke: '#E4EAE5' }}
                tickLine={false}
              />
              <YAxis
                stroke="#D2DDD4"
                tick={{ fill: '#77847C', fontSize: 11 }}
                unit="%"
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={10.0} stroke="#16865B" strokeDasharray="3 3" label={{ value: 'Target Goal (10%)', fill: '#16865B', fontSize: 10, position: 'insideTopRight' }} />
              <Area
                type="monotone"
                dataKey="wastePct"
                name="Waste Ratio (%)"
                stroke="#D97706"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#wastePctGradient)"
                activeDot={{ r: 5, fill: '#D97706', stroke: '#FFFFFF', strokeWidth: 2 }}
              />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>

      <div className="mt-3 pt-3 border-t border-[#EEF2EF] flex flex-wrap items-center justify-between text-[11px] text-[#77847C]">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#16865B]"></span>
            Recorded Waste Trend
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-[#EF4444]"></span>
            Mess Capacity Threshold
          </span>
        </div>
        <span className="text-[#77847C] font-mono">
          Avg 14d Waste: 268 kg/day
        </span>
      </div>
    </div>
  );
};
