import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { HorizontalDateSelector } from '../components/booking/HorizontalDateSelector';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const SlotBookingScreen = () => {
  const navigate = useNavigate();
  const { stationId, chargerId } = useParams();
  const { stations, selectedStation, selectedCharger, addBooking } = useEV();
  const { showToast } = useUI();

  const station = stations.find((s) => s.id === stationId) || selectedStation || stations[0];
  const charger =
    station.chargers?.find((c) => c.id === chargerId) || selectedCharger || station.chargers[0];

  const [selectedDate, setSelectedDate] = useState('24 Sep 2026');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('04:00 PM – 05:00 PM');

  // Time slots with availability status
  const timeSlots = [
    { time: '02:00 PM – 03:00 PM', available: true },
    { time: '03:00 PM – 04:00 PM', available: true },
    { time: '04:00 PM – 05:00 PM', available: true, recommended: true },
    { time: '05:00 PM – 06:00 PM', available: true },
    { time: '06:00 PM – 07:00 PM', available: false, reason: 'Reserved' },
    { time: '07:00 PM – 08:00 PM', available: true },
    { time: '08:00 PM – 09:00 PM', available: true },
  ];

  const handleConfirm = () => {
    if (!selectedTimeSlot) {
      showToast('Please select a time slot', 'error');
      return;
    }

    const newBooking = addBooking({
      date: selectedDate,
      time: selectedTimeSlot,
    });

    showToast('Booking Confirmed! Slot successfully locked.', 'success');
    navigate(`/booking-confirmation/${newBooking.id}`);
  };

  return (
    <div className="flex flex-col min-h-full justify-between pb-6 select-none">
      <div>
        <Header title="Reserve Charging Slot" showBack onBack={() => navigate(-1)} />

        <div className="px-4 py-4 space-y-5">
          {/* 1. Date Selector */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                1. Select Date
              </span>
              <span className="text-xs text-[#00F5A0] font-semibold">
                {selectedDate}
              </span>
            </div>
            <HorizontalDateSelector
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
            />
          </div>

          {/* 2. Time Slot Selector */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                2. Select Time Slot
              </span>
              <span className="text-[11px] text-slate-400">1 hour slots</span>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {timeSlots.map((slot, idx) => {
                const isSelected = selectedTimeSlot === slot.time;
                const isAvailable = slot.available;

                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={!isAvailable}
                    onClick={() => isAvailable && setSelectedTimeSlot(slot.time)}
                    className={`
                      flex items-center justify-between p-3 rounded-2xl border transition-all duration-200 text-left
                      ${
                        isSelected
                          ? 'bg-[#00F5A0]/15 border-[#00F5A0] text-white shadow-[0_0_15px_rgba(0,245,160,0.2)]'
                          : isAvailable
                          ? 'bg-[#0D1527] text-slate-200 border-white/10 hover:border-white/20 hover:bg-[#131E35]'
                          : 'bg-[#070B19]/50 text-slate-500 border-white/5 cursor-not-allowed opacity-50'
                      }
                    `}
                  >
                    <div className="flex items-center gap-2.5">
                      <Clock
                        className={`w-4 h-4 ${
                          isSelected ? 'text-[#00F5A0]' : isAvailable ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      />
                      <span className="text-xs font-semibold">{slot.time}</span>
                      {slot.recommended && isAvailable && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold uppercase">
                          Popular
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-semibold">
                      {isAvailable ? (
                        <span className="flex items-center gap-1 text-emerald-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Available
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-rose-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                          Booked
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Booking Summary Card */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2.5">
              3. Booking Summary
            </span>

            <Card className="bg-[#0D1527] border-white/10 p-4 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Station:</span>
                <span className="font-bold text-white">{station.name}</span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Charger:</span>
                <span className="font-bold text-[#00E5FF] font-mono">
                  {charger.id} ({charger.name})
                </span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Date:</span>
                <span className="font-semibold text-white">{selectedDate}</span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Time:</span>
                <span className="font-semibold text-emerald-400 font-mono">
                  {selectedTimeSlot}
                </span>
              </div>

              <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-400">Estimated Rate:</span>
                <span className="font-bold text-base text-[#00F5A0] font-mono">
                  ₹{charger.rate || 10}/kWh
                </span>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Primary Confirm Button */}
      <div className="px-4 pt-2">
        <Button
          size="lg"
          fullWidth
          onClick={handleConfirm}
          icon={CheckCircle2}
          iconPosition="right"
        >
          Confirm Booking
        </Button>
      </div>
    </div>
  );
};
