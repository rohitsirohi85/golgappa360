import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Car,
  ChevronRight,
  Shield,
  Bell,
  Globe,
  Moon,
  HelpCircle,
  FileText,
  LogOut,
  Zap,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';

export const ProfileScreen = () => {
  const navigate = useNavigate();
  const { user, vehicle, logout } = useAuth();
  const { showToast } = useUI();

  const handleLogout = () => {
    logout();
    showToast('Logged out successfully', 'info');
    navigate('/login');
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      {/* Top Profile Header */}
      <div className="p-6 bg-gradient-to-b from-[#0D182E] to-[#070B19] border-b border-white/5 flex flex-col items-center text-center">
        <div className="relative mb-3">
          <div className="w-20 h-20 rounded-full border-2 border-[#00F5A0] overflow-hidden shadow-[0_0_20px_rgba(0,245,160,0.3)]">
            <img
              src={user?.avatar}
              alt={user?.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute bottom-0 right-0 p-1.5 rounded-full bg-[#00F5A0] text-[#050811] shadow">
            <Zap className="w-3.5 h-3.5 fill-[#050811]" />
          </div>
        </div>

        <h2 className="text-xl font-bold text-white tracking-tight">
          {user?.name || 'Suman'}
        </h2>
        <span className="text-xs text-slate-400 font-mono mt-0.5">
          {user?.email || 'suman@example.com'}
        </span>
      </div>

      <div className="px-4 py-4 space-y-5">
        {/* Section 1: Vehicle */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Vehicle Details
          </span>
          <Card className="bg-[#0D1527] border-white/10 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#00F5A0]/10 border border-[#00F5A0]/20 text-[#00F5A0]">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">
                    {vehicle?.make} {vehicle?.model}
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">
                    {vehicle?.batteryCapacity} kWh Capacity • {vehicle?.connector}
                  </span>
                </div>
              </div>
            </div>

            <Button
              size="sm"
              variant="outline"
              fullWidth
              onClick={() => navigate('/vehicle-management')}
            >
              Edit Vehicle Information
            </Button>
          </Card>
        </div>

        {/* Section 2: Account */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Account
          </span>
          <div className="bg-[#0D1527] rounded-2xl border border-white/5 divide-y divide-white/5 overflow-hidden">
            <button
              onClick={() => showToast('Personal details editor', 'info')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-slate-400" />
                <span>Personal Information</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => showToast('Security & password manager', 'info')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Shield className="w-4 h-4 text-slate-400" />
                <span>Password & Security</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => navigate('/notifications')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Bell className="w-4 h-4 text-slate-400" />
                <span>Notifications</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
        </div>

        {/* Section 3: App */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Application
          </span>
          <div className="bg-[#0D1527] rounded-2xl border border-white/5 divide-y divide-white/5 overflow-hidden">
            <button
              onClick={() => navigate('/settings')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-slate-400" />
                <span>Language & Region</span>
              </div>
              <span className="text-slate-500 text-[11px] flex items-center gap-1">
                English <ChevronRight className="w-4 h-4" />
              </span>
            </button>

            <button
              onClick={() => navigate('/settings')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Moon className="w-4 h-4 text-slate-400" />
                <span>Theme</span>
              </div>
              <span className="text-[#00F5A0] text-[11px] flex items-center gap-1">
                Dark Neon <ChevronRight className="w-4 h-4" />
              </span>
            </button>

            <button
              onClick={() => showToast('Help & Support: 24/7 Helpline 1800-EV-SMART', 'info')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <HelpCircle className="w-4 h-4 text-slate-400" />
                <span>Help & Support</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => showToast('Privacy Policy & Terms of Service', 'info')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>Terms & Privacy</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
        </div>

        {/* Logout Button */}
        <div className="pt-2">
          <Button
            size="lg"
            variant="danger"
            fullWidth
            onClick={handleLogout}
            icon={LogOut}
          >
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
};
