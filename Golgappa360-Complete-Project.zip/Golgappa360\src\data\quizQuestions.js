/**
 * STELLAR — Observatory Challenge Quiz Question Bank
 * Comprehensive astronomical question bank with 30+ scientifically verified
 * questions across Easy, Intermediate, and Expert difficulty levels.
 */

export const QUIZ_QUESTIONS = [
  // ==========================================
  // EASY LEVEL (10+ Questions)
  // ==========================================
  {
    id: 'easy-01',
    difficulty: 'easy',
    category: 'Stars',
    question: 'Which star is physically closest to planet Earth?',
    options: ['The Sun', 'Proxima Centauri', 'Sirius', 'Polaris'],
    correctAnswer: 'The Sun',
    explanation: 'The Sun is the central star of our Solar System, located approximately 93 million miles (1 AU or 8.3 light-minutes) from Earth. Proxima Centauri is the closest extrasolar star at 4.25 light-years.',
  },
  {
    id: 'easy-02',
    difficulty: 'easy',
    category: 'Astronomy Basics',
    question: 'What fundamental process powers stars throughout their main-sequence lifetime?',
    options: ['Nuclear fusion', 'Chemical combustion', 'Gravitational friction', 'Radioactive fission'],
    correctAnswer: 'Nuclear fusion',
    explanation: 'Stars generate tremendous energy in their scorching cores by fusing lighter hydrogen nuclei into heavier helium nuclei under extreme gravitational pressure and heat.',
  },
  {
    id: 'easy-03',
    difficulty: 'easy',
    category: 'Spectral Classes',
    question: 'Which color corresponds to the hottest stellar surface temperature?',
    options: ['Blue', 'Red', 'Yellow', 'Orange'],
    correctAnswer: 'Blue',
    explanation: 'According to Wien’s displacement law, hotter stars radiate higher-energy, shorter-wavelength photons, causing them to appear blue or blue-white (exceeding 10,000 to 30,000 K).',
  },
  {
    id: 'easy-04',
    difficulty: 'easy',
    category: 'Constellations',
    question: 'Which iconic constellation contains the famous red supergiant Betelgeuse and blue supergiant Rigel?',
    options: ['Orion', 'Ursa Major', 'Cassiopeia', 'Scorpius'],
    correctAnswer: 'Orion',
    explanation: 'Orion the Hunter features Betelgeuse at its right shoulder and Rigel anchoring its opposing foot, flanking the world-renowned three-star belt.',
  },
  {
    id: 'easy-05',
    difficulty: 'easy',
    category: 'Stars',
    question: 'What is the brightest star visible in Earth’s nighttime sky?',
    options: ['Sirius', 'Vega', 'Betelgeuse', 'Arcturus'],
    correctAnswer: 'Sirius',
    explanation: 'Sirius (The Dog Star in Canis Major) shines with an apparent magnitude of −1.46, making it visually the brightest star in our night sky.',
  },
  {
    id: 'easy-06',
    difficulty: 'easy',
    category: 'Constellations',
    question: 'What famous asterism is part of the constellation Ursa Major?',
    options: ['The Big Dipper', 'The Orion Belt', 'The Summer Triangle', 'The Sickle'],
    correctAnswer: 'The Big Dipper',
    explanation: 'The Big Dipper (or the Plough) consists of the seven brightest stars of Ursa Major (The Great Bear) and has served as a navigational beacon across centuries.',
  },
  {
    id: 'easy-07',
    difficulty: 'easy',
    category: 'Astronomy Basics',
    question: 'What astronomical unit measures the distance that light travels in one Julian year in a vacuum?',
    options: ['Light-year', 'Astronomical Unit (AU)', 'Parsec', 'Kiloparsec'],
    correctAnswer: 'Light-year',
    explanation: 'A light-year is a unit of distance, not time. Light traveling at approximately 300,000 km/s traverses roughly 9.46 trillion kilometers (5.88 trillion miles) in one year.',
  },
  {
    id: 'easy-08',
    difficulty: 'easy',
    category: 'Constellations',
    question: 'Why is Polaris (the North Star) important for northern celestial navigation?',
    options: [
      'It aligns almost directly with Earth’s northern rotational axis',
      'It is the intrinsically brightest star in the Milky Way',
      'It changes position faster than any other star',
      'It emits unique green radio pulses',
    ],
    correctAnswer: 'It aligns almost directly with Earth’s northern rotational axis',
    explanation: 'Polaris sits near true celestial north, meaning that as Earth rotates, all other northern constellations appear to wheel around it while Polaris remains virtually motionless.',
  },
  {
    id: 'easy-09',
    difficulty: 'easy',
    category: 'Star Types',
    question: 'What category of star is our Sun classified as?',
    options: ['Yellow Dwarf (G-type Main Sequence)', 'Red Supergiant', 'White Dwarf', 'Blue Hypergiant'],
    correctAnswer: 'Yellow Dwarf (G-type Main Sequence)',
    explanation: 'The Sun is a G2V main-sequence star, popularly termed a yellow dwarf, currently halfway through its stable 10-billion-year hydrogen-burning phase.',
  },
  {
    id: 'easy-10',
    difficulty: 'easy',
    category: 'Star Life Cycle',
    question: 'Where are stars born inside our galaxy?',
    options: [
      'Enormous cold molecular clouds of gas and dust',
      'Inside black hole event horizons',
      'In the vacuum between distant galaxies',
      'From asteroid collisions in solar systems',
    ],
    correctAnswer: 'Enormous cold molecular clouds of gas and dust',
    explanation: 'Stellar nurseries (giant molecular clouds or nebulae) provide the cold, dense molecular hydrogen and gravitational conditions required to trigger gravitational collapse and star birth.',
  },

  // ==========================================
  // INTERMEDIATE LEVEL (10+ Questions)
  // ==========================================
  {
    id: 'med-01',
    difficulty: 'intermediate',
    category: 'Spectral Classes',
    question: 'What is the traditional Harvard sequence of stellar spectral types from hottest to coolest?',
    options: [
      'O, B, A, F, G, K, M',
      'M, K, G, F, A, B, O',
      'A, B, C, D, E, F, G',
      'O, G, A, M, B, K, F',
    ],
    correctAnswer: 'O, B, A, F, G, K, M',
    explanation: 'Developed by Annie Jump Cannon and the Harvard Computers, the classification orders stars by photospheric temperature from searing Class O (>30,000 K) down to cool Class M (<3,500 K).',
  },
  {
    id: 'med-02',
    difficulty: 'intermediate',
    category: 'Star Life Cycle',
    question: 'What single physical property most decisively dictates how a star lives and dies?',
    options: ['Birth Mass', 'Rotational Velocity', 'Orbital Inclination', 'Distance from the Galactic Core'],
    correctAnswer: 'Birth Mass',
    explanation: 'Stellar mass governs the gravitational pressure in a star’s core. More massive stars fuse nuclear fuel at exponentially faster rates, live drastically shorter lives, and end in violent supernovas.',
  },
  {
    id: 'med-03',
    difficulty: 'intermediate',
    category: 'Star Types',
    question: 'What quantum mechanical pressure supports a white dwarf star against gravitational collapse?',
    options: [
      'Electron degeneracy pressure',
      'Neutron degeneracy pressure',
      'Thermal radiation pressure',
      'Electrostatic magnetic repulsion',
    ],
    correctAnswer: 'Electron degeneracy pressure',
    explanation: 'In a white dwarf, electrons are packed so densely that the Pauli Exclusion Principle prevents them from occupying identical quantum states, providing the electron degeneracy pressure that resists gravity.',
  },
  {
    id: 'med-04',
    difficulty: 'intermediate',
    category: 'Constellations',
    question: 'Which star in Scorpius is known as the "Rival of Mars" due to its fiery ruby coloration?',
    options: ['Antares', 'Shaula', 'Aldebaran', 'Betelgeuse'],
    correctAnswer: 'Antares',
    explanation: 'Antares comes from ancient Greek "Anti-Ares" (counterpart/rival to Ares/Mars) because its intense crimson hue closely mimics the appearance of the red planet in the night sky.',
  },
  {
    id: 'med-05',
    difficulty: 'intermediate',
    category: 'Stars',
    question: 'What remarkable stellar companion orbits the bright star Sirius A?',
    options: [
      'Sirius B, an Earth-sized white dwarf',
      'A supermassive black hole',
      'A pulsar with millisecond radio beams',
      'A Jupiter-sized gas giant planet only',
    ],
    correctAnswer: 'Sirius B, an Earth-sized white dwarf',
    explanation: 'Sirius B ("The Pup") was the historically first white dwarf ever identified. It packs roughly one entire solar mass into a hyper-dense volume roughly the size of planet Earth.',
  },
  {
    id: 'med-06',
    difficulty: 'intermediate',
    category: 'Star Life Cycle',
    question: 'What stellar remnant is left behind after a Sun-like star sheds its outer atmosphere as a planetary nebula?',
    options: ['White dwarf', 'Black hole', 'Neutron star', 'Protostar'],
    correctAnswer: 'White dwarf',
    explanation: 'Intermediate and low-mass stars (like our Sun) lack the gravitational mass to fuse carbon/oxygen or create a supernova; they gently eject their envelopes into a planetary nebula, leaving behind a cooling white dwarf.',
  },
  {
    id: 'med-07',
    difficulty: 'intermediate',
    category: 'Astronomy Basics',
    question: 'In astronomical apparent magnitude, what does a lower or negative numerical value indicate?',
    options: [
      'A brighter object in the sky',
      'A dimmer object in the sky',
      'A higher core temperature',
      'A greater physical distance',
    ],
    correctAnswer: 'A brighter object in the sky',
    explanation: 'The astronomical magnitude scale is logarithmic and inverted: the brighter an celestial object appears from Earth, the lower or more negative its numerical magnitude (e.g., Sun is −26.74, Sirius is −1.46).',
  },
  {
    id: 'med-08',
    difficulty: 'intermediate',
    category: 'Constellations',
    question: 'What shape is famously formed by the five brightest stars of Cassiopeia?',
    options: ['An unmistakable "W" or "M" pattern', 'A perfect equilateral triangle', 'A diamond cross', 'A circle of seven gems'],
    correctAnswer: 'An unmistakable "W" or "M" pattern',
    explanation: 'Caph, Schedar, Navi (Gamma Cas), Ruchbah, and Segin form the distinctive zigzag "W" (or "M") asterism that circles Polaris in the northern celestial hemisphere.',
  },
  {
    id: 'med-09',
    difficulty: 'intermediate',
    category: 'Star Types',
    question: 'Why do low-mass red dwarf stars live for trillions of years, far longer than the current age of the universe?',
    options: [
      'They are fully convective and burn hydrogen at an exceptionally frugal rate',
      'They do not undergo nuclear fusion',
      'Their strong magnetic fields replenish hydrogen from space',
      'They absorb dark matter as nuclear fuel',
    ],
    correctAnswer: 'They are fully convective and burn hydrogen at an exceptionally frugal rate',
    explanation: 'Red dwarfs possess convection currents that circulate hydrogen from their surface down into their core, allowing them to burn nearly 100% of their fuel at a very slow, stable rate.',
  },
  {
    id: 'med-10',
    difficulty: 'intermediate',
    category: 'Star Life Cycle',
    question: 'What catastrophic stellar event occurs when a massive star’s iron core collapses under gravity?',
    options: ['Type II Supernova', 'Nova', 'Thermal Helium Flash', 'Planetary Nebula Formation'],
    correctAnswer: 'Type II Supernova',
    explanation: 'Because fusing iron consumes energy rather than releasing it, thermal radiation pressure vanishes almost instantly, causing a catastrophic core collapse and rebound explosion known as a core-collapse supernova.',
  },

  // ==========================================
  // EXPERT LEVEL (10+ Questions)
  // ==========================================
  {
    id: 'exp-01',
    difficulty: 'expert',
    category: 'Star Life Cycle',
    question: 'What is the theoretical maximum mass limit for a stable non-rotating white dwarf before it collapses, known as the Chandrasekhar Limit?',
    options: ['≈ 1.44 Solar Masses', '≈ 3.0 Solar Masses', '≈ 8.0 Solar Masses', '≈ 0.5 Solar Masses'],
    correctAnswer: '≈ 1.44 Solar Masses',
    explanation: 'Discovered by Subrahmanyan Chandrasekhar in 1930, if an electron-degenerate core exceeds approximately 1.44 solar masses ($M_\\odot$), electron degeneracy pressure can no longer withstand gravity.',
  },
  {
    id: 'exp-02',
    difficulty: 'expert',
    category: 'Stars',
    question: 'Why does the star Regulus (Alpha Leonis) have an equatorial diameter roughly 32% larger than its polar diameter?',
    options: [
      'Extreme centrifugal distortion from spinning once every 15.9 hours',
      'Tidal stretching from a nearby companion black hole',
      'Uneven surface magnetic fields causing mass bulges',
      'Asymmetric stellar winds blowing along its equator',
    ],
    correctAnswer: 'Extreme centrifugal distortion from spinning once every 15.9 hours',
    explanation: 'Regulus rotates at 96% of its critical break-up velocity, bulging severely at its equator and causing gravity darkening where the poles are substantially hotter and brighter than the equator.',
  },
  {
    id: 'exp-03',
    difficulty: 'expert',
    category: 'Star Types',
    question: 'What astronomical object is a rapidly rotating, highly magnetized neutron star that emits beamed synchrotron radiation?',
    options: ['Pulsar', 'Magnetar-only without rotation', 'Quark star', 'Wolf-Rayet star'],
    correctAnswer: 'Pulsar',
    explanation: 'Pulsars are rotating neutron stars whose misaligned magnetic poles sweep lighthouse-like beams of electromagnetic radiation across our line of sight with extreme periodicity.',
  },
  {
    id: 'exp-04',
    difficulty: 'expert',
    category: 'Astronomy Basics',
    question: 'Which nuclear fusion pathway dominates hydrogen burning in stars significantly more massive than the Sun with core temperatures above 17 million Kelvin?',
    options: [
      'The CNO (Carbon-Nitrogen-Oxygen) cycle',
      'The Proton-Proton (p-p) chain',
      'The Triple-Alpha process',
      'Silicon burning',
    ],
    correctAnswer: 'The CNO (Carbon-Nitrogen-Oxygen) cycle',
    explanation: 'While the proton-proton chain dominates in the Sun, at higher core temperatures the CNO catalytic cycle has a far steeper temperature dependence ($T^{17}$) and becomes the primary thermonuclear engine.',
  },
  {
    id: 'exp-05',
    difficulty: 'expert',
    category: 'Star Life Cycle',
    question: 'What is the Tolman-Oppenheimer-Volkoff (TOV) limit in relativistic astrophysics?',
    options: [
      'The upper mass boundary (≈ 2.1–2.3 M☉) above which a neutron star collapses into a black hole',
      'The minimum mass required for deuterium fusion in a brown dwarf',
      'The maximum luminosity a star can maintain before blowing away its atmosphere',
      'The radius of a non-rotating black hole event horizon',
    ],
    correctAnswer: 'The upper mass boundary (≈ 2.1–2.3 M☉) above which a neutron star collapses into a black hole',
    explanation: 'Analogous to the Chandrasekhar limit for white dwarfs, the TOV limit represents the maximum mass that neutron degeneracy pressure and strong nuclear repulsion can support against complete gravitational collapse.',
  },
  {
    id: 'exp-06',
    difficulty: 'expert',
    category: 'Constellations',
    question: 'The stars Mizar and Alcor in the Big Dipper handle were historically used as an eye test. High-resolution spectroscopy has revealed that Mizar and Alcor together form a system of how many gravitationally bound stars?',
    options: ['6 stars (sextuple system)', '2 stars (simple binary)', '3 stars (triple system)', '12 stars (star cluster)'],
    correctAnswer: '6 stars (sextuple system)',
    explanation: 'Mizar itself consists of two spectroscopic binary pairs (four stars), and Alcor is another binary pair (two stars), making the combined Mizar-Alcor complex an astonishing sextuple stellar system.',
  },
  {
    id: 'exp-07',
    difficulty: 'expert',
    category: 'Spectral Classes',
    question: 'In the Yerkes (MKK) two-dimensional spectral luminosity classification, what does luminosity class "Ia" denote?',
    options: ['Luminous Supergiant', 'Main Sequence Dwarf', 'Bright Giant', 'Subdwarf'],
    correctAnswer: 'Luminous Supergiant',
    explanation: 'The Yerkes system appends Roman numerals to Harvard spectral classes: Ia indicates luminous supergiants (like Rigel B8Ia), Ib denotes less luminous supergiants, III denotes normal giants, and V represents main-sequence dwarfs.',
  },
  {
    id: 'exp-08',
    difficulty: 'expert',
    category: 'Astronomy Basics',
    question: 'What is the physical boundary of a non-rotating black hole from within which no light or particle can escape?',
    options: ['Event Horizon (Schwarzschild radius)', 'Ergosurface', 'Photon Sphere', 'Accretion Disk Boundary'],
    correctAnswer: 'Event Horizon (Schwarzschild radius)',
    explanation: 'The event horizon defines the causal boundary where the escape velocity equals the speed of light in vacuum. For a non-rotating Schwarzschild black hole, $R_s = \\frac{2GM}{c^2}$.',
  },
  {
    id: 'exp-09',
    difficulty: 'expert',
    category: 'Stars',
    question: 'Why did Hipparchus in 134 BCE notice that the coordinates of Spica (Alpha Virginis) had shifted relative to previous Babylonian star charts?',
    options: [
      'Discovery of the precession of Earth’s equinoxes',
      'Spica’s rapid proper motion through the galaxy',
      'Gravitational lensing by the Sun',
      'Errors in ancient water clock calibration',
    ],
    correctAnswer: 'Discovery of the precession of Earth’s equinoxes',
    explanation: 'Comparing Spica’s position with records from Timocharis 150 years earlier, Hipparchus deduced that Earth’s rotational axis slowly wobbles in space with a 25,772-year cycle known as axial precession.',
  },
  {
    id: 'exp-10',
    difficulty: 'expert',
    category: 'Star Life Cycle',
    question: 'During core helium exhaustion in stars between 0.8 and 8 M☉, what explosive thermonuclear runaway occurs in a degenerate helium core?',
    options: ['Helium Flash', 'Carbon Detonation', 'Silicon Burning Phase', 'Photodisintegration'],
    correctAnswer: 'Helium Flash',
    explanation: 'Because electron-degenerate matter does not expand when heated, the onset of the triple-alpha reaction causes core temperature to spike violently without expanding the star, resulting in a brief, explosive helium flash.',
  },
];

/**
 * Fisher-Yates shuffle algorithm for clean randomization
 */
export function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Generates a randomized quiz of `count` questions for the given difficulty.
 * Safely randomizes both question sequence and option order while preserving
 * accurate correctAnswer tracking.
 */
export function generateQuiz(difficulty = 'intermediate', count = 10) {
  const filtered = QUIZ_QUESTIONS.filter((q) => q.difficulty === difficulty);
  const pool = filtered.length >= count ? filtered : QUIZ_QUESTIONS;
  const shuffledQuestions = shuffleArray(pool).slice(0, count);

  return shuffledQuestions.map((q) => {
    const randomizedOptions = shuffleArray(q.options);
    return {
      ...q,
      options: randomizedOptions,
    };
  });
}
