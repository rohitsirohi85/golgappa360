// =====================================================================
// Golgappa360 - High-Fidelity Realistic Business Store & Mock DB
// Generates 30 days of street food operational data for Rajesh Sharma's
// "Sharma Ji Golgappa Center", Karol Bagh / CP, New Delhi.
// =====================================================================

export const initialCategories = [
  { id: 1, name: 'Classic Pani Puri', description: 'Traditional crispy puris with spiced water and potato-vatana filling' },
  { id: 2, name: 'Flavoured Specials', description: 'Signature pani varieties: Extra Teekha, Sweet Tamarind, and Hing' },
  { id: 3, name: 'Chaat & Loaded Puris', description: 'Curd, sev, and rich chutney loaded savories' },
  { id: 4, name: 'Custom & Dry Add-ons', description: 'Sukha puri, masala puris, and extra boondi refills' },
];

export const initialMenuItems = [
  {
    id: 1,
    item_code: 'REG-01',
    name: 'Regular Golgappa (6 pcs)',
    category_id: 1,
    category_name: 'Classic Pani Puri',
    flavour_profile: 'Teekha & Khatta Mix',
    pieces_per_plate: 6,
    selling_price: 30.00,
    cost_price: 8.40,
    margin_pct: 72.0,
    is_active: true,
    popularity_score: 95,
    description: 'Crispy suji & atta puris filled with spiced potato-vatana mash, dunked in signature pudina-imli pani.'
  },
  {
    id: 2,
    item_code: 'SPICY-02',
    name: 'Spicy Teekha Pani Puri (6 pcs)',
    category_id: 2,
    category_name: 'Flavoured Specials',
    flavour_profile: 'Fiery Pudina Teekha',
    pieces_per_plate: 6,
    selling_price: 35.00,
    cost_price: 9.20,
    margin_pct: 73.7,
    is_active: true,
    popularity_score: 88,
    description: 'Extra fiery green chilli and roasted cumin infused mint water for authentic spice lovers.'
  },
  {
    id: 3,
    item_code: 'SWEET-03',
    name: 'Sweet Meetha Pani Puri (6 pcs)',
    category_id: 2,
    category_name: 'Flavoured Specials',
    flavour_profile: 'Khatta Meetha Tamarind',
    pieces_per_plate: 6,
    selling_price: 35.00,
    cost_price: 9.80,
    margin_pct: 72.0,
    is_active: true,
    popularity_score: 82,
    description: 'Sweet jaggery-tamarind saunth water with boondi crunch, gentle on spice tolerance.'
  },
  {
    id: 4,
    item_code: 'HING-04',
    name: 'Special Hing & Jeera Golgappa (6 pcs)',
    category_id: 2,
    category_name: 'Flavoured Specials',
    flavour_profile: 'Royal Asafoetida & Cumin',
    pieces_per_plate: 6,
    selling_price: 40.00,
    cost_price: 10.50,
    margin_pct: 73.8,
    is_active: true,
    popularity_score: 79,
    description: 'Infused with premium Hathras asafoetida, black rock salt, and hand-ground roasted cumin.'
  },
  {
    id: 5,
    item_code: 'DAHI-05',
    name: 'Dahi Puri Deluxe (5 pcs)',
    category_id: 3,
    category_name: 'Chaat & Loaded Puris',
    flavour_profile: 'Creamy Dahi & Sev',
    pieces_per_plate: 5,
    selling_price: 60.00,
    cost_price: 18.00,
    margin_pct: 70.0,
    is_active: true,
    popularity_score: 91,
    description: 'Loaded puris filled with sweetened creamy curd, double chutneys, fresh pomegranate, and fine nylon sev.'
  },
  {
    id: 6,
    item_code: 'SUKHA-06',
    name: 'Sukha Puri / Masala Puri (6 pcs)',
    category_id: 4,
    category_name: 'Custom & Dry Add-ons',
    flavour_profile: 'Crunchy Dry Chaat',
    pieces_per_plate: 6,
    selling_price: 25.00,
    cost_price: 6.50,
    margin_pct: 74.0,
    is_active: true,
    popularity_score: 74,
    description: 'Crispy puris stuffed with aloo-vatana, chaat masala, lemon splash, and crushed roasted peanuts.'
  }
];

export const initialIngredients = [
  {
    id: 1,
    code: 'ING-PURI',
    name: 'Suji & Atta Puris',
    category: 'Bakery & Fryum',
    unit: 'pcs',
    current_stock: 3450,
    minimum_threshold: 1500,
    reorder_level: 2500,
    unit_cost: 0.35,
    daily_consumption_avg: 1850,
    status: 'Optimal',
    supplier: 'Gupta Puri Suppliers, Khari Baoli'
  },
  {
    id: 2,
    code: 'ING-ALOO',
    name: 'Potatoes (Aloo)',
    category: 'Fresh Produce',
    unit: 'kg',
    current_stock: 28.5,
    minimum_threshold: 15.0,
    reorder_level: 25.0,
    unit_cost: 24.00,
    daily_consumption_avg: 16.5,
    status: 'Optimal',
    supplier: 'Azadpur Mandi Stall 104'
  },
  {
    id: 3,
    code: 'ING-CHANA',
    name: 'White Chickpeas (Safed Vatana)',
    category: 'Legumes & Pulses',
    unit: 'kg',
    current_stock: 18.0,
    minimum_threshold: 10.0,
    reorder_level: 20.0,
    unit_cost: 68.00,
    daily_consumption_avg: 9.0,
    status: 'Optimal',
    supplier: 'Laxmi Kirana Stores'
  },
  {
    id: 4,
    code: 'ING-MINT-COR',
    name: 'Fresh Mint & Coriander (Pudina & Dhaniya)',
    category: 'Fresh Produce',
    unit: 'kg',
    current_stock: 3.2,
    minimum_threshold: 3.0,
    reorder_level: 6.0,
    unit_cost: 45.00,
    daily_consumption_avg: 4.8,
    status: 'Low',
    supplier: 'Green Farm Daily Mandi'
  },
  {
    id: 5,
    code: 'ING-IMLI',
    name: 'Tamarind & Jaggery Chutney Base',
    category: 'Sauces & Bases',
    unit: 'kg',
    current_stock: 8.5,
    minimum_threshold: 5.0,
    reorder_level: 10.0,
    unit_cost: 85.00,
    daily_consumption_avg: 4.2,
    status: 'Optimal',
    supplier: 'In-house Daily Kitchen Prep'
  },
  {
    id: 6,
    code: 'ING-SEV',
    name: 'Fine Nylon Sev',
    category: 'Dry Savories',
    unit: 'kg',
    current_stock: 6.8,
    minimum_threshold: 4.0,
    reorder_level: 8.0,
    unit_cost: 125.00,
    daily_consumption_avg: 3.0,
    status: 'Optimal',
    supplier: 'Haldiram Wholesale Depot'
  },
  {
    id: 7,
    code: 'ING-DAHI',
    name: 'Fresh Thick Curd (Dahi)',
    category: 'Dairy',
    unit: 'kg',
    current_stock: 8.0,
    minimum_threshold: 6.0,
    reorder_level: 12.0,
    unit_cost: 65.00,
    daily_consumption_avg: 7.5,
    status: 'Optimal',
    supplier: 'Mother Dairy Local Route'
  },
  {
    id: 8,
    code: 'ING-SPICE-MIX',
    name: 'Special Chaat & Hing Masala Mix',
    category: 'Spices',
    unit: 'kg',
    current_stock: 4.1,
    minimum_threshold: 2.0,
    reorder_level: 5.0,
    unit_cost: 280.00,
    daily_consumption_avg: 0.9,
    status: 'Optimal',
    supplier: 'Old Delhi Secret Spice Blenders'
  }
];

// Helper to generate realistic date series
function generateHistoricalData() {
  const days = 30;
  const dailySummaries = [];
  const transactions = [];
  const wasteLogs = [];
  const inventoryLedger = [];

  const now = new Date('2026-10-29T18:00:00+05:30');
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // Base seed factors for realistic variation
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayOfWeek = dayNames[d.getDay()];
    const isWeekend = dayOfWeek === 'Saturday' || dayOfWeek === 'Sunday';

    // Weekend multiplier: 1.5x to 1.8x footfall
    const footfallMultiplier = isWeekend ? 1.55 + (Math.sin(i) * 0.15) : 0.95 + (Math.cos(i) * 0.12);

    // Baseline plates sold: 260 average
    const totalPlates = Math.round(260 * footfallMultiplier);
    
    // Weighted item mix:
    // Reg: 42%, Spicy: 20%, Sweet: 14%, Dahi: 12%, Hing: 8%, Sukha: 4%
    const platesReg = Math.round(totalPlates * 0.42);
    const platesSpicy = Math.round(totalPlates * 0.20);
    const platesSweet = Math.round(totalPlates * 0.14);
    const platesDahi = Math.round(totalPlates * 0.12);
    const platesHing = Math.round(totalPlates * 0.08);
    const platesSukha = totalPlates - (platesReg + platesSpicy + platesSweet + platesDahi + platesHing);

    const grossRevenue = 
      (platesReg * 30.00) +
      (platesSpicy * 35.00) +
      (platesSweet * 35.00) +
      (platesHing * 40.00) +
      (platesDahi * 60.00) +
      (platesSukha * 25.00);

    const totalCogs = 
      (platesReg * 8.40) +
      (platesSpicy * 9.20) +
      (platesSweet * 9.80) +
      (platesHing * 10.50) +
      (platesDahi * 18.00) +
      (platesSukha * 6.50);

    const grossProfit = grossRevenue - totalCogs;
    const grossMarginPct = Number(((grossProfit / grossRevenue) * 100).toFixed(1));

    // Daily Food Waste calculation
    // Slow days (like rainy Tuesdays) have higher leftover pani; peak days have higher puri breakage
    const brokenPurisQty = Math.round(75 + (totalPlates * 0.25) + (Math.sin(i * 3) * 20)); // pcs
    const brokenPurisCost = Number((brokenPurisQty * 0.35).toFixed(2));

    const leftoverPaniQty = Number((1.5 + (isWeekend ? 0.8 : 2.4) + (Math.cos(i) * 0.5)).toFixed(1)); // liters
    const leftoverPaniCost = Number((leftoverPaniQty * 25.0).toFixed(2));

    const potatoWasteQty = Number((0.6 + (!isWeekend ? 1.0 : 0.4)).toFixed(1)); // kg
    const potatoWasteCost = Number((potatoWasteQty * 24.0).toFixed(2));

    const dailyWasteCost = Number((brokenPurisCost + leftoverPaniCost + potatoWasteCost).toFixed(2));
    const netEstimatedProfit = Number((grossProfit - dailyWasteCost).toFixed(2));
    const wasteRatePct = Number(((dailyWasteCost / totalCogs) * 100).toFixed(1));

    // Payment splits: UPI ~71%, Cash ~26%, Card ~3%
    const upiRevenue = Number((grossRevenue * 0.71).toFixed(2));
    const cashRevenue = Number((grossRevenue * 0.26).toFixed(2));
    const cardRevenue = Number((grossRevenue - upiRevenue - cashRevenue).toFixed(2));
    const totalOrders = Math.round(totalPlates / 1.7); // average 1.7 plates per customer order

    dailySummaries.push({
      date: dateStr,
      dayOfWeek,
      totalOrders,
      totalPlates,
      grossRevenue: Number(grossRevenue.toFixed(2)),
      totalCogs: Number(totalCogs.toFixed(2)),
      grossProfit: Number(grossProfit.toFixed(2)),
      grossMarginPct,
      dailyWasteCost,
      netEstimatedProfit,
      wasteRatePct,
      upiRevenue,
      cashRevenue,
      cardRevenue,
      aov: Number((grossRevenue / totalOrders).toFixed(2)),
      peakHour: '18:00 - 19:00',
      topItem: 'Regular Golgappa (6 pcs)'
    });

    // Add Waste Log entries
    wasteLogs.push(
      {
        id: `WST-${dateStr}-01`,
        date: dateStr,
        ingredient_name: 'Suji & Atta Puris',
        quantity: brokenPurisQty,
        unit: 'pcs',
        unit_cost: 0.35,
        estimated_cost: brokenPurisCost,
        reason: 'Broken Puris (Transit/Handling)',
        severity: brokenPurisQty > 140 ? 'High' : 'Normal',
        recommendation: 'Use partitioned shock-absorbent containers for supplier delivery.'
      },
      {
        id: `WST-${dateStr}-02`,
        date: dateStr,
        ingredient_name: 'Spicy Teekha & Pudina Pani',
        quantity: leftoverPaniQty,
        unit: 'liters',
        unit_cost: 25.00,
        estimated_cost: leftoverPaniCost,
        reason: 'Leftover Souring Flavoured Pani',
        severity: leftoverPaniQty > 3.0 ? 'High' : 'Normal',
        recommendation: 'Cap pre-prep at 18L on weekdays; mix second batch after 6 PM.'
      },
      {
        id: `WST-${dateStr}-03`,
        date: dateStr,
        ingredient_name: 'Boiled Potato Mash',
        quantity: potatoWasteQty,
        unit: 'kg',
        unit_cost: 24.00,
        estimated_cost: potatoWasteCost,
        reason: 'Excess Boiled Potato Mash Souring',
        severity: potatoWasteQty > 1.5 ? 'High' : 'Normal',
        recommendation: 'Do two separate boil cycles rather than morning-only mega batch.'
      }
    );

    // Add Inventory Ledger for key items
    inventoryLedger.push(
      {
        id: `LED-${dateStr}-PURI`,
        date: dateStr,
        ingredient: 'Suji & Atta Puris',
        opening: 4200,
        purchases: isWeekend ? 3000 : 1500,
        consumption: totalPlates * 6,
        wastage: brokenPurisQty,
        closing: 4200 + (isWeekend ? 3000 : 1500) - (totalPlates * 6 + brokenPurisQty),
        unit: 'pcs',
        status: 'Optimal'
      },
      {
        id: `LED-${dateStr}-ALOO`,
        date: dateStr,
        ingredient: 'Potatoes (Aloo)',
        opening: 35.0,
        purchases: 25.0,
        consumption: Number(((totalPlates * 0.055)).toFixed(1)),
        wastage: potatoWasteQty,
        closing: Number((35.0 + 25.0 - (totalPlates * 0.055 + potatoWasteQty)).toFixed(1)),
        unit: 'kg',
        status: 'Optimal'
      }
    );
  }

  // Generate 85 realistic recent transactions for Today & Yesterday
  const hours = [15, 16, 17, 18, 19, 20, 21, 22];
  const hourDistribution = {
    15: 0.04, 16: 0.10, 17: 0.18, 18: 0.24, 19: 0.23, 20: 0.15, 21: 0.06
  };
  const paymentMethods = ['UPI', 'UPI', 'UPI', 'Cash', 'Cash', 'Card'];
  const customerTypes = ['Dine-in', 'Dine-in', 'Dine-in', 'Takeaway'];

  for (let t = 1; t <= 85; t++) {
    const hr = hours[Math.floor(Math.random() * (hours.length - 1))];
    const min = Math.floor(Math.random() * 60).toString().padStart(2, '0');
    const orderItems = [];

    // Random items in transaction
    const numItems = Math.random() > 0.65 ? 2 : 1;
    let orderPlates = 0;
    let orderRevenue = 0;
    let orderCost = 0;

    for (let k = 0; k < numItems; k++) {
      const item = initialMenuItems[Math.floor(Math.random() * initialMenuItems.length)];
      const qty = Math.random() > 0.8 ? 2 : 1;
      orderItems.push({
        item_id: item.id,
        name: item.name,
        price: item.selling_price,
        cost: item.cost_price,
        qty
      });
      orderPlates += qty;
      orderRevenue += (item.selling_price * qty);
      orderCost += (item.cost_price * qty);
    }

    const payMethod = paymentMethods[Math.floor(Math.random() * paymentMethods.length)];
    const custType = customerTypes[Math.floor(Math.random() * customerTypes.length)];

    transactions.push({
      id: `TXN-20261029-${(100 + t)}`,
      time: `${hr}:${min}`,
      timestamp: `2026-10-29T${hr}:${min}:00+05:30`,
      customerType: custType,
      itemsSummary: orderItems.map(i => `${i.qty}x ${i.name.split(' (')[0]}`).join(', '),
      itemsDetail: orderItems,
      totalPlates: orderPlates,
      amount: orderRevenue,
      cost: Number(orderCost.toFixed(2)),
      profit: Number((orderRevenue - orderCost).toFixed(2)),
      paymentMethod: payMethod,
      status: 'Completed'
    });
  }

  // Reverse transactions so newest comes first
  transactions.reverse();

  // Hourly profile (Aggregated over 30 days)
  const hourlySalesProfile = [
    { hour: '3:00 PM', hour24: 15, orders: 42, plates: 75, revenue: 2650, cogs: 760, footfallIntensity: 'Light Warmup' },
    { hour: '4:00 PM', hour24: 16, orders: 110, plates: 195, revenue: 6850, cogs: 1980, footfallIntensity: 'Afternoon Office Snack' },
    { hour: '5:00 PM', hour24: 17, orders: 215, plates: 390, revenue: 13950, cogs: 3990, footfallIntensity: 'Evening Rush Kickoff' },
    { hour: '6:00 PM', hour24: 18, orders: 320, plates: 580, revenue: 20850, cogs: 5980, footfallIntensity: 'Peak Commuter Rush' },
    { hour: '7:00 PM', hour24: 19, orders: 345, plates: 625, revenue: 22600, cogs: 6490, footfallIntensity: 'Peak Family & Friends' },
    { hour: '8:00 PM', hour24: 20, orders: 280, plates: 510, revenue: 18450, cogs: 5310, footfallIntensity: 'Dinner Chaat Hour' },
    { hour: '9:00 PM', hour24: 21, orders: 150, plates: 260, revenue: 9400, cogs: 2710, footfallIntensity: 'Late Evening Walk-ins' },
    { hour: '10:00 PM', hour24: 22, orders: 55, plates: 95, revenue: 3450, cogs: 990, footfallIntensity: 'Closing Wrap & Sukha' },
  ];

  return {
    dailySummaries,
    transactions,
    wasteLogs,
    inventoryLedger,
    hourlySalesProfile
  };
}

// Singleton state
class MockStore {
  constructor() {
    this.reset();
  }

  reset() {
    this.categories = [...initialCategories];
    this.menuItems = JSON.parse(JSON.stringify(initialMenuItems));
    this.ingredients = JSON.parse(JSON.stringify(initialIngredients));
    const generated = generateHistoricalData();
    this.dailySummaries = generated.dailySummaries;
    this.transactions = generated.transactions;
    this.wasteLogs = generated.wasteLogs;
    this.inventoryLedger = generated.inventoryLedger;
    this.hourlySalesProfile = generated.hourlySalesProfile;
    this.stallSettings = {
      stallName: 'Sharma Ji Golgappa Center',
      tagline: 'Specialist in 5 Flavours of Puris & Delhi Royal Chaat',
      ownerName: 'Rajesh Sharma',
      location: 'Block 12, Main Market, Karol Bagh, New Delhi',
      establishedYear: 2018,
      currencySymbol: '₹',
      defaultPlatePieces: 6,
      lowStockThresholdAlert: 20, // alert when stock <= 20% of max
      wasteWarningThresholdPct: 5.0, // alert when waste > 5% of COGS
      targetGrossMarginPct: 70.0,
      upiVpa: 'sharmagolgappa@icici'
    };
  }

  // Overview Dashboard KPI Aggregator
  getOverviewMetrics(filterRange = '30d') {
    let summaries = this.dailySummaries;
    if (filterRange === 'today') {
      summaries = summaries.slice(-1);
    } else if (filterRange === 'yesterday') {
      summaries = summaries.slice(-2, -1);
    } else if (filterRange === '7d') {
      summaries = summaries.slice(-7);
    } else if (filterRange === '14d') {
      summaries = summaries.slice(-14);
    }

    const totalRevenue = summaries.reduce((acc, s) => acc + s.grossRevenue, 0);
    const totalPlatesSold = summaries.reduce((acc, s) => acc + s.totalPlates, 0);
    const totalCogs = summaries.reduce((acc, s) => acc + s.totalCogs, 0);
    const totalGrossProfit = summaries.reduce((acc, s) => acc + s.grossProfit, 0);
    const totalWasteCost = summaries.reduce((acc, s) => acc + s.dailyWasteCost, 0);
    const netEstimatedProfit = totalGrossProfit - totalWasteCost;
    const grossMarginPct = totalRevenue > 0 ? Number(((totalGrossProfit / totalRevenue) * 100).toFixed(1)) : 0;
    const wasteRatePct = totalCogs > 0 ? Number(((totalWasteCost / totalCogs) * 100).toFixed(1)) : 0;
    const totalOrders = summaries.reduce((acc, s) => acc + s.totalOrders, 0);
    const aov = totalOrders > 0 ? Number((totalRevenue / totalOrders).toFixed(2)) : 0;

    // Top selling product share
    const productSalesDistribution = [
      { name: 'Regular Golgappa', plates: Math.round(totalPlatesSold * 0.42), revenue: Math.round(totalRevenue * 0.36), share: 42, color: '#176B4D' },
      { name: 'Spicy Teekha Puri', plates: Math.round(totalPlatesSold * 0.20), revenue: Math.round(totalRevenue * 0.20), share: 20, color: '#27986B' },
      { name: 'Dahi Puri Deluxe', plates: Math.round(totalPlatesSold * 0.12), revenue: Math.round(totalRevenue * 0.21), share: 12, color: '#F4A340' },
      { name: 'Sweet Meetha Puri', plates: Math.round(totalPlatesSold * 0.14), revenue: Math.round(totalRevenue * 0.14), share: 14, color: '#F7C378' },
      { name: 'Hing & Jeera Special', plates: Math.round(totalPlatesSold * 0.08), revenue: Math.round(totalRevenue * 0.09), share: 8, color: '#88A398' },
    ];

    // Daily Sales Line Data
    const dailySalesChart = summaries.map(s => ({
      date: s.date.slice(5), // '10-29'
      fullDate: s.date,
      day: s.dayOfWeek.slice(0, 3),
      revenue: s.grossRevenue,
      cogs: s.totalCogs,
      grossProfit: s.grossProfit,
      wasteCost: s.dailyWasteCost,
      plates: s.totalPlates
    }));

    return {
      kpis: {
        totalRevenue: Math.round(totalRevenue),
        totalPlatesSold,
        grossProfit: Math.round(totalGrossProfit),
        grossMarginPct,
        totalWasteCost: Math.round(totalWasteCost),
        wasteRatePct,
        netEstimatedProfit: Math.round(netEstimatedProfit),
        totalOrders,
        aov
      },
      productSalesDistribution,
      dailySalesChart,
      hourlySalesProfile: this.hourlySalesProfile,
      recentTransactions: this.transactions.slice(0, 10),
      activeLowStockCount: this.ingredients.filter(i => i.status === 'Low' || i.current_stock <= i.minimum_threshold).length
    };
  }

  // Menu CRUD
  addMenuItem(itemData) {
    const nextId = Math.max(...this.menuItems.map(m => m.id)) + 1;
    const newItem = {
      id: nextId,
      item_code: itemData.item_code || `SPEC-${nextId.toString().padStart(2, '0')}`,
      name: itemData.name,
      category_id: Number(itemData.category_id) || 2,
      category_name: itemData.category_name || 'Flavoured Specials',
      flavour_profile: itemData.flavour_profile || 'Custom Spice Blend',
      pieces_per_plate: Number(itemData.pieces_per_plate) || 6,
      selling_price: Number(itemData.selling_price) || 40.00,
      cost_price: Number(itemData.cost_price) || 10.00,
      margin_pct: Number((((itemData.selling_price - itemData.cost_price) / itemData.selling_price) * 100).toFixed(1)),
      is_active: true,
      popularity_score: 70,
      description: itemData.description || 'Custom crafted stall specialty.'
    };
    this.menuItems.push(newItem);
    return newItem;
  }

  updateMenuItem(id, updates) {
    const idx = this.menuItems.findIndex(m => m.id === Number(id));
    if (idx === -1) return null;
    const item = { ...this.menuItems[idx], ...updates };
    if (updates.selling_price || updates.cost_price) {
      item.margin_pct = Number((((item.selling_price - item.cost_price) / item.selling_price) * 100).toFixed(1));
    }
    this.menuItems[idx] = item;
    return item;
  }

  // Inventory Updates
  updateStock(ingredientId, newStockAmount, notes = '') {
    const idx = this.ingredients.findIndex(i => i.id === Number(ingredientId));
    if (idx === -1) return null;
    const ing = this.ingredients[idx];
    const prevStock = ing.current_stock;
    ing.current_stock = Number(newStockAmount);
    ing.status = ing.current_stock <= ing.minimum_threshold ? 'Low' : 'Optimal';

    // Add to ledger
    this.inventoryLedger.unshift({
      id: `LED-${new Date().toISOString().slice(0, 10)}-${ing.code}-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().slice(0, 10),
      ingredient: ing.name,
      opening: prevStock,
      purchases: newStockAmount > prevStock ? newStockAmount - prevStock : 0,
      consumption: newStockAmount < prevStock ? prevStock - newStockAmount : 0,
      wastage: 0,
      closing: ing.current_stock,
      unit: ing.unit,
      status: ing.status,
      notes: notes || 'Manual inventory audit/restock update'
    });

    return ing;
  }

  // Waste Log creation
  logWasteEntry(wasteData) {
    const ing = this.ingredients.find(i => i.id === Number(wasteData.ingredient_id)) || this.ingredients[0];
    const qty = Number(wasteData.quantity);
    const estCost = Number((qty * ing.unit_cost).toFixed(2));

    const newLog = {
      id: `WST-MANUAL-${Date.now().toString().slice(-6)}`,
      date: wasteData.date || new Date().toISOString().slice(0, 10),
      ingredient_name: ing.name,
      quantity: qty,
      unit: ing.unit,
      unit_cost: ing.unit_cost,
      estimated_cost: estCost,
      reason: wasteData.reason || 'Leftover Souring Flavoured Pani',
      severity: estCost > 150 ? 'High' : 'Normal',
      recommendation: wasteData.recommendation || 'Adjust batch preparation volume according to daily footfall prediction.'
    };

    this.wasteLogs.unshift(newLog);
    return newLog;
  }
}

export const mockStore = new MockStore();
