import api from '../../services/api';

export const aiService = {
  // 1. Demand Prediction
  predictDemand: async (stationId, date, hour) => {
    return api.post('/ai/predict-demand', { stationId, date, hour });
  },

  getDemandHistory: async (stationId = 'all', days = 7) => {
    const qs = `?stationId=${stationId}&days=${days}`;
    return api.get(`/ai/demand-history${qs}`);
  },

  // 2. Anomaly Detection
  getAnomalies: async (chargerId = 'all', status = 'all') => {
    const qs = `?chargerId=${chargerId}&status=${status}`;
    return api.get(`/ai/anomalies${qs}`);
  },

  detectLiveAnomalies: async () => {
    return api.post('/ai/detect-anomalies', {});
  },

  // 3. Maintenance Risk
  getMaintenanceRisks: async () => {
    return api.get('/ai/maintenance-risk');
  },

  // 4. Smart Optimization & Recommendations
  getRecommendations: async () => {
    return api.get('/ai/recommendations');
  },

  getSmartWindowForDriver: async (stationId) => {
    return api.get(`/ai/smart-window/${stationId}`);
  },

  recommendChargerForDriver: async (stationId, connectorType = '') => {
    const qs = connectorType ? `?connectorType=${connectorType}` : '';
    return api.get(`/ai/recommend-charger/${stationId}${qs}`);
  },

  // 5. Model Management & Versioning
  getModels: async () => {
    return api.get('/ai/models');
  },

  trainModel: async (modelType = 'demand') => {
    return api.post('/ai/train', { modelType });
  },

  // 6. Accuracy & Accuracy Performance Monitoring
  getPerformance: async () => {
    return api.get('/ai/performance');
  },

  // 7. Full Executive Insights Report
  getInsightsReport: async () => {
    return api.get('/ai/insights-report');
  },
};

export default aiService;
