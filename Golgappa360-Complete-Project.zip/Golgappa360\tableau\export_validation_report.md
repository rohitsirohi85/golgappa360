# Golgappa360 — Tableau Export Validation & Reconciliation Report

**Audit Date:** 2026-10-29  
**Platform Version:** Golgappa360 Phase 4  
**Audit Scope:** Full 6-Month Operational Dataset (2026-05-01 to 2026-10-29)  
**Status:** **100% RECONCILED — ZERO DISCREPANCIES DETECTED**

---

## 1. Executive Summary

This validation audit certifies that all 6 exported Tableau datasets (`tableau_sales.csv`, `tableau_products.csv`, `tableau_inventory.csv`, `tableau_daily_summary.csv`, `tableau_expenses.csv`, `tableau_data_dictionary.csv`) achieve exact parity with the underlying synthetic and MySQL relational database layers.

Every transaction, plate, discount, ingredient movement, and expense voucher has been reconciled against the source data. There is **zero Cartesian product inflation**, **zero duplicate rows**, and **zero floating-point discrepancy**.

---

## 2. Quantitative Reconciliation Matrix

| Reconciliation Metric | Underlying Source Data | Exported Tableau Datasets | Absolute Variance | Reconciliation Status |
|:---|:---:|:---:|:---:|:---:|
| **Sales Orders Count** | 31,938 orders | 31,938 orders | 0 | **PASS** |
| **Total Plates Sold** | 47,658 plates | 47,658 plates | 0 | **PASS** |
| **Gross Sales Turnover** | ₹1,765,505.00 | ₹1,765,505.00 | ₹0.00 | **PASS** |
| **Promotional Discounts** | ₹5,540.00 | ₹5,540.00 | ₹0.00 | **PASS** |
| **Net Revenue** | ₹1,759,965.00 | ₹1,759,965.00 | ₹0.00 | **PASS** |
| **Cost of Goods Sold (COGS)** | ₹492,957.90 | ₹492,957.90 | ₹0.00 | **PASS** |
| **Gross Profit** | ₹1,267,007.10 | ₹1,267,007.10 | ₹0.00 | **PASS** |
| **Gross Profit Margin** | 71.99% | 71.99% | 0.00% | **PASS** |
| **Total Operating Expenses** | ₹126,540.06 | ₹126,540.06 | ₹0.00 | **PASS** |
| **Recorded Food Waste Cost** | ₹11,626.98 | ₹11,626.98 | ₹0.00 | **PASS** |
| **Purchased Inventory (Units)** | 311,814.00 units | 311,814.00 units | 0.00 units | **PASS** |
| **Consumed Inventory (Units)** | 292,920.76 units | 292,920.76 units | 0.00 units | **PASS** |
| **Daily Summary Revenue Parity** | ₹1,759,965.00 | ₹1,759,965.00 | ₹0.00 | **PASS** |
| **Daily Summary Profit Parity** | ₹1,267,007.10 | ₹1,267,007.10 | ₹0.00 | **PASS** |
| **Daily Summary Operating Income** | ₹1,140,467.04 | ₹1,140,467.04 | ₹0.00 | **PASS** |
| **Operating Margin %** | 64.80% | 64.80% | 0.00% | **PASS** |

---

## 3. Dataset Integrity & Dimensional Grain

| Dataset File | Physical File Size | Row Count | Column Count | Primary Key | Grain Level |
|:---|:---:|:---:|:---:|:---:|:---|
| **`tableau_sales.csv`** | 5,708,893 bytes (5.57 MB) | 31,938 | 21 | `sale_id` | Individual order line transaction |
| **`tableau_products.csv`** | 936 bytes (0.9 KB) | 5 | 10 | `product_id` | Unique menu variety catalog |
| **`tableau_inventory.csv`** | 321,931 bytes (314 KB) | 2,391 | 13 | `transaction_id` | Individual stock movement (Purchase, Consumption, Waste) |
| **`tableau_daily_summary.csv`** | 21,528 bytes (21.0 KB) | 182 | 17 | `sale_date` | Operational day aggregation |
| **`tableau_expenses.csv`** | 70,822 bytes (69.2 KB) | 845 | 7 | `expense_id` | Individual operating expense voucher |
| **`tableau_data_dictionary.csv`** | 8,034 bytes (7.8 KB) | 54 | 8 | `(dataset, field)` | Semantic BI attribute catalog |

---

## 4. Accounting & Relational Safeguards

1. **Fan Trap & Grain Separation Safeguard:**
   - Sales transactions (`31,938` records) and inventory movements (`2,391` records) are intentionally provided as separate fact tables. Blindly joining them in SQL or Tableau creates a Cartesian product of over 76 million rows, multiplying revenue and stock movements artificially.
   - Recommended modeling approach in Tableau: Connect using **Tableau Logical Relationships (the "noodle")** or maintain them as separate Data Sources.
2. **COGS Accounting Integrity:**
   - In `tableau_sales.csv`, COGS is calculated directly at the line-item level:
     $$\text{COGS} = \text{quantity\_plates} \times \text{ingredient\_cost\_per\_plate}$$
   - This avoids double-counting raw ingredient purchases with plate sales. Raw material purchases are held on the balance sheet until consumed.
3. **Food Waste Separation:**
   - Food waste loss (₹11,626.98) is recorded in `tableau_inventory.csv` with `transaction_type = 'WASTE'`.
   - In `tableau_daily_summary.csv`, daily waste cost is allocated alongside operating expenses without corrupting gross profit.
4. **Discounts & Gross vs Net Accounting:**
   - Gross Turnover = ₹1,765,505.00
   - Promotional Discounts = ₹5,540.00
   - Net Collected Revenue = ₹1,759,965.00
   - Discounts are deducted before calculating gross profit.

---

## 5. Certification Sign-Off

The automated validation script `tableau/validate_tableau_exports.js` executed against the live export directory and confirmed that all 15 audit assertions passed with **zero variance**. The exported data is certified ready for Tableau Desktop, Tableau Public, Power BI, and Microsoft Excel.
