import React from 'react';

/**
 * SectionHeading — Reusable header component with futuristic typography,
 * optional telemetry eyebrow, and gradient emphasis.
 */
export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  highlightText,
  align = 'center',
  className = '',
}) {
  const isCentered = align === 'center';

  // Render title with optional highlightText gradient
  const renderTitle = () => {
    if (!highlightText || !title.includes(highlightText)) {
      return title;
    }

    const parts = title.split(highlightText);
    return (
      <>
        {parts[0]}
        <span className="bg-gradient-to-r from-amber-200 via-cyan-100 to-white bg-clip-text text-transparent font-bold">
          {highlightText}
        </span>
        {parts.slice(1).join(highlightText)}
      </>
    );
  };

  return (
    <div
      className={`flex flex-col ${
        isCentered ? 'items-center text-center' : 'items-start text-left'
      } ${className}`}
    >
      {eyebrow && (
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full bg-white/[0.03] border border-white/10 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span>{eyebrow}</span>
        </div>
      )}

      <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-white leading-[1.18]">
        {renderTitle()}
      </h2>

      {subtitle && (
        <p className="mt-4 sm:mt-5 text-base sm:text-lg text-slate-300/80 max-w-2xl leading-relaxed font-normal">
          {subtitle}
        </p>
      )}
    </div>
  );
}
