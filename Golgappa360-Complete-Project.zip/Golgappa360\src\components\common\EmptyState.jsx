import React from 'react';
import { Button } from './Button';

export const EmptyState = ({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  className = '',
}) => {
  return (
    <div
      className={`
        flex flex-col items-center justify-center text-center p-8 rounded-3xl
        bg-[#0D1527]/50 border border-white/5 my-4 ${className}
      `}
    >
      {Icon && (
        <div className="p-4 rounded-2xl bg-[#131E35] border border-white/10 text-slate-400 mb-3.5 shadow-inner">
          <Icon className="w-8 h-8 text-[#00F5A0]" />
        </div>
      )}
      <h3 className="text-base font-bold text-white mb-1">{title}</h3>
      {description && (
        <p className="text-xs text-slate-400 max-w-xs mb-5 leading-relaxed">
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <Button size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};
