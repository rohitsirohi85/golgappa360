import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { socketService } from '../../services/socketService';
import { adminService } from '../services/adminService';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

export const AdminLayout = ({
  children,
  pageTitle = 'Fleet Management',
  subtitle = '',
}) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [socketStatus, setSocketStatus] = useState('disconnected');
  const [activeAlerts, setActiveAlerts] = useState([]);

  // Socket.IO Status & Live Alerts
  useEffect(() => {
    socketService.connect();
    const unsubStatus = socketService.onStatusChange((status) => {
      setSocketStatus(status);
    });

    const fetchAlerts = async () => {
      try {
        const data = await adminService.getAlerts('all', 'active');
        if (Array.isArray(data)) {
          setActiveAlerts(data);
        }
      } catch (err) {
        console.warn('Could not fetch initial alerts:', err.message);
      }
    };
    fetchAlerts();

    // Listen to real-time fault, admin notifications, and device events
    const socket = socketService.socket;
    const handleFault = (fault) => {
      setActiveAlerts((prev) => [
        fault,
        ...(Array.isArray(prev) ? prev.filter((a) => a._id !== fault._id) : []),
      ]);
    };
    const handleAdminNotif = (notif) => {
      setActiveAlerts((prev) => [
        {
          _id: notif._id || notif.id || `notif-${Date.now()}`,
          chargerNumber: notif.data?.chargerNumber || 'Fleet',
          alertType: notif.type || 'System Notice',
          message: notif.message,
          timestamp: notif.createdAt || new Date(),
          status: 'active',
        },
        ...(Array.isArray(prev) ? prev : []),
      ]);
    };
    const handleOffline = (offline) => {
      setActiveAlerts((prev) => [
        {
          _id: `offline-${Date.now()}`,
          chargerNumber: offline.chargerNumber || 'Bay',
          alertType: 'DEVICE_OFFLINE',
          message: `${offline.chargerNumber || 'Charger'} went offline`,
          timestamp: new Date(),
          status: 'active',
        },
        ...(Array.isArray(prev) ? prev : []),
      ]);
    };

    if (socket) {
      socket.on('charger:fault', handleFault);
      socket.on('admin:notification', handleAdminNotif);
      socket.on('charger:offline', handleOffline);
    }

    return () => {
      unsubStatus();
      if (socket) {
        socket.off('charger:fault', handleFault);
        socket.off('admin:notification', handleAdminNotif);
        socket.off('charger:offline', handleOffline);
      }
    };
  }, []);

  // Strict Keyboard Control: Never navigate to User pages while in /admin/*
  useEffect(() => {
    const handleAdminKeyDown = (e) => {
      // Check if target is an input/textarea
      const tag = e.target?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') {
        return;
      }

      // Block known user shortcuts (e.g., Ctrl+K, or single-key navigation)
      // Only allow shortcuts with Alt that stay inside /admin/*
      if (e.altKey && !e.ctrlKey && !e.metaKey) {
        switch (e.key) {
          case '1':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/dashboard');
            break;
          case '2':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/stations');
            break;
          case '3':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/chargers');
            break;
          case '4':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/bookings');
            break;
          case '5':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/sessions');
            break;
          case '6':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/devices');
            break;
          case '7':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/energy');
            break;
          case '8':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/analytics');
            break;
          case '9':
            e.preventDefault();
            e.stopPropagation();
            navigate('/admin/alerts');
            break;
          default:
            break;
        }
      }
    };

    // Use capture phase so admin trap fires before any child listeners
    window.addEventListener('keydown', handleAdminKeyDown, true);
    return () => window.removeEventListener('keydown', handleAdminKeyDown, true);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row antialiased selection:bg-emerald-500 selection:text-slate-950 font-sans">
      {/* Strict Admin Sidebar */}
      <AdminSidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activeAlertsCount={activeAlerts.length}
      />

      {/* Main Admin Content Wrapper */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Strict Admin Header */}
        <AdminHeader
          pageTitle={pageTitle}
          subtitle={subtitle}
          socketStatus={socketStatus}
          activeAlerts={activeAlerts}
          onMenuToggle={() => setSidebarOpen((prev) => !prev)}
        />

        {/* Admin Content Viewport (Desktop responsive, never a phone frame) */}
        <main className="flex-1 p-4 md:p-8 overflow-x-hidden min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
