/**
 * STELLAR 2.0 — Cosmic Compare Engine (Phase U12)
 * 
 * Reusable astronomical comparison service:
 * - Dynamic category-aware common metrics extraction
 * - Normalized numerical visual comparison bars (with logarithmic scaling for extreme disparities)
 * - Factual difference highlights ("Smart Insights") derived strictly from verified data
 * - Contextual related comparison suggestions from existing astronomical catalog
 * 
 * DISCLAIMER: Curated educational comparison visualization — not to physical scale.
 */

import {
  ALL_SEARCHABLE_OBJECTS,
  CELESTIAL_CATEGORIES,
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
  getCelestialObjectById,
} from '../data/celestialObjects.js';

/**
 * Extracts a clean numeric value from astronomical string representations
 * Handles: "5,778 K", "≈ 2.06 × Sun", "887 × Sun", "8.6 light-years", "1.52 AU", "95 moons"
 */
export function parseNumericValue(valStr) {
  if (typeof valStr === 'number') return valStr;
  if (!valStr || typeof valStr !== 'string') return null;

  const clean = valStr.replace(/,/g, '').trim();

  // 1. Exponential notation (e.g., "1.989 × 10³⁰" or "4.3 × 10⁶")
  if (clean.includes('10³⁰')) {
    const m = clean.match(/([\d.]+)/);
    return m ? parseFloat(m[1]) * 1000 : null;
  }
  if (clean.includes('million') || clean.includes('billion')) {
    const m = clean.match(/([\d.]+)/);
    if (!m) return null;
    const base = parseFloat(m[1]);
    return clean.includes('billion') ? base * 1e9 : base * 1e6;
  }

  // 2. Multiplier times Sun / Earth (e.g. "≈ 887 × Sun", "11 M☉", "1.71 R☉")
  const multMatch = clean.match(/([\d.]+)\s*(?:×|M☉|R☉|M⊕|R⊕)/i);
  if (multMatch) {
    return parseFloat(multMatch[1]);
  }

  // 3. Temperature in Kelvin (e.g. "5778 K", "3500 K")
  const tempMatch = clean.match(/([\d.]+)\s*K/i);
  if (tempMatch) {
    return parseFloat(tempMatch[1]);
  }

  // 4. Distance in light-years or AU
  const distMatch = clean.match(/([\d.]+)\s*(?:light-years|ly|AU|km)/i);
  if (distMatch) {
    return parseFloat(distMatch[1]);
  }

  // 5. Generic leading number
  const numMatch = clean.match(/[-+]?[\d.]+/);
  return numMatch ? parseFloat(numMatch[0]) : null;
}

/**
 * Normalizes two values into percentage widths [pctA, pctB] for comparison bars
 * Uses logarithmic scaling when values differ by more than 8x so smaller bar remains clearly visible.
 */
export function calculateComparisonBarPercentages(numA, numB) {
  if (numA === null || numB === null || isNaN(numA) || isNaN(numB) || numA <= 0 || numB <= 0) {
    return { pctA: 50, pctB: 50, isComparable: false };
  }

  const ratio = Math.max(numA, numB) / Math.min(numA, numB);

  // If extreme difference (orders of magnitude), use log scaling
  if (ratio > 8) {
    const logA = Math.log10(numA + 1);
    const logB = Math.log10(numB + 1);
    const maxLog = Math.max(logA, logB);
    const pctA = Math.max(8, Math.round((logA / maxLog) * 100));
    const pctB = Math.max(8, Math.round((logB / maxLog) * 100));
    return { pctA, pctB, isComparable: true, isLogarithmic: true };
  }

  // Linear scaling
  const max = Math.max(numA, numB);
  const pctA = Math.max(12, Math.round((numA / max) * 100));
  const pctB = Math.max(12, Math.round((numB / max) * 100));
  return { pctA, pctB, isComparable: true, isLogarithmic: false };
}

/**
 * Extracts category-aware common comparison metrics for Object A and Object B
 * Only includes fields where at least one object has verified data.
 */
export function getComparisonMetrics(objA, objB) {
  if (!objA && !objB) return [];

  const rawDefinitions = [
    {
      id: 'type',
      label: 'Classification',
      icon: '🏷️',
      getA: (a) => a.subtype || a.type || (a.category ? CATEGORY_LABELS[a.category] : null),
      getB: (b) => b.subtype || b.type || (b.category ? CATEGORY_LABELS[b.category] : null),
      type: 'text',
    },
    {
      id: 'category',
      label: 'Object Realm',
      icon: '🌌',
      getA: (a) => (a.category ? CATEGORY_LABELS[a.category] : null),
      getB: (b) => (b.category ? CATEGORY_LABELS[b.category] : null),
      type: 'text',
    },
    {
      id: 'temperature',
      label: 'Effective Temperature',
      icon: '🔥',
      getA: (a) => a.temperature,
      getB: (b) => b.temperature,
      type: 'numeric',
    },
    {
      id: 'mass',
      label: 'Mass / Gravitational Scale',
      icon: '⚖️',
      getA: (a) => a.mass,
      getB: (b) => b.mass,
      type: 'numeric',
    },
    {
      id: 'radius',
      label: 'Physical Radius / Span',
      icon: '📏',
      getA: (a) => a.radius || a.diameter || a.eventHorizonRadius,
      getB: (b) => b.radius || b.diameter || b.eventHorizonRadius,
      type: 'numeric',
    },
    {
      id: 'distance',
      label: 'Distance from Earth / Sun',
      icon: '📍',
      getA: (a) => a.distance || a.distanceFromSun,
      getB: (b) => b.distance || b.distanceFromSun,
      type: 'numeric',
    },
    {
      id: 'orbitalPeriod',
      label: 'Orbital Period',
      icon: '🔄',
      getA: (a) => a.orbitalPeriod,
      getB: (b) => b.orbitalPeriod,
      type: 'text',
    },
    {
      id: 'rotationPeriod',
      label: 'Rotation Period',
      icon: '⏱️',
      getA: (a) => a.rotationPeriod,
      getB: (b) => b.rotationPeriod,
      type: 'text',
    },
    {
      id: 'spectralClass',
      label: 'Spectral Class',
      icon: '🌈',
      getA: (a) => a.spectralClass,
      getB: (b) => b.spectralClass,
      type: 'text',
    },
    {
      id: 'moons',
      label: 'Known Natural Moons',
      icon: '🌕',
      getA: (a) => (a.moons !== undefined ? `${a.moons} known moons` : null),
      getB: (b) => (b.moons !== undefined ? `${b.moons} known moons` : null),
      type: 'numeric',
    },
    {
      id: 'atmosphere',
      label: 'Atmospheric Composition',
      icon: '💨',
      getA: (a) => a.atmosphere,
      getB: (b) => b.atmosphere,
      type: 'text',
    },
    {
      id: 'constellation',
      label: 'Constellation / Region',
      icon: '✨',
      getA: (a) => a.constellation || a.relatedConstellation || a.hostGalaxy,
      getB: (b) => b.constellation || b.relatedConstellation || b.hostGalaxy,
      type: 'text',
    },
    {
      id: 'age',
      label: 'Estimated Stellar Age',
      icon: '⏳',
      getA: (a) => a.age,
      getB: (b) => b.age,
      type: 'text',
    },
    {
      id: 'magnitude',
      label: 'Apparent Visual Magnitude',
      icon: '💡',
      getA: (a) => a.magnitude,
      getB: (b) => b.magnitude,
      type: 'text',
    },
  ];

  const results = [];

  for (const def of rawDefinitions) {
    const valA = objA ? def.getA(objA) : null;
    const valB = objB ? def.getB(objB) : null;

    // Only include if at least one object has non-empty data
    if ((valA && valA !== '—') || (valB && valB !== '—')) {
      let bars = null;
      if (def.type === 'numeric' && valA && valB) {
        const numA = parseNumericValue(valA);
        const numB = parseNumericValue(valB);
        if (numA !== null && numB !== null) {
          bars = calculateComparisonBarPercentages(numA, numB);
        }
      }

      results.push({
        id: def.id,
        label: def.label,
        icon: def.icon,
        valA: valA || '—',
        valB: valB || '—',
        bars,
      });
    }
  }

  return results;
}

/**
 * Calculates smart, factual difference highlights based on verified object properties
 */
export function getComparisonInsights(objA, objB) {
  if (!objA || !objB) return [];

  const insights = [];

  // 1. Same-type vs Cross-type insight
  if (objA.category === objB.category) {
    insights.push({
      type: 'category',
      title: 'Same Celestial Realm',
      text: `Both ${objA.name} and ${objB.name} belong to the ${CATEGORY_LABELS[objA.category] || 'same category'} classification, allowing a direct comparison of evolutionary and physical properties.`,
    });
  } else {
    insights.push({
      type: 'category',
      title: 'Cross-Category Contrast',
      text: `Contrasting ${objA.name} (${CATEGORY_LABELS[objA.category] || 'Object'}) with ${objB.name} (${CATEGORY_LABELS[objB.category] || 'Object'}) reveals how matter behaves under vastly differing cosmic scales and forces.`,
    });
  }

  // 2. Temperature Difference
  if (objA.temperature && objB.temperature) {
    const numA = parseNumericValue(objA.temperature);
    const numB = parseNumericValue(objB.temperature);
    if (numA && numB) {
      if (Math.abs(numA - numB) > 200) {
        const hotter = numA > numB ? objA : objB;
        const cooler = numA > numB ? objB : objA;
        const diff = Math.abs(numA - numB).toLocaleString();
        insights.push({
          type: 'temperature',
          title: 'Thermal Energy',
          text: `${hotter.name} is hotter than ${cooler.name} by approximately ${diff} K (${hotter.temperature} vs ${cooler.temperature}).`,
        });
      } else {
        insights.push({
          type: 'temperature',
          title: 'Thermal Parity',
          text: `Both objects possess remarkably similar surface temperatures (${objA.temperature} vs ${objB.temperature}).`,
        });
      }
    }
  }

  // 3. Radius / Size Difference
  const radA = objA.radius || objA.diameter;
  const radB = objB.radius || objB.diameter;
  if (radA && radB) {
    const numRadA = parseNumericValue(radA);
    const numRadB = parseNumericValue(radB);
    if (numRadA && numRadB && numRadA !== numRadB) {
      const bigger = numRadA > numRadB ? objA : objB;
      const smaller = numRadA > numRadB ? objB : objA;
      const ratio = (Math.max(numRadA, numRadB) / Math.min(numRadA, numRadB)).toFixed(1);
      insights.push({
        type: 'size',
        title: 'Physical Scale',
        text: `${bigger.name} is approximately ${ratio}× larger in physical dimension than ${smaller.name}.`,
      });
    }
  }

  // 4. Moons comparison for planets
  if (objA.moons !== undefined && objB.moons !== undefined) {
    if (objA.moons !== objB.moons) {
      const more = objA.moons > objB.moons ? objA : objB;
      const less = objA.moons > objB.moons ? objB : objA;
      insights.push({
        type: 'moons',
        title: 'Satellite System',
        text: `${more.name} anchors ${more.moons} natural satellites, while ${less.name} possesses ${less.moons}.`,
      });
    }
  }

  // 5. Black hole event horizon comparison
  if (objA.category === CELESTIAL_CATEGORIES.BLACK_HOLE && objB.category === CELESTIAL_CATEGORIES.BLACK_HOLE) {
    insights.push({
      type: 'black-hole',
      title: 'Relativistic Gravity',
      text: `${objA.name} and ${objB.name} both form an event horizon where escape velocity equals the speed of light, warping surrounding spacetime.`,
    });
  }

  return insights.slice(0, 3);
}

/**
 * Suggests curated related comparison pairs based on currently compared targets
 */
export function getRelatedComparisons(objA, objB) {
  const currentIds = new Set([objA?.id, objB?.id].filter(Boolean));

  // Curated prominent comparisons bank
  const predefinedPairs = [
    ['sun', 'betelgeuse'],
    ['sun', 'sirius'],
    ['sun', 'vega'],
    ['betelgeuse', 'rigel'],
    ['earth', 'mars'],
    ['earth', 'venus'],
    ['jupiter', 'saturn'],
    ['sagittarius-a-star', 'm87-star'],
    ['sagittarius-a-star', 'cygnus-x1'],
    ['crab-pulsar', 'vela-pulsar'],
    ['sirius-b', 'crab-pulsar'],
    ['orion-nebula', 'andromeda-galaxy'],
    ['pleiades', 'hercules-cluster'],
  ];

  const results = [];

  // 1. Look for pairs involving either objA or objB
  for (const [id1, id2] of predefinedPairs) {
    if ((currentIds.has(id1) || currentIds.has(id2)) && !(currentIds.has(id1) && currentIds.has(id2))) {
      const o1 = getCelestialObjectById(id1);
      const o2 = getCelestialObjectById(id2);
      if (o1 && o2) {
        results.push({ objA: o1, objB: o2, label: `${o1.name} vs ${o2.name}` });
      }
    }
  }

  // 2. If fewer than 3, add general classic comparisons
  if (results.length < 3) {
    for (const [id1, id2] of predefinedPairs) {
      if (!currentIds.has(id1) && !currentIds.has(id2)) {
        const o1 = getCelestialObjectById(id1);
        const o2 = getCelestialObjectById(id2);
        if (o1 && o2) {
          results.push({ objA: o1, objB: o2, label: `${o1.name} vs ${o2.name}` });
        }
      }
      if (results.length >= 3) break;
    }
  }

  return results.slice(0, 3);
}
