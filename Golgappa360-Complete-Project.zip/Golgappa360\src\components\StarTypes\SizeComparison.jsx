import React, { useState } from 'react';

/**
 * SizeComparison — "SIZE IS EVERYTHING"
 * Visualizes the astonishing scale differential between:
 * White Dwarf -> Sun -> Red Giant -> Supergiant
 * Features "Relative scale — illustrative" badge and interactive telemetry chips.
 */
export default function SizeComparison() {
  const [activeItem, setActiveItem] = useState(null);

  const tiers = [
    {
      id: 'white-dwarf',
      name: 'White Dwarf',
      example: 'Sirius B',
      scaleLabel: '≈ 0.008 × Sun (≈ Earth)',
      diameter: '≈ 12,000 km',
      relativeVolume: '1 / 1,000,000 of Sun',
      color: '#f8fafc',
      glow: 'rgba(248, 250, 252, 0.6)',
      sizeClass: 'w-3 h-3',
      description: 'Ultra-dense degenerate core. Packs a full solar mass into an Earth-sized sphere.',
    },
    {
      id: 'sun',
      name: 'Sun (Yellow Dwarf)',
      example: 'Sol',
      scaleLabel: '1.0 × Sun (Reference)',
      diameter: '1,392,700 km',
      relativeVolume: '1.3 million Earths',
      color: '#fbbf24',
      glow: 'rgba(251, 191, 36, 0.5)',
      sizeClass: 'w-10 h-10 sm:w-12 sm:h-12',
      description: 'Our baseline main-sequence star. Standard astronomical unit of stellar mass and radius.',
    },
    {
      id: 'red-giant',
      name: 'Red Giant',
      example: 'Arcturus / Aldebaran',
      scaleLabel: '≈ 25–45 × Sun',
      diameter: '≈ 35–60 million km',
      relativeVolume: '≈ 15,000 to 90,000 Suns',
      color: '#fb923c',
      glow: 'rgba(251, 146, 60, 0.5)',
      sizeClass: 'w-24 h-24 sm:w-28 sm:h-28',
      description: 'Core hydrogen exhausted; outer convective atmosphere expands past inner planet orbits.',
    },
    {
      id: 'supergiant',
      name: 'Red Supergiant',
      example: 'Betelgeuse / Antares',
      scaleLabel: '≈ 700–1,000 × Sun',
      diameter: '≈ 1+ billion km',
      relativeVolume: '≈ 300 to 1,000 million Suns',
      color: '#ef4444',
      glow: 'rgba(239, 68, 68, 0.5)',
      sizeClass: 'w-48 h-48 sm:w-60 sm:h-60 lg:w-72 lg:h-72',
      description: 'Titan of the cosmos. If placed in our solar system, its surface would reach Jupiter.',
    },
  ];

  return (
    <div className="w-full flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-white/10 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>SCALE DISPARITY</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-2">
          SIZE IS EVERYTHING
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/80 leading-relaxed max-w-xl mx-auto">
          Stars span mind-boggling dimensions — from dense remnants smaller than Earth to gargantuan supergiants capable of swallowing whole planetary orbits.
        </p>

        {/* Mandatory Scientific Disclaimer Label */}
        <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-mono uppercase tracking-widest text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <span>Relative scale — illustrative</span>
        </div>
      </div>

      {/* Main Relative Scale Stage */}
      <div className="w-full p-6 sm:p-10 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden">
        {/* Stage Grid Background Lines */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none"
        />

        {/* Spheres Row */}
        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-around gap-8 sm:gap-12 min-h-[320px]">
          {tiers.map((tier) => {
            const isHovered = activeItem === tier.id;
            return (
              <div
                key={tier.id}
                onMouseEnter={() => setActiveItem(tier.id)}
                onMouseLeave={() => setActiveItem(null)}
                className="flex flex-col items-center text-center group cursor-pointer"
              >
                {/* Celestial Sphere Wrapper */}
                <div className="relative flex items-center justify-center min-h-[160px] sm:min-h-[220px]">
                  {/* Aura */}
                  <div
                    aria-hidden="true"
                    className="absolute rounded-full blur-xl transition-all duration-500 opacity-60 group-hover:opacity-100"
                    style={{
                      width: '100%',
                      height: '100%',
                      backgroundColor: tier.color,
                      transform: isHovered ? 'scale(1.2)' : 'scale(1)',
                    }}
                  />

                  {/* Body Sphere */}
                  <div
                    className={`relative rounded-full transition-transform duration-500 ease-out shadow-2xl ${tier.sizeClass} ${
                      isHovered ? 'scale-110' : ''
                    }`}
                    style={{
                      backgroundColor: tier.color,
                      boxShadow: `0 0 35px ${tier.glow}, inset 0 0 15px rgba(255, 255, 255, 0.7)`,
                    }}
                  />
                </div>

                {/* Info Text */}
                <div className="mt-4">
                  <h4 className="font-display font-semibold text-base sm:text-lg text-white group-hover:text-cyan-200 transition-colors">
                    {tier.name}
                  </h4>
                  <div className="text-xs font-mono text-cyan-300 mt-0.5">
                    {tier.scaleLabel}
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                    Ex: {tier.example}
                  </div>
                </div>

                {/* Subdued Description */}
                <p className="mt-2 font-sans text-xs text-slate-400 max-w-[180px] leading-relaxed hidden sm:block">
                  {tier.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Bottom Comparative Dimension Meter */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-slate-400">
          <div>
            <span>SMALLEST: </span>
            <strong className="text-white">Earth-sized White Dwarf (12,000 km)</strong>
          </div>
          <div>
            <span>LARGEST: </span>
            <strong className="text-rose-400">Betelgeuse (1+ Billion km across)</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
