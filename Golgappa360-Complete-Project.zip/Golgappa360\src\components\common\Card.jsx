import React from 'react';

export const Card = ({
  children,
  className = '',
  onClick,
  hoverable = false,
  glow = false,
  padded = true,
  ...props
}) => {
  const clickable = Boolean(onClick);

  return (
    <div
      onClick={onClick}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
      className={`
        bg-[#131E35]/85 backdrop-blur-md rounded-2xl
        border border-white/[0.08] transition-all duration-200
        ${padded ? 'p-4' : ''}
        ${clickable || hoverable ? 'cursor-pointer hover:bg-[#182642] hover:border-white/15 active:scale-[0.99]' : ''}
        ${glow ? 'shadow-[0_0_20px_-5px_rgba(0,245,160,0.15)] border-[#00F5A0]/25' : ''}
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  );
};
