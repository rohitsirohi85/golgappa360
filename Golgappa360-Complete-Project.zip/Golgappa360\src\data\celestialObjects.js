/**
 * STELLAR 2.0 — Celestial Objects Database & Universal Schema
 * 
 * Reusable astronomical object taxonomy and verified records for:
 * - Stars (Main Sequence, Giants, Supergiants, Red Dwarfs)
 * - White Dwarfs
 * - Neutron Stars
 * - Pulsars
 * - Black Holes
 * - Nebulae
 * - Star Clusters
 * - Galaxies
 * 
 * Extends the existing STARS_DATA architecture without duplication.
 * DISCLAIMER: Illustrative educational visualization — not to scale.
 */

import { STARS_DATA } from './stars.js';
import { STAR_COORDINATES, CONSTELLATION_REGIONS } from '../utils/mapCoordinates.js';
import { SOLAR_SYSTEM_DATA, MOON_DATA } from './solarSystem.js';
import { CONSTELLATIONS_DATA } from './constellations.js';

import {
  CELESTIAL_CATEGORIES,
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
} from './categories.js';

export {
  CELESTIAL_CATEGORIES,
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
};

/**
 * Deep Sky Celestial Objects (Black Holes, Nebulae, Clusters, Galaxies, Pulsars, Neutron Stars)
 */
export const DEEP_SKY_OBJECTS = [
  // ==========================================
  // BLACK HOLES
  // ==========================================
  {
    id: 'sagittarius-a-star',
    name: 'Sagittarius A*',
    commonName: 'Milky Way Central Supermassive Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Supermassive Black Hole',
    blackHoleType: 'supermassive',
    constellation: 'Sagittarius',
    hostGalaxy: 'Milky Way Galaxy',
    distance: '≈ 26,670 light-years',
    mass: '≈ 4.297 million × Sun',
    eventHorizonRadius: '≈ 12.7 million km (0.08 AU)',
    spinParameter: 'a* ≈ 0.90 (High Spin)',
    accretionDiskTemp: '≈ 10¹¹ K (Hot, thin RIAF flow)',
    hasJets: false,
    description: 'The supermassive gravitational behemoth residing at the dynamical heart of our Milky Way galaxy. In 2022, the Event Horizon Telescope collaborated across world observatories to resolve its shadow, confirming a searing ring of synchrotron light encircling the event horizon.',
    interestingFact: 'Stars near Sagittarius A*, like S2, whip around it at speeds reaching 8% of the speed of light during their closest orbital periastron.',
    visualColor: '#f59e0b',
    colorHex: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.45)',
    sizeClass: 'black-hole',
    x: 480,
    y: 60,
    tier: 1,
    baseRadius: 10,
    relatedConstellation: 'Sagittarius',
  },
  {
    id: 'm87-star',
    name: 'M87* (Messier 87)',
    commonName: 'First Ever Directly Imaged Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Supermassive Black Hole with Relativistic Jet',
    blackHoleType: 'supermassive',
    constellation: 'Virgo',
    hostGalaxy: 'Messier 87 (Virgo A Elliptical Galaxy)',
    distance: '≈ 53.5 million light-years',
    mass: '≈ 6.5 billion × Sun',
    eventHorizonRadius: '≈ 19.2 billion km (≈ 128 AU, larger than Pluto\'s orbit)',
    spinParameter: 'a* ≈ 0.90 ± 0.05',
    accretionDiskTemp: '≈ 10¹² K (Ultra-relativistic magnetized flow)',
    hasJets: true,
    description: 'The legendary cosmic monster at the core of giant elliptical galaxy Messier 87. In April 2019, humanity captured its historic first direct image of a black hole shadow, surrounded by an asymmetric ring of warped synchrotron emission and unleashing a 5,000-light-year relativistic jet into the Virgo Cluster.',
    interestingFact: 'Its event horizon is so colossal (over 38 billion km across) that our entire Solar System out past Neptune and Pluto could fit inside it multiple times.',
    visualColor: '#ea580c',
    colorHex: '#ea580c',
    glowColor: 'rgba(234, 88, 12, 0.5)',
    sizeClass: 'black-hole',
    x: -150,
    y: 110,
    tier: 2,
    baseRadius: 11,
    relatedConstellation: 'Virgo',
  },
  {
    id: 'cygnus-x1',
    name: 'Cygnus X-1',
    commonName: 'First Confirmed Stellar-Mass Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Stellar-Mass Black Hole (X-Ray Binary)',
    blackHoleType: 'stellar',
    constellation: 'Cygnus',
    hostGalaxy: 'Milky Way Galaxy',
    distance: '≈ 7,300 light-years',
    mass: '≈ 21.2 × Sun',
    eventHorizonRadius: '≈ 63 km',
    spinParameter: 'a* > 0.95 (Near Extreme Kerr Limit)',
    accretionDiskTemp: '≈ 10⁷ K (Intense soft X-rays)',
    companionStar: 'HDE 226868 (Blue Supergiant O9.7Iab)',
    hasJets: true,
    description: 'The first widely accepted black hole candidate discovered in 1964. Locked in a furious binary dance with blue supergiant companion star HDE 226868, it siphons stellar wind onto an incandescent relativistic accretion disk generating intense X-rays.',
    interestingFact: 'Stephen Hawking famously made a friendly scientific bet with physicist Kip Thorne in 1974 that Cygnus X-1 was not a black hole, finally conceding defeat in 1990.',
    visualColor: '#38bdf8',
    colorHex: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    sizeClass: 'black-hole',
    x: 390,
    y: -300,
    tier: 2,
    baseRadius: 7,
    relatedConstellation: 'Cygnus',
  },

  // ==========================================
  // NEUTRON STARS & PULSARS
  // ==========================================
  {
    id: 'crab-pulsar',
    name: 'Crab Pulsar',
    commonName: 'PSR B0531+21',
    category: CELESTIAL_CATEGORIES.PULSAR,
    subtype: 'Rotating Magnetized Neutron Star',
    constellation: 'Taurus',
    distance: '≈ 6,500 light-years',
    mass: '≈ 1.4 × Sun',
    radius: '≈ 10–12 km',
    rotationPeriod: '33.5 milliseconds (30 rev/sec)',
    description: 'The spinning superdense remnant of the historic SN 1054 supernova. Packing more mass than our Sun into a sphere the size of a city, it spins 30 times every second, sweeping twin synchrotron beams across cosmos like an ultra-precise cosmic lighthouse.',
    interestingFact: 'The energy output driving the entire expanding Crab Nebula is generated solely by the spin-down rotational kinetic energy of the Crab Pulsar.',
    visualColor: '#22d3ee',
    colorHex: '#22d3ee',
    glowColor: 'rgba(34, 211, 238, 0.6)',
    sizeClass: 'pulsar',
    x: -510,
    y: 190,
    tier: 2,
    baseRadius: 4.5,
    relatedConstellation: 'Taurus',
  },
  {
    id: 'vela-pulsar',
    name: 'Vela Pulsar',
    commonName: 'PSR B0833-45',
    category: CELESTIAL_CATEGORIES.PULSAR,
    subtype: 'Radio & Gamma-Ray Pulsar',
    constellation: 'Vela',
    distance: '≈ 936 light-years',
    mass: '≈ 1.5 × Sun',
    radius: '≈ 11 km',
    rotationPeriod: '89.3 milliseconds (11.2 rev/sec)',
    description: 'One of the brightest continuous sources of cosmic gamma rays in the nocturnal sky. Formed in a core-collapse supernova approximately 11,000 years ago, it is renowned for sudden rotational "glitches" where its spin rate abruptly accelerates.',
    interestingFact: 'Vela Pulsar exhibits occasional starquakes where its crystalline neutron crust fractures under immense rotational stress.',
    visualColor: '#818cf8',
    colorHex: '#818cf8',
    glowColor: 'rgba(129, 140, 248, 0.55)',
    sizeClass: 'pulsar',
    x: 320,
    y: 440,
    tier: 2,
    baseRadius: 4.2,
    relatedConstellation: 'Vela',
  },
  {
    id: 'rx-j1856',
    name: 'RX J1856.5-3754',
    commonName: 'The Magnificent Seven Anchor',
    category: CELESTIAL_CATEGORIES.NEUTRON_STAR,
    subtype: 'Isolated Thermal Neutron Star',
    constellation: 'Corona Australis',
    distance: '≈ 400 light-years',
    mass: '≈ 1.4 × Sun',
    radius: '≈ 14 km',
    temperature: '≈ 434,000 K',
    description: 'The closest known neutron star to Earth. Unlike pulsars, it does not display radio pulsations; its faint emission is purely thermal blackbody radiation emanating from its blisteringly hot surface cooled in deep vacuum.',
    interestingFact: 'A single teaspoon of material from RX J1856 would weigh approximately 5 billion metric tons on Earth.',
    visualColor: '#c084fc',
    colorHex: '#c084fc',
    glowColor: 'rgba(192, 132, 252, 0.5)',
    sizeClass: 'neutron-star',
    x: 430,
    y: 350,
    tier: 3,
    baseRadius: 3.5,
    relatedConstellation: 'Corona Australis',
  },

  // ==========================================
  // NEBULAE
  // ==========================================
  {
    id: 'orion-nebula',
    name: 'Orion Nebula',
    commonName: 'Messier 42 (M42 / NGC 1976)',
    category: CELESTIAL_CATEGORIES.NEBULA,
    subtype: 'Diffuse Emission & Reflection Nebula',
    constellation: 'Orion',
    distance: '≈ 1,344 light-years',
    diameter: '≈ 24 light-years across',
    description: 'One of the most intensely studied and luminous stellar nurseries in the Milky Way. Visible to the unaided eye directly below Orion’s Belt, it contains hundreds of protoplanetary disks (proplyds) birthing brand new stars and planetary systems.',
    interestingFact: 'The Trapezium Cluster at its center contains massive O-type stars whose ultraviolet photon barrage ionizes and illuminates the surrounding gas.',
    visualColor: '#38bdf8',
    colorHex: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.45)',
    sizeClass: 'nebula',
    x: -350,
    y: 360,
    tier: 1,
    baseRadius: 18,
    relatedConstellation: 'Orion',
  },
  {
    id: 'crab-nebula',
    name: 'Crab Nebula',
    commonName: 'Messier 1 (M1 / NGC 1952)',
    category: CELESTIAL_CATEGORIES.NEBULA,
    subtype: 'Supernova Remnant (Plerion)',
    constellation: 'Taurus',
    distance: '≈ 6,500 light-years',
    diameter: '≈ 11 light-years across',
    description: 'The expanding filamentary debris field of a titanic supernova explosion recorded by Chinese, Japanese, and Arab astronomers in 1054 CE. Powered by the central Crab Pulsar, the tangled glowing gas expands outward at 1,500 km/s.',
    interestingFact: 'The original 1054 supernova was so bright that it was visible in broad daylight for 23 consecutive days.',
    visualColor: '#f87171',
    colorHex: '#f87171',
    glowColor: 'rgba(248, 113, 113, 0.4)',
    sizeClass: 'nebula',
    x: -520,
    y: 200,
    tier: 2,
    baseRadius: 14,
    relatedConstellation: 'Taurus',
  },
  {
    id: 'ring-nebula',
    name: 'Ring Nebula',
    commonName: 'Messier 57 (M57 / NGC 6720)',
    category: CELESTIAL_CATEGORIES.NEBULA,
    subtype: 'Planetary Nebula',
    constellation: 'Lyra',
    distance: '≈ 2,570 light-years',
    diameter: '≈ 1.3 light-years across',
    description: 'A barrel-shaped expanding shell of glowing ionized gas ejected by a dying intermediate-mass star, showcasing the eventual fate awaiting our own Sun in approximately 5 billion years. At its core shines a blistering white dwarf.',
    interestingFact: 'The distinctive ring appearance is a line-of-sight perspective effect looking down the open cylinder pole of the expanding gas bubble.',
    visualColor: '#34d399',
    colorHex: '#34d399',
    glowColor: 'rgba(52, 211, 153, 0.45)',
    sizeClass: 'nebula',
    x: 270,
    y: -240,
    tier: 2,
    baseRadius: 12,
    relatedConstellation: 'Lyra',
  },
  {
    id: 'carina-nebula',
    name: 'Carina Nebula',
    commonName: 'NGC 3372 / Grand Nebula',
    category: CELESTIAL_CATEGORIES.NEBULA,
    subtype: 'Giant H II Emission Nebula',
    constellation: 'Carina',
    distance: '≈ 8,500 light-years',
    diameter: '≈ 460 light-years across',
    description: 'Four times larger and vastly more luminous than the Orion Nebula, Carina is an immense cauldron of active star formation containing some of the most massive and luminous hypergiants in the galaxy, including volatile Eta Carinae.',
    interestingFact: 'The Carina Nebula features the famous "Mystic Mountain" pillar of gas and dust immortalized in Hubble and James Webb imagery.',
    visualColor: '#fb7185',
    colorHex: '#fb7185',
    glowColor: 'rgba(251, 113, 133, 0.4)',
    sizeClass: 'nebula',
    x: 70,
    y: 490,
    tier: 2,
    baseRadius: 16,
    relatedConstellation: 'Carina',
  },

  // ==========================================
  // STAR CLUSTERS
  // ==========================================
  {
    id: 'pleiades',
    name: 'Pleiades',
    commonName: 'The Seven Sisters (Messier 45 / M45)',
    category: CELESTIAL_CATEGORIES.STAR_CLUSTER,
    subtype: 'Open Star Cluster',
    constellation: 'Taurus',
    distance: '≈ 444 light-years',
    diameter: '≈ 17.5 light-years across',
    age: '≈ 100 million years',
    starCount: '≈ 1,000+ stars (7 naked-eye)',
    description: 'The most iconic open cluster in the northern sky, dominated by luminous hot blue B-type stars. The cluster is currently drifting through a cold interstellar reflection nebula, causing the stars to be veiled in ethereal sapphire dust clouds.',
    interestingFact: 'Nearly every ancient civilization—from the Greeks, Celts, and Maori to the Persians and Japanese (Subaru)—has mythologies surrounding the Seven Sisters.',
    visualColor: '#60a5fa',
    colorHex: '#60a5fa',
    glowColor: 'rgba(96, 165, 250, 0.5)',
    sizeClass: 'cluster',
    x: -560,
    y: 110,
    tier: 1,
    baseRadius: 13,
    relatedConstellation: 'Taurus',
  },
  {
    id: 'hyades',
    name: 'Hyades Cluster',
    commonName: 'Caldwell 41 / Melotte 25',
    category: CELESTIAL_CATEGORIES.STAR_CLUSTER,
    subtype: 'Open Star Cluster',
    constellation: 'Taurus',
    distance: '≈ 153 light-years',
    diameter: '≈ 20 light-years across',
    age: '≈ 625 million years',
    starCount: '≈ 300–400 stars',
    description: 'The closest open star cluster to Earth, forming the distinctive "V" shaped head of Taurus the Bull. While bright orange Aldebaran appears in the middle of the "V", it is a foreground star and not a true physical cluster member.',
    interestingFact: 'The Hyades and the Praesepe (Beehive) cluster share similar ages and proper motions, indicating a common origin in the same ancestral molecular cloud.',
    visualColor: '#f59e0b',
    colorHex: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    sizeClass: 'cluster',
    x: -450,
    y: 130,
    tier: 2,
    baseRadius: 11,
    relatedConstellation: 'Taurus',
  },
  {
    id: 'hercules-cluster',
    name: 'Hercules Cluster',
    commonName: 'Great Globular Cluster (Messier 13 / M13)',
    category: CELESTIAL_CATEGORIES.STAR_CLUSTER,
    subtype: 'Globular Star Cluster',
    constellation: 'Hercules',
    distance: '≈ 22,200 light-years',
    diameter: '≈ 145 light-years across',
    age: '≈ 11.6 billion years',
    starCount: '≈ 300,000+ stars',
    description: 'A densely packed spherical swarm of over 300,000 ancient stars orbiting in the Milky Way halo. In 1974, the Arecibo radio observatory beamed the famous Arecibo Message toward M13 in an effort to contact extraterrestrial intelligence.',
    interestingFact: 'Near the core of M13, stars are packed together 500 times more densely than the stellar neighborhood surrounding our Sun.',
    visualColor: '#e0f2fe',
    colorHex: '#e0f2fe',
    glowColor: 'rgba(224, 242, 254, 0.45)',
    sizeClass: 'cluster',
    x: 100,
    y: -190,
    tier: 2,
    baseRadius: 12,
    relatedConstellation: 'Hercules',
  },

  // ==========================================
  // GALAXIES
  // ==========================================
  {
    id: 'milky-way-core',
    name: 'Milky Way Core',
    commonName: 'Galactic Center (Sagittarius Arm)',
    category: CELESTIAL_CATEGORIES.GALAXY,
    subtype: 'Barred Spiral Galaxy Center',
    constellation: 'Sagittarius',
    distance: '≈ 26,670 light-years',
    diameter: '≈ 100,000 light-years total span',
    starCount: '≈ 100–400 billion stars',
    description: 'The rotational axis and dense stellar nucleus of our home island universe. Shrouded by dense lanes of interstellar dust along the galactic equator, it contains billions of ancient stars swirling around central supermassive black hole Sagittarius A*.',
    interestingFact: 'Our Solar System orbits the Galactic Center once every 230 million years, a duration known as one "Cosmic Year".',
    visualColor: '#fef08a',
    colorHex: '#fef08a',
    glowColor: 'rgba(254, 240, 138, 0.4)',
    sizeClass: 'galaxy',
    x: 480,
    y: 80,
    tier: 1,
    baseRadius: 22,
    relatedConstellation: 'Sagittarius',
  },
  {
    id: 'andromeda-galaxy',
    name: 'Andromeda Galaxy',
    commonName: 'Messier 31 (M31 / NGC 224)',
    category: CELESTIAL_CATEGORIES.GALAXY,
    subtype: 'Major Barred Spiral Galaxy',
    constellation: 'Andromeda',
    distance: '≈ 2.537 million light-years',
    diameter: '≈ 220,000 light-years across',
    starCount: '≈ 1 trillion stars',
    description: 'The largest member of our Local Group of galaxies and the most distant object routinely visible to the naked human eye under pristine dark skies. Spanning over 220,000 light-years, it contains roughly one trillion stars.',
    interestingFact: 'Andromeda and the Milky Way are hurtling toward each other at 110 km/s and are predicted to merge into a giant elliptical galaxy ("Milkomeda") in 4.5 billion years.',
    visualColor: '#93c5fd',
    colorHex: '#93c5fd',
    glowColor: 'rgba(147, 197, 253, 0.4)',
    sizeClass: 'galaxy',
    x: 600,
    y: -450,
    tier: 1,
    baseRadius: 24,
    relatedConstellation: 'Andromeda',
  },
  {
    id: 'triangulum-galaxy',
    name: 'Triangulum Galaxy',
    commonName: 'Messier 33 (M33 / NGC 598)',
    category: CELESTIAL_CATEGORIES.GALAXY,
    subtype: 'Pinwheel Spiral Galaxy',
    constellation: 'Triangulum',
    distance: '≈ 2.73 million light-years',
    diameter: '≈ 60,000 light-years across',
    starCount: '≈ 40 billion stars',
    description: 'The third-largest galaxy in our Local Group after Andromeda and the Milky Way. Known for prominent face-on spiral arms teeming with luminous starburst regions, most notably NGC 604, one of the largest known emission nebulae in the universe.',
    interestingFact: 'M33 may be gravitationally bound to Andromeda, orbiting as a colossal companion galaxy.',
    visualColor: '#c7d2fe',
    colorHex: '#c7d2fe',
    glowColor: 'rgba(199, 210, 254, 0.35)',
    sizeClass: 'galaxy',
    x: 680,
    y: -380,
    tier: 2,
    baseRadius: 16,
    relatedConstellation: 'Triangulum',
  },
  {
    id: 'large-magellanic-cloud',
    name: 'Large Magellanic Cloud',
    commonName: 'LMC / Satellite Galaxy',
    category: CELESTIAL_CATEGORIES.GALAXY,
    subtype: 'Magellanic Spiral / Dwarf Satellite',
    constellation: 'Dorado / Mensa',
    distance: '≈ 158,200 light-years',
    diameter: '≈ 32,000 light-years across',
    starCount: '≈ 20 billion stars',
    description: 'A vibrant dwarf satellite galaxy orbiting the Milky Way, easily observed with the naked eye from the Southern Hemisphere. It houses the Tarantula Nebula (30 Doradus), the most active starburst nursery in the entire Local Group.',
    interestingFact: 'The closest observed supernova in modern history, SN 1987A, erupted inside the Large Magellanic Cloud in February 1987.',
    visualColor: '#a7f3d0',
    colorHex: '#a7f3d0',
    glowColor: 'rgba(167, 243, 208, 0.35)',
    sizeClass: 'galaxy',
    x: -120,
    y: 550,
    tier: 2,
    baseRadius: 18,
    relatedConstellation: 'Dorado',
  },
];

/**
 * Normalizes all 31 existing stars from STARS_DATA to match the universal celestial schema.
 */
export const NORMALIZED_STARS = STARS_DATA.map((star) => {
  const isWhiteDwarf = star.id === 'sirius-b' || star.type === 'White Dwarf';
  const category = isWhiteDwarf ? CELESTIAL_CATEGORIES.WHITE_DWARF : CELESTIAL_CATEGORIES.STAR;

  const coord = STAR_COORDINATES[star.id] || {
    x: 0,
    y: 0,
    tier: 2,
    baseRadius: 4.5,
    hasDiffraction: false,
  };

  let sizeClass = 'normal';
  if (star.type === 'Supergiant') sizeClass = 'supergiant';
  else if (star.type === 'Giant') sizeClass = 'giant';
  else if (star.type === 'Red Dwarf') sizeClass = 'dwarf';
  else if (isWhiteDwarf) sizeClass = 'white-dwarf';

  return {
    ...star,
    ...coord,
    category,
    subtype: star.type,
    sizeClass,
    isStar: true,
    relatedConstellation: star.constellation,
  };
});

/**
 * Astronomical relationships between celestial objects.
 */
export const CELESTIAL_RELATIONSHIPS = {
  'sun': ['earth', 'jupiter', 'mars', 'saturn', 'venus', 'mercury', 'uranus', 'neptune', 'proxima-centauri', 'sirius'],
  'mercury': ['sun', 'venus'],
  'venus': ['mercury', 'earth', 'sun'],
  'earth': ['moon', 'sun', 'mars', 'venus', 'jupiter'],
  'moon': ['earth', 'sun'],
  'mars': ['earth', 'sun', 'jupiter'],
  'jupiter': ['sun', 'saturn', 'mars'],
  'saturn': ['jupiter', 'uranus', 'sun'],
  'uranus': ['saturn', 'neptune', 'sun'],
  'neptune': ['uranus', 'sun'],
  'proxima-centauri': ['sun'],
  'sirius': ['sirius-b', 'adhara', 'wezen'],
  'sirius-b': ['sirius', 'adhara'],
  'adhara': ['sirius', 'wezen'],
  'wezen': ['sirius', 'adhara'],
  'betelgeuse': ['rigel', 'bellatrix', 'orion-nebula', 'alnilam'],
  'rigel': ['betelgeuse', 'mintaka', 'saiph', 'orion-nebula'],
  'bellatrix': ['betelgeuse', 'mintaka', 'orion-nebula'],
  'alnilam': ['alnitak', 'mintaka', 'betelgeuse', 'orion-nebula'],
  'alnitak': ['alnilam', 'saiph', 'orion-nebula'],
  'mintaka': ['alnilam', 'bellatrix', 'rigel', 'orion-nebula'],
  'saiph': ['rigel', 'alnitak', 'orion-nebula'],
  'orion-nebula': ['betelgeuse', 'rigel', 'alnilam'],
  'aldebaran': ['pleiades', 'hyades', 'crab-nebula'],
  'pleiades': ['aldebaran', 'hyades'],
  'hyades': ['aldebaran', 'pleiades'],
  'crab-nebula': ['crab-pulsar', 'aldebaran'],
  'crab-pulsar': ['crab-nebula', 'aldebaran'],
  'vega': ['deneb', 'ring-nebula'],
  'ring-nebula': ['vega', 'deneb'],
  'deneb': ['vega', 'cygnus-x1'],
  'cygnus-x1': ['deneb', 'sagittarius-a-star', 'm87-star'],
  'polaris': ['dubhe', 'merak'],
  'dubhe': ['merak', 'alioth', 'polaris'],
  'merak': ['dubhe', 'alioth', 'polaris'],
  'alioth': ['mizar', 'merak', 'dubhe'],
  'mizar': ['alioth', 'alkaid'],
  'alkaid': ['mizar', 'arcturus'],
  'arcturus': ['spica', 'alkaid'],
  'spica': ['arcturus', 'm87-star'],
  'caph': ['schedar', 'gamma-cas'],
  'schedar': ['caph', 'gamma-cas'],
  'gamma-cas': ['schedar', 'caph'],
  'antares': ['shaula'],
  'shaula': ['antares'],
  'regulus': ['denebola'],
  'denebola': ['regulus'],
  'sagittarius-a-star': ['milky-way-core', 'm87-star', 'cygnus-x1'],
  'm87-star': ['sagittarius-a-star', 'cygnus-x1', 'spica'],
  'milky-way-core': ['sagittarius-a-star', 'large-magellanic-cloud'],
  'andromeda-galaxy': ['triangulum-galaxy', 'milky-way-core'],
  'triangulum-galaxy': ['andromeda-galaxy', 'milky-way-core'],
  'large-magellanic-cloud': ['milky-way-core'],
  'vela-pulsar': ['rx-j1856', 'carina-nebula'],
  'rx-j1856': ['vela-pulsar'],
  'carina-nebula': ['vela-pulsar'],
  'hercules-cluster': ['vega', 'arcturus'],
};

/**
 * Complete unified database of all Celestial Objects on the Universe Map:
 * 31 catalog stars + 15 deep-sky objects = 46 celestial landmarks.
 */
export const ALL_CELESTIAL_OBJECTS = [
  ...NORMALIZED_STARS,
  ...DEEP_SKY_OBJECTS,
];

/**
 * Featured Constellations mapped as celestial regions for search, discovery and navigation.
 */
export const CONSTELLATION_OBJECTS = CONSTELLATIONS_DATA.map((c) => {
  const reg = CONSTELLATION_REGIONS.find((r) => r.id === c.id || r.name.toLowerCase() === c.name.toLowerCase()) || { x: 0, y: 0, framingZoom: 1.45, radius: 180 };
  return {
    id: c.id,
    name: c.name,
    latinName: c.latinName,
    commonName: c.commonTitle,
    category: CELESTIAL_CATEGORIES.CONSTELLATION,
    subtype: 'Constellation Pattern',
    description: c.description,
    mythology: c.mythology,
    hemisphere: c.hemisphere,
    bestViewingSeason: c.bestViewingSeason,
    quadrant: c.quadrant,
    areaSqDeg: c.areaSqDeg,
    abbreviation: c.abbreviation,
    x: reg.x,
    y: reg.y,
    framingZoom: reg.framingZoom || 1.45,
    regionRadius: reg.radius || 180,
    colorHex: c.accentColor || '#38bdf8',
    glowColor: c.glowColor || 'rgba(56, 189, 248, 0.45)',
    mainStars: c.mainStars,
    showcaseStars: c.showcaseStars,
    notableObjects: c.notableObjects,
    visibilityNotes: c.visibilityNotes,
    isConstellation: true,
  };
});

/**
 * Extended search index including the 8 major Solar System planets, the Moon, and featured constellations.
 */
export const ALL_SEARCHABLE_OBJECTS = [
  ...ALL_CELESTIAL_OBJECTS,
  ...SOLAR_SYSTEM_DATA.filter((p) => p.id !== 'sun'),
  MOON_DATA,
  ...CONSTELLATION_OBJECTS,
];

/**
 * Filter options for the Universe Map
 */
export const FILTER_OPTIONS = [
  { id: 'ALL', label: 'All Objects', category: null },
  { id: 'CONSTELLATIONS', label: 'Constellations', category: CELESTIAL_CATEGORIES.CONSTELLATION },
  { id: 'STARS', label: 'Stars', category: CELESTIAL_CATEGORIES.STAR },
  { id: 'WHITE_DWARFS', label: 'White Dwarfs', category: CELESTIAL_CATEGORIES.WHITE_DWARF },
  { id: 'NEUTRON_STARS', label: 'Neutron Stars', category: CELESTIAL_CATEGORIES.NEUTRON_STAR },
  { id: 'PULSARS', label: 'Pulsars', category: CELESTIAL_CATEGORIES.PULSAR },
  { id: 'BLACK_HOLES', label: 'Black Holes', category: CELESTIAL_CATEGORIES.BLACK_HOLE },
  { id: 'NEBULAE', label: 'Nebulae', category: CELESTIAL_CATEGORIES.NEBULA },
  { id: 'CLUSTERS', label: 'Star Clusters', category: CELESTIAL_CATEGORIES.STAR_CLUSTER },
  { id: 'GALAXIES', label: 'Galaxies', category: CELESTIAL_CATEGORIES.GALAXY },
];

/**
 * Quick lookup index for all celestial objects (including planets, Moon, and constellations)
 */
const OBJECT_MAP = new Map(
  [...ALL_CELESTIAL_OBJECTS, ...SOLAR_SYSTEM_DATA, MOON_DATA, ...CONSTELLATION_OBJECTS].map((obj) => [obj.id, obj])
);

/**
 * Returns a celestial object by ID.
 */
export function getCelestialObjectById(id) {
  return OBJECT_MAP.get(id) || null;
}

/**
 * Returns full objects for all related IDs of a given celestial object.
 */
export function getRelatedObjects(id) {
  const ids = CELESTIAL_RELATIONSHIPS[id] || [];
  return ids.map((relId) => OBJECT_MAP.get(relId)).filter(Boolean);
}
