import React, { useState } from 'react';
import {
  TrendingUp,
  CreditCard,
  QrCode,
  Banknote,
  Clock,
  Calendar,
  Layers,
  Award,
  Sparkles,
  ArrowUpRight,
  ShoppingBag,
  Flame,
  CheckCircle2
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard, GlassPanel } from '../components/glass/GlassCard';
import { Badge } from '../components/common/Badge';

export function SalesAnalyticsPage() {
  const { overviewData, salesAnalytics } = useGolgappa();
  const [timeGranularity, setTimeGranularity] = useState('daily'); // 'daily', 'weekly', 'monthly'

  const kpis = overviewData?.kpis || {
    totalRevenue: 301655,
    totalPlatesSold: 8400,
    grossProfit: 217624,
    aov: 61.04,
    totalOrders: 4942
  };

  const dailySales = overviewData?.dailySalesChart || [];
  const hourlyProfile = salesAnalytics?.hourlySalesProfile || overviewData?.hourlySalesProfile || [];

  // Monthly Aggregated Data derived from real analytics
  const monthlyData = (salesAnalytics?.monthlySalesChart || []).map(m => ({
    period: m.monthLabel || m.month,
    revenue: m.revenue,
    plates: m.plates,
    profit: m.grossProfit,
    cogs: m.cogs,
    expenses: m.expenses,
    operatingProfit: m.operatingProfit
  }));

  // Weekly Aggregated Data dynamically grouped from daily sales (7-day intervals)
  const weeklyData = [];
  if (dailySales && dailySales.length > 0) {
    for (let i = 0; i < dailySales.length; i += 7) {
      const chunk = dailySales.slice(i, i + 7);
      const startDay = chunk[0].date || chunk[0].fullDate?.slice(5);
      const endDay = chunk[chunk.length - 1].date || chunk[chunk.length - 1].fullDate?.slice(5);
      const rev = chunk.reduce((acc, c) => acc + (c.revenue || 0), 0);
      const plates = chunk.reduce((acc, c) => acc + (c.plates || 0), 0);
      const orders = chunk.reduce((acc, c) => acc + (c.orders || 0), 0);
      weeklyData.push({
        period: `${startDay} - ${endDay}`,
        revenue: Math.round(rev),
        plates,
        aov: orders > 0 ? Number((rev / orders).toFixed(2)) : 0
      });
    }
  }

  const currentChartData = timeGranularity === 'weekly' 
    ? (weeklyData.length > 0 ? weeklyData : dailySales)
    : timeGranularity === 'monthly' 
    ? (monthlyData.length > 0 ? monthlyData : dailySales)
    : dailySales;

  // Day of week trends from real analytics
  const rawDow = salesAnalytics?.dayOfWeekTrends || [];
  const dayOfWeekTrends = rawDow.map(d => ({
    day: d.dayFull || d.day,
    shortDay: d.shortDay || d.day?.slice(0, 3),
    avgPlates: d.plates,
    avgRevenue: d.revenue
  }));

  // Payment Breakdown with real counts & turnover
  const rawPayments = salesAnalytics?.paymentBreakdown || [];
  const paymentBreakdown = rawPayments.map(p => ({
    method: p.method,
    short: p.rawMethod || (p.method?.includes('UPI') ? 'UPI' : 'Cash'),
    percentage: p.revenueSharePct || p.percentage || 50,
    revenue: p.revenue,
    orders: p.count || p.orders || 0,
    color: p.color || (p.rawMethod === 'Cash' ? '#EAB64B' : '#A7D78A'),
    icon: p.rawMethod === 'Cash' ? Banknote : QrCode
  }));

  // Product & Flavour Performance from real analytics
  const flavourAnalytics = (salesAnalytics?.productPerformance || overviewData?.productSalesDistribution || []).map(p => ({
    flavour: p.product_name || p.name,
    plates: p.plates_sold !== undefined ? p.plates_sold : p.plates,
    revenue: p.net_revenue !== undefined ? p.net_revenue : p.revenue,
    share: p.volume_share_pct !== undefined ? p.volume_share_pct : p.share,
    margin: p.gross_margin_pct !== undefined ? p.gross_margin_pct : p.margin,
    note: `${p.category || 'Speciality'} • ₹${p.selling_price || 35} / plate`
  }));

  return (
    <div className="space-y-6">
      {/* Top Header & Granularity Pill Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/[0.08]">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F4F1] font-sans">
            Sales Analytics & Footfall Engine
          </h2>
          <p className="text-xs text-[#929195] mt-0.5">
            Cross-analyzing turnover velocity against physical plate serving speed
          </p>
        </div>

        {/* Granularity Pill Switcher */}
        <div className="flex items-center p-1 bg-white/[0.07] rounded-2xl border border-white/12 shadow-xs">
          {[
            { id: 'daily', label: 'Daily View' },
            { id: 'weekly', label: 'Weekly Summary' },
            { id: 'monthly', label: 'Monthly Growth' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setTimeGranularity(tab.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                timeGranularity === tab.id
                  ? 'bg-white/20 text-[#F5F4F1] border border-white/20 shadow-xs'
                  : 'text-[#929195] hover:text-[#F5F4F1]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Top 4 Metric Glass Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Average Order Value (AOV)</p>
          <div className="flex items-baseline justify-between mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1]">₹{kpis.aov}</h3>
            <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-md border border-[#A7D78A]/30">
              +₹4.20 vs Aug
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">Avg 1.7 plates per customer bill</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Peak Hour Throughput</p>
          <div className="flex items-baseline justify-between mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1]">625 Plates</h3>
            <span className="text-xs font-bold text-[#EAB64B] bg-[#EAB64B]/15 px-2 py-0.5 rounded-md border border-[#EAB64B]/30">
              7:00 – 8:00 PM
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">10.4 plates served every minute</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Weekend Footfall Surge</p>
          <div className="flex items-baseline justify-between mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1]">+74.5%</h3>
            <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-md border border-[#A7D78A]/30">
              Sat & Sun
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">420 weekend vs 235 weekday plates</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Digital UPI Settlement</p>
          <div className="flex items-baseline justify-between mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#A7D78A]">71.2%</h3>
            <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-md border border-[#A7D78A]/30">
              ₹2.14L settled
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">Zero cash change shortage complaints</p>
        </GlassCard>
      </div>

      {/* Main Composed Chart Glass Card */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] tracking-tight">
              Revenue & Plate Volume Dynamics ({timeGranularity.toUpperCase()})
            </h3>
            <p className="text-xs text-[#929195]">
              Correlating turnover velocity with counter preparation volume
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#A7D78A]" />
              <span className="text-[#B8B7B9] font-medium">Turnover (₹)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#EAB64B]" />
              <span className="text-[#B8B7B9] font-medium">Plates Sold</span>
            </div>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={currentChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis
                dataKey={timeGranularity === 'daily' ? 'date' : 'period'}
                tick={{ fill: '#929195', fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis yAxisId="revAxis" tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="plateAxis" orientation="right" tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(28,28,30,0.95)',
                  borderColor: 'rgba(255,255,255,0.15)',
                  borderRadius: '14px',
                  fontSize: '11px',
                  color: '#F5F4F1'
                }}
                formatter={(val, name) => [
                  name === 'revenue' ? `₹${val.toLocaleString('en-IN')}` : `${val} plates`,
                  name === 'revenue' ? 'Turnover (₹)' : 'Plates'
                ]}
              />
              <Bar yAxisId="plateAxis" dataKey="plates" fill="#EAB64B" radius={[4, 4, 0, 0]} opacity={0.88} name="Plates Sold" />
              <Line yAxisId="revAxis" type="monotone" dataKey="revenue" stroke="#A7D78A" strokeWidth={3} dot={{ r: 3, fill: '#A7D78A' }} name="Turnover (₹)" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>

      {/* Row 2: Day of Week Seasonality & Payment Channel Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Day of Week Seasonality */}
        <div className="lg:col-span-7 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1]">Day-of-Week Rush Analysis</h3>
              <p className="text-xs text-[#929195]">Average plates and revenue per day of week</p>
            </div>
            <span className="text-[10px] font-bold text-[#EAB64B] bg-[#EAB64B]/15 px-2.5 py-1 rounded-full border border-[#EAB64B]/30">
              Weekend Spike
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dayOfWeekTrends} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="shortDay" tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(28,28,30,0.95)',
                    borderColor: 'rgba(255,255,255,0.15)',
                    borderRadius: '14px',
                    fontSize: '11px',
                    color: '#F5F4F1'
                  }}
                  formatter={(val, name) => [
                    name === 'avgRevenue' ? `₹${val.toLocaleString('en-IN')}` : `${val} plates`,
                    name === 'avgRevenue' ? 'Avg Revenue' : 'Avg Plates'
                  ]}
                />
                <Bar dataKey="avgRevenue" radius={[5, 5, 0, 0]} name="Avg Revenue (₹)">
                  {dayOfWeekTrends.map((d, index) => (
                    <Cell
                      key={`dow-${index}`}
                      fill={d.day === 'Saturday' || d.day === 'Sunday' ? '#EAB64B' : '#A7D78A'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 bg-white/[0.04] rounded-2xl border border-white/10 text-xs text-[#B8B7B9] flex items-center justify-between">
            <span>Weekday Baseline: <strong>₹7,800 / day</strong></span>
            <span>Weekend Peak: <strong className="text-[#EAB64B]">₹15,200 / day</strong> (+94% surge)</span>
          </div>
        </div>

        {/* Payment Methods Breakdown */}
        <div className="lg:col-span-5 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1]">Payment Channel Distribution</h3>
              <p className="text-xs text-[#929195]">Turnover & volume by settlement mode</p>
            </div>
            <Badge variant="success" size="sm">UPI Dominant</Badge>
          </div>

          <div className="space-y-4 my-auto py-2">
            {paymentBreakdown.map((pay) => (
              <div key={pay.method} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: pay.color }} />
                    <span className="font-semibold text-[#F5F4F1]">{pay.short}</span>
                    <span className="text-[#929195]">({pay.orders} bills)</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="font-bold text-[#F5F4F1]">₹{pay.revenue.toLocaleString('en-IN')}</span>
                    <span className="font-semibold text-[#929195]">({pay.percentage}%)</span>
                  </div>
                </div>
                {/* Glass progress bar */}
                <div className="w-full h-2 rounded-full bg-white/[0.08] overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pay.percentage}%`, backgroundColor: pay.color }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3.5 bg-white/[0.04] rounded-2xl border border-white/10 text-xs text-[#A7D78A] flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed text-[#B8B7B9]">
              <strong className="text-[#A7D78A]">UPI Reconciliation:</strong> Digital QR tickets average ₹68.40 vs ₹52.10 in Cash, generating 31% higher basket sizes.
            </p>
          </div>
        </div>
      </div>

      {/* Row 3: Flavour Volume Table */}
      <div className="glass-card p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] tracking-tight">
              Flavour & Recipe Volume Breakdown
            </h3>
            <p className="text-xs text-[#929195]">
              Customer preference analysis across spiced water recipes and loaded savories
            </p>
          </div>
          <span className="text-xs font-semibold text-[#A7D78A] bg-[#A7D78A]/15 px-3 py-1 rounded-full border border-[#A7D78A]/30">
            5 Flavours Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#F5F4F1]">
            <thead className="bg-white/[0.04] text-[#929195] font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-5 py-3.5 rounded-l-xl">Flavour Profile</th>
                <th className="px-5 py-3.5 text-center">Plates Sold</th>
                <th className="px-5 py-3.5 text-center">Volume Share</th>
                <th className="px-5 py-3.5 text-center">Gross Margin %</th>
                <th className="px-5 py-3.5 rounded-r-xl">Consumer Trend Observation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              {flavourAnalytics.map((item) => (
                <tr key={item.flavour} className="hover:bg-white/[0.04] transition-colors">
                  <td className="px-5 py-3.5 font-bold text-[#F5F4F1] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#A7D78A]" />
                    {item.flavour}
                  </td>
                  <td className="px-5 py-3.5 text-center font-bold">
                    {item.plates.toLocaleString('en-IN')}
                  </td>
                  <td className="px-5 py-3.5 text-center font-semibold text-[#A7D78A]">
                    {item.share}%
                  </td>
                  <td className="px-5 py-3.5 text-center font-bold text-[#EAB64B]">
                    {item.margin}%
                  </td>
                  <td className="px-5 py-3.5 text-[#B8B7B9]">
                    {item.note}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
