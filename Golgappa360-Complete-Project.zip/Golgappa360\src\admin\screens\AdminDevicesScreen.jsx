import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  Cpu,
  Wifi,
  Radio,
  Clock,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';

export const AdminDevicesScreen = () => {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchDevices = async () => {
    try {
      setLoading(true);
      const data = await adminService.getDevices();
      if (Array.isArray(data)) {
        setDevices(data);
      }
    } catch (err) {
      console.error('Error fetching devices:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDevices();
  }, []);

  const filteredDevices = devices.filter((d) => {
    const matches =
      d.deviceId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.chargerId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.ipAddress?.toLowerCase().includes(searchTerm.toLowerCase());
    return matches;
  });

  const onlineCount = devices.filter((d) => d.status === 'online').length;

  return (
    <AdminLayout
      pageTitle="IoT Hardware Monitor"
      subtitle="ESP32 microcontrollers, sensor telemetry health & edge connectivity status"
    >
      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Total Devices</span>
          <div className="text-2xl font-black text-white font-mono">{devices.length}</div>
          <span className="text-xs text-slate-400">Deployed microcontrollers</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Online Heartbeat</span>
          <div className="text-2xl font-black text-emerald-400 font-mono">{onlineCount}</div>
          <span className="text-xs text-slate-400">Transmitting telemetry</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Watchdog Protocol</span>
          <div className="text-2xl font-black text-sky-400 font-mono">15s / 30s</div>
          <span className="text-xs text-slate-400">Ping interval / Offline trip</span>
        </div>
      </div>

      {/* Search & Refresh */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by device ID, bay, IP address..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-emerald-500 focus:outline-none"
          />
        </div>

        <button
          onClick={fetchDevices}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Sync Hardware</span>
        </button>
      </div>

      {/* Devices Grid */}
      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Querying edge device heartbeats...</p>
        </div>
      ) : filteredDevices.length === 0 ? (
        <div className="h-64 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-slate-500 text-xs">
          <Cpu className="w-10 h-10 mb-2 text-slate-700" />
          <p>No IoT devices registered.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDevices.map((d) => {
            const isOnline = d.status === 'online';

            return (
              <div
                key={d._id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                        <Cpu className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-white text-sm font-mono">{d.deviceId}</h4>
                        <span className="text-[11px] text-slate-400">
                          Bay: <strong className="text-emerald-400">{d.chargerId}</strong>
                        </span>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${
                        isOnline
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {d.status}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 my-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">IP Address:</span>
                      <span className="font-mono text-slate-300">{d.ipAddress || '192.168.1.101'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Wi-Fi Signal:</span>
                      <div className="flex items-center gap-1 font-mono text-slate-300">
                        <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{d.rssi || -58} dBm</span>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Firmware:</span>
                      <span className="font-mono text-emerald-400">v3.4.0-RTOS</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>Last heartbeat:</span>
                  </span>
                  <span className="font-mono text-slate-400">
                    {d.lastHeartbeat ? new Date(d.lastHeartbeat).toLocaleTimeString() : 'Recent'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminDevicesScreen;
