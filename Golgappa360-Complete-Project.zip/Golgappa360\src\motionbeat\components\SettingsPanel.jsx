import React from 'react';
import { 
  Sliders, 
  ChevronRight, 
  RotateCcw, 
  Sparkles, 
  Eye, 
  Gauge, 
  Zap, 
  Video, 
  Radio,
  Cpu
} from 'lucide-react';

export const SettingsPanel = ({
  settings,
  onUpdateSettings,
  onResetSettings,
  isOpen,
  onToggle,
  mousePos = { x: 0, y: 0 },
  trackingTelemetry = { handCount: 0, hands: [], inferenceTimeMs: 0 },
  cameraStatus = 'off',
  gestureEnabled = true,
  onToggleGesture,
  graphicsQuality = 'high',
  onQualityChange,
}) => {
  if (!isOpen) return null;

  return (
    <aside className="w-80 border-l border-white/10 mb-panel flex flex-col z-20 transition-all duration-300 h-full overflow-hidden select-none">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="font-semibold text-sm text-slate-100 uppercase tracking-wider font-mono">
            Visual Controls
          </h2>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={onResetSettings}
            className="p-1 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-white/10 transition-colors"
            title="Reset to Defaults"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={onToggle}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Collapse Panel"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Settings List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 mb-scrollbar">
        {/* 0. Graphics Quality Preset Selector */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              Graphics Preset
            </span>
            <span className="font-mono text-cyan-400 text-[11px] bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40 uppercase">
              {graphicsQuality}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
            {['high', 'balanced', 'low'].map((q) => (
              <button
                key={q}
                onClick={() => onQualityChange && onQualityChange(q)}
                className={`py-1.5 px-2 rounded-lg font-mono text-[10px] uppercase font-bold transition-all ${
                  graphicsQuality === q
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* 1. Particle Density / Detail */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Density / Detail
            </span>
            <span className="font-mono text-cyan-400 text-[11px] bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">
              {Math.round(settings.density * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={settings.density}
            onChange={(e) => onUpdateSettings({ density: parseFloat(e.target.value) })}
            className="mb-slider"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>Low (10%)</span>
            <span>Ultra (100%)</span>
          </div>
        </div>

        {/* 2. Flow / Animation Speed */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-purple-400" />
              Flow Speed
            </span>
            <span className="font-mono text-purple-400 text-[11px] bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/40">
              {settings.speed.toFixed(2)}x
            </span>
          </div>
          <input
            type="range"
            min="0.2"
            max="3.0"
            step="0.1"
            value={settings.speed}
            onChange={(e) => onUpdateSettings({ speed: parseFloat(e.target.value) })}
            className="mb-slider mb-slider-purple"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>0.2x Calm</span>
            <span>3.0x Hyper</span>
          </div>
        </div>

        {/* 3. Color & Glow Intensity */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              Glow Intensity
            </span>
            <span className="font-mono text-cyan-400 text-[11px] bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">
              {settings.colorIntensity.toFixed(2)}x
            </span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.5"
            step="0.1"
            value={settings.colorIntensity}
            onChange={(e) => onUpdateSettings({ colorIntensity: parseFloat(e.target.value) })}
            className="mb-slider"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>Subtle</span>
            <span>Supernova</span>
          </div>
        </div>

        {/* 4. Audio Reactivity Sensitivity */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              Audio Sensitivity
            </span>
            <span className="font-mono text-purple-400 text-[11px] bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/40">
              {settings.sensitivity.toFixed(2)}x
            </span>
          </div>
          <input
            type="range"
            min="0.2"
            max="2.5"
            step="0.1"
            value={settings.sensitivity}
            onChange={(e) => onUpdateSettings({ sensitivity: parseFloat(e.target.value) })}
            className="mb-slider mb-slider-purple"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>0.2x Gentle</span>
            <span>2.5x Explosive</span>
          </div>
        </div>

        {/* 5. Camera FOV / Depth */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              Camera FOV
            </span>
            <span className="font-mono text-cyan-400 text-[11px] bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">
              {settings.cameraFov}°
            </span>
          </div>
          <input
            type="range"
            min="45"
            max="90"
            step="1"
            value={settings.cameraFov}
            onChange={(e) => onUpdateSettings({ cameraFov: parseInt(e.target.value) })}
            className="mb-slider"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>45° Narrow</span>
            <span>90° Fisheye</span>
          </div>
        </div>

        {/* Gesture Dynamics Toggle & Live Telemetry Card */}
        <div className="pt-2 border-t border-white/10 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
              <Video className="w-4 h-4 text-cyan-400" />
              Gesture Dynamics
            </span>
            <button
              onClick={onToggleGesture}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold border transition-all ${
                gestureEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                  : 'bg-white/5 text-slate-400 border-white/10'
              }`}
            >
              {gestureEnabled ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-black/60 border border-cyan-500/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                <span>Hand Tracking Live</span>
              </span>
              <span
                className={`text-[9px] font-mono px-2 py-0.5 rounded-full border ${
                  cameraStatus === 'active'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-white/5 text-slate-400 border-white/10'
                }`}
              >
                {cameraStatus === 'active' ? 'WEBCAM ACTIVE' : 'MOUSE FALLBACK'}
              </span>
            </div>

            {cameraStatus === 'active' && trackingTelemetry.hands && trackingTelemetry.hands.length > 0 ? (
              <div className="space-y-2">
                {trackingTelemetry.hands.map((h, i) => (
                  <div key={h.id || i} className="bg-white/5 p-2 rounded-lg border border-white/5 text-[10px] font-mono space-y-0.5">
                    <div className="flex justify-between items-center">
                      <span className={i === 0 ? 'text-cyan-400 font-semibold' : 'text-purple-300 font-semibold'}>
                        {h.handedness} Hand
                      </span>
                      <span className="text-slate-400">{Math.round((h.score || 0.95) * 100)}% Conf</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>3D Pos:</span>
                      <span>{h.position.x.toFixed(2)}, {h.position.y.toFixed(2)}, {(h.position.z || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Pinch:</span>
                      <span className={h.isPinching ? 'text-amber-300 font-bold' : 'text-slate-400'}>
                        {h.isPinching ? 'ACTIVE (ATTRACT)' : 'OPEN (SWIRL)'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                  <span className="text-slate-500 block">Cursor X</span>
                  <span className="text-cyan-400 font-semibold">{mousePos.x.toFixed(3)}</span>
                </div>
                <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                  <span className="text-slate-500 block">Cursor Y</span>
                  <span className="text-cyan-400 font-semibold">{mousePos.y.toFixed(3)}</span>
                </div>
              </div>
            )}

            <div className="text-[10px] font-mono text-slate-500 flex items-center justify-between pt-1 border-t border-white/5">
              <span>Model: Tasks-Vision</span>
              <span className="text-cyan-400">21 3D Landmarks</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
