import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { History, Calendar, Flame, Zap, ChevronRight, FileText } from 'lucide-react';
import { Header } from '../components/common/Header';
import { Card } from '../components/common/Card';
import { StatusBadge } from '../components/common/StatusBadge';
import { EmptyState } from '../components/common/EmptyState';
import { useEV } from '../context/EVContext';

export const ChargingHistoryScreen = () => {
  const navigate = useNavigate();
  const { history } = useEV();

  const [activeFilter, setActiveFilter] = useState('All'); // 'All', 'Completed', 'Cancelled', 'This Month'

  const filters = ['All', 'Completed', 'Cancelled', 'This Month'];

  const filteredHistory = history.filter((item) => {
    if (activeFilter === 'Completed') return item.status === 'Completed';
    if (activeFilter === 'Cancelled') return item.status === 'Cancelled';
    if (activeFilter === 'This Month') return item.date.includes('Sep 2026');
    return true;
  });

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header title="Charging History" showBack onBack={() => navigate('/home')} />

      <div className="px-4 py-3 space-y-4">
        {/* Total Summary Strip */}
        <div className="grid grid-cols-2 gap-2.5 p-3.5 rounded-2xl bg-[#0D1527] border border-white/5">
          <div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
              Total Sessions
            </span>
            <span className="text-xl font-bold font-mono text-white mt-0.5 block">
              {history.length} Completed
            </span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
              Total Energy
            </span>
            <span className="text-xl font-bold font-mono text-[#00F5A0] mt-0.5 block">
              {history
                .reduce((acc, h) => acc + (h.energyKwh || 0), 0)
                .toFixed(1)}{' '}
              <span className="text-xs font-normal text-slate-400">kWh</span>
            </span>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {filters.map((f) => {
            const isActive = activeFilter === f;
            return (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`
                  px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition-all duration-200 shrink-0
                  ${
                    isActive
                      ? 'bg-[#00F5A0] text-[#050811] border-[#00F5A0] shadow-[0_0_10px_rgba(0,245,160,0.3)]'
                      : 'bg-[#0D1527] text-slate-300 border-white/10 hover:border-white/20'
                  }
                `}
              >
                {f}
              </button>
            );
          })}
        </div>

        {/* History Cards List */}
        <div className="space-y-3">
          {filteredHistory.length > 0 ? (
            filteredHistory.map((item) => (
              <Card
                key={item.id}
                hoverable
                onClick={() => navigate('/bill')}
                className="p-4"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-0.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{item.date}</span>
                      {item.time && <span>• {item.time}</span>}
                    </div>
                    <h3 className="font-bold text-sm text-white">
                      {item.stationName}
                    </h3>
                  </div>
                  <StatusBadge status={item.status} size="sm" />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                  <div className="flex items-center gap-4">
                    {item.energyKwh > 0 && (
                      <span className="text-slate-300 flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 text-[#00F5A0]" />
                        <strong className="font-mono">{item.energyKwh} kWh</strong>
                      </span>
                    )}
                    <span className="text-slate-400">{item.duration}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white font-mono">
                      ₹{item.amount}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <EmptyState
              icon={History}
              title={`No ${activeFilter} Sessions`}
              description="No charging history found matching the selected filter criteria."
              actionLabel="View All"
              onAction={() => setActiveFilter('All')}
            />
          )}
        </div>
      </div>
    </div>
  );
};
