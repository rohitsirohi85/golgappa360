import React, { useState } from 'react';
import StarVisual from './StarVisual';

/**
 * StarCard — Premium observatory star dossier card
 * Prioritized visual hierarchy:
 * 1. Star Name
 * 2. Star Type (+ Sirius System indicator)
 * 3. Constellation
 * 4. Distance
 * 5. Temperature
 * 6. Description (consistent 2-3 line clamped height)
 * 7. Explore button
 */
export default function StarCard({ star, onExplore }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative flex flex-col justify-between h-full rounded-2xl glass-surface p-5 sm:p-6 transition-all duration-300 ease-out hover:-translate-y-1 select-none overflow-hidden border border-white/8 hover:border-white/20 bg-white/[0.025] hover:bg-white/[0.04]"
      style={{
        boxShadow: isHovered
          ? '0 12px 30px -10px rgba(0, 0, 0, 0.8)'
          : '0 4px 16px -8px rgba(0, 0, 0, 0.5)',
      }}
    >
      {/* Background Spectral Tint Gradient on Hover */}
      <div
        aria-hidden="true"
        className="absolute top-0 right-0 w-44 h-44 rounded-full blur-3xl opacity-0 transition-opacity duration-500 pointer-events-none group-hover:opacity-10"
        style={{ backgroundColor: star.colorHex }}
      />

      {/* Top Visual Area */}
      <div className="relative w-full h-40 sm:h-44 flex items-center justify-center mb-5 rounded-xl bg-black/40 border border-white/[0.04]">
        {/* Subtle Astronomical Orbit Guides */}
        <div
          aria-hidden="true"
          className="absolute w-32 h-32 sm:w-36 sm:h-36 rounded-full border border-white/5 border-dashed pointer-events-none"
        />

        {/* Animated Star Rendering */}
        <StarVisual star={star} size="md" isHovered={isHovered} />

        {/* Top Right Constellation Badge */}
        <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-white/[0.03] border border-white/10 text-[10px] font-mono text-slate-300 tracking-wider">
          {star.constellation}
        </div>

        {/* Top Left Magnitude */}
        <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/[0.03] border border-white/10 text-[10px] font-mono text-slate-400">
          MAG {star.magnitude}
        </div>
      </div>

      {/* Star Identity & Type Hierarchy */}
      <div className="flex-1 flex flex-col">
        {/* 1. Star Name */}
        <div className="flex items-baseline justify-between gap-2 mb-2">
          <h3 className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-white group-hover:text-cyan-200 transition-colors duration-200">
            {star.name}
          </h3>
          <span className="text-xs font-mono text-slate-400 tracking-wider">
            {star.spectralClass}
          </span>
        </div>

        {/* 2. Star Type & System Badge */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-widest bg-cyan-500/10 text-cyan-300 border border-cyan-500/25">
            {star.type}
          </span>

          {/* Sirius System Clarity Indicator */}
          {star.systemName === 'Sirius System' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono tracking-wider bg-amber-500/15 text-amber-300 border border-amber-500/35">
              <span>✦</span>
              <span>SIRIUS SYSTEM</span>
            </span>
          )}

          {star.commonName && (
            <span className="text-xs text-slate-400 italic truncate max-w-[170px]">
              {star.commonName}
            </span>
          )}
        </div>

        {/* 3. Constellation & System Relationship */}
        {star.systemRelationship && star.systemName === 'Sirius System' && (
          <div className="text-[11px] font-mono text-amber-200/80 mb-3 px-2 py-1 rounded bg-amber-500/10 border border-amber-500/20">
            {star.systemRelationship}
          </div>
        )}

        {/* 4 & 5. Distance and Temperature Telemetry Grid */}
        <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-black/30 border border-white/5 mb-4 text-xs font-mono">
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">
              DISTANCE
            </div>
            <div className="text-slate-200 font-medium truncate">
              {star.distance}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">
              TEMPERATURE
            </div>
            <div className="text-slate-200 font-medium">
              {star.temperature}
            </div>
          </div>
        </div>

        {/* 6. Short Narrative Description (Normalized Height with Line Clamp) */}
        <p className="text-xs sm:text-sm text-slate-300/80 leading-relaxed line-clamp-2 sm:line-clamp-3 mb-5 min-h-[2.75rem] flex-grow">
          {star.description}
        </p>
      </div>

      {/* 7. Action Footer: Explore Star → (Pinned to Card Bottom) */}
      <button
        type="button"
        onClick={() => onExplore(star)}
        className="mt-auto relative w-full py-2.5 px-4 rounded-xl flex items-center justify-between font-mono text-xs tracking-wider transition-all duration-300 group-hover:bg-cyan-500/15 group-hover:border-cyan-400/40 group-hover:text-cyan-300 bg-white/[0.04] border border-white/10 text-slate-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
      >
        <span>Explore Star</span>
        <span className="transform transition-transform duration-300 group-hover:translate-x-1 text-cyan-400">
          →
        </span>
      </button>
    </div>
  );
}
