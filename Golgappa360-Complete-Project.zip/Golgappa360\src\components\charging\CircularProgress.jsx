import React from 'react';
import { Zap } from 'lucide-react';

export const CircularProgress = ({
  percentage = 78,
  targetPercentage = 80,
  power = 2.23,
  isCharging = true,
  size = 220,
  strokeWidth = 14,
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progressOffset = circumference - (percentage / 100) * circumference;
  const targetOffset = circumference - (targetPercentage / 100) * circumference;

  return (
    <div className="relative flex flex-col items-center justify-center my-2 select-none">
      {/* Outer ambient glow */}
      {isCharging && (
        <div
          className="absolute rounded-full bg-[#00F5A0]/10 blur-2xl pointer-events-none"
          style={{ width: size * 0.9, height: size * 0.9 }}
        />
      )}

      <svg width={size} height={size} className="transform -rotate-90">
        <defs>
          <linearGradient id="chargingGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="60%" stopColor="#00F5A0" />
            <stop offset="100%" stopColor="#10B981" />
          </linearGradient>

          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Outer subtle ticks circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius + 4}
          stroke="rgba(255, 255, 255, 0.05)"
          strokeWidth="1"
          strokeDasharray="3 6"
          fill="none"
        />

        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#0D172B"
          strokeWidth={strokeWidth}
          fill="transparent"
        />

        {/* Target limit indicator marker */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255, 255, 255, 0.25)"
          strokeWidth={strokeWidth}
          strokeDasharray="2 1000"
          strokeDashoffset={targetOffset}
          strokeLinecap="round"
          fill="transparent"
        />

        {/* Active Charging Progress Arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="url(#chargingGradient)"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={progressOffset}
          strokeLinecap="round"
          fill="transparent"
          filter="url(#glow)"
          className="transition-all duration-500 ease-out"
        />
      </svg>

      {/* Center Readout */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        {isCharging ? (
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#00F5A0]/15 border border-[#00F5A0]/30 text-[#00F5A0] text-[11px] font-bold tracking-wider uppercase mb-1">
            <Zap className="w-3 h-3 fill-[#00F5A0] animate-pulse" />
            <span>Fast Charging</span>
          </div>
        ) : (
          <span className="text-[11px] text-slate-400 font-medium tracking-wide uppercase mb-1">
            Standby
          </span>
        )}

        <div className="flex items-baseline">
          <span className="text-5xl font-extrabold tracking-tight text-white font-mono drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
            {percentage}
          </span>
          <span className="text-2xl font-bold text-[#00F5A0] ml-1">%</span>
        </div>

        <div className="text-xs font-semibold text-slate-400 mt-1 flex items-center gap-1.5">
          <span className="text-[#00E5FF] font-mono">{power} kW</span>
          <span className="text-slate-600">•</span>
          <span>Target {targetPercentage}%</span>
        </div>
      </div>
    </div>
  );
};
