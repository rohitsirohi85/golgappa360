import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, MessageCircle, ArrowUpRight } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';

export const Navbar = ({ onOpenTrial }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile drawer on route change or escape
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileMenuOpen]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const whatsAppUrl = `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
    siteConfig.contact.whatsAppDefaultMessage
  )}`;

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0B0B0F]/92 backdrop-blur-md border-b border-white/[0.08] py-3.5'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between">
          
          {/* Brand Wordmark */}
          <Link
            to="/"
            className="group flex flex-col focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded-sm py-1"
            aria-label={`${siteConfig.academy.name} Homepage`}
          >
            <span className="font-display font-bold tracking-tight text-lg sm:text-xl uppercase text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors leading-none">
              MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
            </span>
            <span className="font-mono text-[9px] tracking-widest uppercase text-[#A5A1B2] mt-0.5 opacity-80">
              URBAN DANCE ACADEMY
            </span>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7" aria-label="Main Navigation">
            {siteConfig.navigation.links.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-xs font-sans tracking-wide uppercase font-semibold transition-all duration-200 py-1 relative group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded ${
                    isActive
                      ? 'text-white'
                      : 'text-[#A5A1B2] hover:text-[#F5F3F8]'
                  }`}
                >
                  {link.label}
                  <span
                    className={`absolute bottom-0 left-0 h-[2px] bg-[#8B5CF6] transition-all duration-200 ${
                      isActive ? 'w-full' : 'w-0 group-hover:w-full'
                    }`}
                  />
                </Link>
              );
            })}
          </nav>

          {/* Desktop Contact Actions (Call Now + WhatsApp + Trial) */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Direct Call Link */}
            <a
              href={`tel:${siteConfig.contact.telNumber}`}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-mono font-medium text-[#A5A1B2] hover:text-white bg-[#15151C] hover:bg-[#1B1B26] border border-white/[0.08] rounded-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              title={`Call Academy: ${siteConfig.contact.displayPhone}`}
            >
              <Phone className="w-3.5 h-3.5 text-[#8B5CF6]" />
              <span>CALL NOW</span>
            </a>

            {/* Direct WhatsApp Link */}
            <a
              href={whatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-mono font-medium text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 rounded-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              title="Chat with Studio on WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>WHATSAPP</span>
            </a>

            {/* Book Trial CTA */}
            {onOpenTrial && (
              <button
                onClick={onOpenTrial}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all duration-200 rounded-sm shadow-[0_0_15px_-3px_rgba(139,92,246,0.5)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              >
                <span>TRIAL PASS</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Mobile Right Bar: Call button + Hamburger Menu */}
          <div className="flex items-center gap-2 lg:hidden">
            <a
              href={`tel:${siteConfig.contact.telNumber}`}
              className="p-2 text-[#A5A1B2] hover:text-white bg-[#15151C] border border-white/[0.08] rounded-sm"
              aria-label="Call studio phone"
            >
              <Phone className="w-4 h-4 text-[#8B5CF6]" />
            </a>

            <a
              href={whatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-sm"
              aria-label="WhatsApp studio"
            >
              <MessageCircle className="w-4 h-4" />
            </a>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#F5F3F8] hover:text-[#A78BFA] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </header>

      {/* Accessible Fullscreen Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation"
          className="fixed inset-0 z-50 lg:hidden flex flex-col bg-[#0B0B0F]/98 backdrop-blur-xl animate-fade-in"
        >
          {/* Top Bar */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/[0.08]">
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="font-display font-bold text-lg uppercase text-[#F5F3F8]"
            >
              MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
            </Link>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 text-[#A5A1B2] hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              aria-label="Close menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Links Body */}
          <div className="flex-1 overflow-y-auto px-6 py-8 flex flex-col justify-between">
            <nav className="flex flex-col gap-5" aria-label="Mobile Menu Links">
              {siteConfig.navigation.links.map((link, idx) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`group flex items-center justify-between text-2xl font-display font-bold transition-colors py-1 ${
                      isActive ? 'text-[#8B5CF6]' : 'text-[#F5F3F8] hover:text-[#A78BFA]'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span className="font-mono text-xs text-[#8B5CF6] opacity-75">
                        0{idx + 1}
                      </span>
                      {link.label}
                    </span>
                    <ArrowUpRight className="w-5 h-5 text-[#8B5CF6] opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                );
              })}
            </nav>

            {/* Mobile Bottom Contact Bar */}
            <div className="pt-8 mt-6 border-t border-white/[0.08] flex flex-col gap-3">
              <div className="grid grid-cols-2 gap-3">
                <a
                  href={`tel:${siteConfig.contact.telNumber}`}
                  className="flex items-center justify-center gap-2 py-3 px-4 text-xs font-mono font-medium text-white bg-[#15151C] border border-white/[0.1] rounded-sm"
                >
                  <Phone className="w-4 h-4 text-[#8B5CF6]" />
                  <span>CALL NOW</span>
                </a>
                <a
                  href={whatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-3 px-4 text-xs font-mono font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WHATSAPP</span>
                </a>
              </div>

              {onOpenTrial && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenTrial();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.6)]"
                >
                  <span>RESERVE TRIAL PASS</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              )}

              <div className="flex items-center justify-between text-xs text-[#A5A1B2] font-mono pt-3">
                <span>{siteConfig.contact.displayPhone}</span>
                <span>METROPOLIS, NY</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;
