import React from 'react';

export const Input = ({
  label,
  type = 'text',
  placeholder,
  value,
  onChange,
  error,
  icon: Icon,
  rightElement,
  helperText,
  disabled = false,
  className = '',
  required = false,
  ...props
}) => {
  return (
    <div className={`flex flex-col gap-1.5 w-full ${className}`}>
      {label && (
        <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
          <span>
            {label}
            {required && <span className="text-[#00F5A0] ml-1">*</span>}
          </span>
        </label>
      )}

      <div className="relative flex items-center">
        {Icon && (
          <div className="absolute left-3.5 text-slate-400 pointer-events-none flex items-center">
            <Icon className="w-4 h-4" />
          </div>
        )}

        <input
          type={type}
          value={value}
          onChange={onChange}
          disabled={disabled}
          placeholder={placeholder}
          className={`
            w-full rounded-xl bg-[#0D1527] text-white text-sm
            border transition-all duration-200 outline-none
            placeholder:text-slate-500
            ${Icon ? 'pl-10' : 'pl-3.5'}
            ${rightElement ? 'pr-11' : 'pr-3.5'}
            py-2.5
            ${
              error
                ? 'border-red-500/80 focus:border-red-500 focus:ring-1 focus:ring-red-500/30'
                : 'border-white/10 hover:border-white/20 focus:border-[#00F5A0] focus:ring-2 focus:ring-[#00F5A0]/20'
            }
            ${disabled ? 'opacity-50 cursor-not-allowed bg-slate-900/50' : ''}
          `}
          {...props}
        />

        {rightElement && (
          <div className="absolute right-3 flex items-center">
            {rightElement}
          </div>
        )}
      </div>

      {(error || helperText) && (
        <p className={`text-xs ${error ? 'text-red-400 font-medium' : 'text-slate-400'}`}>
          {error || helperText}
        </p>
      )}
    </div>
  );
};
