import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const range = req.query.range || '180d';
    const menuData = syntheticStore.getMenuData(range);

    res.json({
      success: true,
      data: menuData
    });
  } catch (error) {
    console.error('[API /api/menu Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
