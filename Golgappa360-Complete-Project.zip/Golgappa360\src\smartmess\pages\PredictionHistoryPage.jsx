import React, { useState, useEffect, useCallback } from 'react';
import {
  History,
  Search,
  RotateCcw,
  Trash2,
  RefreshCw,
  Eye,
  X,
} from 'lucide-react';
import { useMess } from '../context/MessContext';
import { messApi } from '../services/messApiService';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { EmptyState } from '../components/common/EmptyState';
import { ErrorState } from '../components/common/ErrorState';

export const PredictionHistoryPage = () => {
  const { navigateTo } = useMess();

  const [historyData, setHistoryData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Pagination
  const [page, setPage] = useState(1);
  const [pageSize] = useState(15);
  const [mealFilter, setMealFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Selected item for detail inspection
  const [inspectItem, setInspectItem] = useState(null);
  // Deleting item ID
  const [deletingId, setDeletingId] = useState(null);
  const [actionNotice, setActionNotice] = useState(null);

  const fetchHistory = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const params = {
        page,
        page_size: pageSize,
      };
      if (mealFilter !== 'All') {
        params.meal_type = mealFilter.toLowerCase();
      }
      if (riskFilter === 'HighRisk') {
        params.high_risk_only = true;
      }

      const res = await messApi.getPredictionHistory(params);
      setHistoryData(res);
    } catch (err) {
      console.error('Failed to load prediction history:', err);
      setError(err.message || 'Unable to retrieve prediction logs from backend.');
    } finally {
      setIsLoading(false);
    }
  }, [page, pageSize, mealFilter, riskFilter]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const handleDelete = async (predictionId) => {
    if (!window.confirm(`Delete prediction record '${predictionId}' from SQLite database?`)) {
      return;
    }
    setDeletingId(predictionId);
    try {
      await messApi.deletePrediction(predictionId);
      setActionNotice({ type: 'success', text: `Prediction '${predictionId}' deleted successfully.` });
      setTimeout(() => setActionNotice(null), 3500);
      fetchHistory();
    } catch (err) {
      console.error('Failed to delete prediction:', err);
      setActionNotice({ type: 'error', text: `Delete failed: ${err.message}` });
    } finally {
      setDeletingId(null);
    }
  };

  const records = historyData?.predictions || [];
  const totalRecords = historyData?.total_records || 0;
  const totalPages = historyData?.total_pages || 1;

  // Local client-side search across returned records
  const filteredRecords = records.filter((item) => {
    if (!searchTerm.trim()) return true;
    const s = searchTerm.toLowerCase();
    return (
      item.prediction_id.toLowerCase().includes(s) ||
      item.meal_type.toLowerCase().includes(s) ||
      (item.notes && item.notes.toLowerCase().includes(s)) ||
      (item.menu_category && item.menu_category.toLowerCase().includes(s))
    );
  });

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-[#16865B]" />
            Prediction Audit Trail & SQLite History
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              Live SQLite Database
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            Historical logs tracking persistent machine learning inference runs and batch recommendations.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={fetchHistory}
            disabled={isLoading}
            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#16865B] bg-white transition-colors border border-[#E4EAE5] cursor-pointer shadow-xs"
            title="Refresh history"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#16865B]' : ''}`} />
          </button>
          <div className="text-xs font-mono text-[#25332D] bg-white border border-[#E4EAE5] px-3 py-1.5 rounded-lg shadow-xs">
            Total Logged Runs: <span className="text-[#16865B] font-semibold">{totalRecords}</span>
          </div>
        </div>
      </div>

      {/* Action Notification Toast */}
      {actionNotice && (
        <div
          className={`p-3 rounded-lg text-xs flex items-center justify-between transition-all shadow-xs ${
            actionNotice.type === 'success'
              ? 'bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]'
              : 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]'
          }`}
        >
          <span>{actionNotice.text}</span>
          <button onClick={() => setActionNotice(null)} className="text-[#77847C] hover:text-[#25332D] cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-4 space-y-3 shadow-xs">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#77847C]" />
            <input
              type="text"
              placeholder="Search by Run ID (e.g. PRED-...), meal slot, or notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#25332D] placeholder-[#77847C] focus:outline-none focus:border-[#16865B] focus:bg-white"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Meal Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Meal:</span>
              <select
                value={mealFilter}
                onChange={(e) => {
                  setMealFilter(e.target.value);
                  setPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Meals</option>
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
              </select>
            </div>

            {/* Risk Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Risk:</span>
              <select
                value={riskFilter}
                onChange={(e) => {
                  setRiskFilter(e.target.value);
                  setPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Records</option>
                <option value="HighRisk">High Waste Risk (≥87.7 kg)</option>
              </select>
            </div>

            {(searchTerm || mealFilter !== 'All' || riskFilter !== 'All') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setMealFilter('All');
                  setRiskFilter('All');
                  setPage(1);
                }}
                className="p-2 rounded-lg bg-[#E4EAE5] text-[#77847C] hover:text-[#25332D] cursor-pointer"
                title="Reset filters"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content States */}
      {isLoading && !historyData ? (
        <LoadingSkeleton type="table" />
      ) : error && !historyData ? (
        <div className="py-8">
          <ErrorState
            title="Unable to load Prediction History"
            message={error}
            onRetry={fetchHistory}
          />
        </div>
      ) : filteredRecords.length === 0 ? (
        <div className="py-12">
          <EmptyState
            title="No Prediction Records Found"
            description={
              totalRecords === 0
                ? "No predictions have been logged to the SQLite database yet. Run the Simulator to generate your first ML prediction."
                : "No prediction records match your current search and filter criteria."
            }
            actionLabel="Run Prediction Simulator"
            onAction={() => navigateTo('predict')}
          />
        </div>
      ) : (
        /* History Log Table */
        <div className="rounded-xl bg-white border border-[#E4EAE5] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#E4EAE5] bg-[#F8FAF8] text-[#77847C] uppercase text-[10px] font-semibold tracking-wider">
                  <th className="py-3 px-4">Prediction ID</th>
                  <th className="py-3 px-4">Meal & Service</th>
                  <th className="py-3 px-4 text-right">Headcount</th>
                  <th className="py-3 px-4 text-right">Prepared (kg)</th>
                  <th className="py-3 px-4 text-right">Predicted Waste</th>
                  <th className="py-3 px-4 text-right">Recommended Batch</th>
                  <th className="py-3 px-4 text-center">Risk Level</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF2EF] font-mono text-[#25332D]">
                {filteredRecords.map((item) => {
                  const isHighRisk = Boolean(item.high_waste_risk);
                  return (
                    <tr key={item.prediction_id} className="hover:bg-[#F8FAF8] transition-colors">
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="text-[#16865B] font-semibold">{item.prediction_id.slice(0, 14)}...</span>
                        <div className="text-[10px] text-[#77847C] font-normal">
                          {new Date(item.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-sans whitespace-nowrap">
                        <span className="font-semibold text-[#25332D] capitalize">{item.meal_type}</span>
                        <span className="text-[#77847C] text-xs ml-1.5 font-normal">({item.weekday})</span>
                        <div className="text-[10px] text-[#77847C] font-mono">
                          {item.menu_category} • {item.weather_condition}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-[#25332D] whitespace-nowrap font-medium">
                        {item.expected_attendance}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-[#25332D] whitespace-nowrap">
                        {item.food_prepared_kg} kg
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono whitespace-nowrap">
                        <span className="text-[#B91C1C] font-bold">{item.predicted_waste_kg} kg</span>
                        <div className="text-[10px] text-[#D97706] font-medium">{item.predicted_waste_pct}%</div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-[#16865B] font-semibold whitespace-nowrap">
                        {item.recommended_batch_kg} kg
                        {item.potential_saving_kg > 0 && (
                          <div className="text-[10px] text-[#77847C]">
                            - {item.potential_saving_kg} kg
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center whitespace-nowrap font-sans">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono border font-semibold ${
                            isHighRisk
                              ? 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]'
                              : 'bg-[#E9F6EE] text-[#16865B] border-[#C5E5D0]'
                          }`}
                        >
                          {isHighRisk ? 'High Risk' : 'Normal'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setInspectItem(item)}
                            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#16865B] hover:bg-[#E9F6EE] transition-colors cursor-pointer"
                            title="Inspect details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(item.prediction_id)}
                            disabled={deletingId === item.prediction_id}
                            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#DC2626] hover:bg-[#FEF2F2] transition-colors cursor-pointer"
                            title="Delete prediction from SQLite"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Footer with Pagination */}
          <div className="p-3 bg-[#F8FAF8] border-t border-[#E4EAE5] flex flex-col sm:flex-row items-center justify-between text-xs px-5 text-[#77847C] gap-2">
            <span>
              Showing Page {page} of {totalPages} ({totalRecords} records stored in SQLite)
            </span>

            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1 rounded bg-white border border-[#E4EAE5] text-[#25332D] hover:bg-[#F8FAF8] disabled:opacity-40 cursor-pointer shadow-2xs font-medium"
              >
                Previous
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="px-2.5 py-1 rounded bg-white border border-[#E4EAE5] text-[#25332D] hover:bg-[#F8FAF8] disabled:opacity-40 cursor-pointer shadow-2xs font-medium"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Record Inspection Modal */}
      {inspectItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#25332D]/40 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white border border-[#E4EAE5] p-6 text-[#25332D] shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
              <div>
                <h3 className="text-base font-bold text-[#25332D] flex items-center gap-2">
                  Prediction Audit Record
                </h3>
                <span className="text-xs font-mono text-[#16865B] font-semibold">
                  {inspectItem.prediction_id}
                </span>
              </div>
              <button
                onClick={() => setInspectItem(null)}
                className="p-1 rounded-lg text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs mt-4">
              <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
                <div>
                  <span className="text-[#77847C] uppercase text-[10px] block">Service Slot:</span>
                  <span className="text-[#25332D] font-semibold capitalize">{inspectItem.meal_type} ({inspectItem.weekday})</span>
                </div>
                <div>
                  <span className="text-[#77847C] uppercase text-[10px] block">Created Timestamp:</span>
                  <span className="font-mono text-[#25332D] text-[11px]">{inspectItem.created_at}</span>
                </div>
                <div>
                  <span className="text-[#77847C] uppercase text-[10px] block">Menu & Weather:</span>
                  <span className="text-[#25332D] font-mono">{inspectItem.menu_category} • {inspectItem.weather_condition}</span>
                </div>
                <div>
                  <span className="text-[#77847C] uppercase text-[10px] block">Model Serving Version:</span>
                  <span className="text-[#16865B] font-mono font-semibold">{inspectItem.model_version || 'v1.0.0-phase3'}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-center">
                  <span className="text-[10px] text-[#77847C] block">Attendance</span>
                  <span className="text-sm font-bold text-[#25332D] font-mono">{inspectItem.expected_attendance}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-center">
                  <span className="text-[10px] text-[#77847C] block">Food Prepared</span>
                  <span className="text-sm font-bold text-[#25332D] font-mono">{inspectItem.food_prepared_kg} kg</span>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-center">
                  <span className="text-[10px] text-[#77847C] block">Predicted Waste</span>
                  <span className="text-sm font-bold text-[#B91C1C] font-mono">{inspectItem.predicted_waste_kg} kg</span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="text-[10px] text-[#77847C] font-semibold uppercase">Actionable Guidance:</span>
                <p className="text-[#25332D] leading-relaxed">{inspectItem.actionable_guidance}</p>
              </div>

              {inspectItem.notes && (
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-[11px] text-[#55635C]">
                  <span className="font-semibold text-[#25332D]">Staff Notes: </span>
                  {inspectItem.notes}
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-[#EEF2EF] flex justify-end gap-2">
              <button
                onClick={() => setInspectItem(null)}
                className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-[#16865B] text-white hover:bg-[#126E4A] transition-colors cursor-pointer shadow-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
