import React from 'react';

/**
 * StarStats — Observatory telemetry strip displaying catalog metrics
 * 12 STARS CATALOGED, 5 STAR TYPES, 11 CONSTELLATIONS, 6 STELLAR CLASSES
 */
export default function StarStats({
  catalogCount = 12,
  typesCount = 5,
  constellationsCount = 11,
  classesCount = 6,
  className = '',
}) {
  const stats = [
    {
      value: catalogCount,
      label: 'STARS CATALOGED',
      accent: 'text-cyan-400',
      glow: 'shadow-[0_0_15px_rgba(56,189,248,0.3)]',
    },
    {
      value: typesCount,
      label: 'STAR TYPES',
      accent: 'text-amber-400',
      glow: 'shadow-[0_0_15px_rgba(251,191,36,0.3)]',
    },
    {
      value: constellationsCount,
      label: 'CONSTELLATIONS',
      accent: 'text-violet-400',
      glow: 'shadow-[0_0_15px_rgba(139,92,246,0.3)]',
    },
    {
      value: classesCount,
      label: 'STELLAR CLASSES',
      accent: 'text-sky-300',
      glow: 'shadow-[0_0_15px_rgba(56,189,248,0.25)]',
    },
  ];

  return (
    <div
      className={`w-full grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-6 rounded-2xl glass-surface border border-white/10 ${className}`}
    >
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex flex-col items-center justify-center p-3 rounded-xl bg-[#020308]/60 border border-white/8 transition-transform duration-300 hover:scale-[1.02]"
        >
          <div className="flex items-center gap-2 mb-1">
            <span
              className={`font-display text-3xl sm:text-4xl font-semibold tracking-tight ${stat.accent}`}
            >
              {stat.value}
            </span>
          </div>
          <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] text-slate-400 text-center">
            {stat.label}
          </div>
        </div>
      ))}
    </div>
  );
}
