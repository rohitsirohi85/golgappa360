import { api } from './api';
import { DEFAULT_VEHICLE } from '../data/mockVehicles';

export const vehicleService = {
  getVehicles: async () => {
    try {
      const data = await api.get('/vehicles');
      if (Array.isArray(data) && data.length > 0) {
        return data.map((v) => ({
          id: v._id,
          make: v.brand,
          model: v.model,
          licensePlate: v.vehicleNumber,
          batteryCapacity: v.batteryCapacity,
          currentBattery: v.currentBatteryPercentage || 78,
          currentRange: Math.round(((v.currentBatteryPercentage || 78) / 100) * 400),
          connector: v.connectorType,
          health: '98%',
          image: DEFAULT_VEHICLE.image,
        }));
      }
      return [DEFAULT_VEHICLE];
    } catch (err) {
      console.warn('Backend getVehicles fallback:', err.message);
      return [DEFAULT_VEHICLE];
    }
  },

  createVehicle: async (vehicleData) => {
    try {
      const data = await api.post('/vehicles', {
        vehicleNumber: vehicleData.licensePlate || 'KA 01 EV 2026',
        brand: vehicleData.make || vehicleData.brand || 'Tesla',
        model: vehicleData.model || 'Model 3',
        batteryCapacity: Number(vehicleData.batteryCapacity) || 60,
        connectorType: vehicleData.connector || 'CCS2',
        currentBatteryPercentage: vehicleData.currentBattery || 78,
      });
      return {
        id: data._id,
        make: data.brand,
        model: data.model,
        licensePlate: data.vehicleNumber,
        batteryCapacity: data.batteryCapacity,
        currentBattery: data.currentBatteryPercentage,
        connector: data.connectorType,
      };
    } catch (err) {
      return {
        ...DEFAULT_VEHICLE,
        ...vehicleData,
      };
    }
  },

  updateVehicle: async (id, vehicleData) => {
    try {
      if (id && id.match(/^[0-9a-fA-F]{24}$/)) {
        await api.put(`/vehicles/${id}`, {
          brand: vehicleData.make,
          model: vehicleData.model,
          batteryCapacity: Number(vehicleData.batteryCapacity),
          connectorType: vehicleData.connector,
        });
      }
    } catch (err) {
      console.warn('Backend updateVehicle fallback:', err.message);
    }
    return vehicleData;
  },
};
