import React from 'react';
import { LIFETIME_SCALE_DATA } from '../../data/stellarEvolutionPaths';

/**
 * EvolutionTimeline — "NOT ALL STARS LIVE EQUALLY LONG."
 * Visual comparative timeline contrasting lifespans of:
 * - Massive stars (Shorter lives)
 * - Sun-like stars (Billions of years)
 * - Red dwarfs (Extremely long lifetimes)
 */
export default function EvolutionTimeline() {
  return (
    <div className="w-full flex flex-col items-center select-none">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-white/10 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>CHRONOLOGICAL LIFESPAN DIVERSITY</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          NOT ALL STARS LIVE EQUALLY LONG.
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/80 leading-relaxed max-w-xl mx-auto">
          A star's lifespan is inversely proportional to its rate of nuclear fusion. Massive stars exhaust their fuel in a cosmic flash, while tiny red dwarfs live for an eternity.
        </p>
      </div>

      {/* Main Timeline Comparison Container */}
      <div className="w-full p-6 sm:p-8 lg:p-10 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
        {/* Visual Timeline Bars */}
        <div className="space-y-6 sm:space-y-8">
          {LIFETIME_SCALE_DATA.map((item) => (
            <div key={item.name} className="flex flex-col gap-2">
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-sm font-mono">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: item.color, boxShadow: `0 0 10px ${item.color}` }}
                  />
                  <span className="font-display font-semibold text-base sm:text-lg text-white">
                    {item.name}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:inline">
                    (Ex: {item.example})
                  </span>
                </div>
                <div className="font-bold text-base sm:text-lg" style={{ color: item.color }}>
                  {item.duration}
                </div>
              </div>

              {/* Bar Track */}
              <div className="relative h-6 sm:h-7 w-full rounded-xl bg-[#020308]/60 border border-white/8 p-1 overflow-hidden">
                <div
                  className="h-full rounded-lg transition-all duration-1000 ease-out flex items-center justify-end pr-2"
                  style={{
                    width: item.relativeWidth,
                    backgroundColor: item.color,
                    boxShadow: `0 0 20px ${item.glow}`,
                  }}
                >
                  <span className="text-[10px] font-mono text-black font-bold uppercase tracking-wider hidden sm:inline">
                    {item.barLabel}
                  </span>
                </div>
              </div>

              {/* Descriptive Annotation */}
              <p className="font-sans text-xs text-slate-400 px-1 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Small Required Label */}
        <div className="mt-8 pt-5 border-t border-white/10 flex items-center justify-between text-xs font-mono text-slate-400">
          <span className="italic">
            “Approximate lifetimes vary with stellar mass and evolution.”
          </span>
          <span className="hidden sm:inline text-cyan-400">
            ASTROPHYSICAL SCALING
          </span>
        </div>
      </div>
    </div>
  );
}
