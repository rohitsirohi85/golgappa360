import React from 'react';
import { Zap, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Card } from '../common/Card';
import { StatusBadge } from '../common/StatusBadge';
import { Button } from '../common/Button';

export const ChargerCard = ({
  charger,
  isSelected = false,
  onSelect,
  onView,
}) => {
  const isAvailable = charger.status === 'Available';
  const isCharging = charger.status === 'Charging';
  const isFault = charger.status === 'Fault';

  return (
    <Card
      className={`
        relative transition-all duration-200
        ${isSelected ? 'border-[#00F5A0] shadow-[0_0_20px_-3px_rgba(0,245,160,0.3)] bg-[#162544]' : ''}
        ${isFault ? 'opacity-65 border-red-500/20 bg-red-950/10' : ''}
      `}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`p-2.5 rounded-xl border ${
              isAvailable
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : isCharging
                ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                : 'bg-red-500/10 border-red-500/30 text-red-400'
            }`}
          >
            <Zap className="w-4 h-4" />
          </div>

          <div>
            <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
              <span>{charger.name}</span>
              {isSelected && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00F5A0]/20 text-[#00F5A0] font-semibold">
                  Selected
                </span>
              )}
            </h4>
            <span className="text-xs text-slate-400">
              {charger.type} • {charger.connector}
            </span>
          </div>
        </div>

        <StatusBadge status={charger.status} size="sm" />
      </div>

      {/* Spec grid */}
      <div className="grid grid-cols-2 gap-2 text-xs py-2 px-3 rounded-xl bg-[#0D1527] border border-white/5 mb-3">
        <div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
            Power Output
          </span>
          <span className="font-semibold text-white font-mono mt-0.5 block">
            {charger.power}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
            Rate
          </span>
          <span className="font-semibold text-[#00F5A0] font-mono mt-0.5 block">
            ₹{charger.rate}/kWh
          </span>
        </div>
      </div>

      {/* Auxiliary status info */}
      {isCharging && charger.estimatedAvailable && (
        <div className="flex items-center gap-1.5 text-xs text-cyan-300 bg-cyan-500/10 px-3 py-1.5 rounded-lg border border-cyan-500/20 mb-3">
          <Clock className="w-3.5 h-3.5" />
          <span>Estimated available: <strong>{charger.estimatedAvailable}</strong></span>
        </div>
      )}

      {isFault && (
        <div className="flex items-center gap-1.5 text-xs text-rose-400 bg-rose-500/10 px-3 py-1.5 rounded-lg border border-rose-500/20 mb-3">
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>{charger.faultReason || 'Under Maintenance'}</span>
        </div>
      )}

      {isAvailable && charger.estimatedTime && (
        <div className="text-[11px] text-slate-400 mb-3 flex items-center gap-1">
          <Clock className="w-3 h-3 text-slate-500" />
          <span>Est. 20% to 80% in {charger.estimatedTime}</span>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-end gap-2 pt-1 border-t border-white/5">
        {isAvailable && (
          <Button
            size="sm"
            variant={isSelected ? 'primary' : 'outline'}
            onClick={() => onSelect?.(charger)}
            className="w-full"
          >
            {isSelected ? 'Selected' : 'Select'}
          </Button>
        )}

        {isCharging && (
          <Button
            size="sm"
            variant="secondary"
            onClick={() => onView?.(charger)}
            className="w-full"
          >
            View
          </Button>
        )}

        {isFault && (
          <Button size="sm" variant="secondary" disabled className="w-full">
            Under Maintenance
          </Button>
        )}
      </div>
    </Card>
  );
};
