import React, { useState } from 'react';

/**
 * QuizQuestion — Active Question Terminal
 * Displays current question, 4 interactive glass options (A, B, C, D),
 * confirmation button, and animated scientific explanation feedback.
 */
export default function QuizQuestion({
  question,
  currentIndex,
  totalQuestions,
  difficulty,
  onAnswerSubmit,
  onNextQuestion,
}) {
  const [selectedOption, setSelectedOption] = useState(null);
  const [isConfirmed, setIsConfirmed] = useState(false);

  // If question changes, reset local selection and confirmation
  const [prevQuestionId, setPrevQuestionId] = useState(question.id);
  if (question.id !== prevQuestionId) {
    setPrevQuestionId(question.id);
    setSelectedOption(null);
    setIsConfirmed(false);
  }

  const optionLetters = ['A', 'B', 'C', 'D'];
  const progressPercent = ((currentIndex + 1) / totalQuestions) * 100;
  const isLastQuestion = currentIndex === totalQuestions - 1;

  const handleSelect = (option) => {
    if (isConfirmed) return; // Prevent changing after confirmation
    setSelectedOption(option);
  };

  const handleConfirm = () => {
    if (!selectedOption || isConfirmed) return;
    setIsConfirmed(true);
    const isCorrect = selectedOption === question.correctAnswer;
    onAnswerSubmit(isCorrect);
  };

  const isCorrect = isConfirmed && selectedOption === question.correctAnswer;

  return (
    <div className="w-full max-w-3xl mx-auto rounded-3xl glass-surface border border-white/10 p-6 sm:p-10 shadow-[0_25px_60px_rgba(0,0,0,0.7)] text-left relative overflow-hidden">
      {/* Background Soft Galactic Atmosphere */}
      <div
        aria-hidden="true"
        className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-cyan-500/10 blur-[100px] pointer-events-none"
      />

      {/* Top HUD Telemetry Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-mono uppercase tracking-[0.2em] text-cyan-400 font-semibold">
            STELLAR MISSION // {difficulty.toUpperCase()}
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 hidden sm:inline-block">
            {question.category}
          </span>
        </div>

        <span className="text-xs font-mono text-slate-300">
          QUESTION <strong className="text-white">{String(currentIndex + 1).padStart(2, '0')}</strong> / {String(totalQuestions).padStart(2, '0')}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden mb-8">
        <div
          className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 transition-all duration-500 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Question Statement */}
      <div className="mb-8">
        <h3 className="font-display text-2xl sm:text-3xl font-semibold text-white leading-tight">
          {question.question}
        </h3>
      </div>

      {/* 4 Interactive Answer Options */}
      <div className="space-y-3 sm:space-y-3.5 mb-8">
        {question.options.map((option, idx) => {
          const letter = optionLetters[idx];
          const isSelected = selectedOption === option;

          // Styling logic during confirmation feedback
          let optionStyle =
            'border-white/8 bg-[#020308]/60 text-slate-200 hover:border-cyan-400/50 hover:bg-white/5 hover:translate-x-1';

          if (isSelected && !isConfirmed) {
            optionStyle =
              'border-cyan-400 bg-cyan-950/40 text-white shadow-[0_0_20px_rgba(6,182,212,0.3)] translate-x-1';
          } else if (isConfirmed) {
            if (option === question.correctAnswer) {
              optionStyle =
                'border-emerald-500/80 bg-emerald-950/40 text-emerald-100 shadow-[0_0_20px_rgba(16,185,129,0.25)]';
            } else if (isSelected && !isCorrect) {
              optionStyle =
                'border-rose-500/80 bg-rose-950/40 text-rose-200 shadow-[0_0_20px_rgba(244,63,94,0.2)]';
            } else {
              optionStyle = 'border-white/5 bg-[#020308]/40 text-slate-500 opacity-60';
            }
          }

          return (
            <button
              key={idx}
              type="button"
              onClick={() => handleSelect(option)}
              disabled={isConfirmed}
              className={`w-full p-4 sm:p-4.5 rounded-2xl border transition-all duration-300 text-left flex items-center justify-between cursor-pointer text-sm sm:text-base font-normal ${optionStyle} ${
                isConfirmed ? 'cursor-default' : ''
              }`}
            >
              <div className="flex items-center gap-3.5">
                <span
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-mono font-bold transition-colors ${
                    isConfirmed && option === question.correctAnswer
                      ? 'bg-emerald-500 text-slate-950'
                      : isConfirmed && isSelected && !isCorrect
                      ? 'bg-rose-500 text-white'
                      : isSelected
                      ? 'bg-cyan-400 text-slate-950'
                      : 'bg-white/10 text-slate-400'
                  }`}
                >
                  {letter}
                </span>
                <span className="font-medium">{option}</span>
              </div>

              {/* Status Indicator Icon */}
              {isConfirmed && option === question.correctAnswer && (
                <span className="text-emerald-400 font-mono text-sm font-bold flex items-center gap-1">
                  <span>✓</span>
                  <span className="hidden sm:inline text-xs">CORRECT</span>
                </span>
              )}
              {isConfirmed && isSelected && !isCorrect && (
                <span className="text-rose-400 font-mono text-sm font-bold flex items-center gap-1">
                  <span>✕</span>
                  <span className="hidden sm:inline text-xs">YOUR CHOICE</span>
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Confirmation Action Strip (Before Confirmation) */}
      {!isConfirmed && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!selectedOption}
            className={`px-8 py-3.5 rounded-full font-mono text-xs tracking-wider uppercase font-bold transition-all duration-300 flex items-center gap-2 ${
              selectedOption
                ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_25px_rgba(6,182,212,0.4)] hover:scale-105 cursor-pointer'
                : 'bg-white/10 text-slate-500 cursor-not-allowed border border-white/5'
            }`}
          >
            <span>CONFIRM ANSWER</span>
            <span>→</span>
          </button>
        </div>
      )}

      {/* Scientific Explanation Dossier (After Confirmation) */}
      {isConfirmed && (
        <div className="mt-6 pt-6 border-t border-white/10 space-y-4 animate-fade-in">
          {/* Header Feedback Banner */}
          <div className="flex items-center gap-2 text-sm font-mono uppercase tracking-widest font-bold">
            {isCorrect ? (
              <span className="text-emerald-400 flex items-center gap-1.5">
                <span>✓</span>
                <span>CORRECT</span>
              </span>
            ) : (
              <span className="text-rose-400 flex items-center gap-1.5">
                <span>✕</span>
                <span>NOT QUITE</span>
              </span>
            )}
            <span className="text-slate-600">/</span>
            <span className="text-cyan-300">WHY?</span>
          </div>

          {/* Explanation Text */}
          <p className="font-sans text-sm text-slate-200 leading-relaxed font-normal bg-[#020308]/60 p-4 rounded-xl border border-white/8">
            {question.explanation}
          </p>

          {/* Next Question CTA */}
          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={onNextQuestion}
              className="px-8 py-3.5 rounded-full bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-mono text-xs tracking-wider uppercase font-bold transition-all duration-300 shadow-[0_0_25px_rgba(6,182,212,0.4)] hover:scale-105 cursor-pointer flex items-center gap-2"
            >
              <span>{isLastQuestion ? 'VIEW MISSION RESULTS' : 'NEXT QUESTION'}</span>
              <span>→</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
