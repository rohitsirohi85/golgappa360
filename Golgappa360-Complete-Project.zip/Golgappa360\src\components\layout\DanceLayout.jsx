import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { TrialBookingModal } from '../../dance/components/TrialBookingModal';

export const DanceLayout = () => {
  const [trialModalOpen, setTrialModalOpen] = useState(false);
  const [initialProgramId, setInitialProgramId] = useState(null);

  const handleOpenTrial = (progId = null) => {
    setInitialProgramId(progId);
    setTrialModalOpen(true);
  };

  const handleCloseTrial = () => {
    setTrialModalOpen(false);
    setInitialProgramId(null);
  };

  return (
    <div className="min-h-screen bg-[#0B0B0F] text-[#F5F3F8] selection:bg-[#8B5CF6]/30 selection:text-[#F5F3F8] flex flex-col justify-between">
      {/* Shared Navigation */}
      <Navbar onOpenTrial={() => handleOpenTrial()} />

      {/* Page Content Flow via Outlet */}
      <main id="main-content" className="flex-1">
        <Outlet context={{ onOpenTrial: handleOpenTrial }} />
      </main>

      {/* Shared Footer */}
      <Footer onOpenTrial={() => handleOpenTrial()} />

      {/* Global Interactive Trial Pass Modal */}
      <TrialBookingModal
        isOpen={trialModalOpen}
        onClose={handleCloseTrial}
        initialProgramId={initialProgramId}
      />
    </div>
  );
};

export default DanceLayout;
