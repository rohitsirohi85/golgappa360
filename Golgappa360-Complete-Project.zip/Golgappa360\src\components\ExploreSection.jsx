import React from 'react';
import SectionHeading from './SectionHeading';
import Button from './Button';
import { STARS_DATA } from '../data/stars';

/**
 * ExploreSection (Temporary Phase 1 Foundation)
 * Heading: “THE STARS ARE WAITING”
 * Text: “Star exploration begins here.”
 * Button: “Coming in Phase 2 →”
 * Previews upcoming star data architecture in a sleek, non-intrusive observatory format.
 */
export default function ExploreSection() {
  return (
    <section
      id="explore-stars"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Subtle Radial Nebula */}
      <div
        aria-hidden="true"
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-amber-950/15 via-cyan-950/15 to-indigo-950/20 blur-[130px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
          {/* Eyebrow */}
          <SectionHeading
            eyebrow="MODULE IN PREPARATION"
            title="THE STARS ARE WAITING"
            subtitle="Star exploration begins here."
            align="center"
          />

          {/* Coming in Phase 2 CTA */}
          <div className="mt-8 flex flex-col sm:flex-row items-center gap-4">
            <Button
              variant="secondary"
              size="lg"
              className="border-cyan-400/30 text-cyan-300 shadow-[0_0_20px_rgba(56,189,248,0.15)] group cursor-default"
              disabled
            >
              <span>Coming in Phase 2</span>
              <span className="font-mono text-xs text-cyan-400">→</span>
            </Button>
          </div>

          {/* Phase 2 Architecture Preview Cards (Clean, non-interactive teaser of stars.js) */}
          <div className="mt-14 w-full">
            <div className="text-[11px] font-mono uppercase tracking-[0.25em] text-slate-400 mb-6 flex items-center justify-center gap-3">
              <span className="h-[1px] w-12 bg-white/10" />
              <span>CATALOG TARGETS QUEUED FOR PHASE 2 EXPLORER</span>
              <span className="h-[1px] w-12 bg-white/10" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-left">
              {STARS_DATA.slice(0, 4).map((star) => (
                <div
                  key={star.id}
                  className="glass-surface-interactive p-4 sm:p-5 rounded-2xl relative overflow-hidden group"
                >
                  {/* Subtle Spectral Color Accent */}
                  <div
                    aria-hidden="true"
                    className="absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl opacity-20 pointer-events-none transition-opacity duration-300 group-hover:opacity-40"
                    style={{ backgroundColor: star.colorHex }}
                  />

                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono tracking-widest text-slate-400">
                      CLASS {star.spectralType}
                    </span>
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: star.colorHex, boxShadow: `0 0 8px ${star.colorHex}` }}
                    />
                  </div>

                  <h3 className="font-display font-bold text-base sm:text-lg text-white">
                    {star.name}
                  </h3>

                  <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                    {star.constellation}
                  </p>

                  <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-500">
                    <span>{star.distance} ly</span>
                    <span>{star.temperature.toLocaleString()} K</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
