import React, { useState, useEffect, useCallback } from 'react';
import { ArrowUpRight, X, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const GalleryPage = () => {
  const [activePhotoIdx, setActivePhotoIdx] = useState(null);

  const activePhoto =
    activePhotoIdx !== null ? siteConfig.gallery[activePhotoIdx] : null;

  const handleNext = useCallback(() => {
    if (activePhotoIdx !== null) {
      setActivePhotoIdx((prev) => (prev + 1) % siteConfig.gallery.length);
    }
  }, [activePhotoIdx]);

  const handlePrev = useCallback(() => {
    if (activePhotoIdx !== null) {
      setActivePhotoIdx(
        (prev) => (prev - 1 + siteConfig.gallery.length) % siteConfig.gallery.length
      );
    }
  }, [activePhotoIdx]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (activePhotoIdx === null) return;
      if (e.key === 'Escape') {
        setActivePhotoIdx(null);
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activePhotoIdx, handleNext, handlePrev]);

  useEffect(() => {
    if (activePhotoIdx !== null) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [activePhotoIdx]);

  return (
    <>
      <SEO
        title="Movement Archive & Performances"
        description="Visual documentation of daily sweat, kinetic precision, and late-night cypher explorations at MOTION IS ART dance academy."
      />

      <div className="pt-28 sm:pt-36 pb-24 sm:pb-32 bg-[#0B0B0F] text-[#F5F3F8]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          
          {/* Page Editorial Header */}
          <div className="pb-12 border-b border-white/[0.08] max-w-4xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ VISUAL DOCUMENTATION ]
            </span>
            <h1 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase">
              MOVEMENT <br />
              <span className="text-[#A78BFA]">IN STILLNESS.</span>
            </h1>
            <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] leading-relaxed max-w-2xl font-sans">
              A curated photographic record of daily rehearsals, kinetic studies, cyphers, and stagecraft showcases captured in our studios.
            </p>
          </div>

          {/* Curated Editorial Varied-Crop Gallery */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {siteConfig.gallery.map((item, idx) => (
              <div
                key={item.id}
                onClick={() => setActivePhotoIdx(idx)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setActivePhotoIdx(idx);
                  }
                }}
                role="button"
                tabIndex={0}
                aria-label={`View expanded photo: ${item.caption}`}
                className="group relative rounded-sm overflow-hidden bg-[#15151C] border border-white/[0.08] hover:border-[#8B5CF6]/50 cursor-pointer transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] aspect-[4/3] sm:aspect-[4/5]"
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  loading="lazy"
                  className="w-full h-full object-cover filter contrast-[1.1] brightness-[0.9] group-hover:scale-105 group-hover:brightness-100 transition-all duration-500"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity pointer-events-none" />
                <div className="film-grain absolute inset-0 pointer-events-none" />

                <div className="absolute top-4 left-4 z-10 pointer-events-none">
                  <span className="font-mono text-[9px] text-white/80 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded border border-white/10 uppercase tracking-widest">
                    {item.category}
                  </span>
                </div>

                <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity p-2 rounded-sm bg-[#8B5CF6] text-white shadow-lg pointer-events-none">
                  <Maximize2 className="w-3.5 h-3.5" />
                </div>

                <div className="absolute bottom-4 left-4 right-4 z-10">
                  <span className="font-mono text-[10px] text-[#A78BFA] block mb-0.5">
                    FRAME 0{idx + 1}
                  </span>
                  <p className="font-sans text-sm font-semibold text-white drop-shadow-sm">
                    {item.caption}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Accessible Fullscreen Lightbox Modal */}
        {activePhoto && (
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Expanded Movement Photograph"
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/92 backdrop-blur-lg animate-fade-in"
            onClick={() => setActivePhotoIdx(null)}
          >
            <div
              className="relative max-w-5xl w-full max-h-[90vh] flex flex-col items-center justify-center"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header Controls */}
              <div className="w-full flex items-center justify-between pb-4 text-white">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-[#8B5CF6] font-bold">
                    FRAME 0{activePhotoIdx + 1} / 0{siteConfig.gallery.length}
                  </span>
                  <span className="font-mono text-xs text-[#A5A1B2] uppercase hidden sm:inline">
                    // {activePhoto.category}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    className="p-2 rounded bg-white/10 hover:bg-[#8B5CF6] text-white transition-colors"
                    aria-label="Previous photograph"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="p-2 rounded bg-white/10 hover:bg-[#8B5CF6] text-white transition-colors"
                    aria-label="Next photograph"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setActivePhotoIdx(null)}
                    className="p-2 rounded bg-white/10 hover:bg-white/20 text-white transition-colors ml-2"
                    aria-label="Close photograph preview (Press Escape)"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Main Image Frame */}
              <div className="relative w-full max-h-[75vh] flex items-center justify-center rounded-sm overflow-hidden bg-[#15151C] border border-white/[0.12]">
                <img
                  src={activePhoto.src}
                  alt={activePhoto.alt}
                  className="max-h-[75vh] w-auto max-w-full object-contain filter contrast-[1.05]"
                />
              </div>

              {/* Bottom Caption */}
              <div className="w-full pt-3 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-[#A5A1B2]">
                <p className="font-sans font-medium text-[#F5F3F8]">
                  {activePhoto.caption}
                </p>
                <span className="font-mono text-[11px] mt-1 sm:mt-0 text-[#A5A1B2]">
                  Use Left / Right Arrows to navigate • Esc to close
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default GalleryPage;
