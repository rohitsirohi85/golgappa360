import React from 'react';
import { 
  Sparkles, 
  Maximize, 
  Minimize, 
  Camera,
  CameraOff, 
  Radio, 
  Sliders, 
  Layers, 
  Activity, 
  Disc, 
  Music, 
  Video 
} from 'lucide-react';

export const TopBar = ({
  activeNav,
  setActiveNav,
  isFullscreen,
  toggleFullscreen,
  cameraStatus = 'off',
  handCount = 0,
  showCameraPanel,
  setShowCameraPanel,
  onOpenGestureModal,
  showLeftPanel,
  setShowLeftPanel,
  showRightPanel,
  setShowRightPanel,
  showHUD,
  setShowHUD,
  fps = 60,
  audioPlaying = false,
}) => {
  const navItems = [
    { id: 'studio', label: 'Studio', icon: Activity },
    { id: 'visuals', label: 'Visuals', icon: Layers },
    { id: 'sounds', label: 'Sounds', icon: Music },
    { id: 'recordings', label: 'Recordings', icon: Disc },
  ];

  return (
    <header className="h-16 px-4 md:px-6 flex items-center justify-between border-b border-white/10 mb-panel z-30 select-none">
      {/* Brand & Identity */}
      <div className="flex items-center gap-3">
        <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600/30 via-blue-600/20 to-cyan-500/30 border border-cyan-400/40 mb-glow-cyan">
          <Sparkles className="w-5 h-5 text-cyan-300 animate-pulse" />
          {audioPlaying && (
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-400"></span>
            </span>
          )}
        </div>

        <div>
          <div className="flex items-center gap-2">
            <span className="font-extrabold tracking-wider text-lg text-white font-mono flex items-center gap-1.5">
              MOTION<span className="text-cyan-400">BEAT</span>
            </span>
            <span className="text-[10px] tracking-widest uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono font-semibold">
              Phase 2: Hand Tracking
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-sans tracking-wide">
            Gesture & Audio Performance Studio
          </p>
        </div>
      </div>

      {/* Center Studio Navigation */}
      <nav className="hidden lg:flex items-center gap-1 p-1 rounded-xl bg-black/40 border border-white/5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeNav === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/20 to-purple-600/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Right Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Panel toggle shortcuts */}
        <div className="flex items-center bg-black/30 rounded-lg p-0.5 border border-white/5">
          <button
            onClick={() => setShowLeftPanel(!showLeftPanel)}
            title="Toggle Presets Panel"
            className={`p-1.5 rounded-md text-xs transition-colors ${
              showLeftPanel ? 'text-cyan-300 bg-white/10' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowRightPanel(!showRightPanel)}
            title="Toggle Settings Panel"
            className={`p-1.5 rounded-md text-xs transition-colors ${
              showRightPanel ? 'text-cyan-300 bg-white/10' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowCameraPanel(!showCameraPanel)}
            title="Toggle Camera Tracking Panel"
            className={`p-1.5 rounded-md text-xs transition-colors ${
              showCameraPanel ? 'text-emerald-300 bg-white/10' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Video className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowHUD(!showHUD)}
            title="Toggle Telemetry HUD"
            className={`p-1.5 rounded-md text-xs transition-colors ${
              showHUD ? 'text-purple-300 bg-white/10' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4" />
          </button>
        </div>

        {/* Live Camera & Gesture Tracking Status Button */}
        <button
          onClick={() => setShowCameraPanel(!showCameraPanel)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border transition-all text-xs font-mono group ${
            cameraStatus === 'active'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/50 shadow-sm shadow-emerald-500/20'
              : cameraStatus === 'requesting'
              ? 'bg-amber-950/40 border-amber-500/40 text-amber-300 animate-pulse'
              : cameraStatus === 'error'
              ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:border-cyan-500/40'
          }`}
          title="Toggle Hand Tracking Camera Panel"
        >
          <div className="relative flex h-2 w-2">
            {cameraStatus === 'active' ? (
              <>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 shadow-[0_0_8px_#34d399]"></span>
              </>
            ) : cameraStatus === 'requesting' ? (
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400"></span>
            ) : cameraStatus === 'error' ? (
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
            ) : (
              <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-500"></span>
            )}
          </div>

          {cameraStatus === 'active' ? (
            <>
              <Camera className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">TRACKING:</span>
              <span className="text-emerald-300 font-semibold text-[11px]">
                {handCount > 0 ? `${handCount} ${handCount === 1 ? 'HAND' : 'HANDS'}` : 'SEARCHING'}
              </span>
            </>
          ) : cameraStatus === 'requesting' ? (
            <>
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-amber-300 text-[11px]">CONNECTING...</span>
            </>
          ) : cameraStatus === 'error' ? (
            <>
              <CameraOff className="w-3.5 h-3.5 text-rose-400" />
              <span className="text-rose-300 text-[11px]">CAM ERROR</span>
            </>
          ) : (
            <>
              <CameraOff className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">CAMERA:</span>
              <span className="text-slate-400 font-semibold text-[11px]">OFF</span>
            </>
          )}
        </button>

        {/* Fullscreen Mode Toggle */}
        <button
          onClick={toggleFullscreen}
          className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 hover:border-cyan-500/40 transition-all"
          title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen Performance Mode'}
        >
          {isFullscreen ? (
            <Minimize className="w-4 h-4 text-cyan-400" />
          ) : (
            <Maximize className="w-4 h-4" />
          )}
        </button>
      </div>
    </header>
  );
};
