import React from 'react';
import { Activity, Sparkles, Video, Radio, Cpu, Hand, Gauge } from 'lucide-react';

export const PerformanceHUD = ({
  showHUD,
  fps = 60,
  preset = 'particle-universe',
  mousePos = { x: 0, y: 0 },
  audioPlaying = false,
  bpm = 124,
  triangles = 0,
  points = 0,
  trackingMode = 'mouse',
  handCount = 0,
  inferenceFps = 0,
  inferenceLatencyMs = 0,
  graphicsQuality = 'high',
  cameraStatus = 'off',
}) => {
  if (!showHUD) return null;

  return (
    <div className="absolute top-4 left-4 z-20 pointer-events-none select-none">
      <div className="bg-black/75 backdrop-blur-md border border-white/10 rounded-xl p-3.5 shadow-2xl text-[11px] font-mono space-y-1.5 w-64">
        {/* Header / Render FPS */}
        <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
          <span className="flex items-center gap-1.5 text-cyan-400 font-bold tracking-wider">
            <Activity className="w-3.5 h-3.5" />
            DIAGNOSTICS
          </span>
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                fps >= 50
                  ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                  : fps >= 30
                  ? 'bg-amber-400'
                  : 'bg-rose-500'
              }`}
            />
            <span className="font-bold text-slate-100">{fps} FPS</span>
          </div>
        </div>

        {/* Hand Tracking Inference Metrics */}
        <div className="flex justify-between text-slate-400">
          <span>INFERENCE:</span>
          {cameraStatus === 'active' ? (
            <span className="text-emerald-300 font-semibold">
              {inferenceFps > 0 ? `${inferenceFps} FPS` : '~14 FPS'} ({inferenceLatencyMs}ms)
            </span>
          ) : (
            <span className="text-slate-500">CAMERA OFF</span>
          )}
        </div>

        {/* Detected Hands */}
        <div className="flex justify-between text-slate-400">
          <span>HANDS DETECTED:</span>
          <span className={handCount > 0 ? 'text-cyan-300 font-bold' : 'text-slate-500'}>
            {handCount} {handCount === 1 ? 'HAND' : 'HANDS'}
          </span>
        </div>

        {/* Active Graphics Quality */}
        <div className="flex justify-between text-slate-400">
          <span>QUALITY:</span>
          <span className="text-purple-300 font-semibold uppercase">
            {graphicsQuality} ({points > 0 ? `${(points / 1000).toFixed(0)}k PTS` : `${triangles} TRIS`})
          </span>
        </div>

        {/* Scene Preset */}
        <div className="flex justify-between text-slate-400">
          <span>SCENE:</span>
          <span className="text-slate-200 font-semibold truncate max-w-[120px]">
            {preset.replace('-', ' ').toUpperCase()}
          </span>
        </div>

        {/* Interaction Input Mode */}
        <div className="flex justify-between text-slate-400">
          <span>INPUT MODE:</span>
          <span className={trackingMode === 'hands' ? 'text-emerald-400 font-semibold' : 'text-slate-300'}>
            {trackingMode === 'hands' ? 'HAND GESTURES' : 'MOUSE PREVIEW'}
          </span>
        </div>

        {/* Audio Reactivity Status */}
        <div className="flex justify-between text-slate-400 pt-1 border-t border-white/5">
          <span>AUDIO ENGINE:</span>
          <span className={audioPlaying ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
            {audioPlaying ? `PLAYING (${bpm} BPM)` : 'STANDBY'}
          </span>
        </div>
      </div>
    </div>
  );
};
