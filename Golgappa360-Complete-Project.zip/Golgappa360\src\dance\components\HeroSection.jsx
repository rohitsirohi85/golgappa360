import React, { useRef, useState, useEffect, useCallback } from 'react';
import { ArrowDown, ArrowUpRight, Compass, ShieldCheck } from 'lucide-react';
import { ACADEMY_CONFIG } from '../data/danceData';

export const HeroSection = ({ onOpenTrial }) => {
  const heroRef = useRef(null);
  const visualRef = useRef(null);
  const spotlightRef = useRef(null);

  // Motion Field state (normalized [-1, 1])
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Position references for smooth rAF interpolation
  const targetPos = useRef({ x: 0, y: 0, px: 50, py: 50 });
  const currentPos = useRef({ x: 0, y: 0, px: 50, py: 50 });
  const animFrameId = useRef(null);
  const isPointerInside = useRef(false);

  // Detect touch devices and reduced-motion preference
  useEffect(() => {
    const touchCheck = window.matchMedia('(hover: none) and (pointer: coarse)').matches;
    setIsTouchDevice(touchCheck);

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(motionQuery.matches);

    const handleMotionChange = (e) => setPrefersReducedMotion(e.matches);
    motionQuery.addEventListener('change', handleMotionChange);

    return () => motionQuery.removeEventListener('change', handleMotionChange);
  }, []);

  // Smooth easing animation loop for The Motion Field
  const updateMotion = useCallback(() => {
    if (prefersReducedMotion || isTouchDevice) return;

    // Linear interpolation with restrained damping factor (0.06)
    const factor = 0.06;
    currentPos.current.x += (targetPos.current.x - currentPos.current.x) * factor;
    currentPos.current.y += (targetPos.current.y - currentPos.current.y) * factor;
    currentPos.current.px += (targetPos.current.px - currentPos.current.px) * factor;
    currentPos.current.py += (targetPos.current.py - currentPos.current.py) * factor;

    // Apply restrained 3D translation to dancer visual (max 10px shift)
    if (visualRef.current) {
      const shiftX = (currentPos.current.x * 9).toFixed(2);
      const shiftY = (currentPos.current.y * 7).toFixed(2);
      visualRef.current.style.transform = `translate3d(${shiftX}px, ${shiftY}px, 0)`;
    }

    // Apply spotlight position
    if (spotlightRef.current) {
      const posX = currentPos.current.px.toFixed(1);
      const posY = currentPos.current.py.toFixed(1);
      spotlightRef.current.style.background = `radial-gradient(650px circle at ${posX}% ${posY}%, rgba(139, 92, 246, 0.22), transparent 70%)`;
    }

    // Stop loop if pointer left and position is virtually reset
    const delta =
      Math.abs(targetPos.current.x - currentPos.current.x) +
      Math.abs(targetPos.current.y - currentPos.current.y);

    if (isPointerInside.current || delta > 0.005) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    } else {
      animFrameId.current = null;
    }
  }, [prefersReducedMotion, isTouchDevice]);

  // Pointer event handlers
  const handlePointerMove = (e) => {
    if (isTouchDevice || prefersReducedMotion) return;
    if (!heroRef.current) return;

    const rect = heroRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    // Normalized coordinates [-1, 1]
    const normX = (clientX / rect.width) * 2 - 1;
    const normY = (clientY / rect.height) * 2 - 1;

    // Percentage coordinates [0, 100]
    const pctX = (clientX / rect.width) * 100;
    const pctY = (clientY / rect.height) * 100;

    targetPos.current = {
      x: Math.max(-1, Math.min(1, normX)),
      y: Math.max(-1, Math.min(1, normY)),
      px: Math.max(0, Math.min(100, pctX)),
      py: Math.max(0, Math.min(100, pctY))
    };

    isPointerInside.current = true;
    if (!animFrameId.current) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    }
  };

  const handlePointerLeave = () => {
    if (isTouchDevice || prefersReducedMotion) return;
    targetPos.current = { x: 0, y: 0, px: 50, py: 50 };
    isPointerInside.current = false;
    if (!animFrameId.current) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    }
  };

  useEffect(() => {
    return () => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
      }
    };
  }, []);

  const handleScrollToPrograms = () => {
    const el = document.getElementById('programs');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={heroRef}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      className="relative min-h-[100vh] lg:min-h-[105vh] flex flex-col justify-between pt-28 sm:pt-36 pb-12 sm:pb-16 overflow-hidden bg-[#0B0B0F]"
      aria-label="Hero Showcase"
    >
      {/* 
        SIGNATURE INTERACTION: THE MOTION FIELD SPOTLIGHT
        On desktop: soft violet spotlight follows pointer smoothly.
        On mobile/touch: static beautifully calibrated atmospheric violet glow.
      */}
      <div
        ref={spotlightRef}
        className="pointer-events-none absolute inset-0 z-0 transition-opacity duration-700"
        style={{
          background: isTouchDevice || prefersReducedMotion
            ? 'radial-gradient(800px circle at 75% 45%, rgba(139, 92, 246, 0.18), transparent 75%)'
            : 'radial-gradient(650px circle at 50% 50%, rgba(139, 92, 246, 0.2), transparent 70%)'
        }}
      />

      {/* Subtle architectural vertical grid lines */}
      <div className="pointer-events-none absolute inset-0 z-0 flex justify-between max-w-7xl mx-auto px-6 opacity-15">
        <div className="w-[1px] h-full bg-white/20" />
        <div className="w-[1px] h-full bg-white/10 hidden md:block" />
        <div className="w-[1px] h-full bg-white/10 hidden lg:block" />
        <div className="w-[1px] h-full bg-white/20" />
      </div>

      {/* Main Hero Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Editorial Headline & Actions (Stays Rock Solid & Stable) */}
          <div className="lg:col-span-7 flex flex-col z-20">
            {/* Editorial Badge */}
            <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-[#14141B] border border-white/[0.08] w-fit mb-6 sm:mb-8">
              <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
              <span className="font-mono text-[11px] font-semibold tracking-wider uppercase text-[#A5A1B2]">
                ACADEMY VOL. 2026 // URBAN DANCE CURRICULUM
              </span>
            </div>

            {/* The Original Sample Headline */}
            <h1 className="editorial-headline text-[#F5F3F8] tracking-[-0.04em] text-5xl sm:text-7xl xl:text-[5.5rem] leading-[0.92] uppercase select-text">
              <span className="block">YOUR BODY.</span>
              <span className="block text-[#A78BFA] transition-colors">YOUR RHYTHM.</span>
              <span className="block">YOUR ART.</span>
            </h1>

            {/* Original Supporting Copy */}
            <p className="mt-6 sm:mt-8 text-base sm:text-lg text-[#A5A1B2] max-w-xl font-normal leading-relaxed">
              {ACADEMY_CONFIG.supportingCopy}
            </p>

            {/* Primary & Secondary Call To Actions */}
            <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row items-stretch sm:items-center gap-4 max-w-md sm:max-w-none">
              {/* Primary CTA: EXPLORE CLASSES */}
              <button
                onClick={handleScrollToPrograms}
                className="group inline-flex items-center justify-center gap-3 px-7 py-4 text-xs sm:text-sm font-semibold tracking-widest uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all duration-200 rounded-sm shadow-[0_0_25px_-5px_rgba(139,92,246,0.55)] hover:shadow-[0_0_35px_0_rgba(167,139,250,0.65)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0B0B0F]"
              >
                <span>EXPLORE CLASSES</span>
                <ArrowDown className="w-4 h-4 transition-transform group-hover:translate-y-0.5 text-white" />
              </button>

              {/* Secondary CTA: BOOK A TRIAL */}
              <button
                onClick={onOpenTrial}
                className="group inline-flex items-center justify-center gap-2.5 px-7 py-4 text-xs sm:text-sm font-semibold tracking-widest uppercase text-[#F5F3F8] bg-[#14141B] hover:bg-[#1B1B26] border border-white/[0.12] hover:border-[#8B5CF6]/50 transition-all duration-200 rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              >
                <span>BOOK A TRIAL</span>
                <ArrowUpRight className="w-4 h-4 text-[#8B5CF6] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>

            {/* Editorial Quick Indicators */}
            <div className="mt-12 pt-8 border-t border-white/[0.08] grid grid-cols-3 gap-4 max-w-lg">
              <div>
                <span className="font-display font-extrabold text-2xl sm:text-3xl text-[#F5F3F8] block">05</span>
                <span className="font-mono text-[10px] sm:text-xs text-[#A5A1B2] uppercase tracking-wider">Disciplines</span>
              </div>
              <div>
                <span className="font-display font-extrabold text-2xl sm:text-3xl text-[#A78BFA] block">18+</span>
                <span className="font-mono text-[10px] sm:text-xs text-[#A5A1B2] uppercase tracking-wider">Master Faculty</span>
              </div>
              <div>
                <span className="font-display font-extrabold text-2xl sm:text-3xl text-[#F5F3F8] block">12:1</span>
                <span className="font-mono text-[10px] sm:text-xs text-[#A5A1B2] uppercase tracking-wider">Max Ratio</span>
              </div>
            </div>
          </div>

          {/* Right Column: Signature Hero Dancer Visual with Motion Field */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0 flex items-center justify-center">
            
            {/* Visual Container with Organic Cropping & Grain Overlay */}
            <div className="relative w-full max-w-[460px] aspect-[4/5] sm:aspect-[3/4] lg:aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#14141B] shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
              
              {/* Responsive Dancer Photography with subtle depth transform */}
              <div
                ref={visualRef}
                className="absolute inset-0 w-full h-full will-change-transform transition-transform duration-100 ease-out"
                style={{
                  transform: 'translate3d(0, 0, 0)'
                }}
              >
                <img
                  src="/images/dance/hero-dancer.jpg"
                  alt="Contemporary urban dancer captured in mid-air expressive leap"
                  loading="eager"
                  fetchPriority="high"
                  className="w-full h-full object-cover object-center filter contrast-[1.08] brightness-[0.96]"
                />
              </div>

              {/* Art Directed Image Overlays: Edge Vignette & Electric Violet Gradient */}
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-90" />
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-[#0B0B0F]/70 via-transparent to-transparent" />
              <div className="absolute inset-0 pointer-events-none mix-blend-color opacity-25 bg-[#8B5CF6]" />

              {/* Film Grain Texture */}
              <div className="film-grain absolute inset-0 pointer-events-none" />

              {/* Editorial Frame Accents */}
              <div className="absolute top-4 left-4 z-10 pointer-events-none">
                <span className="font-mono text-[10px] font-semibold text-white/80 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-white/10 uppercase tracking-widest">
                  FIG. 01 — KINETIC TORSION
                </span>
              </div>

              {/* Interactive Pointer Indicator (Desktop only) */}
              {!isTouchDevice && !prefersReducedMotion && (
                <div className="absolute bottom-4 right-4 z-10 pointer-events-none">
                  <span className="font-mono text-[9px] text-white/60 bg-black/60 backdrop-blur-sm px-2 py-1 rounded border border-white/5 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] animate-pulse" />
                    MOTION FIELD ACTIVE
                  </span>
                </div>
              )}

              {/* Bottom Editorial Caption */}
              <div className="absolute bottom-4 left-4 z-10 pointer-events-none max-w-[280px]">
                <p className="font-sans text-xs text-[#F5F3F8] font-medium leading-tight drop-shadow-md">
                  "The silence between beats is where genuine style is born."
                </p>
                <span className="font-mono text-[9px] text-[#A5A1B2] mt-1 block tracking-wider uppercase">
                  MOTION IS ART // CAMPAIGN VISUAL
                </span>
              </div>
            </div>

            {/* Subtle background glow element */}
            <div className="pointer-events-none absolute -bottom-10 -right-10 w-72 h-72 rounded-full bg-[#8B5CF6]/15 blur-3xl" />
          </div>

        </div>
      </div>

      {/* Hero Bottom Bar: Editorial Caption & Scroll Indicator */}
      <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 w-full mt-12 pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-[#8B5CF6] font-bold">01 //</span>
          <span className="font-mono text-xs tracking-wider text-[#A5A1B2] uppercase">
            ARCHIVE VOL. 04 — CONTEMPORARY STREET EDITORIAL
          </span>
        </div>

        <button
          onClick={handleScrollToPrograms}
          className="group inline-flex items-center gap-2 text-xs font-mono tracking-wider text-[#A5A1B2] hover:text-[#F5F3F8] transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6] py-1"
          aria-label="Scroll to programs section"
        >
          <span>SCROLL TO DISCOVER</span>
          <ArrowDown className="w-3.5 h-3.5 text-[#8B5CF6] transition-transform group-hover:translate-y-1" />
        </button>
      </div>
    </section>
  );
};
