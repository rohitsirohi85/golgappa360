import React from "react";
import { NavLink } from "react-router-dom";
import { Home, Search, Sparkles, Flame, User, LogIn } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

export const MobileNav = () => {
  const { isAuthenticated, currentUser } = useAuth();

  const items = [
    { to: "/", label: "Home", icon: Home },
    { to: "/search", label: "Search", icon: Search },
    { to: "/ai-search", label: "AI", icon: Sparkles, highlight: true },
    { to: "/trending", label: "Trending", icon: Flame },
    {
      to: isAuthenticated ? "/profile" : "/login",
      label: isAuthenticated ? "Profile" : "Log In",
      icon: User,
      customAvatar: isAuthenticated ? currentUser?.avatar : null
    }
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#090b12]/95 backdrop-blur-2xl border-t border-white/10 px-2 py-1.5 shadow-2xl">
      <div className="flex items-center justify-around">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? "text-purple-400 font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div
                  className={`p-1 rounded-xl transition-all flex items-center justify-center ${
                    isActive
                      ? "bg-purple-500/20 text-purple-300"
                      : item.highlight
                      ? "text-cyan-300"
                      : ""
                  }`}
                >
                  {item.customAvatar ? (
                    <img
                      src={item.customAvatar}
                      alt="Avatar"
                      className={`w-5 h-5 rounded-full object-cover ring-1 ${
                        isActive ? "ring-purple-400" : "ring-white/20"
                      }`}
                    />
                  ) : (
                    <item.icon className="w-5 h-5" />
                  )}
                </div>
                <span className="text-[10px] tracking-tight mt-0.5">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
