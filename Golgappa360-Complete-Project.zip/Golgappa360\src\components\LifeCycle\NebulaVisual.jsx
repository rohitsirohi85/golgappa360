import React from 'react';

/**
 * NebulaVisual — Cinematic stellar nursery nebula background visual
 * Features layered organic gas clouds (purple, blue, cyan, warm orange)
 * and floating soft particles with subtle gravitational breathing.
 */
export default function NebulaVisual({ className = '' }) {
  return (
    <div
      aria-hidden="true"
      className={`relative w-full h-[280px] sm:h-[360px] lg:h-[420px] rounded-3xl overflow-hidden pointer-events-none select-none ${className}`}
    >
      {/* Deep Space Background Layer */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#030712] via-[#050b1d] to-[#030712]" />

      {/* Cloud 1: Deep Cosmic Violet / Purple (Large) */}
      <div
        className="absolute -top-[10%] left-[15%] w-[45vw] max-w-[500px] h-[45vw] max-h-[500px] rounded-full bg-gradient-to-br from-purple-600/25 via-indigo-700/20 to-transparent blur-[80px] sm:blur-[110px] animate-nebula-breath"
        style={{ animationDuration: '16s' }}
      />

      {/* Cloud 2: Electric Cyan / Blue (Center-Left) */}
      <div
        className="absolute top-[20%] left-[30%] w-[35vw] max-w-[420px] h-[35vw] max-h-[420px] rounded-full bg-gradient-to-tr from-cyan-500/25 via-blue-600/15 to-transparent blur-[70px] sm:blur-[95px] animate-nebula-breath"
        style={{ animationDuration: '22s', animationDelay: '-4s' }}
      />

      {/* Cloud 3: Warm Orange / Amber Incandescent Core (Center-Right Infant Star Pocket) */}
      <div
        className="absolute top-[35%] right-[25%] w-[28vw] max-w-[340px] h-[28vw] max-h-[340px] rounded-full bg-gradient-to-bl from-amber-500/25 via-orange-600/15 to-transparent blur-[60px] sm:blur-[85px] animate-pulse-glow"
        style={{ animationDuration: '7s' }}
      />

      {/* Cloud 4: Deep Midnight Blue Mantle */}
      <div
        className="absolute -bottom-[15%] right-[10%] w-[40vw] max-w-[450px] h-[40vw] max-h-[450px] rounded-full bg-gradient-to-t from-sky-600/20 via-indigo-900/15 to-transparent blur-[90px]"
      />

      {/* Embryonic Protostellar Condensation Hotspots */}
      <div className="absolute top-[42%] left-[45%] w-2 h-2 rounded-full bg-cyan-200 blur-[1px] shadow-[0_0_15px_#38bdf8] animate-ping" style={{ animationDuration: '4s' }} />
      <div className="absolute top-[38%] right-[32%] w-2.5 h-2.5 rounded-full bg-amber-200 blur-[1px] shadow-[0_0_20px_#fbbf24] animate-pulse" style={{ animationDuration: '3s' }} />
      <div className="absolute bottom-[40%] left-[28%] w-1.5 h-1.5 rounded-full bg-purple-200 blur-[1px] shadow-[0_0_12px_#c084fc] animate-pulse" style={{ animationDuration: '5s' }} />

      {/* Dust Silhouette Filaments (Interstellar dust lanes) */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_48%_45%,transparent_35%,rgba(3,7,18,0.75)_85%)]" />

      {/* Astronomical Reticle & Telemetry Overlay */}
      <div className="absolute top-4 left-6 flex items-center gap-2 text-[10px] font-mono text-cyan-400/80 tracking-widest uppercase">
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
        <span>STELLAR NURSERY // IONIZATION FRONT</span>
      </div>

      <div className="absolute bottom-4 right-6 text-[10px] font-mono text-slate-500 tracking-wider">
        <span>MOLECULAR DENSITY: 10⁴ PART/CM³</span>
      </div>
    </div>
  );
}
