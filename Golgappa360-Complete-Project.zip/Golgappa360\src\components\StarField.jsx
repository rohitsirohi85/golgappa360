import React, { useEffect, useRef } from 'react';

/**
 * High-performance cinematic StarField component
 * Renders hundreds of multi-layered stars with subtle twinkling,
 * gentle cosmic drift, and responsive mouse parallax on HTML5 Canvas.
 */
export default function StarField({ className = '' }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Mouse parallax state with smooth lerping
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const handleMouseMove = (e) => {
      if (prefersReducedMotion) return;
      const normalizedX = (e.clientX / window.innerWidth - 0.5) * 2;
      const normalizedY = (e.clientY / window.innerHeight - 0.5) * 2;
      mouse.targetX = normalizedX * 25; // max 25px offset
      mouse.targetY = normalizedY * 25;
    };

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initStars();
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('resize', handleResize);

    // Star color palette (deep space accurate: cool white, soft cyan, stellar amber, violet tint)
    const starColors = [
      'rgba(240, 246, 255, ', // White diamond (majority)
      'rgba(224, 242, 254, ', // Ice blue (O/B type)
      'rgba(254, 243, 199, ', // Pale gold (G type)
      'rgba(254, 215, 170, ', // Warm amber (K type)
      'rgba(233, 213, 255, ', // Faint cosmic violet
    ];

    let stars = [];

    const initStars = () => {
      // Density based on viewport area
      const count = Math.floor(Math.min(width, 1920) * 0.28);
      stars = [];

      for (let i = 0; i < count; i++) {
        // 3 depth layers: 0 (deep background), 1 (midground), 2 (foreground)
        const layer = Math.random() < 0.65 ? 0 : Math.random() < 0.88 ? 1 : 2;

        let radius;
        let baseAlpha;
        let speed;

        if (layer === 0) {
          radius = Math.random() * 0.7 + 0.3; // Tiny dust stars
          baseAlpha = Math.random() * 0.35 + 0.15;
          speed = Math.random() * 0.02 + 0.01;
        } else if (layer === 1) {
          radius = Math.random() * 0.9 + 0.8; // Midground stars
          baseAlpha = Math.random() * 0.45 + 0.3;
          speed = Math.random() * 0.04 + 0.02;
        } else {
          radius = Math.random() * 1.2 + 1.4; // Prominent foreground stars
          baseAlpha = Math.random() * 0.4 + 0.55;
          speed = Math.random() * 0.07 + 0.03;
        }

        // Color choice
        const colorPrefix =
          layer === 2
            ? starColors[Math.floor(Math.random() * starColors.length)]
            : starColors[Math.random() < 0.7 ? 0 : 1];

        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius,
          baseAlpha,
          alpha: baseAlpha,
          twinkleSpeed: Math.random() * 0.025 + 0.008,
          twinklePhase: Math.random() * Math.PI * 2,
          twinkleVariance: Math.random() * 0.3 + 0.15,
          colorPrefix,
          layer,
          vx: (Math.random() - 0.5) * speed * 0.6,
          vy: -speed * 0.5, // gentle upward cosmic drift
          hasDiffraction: layer === 2 && Math.random() > 0.4,
        });
      }
    };

    initStars();

    const render = () => {

      // Smooth mouse lerp
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < stars.length; i++) {
        const star = stars[i];

        // Cosmic drift
        if (!prefersReducedMotion) {
          star.x += star.vx;
          star.y += star.vy;

          // Wrap edges smoothly
          if (star.x < -10) star.x = width + 10;
          if (star.x > width + 10) star.x = -10;
          if (star.y < -10) star.y = height + 10;
          if (star.y > height + 10) star.y = -10;

          // Twinkle calculation
          star.twinklePhase += star.twinkleSpeed;
          star.alpha =
            star.baseAlpha + Math.sin(star.twinklePhase) * star.twinkleVariance;
          if (star.alpha < 0.05) star.alpha = 0.05;
          if (star.alpha > 1) star.alpha = 1;
        }

        // Parallax offset by layer depth
        const parallaxMultiplier = (star.layer + 1) * 0.35;
        const renderX = star.x + mouse.x * parallaxMultiplier;
        const renderY = star.y + mouse.y * parallaxMultiplier;

        ctx.beginPath();
        ctx.arc(renderX, renderY, star.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${star.colorPrefix}${star.alpha})`;
        ctx.fill();

        // Subtle diffraction spikes on prominent foreground stars
        if (star.hasDiffraction && star.alpha > 0.6) {
          ctx.save();
          ctx.strokeStyle = `${star.colorPrefix}${star.alpha * 0.35})`;
          ctx.lineWidth = 0.5;

          const spikeLen = star.radius * 3.5;
          ctx.beginPath();
          // Horizontal spike
          ctx.moveTo(renderX - spikeLen, renderY);
          ctx.lineTo(renderX + spikeLen, renderY);
          // Vertical spike
          ctx.moveTo(renderX, renderY - spikeLen);
          ctx.lineTo(renderX, renderY + spikeLen);
          ctx.stroke();
          ctx.restore();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className={`fixed inset-0 pointer-events-none overflow-hidden z-0 ${className}`}>
      {/* Deep Space Background Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 block w-full h-full" />

      {/* Subtle Atmospheric Nebula Gradients (Soft, not overly bright) */}
      <div
        aria-hidden="true"
        className="absolute -top-[15%] left-[10%] w-[55vw] h-[55vw] rounded-full bg-gradient-to-br from-indigo-950/20 via-purple-900/10 to-transparent blur-[120px] animate-nebula-breath pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute top-[25%] -right-[10%] w-[60vw] h-[60vw] rounded-full bg-gradient-to-bl from-cyan-950/25 via-blue-950/15 to-transparent blur-[140px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-[-10%] left-[25%] w-[50vw] h-[50vw] rounded-full bg-gradient-to-t from-amber-950/10 via-transparent to-transparent blur-[130px] pointer-events-none"
      />

      {/* Subtle Astronomical Vignette / Horizon Mask */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(3,7,18,0.7)_100%)] pointer-events-none"
      />
    </div>
  );
}
