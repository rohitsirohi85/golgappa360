import React, { useState, useEffect, useCallback } from 'react';
import { useMess } from '../context/MessContext';
import { KPI_METRICS } from '../../data/mockWasteData';
import { messApi } from '../services/messApiService';
import { StatCard } from '../components/common/StatCard';
import { DailyWasteTrendChart } from '../components/charts/DailyWasteTrendChart';
import { ActualVsPredictedChart } from '../components/charts/ActualVsPredictedChart';
import { MealTypeComparisonChart } from '../components/charts/MealTypeComparisonChart';
import { WasteCompositionDonut } from '../components/charts/WasteCompositionDonut';
import { RecentMealsTable } from '../components/tables/RecentMealsTable';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { EmptyState } from '../components/common/EmptyState';
import { ErrorState } from '../components/common/ErrorState';
import {
  UtensilsCrossed,
  ChefHat,
  Trash2,
  Percent,
  PiggyBank,
  Sparkles,
  Info,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';

export const OverviewPage = () => {
  const { simulationState, setSimulationState, setIsDemoModalOpen, navigateTo } = useMess();
  
  // Real backend data states
  const [dashboardData, setDashboardData] = useState(null);
  const [recentRecords, setRecentRecords] = useState([]);
  const [isLoadingApi, setIsLoadingApi] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [selectedMealRecord, setSelectedMealRecord] = useState(null);

  const fetchData = useCallback(async () => {
    setIsLoadingApi(true);
    setApiError(null);
    try {
      const [summaryRes, recordsRes] = await Promise.all([
        messApi.getDashboardSummary(),
        messApi.getDataRecords({ page: 1, page_size: 10, sort_by: 'date', sort_order: 'desc' }),
      ]);
      setDashboardData(summaryRes);
      setRecentRecords(recordsRes.records || []);
    } catch (err) {
      console.warn('FastAPI backend connection warning in OverviewPage:', err);
      setApiError(err.message || 'Unable to connect to FastAPI backend');
    } finally {
      setIsLoadingApi(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Reviewer test states: loading, empty, error
  if (simulationState === 'loading' || (isLoadingApi && !dashboardData && !apiError)) {
    return (
      <div className="space-y-6">
        <LoadingSkeleton type="stat-grid" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <LoadingSkeleton type="chart" />
          <LoadingSkeleton type="chart" />
        </div>
        <LoadingSkeleton type="table" />
      </div>
    );
  }

  if (simulationState === 'error' || (apiError && !dashboardData)) {
    return (
      <div className="py-12">
        <ErrorState
          title="Backend Connection Failed"
          message={apiError || 'Failed to query /api/dashboard/summary. Verify that FastAPI is running on http://localhost:8000.'}
          onRetry={fetchData}
        />
      </div>
    );
  }

  if (simulationState === 'empty') {
    return (
      <div className="py-12">
        <EmptyState
          title="No Active Mess Telemetry Found"
          description="The mess monitoring hub is currently in standby mode or waiting for initial meal sensor calibration."
          actionLabel="Load Benchmark Telemetry"
          onAction={() => setSimulationState('normal')}
        />
      </div>
    );
  }

  // Derive metrics: Prefer real backend data, fallback to calibrated metadata
  const ds = dashboardData?.dataset_summary;
  const totalMealsFormatted = ds ? ds.total_meals_recorded.toLocaleString() : KPI_METRICS.totalMealsRecorded.formatted;
  const totalPrepFormatted = ds ? `${ds.total_food_prepared_kg.toLocaleString()} kg` : `${KPI_METRICS.totalFoodPrepared.formatted} kg`;
  const totalWasteFormatted = ds ? `${ds.total_food_waste_kg.toLocaleString()} kg` : `${KPI_METRICS.totalFoodWaste.formatted} kg`;
  const avgWastePctFormatted = ds ? `${ds.average_waste_percentage}%` : KPI_METRICS.averageWastePercentage.formatted;
  const totalCostFormatted = ds ? `₹${ds.total_prepared_cost_inr.toLocaleString()}` : KPI_METRICS.estimatedCostSaved.formatted;
  const totalLossFormatted = ds ? `₹${ds.total_wasted_cost_inr.toLocaleString()}` : '₹56,44,470';

  return (
    <div className="space-y-6 pb-8">
      {/* Disclaimer Banner: Light emerald style */}
      <div className="p-4 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-white text-[#16865B] border border-[#C5E5D0] shrink-0 mt-0.5 shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-[#16865B] text-xs sm:text-sm">
                Synthetic Benchmark Telemetry (FastAPI Connected)
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white text-[#16865B] border border-[#C5E5D0]">
                Live API: /api/dashboard/summary
              </span>
            </div>
            <p className="text-xs text-[#55635C] mt-0.5">
              Live metrics populated from FastAPI backend with SQLite persistence for MCA Major Project demonstration.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={fetchData}
            disabled={isLoadingApi}
            className="p-1.5 rounded-lg text-[#55635C] hover:text-[#16865B] bg-white hover:bg-[#F8FAF8] transition-colors border border-[#C5E5D0] cursor-pointer shadow-xs"
            title="Refresh dashboard metrics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingApi ? 'animate-spin text-[#16865B]' : ''}`} />
          </button>
          <button
            onClick={() => setIsDemoModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white hover:bg-[#F8FAF8] text-[#16865B] border border-[#C5E5D0] transition-all cursor-pointer whitespace-nowrap shadow-xs"
          >
            <Info className="w-3.5 h-3.5" />
            Data Notice
          </button>
        </div>
      </div>

      {/* Overview Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Meals Recorded */}
        <StatCard
          title="Total Meals Logged"
          value={totalMealsFormatted}
          unit="meals"
          delta="+12.4%"
          trend="up"
          subtext="from 1,000 synthetic observations"
          icon={UtensilsCrossed}
          accentColor="emerald"
        />

        {/* Total Food Prepared */}
        <StatCard
          title="Total Food Prepared"
          value={totalPrepFormatted}
          unit=""
          delta="-4.2%"
          trend="down"
          subtext="aggregate kitchen batch volume"
          icon={ChefHat}
          accentColor="teal"
        />

        {/* Total Food Waste */}
        <StatCard
          title="Total Food Waste"
          value={totalWasteFormatted}
          unit=""
          delta="-18.6%"
          trend="down"
          subtext="total post-service discards"
          icon={Trash2}
          accentColor="amber"
        />

        {/* Average Waste Percentage */}
        <StatCard
          title="Avg Waste Percentage"
          value={avgWastePctFormatted}
          unit=""
          delta="-2.1%"
          trend="down"
          subtext="benchmark target threshold: < 7.0%"
          icon={Percent}
          accentColor="indigo"
        />
      </div>

      {/* Secondary Financial & Sustainability Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
            <PiggyBank className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-medium uppercase text-[#77847C] tracking-wider">
              Total Prepared Cost
            </span>
            <div className="text-lg font-bold text-[#25332D] font-mono">
              {totalCostFormatted}
            </div>
            <span className="text-[10px] text-[#16865B]">
              ingredient and fuel expenditure
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#FEF2F2] text-[#DC2626] border border-[#FECACA]">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-medium uppercase text-[#77847C] tracking-wider">
              Total Financial Waste Loss
            </span>
            <div className="text-lg font-bold text-[#B91C1C] font-mono">
              {totalLossFormatted}
            </div>
            <span className="text-[10px] text-[#77847C]">
              cost of discarded food surplus
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-medium uppercase text-[#77847C] tracking-wider">
              FastAPI ML Pipeline
            </span>
            <div className="text-sm font-semibold text-[#25332D] mt-0.5 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#16865B]"></span>
              Linear Regression Pipeline
            </div>
            <span className="text-[10px] text-[#77847C] font-mono">
              MAE 20.50 kg • R² 0.5134
            </span>
          </div>
          <button
            onClick={() => navigateTo('predict')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] hover:bg-[#D8F0E1] transition-colors cursor-pointer flex items-center gap-1"
          >
            Predict
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Row 1 Charts: Daily Waste Trend & Actual vs Predicted */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DailyWasteTrendChart />
        <ActualVsPredictedChart />
      </div>

      {/* Row 2 Charts: Meal-type Comparison & Waste Composition Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MealTypeComparisonChart data={dashboardData?.meal_type_breakdown} />
        </div>
        <div>
          <WasteCompositionDonut />
        </div>
      </div>

      {/* Recent Meal Records Table: Fed from /api/data/records */}
      <RecentMealsTable
        records={recentRecords}
        isLoading={isLoadingApi}
        onRefresh={fetchData}
        onRecordClick={(rec) => setSelectedMealRecord(rec)}
      />

      {/* Record Inspection Modal */}
      {selectedMealRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#25332D]/40 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white border border-[#E4EAE5] p-6 text-[#25332D] shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
              <div>
                <h3 className="text-base font-bold text-[#25332D] flex items-center gap-2">
                  Meal Telemetry Details
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                    {selectedMealRecord.id}
                  </span>
                </h3>
                <span className="text-xs text-[#77847C]">
                  {selectedMealRecord.date} • {selectedMealRecord.mealType}
                </span>
              </div>
              <button
                onClick={() => setSelectedMealRecord(null)}
                className="text-[#77847C] hover:text-[#25332D] p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                <span className="text-[#77847C] font-medium">Menu Category / Items:</span>
                <p className="text-[#25332D] font-medium mt-0.5">{selectedMealRecord.menu}</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C]">Student Headcount:</span>
                  <div className="text-base font-mono font-bold text-[#25332D] mt-0.5">
                    {selectedMealRecord.actualHeadcount} <span className="text-xs font-normal text-[#77847C]">students</span>
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C]">Waste Percentage:</span>
                  <div className="text-base font-mono font-bold text-[#D97706] mt-0.5">
                    {selectedMealRecord.wastePct}%
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-center">
                  <span className="text-[#77847C] text-[11px]">Food Prepared</span>
                  <div className="font-mono font-semibold text-[#25332D] mt-0.5">{selectedMealRecord.preparedKg} kg</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-center">
                  <span className="text-[#77847C] text-[11px]">Food Wasted</span>
                  <div className="font-mono font-semibold text-[#B91C1C] mt-0.5">{selectedMealRecord.wastedKg} kg</div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] flex justify-between text-[#77847C]">
                <span>Weather Condition:</span>
                <span className="text-[#25332D] font-mono">{selectedMealRecord.weather}</span>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-[#EEF2EF] flex justify-end">
              <button
                onClick={() => setSelectedMealRecord(null)}
                className="px-4 py-1.5 rounded-lg text-xs bg-[#16865B] hover:bg-[#126E4A] text-white transition-colors cursor-pointer shadow-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
