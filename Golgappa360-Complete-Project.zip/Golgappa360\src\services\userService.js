import { userProfileData } from "../data/analytics";
import { initialSearchHistory } from "../data/searches";
import { songs } from "../data/songs";
import { playlists } from "../data/playlists";
import { authService } from "./authService";

const PROFILE_STORAGE_KEY = "lyriclens_profile_data";

export const userService = {
  async getProfile() {
    const sessionUser = authService.getCurrentUser();
    try {
      const stored = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...userProfileData, ...sessionUser, ...parsed };
      }
    } catch (e) {
      console.error(e);
    }
    return { ...userProfileData, ...sessionUser };
  },

  async updateProfile(updatedData) {
    await new Promise((resolve) => setTimeout(resolve, 400));
    const current = await this.getProfile();
    const merged = { ...current, ...updatedData };
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(merged));
      // Also update auth session if name, username, or avatar changed
      const sessionUser = authService.getCurrentUser();
      if (sessionUser) {
        const updatedSession = { ...sessionUser, ...updatedData };
        localStorage.setItem("lyriclens_auth_session", JSON.stringify(updatedSession));
      }
    } catch (e) {
      console.error(e);
    }
    return merged;
  },

  async getSearchHistory() {
    return [...initialSearchHistory];
  },

  async getFavoriteSongs() {
    return songs.slice(0, 4);
  },

  async getUserPlaylists() {
    return playlists.filter((p) => p.isUserCreated);
  }
};
