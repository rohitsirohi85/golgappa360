import React, { useState } from 'react';
import { CONSTELLATIONS_DATA } from '../../data/constellations';

/**
 * ConstellationSelector — Selector bar for switching constellations
 * Provides fast tab navigation, quick search, and active indicators.
 */
export default function ConstellationSelector({
  selectedId,
  onSelectConstellation,
}) {
  const [searchFilter, setSearchFilter] = useState('');

  const filteredConstellations = CONSTELLATIONS_DATA.filter((c) => {
    if (!searchFilter.trim()) return true;
    const query = searchFilter.toLowerCase();
    return (
      c.name.toLowerCase().includes(query) ||
      c.commonTitle.toLowerCase().includes(query) ||
      c.abbreviation.toLowerCase().includes(query) ||
      c.mainStars.some((s) => s.name.toLowerCase().includes(query))
    );
  });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-4">
      {/* Top Header & Search Strip */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-2">
        <div className="text-left w-full sm:w-auto">
          <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-cyan-400 block">
            CELESTIAL CATALOG NAVIGATION
          </span>
          <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
            EXPLORE A CONSTELLATION
          </h3>
        </div>

        {/* Quick Filter Input */}
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search constellation or star..."
            className="w-full px-4 py-2 pl-9 pr-8 rounded-full bg-black/40 border border-white/15 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-xs font-mono text-slate-200 placeholder-slate-500 transition-all outline-none"
            aria-label="Filter constellations"
          />
          <svg
            className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          {searchFilter && (
            <button
              type="button"
              onClick={() => setSearchFilter('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs font-mono"
              aria-label="Clear filter"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Constellation Pill Tabs */}
      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 sm:gap-2.5">
        {filteredConstellations.length > 0 ? (
          filteredConstellations.map((constellation) => {
            const isActive = constellation.id === selectedId;
            return (
              <button
                key={constellation.id}
                type="button"
                onClick={() => onSelectConstellation(constellation.id)}
                className={`relative px-4 py-2.5 rounded-2xl text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-2.5 border ${
                  isActive
                    ? 'bg-cyan-950/60 text-white border-cyan-400/80 shadow-[0_0_20px_rgba(6,182,212,0.25)]'
                    : 'bg-black/30 text-slate-300 border-white/10 hover:border-white/25 hover:text-white hover:bg-white/5'
                }`}
              >
                {/* Abbreviation Badge */}
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    isActive
                      ? 'bg-cyan-500/30 text-cyan-300 border border-cyan-400/40'
                      : 'bg-white/5 text-slate-400 border border-white/10'
                  }`}
                >
                  {constellation.abbreviation}
                </span>

                <span className="font-semibold">{constellation.name}</span>

                {/* Subtitle Moniker */}
                <span className="text-[10px] text-slate-400 hidden md:inline lowercase font-normal italic">
                  ({constellation.commonTitle})
                </span>

                {isActive && (
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping absolute top-2 right-2"
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })
        ) : (
          <div className="w-full text-center py-3 text-xs font-mono text-slate-400">
            No constellations matching &ldquo;{searchFilter}&rdquo;
          </div>
        )}
      </div>
    </div>
  );
}
