import React, { createContext, useContext, useState } from 'react';

const UIContext = createContext();

export const UIProvider = ({ children }) => {
  // Mobile device simulator frame toggle (true by default on desktop, adapts on mobile)
  const [isDeviceFrame, setIsDeviceFrame] = useState(true);
  const [isPresentationMode, setIsPresentationMode] = useState(false);
  const [isScreenshotMode, setIsScreenshotMode] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [activeTab, setActiveTab] = useState('home');

  const showToast = (message, type = 'success') => {
    const id = Date.now();
    setToasts((prev) => [...(Array.isArray(prev) ? prev : []), { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => (Array.isArray(prev) ? prev.filter((t) => t.id !== id) : []));
    }, 3500);
  };

  const removeToast = (id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <UIContext.Provider
      value={{
        isDeviceFrame,
        setIsDeviceFrame,
        isPresentationMode,
        setIsPresentationMode,
        isScreenshotMode,
        setIsScreenshotMode,
        toasts,
        showToast,
        removeToast,
        activeTab,
        setActiveTab,
      }}
    >
      {children}
    </UIContext.Provider>
  );
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (!context) {
    throw new Error('useUI must be used within a UIProvider');
  }
  return context;
};
