import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Zap, Navigation, ArrowRight } from 'lucide-react';
import { Card } from '../common/Card';
import { StatusBadge } from '../common/StatusBadge';
import { Button } from '../common/Button';
import { useEV } from '../../context/EVContext';

export const BookingCard = ({
  booking,
  onCancel,
  onNavigateMap,
  onStartCharging,
}) => {
  const navigate = useNavigate();
  const { startCharging } = useEV();

  const isConfirmed = booking.status === 'Confirmed';
  const isCompleted = booking.status === 'Completed';
  const isCancelled = booking.status === 'Cancelled';

  const handleStartCharging = () => {
    startCharging(
      { id: booking.chargerId, name: booking.chargerName },
      { name: booking.stationName }
    );
    navigate('/live-charging');
  };

  return (
    <Card className="relative overflow-hidden group">
      {/* Top Header */}
      <div className="flex items-start justify-between gap-3 mb-2.5">
        <div>
          <span className="text-[10px] font-mono text-slate-400 block mb-0.5">
            ID: {booking.id}
          </span>
          <h3 className="font-bold text-base text-white">{booking.stationName}</h3>
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
            <Zap className="w-3.5 h-3.5 text-[#00F5A0]" />
            <span>{booking.chargerName}</span>
            <span className="text-slate-600">•</span>
            <span>{booking.power || '60 kW'}</span>
            <span className="text-slate-600">•</span>
            <span>{booking.connector || 'CCS2'}</span>
          </div>
        </div>

        <StatusBadge status={booking.status} />
      </div>

      {/* Date & Time Slot Banner */}
      <div className="flex items-center justify-between p-3 rounded-xl bg-[#0D1527] border border-white/5 my-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-semibold text-white">{booking.date}</span>
        </div>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#00E5FF]" />
          <span className="text-xs font-semibold text-slate-200">{booking.time}</span>
        </div>
      </div>

      {/* Address if available */}
      {booking.stationAddress && (
        <p className="text-[11px] text-slate-400 flex items-center gap-1 mb-3 truncate">
          <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
          <span>{booking.stationAddress}</span>
        </p>
      )}

      {/* Rate or Final Amount */}
      <div className="flex items-center justify-between text-xs py-1 mb-3 text-slate-400 border-t border-white/5 pt-2">
        <span>Estimated Rate:</span>
        <span className="font-semibold text-white font-mono">
          {booking.totalAmount ? `₹${booking.totalAmount}` : `₹${booking.rate || 10}/kWh`}
        </span>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2 pt-1 border-t border-white/5">
        {isConfirmed && (
          <>
            <Button
              size="sm"
              variant="primary"
              className="flex-1"
              onClick={handleStartCharging}
              icon={Zap}
            >
              Start Charging
            </Button>

            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateMap?.(booking)}
              icon={Navigation}
            >
              Navigate
            </Button>

            <Button
              size="sm"
              variant="danger"
              onClick={() => onCancel?.(booking)}
            >
              Cancel
            </Button>
          </>
        )}

        {isCompleted && (
          <Button
            size="sm"
            variant="secondary"
            className="w-full"
            onClick={() => navigate('/bill')}
            icon={ArrowRight}
            iconPosition="right"
          >
            View Invoice & Receipt
          </Button>
        )}

        {isCancelled && (
          <div className="text-xs text-rose-400/90 italic py-1">
            Slot was cancelled. No charges incurred.
          </div>
        )}
      </div>
    </Card>
  );
};
