# Golgappa360 — System Architecture Document

> **Master of Computer Applications (MCA) Major Capstone Project**  
> **Project:** Golgappa360 — Golgappa Business Intelligence & Sales Analytics System  
> **Architecture Pattern:** Multi-Tiered Dual-Engine Client-Server Architecture  
> **Version:** 5.0 (Final Submission)

---

## 1. Architectural Philosophy & Design Goals

Golgappa360 is engineered as an enterprise-grade analytics platform adapted for small, high-velocity Indian food businesses (specifically street-food stalls, chaat centers, and quick-service kiosks). The system adheres to three architectural imperatives:

1. **Dual-Engine Business Intelligence:**
   - **Primary Engine (Production Scale):** MySQL 8.0 relational database with connection pooling, indexed 3NF schema, and materialized views.
   - **Fallback Engine (Zero-Configuration Resilience):** In-memory synthetic analytical store pre-loaded with the calibrated 6-month operational dataset. If MySQL is offline, unauthenticated, or in migration, the application degrades gracefully without user disruption.
2. **Unified Semantic & Accounting Invariants:**
   - Calculations across all tiers (SQL Views, Express REST APIs, React Client, Tableau Calculated Fields, and Excel Pivot Tables) use identical mathematical definitions to ensure mathematical parity ($₹0.00$ variance).
3. **Decoupled Analytical Grains:**
   - High-volume transaction line items (`31,938` rows) and stock ledger movements (`2,391` rows) are isolated to prevent Cartesian product inflation (fan traps), connected only via Tableau Logical Relationships.

---

## 2. Multi-Tiered Architecture Diagram

```mermaid
flowchart TD
    subgraph Presentation["Presentation Tier (Client - React 19 + Vite :5173)"]
        UI_Shell["Dark Glassmorphism UI Shell (#171717)"]
        UI_Nav["Sidebar & History-Synchronized Hash Router"]
        UI_Overview["Overview Dashboard (KPIs & Real-Time Velocity)"]
        UI_Sales["Sales & Rush Hour Heatmap Engine"]
        UI_Menu["Menu Engineering & BOM Margins"]
        UI_Inventory["Raw Ingredient Runway & Restock Modal"]
        UI_Waste["Food Waste & Spoilage Tracker"]
        UI_Reports["Reports, Tableau CSVs & SQL Hub"]
        UI_Settings["System Configuration & MySQL Diagnostics"]
    end

    subgraph Service["Application & API Tier (Node.js / Express :5000)"]
        Router["Express REST Router (/api)"]
        MW_Cors["CORS & Request Latency Logger"]
        MW_Validate["Query Parameter Validation Middleware"]
        MW_Error["Sanitizing Global Error Handler"]
        Controller["Modular Route Controllers (Dashboard, Sales, Products, Inventory, Waste, Reports)"]
        Service_Analytics["Centralized Analytics Service (Accounting Invariants)"]
    end

    subgraph DualEngine["Data Persistence & Dual-Engine Tier"]
        DB_Pool["mysql2/promise Connection Pool"]
        MySQL_DB[("MySQL 8.0 Relational DB (golgappa360)")]
        Store_Synthetic["High-Fidelity In-Memory Store (Synthetic)"]
        CSV_Files[("Reproducible CSV Files (data/synthetic)")]
    end

    subgraph BITier["Business Intelligence & Export Tier"]
        Export_Script["Tableau RFC 4180 Export Generator"]
        Tableau_CSVs["Verified Tableau CSV Bundle (tableau/exports)"]
        Tableau_BI["Tableau Desktop / Public (Logical Relationships)"]
        Excel_BI["Microsoft Excel (Power Query & Pivot Models)"]
    end

    Presentation -->|HTTP REST Requests (JSON)| Router
    Router --> MW_Cors
    MW_Cors --> MW_Validate
    MW_Validate --> Controller
    Controller --> Service_Analytics

    Service_Analytics -->|MySQL Connection Active| DB_Pool
    DB_Pool --> MySQL_DB
    Service_Analytics -->|Fallback / Offline Mode| Store_Synthetic
    Store_Synthetic --> CSV_Files

    Export_Script --> CSV_Files
    Export_Script --> Tableau_CSVs
    Tableau_CSVs --> Tableau_BI
    Tableau_CSVs --> Excel_BI
```

---

## 3. Tier Responsibilities & Specifications

### 3.1 Presentation Tier (Frontend)
- **Framework:** React 19 + Vite 8.
- **Styling Architecture:** Tailwind CSS v4 with custom dark glassmorphism design tokens:
  - Base canvas: `#171717` (Deep charcoal).
  - Glass cards: `rgba(48, 48, 50, 0.88)` with `backdrop-filter: blur(24px)`.
  - Glass borders: `rgba(255, 255, 255, 0.12)`.
  - Sage green accent: `#A7D78A` (Margins & primary series).
  - Saffron orange accent: `#EAB64B` (Volume & highlights).
  - Terracotta warning: `#D98768` (Waste loss & alerts).
- **State Management:** `GolgappaContext.jsx` leveraging React Hooks (`useContext`, `useCallback`, `useState`, `useEffect`).
- **Navigation:** Hash-synchronized browser history routing (`/#overview`, `/#sales`, `/#menu`, `/#inventory`, `/#waste`, `/#reports`, `/#settings`) supporting deep-linking and browser navigation.
- **Data Visualization:** Recharts (ResponsiveContainer, AreaChart, BarChart, LineChart, PieChart).

### 3.2 Service Tier (Backend API)
- **Runtime:** Node.js v24.14.0 (compatible with Node 18+).
- **Framework:** Express 4.21.
- **Middleware Pipeline:**
  1. `cors({ origin: '*' })`: Universal access for frontend and external tooling.
  2. `express.json()` and `express.urlencoded()`: Payload parsing.
  3. Development Latency Logger: Logs execution duration for all `/api` routes.
  4. `validateDateRange`: Enforces `YYYY-MM-DD` date syntax, checks `startDate <= endDate`, and validates range presets (`today`, `7d`, `30d`, `90d`, `180d`, `all`).
  5. `validatePagination`: Enforces positive integer pagination (`page >= 1`, `1 <= limit <= 500`).
  6. `errorHandler`: Shielding middleware masking raw database stack traces while returning standard `{ success: false, error: message }` envelopes.

### 3.3 Data Tier (Dual-Engine)
- **MySQL 8.0:** Normalized 3NF schema with foreign key constraints, indexes on timestamps and categories, and 4 pre-aggregated analytical views.
- **Synthetic Fallback Store:** Memory-resident dataset loaded directly on startup from reproducible CSVs, providing zero-configuration uptime.

### 3.4 Business Intelligence & Export Tier
- RFC 4180 compliant CSV export generator ensuring unformatted numeric data types (no currency symbols inside numeric fields) for immediate consumption in Tableau Desktop, Tableau Public, Power BI, and Microsoft Excel.

---

## 4. Communication Protocols & Data Contracts

All endpoints return uniform response payloads:

### Standard Success Envelope
```json
{
  "success": true,
  "data": { ... }
}
```

### Standard Error Envelope
```json
{
  "success": false,
  "error": "Human-readable sanitized error description"
}
```

### Direct Binary Streaming (CSV Exports)
- `Content-Type: text/csv; charset=utf-8`
- `Content-Disposition: attachment; filename="dataset_name.csv"`

---

## 5. Security & Isolation Controls

1. **SQL Injection Prevention:** All SQL statements in `AnalyticsService` execute via parameterized placeholders (`?`). No string concatenation is used in SQL generation.
2. **Credential Sanitization:** Real database passwords are not stored in source code. Configuration is read strictly from `process.env` with fallback to `.env.example` placeholders.
3. **Data Immutability:** Historical sales transactions are append-only. Only inventory restocks and food waste logs generate new transactional mutations.
