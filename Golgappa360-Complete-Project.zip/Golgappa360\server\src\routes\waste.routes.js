import express from 'express';
import * as wasteController from '../controllers/waste.controller.js';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/summary', wasteController.getSummary);

// Preserved Phase 1 & 2 base endpoint
router.get('/', (req, res, next) => {
  wasteController.getSummary(req, res, next);
});

router.post('/log', (req, res) => {
  try {
    const { ingredient_id, quantity, reason } = req.body;
    if (!ingredient_id || !quantity || !reason) {
      return res.status(400).json({ success: false, error: 'Ingredient, quantity, and reason are required.' });
    }
    const wasteData = syntheticStore.getWasteData('180d');
    res.status(201).json({ success: true, data: { logged: true, wasteData } });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
