import React from 'react';
import { Zap } from 'lucide-react';

export const BatteryIndicator = ({
  percentage = 78,
  range = 312,
  size = 140,
  strokeWidth = 10,
  showRange = true,
  isCharging = false,
  className = '',
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  // Determine color based on battery level
  let strokeColor = '#00F5A0'; // emerald green
  if (percentage <= 20) {
    strokeColor = '#EF4444'; // red
  } else if (percentage <= 45) {
    strokeColor = '#F59E0B'; // amber
  }

  return (
    <div className={`relative flex flex-col items-center justify-center ${className}`}>
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255, 255, 255, 0.08)"
          strokeWidth={strokeWidth}
          fill="transparent"
        />

        {/* Active progress */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          fill="transparent"
          className="transition-all duration-700 ease-out"
          style={{
            filter: `drop-shadow(0 0 10px ${strokeColor}88)`,
          }}
        />
      </svg>

      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        {isCharging && (
          <div className="flex items-center gap-1 text-[#00F5A0] text-xs font-semibold animate-pulse mb-0.5">
            <Zap className="w-3.5 h-3.5 fill-[#00F5A0]" />
            <span>CHARGING</span>
          </div>
        )}
        <div className="flex items-baseline">
          <span className="text-3xl font-extrabold tracking-tight text-white font-mono">
            {percentage}
          </span>
          <span className="text-lg font-bold text-[#00F5A0] ml-0.5">%</span>
        </div>
        {showRange && range && (
          <span className="text-[11px] font-medium text-slate-400 mt-0.5">
            {range} km range
          </span>
        )}
      </div>
    </div>
  );
};
