import React, { useState } from 'react';
import ConstellationHeader from './Constellations/ConstellationHeader';
import ConstellationStats from './Constellations/ConstellationStats';
import ConstellationSelector from './Constellations/ConstellationSelector';
import SkyMap from './Constellations/SkyMap';
import ConstellationDetailPanel from './Constellations/ConstellationDetailPanel';
import EducationalNote from './Constellations/EducationalNote';
import ConstellationCardGrid from './Constellations/ConstellationCardGrid';
import { getConstellationById } from '../data/constellations';

/**
 * ConstellationsSection — "CONSTELLATION EXPLORER" (Phase 5)
 * Comprehensive Night Sky Atlas:
 * 1. Cinematic Intro & Scientific HUD Coordinates
 * 2. Dynamic Statistics Strip (88 Official, 6 Featured, 38+ Stars, 1 Sky)
 * 3. Interactive Constellation Selector & Search Bar
 * 4. Interactive Sky Map with Magnitude Scaling, Pan/Zoom, and Glowing Lines
 * 5. Constellation Detail Panel with Live Spectroscopic Dossier & Lore
 * 6. Educational 3D Perspective Note (2D Patterns vs 3D Stellar Distances)
 * 7. "EXPLORE THE CONSTELLATIONS" 6-Card Interactive Grid
 */
export default function ConstellationsSection({
  onSelectStarFromConstellation,
  onViewConstellationOnMap,
}) {
  // Currently active constellation (defaults to 'orion')
  const [selectedConstellationId, setSelectedConstellationId] = useState('orion');

  // Currently selected star within active constellation
  const [selectedStar, setSelectedStar] = useState(null);

  const activeConstellation = getConstellationById(selectedConstellationId);

  const handleSelectConstellation = (id) => {
    setSelectedConstellationId(id);
    const constObj = getConstellationById(id);
    const focalStar = constObj.mainStars.find((s) => s.isFocal) || constObj.mainStars[0];
    setSelectedStar(focalStar);
  };

  const handleSelectStar = (star) => {
    setSelectedStar(star);
  };

  return (
    <section
      id="constellations"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Soft Celestial Atmospheres */}
      <div
        aria-hidden="true"
        className="absolute top-1/4 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-950/20 blur-[150px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute top-1/2 -left-40 w-[650px] h-[650px] rounded-full bg-indigo-950/25 blur-[160px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-10 right-1/3 w-[500px] h-[500px] rounded-full bg-purple-950/15 blur-[140px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16 sm:space-y-24">
        {/* 1. Cinematic Header */}
        <ConstellationHeader />

        {/* 2. Dynamic Statistics Strip */}
        <ConstellationStats />

        {/* 3. Constellation Selector */}
        <ConstellationSelector
          selectedId={selectedConstellationId}
          onSelectConstellation={handleSelectConstellation}
        />

        {/* 4. Main Interactive Sky Map + Detail Panel */}
        <div
          id="constellation-sky-map"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start scroll-mt-28"
        >
          {/* Left/Top: Interactive Sky Map Canvas */}
          <div className="lg:col-span-7">
            <SkyMap
              constellation={activeConstellation}
              selectedStarId={selectedStar?.id || activeConstellation.mainStars[0].id}
              onSelectStar={handleSelectStar}
            />
          </div>

          {/* Right/Bottom: Constellation Dossier & Selected Star Telemetry */}
          <div className="lg:col-span-5">
            <ConstellationDetailPanel
              constellation={activeConstellation}
              selectedStar={selectedStar}
              onSelectStar={handleSelectStar}
              onExploreStar={onSelectStarFromConstellation}
              onViewOnUniverseMap={onViewConstellationOnMap}
            />
          </div>
        </div>

        {/* 5. Educational Perspective Principle */}
        <EducationalNote />

        {/* 6. Constellation Card Grid */}
        <ConstellationCardGrid
          selectedId={selectedConstellationId}
          onSelectConstellation={handleSelectConstellation}
          onViewOnUniverseMap={onViewConstellationOnMap}
        />
      </div>
    </section>
  );
}
