import React from 'react';
import { useUI } from '../../context/UIContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer = () => {
  const { toasts, removeToast } = useUI();

  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 w-full max-w-xs px-3 pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`
              pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border shadow-xl backdrop-blur-xl transition-all animate-in fade-in slide-in-from-top-4 duration-250
              ${
                isSuccess
                  ? 'bg-[#0D1E2A]/95 border-[#00F5A0]/40 text-[#00F5A0] shadow-[0_4px_20px_rgba(0,245,160,0.2)]'
                  : isError
                  ? 'bg-[#2A0E14]/95 border-red-500/40 text-red-300 shadow-[0_4px_20px_rgba(239,68,68,0.2)]'
                  : 'bg-[#0D1527]/95 border-cyan-500/40 text-cyan-300 shadow-[0_4px_20px_rgba(0,229,255,0.2)]'
              }
            `}
          >
            <div className="flex items-center gap-2.5">
              {isSuccess && <CheckCircle2 className="w-4 h-4 shrink-0 text-[#00F5A0]" />}
              {isError && <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />}
              {!isSuccess && !isError && <Info className="w-4 h-4 shrink-0 text-cyan-400" />}
              <span className="text-xs font-semibold text-white leading-snug">
                {toast.message}
              </span>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-white/60 hover:text-white shrink-0 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
