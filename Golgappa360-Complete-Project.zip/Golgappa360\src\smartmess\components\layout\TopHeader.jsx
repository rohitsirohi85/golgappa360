import React, { useState, useEffect, useCallback } from 'react';
import { useMess, NAV_ITEMS } from '../../context/MessContext';
import { SyntheticDataBadge } from '../common/SyntheticDataBadge';
import { SimulationControlBar } from '../common/SimulationControlBar';
import { messApi } from '../../services/messApiService';
import {
  Calendar,
  Menu,
  SlidersHorizontal,
  X,
  RefreshCw,
} from 'lucide-react';

export const TopHeader = () => {
  const { activeTab, toggleMobileMenu } = useMess();
  const [showSimulatorBar, setShowSimulatorBar] = useState(false);

  // Healthcheck state
  const [apiHealth, setApiHealth] = useState({ status: 'checking', details: null });

  const checkHealth = useCallback(async () => {
    try {
      const data = await messApi.getHealth();
      setApiHealth({ status: 'online', details: data });
    } catch (err) {
      setApiHealth({ status: 'offline', details: err.message });
    }
  }, []);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 45000);
    return () => clearInterval(interval);
  }, [checkHealth]);

  // Find active item definition
  const currentNav = NAV_ITEMS.find((item) => item.id === activeTab) || NAV_ITEMS[0];

  // Dynamic formatted date
  const [formattedDate, setFormattedDate] = useState('');

  useEffect(() => {
    const d = new Date(2026, 9, 28); // Oct 28, 2026
    const options = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
    setFormattedDate(d.toLocaleDateString('en-US', options));
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-[#E4EAE5] px-6 sm:px-8 py-3.5 transition-colors">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger & Page Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleMobileMenu}
            className="md:hidden p-1.5 rounded-lg text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8] transition-colors cursor-pointer"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-semibold text-[#25332D] tracking-tight">
                {currentNav.label}
              </h1>
              <span className="hidden sm:inline-flex text-[10px] font-mono text-[#16865B] bg-[#E9F6EE] px-2 py-0.5 rounded-md font-medium">
                v1.4.2
              </span>
            </div>
            <p className="text-xs text-[#77847C] hidden sm:block">
              Intelligent Food Waste Prediction & Prevention System
            </p>
          </div>
        </div>

        {/* Right: Date, Synthetic Data Indicator, API Health, and Simulation Toggle */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* API Health Pill */}
          <button
            type="button"
            onClick={checkHealth}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono transition-colors cursor-pointer ${
              apiHealth.status === 'online'
                ? 'bg-[#E9F6EE] text-[#16865B] border border-[#D1EAD8] hover:bg-[#DCF2E4]'
                : apiHealth.status === 'offline'
                ? 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FEE2E2] hover:bg-[#FEE2E2]'
                : 'bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]'
            }`}
            title={
              apiHealth.status === 'online'
                ? `FastAPI Port 8000 Connected • ${apiHealth.details?.dataset?.records_available || 1000} records loaded • Click to ping`
                : 'FastAPI Offline • Click to retry connection'
            }
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                apiHealth.status === 'online'
                  ? 'bg-[#16865B]'
                  : apiHealth.status === 'offline'
                  ? 'bg-[#B91C1C]'
                  : 'bg-[#77847C]'
              }`}
            />
            <span className="text-[11px]">
              {apiHealth.status === 'online' ? 'API: Connected' : apiHealth.status === 'offline' ? 'API: Offline' : 'API: ...'}
            </span>
          </button>

          {/* Date Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#F8FAF8] border border-[#E4EAE5] text-xs text-[#77847C]">
            <Calendar className="w-3.5 h-3.5 text-[#16865B]" />
            <span className="font-mono text-xs">{formattedDate || 'Oct 28, 2026'}</span>
          </div>

          {/* Prominently visible Synthetic Demo Data Indicator */}
          <SyntheticDataBadge />

          {/* Quick toggle for State Testing */}
          <button
            onClick={() => setShowSimulatorBar((prev) => !prev)}
            className={`p-1.5 rounded-md border text-xs font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              showSimulatorBar
                ? 'bg-[#E9F6EE] text-[#16865B] border-[#D1EAD8]'
                : 'bg-white text-[#77847C] border-[#E4EAE5] hover:text-[#25332D] hover:bg-[#F8FAF8]'
            }`}
            title="Toggle UI state switch (Loading / Empty / Error testing)"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="hidden xl:inline text-xs">Test States</span>
          </button>
        </div>
      </div>

      {/* Expandable Simulation Control Bar */}
      {showSimulatorBar && (
        <div className="mt-3 pt-3 border-t border-[#E4EAE5] flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#25332D] font-medium">Reviewer Testing Controls:</span>
            <span className="text-xs text-[#77847C]">
              Switch between simulated telemetry states:
            </span>
          </div>
          <div className="flex items-center gap-3">
            <SimulationControlBar />
            <button
              onClick={() => setShowSimulatorBar(false)}
              className="text-[#77847C] hover:text-[#25332D] p-1 cursor-pointer"
              title="Close controls"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
