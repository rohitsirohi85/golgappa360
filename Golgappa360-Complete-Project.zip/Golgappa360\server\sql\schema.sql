-- =====================================================================
-- Golgappa360 - Relational Database Schema (MySQL 8.0+)
-- Database: golgappa360
-- E-R Architecture: 3rd Normal Form (3NF) for Food-Stall Operations
-- =====================================================================

CREATE DATABASE IF NOT EXISTS golgappa360
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE golgappa360;

-- Drop dependent tables in reverse FK dependency order for clean migrations
DROP VIEW IF EXISTS vw_dashboard_kpis;
DROP VIEW IF EXISTS vw_daily_financial_summary;
DROP VIEW IF EXISTS vw_product_performance;
DROP VIEW IF EXISTS vw_inventory_status;
DROP TABLE IF EXISTS sale_items;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS inventory_transactions;
DROP TABLE IF EXISTS ingredients;
DROP TABLE IF EXISTS daily_expenses;

-- -----------------------------------------------------
-- Table 1: products
-- Master catalog of golgappa varieties and standard BOM costs
-- -----------------------------------------------------
CREATE TABLE products (
    product_id VARCHAR(30) NOT NULL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(60) NOT NULL,
    selling_price DECIMAL(10, 2) NOT NULL,
    ingredient_cost_per_plate DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_selling_price CHECK (selling_price > 0),
    CONSTRAINT chk_ingredient_cost CHECK (ingredient_cost_per_plate > 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Table 2: sales (Header)
-- Individual customer order transactions and payment settlements
-- -----------------------------------------------------
CREATE TABLE sales (
    sale_id VARCHAR(30) NOT NULL PRIMARY KEY,
    sale_datetime DATETIME NOT NULL,
    payment_method ENUM('UPI', 'Cash', 'Card') NOT NULL DEFAULT 'UPI',
    discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_discount CHECK (discount >= 0),
    INDEX idx_sale_datetime (sale_datetime),
    INDEX idx_payment_method (payment_method)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Table 3: sale_items (Line Items Detail)
-- Normalized line items linking products to parent sale orders
-- -----------------------------------------------------
CREATE TABLE sale_items (
    sale_item_id VARCHAR(40) NOT NULL PRIMARY KEY,
    sale_id VARCHAR(30) NOT NULL,
    product_id VARCHAR(30) NOT NULL,
    quantity_plates INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_quantity CHECK (quantity_plates > 0),
    CONSTRAINT chk_unit_price CHECK (unit_price > 0),
    CONSTRAINT fk_sale_items_sale FOREIGN KEY (sale_id)
        REFERENCES sales(sale_id) ON DELETE CASCADE,
    CONSTRAINT fk_sale_items_product FOREIGN KEY (product_id)
        REFERENCES products(product_id) ON DELETE RESTRICT,
    INDEX idx_items_sale_id (sale_id),
    INDEX idx_items_product_id (product_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Table 4: ingredients
-- Raw material master catalog with unit costs and safety thresholds
-- -----------------------------------------------------
CREATE TABLE ingredients (
    ingredient_id VARCHAR(30) NOT NULL PRIMARY KEY,
    ingredient_name VARCHAR(100) NOT NULL,
    unit VARCHAR(20) NOT NULL, -- 'pcs', 'kg', 'liters'
    unit_cost DECIMAL(10, 2) NOT NULL,
    reorder_level DECIMAL(10, 2) NOT NULL DEFAULT 10.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_unit_cost CHECK (unit_cost >= 0),
    CONSTRAINT chk_reorder_level CHECK (reorder_level >= 0)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Table 5: inventory_transactions
-- Physical stock ledger tracking purchases, consumption, and waste.
-- Quantity Convention: Always stored as a positive quantity;
-- transaction_type determines ledger movement direction:
--   - 'PURCHASE': Increases physical on-hand stock (+quantity)
--   - 'CONSUMPTION': Deducts ingredient usage from sales (-quantity)
--   - 'WASTE': Deducts physical spoilage or handling loss (-quantity)
-- -----------------------------------------------------
CREATE TABLE inventory_transactions (
    transaction_id VARCHAR(30) NOT NULL PRIMARY KEY,
    transaction_date DATE NOT NULL,
    ingredient_id VARCHAR(30) NOT NULL,
    transaction_type ENUM('PURCHASE', 'CONSUMPTION', 'WASTE') NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    reference_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_inv_qty CHECK (quantity > 0),
    CONSTRAINT fk_inv_ingredient FOREIGN KEY (ingredient_id)
        REFERENCES ingredients(ingredient_id) ON DELETE RESTRICT,
    INDEX idx_inv_date (transaction_date),
    INDEX idx_inv_type (transaction_type),
    INDEX idx_inv_ingredient (ingredient_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Table 6: daily_expenses
-- Operating overheads (rent, packaging dona, utilities, gas, transport)
-- -----------------------------------------------------
CREATE TABLE daily_expenses (
    expense_id VARCHAR(30) NOT NULL PRIMARY KEY,
    expense_date DATE NOT NULL,
    expense_category VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_expense_amount CHECK (amount > 0),
    INDEX idx_expense_date (expense_date),
    INDEX idx_expense_category (expense_category)
) ENGINE=InnoDB;

-- =====================================================================
-- DATABASE ANALYTICAL VIEWS
-- =====================================================================

-- -----------------------------------------------------
-- View 1: vw_dashboard_kpis
-- High-level cumulative executive summary
-- -----------------------------------------------------
CREATE OR REPLACE VIEW vw_dashboard_kpis AS
SELECT
    COUNT(DISTINCT s.sale_id) AS total_orders,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(SUM(si.quantity_plates * si.unit_price), 0.00) AS gross_revenue,
    COALESCE(SUM(s.discount), 0.00) AS total_discounts,
    COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0.00) AS net_revenue,
    COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00) AS total_cogs,
    COALESCE(
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - 
        SUM(si.quantity_plates * p.ingredient_cost_per_plate), 
        0.00
    ) AS gross_profit,
    ROUND(
        COALESCE(
            ((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) / 
            NULLIF(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0)) * 100, 
            0.0
        ), 1
    ) AS gross_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id;

-- -----------------------------------------------------
-- View 2: vw_product_performance
-- Menu variety margin ranking and volume contribution
-- -----------------------------------------------------
CREATE OR REPLACE VIEW vw_product_performance AS
SELECT
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_margin,
    COALESCE(SUM(si.quantity_plates), 0) AS total_plates_sold,
    COALESCE(SUM(si.quantity_plates * si.unit_price), 0.00) AS gross_revenue,
    -- Proportionally allocated order discounts
    COALESCE(SUM(s.discount), 0.00) AS allocated_discounts,
    COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0.00) AS net_revenue,
    COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00) AS total_cogs,
    COALESCE(
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - 
        SUM(si.quantity_plates * p.ingredient_cost_per_plate), 
        0.00
    ) AS gross_profit,
    ROUND(
        COALESCE(
            (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
            NULLIF(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0)) * 100,
            0.0
        ), 1
    ) AS gross_margin_pct
FROM products p
LEFT JOIN sale_items si ON p.product_id = si.product_id
LEFT JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate;

-- -----------------------------------------------------
-- View 3: vw_daily_financial_summary
-- Daily aggregated revenue, COGS, profit, expenses, and operating profit
-- -----------------------------------------------------
CREATE OR REPLACE VIEW vw_daily_financial_summary AS
WITH DailySalesAgg AS (
    SELECT
        DATE(s.sale_datetime) AS sale_date,
        COUNT(DISTINCT s.sale_id) AS orders_count,
        SUM(si.quantity_plates) AS plates_sold,
        SUM(si.quantity_plates * si.unit_price) - SUM(s.discount) AS net_revenue,
        SUM(si.quantity_plates * p.ingredient_cost_per_plate) AS cogs,
        (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate) AS gross_profit
    FROM sales s
    JOIN sale_items si ON s.sale_id = si.sale_id
    JOIN products p ON si.product_id = p.product_id
    GROUP BY DATE(s.sale_datetime)
),
DailyExpensesAgg AS (
    SELECT
        expense_date,
        SUM(amount) AS total_expenses
    FROM daily_expenses
    GROUP BY expense_date
),
DailyWasteAgg AS (
    SELECT
        t.transaction_date,
        SUM(t.quantity * i.unit_cost) AS total_waste_cost
    FROM inventory_transactions t
    JOIN ingredients i ON t.ingredient_id = i.ingredient_id
    WHERE t.transaction_type = 'WASTE'
    GROUP BY t.transaction_date
)
SELECT
    ds.sale_date,
    DAYNAME(ds.sale_date) AS day_of_week,
    ds.orders_count,
    ds.plates_sold,
    ROUND(ds.net_revenue, 2) AS net_revenue,
    ROUND(ds.cogs, 2) AS cogs,
    ROUND(ds.gross_profit, 2) AS gross_profit,
    ROUND(COALESCE(dw.total_waste_cost, 0.00), 2) AS waste_cost,
    ROUND(COALESCE(de.total_expenses, 0.00), 2) AS operating_expenses,
    ROUND(ds.gross_profit - COALESCE(de.total_expenses, 0.00), 2) AS estimated_operating_profit
FROM DailySalesAgg ds
LEFT JOIN DailyExpensesAgg de ON ds.sale_date = de.expense_date
LEFT JOIN DailyWasteAgg dw ON ds.sale_date = dw.transaction_date;

-- -----------------------------------------------------
-- View 4: vw_inventory_status
-- Real-time stock runway, on-hand balances, and threshold status
-- -----------------------------------------------------
CREATE OR REPLACE VIEW vw_inventory_status AS
WITH StockLedger AS (
    SELECT
        ingredient_id,
        SUM(CASE WHEN transaction_type = 'PURCHASE' THEN quantity ELSE 0 END) AS total_purchased,
        SUM(CASE WHEN transaction_type = 'CONSUMPTION' THEN quantity ELSE 0 END) AS total_consumed,
        SUM(CASE WHEN transaction_type = 'WASTE' THEN quantity ELSE 0 END) AS total_wasted
    FROM inventory_transactions
    GROUP BY ingredient_id
)
SELECT
    i.ingredient_id,
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    i.reorder_level,
    COALESCE(sl.total_purchased, 0.00) AS total_purchased,
    COALESCE(sl.total_consumed, 0.00) AS total_consumed,
    COALESCE(sl.total_wasted, 0.00) AS total_wasted,
    ROUND(
        COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00),
        2
    ) AS current_stock,
    ROUND(
        (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) * i.unit_cost,
        2
    ) AS inventory_value,
    CASE
        WHEN (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) <= (i.reorder_level * 0.5) THEN 'Critical'
        WHEN (COALESCE(sl.total_purchased, 0.00) - COALESCE(sl.total_consumed, 0.00) - COALESCE(sl.total_wasted, 0.00)) <= i.reorder_level THEN 'Low'
        ELSE 'Healthy'
    END AS stock_status
FROM ingredients i
LEFT JOIN StockLedger sl ON i.ingredient_id = sl.ingredient_id;
