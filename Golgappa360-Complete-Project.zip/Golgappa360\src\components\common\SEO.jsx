import React, { useEffect } from 'react';
import { siteConfig } from '../../config/siteConfig';

export const SEO = ({ title, description }) => {
  useEffect(() => {
    const pageTitle = title
      ? `${title} | ${siteConfig.academy.name}`
      : siteConfig.SEO.siteTitle;
    document.title = pageTitle;

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute(
        'content',
        description || siteConfig.SEO.defaultDescription
      );
    }
  }, [title, description]);

  return null;
};

export default SEO;
