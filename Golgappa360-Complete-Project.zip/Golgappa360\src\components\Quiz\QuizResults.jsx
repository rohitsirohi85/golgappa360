import React from 'react';

/**
 * QuizResults — Cinematic Observatory Mission Results Screen
 * Features:
 * - Dynamic Rank Title & Performance Message based on score percentage
 * - Score Metrics (Score / 10, Accuracy %, Correct, Incorrect)
 * - Cosmic Profile Scorecard (Knowledge, Exploration, Curiosity)
 * - Action buttons: "TRY AGAIN", "EXPLORE THE STARS →", "EXPLORE CONSTELLATIONS →"
 * - Best score tracker & reset capability
 */
export default function QuizResults({
  score,
  totalQuestions,
  difficulty,
  onRetry,
  bestScore,
  onResetBestScore,
}) {
  const percentage = Math.round((score / totalQuestions) * 100);
  const incorrect = totalQuestions - score;

  // Derive Rank Title & Feedback Message
  let rankTitle = 'STELLAR APPRENTICE';
  let rankMessage = 'Every astronomer starts by looking up. The cosmos holds endless discoveries waiting for you.';
  let rankColor = '#f59e0b'; // Amber

  if (percentage >= 90) {
    rankTitle = 'MASTER OF THE STARS';
    rankMessage = 'You could navigate the stellar catalog with confidence. Your cosmic knowledge rivals experienced astronomers.';
    rankColor = '#38bdf8'; // Cyan
  } else if (percentage >= 70) {
    rankTitle = 'COSMIC EXPLORER';
    rankMessage = 'You have a strong understanding of the night sky, stellar lifecycles, and astrophysical mechanics.';
    rankColor = '#818cf8'; // Indigo
  } else if (percentage >= 50) {
    rankTitle = 'RISING STARGAZER';
    rankMessage = 'You’re on the right trajectory. Keep exploring the catalogs and charting the celestial vault.';
    rankColor = '#c084fc'; // Purple
  }

  // Scroll helpers
  const handleScrollToStars = () => {
    const el = document.getElementById('stars');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScrollToConstellations = () => {
    const el = document.getElementById('constellations');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="w-full max-w-3xl mx-auto rounded-3xl glass-surface border border-white/10 p-6 sm:p-10 shadow-[0_25px_60px_rgba(0,0,0,0.8)] text-center relative overflow-hidden">
      {/* Background Radiance */}
      <div
        aria-hidden="true"
        className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-[140px] pointer-events-none opacity-40"
        style={{ backgroundColor: rankColor }}
      />

      {/* Top Header Badge */}
      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/50 border border-white/10 text-xs font-mono uppercase tracking-[0.25em] text-cyan-300 mb-6">
        <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: rankColor }} />
        <span>MISSION COMPLETE // {difficulty.toUpperCase()} EVALUATION</span>
      </div>

      {/* Rank Title */}
      <h3
        className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-transparent bg-clip-text mb-3"
        style={{
          backgroundImage: `linear-gradient(to right, #ffffff, ${rankColor}, #ffffff)`,
        }}
      >
        {rankTitle}
      </h3>

      {/* Encouraging Feedback Message */}
      <p className="font-sans text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed mb-8">
        &ldquo;{rankMessage}&rdquo;
      </p>

      {/* Primary Score Ring & Metrics Strip */}
      <div className="p-6 rounded-2xl bg-[#020308]/60 border border-white/8 max-w-lg mx-auto mb-8">
        <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 block mb-1">
          YOUR MISSION SCORE
        </span>
        <div className="font-display text-5xl sm:text-6xl font-semibold text-white flex items-center justify-center gap-2 mb-2">
          <span>{score}</span>
          <span className="text-2xl text-slate-500 font-normal">/ {totalQuestions}</span>
        </div>
        <span className="text-sm font-mono text-cyan-300 font-bold block mb-4">
          ACCURACY: {percentage}%
        </span>

        {/* Detailed Metrics Grid */}
        <div className="grid grid-cols-3 gap-2.5 pt-4 border-t border-white/10 text-xs font-mono">
          <div className="p-2.5 rounded-xl bg-white/5">
            <span className="text-[9px] uppercase text-slate-400 block">CORRECT</span>
            <span className="text-emerald-400 font-bold text-base">{score}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <span className="text-[9px] uppercase text-slate-400 block">INCORRECT</span>
            <span className="text-rose-400 font-bold text-base">{incorrect}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <span className="text-[9px] uppercase text-slate-400 block">BEST RECORD</span>
            <span className="text-amber-300 font-bold text-base">
              {bestScore !== null ? `${bestScore}/${totalQuestions}` : `${score}/${totalQuestions}`}
            </span>
          </div>
        </div>

        {bestScore !== null && (
          <div className="mt-3 text-right">
            <button
              type="button"
              onClick={onResetBestScore}
              className="text-[10px] font-mono text-slate-500 hover:text-rose-400 underline cursor-pointer"
            >
              Reset Saved Record
            </button>
          </div>
        )}
      </div>

      {/* Cosmic Profile Scorecard */}
      <div className="p-5 rounded-2xl bg-cyan-950/15 border border-cyan-500/20 max-w-lg mx-auto mb-10 text-left">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold flex items-center gap-1.5">
            <span>👤</span>
            <span>YOUR COSMIC PROFILE</span>
          </span>
          <span className="text-[10px] font-mono text-slate-500">
            SESSION TELEMETRY
          </span>
        </div>

        <div className="grid grid-cols-3 gap-3 text-xs font-mono">
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-white/5">
            <span className="text-[9px] text-slate-400 block uppercase">KNOWLEDGE</span>
            <span className="text-white font-bold text-sm">{percentage}%</span>
          </div>
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-white/5">
            <span className="text-[9px] text-slate-400 block uppercase">EXPLORATION</span>
            <span className="text-cyan-300 font-bold text-sm">{score} / {totalQuestions}</span>
          </div>
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-white/5">
            <span className="text-[9px] text-slate-400 block uppercase">CURIOSITY</span>
            <span className="text-amber-300 font-bold text-sm">MAXIMUM</span>
          </div>
        </div>
      </div>

      {/* Action Buttons Strip */}
      <div className="flex flex-wrap items-center justify-center gap-3.5">
        <button
          type="button"
          onClick={onRetry}
          className="px-7 py-3 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs tracking-wider uppercase font-bold transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:scale-105 cursor-pointer"
        >
          TRY AGAIN
        </button>

        <button
          type="button"
          onClick={handleScrollToStars}
          className="px-6 py-3 rounded-full glass-surface border border-white/15 hover:border-cyan-400/50 hover:bg-white/10 text-slate-200 hover:text-white font-mono text-xs tracking-wider uppercase transition-all cursor-pointer flex items-center gap-2"
        >
          <span>EXPLORE THE STARS</span>
          <span>→</span>
        </button>

        <button
          type="button"
          onClick={handleScrollToConstellations}
          className="px-6 py-3 rounded-full glass-surface border border-white/15 hover:border-indigo-400/50 hover:bg-white/10 text-slate-200 hover:text-white font-mono text-xs tracking-wider uppercase transition-all cursor-pointer flex items-center gap-2"
        >
          <span>EXPLORE CONSTELLATIONS</span>
          <span>→</span>
        </button>
      </div>
    </div>
  );
}
