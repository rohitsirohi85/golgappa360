import React from "react";
import { Link } from "react-router-dom";

export const Logo = ({ size = "default", withLink = true, withTagline = false }) => {
  const isLarge = size === "large";

  const content = (
    <div className="flex items-center gap-2.5 group select-none">
      {/* Brand Icon combining Search Lens + Soundwave + Musical Note + Lyric Quote */}
      <div className={`relative flex items-center justify-center rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[1.5px] shadow-lg shadow-purple-500/20 group-hover:shadow-purple-500/40 transition-all duration-300 ${
        isLarge ? "w-11 h-11" : "w-9 h-9"
      }`}>
        <div className="w-full h-full bg-[#0d0e15] rounded-[10.5px] flex items-center justify-center overflow-hidden relative">
          {/* Subtle glowing center */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-cyan-500/10" />

          {/* SVG Custom Lens + Note + Soundwave mark */}
          <svg
            className={`relative z-10 text-white transition-transform duration-300 group-hover:scale-105 ${
              isLarge ? "w-6 h-6" : "w-5 h-5"
            }`}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {/* Search Lens Ring */}
            <circle cx="10.5" cy="10.5" r="6.5" className="stroke-purple-400" />
            <path d="m15.5 15.5 4 4" className="stroke-purple-400" />

            {/* Note Stem & Flag inside Lens */}
            <path d="M12 7.5v5" className="stroke-cyan-300" strokeWidth="2" />
            <path d="M12 7.5c1.2 0 2.2-.4 2.8-1.2" className="stroke-cyan-300" strokeWidth="1.8" />
            <circle cx="10" cy="12.5" r="1.5" className="fill-cyan-400 stroke-none" />

            {/* Lyric / Soundwave bars on right */}
            <line x1="18" y1="8" x2="20" y2="8" className="stroke-purple-300/80" strokeWidth="1.8" />
            <line x1="17.5" y1="11" x2="21" y2="11" className="stroke-cyan-300/80" strokeWidth="1.8" />
          </svg>
        </div>
      </div>

      {/* Brand Text */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className={`font-bold tracking-tight text-white font-['Space_Grotesk'] ${
            isLarge ? "text-2xl" : "text-lg"
          }`}>
            Lyric<span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">Lens</span>
          </span>
          <span className="px-1.5 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
            AI
          </span>
        </div>
        {withTagline && (
          <span className="text-xs text-slate-400 tracking-wide">
            Remember the lyric. Find the song.
          </span>
        )}
      </div>
    </div>
  );

  if (withLink) {
    return (
      <Link to="/" className="inline-flex focus:outline-none">
        {content}
      </Link>
    );
  }

  return content;
};
