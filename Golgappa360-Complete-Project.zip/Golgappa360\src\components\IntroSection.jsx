import React from 'react';

/**
 * IntroSection — Elegant, intentionally simple introduction
 * Heading: “EVERY STAR HAS A STORY.”
 * Paragraph: “From quiet red dwarfs to spectacular supergiants, stars are the engines that shape galaxies, create elements, and illuminate the universe.”
 * Visual: Minimal glowing stellar orb with orbital trajectory lines.
 */
export default function IntroSection() {
  return (
    <section
      id="intro"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Soft Glow */}
      <div
        aria-hidden="true"
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-cyan-950/20 via-indigo-950/20 to-purple-950/20 blur-[120px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left / Main Text Column */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Eyebrow Label */}
            <div className="inline-flex items-center gap-2 px-3 py-1 mb-6 rounded-full glass-surface border border-white/10 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>COSMIC FOUNDATION</span>
            </div>

            {/* Heading */}
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight text-white leading-[1.12] mb-6">
              EVERY STAR <br className="hidden sm:inline" />
              HAS A{' '}
              <span className="bg-gradient-to-r from-amber-300 via-cyan-200 to-indigo-300 bg-clip-text text-transparent">
                STORY.
              </span>
            </h2>

            {/* Paragraph */}
            <p className="font-sans text-lg sm:text-xl text-slate-300/85 leading-relaxed font-normal max-w-2xl">
              From quiet red dwarfs to spectacular supergiants, stars are the engines
              that shape galaxies, create elements, and illuminate the universe.
            </p>

            {/* Minimal scientific metadata indicator */}
            <div className="mt-8 flex items-center gap-6 text-xs font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">01</span>
                <span>NUCLEOSYNTHESIS</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-amber-400">02</span>
                <span>GRAVITATIONAL EQUILIBRIUM</span>
              </div>
            </div>
          </div>

          {/* Right Column: Minimal Visual Element (Glowing Stellar Orb with Orbital Line) */}
          <div className="lg:col-span-5 flex items-center justify-center">
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
              {/* Outer Orbital Ellipse */}
              <div
                aria-hidden="true"
                className="absolute inset-0 rounded-full border border-cyan-400/20 border-dashed animate-slow-orbit pointer-events-none"
              />

              {/* Secondary Inclined Orbital Ring */}
              <div
                aria-hidden="true"
                className="absolute inset-6 rounded-full border border-purple-400/20 rotate-45 pointer-events-none"
              >
                {/* Orbital Node Marker */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]" />
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
              </div>

              {/* Minimal Glowing Stellar Orb */}
              <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full flex items-center justify-center">
                {/* Aura */}
                <div className="absolute -inset-4 rounded-full bg-gradient-to-r from-cyan-400/30 via-indigo-500/20 to-amber-400/30 blur-xl animate-pulse-glow" />

                {/* Orb Core */}
                <div className="relative w-full h-full rounded-full bg-gradient-to-tr from-cyan-400 via-sky-200 to-white shadow-[0_0_30px_rgba(56,189,248,0.6),inset_0_0_15px_rgba(255,255,255,0.9)] border border-cyan-200/50 flex items-center justify-center">
                  {/* Inner Core Pulse */}
                  <div className="w-6 h-6 rounded-full bg-white blur-[2px] animate-pulse" />
                </div>
              </div>

              {/* Subtle Astronomical Crosshairs */}
              <div className="absolute inset-x-0 top-1/2 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent pointer-events-none" />
              <div className="absolute inset-y-0 left-1/2 w-[1px] bg-gradient-to-b from-transparent via-cyan-400/20 to-transparent pointer-events-none" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
