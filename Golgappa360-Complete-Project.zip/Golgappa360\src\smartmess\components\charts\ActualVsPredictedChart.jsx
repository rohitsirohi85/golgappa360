import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { ACTUAL_VS_PREDICTED } from '../../data/mockWasteData';
import { BrainCircuit } from 'lucide-react';

const CustomBenchmarkTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const diff = data.actualKg - data.predictedKg;
    return (
      <div className="rounded-lg bg-white border border-[#E4EAE5] p-3 shadow-lg text-xs space-y-1.5 min-w-[200px]">
        <div className="font-semibold text-[#25332D] border-b border-[#EEF2EF] pb-1 flex justify-between items-center">
          <span>{label}</span>
          <span className="text-[10px] font-mono text-[#16865B]">Benchmark Val</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Baseline Prep Waste:</span>
          <span className="font-mono text-[#77847C] line-through">{data.baselineRuleKg} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Actual Waste:</span>
          <span className="font-mono font-semibold text-[#0284C7]">{data.actualKg} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#16865B] font-medium">AI Model Forecast:</span>
          <span className="font-mono font-bold text-[#16865B]">{data.predictedKg} kg</span>
        </div>
        <div className="pt-1 text-[10px] flex justify-between border-t border-[#EEF2EF] text-[#77847C] font-mono">
          <span>Forecast Variance:</span>
          <span className={diff > 0 ? 'text-[#D97706] font-semibold' : 'text-[#16865B] font-semibold'}>
            {diff > 0 ? `+${diff} kg` : `${diff} kg`}
          </span>
        </div>
      </div>
    );
  }
  return null;
};

export const ActualVsPredictedChart = () => {
  return (
    <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 shadow-xs relative overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
              Actual vs. Predicted Waste
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] flex items-center gap-1">
                <BrainCircuit className="w-3 h-3" />
                ML Validation Benchmark
              </span>
            </h3>
          </div>
          <p className="text-xs text-[#77847C] mt-0.5">
            Model inference performance benchmark vs unoptimized baseline heuristic
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-[#77847C] bg-[#F8FAF8] px-3 py-1.5 rounded-lg border border-[#E4EAE5]">
          <span className="w-2 h-2 rounded-full bg-[#16865B]"></span>
          <span className="font-mono text-[11px] text-[#16865B] font-medium">R² = 0.938 (Regression Pipeline)</span>
        </div>
      </div>

      <div className="h-64 sm:h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={ACTUAL_VS_PREDICTED} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
            <XAxis
              dataKey="day"
              stroke="#D2DDD4"
              tick={{ fill: '#77847C', fontSize: 11 }}
              axisLine={{ stroke: '#E4EAE5' }}
              tickLine={false}
            />
            <YAxis
              stroke="#D2DDD4"
              tick={{ fill: '#77847C', fontSize: 11 }}
              unit=" kg"
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomBenchmarkTooltip />} />
            <Legend
              verticalAlign="top"
              align="right"
              wrapperStyle={{ paddingBottom: '12px', fontSize: '11px', color: '#77847C' }}
              iconSize={8}
            />
            {/* Unoptimized heuristic baseline */}
            <Bar
              dataKey="baselineRuleKg"
              name="Unoptimized Baseline (kg)"
              fill="#E4EAE5"
              radius={[4, 4, 0, 0]}
              maxBarSize={28}
            />
            {/* Actual Recorded Waste */}
            <Line
              type="monotone"
              dataKey="actualKg"
              name="Actual Waste (kg)"
              stroke="#0284C7"
              strokeWidth={2.5}
              dot={{ r: 4, fill: '#0284C7' }}
              activeDot={{ r: 6 }}
            />
            {/* AI Model Predicted Waste */}
            <Line
              type="monotone"
              dataKey="predictedKg"
              name="Predicted Waste (kg)"
              stroke="#16865B"
              strokeWidth={2.5}
              strokeDasharray="4 2"
              dot={{ r: 4, fill: '#16865B' }}
              activeDot={{ r: 6 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3 pt-3 border-t border-[#EEF2EF] flex flex-wrap items-center justify-between text-[11px] text-[#77847C]">
        <div className="flex items-center gap-3">
          <span className="text-[#16865B] font-medium">
            MAE: 4.15 kg / meal
          </span>
          <span className="text-[#D2DDD4]">|</span>
          <span className="text-[#77847C]">
            Avg Waste Slashed vs Baseline: <strong className="text-[#25332D]">~23.4%</strong>
          </span>
        </div>
        <span className="text-[#77847C] font-mono text-[10px]">
          [Synthetic Model Evaluation Output]
        </span>
      </div>
    </div>
  );
};
