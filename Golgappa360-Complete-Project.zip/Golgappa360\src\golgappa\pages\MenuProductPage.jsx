import React, { useState } from 'react';
import {
  UtensilsCrossed,
  Plus,
  TrendingUp,
  Percent,
  IndianRupee,
  Layers,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Award,
  Sparkles
} from 'lucide-react';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard, GlassPanel } from '../components/glass/GlassCard';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';

export function MenuProductPage() {
  const { menuData, handleAddMenuItem, searchQuery } = useGolgappa();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    selling_price: '',
    cost_price: '',
    category_id: '2',
    category_name: 'Flavoured Specials',
    pieces_per_plate: '6',
    flavour_profile: 'Signature Spice Blend',
    description: ''
  });

  const items = menuData?.items || [];
  const categories = menuData?.categories || [];
  const highlights = menuData?.highlights || {};

  const filteredItems = items.filter((item) => {
    const cat = item.category || item.category_name || '';
    const matchesCategory = selectedCategory === 'All' || cat.toLowerCase().includes(selectedCategory.toLowerCase());
    const name = item.name || item.product_name || '';
    const flavour = item.flavour_profile || cat || '';
    const code = item.item_code || item.product_id || '';
    const matchesSearch = !searchQuery || 
      name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flavour.toLowerCase().includes(searchQuery.toLowerCase()) ||
      code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Top & bottom performers
  const sortedByRevenue = [...items].sort((a, b) => (b.total_revenue || b.totalRevenue || 0) - (a.total_revenue || a.totalRevenue || 0));
  const topRevenueItem = sortedByRevenue[0] || items[0];
  const sortedByMargin = [...items].sort((a, b) => (b.margin_pct || b.grossMarginPct || 0) - (a.margin_pct || a.grossMarginPct || 0));
  const topMarginItem = sortedByMargin[0] || items[0];
  const bottomVolumeItem = sortedByRevenue[sortedByRevenue.length - 1] || items[items.length - 1];

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    const sp = parseFloat(formData.selling_price);
    const cp = parseFloat(formData.cost_price);

    if (isNaN(sp) || sp <= 0) {
      setFormError('Please enter a valid selling price greater than ₹0.');
      return;
    }
    if (isNaN(cp) || cp <= 0) {
      setFormError('Please enter a valid cost price greater than ₹0.');
      return;
    }
    if (cp >= sp) {
      setFormError('Cost price cannot be equal to or greater than selling price.');
      return;
    }

    setIsSubmitting(true);
    const res = await handleAddMenuItem(formData);
    setIsSubmitting(false);

    if (res.success) {
      setIsAddModalOpen(false);
      setFormData({
        name: '',
        selling_price: '',
        cost_price: '',
        category_id: '2',
        category_name: 'Flavoured Specials',
        pieces_per_plate: '6',
        flavour_profile: 'Signature Spice Blend',
        description: ''
      });
    } else {
      setFormError(res.error || 'Failed to add item');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/[0.08]">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F4F1] font-sans">
            Menu & Product Economics
          </h2>
          <p className="text-xs text-[#929195] mt-0.5">
            Unit recipe costing, counter selling prices, contribution margins & volume performance
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#A7D78A] text-[#171717] text-xs font-bold hover:bg-[#96C679] transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Variety</span>
        </button>
      </div>

      {/* Performance Highlights Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Top Revenue */}
        <GlassCard className="p-4.5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-2xl bg-[#A7D78A]/15 border border-[#A7D78A]/30 text-[#A7D78A] flex items-center justify-center shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold text-[#929195] uppercase tracking-wider">Top Revenue Leader</p>
            <h4 className="text-sm font-bold text-[#F5F4F1] truncate">{topRevenueItem?.name || topRevenueItem?.product_name || 'Classic Golgappa'}</h4>
            <p className="text-xs text-[#A7D78A] font-semibold mt-0.5">
              ₹{(topRevenueItem?.total_revenue || topRevenueItem?.totalRevenue || 0).toLocaleString('en-IN')} (Top sales contributor)
            </p>
          </div>
        </GlassCard>

        {/* Top Margin */}
        <GlassCard className="p-4.5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-2xl bg-[#EAB64B]/15 border border-[#EAB64B]/30 text-[#EAB64B] flex items-center justify-center shrink-0">
            <Percent className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold text-[#929195] uppercase tracking-wider">Highest Margin Variety</p>
            <h4 className="text-sm font-bold text-[#F5F4F1] truncate">{topMarginItem?.name || topMarginItem?.product_name || 'Spicy Pani Puri'}</h4>
            <p className="text-xs text-[#EAB64B] font-semibold mt-0.5">
              {topMarginItem?.margin_pct || topMarginItem?.grossMarginPct || 73.7}% Gross Margin
            </p>
          </div>
        </GlassCard>

        {/* Growth Driver */}
        <GlassCard className="p-4.5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-2xl bg-[#D98768]/15 border border-[#D98768]/30 text-[#D98768] flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold text-[#929195] uppercase tracking-wider">High Ticket Driver</p>
            <h4 className="text-sm font-bold text-[#F5F4F1] truncate">Dahi Puri (6 pcs)</h4>
            <p className="text-xs text-[#D98768] font-semibold mt-0.5">
              ₹60/plate • ₹42.00 unit contribution
            </p>
          </div>
        </GlassCard>
      </div>

      {/* Categories Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {['All', 'Classic', 'Flavoured', 'Chaat'].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-white/20 text-[#F5F4F1] border border-white/25 shadow-xs'
                : 'bg-white/[0.05] text-[#929195] hover:text-[#F5F4F1] border border-transparent'
            }`}
          >
            {cat === 'All' ? 'All Varieties (6)' : cat}
          </button>
        ))}
      </div>

      {/* Product Table Glass Card */}
      <GlassCard className="p-5 sm:p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#F5F4F1]">
            <thead className="bg-white/[0.04] text-[#929195] font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3.5 rounded-l-xl">SKU Code</th>
                <th className="px-4 py-3.5">Product Name & Profile</th>
                <th className="px-4 py-3.5">Portion</th>
                <th className="px-4 py-3.5 text-right">Price</th>
                <th className="px-4 py-3.5 text-right">COGS</th>
                <th className="px-4 py-3.5 text-right">Unit Profit</th>
                <th className="px-4 py-3.5 text-center">Gross Margin %</th>
                <th className="px-4 py-3.5 text-center">Plates Sold</th>
                <th className="px-4 py-3.5 text-right">Gross Profit (₹)</th>
                <th className="px-4 py-3.5 text-center rounded-r-xl">Rank</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-xs text-[#929195]">
                    No menu varieties found matching your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, idx) => {
                const sp = Number(item.selling_price || 30);
                const cp = Number(item.cost_price || item.ingredient_cost_per_plate || 8.4);
                const unitMargin = (sp - cp).toFixed(2);
                const marginPct = item.margin_pct || item.grossMarginPct || (((sp - cp) / sp) * 100).toFixed(1);
                const platesSold = item.plates_sold !== undefined ? item.plates_sold : (item.totalUnitsSold || 0);
                const grossProfit = item.gross_profit !== undefined ? item.gross_profit : (item.grossProfit || 0);

                return (
                  <tr key={item.id || item.product_id || idx} className="hover:bg-white/[0.04] transition-colors">
                    <td className="px-4 py-4 font-mono font-bold text-[#A7D78A]">
                      {item.item_code || item.product_id}
                    </td>
                    <td className="px-4 py-4">
                      <p className="font-bold text-[#F5F4F1] text-sm">{item.name || item.product_name}</p>
                      <p className="text-[11px] text-[#929195] mt-0.5">{item.flavour_profile || item.category}</p>
                    </td>
                    <td className="px-4 py-4">
                      <span className="px-2 py-0.5 rounded-md bg-white/[0.08] text-[#B8B7B9] text-[11px] font-semibold">
                        {item.pieces_per_plate || 6} pcs / plate
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right font-bold text-sm text-[#F5F4F1]">
                      ₹{sp.toFixed(2)}
                    </td>
                    <td className="px-4 py-4 text-right text-[#929195] font-mono">
                      ₹{cp.toFixed(2)}
                    </td>
                    <td className="px-4 py-4 text-right font-bold text-[#A7D78A] font-mono">
                      ₹{unitMargin}
                    </td>
                    <td className="px-4 py-4 text-center">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#A7D78A]/15 text-[#A7D78A] border border-[#A7D78A]/30 font-bold text-xs">
                        {marginPct}%
                      </span>
                    </td>
                    <td className="px-4 py-4 text-center font-bold">
                      {platesSold.toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-4 text-right font-bold text-[#F5F4F1] font-mono">
                      ₹{Math.round(grossProfit).toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-4 text-center">
                      <Badge variant={idx === 0 ? 'success' : idx === filteredItems.length - 1 ? 'neutral' : 'saffron'} size="sm">
                        #{idx + 1}
                      </Badge>
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Recipe derivation box */}
      <div className="bg-white/[0.04] backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-[#F5F4F1]">Unit COGS Recipe Derivation</h4>
          <p className="text-xs text-[#929195] mt-1 max-w-2xl leading-relaxed">
            Standard Golgappa plate (6 pcs): 6 puris (₹2.10) + 40g aloo-chana mash (₹1.80) + 120ml flavoured mint/tamarind water (₹3.20) + spice seasoning and paper dona (₹1.30) = Total recipe baseline <strong>₹8.40</strong> per plate. Selling at ₹30 generates a healthy <strong>72.0% gross margin</strong>.
          </p>
        </div>
        <div className="px-4 py-2.5 bg-white/[0.06] rounded-2xl border border-white/10 text-center shrink-0">
          <p className="text-[10px] font-bold uppercase text-[#929195]">Stall Avg Margin</p>
          <p className="text-xl font-bold text-[#A7D78A]">72.6%</p>
        </div>
      </div>

      {/* Add Menu Item Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Golgappa Variety"
        subtitle="Introduce a new flavour, loaded chaat, or festival special item"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-xl bg-[#E58B79]/20 border border-[#E58B79]/40 text-xs text-[#E58B79] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Variety / Product Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Garlic & Black Pepper Pani Puri"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
                Selling Price (₹)
              </label>
              <input
                type="number"
                step="0.5"
                required
                placeholder="40.00"
                value={formData.selling_price}
                onChange={(e) => setFormData({ ...formData, selling_price: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
                Unit Ingredient Cost (₹)
              </label>
              <input
                type="number"
                step="0.1"
                required
                placeholder="10.50"
                value={formData.cost_price}
                onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
                Category
              </label>
              <select
                value={formData.category_name}
                onChange={(e) => setFormData({ ...formData, category_name: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
              >
                <option value="Classic Pani Puri">Classic Pani Puri</option>
                <option value="Flavoured Specials">Flavoured Specials</option>
                <option value="Chaat & Loaded Puris">Chaat & Loaded Puris</option>
                <option value="Custom & Dry Add-ons">Custom & Dry Add-ons</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
                Pieces Per Plate
              </label>
              <input
                type="number"
                min="1"
                max="12"
                value={formData.pieces_per_plate}
                onChange={(e) => setFormData({ ...formData, pieces_per_plate: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Flavour Profile
            </label>
            <input
              type="text"
              placeholder="e.g. Smoky Roasted Garlic & Hing"
              value={formData.flavour_profile}
              onChange={(e) => setFormData({ ...formData, flavour_profile: e.target.value })}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#929195] hover:text-[#F5F4F1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#A7D78A] text-[#171717] hover:bg-[#96C679] transition-colors"
            >
              {isSubmitting ? 'Adding...' : 'Save Variety'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
