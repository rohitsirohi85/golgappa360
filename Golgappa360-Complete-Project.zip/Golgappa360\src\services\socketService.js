import { io } from 'socket.io-client';

const getDefaultSocketUrl = () => {
  if (typeof window !== 'undefined' && window.location && window.location.hostname && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
    return `${window.location.protocol}//${window.location.hostname}:5000`;
  }
  return 'http://localhost:5000';
};

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || getDefaultSocketUrl();

class SocketService {
  constructor() {
    this.socket = null;
    this.status = 'disconnected'; // 'connected' | 'reconnecting' | 'disconnected'
    this.statusListeners = new Set();
    this.joinedRooms = new Set();
  }

  /**
   * Connect to Socket.IO server with JWT token
   */
  connect(token = null) {
    if (this.socket && this.socket.connected) {
      return this.socket;
    }

    const authToken = token || localStorage.getItem('ev_smart_token') || localStorage.getItem('token');

    this.socket = io(SOCKET_URL, {
      auth: { token: authToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 15,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 10000,
    });

    this.setupListeners();
    return this.socket;
  }

  setupListeners() {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log(`🔌 [Socket.IO] Connected to ${SOCKET_URL} (ID: ${this.socket.id})`);
      this.updateStatus('connected');

      // Re-join any previously tracked rooms upon reconnection
      this.joinedRooms.forEach((roomEvent) => {
        const [action, id] = roomEvent.split(':');
        this.socket.emit(action, id);
      });
    });

    this.socket.on('reconnect_attempt', (attempt) => {
      console.warn(`🟡 [Socket.IO] Reconnecting attempt #${attempt}...`);
      this.updateStatus('reconnecting');
    });

    this.socket.on('reconnect_failed', () => {
      console.error('🔴 [Socket.IO] Reconnection failed.');
      this.updateStatus('disconnected');
    });

    this.socket.on('disconnect', (reason) => {
      console.warn(`🔴 [Socket.IO] Disconnected: ${reason}`);
      this.updateStatus(reason === 'io client disconnect' ? 'disconnected' : 'reconnecting');
    });

    this.socket.on('connect_error', (error) => {
      console.warn(`⚠️ [Socket.IO Error]: ${error.message}`);
      this.updateStatus('reconnecting');
    });
  }

  updateStatus(newStatus) {
    this.status = newStatus;
    this.statusListeners.forEach((callback) => {
      try {
        callback(newStatus);
      } catch (e) {
        console.error('Status listener error:', e);
      }
    });
  }

  /**
   * Subscribe to status changes ('connected' | 'reconnecting' | 'disconnected')
   */
  onStatusChange(callback) {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }

  getStatus() {
    return this.status;
  }

  /**
   * Subscribe to real-time events for a specific Charger Bay (e.g. "CH-01")
   */
  subscribeToCharger(chargerId, { onUpdate, onStatus, onFault, onOnline, onOffline }) {
    if (!this.socket) this.connect();

    const roomKey = `join_charger:${chargerId}`;
    this.joinedRooms.add(roomKey);
    this.socket.emit('join_charger', chargerId);

    const handlers = [];

    if (onUpdate) {
      const h = (data) => {
        if (data.chargerId === chargerId) onUpdate(data);
      };
      this.socket.on('charger:update', h);
      handlers.push({ event: 'charger:update', handler: h });
    }

    if (onStatus) {
      const h = (data) => {
        if (data.chargerId === chargerId) onStatus(data);
      };
      this.socket.on('charger:status', h);
      handlers.push({ event: 'charger:status', handler: h });
    }

    if (onFault) {
      const h = (data) => {
        if (data.chargerId === chargerId) onFault(data);
      };
      this.socket.on('charger:fault', h);
      handlers.push({ event: 'charger:fault', handler: h });
    }

    if (onOnline) {
      const h = (data) => {
        if (data.chargerId === chargerId) onOnline(data);
      };
      this.socket.on('charger:online', h);
      handlers.push({ event: 'charger:online', handler: h });
    }

    if (onOffline) {
      const h = (data) => {
        if (data.chargerId === chargerId) onOffline(data);
      };
      this.socket.on('charger:offline', h);
      handlers.push({ event: 'charger:offline', handler: h });
    }

    // Unsubscribe helper
    return () => {
      this.joinedRooms.delete(roomKey);
      if (this.socket) {
        this.socket.emit('leave_charger', chargerId);
        handlers.forEach(({ event, handler }) => this.socket.off(event, handler));
      }
    };
  }

  /**
   * Subscribe to real-time Station updates (available chargers count, status)
   */
  subscribeToStation(stationId, callback) {
    if (!this.socket) this.connect();

    const roomKey = `join_station:${stationId}`;
    this.joinedRooms.add(roomKey);
    this.socket.emit('join_station', stationId);

    const handler = (data) => {
      if (data.stationId === stationId || !data.stationId) {
        callback(data);
      }
    };

    this.socket.on('station:update', handler);

    return () => {
      this.joinedRooms.delete(roomKey);
      if (this.socket) {
        this.socket.emit('leave_station', stationId);
        this.socket.off('station:update', handler);
      }
    };
  }

  /**
   * Subscribe to personalized user events (notifications, session started, complete)
   */
  subscribeToUser(userId, { onNotification, onChargingStart, onChargingComplete }) {
    if (!this.socket) this.connect();

    const handlers = [];

    if (onNotification) {
      this.socket.on('notification:new', onNotification);
      handlers.push({ event: 'notification:new', handler: onNotification });
    }

    if (onChargingStart) {
      this.socket.on('charging:start', onChargingStart);
      handlers.push({ event: 'charging:start', handler: onChargingStart });
    }

    if (onChargingComplete) {
      this.socket.on('charging:complete', onChargingComplete);
      handlers.push({ event: 'charging:complete', handler: onChargingComplete });
    }

    return () => {
      if (this.socket) {
        handlers.forEach(({ event, handler }) => this.socket.off(event, handler));
      }
    };
  }

  on(event, callback) {
    if (!this.socket) this.connect();
    this.socket.on(event, callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this.socket) {
      if (callback) {
        this.socket.off(event, callback);
      } else {
        this.socket.off(event);
      }
    }
  }

  emit(event, data) {
    if (!this.socket) this.connect();
    this.socket.emit(event, data);
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.updateStatus('disconnected');
    }
  }
}

export const socketService = new SocketService();
