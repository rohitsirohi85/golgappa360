import React from 'react';

/**
 * ConstellationInspector — STELLAR 2.0 (Phase U8: Constellation Integration)
 * 
 * Interactive celestial inspector for constellations as map regions:
 * - Constellation Name & Common English Title (e.g., "Orion — The Hunter")
 * - Astronomical description & verified quadrant data
 * - Mythology / Lore snippet ("Stories Written in the Stars")
 * - Seasonal viewing & hemisphere guide
 * - Interactive Member Stars List: clicking any star selects it, focuses camera,
 *   and opens Universal Object Details
 * - Actions: Focus Region / Re-center, View Full Star Details, Close Region
 * - Educational disclaimer: "Constellation lines represent apparent patterns in Earth's sky;
 *   connected stars are not necessarily physically close."
 */
export default function ConstellationInspector({
  constellation,
  onClose,
  onSelectStar,
  onOpenStarModal,
  onFocusRegion,
  className = '',
}) {
  if (!constellation) return null;

  const accentColor = constellation.colorHex || constellation.accentColor || '#38bdf8';
  const memberStars = constellation.mainStars || [];

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      <div
        className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Constellation Inspector Container */}
      <aside
        className={`fixed md:absolute bottom-0 left-0 right-0 md:bottom-auto md:left-auto md:top-4 md:right-4 z-40 md:w-80 lg:w-96 bg-[#030612]/92 md:bg-[#030612]/90 backdrop-blur-2xl border-t md:border border-white/15 rounded-t-2xl md:rounded-2xl shadow-[0_-10px_40px_rgba(0,0,0,0.85)] md:shadow-[0_20px_50px_rgba(0,0,0,0.85)] max-h-[85vh] md:max-h-[calc(100%-2rem)] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 md:slide-in-from-right-6 duration-200 select-none ${className}`}
        aria-label={`Constellation inspector for ${constellation.name}`}
      >
        {/* Mobile Swipe / Drag Handle Indicator */}
        <div className="md:hidden flex justify-center pt-2 pb-1" onClick={onClose}>
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Header Telemetry Bar */}
        <div className="px-4 sm:px-5 pt-3 pb-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="font-bold text-xs shadow-[0_0_8px_currentColor]"
              style={{ color: accentColor }}
            >
              ✨
            </span>
            <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase truncate">
              CONSTELLATION REGION // {constellation.abbreviation || 'ATLAS'}
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close constellation inspector"
            className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Scrollable Inspector Body */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-4 space-y-4 text-left custom-scrollbar">
          {/* Identity & English Title */}
          <div>
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-display text-2xl font-semibold text-white tracking-tight">
                {constellation.name}
              </h2>
              {constellation.latinName && constellation.latinName !== constellation.name && (
                <span className="text-xs font-mono text-slate-400">
                  ({constellation.latinName})
                </span>
              )}
            </div>

            {constellation.commonName && (
              <p className="text-xs font-mono tracking-wider uppercase text-amber-300 font-medium mt-0.5">
                “{constellation.commonName}”
              </p>
            )}
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            {constellation.hemisphere && (
              <div className="p-2 rounded-xl bg-white/[0.03] border border-white/8">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block mb-0.5">
                  HEMISPHERE
                </span>
                <span className="text-cyan-300 font-semibold truncate block">
                  {constellation.hemisphere}
                </span>
              </div>
            )}

            {constellation.bestViewingSeason && (
              <div className="p-2 rounded-xl bg-white/[0.03] border border-white/8">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block mb-0.5">
                  BEST VIEWING
                </span>
                <span className="text-amber-300 font-semibold truncate block">
                  {constellation.bestViewingSeason}
                </span>
              </div>
            )}
          </div>

          {/* Educational Astronomical Description */}
          {constellation.description && (
            <p className="font-sans text-xs text-slate-300 leading-relaxed font-normal">
              {constellation.description}
            </p>
          )}

          {/* Member Stars Interactive List */}
          <div className="p-3 rounded-xl bg-[#020308]/70 border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-semibold flex items-center gap-1.5">
                <span>✦</span>
                <span>MEMBER STARS ({memberStars.length})</span>
              </span>
              <span className="text-[9px] font-mono text-slate-400">
                CLICK TO SELECT & INSPECT
              </span>
            </div>

            <div className="space-y-1.5">
              {memberStars.map((star) => (
                <button
                  key={star.id}
                  type="button"
                  onClick={() => onSelectStar(star)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-white/[0.02] hover:bg-cyan-500/15 border border-white/5 hover:border-cyan-400/40 text-left transition-all flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="w-2 h-2 rounded-full shrink-0 group-hover:scale-125 transition-transform"
                      style={{
                        backgroundColor: star.colorHex || '#ffffff',
                        boxShadow: `0 0 6px ${star.colorHex || '#ffffff'}`,
                      }}
                    />
                    <span className="font-display text-xs font-semibold text-white group-hover:text-cyan-200 truncate">
                      {star.name}
                    </span>
                    {star.role && (
                      <span className="text-[10px] font-mono text-slate-400 truncate hidden sm:inline">
                        • {star.role}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-[10px] font-mono text-slate-400 group-hover:text-cyan-300">
                    {star.magnitude !== undefined && (
                      <span>mag {star.magnitude.toFixed(1)}</span>
                    )}
                    <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform">
                      →
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Cultural Lore / Mythology Snippet */}
          {constellation.mythology && (
            <div className="p-3 rounded-xl bg-amber-950/15 border border-amber-500/20 text-xs">
              <div className="flex items-center gap-1.5 mb-1.5">
                <span className="text-amber-400 text-xs">📜</span>
                <span className="text-[10px] font-mono uppercase tracking-widest text-amber-300 font-bold">
                  STORIES WRITTEN IN THE STARS // MYTHOLOGY
                </span>
              </div>
              <p className="font-sans text-[11px] text-slate-300 italic leading-relaxed">
                &ldquo;{constellation.mythology}&rdquo;
              </p>
            </div>
          )}

          {/* Educational Principle Disclaimer */}
          <div className="p-2.5 rounded-xl bg-cyan-950/20 border border-cyan-500/20 text-[11px] text-cyan-200/90 leading-snug">
            <span className="font-semibold text-cyan-300 mr-1">✦ Educational Note:</span>
            <span>
              Constellation lines represent apparent patterns in Earth&apos;s sky; connected stars are not necessarily physically close in 3D space.
            </span>
          </div>

          {/* Action Buttons */}
          <div className="pt-1 space-y-2">
            {/* Center / Focus Region */}
            {onFocusRegion && (
              <button
                type="button"
                onClick={() => onFocusRegion(constellation)}
                className="w-full py-2 px-4 rounded-xl font-mono font-medium text-xs tracking-wider text-cyan-200 bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-400/50 hover:border-cyan-400 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.2)]"
              >
                <span>📍 Focus Constellation Region</span>
              </button>
            )}

            {/* Close Constellation View */}
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2 px-4 rounded-xl font-mono text-xs tracking-wider text-slate-400 hover:text-white bg-white/[0.02] hover:bg-white/[0.08] border border-white/10 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>✕ Return to Universe Overview</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
