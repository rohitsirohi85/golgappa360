import React, { useRef, useEffect, useState } from 'react';
import { 
  Camera, 
  CameraOff, 
  ShieldCheck, 
  Radio, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Zap, 
  Minimize2, 
  Maximize2,
  RefreshCw,
  Video
} from 'lucide-react';

export const CameraTrackingPanel = ({
  cameraStatus,       // 'off' | 'requesting' | 'active' | 'error'
  modelStatus,        // 'uninitialized' | 'loading' | 'ready' | 'error'
  errorMessage,
  trackingTelemetry,  // { handCount, hands, inferenceTimeMs, isPinching }
  gestureEnabled,
  onToggleCamera,
  onToggleGesture,
  videoRef,
  overlayCanvasRef,
  isMinimized,
  onToggleMinimize,
}) => {
  return (
    <div
      className={`transition-all duration-300 z-30 mb-panel-elevated rounded-2xl overflow-hidden border border-white/15 shadow-2xl flex flex-col ${
        isMinimized
          ? 'w-64 h-auto'
          : 'w-80 sm:w-96 h-auto'
      }`}
    >
      {/* Panel Header */}
      <div className="p-3 bg-black/70 border-b border-white/10 flex items-center justify-between select-none">
        <div className="flex items-center gap-2">
          <div className="relative flex h-2.5 w-2.5">
            {cameraStatus === 'active' ? (
              <>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400 shadow-[0_0_8px_#34d399]"></span>
              </>
            ) : cameraStatus === 'requesting' ? (
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-400 animate-pulse"></span>
            ) : cameraStatus === 'error' ? (
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            ) : (
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-slate-500"></span>
            )}
          </div>

          <span className="font-mono text-xs font-bold tracking-wide text-white flex items-center gap-1.5">
            <Video className="w-3.5 h-3.5 text-cyan-400" />
            LIVE GESTURE TRACKER
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Privacy Badge */}
          {cameraStatus === 'active' && (
            <span
              className="flex items-center gap-1 text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
              title="Camera stream is processed locally in browser. No video is ever sent to any server."
            >
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>LOCAL PRIVACY</span>
            </span>
          )}

          <button
            onClick={onToggleMinimize}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title={isMinimized ? 'Expand Video' : 'Minimize Video'}
          >
            {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Video & Landmark Overlay Viewport */}
      {!isMinimized && (
        <div className="relative bg-black aspect-video w-full overflow-hidden flex items-center justify-center border-b border-white/10 group">
          {/* 1. Underlying Video Element (Mirrored) */}
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className={`w-full h-full object-cover transform scale-x-[-1] transition-opacity duration-300 ${
              cameraStatus === 'active' ? 'opacity-70' : 'opacity-0'
            }`}
          />

          {/* 2. Mirrored 2D Landmark Overlay Canvas */}
          <canvas
            ref={overlayCanvasRef}
            width={640}
            height={480}
            className={`absolute inset-0 w-full h-full pointer-events-none transition-opacity duration-300 ${
              cameraStatus === 'active' ? 'opacity-100' : 'opacity-0'
            }`}
          />

          {/* 3. Idle / Off State Overlay */}
          {cameraStatus === 'off' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-[#070913]/90 backdrop-blur-sm">
              <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-2.5 text-slate-400">
                <CameraOff className="w-6 h-6 text-slate-400" />
              </div>
              <h4 className="text-xs font-bold text-white font-mono tracking-wider">
                WEBCAM DISCONNECTED
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 max-w-[240px]">
                Click <span className="text-cyan-400 font-semibold">Enable Camera</span> to activate real-time MediaPipe Hand Landmarker.
              </p>
            </div>
          )}

          {/* 4. Requesting Permission State */}
          {cameraStatus === 'requesting' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-black/90 backdrop-blur-sm space-y-2">
              <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
              <h4 className="text-xs font-bold text-cyan-300 font-mono">
                REQUESTING CAMERA PERMISSION...
              </h4>
              <p className="text-[10px] text-slate-400">
                Please approve the camera prompt in your browser address bar.
              </p>
            </div>
          )}

          {/* 5. Error State */}
          {cameraStatus === 'error' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-rose-950/80 backdrop-blur-sm space-y-2">
              <AlertCircle className="w-6 h-6 text-rose-400" />
              <h4 className="text-xs font-bold text-rose-300 font-mono">
                CAMERA ERROR
              </h4>
              <p className="text-[10px] text-slate-300 leading-tight px-2">
                {errorMessage || 'Could not initialize video stream.'}
              </p>
            </div>
          )}

          {/* 6. Model Loading Overlay (when camera active but model loading) */}
          {cameraStatus === 'active' && modelStatus === 'loading' && (
            <div className="absolute bottom-2 left-2 right-2 p-2 rounded-lg bg-black/80 backdrop-blur-md border border-cyan-500/40 text-[10px] font-mono text-cyan-300 flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Loading MediaPipe Hand Model...</span>
            </div>
          )}

          {/* 7. Live Telemetry HUD inside Video viewport */}
          {cameraStatus === 'active' && modelStatus === 'ready' && (
            <div className="absolute top-2 left-2 right-2 flex items-center justify-between text-[10px] font-mono pointer-events-none">
              <span className="px-2 py-0.5 rounded bg-black/70 backdrop-blur-md border border-white/10 text-slate-200">
                {trackingTelemetry.handCount === 0 ? (
                  <span className="text-slate-400">SEARCHING HANDS...</span>
                ) : (
                  <span className="text-emerald-400 font-semibold">
                    {trackingTelemetry.handCount} {trackingTelemetry.handCount === 1 ? 'HAND' : 'HANDS'} TRACKED
                  </span>
                )}
              </span>

              <span className="px-2 py-0.5 rounded bg-black/70 backdrop-blur-md border border-white/10 text-cyan-400">
                {trackingTelemetry.inferenceTimeMs}ms
              </span>
            </div>
          )}
        </div>
      )}

      {/* Control Actions & Telemetry Footer */}
      <div className="p-3 bg-black/60 space-y-2.5 select-none">
        {/* Toggle Buttons */}
        <div className="flex items-center gap-2">
          {cameraStatus === 'active' ? (
            <button
              onClick={onToggleCamera}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-mono text-xs font-bold transition-all"
            >
              <CameraOff className="w-3.5 h-3.5" />
              <span>DISABLE CAMERA</span>
            </button>
          ) : (
            <button
              onClick={onToggleCamera}
              disabled={cameraStatus === 'requesting'}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-mono text-xs font-bold transition-all shadow-md shadow-cyan-500/20 disabled:opacity-50"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>ENABLE CAMERA</span>
            </button>
          )}

          {/* Gesture Modulation Toggle */}
          <button
            onClick={onToggleGesture}
            className={`py-2 px-3 rounded-xl font-mono text-xs font-semibold border transition-all flex items-center gap-1.5 ${
              gestureEnabled
                ? 'bg-purple-600/30 text-purple-200 border-purple-500/50 shadow-sm'
                : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
            }`}
            title="Toggle Gesture-Driven Visual Dynamics"
          >
            <Zap className={`w-3.5 h-3.5 ${gestureEnabled ? 'text-purple-400' : 'text-slate-500'}`} />
            <span>GESTURE: {gestureEnabled ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Live Multi-Hand Telemetry Cards */}
        {cameraStatus === 'active' && trackingTelemetry.hands && trackingTelemetry.hands.length > 0 && (
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono pt-1">
            {trackingTelemetry.hands.map((h, idx) => (
              <div
                key={h.id || idx}
                className="p-2 rounded-lg bg-white/5 border border-white/10 space-y-0.5"
              >
                <div className="flex items-center justify-between">
                  <span className={idx === 0 ? 'text-cyan-400 font-bold' : 'text-purple-300 font-bold'}>
                    {h.handedness.toUpperCase()}
                  </span>
                  <span className="text-slate-400">
                    {Math.round((h.score || 0.95) * 100)}%
                  </span>
                </div>
                <div className="text-slate-300 flex justify-between">
                  <span>POS:</span>
                  <span>{h.position.x.toFixed(2)}, {h.position.y.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>STATE:</span>
                  <span className={h.isPinching ? 'text-amber-300 font-bold' : 'text-slate-400'}>
                    {h.isPinching ? '★ PINCH' : 'OPEN'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
