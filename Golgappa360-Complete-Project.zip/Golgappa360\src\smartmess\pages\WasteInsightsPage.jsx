import React, { useState, useEffect, useCallback } from 'react';
import {
  TrendingDown,
  CloudRain,
  Calendar,
  ShieldCheck,
  PiggyBank,
  Leaf,
  RefreshCw,
  Scale,
  BarChart3,
  DollarSign,
  Utensils,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';
import { messApi } from '../services/messApiService';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { ErrorState } from '../components/common/ErrorState';

export const WasteInsightsPage = () => {
  const [insightsData, setInsightsData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Active Dimension View: 'meal_type' | 'menu_category' | 'weekday' | 'weather'
  const [activeDimension, setActiveDimension] = useState('meal_type');
  // Metric toggle: 'waste_pct' | 'waste_kg' | 'cost_loss'
  const [activeMetric, setActiveMetric] = useState('waste_pct');

  const fetchInsights = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await messApi.getWastePatterns();
      setInsightsData(data);
    } catch (err) {
      console.error('Failed to load waste insights:', err);
      setError(err.message || 'Unable to retrieve waste pattern analytics from backend.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInsights();
  }, [fetchInsights]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <LoadingSkeleton type="stat-grid" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <LoadingSkeleton type="chart" />
          <LoadingSkeleton type="chart" />
        </div>
      </div>
    );
  }

  if (error || !insightsData) {
    return (
      <div className="py-12">
        <ErrorState
          title="Waste Insights Unavailable"
          message={error || 'Failed to query /api/insights/patterns.'}
          onRetry={fetchInsights}
        />
      </div>
    );
  }

  const { summary, by_meal_type, by_menu_category, by_weekday, by_weather, methodology_notice } = insightsData;

  // Selected dimension dataset
  let currentChartData = [];
  let dimensionLabel = 'Meal Service Window';
  if (activeDimension === 'meal_type') {
    currentChartData = by_meal_type.map((d) => ({
      ...d,
      displayName: d.name.charAt(0).toUpperCase() + d.name.slice(1),
    }));
    dimensionLabel = 'Meal Service Window';
  } else if (activeDimension === 'menu_category') {
    currentChartData = by_menu_category.map((d) => ({
      ...d,
      displayName: d.name.replace('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
    }));
    dimensionLabel = 'Menu Category';
  } else if (activeDimension === 'weekday') {
    currentChartData = by_weekday.map((d) => ({
      ...d,
      displayName: d.name.slice(0, 3),
      fullName: d.name,
    }));
    dimensionLabel = 'Day of the Week';
  } else if (activeDimension === 'weather') {
    currentChartData = by_weather.map((d) => ({
      ...d,
      displayName: d.name.replace('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
    }));
    dimensionLabel = 'Weather Condition';
  }

  // Preparation vs Estimated vs Actual Waste Comparison Data
  const prepVsWasteComparisonData = [
    {
      category: 'Food Prepared',
      volumeKg: summary.total_prepared_kg,
      label: `${summary.total_prepared_kg.toLocaleString()} kg`,
      fill: '#0284C7',
      subtext: 'Gross kitchen production volume across 1,000 services',
    },
    {
      category: 'Actual Waste Recorded',
      volumeKg: summary.actual_recorded_waste_kg,
      label: `${summary.actual_recorded_waste_kg.toLocaleString()} kg (${summary.actual_waste_pct}%)`,
      fill: '#16865B',
      subtext: 'Empirical post-service discards and tray returns',
    },
    {
      category: 'Unoptimized Rule Baseline',
      volumeKg: summary.baseline_estimated_waste_kg,
      label: `${summary.baseline_estimated_waste_kg.toLocaleString()} kg (19.0%)`,
      fill: '#D97706',
      subtext: 'Conventional unmonitored institutional waste estimate',
    },
  ];

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-[#16865B]" />
            Waste Insights & Pattern Analytics
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              1,000 Synthetic Telemetry Records
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            Diagnostic analytics identifying food waste patterns across meal type, menu category, weekday, and weather conditions.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={fetchInsights}
            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#16865B] bg-white transition-colors border border-[#E4EAE5] cursor-pointer shadow-xs"
            title="Refresh waste insights"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-2 text-xs text-[#16865B] bg-[#E9F6EE] border border-[#C5E5D0] px-3 py-1.5 rounded-lg shadow-xs">
            <Leaf className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] font-medium">Academic Benchmark Data</span>
          </div>
        </div>
      </div>

      {/* Mandatory Scientific Correlation vs Causation Notice */}
      <div className="p-4 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] text-xs flex flex-col sm:flex-row items-start gap-3 shadow-xs">
        <div className="p-2 rounded-lg bg-white text-[#16865B] border border-[#C5E5D0] shrink-0 mt-0.5 shadow-xs">
          <ShieldCheck className="w-4 h-4" />
        </div>
        <div className="space-y-1">
          <span className="font-bold text-[#16865B] block">
            Scientific Rigor: Correlation Does Not Prove Causation
          </span>
          <p className="text-[#55635C] leading-relaxed text-[11px]">
            {methodology_notice}
          </p>
        </div>
      </div>

      {/* Top Aggregated Cost & Volume Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Food Prepared */}
        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#E0F2FE] text-[#0284C7] border border-[#BAE6FD]">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-[#77847C] tracking-wider">
              Total Prepared Volume
            </span>
            <div className="text-lg font-bold text-[#25332D] font-mono">
              {summary.total_prepared_kg.toLocaleString()} kg
            </div>
            <span className="text-[10px] text-[#77847C] font-mono">
              across 1,000 meal services
            </span>
          </div>
        </div>

        {/* Total Recorded Food Waste */}
        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#FEF2F2] text-[#DC2626] border border-[#FECACA]">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-[#77847C] tracking-wider">
              Recorded Food Waste
            </span>
            <div className="text-lg font-bold text-[#B91C1C] font-mono">
              {summary.actual_recorded_waste_kg.toLocaleString()} kg
            </div>
            <span className="text-[10px] text-[#D97706] font-mono font-medium">
              {summary.actual_waste_pct}% overall discard rate
            </span>
          </div>
        </div>

        {/* Total Kitchen Expenditure */}
        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
            <PiggyBank className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-[#77847C] tracking-wider">
              Total Kitchen Expenditure
            </span>
            <div className="text-lg font-bold text-[#25332D] font-mono">
              ₹{summary.total_prepared_cost_inr.toLocaleString()}
            </div>
            <span className="text-[10px] text-[#77847C] font-mono">
              ingredients & fuel expenditure
            </span>
          </div>
        </div>

        {/* Total Cost Loss to Discards */}
        <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#FFFBEB] text-[#D97706] border border-[#FDE68A]">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-[#77847C] tracking-wider">
              Financial Waste Loss
            </span>
            <div className="text-lg font-bold text-[#B45309] font-mono">
              ₹{summary.total_waste_loss_inr.toLocaleString()}
            </div>
            <span className="text-[10px] text-[#77847C] font-mono">
              {summary.documented_cost_formula.split('=')[0]}
            </span>
          </div>
        </div>
      </div>

      {/* Volume Comparison Section: Prepared vs Actual Recorded vs Baseline Unoptimized */}
      <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#EEF2EF]">
          <div>
            <h3 className="text-sm font-bold text-[#25332D] flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#16865B]" />
              Comparative Volume Benchmark: Prepared vs. Actual Waste vs. Unoptimized Baseline
            </h3>
            <p className="text-xs text-[#77847C] mt-0.5">
              Comparing gross preparation tonnage against empirical recorded waste and the 19% unmonitored institutional baseline.
            </p>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
            Volume Metric (kg)
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Comparison Bar Chart */}
          <div className="lg:col-span-8 h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prepVsWasteComparisonData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" horizontal={false} />
                <XAxis
                  type="number"
                  unit=" kg"
                  stroke="#D2DDD4"
                  tick={{ fill: '#77847C', fontSize: 11 }}
                  axisLine={{ stroke: '#E4EAE5' }}
                  tickLine={false}
                />
                <YAxis
                  type="category"
                  dataKey="category"
                  stroke="#D2DDD4"
                  tick={{ fill: '#25332D', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  width={150}
                />
                <Tooltip
                  formatter={(val) => [`${val.toLocaleString()} kg`, 'Volume']}
                  contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E4EAE5', color: '#25332D', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}
                />
                <Bar dataKey="volumeKg" radius={[0, 4, 4, 0]} maxBarSize={28}>
                  {prepVsWasteComparisonData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Documented Assumptions Card */}
          <div className="lg:col-span-4 p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] text-xs space-y-2">
            <span className="font-semibold text-[#25332D] block text-[11px] uppercase tracking-wider">
              Documented Cost & Benchmark Assumptions:
            </span>
            <ul className="space-y-1.5 text-[#55635C] text-[11px] list-disc list-inside">
              <li>
                <strong>Recorded Waste Cost:</strong> Calculated as: Σ (Food Waste kg × Cost per kg).
              </li>
              <li>
                <strong>Unoptimized Baseline (19.0%):</strong> Represents typical institutional cafeteria discard rates operating without pre-batch attendance forecasting.
              </li>
              <li>
                <strong>Surplus Mitigation Opportunity:</strong> An estimated {(summary.baseline_estimated_waste_kg - summary.actual_recorded_waste_kg).toLocaleString()} kg of food is preserved through structured portioning.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Main Multi-Dimensional Pattern Explorer */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-[#EEF2EF]">
          <div>
            <h3 className="text-sm font-bold text-[#25332D] flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#16865B]" />
              Empirical Waste Patterns Explorer
            </h3>
            <p className="text-xs text-[#77847C] mt-0.5">
              Explore waste patterns broken down by meal slot, menu category, day of week, and weather condition.
            </p>
          </div>

          {/* Dimension Selector Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#F8FAF8] p-1 rounded-lg border border-[#E4EAE5] text-xs">
            {[
              { id: 'meal_type', label: 'By Meal Type' },
              { id: 'menu_category', label: 'By Menu Category' },
              { id: 'weekday', label: 'By Weekday' },
              { id: 'weather', label: 'By Weather' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveDimension(tab.id)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                  activeDimension === tab.id
                    ? 'bg-white text-[#16865B] border border-[#C5E5D0] shadow-xs font-semibold'
                    : 'text-[#77847C] hover:text-[#25332D]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Metric View Controls */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-[#77847C]">
            Displaying: <strong className="text-[#25332D]">{dimensionLabel}</strong> ({currentChartData.length} Categories)
          </span>

          <div className="flex items-center gap-1.5 bg-[#F8FAF8] p-0.5 rounded-lg border border-[#E4EAE5] text-xs font-mono">
            <button
              onClick={() => setActiveMetric('waste_pct')}
              className={`px-2.5 py-1 rounded text-[11px] cursor-pointer ${
                activeMetric === 'waste_pct'
                  ? 'bg-white text-[#16865B] font-bold shadow-xs border border-[#C5E5D0]'
                  : 'text-[#77847C] hover:text-[#25332D]'
              }`}
            >
              Waste Ratio (%)
            </button>
            <button
              onClick={() => setActiveMetric('waste_kg')}
              className={`px-2.5 py-1 rounded text-[11px] cursor-pointer ${
                activeMetric === 'waste_kg'
                  ? 'bg-white text-[#16865B] font-bold shadow-xs border border-[#C5E5D0]'
                  : 'text-[#77847C] hover:text-[#25332D]'
              }`}
            >
              Waste Volume (kg)
            </button>
            <button
              onClick={() => setActiveMetric('cost_loss')}
              className={`px-2.5 py-1 rounded text-[11px] cursor-pointer ${
                activeMetric === 'cost_loss'
                  ? 'bg-white text-[#16865B] font-bold shadow-xs border border-[#C5E5D0]'
                  : 'text-[#77847C] hover:text-[#25332D]'
              }`}
            >
              Cost Loss (₹)
            </button>
          </div>
        </div>

        {/* Dimensional Pattern Chart */}
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={currentChartData} margin={{ top: 10, right: 30, left: 10, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
              <XAxis
                dataKey="displayName"
                stroke="#D2DDD4"
                tick={{ fill: '#77847C', fontSize: 11 }}
                axisLine={{ stroke: '#E4EAE5' }}
                tickLine={false}
              />
              <YAxis
                stroke="#D2DDD4"
                unit={activeMetric === 'waste_pct' ? '%' : activeMetric === 'waste_kg' ? ' kg' : ' ₹'}
                tick={{ fill: '#77847C', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                formatter={(val) => [
                  activeMetric === 'waste_pct'
                    ? `${val}%`
                    : activeMetric === 'waste_kg'
                    ? `${val.toLocaleString()} kg`
                    : `₹${val.toLocaleString()}`,
                  activeMetric === 'waste_pct'
                    ? 'Average Waste Ratio'
                    : activeMetric === 'waste_kg'
                    ? 'Total Food Waste'
                    : 'Total Cost Loss',
                ]}
                labelFormatter={(label) => `${dimensionLabel}: ${label}`}
                contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E4EAE5', color: '#25332D', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}
              />
              <Bar
                dataKey={activeMetric === 'waste_pct' ? 'waste_pct' : activeMetric === 'waste_kg' ? 'waste_kg' : 'waste_cost_loss_inr'}
                name={activeMetric === 'waste_pct' ? 'Waste %' : activeMetric === 'waste_kg' ? 'Waste kg' : 'Loss ₹'}
                radius={[4, 4, 0, 0]}
                maxBarSize={45}
              >
                {currentChartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      activeMetric === 'waste_pct'
                        ? entry.waste_pct > 15.5
                          ? '#DC2626'
                          : entry.waste_pct > 14.5
                          ? '#D97706'
                          : '#16865B'
                        : '#0D9488'
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Detailed Pattern Telemetry Table */}
        <div className="overflow-x-auto rounded-lg border border-[#E4EAE5]">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#E4EAE5] bg-[#F8FAF8] text-[#77847C] uppercase text-[10px] font-semibold tracking-wider">
                <th className="py-2.5 px-4">{dimensionLabel}</th>
                <th className="py-2.5 px-4 text-right">Records Logged</th>
                <th className="py-2.5 px-4 text-right">Avg Attendance</th>
                <th className="py-2.5 px-4 text-right">Total Prep (kg)</th>
                <th className="py-2.5 px-4 text-right">Recorded Waste (kg)</th>
                <th className="py-2.5 px-4 text-right">Waste Ratio</th>
                <th className="py-2.5 px-4 text-right">Cost Loss (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF2EF] font-mono text-[#25332D]">
              {currentChartData.map((item) => (
                <tr key={item.name} className="hover:bg-[#F8FAF8] transition-colors">
                  <td className="py-2.5 px-4 font-sans font-medium text-[#25332D] capitalize">
                    {item.name}
                  </td>
                  <td className="py-2.5 px-4 text-right">{item.records_count}</td>
                  <td className="py-2.5 px-4 text-right text-[#77847C]">{item.avg_attendance}</td>
                  <td className="py-2.5 px-4 text-right">{item.prepared_kg.toLocaleString()} kg</td>
                  <td className="py-2.5 px-4 text-right text-[#B91C1C] font-semibold">
                    {item.waste_kg.toLocaleString()} kg
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                        item.waste_pct > 15.5
                          ? 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]'
                          : item.waste_pct > 14.5
                          ? 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]'
                          : 'bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]'
                      }`}
                    >
                      {item.waste_pct}%
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-bold text-[#D97706]">
                    ₹{item.waste_cost_loss_inr.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Root Cause Context & Observational Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Pattern 1: Menu Category Characteristics */}
        <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
          <div className="p-2.5 rounded-lg bg-[#FFFBEB] text-[#D97706] border border-[#FDE68A] w-fit">
            <Utensils className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-[#25332D]">
            1. Menu Profile & Serving Type
          </h4>
          <p className="text-xs text-[#55635C] leading-relaxed">
            In the dataset, <strong>rice_grains</strong> and <strong>special_feast</strong> exhibit the highest gross discard volumes. Starch-heavy meals demonstrate greater tray plate residue compared to light breakfast items.
          </p>
          <div className="pt-2 text-[11px] font-mono text-[#D97706] font-medium border-t border-[#EEF2EF]">
            Observation: Rice Grains average ~16.4% discard
          </div>
        </div>

        {/* Pattern 2: Weather-Correlated Attendance Fluctuations */}
        <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
          <div className="p-2.5 rounded-lg bg-[#E0F2FE] text-[#0284C7] border border-[#BAE6FD] w-fit">
            <CloudRain className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-[#25332D]">
            2. Weather-Related Attendance Drop
          </h4>
          <p className="text-xs text-[#55635C] leading-relaxed">
            Rainy weather co-occurs with lower average attendance (~740 students vs ~810 on clear days). When kitchens prepare standard batch sizes during precipitation, surplus overage increases.
          </p>
          <div className="pt-2 text-[11px] font-mono text-[#0284C7] font-medium border-t border-[#EEF2EF]">
            Observation: Lower attendance correlates with surplus
          </div>
        </div>

        {/* Pattern 3: Weekday Variations */}
        <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
          <div className="p-2.5 rounded-lg bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] w-fit">
            <Calendar className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-[#25332D]">
            3. Weekend Service Variation
          </h4>
          <p className="text-xs text-[#55635C] leading-relaxed">
            Friday dinners and Sunday services observe lower total headcount as students dine off-campus or travel home. Adjusting prep batches dynamically on weekends yields consistent efficiency.
          </p>
          <div className="pt-2 text-[11px] font-mono text-[#16865B] font-medium border-t border-[#EEF2EF]">
            Observation: Weekend services require adaptive batching
          </div>
        </div>
      </div>
    </div>
  );
};
