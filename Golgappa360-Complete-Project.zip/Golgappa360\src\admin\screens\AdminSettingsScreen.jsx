import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  Settings,
  DollarSign,
  Cpu,
  ShieldAlert,
  Save,
  CheckCircle2,
  AlertCircle,
  Clock,
  Mail,
  Zap,
} from 'lucide-react';

export const AdminSettingsScreen = () => {
  const [settings, setSettings] = useState({
    defaultPricePerKwh: 10,
    peakHourPricePerKwh: 14,
    sensorUpdateIntervalMs: 5000,
    offlineTimeoutMs: 15000,
    overheatThreshold: 65,
    overcurrentThreshold: 32,
    overvoltageThreshold: 260,
    undervoltageThreshold: 180,
    maxBookingDuration: 120,
    maintenanceNotificationEmail: 'admin@evsmart.com',
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const data = await adminService.getSettings();
      if (data && typeof data === 'object') {
        setSettings((prev) => ({ ...prev, ...data }));
      }
    } catch (err) {
      console.error('Error fetching settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleChange = (key, value) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');
    setError('');
    try {
      await adminService.updateSettings(settings);
      setMessage('Platform parameters and safety thresholds successfully updated & logged to audit ledger.');
    } catch (err) {
      setError(`Failed to save settings: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout pageTitle="System Settings">
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading platform configuration...</p>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout
      pageTitle="Platform System Settings"
      subtitle="Configure operational tariffs, ESP32 IoT watchdog telemetry, and hardware safety thresholds"
    >
      {message && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-8 max-w-4xl">
        {/* Section 1: Tariff & Pricing */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800 mb-6">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Commercial Tariffs & Energy Rates</h3>
              <p className="text-xs text-slate-400">Network-wide default pricing per kilowatt-hour</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Base Tariff (₹ / kWh)
              </label>
              <input
                type="number"
                step="0.5"
                required
                value={settings.defaultPricePerKwh || 10}
                onChange={(e) => handleChange('defaultPricePerKwh', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Standard charging rate for all AC & Fast DC bays
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Peak Hour Tariff (₹ / kWh)
              </label>
              <input
                type="number"
                step="0.5"
                required
                value={settings.peakHourPricePerKwh || 14}
                onChange={(e) => handleChange('peakHourPricePerKwh', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Peak demand window surcharge rate
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: IoT Watchdog & Telemetry */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800 mb-6">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">IoT Communication & Edge Watchdog</h3>
              <p className="text-xs text-slate-400">Control transmission rates and disconnect timeout triggers</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Sensor Telemetry Rate (ms)
              </label>
              <input
                type="number"
                step="500"
                required
                value={settings.sensorUpdateIntervalMs || 5000}
                onChange={(e) => handleChange('sensorUpdateIntervalMs', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                ESP32 telemetry broadcast frequency to backend
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Offline Detection Threshold (ms)
              </label>
              <input
                type="number"
                step="1000"
                required
                value={settings.offlineTimeoutMs || 15000}
                onChange={(e) => handleChange('offlineTimeoutMs', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Inactivity duration before bay flagged as OFFLINE
              </span>
            </div>
          </div>
        </div>

        {/* Section 3: Hardware Safety & Trip Protection */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800 mb-6">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Hardware Safety & Protection Thresholds</h3>
              <p className="text-xs text-slate-400">Automatic safety trip cutoffs to prevent equipment damage</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Overheat Cutoff (°C)
              </label>
              <input
                type="number"
                required
                value={settings.overheatThreshold || 65}
                onChange={(e) => handleChange('overheatThreshold', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Max Current Trip (A)
              </label>
              <input
                type="number"
                required
                value={settings.overcurrentThreshold || 32}
                onChange={(e) => handleChange('overcurrentThreshold', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Overvoltage Trip (V)
              </label>
              <input
                type="number"
                required
                value={settings.overvoltageThreshold || 260}
                onChange={(e) => handleChange('overvoltageThreshold', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Undervoltage Trip (V)
              </label>
              <input
                type="number"
                required
                value={settings.undervoltageThreshold || 180}
                onChange={(e) => handleChange('undervoltageThreshold', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Maintenance & Bookings */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800 mb-6">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Maintenance Alerts & Reservation Limits</h3>
              <p className="text-xs text-slate-400">Operator notification routing and driver slot limits</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Alert Email Notification
              </label>
              <input
                type="email"
                required
                value={settings.maintenanceNotificationEmail || 'admin@evsmart.com'}
                onChange={(e) => handleChange('maintenanceNotificationEmail', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                Max Slot Duration (minutes)
              </label>
              <input
                type="number"
                required
                value={settings.maxBookingDuration || 120}
                onChange={(e) => handleChange('maxBookingDuration', Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pt-4">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            {saving ? (
              <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save Platform Settings</span>
              </>
            )}
          </button>
        </div>
      </form>
    </AdminLayout>
  );
};

export default AdminSettingsScreen;
