import React from 'react';
import UniversalSearch from '../search/UniversalSearch';

/**
 * UniverseSearch — Celestial Search Wrapper
 * 
 * Backward-compatible bridge to STELLAR 2.0 UniversalSearch component.
 * Supports legacy props (objects, stars, onSelectStar, onSelectObject)
 * while unlocking universal category filtering, typo-tolerant fuzzy matching,
 * verified scientific aliases, search history, and empty-state suggestions.
 */
export default function UniverseSearch({
  objects = [],
  stars = [],
  onSelectStar,
  onSelectObject,
  className = '',
  placeholder = 'Search the universe...',
}) {
  const handleSelect = (item) => {
    if (onSelectObject) {
      onSelectObject(item);
    } else if (onSelectStar) {
      onSelectStar(item);
    }
  };

  return (
    <UniversalSearch
      variant="map"
      onSelect={handleSelect}
      className={className}
      placeholder={placeholder}
    />
  );
}
