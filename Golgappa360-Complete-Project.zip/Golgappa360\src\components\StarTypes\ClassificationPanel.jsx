import React from 'react';

/**
 * ClassificationPanel — Interactive left-star visual, right-dossier panel
 * Smoothly transitions color, halo, spikes, and astrophysical metadata
 * when spectral class O, B, A, F, G, K, or M is selected.
 */
export default function ClassificationPanel({ selectedClass, onSelectExampleStar }) {
  if (!selectedClass) return null;

  // Determine diffraction spikes for high-temperature classes
  const hasSpikes = ['O', 'B', 'A'].includes(selectedClass.id);

  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center p-6 sm:p-8 lg:p-10 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
      {/* Left Column: Large Dynamic Star Visual */}
      <div className="lg:col-span-5 flex flex-col items-center justify-center relative min-h-[300px] sm:min-h-[380px]">
        {/* Ambient Color Halo */}
        <div
          aria-hidden="true"
          className="absolute inset-0 rounded-full blur-[80px] sm:blur-[110px] opacity-35 pointer-events-none transition-all duration-700 ease-out"
          style={{ backgroundColor: selectedClass.colorHex }}
        />

        {/* Outer Orbital Ring */}
        <div
          aria-hidden="true"
          className="absolute w-[280px] h-[280px] sm:w-[350px] sm:h-[350px] rounded-full border border-dashed border-white/10 animate-slow-orbit pointer-events-none"
        >
          <div
            className="absolute -top-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full transition-colors duration-500"
            style={{
              backgroundColor: selectedClass.colorHex,
              boxShadow: `0 0 10px ${selectedClass.colorHex}`,
            }}
          />
        </div>

        {/* The Animated Star Sphere */}
        <div className="relative w-44 h-44 sm:w-56 sm:h-56 rounded-full flex items-center justify-center select-none animate-float-slow transition-all duration-700">
          {/* Coronal Flare Atmosphere */}
          <div
            aria-hidden="true"
            className="absolute -inset-8 rounded-full blur-2xl opacity-80 transition-all duration-700 ease-out pointer-events-none"
            style={{
              background: `radial-gradient(circle, ${selectedClass.glowColor} 0%, transparent 70%)`,
            }}
          />

          {/* Photosphere 3D Sphere */}
          <div
            className="relative w-full h-full rounded-full overflow-hidden shadow-2xl transition-all duration-700"
            style={{
              boxShadow: `0 0 35px ${selectedClass.glowColor}, inset 0 0 20px rgba(255, 255, 255, 0.7)`,
              background: `radial-gradient(circle at 35% 32%, #ffffff 0%, ${selectedClass.colorHex} 45%, #050b1d 100%)`,
            }}
          >
            {/* Dynamic Convective Granulation 1 */}
            <div
              aria-hidden="true"
              className="absolute inset-0 rounded-full opacity-60 mix-blend-color-burn animate-slow-orbit pointer-events-none"
              style={{
                background: `repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0.4) 0deg, transparent 20deg, rgba(0,0,0,0.5) 40deg)`,
              }}
            />

            {/* Dynamic Convective Granulation 2 */}
            <div
              aria-hidden="true"
              className="absolute inset-0 rounded-full opacity-50 mix-blend-overlay animate-reverse-orbit pointer-events-none"
              style={{
                background: `repeating-radial-gradient(circle at 45% 45%, transparent 0px, rgba(255,255,255,0.3) 6px, transparent 12px)`,
              }}
            />

            {/* Radiant Hotspot */}
            <div className="absolute top-[22%] left-[26%] w-[38%] h-[38%] rounded-full bg-white/75 blur-[2px] animate-pulse-glow pointer-events-none" />

            {/* Limb-Darkening Rim */}
            <div
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{
                boxShadow: `inset 0 0 25px 6px rgba(0, 0, 0, 0.85)`,
              }}
            />
          </div>

          {/* Diffraction Spikes for O, B, A stars */}
          {hasSpikes && (
            <div
              aria-hidden="true"
              className="absolute pointer-events-none transition-opacity duration-700 opacity-70"
            >
              <div
                className="h-[1px] -translate-y-1/2 w-[320px] sm:w-[380px]"
                style={{
                  background: `linear-gradient(to right, transparent, ${selectedClass.colorHex}, transparent)`,
                }}
              />
              <div
                className="w-[1px] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[320px] sm:h-[380px]"
                style={{
                  background: `linear-gradient(to bottom, transparent, ${selectedClass.colorHex}, transparent)`,
                }}
              />
            </div>
          )}
        </div>

        {/* Telemetry Tag below the star */}
        <div className="mt-6 flex items-center gap-3 px-4 py-1.5 rounded-full glass-surface border border-white/10 text-xs font-mono text-slate-300">
          <span
            className="w-2 h-2 rounded-full animate-pulse"
            style={{ backgroundColor: selectedClass.colorHex }}
          />
          <span className="font-semibold text-white">CLASS {selectedClass.id}</span>
          <span className="text-slate-600">//</span>
          <span style={{ color: selectedClass.colorHex }}>
            {selectedClass.temperatureRange}
          </span>
        </div>
      </div>

      {/* Right Column: Educational Metadata Dossier */}
      <div className="lg:col-span-7 flex flex-col text-left">
        {/* Eyebrow & Title */}
        <div className="mb-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-2.5 rounded-full glass-surface border border-white/10 text-xs font-mono uppercase tracking-widest text-slate-300">
            <span>SPECTRAL CLASS</span>
            <span style={{ color: selectedClass.colorHex }}>✦</span>
            <span style={{ color: selectedClass.colorHex }}>
              {selectedClass.shortLabel.toUpperCase()}
            </span>
          </div>

          <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-1">
            {selectedClass.id} — {selectedClass.title.toUpperCase()}
          </h3>

          <p className="text-sm font-mono text-slate-400">
            Galaxy Prevalence: <span className="text-slate-200">{selectedClass.prevalence}</span>
          </p>
        </div>

        {/* Telemetry Physical Properties Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-[#020308]/60 border border-white/8 mb-6">
          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              SURFACE TEMP
            </div>
            <div
              className="text-sm sm:text-base font-bold font-mono"
              style={{ color: selectedClass.colorHex }}
            >
              {selectedClass.temperatureRange}
            </div>
          </div>

          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              BLACKBODY COLOR
            </div>
            <div className="text-sm font-semibold text-white">
              {selectedClass.color}
            </div>
          </div>

          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              TYPICAL LIFETIME
            </div>
            <div className="text-sm font-semibold text-white">
              {selectedClass.typicalLifetime}
            </div>
          </div>

          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              MASS RANGE
            </div>
            <div className="text-sm font-semibold text-white">
              {selectedClass.massRange}
            </div>
          </div>

          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              RADIUS RANGE
            </div>
            <div className="text-sm font-semibold text-white">
              {selectedClass.radiusRange}
            </div>
          </div>

          <div className="p-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
              KEY EXAMPLES
            </div>
            <div className="text-sm font-semibold text-amber-300 truncate">
              {selectedClass.exampleStar}
            </div>
          </div>
        </div>

        {/* Educational Narrative */}
        <p className="font-sans text-sm sm:text-base text-slate-300/90 leading-relaxed mb-5">
          {selectedClass.description}
        </p>

        {/* Astrophysical Characteristics Bullet Points */}
        <div className="space-y-2 mb-6">
          <div className="text-[11px] font-mono uppercase tracking-widest text-cyan-400 font-semibold mb-2">
            OBSERVATIONAL SIGNATURES:
          </div>
          {selectedClass.characteristics.map((point, index) => (
            <div key={index} className="flex items-start gap-2.5 font-sans text-xs sm:text-sm text-slate-300/80">
              <span className="text-cyan-400 mt-1">▸</span>
              <span>{point}</span>
            </div>
          ))}
        </div>

        {/* Example Stars CTA */}
        {selectedClass.exampleStar && (
          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div className="text-slate-400">
              NOTABLE MEMBERS: <span className="text-white font-medium">{selectedClass.exampleStar}</span>
            </div>
            {onSelectExampleStar && (
              <button
                type="button"
                onClick={() => onSelectExampleStar(selectedClass)}
                className="inline-flex items-center gap-1.5 text-cyan-300 hover:text-white transition-colors cursor-pointer underline underline-offset-4"
              >
                <span>View in Star Explorer</span>
                <span>→</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
