import React, { useState, useRef, useEffect, useCallback } from 'react';
import { audioEngine } from '../audio/AudioEngine';
import { cameraManager } from '../tracking/cameraManager';
import { handTracker } from '../tracking/handTracker';
import { LandmarkOverlay } from '../tracking/landmarkOverlay';
import { gestureInterface } from '../tracking/gestureInterface';
import { TopBar } from './TopBar';
import { PresetPanel } from './PresetPanel';
import { SettingsPanel } from './SettingsPanel';
import { CanvasViewport } from './CanvasViewport';
import { AudioBottomBar } from './AudioBottomBar';
import { CameraTrackingPanel } from './CameraTrackingPanel';
import { GestureStatusModal } from './GestureStatusModal';
import '../styles/motionbeat.css';

export const MotionBeatStudio = () => {
  // Navigation
  const [activeNav, setActiveNav] = useState('studio');

  // Visual Scene State
  const [activePreset, setActivePreset] = useState('particle-universe');
  const [graphicsQuality, setGraphicsQuality] = useState('high'); // 'high' | 'balanced' | 'low'
  const [visualSettings, setVisualSettings] = useState({
    density: 1.0,
    speed: 1.0,
    colorIntensity: 1.25,
    sensitivity: 1.2,
    cameraFov: 60,
  });

  // UI Panels State
  const [showLeftPanel, setShowLeftPanel] = useState(true);
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [showCameraPanel, setShowCameraPanel] = useState(true);
  const [isCameraMinimized, setIsCameraMinimized] = useState(false);
  const [showHUD, setShowHUD] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isGestureModalOpen, setIsGestureModalOpen] = useState(false);

  // Camera & Tracking State
  const [cameraStatus, setCameraStatus] = useState('off'); // 'off' | 'requesting' | 'active' | 'error'
  const [modelStatus, setModelStatus] = useState('uninitialized'); // 'uninitialized' | 'loading' | 'ready' | 'error'
  const [cameraError, setCameraError] = useState('');
  const [gestureEnabled, setGestureEnabled] = useState(true);
  const [trackingTelemetry, setTrackingTelemetry] = useState({
    handCount: 0,
    hands: [],
    inferenceTimeMs: 0,
    inferenceFps: 0,
  });

  // Audio State
  const [isPlaying, setIsPlaying] = useState(false);
  const [bpm, setBpm] = useState(124);
  const [volume, setVolume] = useState(0.75);
  const [currentPattern, setCurrentPattern] = useState('cyber-pulse');

  // References
  const visualEngineRef = useRef(null);
  const studioRootRef = useRef(null);
  const videoRef = useRef(null);
  const overlayCanvasRef = useRef(null);
  const overlayRendererRef = useRef(null);

  const isTrackingActiveRef = useRef(false);
  const isProcessingFrameRef = useRef(false);
  const videoFrameCallbackIdRef = useRef(null);
  const fallbackIntervalIdRef = useRef(null);
  const lastTelemetryUpdateRef = useRef(0);

  // Initialize listeners
  useEffect(() => {
    cameraManager.onStatusChange = (status, err) => {
      setCameraStatus(status);
      if (err) setCameraError(err);
    };

    handTracker.onStatusChange = (status, err) => {
      setModelStatus(status);
      if (err) setCameraError(err);
    };

    return () => {
      stopTrackingLoop();
      cameraManager.dispose();
      handTracker.dispose();
      audioEngine.dispose();
    };
  }, []);

  // Initialize 2D Canvas overlay renderer
  useEffect(() => {
    if (overlayCanvasRef.current && !overlayRendererRef.current) {
      overlayRendererRef.current = new LandmarkOverlay(overlayCanvasRef.current);
    }
  }, [showCameraPanel, isCameraMinimized]);

  // Audio Controls Handlers
  const handleTogglePlay = useCallback(() => {
    const playing = audioEngine.toggle();
    setIsPlaying(playing);
  }, []);

  const handleBpmChange = useCallback((newBpm) => {
    const clamped = Math.max(50, Math.min(220, newBpm));
    setBpm(clamped);
    audioEngine.setBpm(clamped);
  }, []);

  const handleVolumeChange = useCallback((newVol) => {
    setVolume(newVol);
    audioEngine.setVolume(newVol);
  }, []);

  const handlePatternChange = useCallback((patternId) => {
    setCurrentPattern(patternId);
    audioEngine.setPattern(patternId);
    setBpm(audioEngine.bpm);
  }, []);

  const handleResetSettings = useCallback(() => {
    setVisualSettings({
      density: 1.0,
      speed: 1.0,
      colorIntensity: 1.25,
      sensitivity: 1.2,
      cameraFov: 60,
    });
  }, []);

  // High-Efficiency Decoupled Video Frame Processor
  const processVideoFrame = (now) => {
    if (!isTrackingActiveRef.current || !videoRef.current) return;
    if (isProcessingFrameRef.current) return; // Non-reentrant

    if (videoRef.current.readyState >= 2 && handTracker.status === 'ready') {
      isProcessingFrameRef.current = true;
      try {
        const results = handTracker.detectVideo(videoRef.current, now);

        if (results) {
          if (overlayRendererRef.current) {
            overlayRendererRef.current.draw(results);
          }

          const gestureContract = gestureInterface.process(results, true);

          if (visualEngineRef.current) {
            visualEngineRef.current.updateGestureData(gestureContract);
          }

          // Throttle React state updates to 300ms to eliminate UI re-rendering overhead
          if (now - lastTelemetryUpdateRef.current > 300) {
            lastTelemetryUpdateRef.current = now;
            setTrackingTelemetry({
              handCount: results.handCount,
              hands: results.hands,
              inferenceTimeMs: results.inferenceTimeMs,
              inferenceFps: results.inferenceFps || 0,
            });
          }
        }
      } catch (err) {
        console.warn('Frame processing error:', err);
      } finally {
        isProcessingFrameRef.current = false;
      }
    }
  };

  // Schedule tracking frames with requestVideoFrameCallback (fallback to 66ms interval)
  const scheduleNextVideoFrame = () => {
    if (!isTrackingActiveRef.current || !videoRef.current) return;

    if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
      videoFrameCallbackIdRef.current = videoRef.current.requestVideoFrameCallback((now) => {
        processVideoFrame(now);
        scheduleNextVideoFrame();
      });
    }
  };

  const startTrackingLoop = () => {
    if (isTrackingActiveRef.current) return;
    isTrackingActiveRef.current = true;

    if (videoRef.current && 'requestVideoFrameCallback' in HTMLVideoElement.prototype) {
      scheduleNextVideoFrame();
    } else {
      // Fallback: dedicated 66ms timer (~15 FPS) completely isolated from Three.js render loop
      fallbackIntervalIdRef.current = setInterval(() => {
        processVideoFrame(performance.now());
      }, 66);
    }
  };

  const stopTrackingLoop = () => {
    isTrackingActiveRef.current = false;
    isProcessingFrameRef.current = false;

    if (videoRef.current && videoFrameCallbackIdRef.current && 'cancelVideoFrameCallback' in videoRef.current) {
      videoRef.current.cancelVideoFrameCallback(videoFrameCallbackIdRef.current);
      videoFrameCallbackIdRef.current = null;
    }

    if (fallbackIntervalIdRef.current) {
      clearInterval(fallbackIntervalIdRef.current);
      fallbackIntervalIdRef.current = null;
    }
  };

  // Camera Activation & Teardown Handlers
  const handleToggleCamera = async () => {
    if (cameraStatus === 'active' || cameraStatus === 'requesting') {
      stopTrackingLoop();
      cameraManager.stopCamera();
      if (overlayRendererRef.current) {
        overlayRendererRef.current.clear();
      }
      setCameraStatus('off');
      setTrackingTelemetry({ handCount: 0, hands: [], inferenceTimeMs: 0, inferenceFps: 0 });

      if (visualEngineRef.current) {
        visualEngineRef.current.updateGestureData(gestureInterface.process(null, false));
      }
    } else {
      try {
        setCameraStatus('requesting');
        setCameraError('');
        setShowCameraPanel(true);

        // 1. Request webcam stream
        await cameraManager.startCamera(videoRef.current);
        setCameraStatus('active');

        if (overlayCanvasRef.current) {
          overlayRendererRef.current = new LandmarkOverlay(overlayCanvasRef.current);
        }

        // 2. Load model
        if (handTracker.status !== 'ready') {
          setModelStatus('loading');
          await handTracker.init();
          setModelStatus('ready');
        }

        // 3. Start decoupled 12-15 FPS inference loop
        startTrackingLoop();
      } catch (err) {
        console.warn('Camera start error:', err);
        setCameraStatus('error');
        setCameraError(err.message || 'Failed to start camera.');
      }
    }
  };

  const handleToggleGesture = () => {
    const nextVal = !gestureEnabled;
    setGestureEnabled(nextVal);
    gestureInterface.setEnabled(nextVal);
    if (visualEngineRef.current) {
      visualEngineRef.current.setGestureEnabled(nextVal);
    }
  };

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      if (studioRootRef.current && studioRootRef.current.requestFullscreen) {
        studioRootRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch((e) => {
          console.warn('Fullscreen error:', e);
        });
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false)).catch((e) => {
          console.warn('Exit fullscreen error:', e);
        });
      }
    }
  }, []);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  return (
    <div
      ref={studioRootRef}
      className="relative flex flex-col w-screen h-screen overflow-hidden bg-[#030308] text-slate-100 font-sans antialiased"
    >
      {/* 1. Top Bar */}
      <TopBar
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        isFullscreen={isFullscreen}
        toggleFullscreen={toggleFullscreen}
        cameraStatus={cameraStatus}
        handCount={trackingTelemetry.handCount}
        showCameraPanel={showCameraPanel}
        setShowCameraPanel={setShowCameraPanel}
        onOpenGestureModal={() => setIsGestureModalOpen(true)}
        showLeftPanel={showLeftPanel}
        setShowLeftPanel={setShowLeftPanel}
        showRightPanel={showRightPanel}
        setShowRightPanel={setShowRightPanel}
        showHUD={showHUD}
        setShowHUD={setShowHUD}
        audioPlaying={isPlaying}
      />

      {/* 2. Main Studio Canvas & Sidebars */}
      <div className="relative flex flex-1 w-full h-[calc(100vh-4rem-4.5rem)] overflow-hidden">
        {/* Left: Visual Presets Panel */}
        <PresetPanel
          activePreset={activePreset}
          onSelectPreset={setActivePreset}
          isOpen={showLeftPanel}
          onToggle={() => setShowLeftPanel(false)}
        />

        {/* Center: Real WebGL 3D Visualization */}
        <div className="relative flex-1 w-full h-full flex flex-col overflow-hidden">
          <CanvasViewport
            visualEngineRef={visualEngineRef}
            audioEngine={audioEngine}
            activePreset={activePreset}
            settings={visualSettings}
            showHUD={showHUD}
            audioPlaying={isPlaying}
            bpm={bpm}
            trackingMode={cameraStatus === 'active' && trackingTelemetry.handCount > 0 ? 'hands' : 'mouse'}
            handCount={trackingTelemetry.handCount}
            inferenceFps={trackingTelemetry.inferenceFps}
            inferenceLatencyMs={trackingTelemetry.inferenceTimeMs}
            graphicsQuality={graphicsQuality}
            cameraStatus={cameraStatus}
            onQualityAutoChange={setGraphicsQuality}
          />

          {/* Floating Live Camera & Hand Tracking PIP Panel */}
          {showCameraPanel && (
            <div className="absolute top-4 right-4 z-25 animate-fadeIn">
              <CameraTrackingPanel
                cameraStatus={cameraStatus}
                modelStatus={modelStatus}
                errorMessage={cameraError}
                trackingTelemetry={trackingTelemetry}
                gestureEnabled={gestureEnabled}
                onToggleCamera={handleToggleCamera}
                onToggleGesture={handleToggleGesture}
                videoRef={videoRef}
                overlayCanvasRef={overlayCanvasRef}
                isMinimized={isCameraMinimized}
                onToggleMinimize={() => setIsCameraMinimized(!isCameraMinimized)}
              />
            </div>
          )}

          {/* Auxiliary Overlay when not on 'studio' tab */}
          {activeNav !== 'studio' && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-xl z-25 p-8 flex flex-col items-center justify-center text-center animate-fadeIn">
              <div className="max-w-md p-6 rounded-2xl mb-panel-elevated border border-white/10 space-y-3">
                <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-widest px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-800/40">
                  {activeNav.toUpperCase()} VIEW
                </span>
                <h3 className="text-lg font-bold text-white font-mono">
                  {activeNav === 'visuals' && '3D Visual Shaders & Presets'}
                  {activeNav === 'sounds' && 'Synthesizer Rhythm Sequencer'}
                  {activeNav === 'recordings' && 'Performance Capture'}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {activeNav === 'visuals' && 'Currently rendering 3 procedural Three.js presets: Particle Universe (45k points), Energy Waves (harmonic terrain displacement), and Neon Tunnel (Z-space hyperspace).'}
                  {activeNav === 'sounds' && 'Procedural Web Audio API sound synthesis engine with sub-bass kicks, analog hats, and resonant filter sweeps running at precision scheduler.'}
                  {activeNav === 'recordings' && 'Audio/visual performance video capture module scheduled for future development.'}
                </p>
                <button
                  onClick={() => setActiveNav('studio')}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-mono text-xs font-semibold hover:opacity-90 transition-opacity"
                >
                  Return to Performance Studio
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Visual Settings Panel */}
        <SettingsPanel
          settings={visualSettings}
          onUpdateSettings={(newVals) => setVisualSettings((prev) => ({ ...prev, ...newVals }))}
          onResetSettings={handleResetSettings}
          isOpen={showRightPanel}
          onToggle={() => setShowRightPanel(false)}
          trackingTelemetry={trackingTelemetry}
          cameraStatus={cameraStatus}
          gestureEnabled={gestureEnabled}
          onToggleGesture={handleToggleGesture}
          graphicsQuality={graphicsQuality}
          onQualityChange={(q) => {
            setGraphicsQuality(q);
            if (visualEngineRef.current) {
              visualEngineRef.current.setGraphicsQuality(q);
            }
          }}
        />
      </div>

      {/* 3. Bottom Audio Controls Console */}
      <AudioBottomBar
        audioEngine={audioEngine}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        bpm={bpm}
        onBpmChange={handleBpmChange}
        volume={volume}
        onVolumeChange={handleVolumeChange}
        currentPattern={currentPattern}
        onPatternChange={handlePatternChange}
      />

      {/* 4. Gesture Tracking Status & Setup Modal */}
      <GestureStatusModal
        isOpen={isGestureModalOpen}
        onClose={() => setIsGestureModalOpen(false)}
      />
    </div>
  );
};
