# EV SMART: Academic Presentation Slide Content
## 20 Defense-Ready Presentation Slides (Concise & Bulleted)

---

### Slide 1: Title Slide
- **Title:** EV SMART: AI & IoT-Based Smart EV Charging Station Management & Energy Optimization System
- **Subtitle:** An End-to-End Distributed IoT, Cloud Microservice & Machine Learning Platform
- **Presenter:** Final Year Engineering Project Team / Candidate
- **Academic Disclaimer:** *Laboratory prototype engineered for academic research and proof-of-concept testing. Electrical circuitry operates at scaled single-phase 230V AC prototype levels.*

---

### Slide 2: Introduction & Research Background
- **Electric Mobility Surge:** Exponential global adoption of EVs accelerating power grid transition.
- **Grid Infrastructure Bottlenecks:** Distribution transformers unequipped for concurrent, uncoordinated charging loads.
- **Legacy Charging Deficits:** Closed proprietary protocols, high operational downtime, and zero real-time grid awareness.
- **Research Goal:** Deliver an open, affordable, smart charging platform with edge safety and predictive energy optimization.

---

### Slide 3: Problem Statement
- **Peak Demand Spikes:** Concurrent charging during evening peak hours threatens local grid stability.
- **Hardware Telemetry Blind Spots:** Lack of granular voltage, current, and thermal telemetry at individual sockets.
- **Cloud-Dependent Safety Vulnerability:** Relying on remote servers for emergency disconnection poses severe fire hazards during network dropouts.
- **Driver Friction:** Inaccurate station availability, charger queuing, and opaque billing models.
- **Static Inflexible Pricing:** Flat-rate tariffs fail to incentivize load shifting away from peak grid hours.

---

### Slide 4: Project Objectives
- **Build Physical IoT Edge Prototype:** ESP32 controller with PZEM-004T AC metering, DHT22 thermal sensing, and relay actuation.
- **Engineer Autonomous Edge Safety:** Sub-50ms local hardware disconnect on overtemperature ($>60^\circ\text{C}$) or overcurrent ($>32\text{A}$).
- **Deploy Resilient Telemetry Pipeline:** Low-overhead MQTT pub/sub streaming with automated HTTP REST fallback.
- **Integrate Predictive AI:** Scikit-learn Random Forest for 24-hr load forecasting and Isolation Forest for anomaly detection.
- **Develop Dual Client Portals:** Mobile-first PWA for EV drivers and an Executive Fleet Dashboard for network operators.
- **Verify Rigorously:** Validate via 200+ automated test assertions and real-world electrical benchmarking.

---

### Slide 5: Overall System Architecture
- **Four-Tier Decoupled Architecture:**
  - **Edge Tier:** Dual-core ESP32 with FreeRTOS and electrical sensors.
  - **Transport Tier:** Eclipse Mosquitto MQTT broker (TCP 1883) + REST API gateway.
  - **Cloud Services Tier:** Node.js/Express core backend + Python FastAPI AI microservice + MongoDB.
  - **Presentation Tier:** React 18 SPA serving Driver Mobile App and Admin Fleet Dashboard via Socket.IO.

---

### Slide 6: IoT Hardware Layer & Sensors
- **ESP32 Microcontroller:** Dual-core 240MHz Xtensa LX6 with built-in Wi-Fi & Bluetooth LE.
- **PZEM-004T v3.0 Sensor:** True RMS measurement of Voltage, Current, Active Power, Energy, Frequency, and Power Factor via UART2.
- **DHT22 Sensor:** Digital enclosure temperature and humidity tracking for thermal runaway prevention.
- **30A Optocoupled Relay:** Active-low transistor-buffered isolation switching AC power to the EV socket.
- **Physical Emergency Pushbutton:** Panel-mounted mechanical stop triggering zero-latency hardware interrupt.
- **Local 16x2 I2C LCD:** Real-time on-device status display for on-site diagnostic monitoring.

---

### Slide 7: Autonomous Edge Safety & FreeRTOS Decoupling
- **Dual-Core Task Separation:**
  - **Core 0 (Safety & Sensors):** Dedicated FreeRTOS task polling sensors and enforcing thermal limits every 100ms.
  - **Core 1 (Network & Telemetry):** Wi-Fi stack, MQTT client, and JSON serialization.
- **Zero-Cloud Dependency:** If Wi-Fi fails or cloud server crashes, local trip logic remains 100% active.
- **Hardware Trip Thresholds:**
  - Temperature $> 60^\circ\text{C} \implies$ Immediate relay de-energize.
  - Current $> 32\text{A} \implies$ Instant trip to prevent electrical fire.
- **Local Ring Buffer:** Caches up to 60 telemetry frames in SRAM during Wi-Fi outages to prevent data loss.

---

### Slide 8: Dual-Channel IoT Communication
- **Primary Channel (MQTT):**
  - Lightweight publish/subscribe via Eclipse Mosquitto broker.
  - Topics: `ev/station/{id}/charger/{id}/telemetry` and `/command`.
  - Sub-50ms message delivery; minimal packet overhead.
- **Failover Channel (HTTP REST):**
  - Automatic switch to `POST /api/iot/telemetry` if MQTT broker connection drops.
  - Guarantees telemetry delivery across restricted enterprise or cellular firewalls.

---

### Slide 9: Backend Cloud Architecture & Streaming
- **Node.js & Express Pipeline:** High-concurrency event-driven architecture using asynchronous I/O.
- **Real-Time WebSocket Gateway:** Socket.IO server pushing live sensor streams to subscribed clients at 1Hz.
- **Microservice Separation:** Clean decoupling between transactional REST APIs and heavy ML mathematical models.
- **Database Engine:** MongoDB Enterprise with Mongoose ODM utilizing compound indexing on `[stationId, chargerId]`.

---

### Slide 10: Database Schema & Entity Relationships
- **Core Collections:**
  - `Users`: Driver, Operator, and Admin credentials with salted bcrypt hashes.
  - `Stations` & `Chargers`: Physical coordinates, power ratings, connector types, and live operational states.
  - `Bookings`: Time-slot reservation registry with conflict-prevention constraints.
  - `ChargingSessions`: Immutable record of energy delivered, duration, and final bill.
  - `Telemetry`: High-frequency timeseries sensor logs (V, I, P, E, T, PF).
  - `AuditLogs`: Append-only tamper-evident security and administrative ledger.

---

### Slide 11: End-User Mobile Application
- **Mobile-First Experience:** Built with React 18, Vite, and Tailwind CSS for 60 FPS mobile responsiveness.
- **Station Discovery:** Geolocation map with instant connector availability indicators.
- **Slot Reservation:** Interactive calendar preventing double-booking and station congestion.
- **Live Charging Cockpit:** Circular SOC gauge, real-time power/current sparklines, and session cost counter.
- **Digital Wallet & History:** Transparent pre-paid wallet system and itemized downloadable receipts.

---

### Slide 12: Admin Fleet Management Dashboard
- **Executive Operations Center:** Real-time visibility across all stations, active load (kW), and network revenue.
- **Multi-Charger Fleet Grid:** Dynamic status tiles showing live state (Available, Charging, Faulted, Offline).
- **Deep Charger Diagnostics:** Remote view of raw electrical telemetry, Wi-Fi RSSI, and firmware health.
- **Centralized Control Overrides:** Ability to initiate remote reboots or execute network-wide emergency disconnects.
- **Fault Triage Center:** Chronological log of electrical and thermal incidents with resolution tracking.

---

### Slide 13: Operational & Energy Analytics
- **Aggregated Energy Curves:** Node.js aggregation pipelines summarizing daily, weekly, and monthly consumption.
- **Station Utilization Heatmap:** 24x7 grid correlating time-of-day vs day-of-week charger occupancy.
- **Peak Demand Factor Analysis:** Identifies peak load hours to guide grid infrastructure reinforcement.
- **Revenue Intelligence:** Itemized tracking of energy sales, peak surcharges, and operator margins.

---

### Slide 14: AI Engine: 24-Hour Ahead Demand Forecasting
- **Dedicated Python FastAPI Microservice:** Sub-11ms REST inference via Scikit-learn & Joblib.
- **Algorithm:** Random Forest Regressor trained on cyclical temporal features (sin/cos encoding of hour and day of week).
- **Feature Pipeline:** Historical load lags, ambient temperature, day-of-week, and holiday flags.
- **Empirical Accuracy:**
  - Coefficient of Determination ($R^2$): **0.9902**
  - Mean Absolute Error (MAE): **3.09 kWh**
  - Root Mean Squared Error (RMSE): **4.41 kWh**
- **Operational Utility:** Enables utility peak-shaving and proactive energy storage dispatch.

---

### Slide 15: AI Engine: Anomaly Detection & Predictive Maintenance
- **Unsupervised Telemetry Screening:** Scikit-learn **Isolation Forest** evaluating 5D electrical vectors $[V, I, P, T, \text{PF}]$.
- **Contamination Parameter:** Set at 5% to isolate genuine outliers while suppressing false alarms.
- **Anomaly Signatures Detected:** Voltage sags, current harmonic spikes, power factor degradation, and thermal anomalies.
- **Predictive Maintenance Index:** Dynamic health score calculating cumulative thermal stress and relay cycle count.

---

### Slide 16: Dynamic Tariff & Smart Grid Optimization
- **Economic Load Shifting:** Automatically scales charging tariffs based on forecasted grid demand.
- **Tariff Formula:**  
  $$\text{Tariff} = \text{Base Rate} \times \text{Peak Multiplier} + \text{Tax} + \text{Platform Fee}$$
- **Multiplier Tiers:**
  - Off-Peak ($00:00 - 06:00$): $0.8\times$ (Discount incentive)
  - Standard ($06:00 - 17:00$): $1.0\times$ (Baseline rate)
  - Critical Peak ($17:00 - 22:00$): $1.4\times - 1.6\times$ (Demand suppression)
- **Grid Benefit:** Flattens evening demand spikes by financially incentivizing daytime and late-night charging.

---

### Slide 17: Cybersecurity, RBAC & Immutable Auditing
- **Authentication & Authorization:** Stateless HMAC-SHA256 JWT tokens with role-based middleware (`driver`, `operator`, `admin`).
- **Cryptographic Security:** bcrypt password hashing with 10 salt rounds; plaintext passwords strictly barred.
- **Network Hardening:** Helmet HTTP security headers, CORS domain whitelisting, and IP-based rate limiting (100 req / 15 min).
- **Tamper-Evident Audit Trail:** MongoDB append-only audit stream tracking all critical configuration changes and emergency stops.

---

### Slide 18: Empirical Benchmarks & Test Results
- **Automated Test Suite Pass Rate:** **202 / 202 assertions passing (100%)** across 6 integration test suites.
- **API Latency Benchmarks (Physical Testbench):**
  - Health Endpoint: **14.86 ms**
  - User Batch Query (10 users): **45.27 ms**
  - Sensor Ingestion Pipeline (25 packets): **17.45 ms**
  - Charging Session Bulk Query: **63.98 ms**
  - ML Demand Inference: **10.93 ms**
- **Frontend Build Performance:** Production bundle generated cleanly via Vite in **1.10 seconds** (0 lint/build warnings).

---

### Slide 19: System Limitations & Boundary Conditions
- **Laboratory Prototype Scale:** Built and validated on single-phase 230V AC up to 16A; high-power DC Fast Charging (CCS2 50kW–350kW) is not physically implemented.
- **Protocol Boundary:** Implements custom lightweight JSON-over-MQTT/REST rather than full enterprise OCPP 2.0.1.
- **Simulated Payment Sandbox:** Wallet financial transactions are verified via mock crypto hashes rather than live banking webhooks.
- **Synthetic Dataset Grounding:** ML models trained on physics-calibrated synthetic EV load distributions.

---

### Slide 20: Future Scope & Conclusion
- **Future Research Directions:**
  - Full OCPP 2.0.1 and ISO 15118 (Plug & Charge) protocol stack implementation.
  - Vehicle-to-Grid (V2G) bi-directional power flow integration.
  - Edge TinyML inference on ESP32 using quantized neural networks.
  - 4G/LTE cellular hardware integration for remote off-grid locations.
- **Conclusion:** EV SMART successfully delivers a verified, resilient, and intelligent IoT & AI charging infrastructure platform that bridges physical edge safety with cloud energy optimization.
