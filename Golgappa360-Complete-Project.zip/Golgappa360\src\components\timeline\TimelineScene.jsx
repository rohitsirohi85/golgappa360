import React, { useRef, useEffect, useState } from 'react';

/**
 * TimelineScene — Category-adaptive Visual Canvas for Cosmic Milestones (Phase U13)
 * 
 * Renders lightweight, cinematic visual simulations for all 10 cosmic milestones:
 * 1. Big Bang: Omnipresent expanding thermal field & quantum fluctuations (not a bomb explosion)
 * 2. First Atoms: Recombination cooling, Cosmic Microwave Background ripples & Dark Ages
 * 3. First Stars: Dark void pierced by brilliant blue-white Population III ignition sparks
 * 4. Early Galaxies: Clumpy protogalactic swirls and merging stellar nurseries
 * 5. Milky Way: Majestic barred spiral galaxy disc with galactic core and spiral arms
 * 6. Solar Nebula: Protoplanetary disk with dust accretion gaps around infant Sun
 * 7. Early Earth: Molten Hadean proto-world with magma fissures and outgassing atmosphere
 * 8. Moon Impact: Giant impact debris disk coalescing into the young Moon
 * 9. Present Universe: Stable modern Solar System and deep-space celestial overview
 * 10. Sun's Future: Interactive 4-stage evolutionary sequence (Main Sequence → Red Giant → Nebula → White Dwarf)
 * 
 * Optimized for high performance and respects prefers-reduced-motion.
 */
export default function TimelineScene({
  milestone,
  futureStageIndex = 0,
  onSelectFutureStage = null,
  className = '',
}) {
  const canvasRef = useRef(null);
  const animationFrameRef = useRef(null);
  const timeRef = useRef(0);

  // Check prefers-reduced-motion
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      setPrefersReducedMotion(mediaQuery.matches);

      const handler = (e) => setPrefersReducedMotion(e.matches);
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;

    // Handle high DPI display
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particle cache for stable procedural animations
    const numParticles = 65;
    const particles = Array.from({ length: numParticles }, (_, i) => ({
      angle: (i / numParticles) * Math.PI * 2,
      dist: 20 + Math.random() * 140,
      speed: 0.2 + Math.random() * 0.8,
      size: 1 + Math.random() * 2.5,
      alpha: 0.3 + Math.random() * 0.7,
      color: i % 2 === 0 ? '#38bdf8' : '#fbbf24',
    }));

    const render = (timestamp) => {
      if (!isRunning) return;

      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;
      const cx = width / 2;
      const cy = height / 2;

      // Update time if motion allowed
      if (!prefersReducedMotion) {
        timeRef.current += 0.016;
      }
      const t = timeRef.current;

      ctx.clearRect(0, 0, width, height);

      const type = milestone?.visualType || 'big-bang';

      switch (type) {
        // -----------------------------------------------------------------
        // 01: BIG BANG — EXPANDING HOT UNIVERSE
        // -----------------------------------------------------------------
        case 'big-bang': {
          // Dark canvas background with radial warmth
          const bgGrad = ctx.createRadialGradient(cx, cy, 10, cx, cy, Math.max(width, height) * 0.6);
          bgGrad.addColorStop(0, 'rgba(251, 146, 60, 0.45)');
          bgGrad.addColorStop(0.3, 'rgba(239, 68, 68, 0.2)');
          bgGrad.addColorStop(0.7, 'rgba(147, 51, 234, 0.08)');
          bgGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, width, height);

          // Omnipresent Expanding Radiant Field (Concentric expanding waves)
          for (let i = 0; i < 4; i++) {
            const waveRadius = ((t * 25 + i * 50) % 200) + 10;
            const alpha = Math.max(0, 1 - waveRadius / 200) * 0.4;
            ctx.beginPath();
            ctx.arc(cx, cy, waveRadius, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(254, 215, 170, ${alpha})`;
            ctx.lineWidth = 1.5;
            ctx.stroke();
          }

          // Central Primordial Glow
          const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 70);
          coreGrad.addColorStop(0, '#ffffff');
          coreGrad.addColorStop(0.2, '#fef08a');
          coreGrad.addColorStop(0.6, '#f97316');
          coreGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
          ctx.beginPath();
          ctx.arc(cx, cy, 70, 0, Math.PI * 2);
          ctx.fillStyle = coreGrad;
          ctx.fill();

          // Quantum foam particles
          particles.forEach((p, idx) => {
            const curDist = ((p.dist + t * p.speed * 30) % 180) + 10;
            const px = cx + Math.cos(p.angle + t * 0.1) * curDist;
            const py = cy + Math.sin(p.angle + t * 0.1) * curDist;
            const pAlpha = Math.max(0, 1 - curDist / 180) * 0.8;

            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, Math.PI * 2);
            ctx.fillStyle = idx % 2 === 0 ? `rgba(254, 240, 138, ${pAlpha})` : `rgba(244, 63, 94, ${pAlpha})`;
            ctx.fill();
          });
          break;
        }

        // -----------------------------------------------------------------
        // 02: FIRST ATOMS — COSMIC DARK AGES & RECOMBINATION
        // -----------------------------------------------------------------
        case 'first-atoms': {
          // Faint, cooling CMB background noise glow
          const cmbGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, 180);
          cmbGrad.addColorStop(0, 'rgba(99, 102, 241, 0.15)');
          cmbGrad.addColorStop(0.5, 'rgba(139, 92, 246, 0.08)');
          cmbGrad.addColorStop(1, 'rgba(3, 5, 14, 0)');
          ctx.fillStyle = cmbGrad;
          ctx.fillRect(0, 0, width, height);

          // Subtle CMB fluctuations / standing ripples
          for (let r = 0; r < 5; r++) {
            const rippleR = 40 + r * 30 + Math.sin(t * 1.5 + r) * 6;
            ctx.beginPath();
            ctx.arc(cx, cy, rippleR, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(165, 180, 252, ${0.12 - r * 0.02})`;
            ctx.lineWidth = 1;
            ctx.setLineDash([4, 6]);
            ctx.stroke();
            ctx.setLineDash([]);
          }

          // Neutral Hydrogen & Helium Atomic Seeds
          particles.forEach((p, idx) => {
            const px = cx + Math.cos(p.angle) * p.dist;
            const py = cy + Math.sin(p.angle) * p.dist;
            const pulse = 0.5 + Math.sin(t * 2 + idx) * 0.3;

            // Free electron / proton bonding aura
            ctx.beginPath();
            ctx.arc(px, py, p.size * 1.2, 0, Math.PI * 2);
            ctx.fillStyle = idx % 3 === 0 ? `rgba(129, 140, 248, ${pulse * 0.6})` : `rgba(224, 231, 255, ${pulse * 0.4})`;
            ctx.fill();
          });
          break;
        }

        // -----------------------------------------------------------------
        // 03: FIRST STARS — POPULATION III IGNITION
        // -----------------------------------------------------------------
        case 'first-stars': {
          // Deep inky void
          ctx.fillStyle = '#020308';
          ctx.fillRect(0, 0, width, height);

          // Intense primordial blue stars bursting through the dark
          const starNodes = [
            { x: cx, y: cy, size: 8, glow: 50, color: '#67e8f9' },
            { x: cx - 65, y: cy - 40, size: 5, glow: 35, color: '#38bdf8' },
            { x: cx + 75, y: cy + 30, size: 6, glow: 40, color: '#bae6fd' },
            { x: cx - 40, y: cy + 60, size: 4, glow: 28, color: '#60a5fa' },
            { x: cx + 55, y: cy - 55, size: 4.5, glow: 30, color: '#93c5fd' },
          ];

          starNodes.forEach((star, sIdx) => {
            const twinkle = 1 + Math.sin(t * 3 + sIdx * 1.5) * 0.2;
            const sGlow = star.glow * twinkle;

            // Reionization ultraviolet halo
            const haloGrad = ctx.createRadialGradient(star.x, star.y, 0, star.x, star.y, sGlow);
            haloGrad.addColorStop(0, 'rgba(56, 189, 248, 0.7)');
            haloGrad.addColorStop(0.4, 'rgba(14, 165, 233, 0.25)');
            haloGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
            ctx.beginPath();
            ctx.arc(star.x, star.y, sGlow, 0, Math.PI * 2);
            ctx.fillStyle = haloGrad;
            ctx.fill();

            // Diamond diffraction spike
            ctx.strokeStyle = 'rgba(224, 242, 254, 0.4)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(star.x - sGlow * 0.7, star.y);
            ctx.lineTo(star.x + sGlow * 0.7, star.y);
            ctx.moveTo(star.x, star.y - sGlow * 0.7);
            ctx.lineTo(star.x, star.y + sGlow * 0.7);
            ctx.stroke();

            // Intense white stellar nucleus
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.fill();
          });
          break;
        }

        // -----------------------------------------------------------------
        // 04: EARLY GALAXIES — PROTOGALACTIC CLUSTERING
        // -----------------------------------------------------------------
        case 'early-galaxies': {
          // Turbulent clumpy gas bridges
          for (let g = 0; g < 3; g++) {
            const gx = cx + Math.cos(t * 0.2 + g * 2) * 45;
            const gy = cy + Math.sin(t * 0.2 + g * 2) * 35;
            const gGrad = ctx.createRadialGradient(gx, gy, 5, gx, gy, 65);
            gGrad.addColorStop(0, 'rgba(168, 85, 247, 0.35)');
            gGrad.addColorStop(0.5, 'rgba(59, 130, 246, 0.15)');
            gGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');

            ctx.beginPath();
            ctx.arc(gx, gy, 65, 0, Math.PI * 2);
            ctx.fillStyle = gGrad;
            ctx.fill();
          }

          // Embedded protogalactic stellar knots
          particles.forEach((p, idx) => {
            const rot = p.angle + t * 0.35 * (idx % 2 === 0 ? 1 : -0.8);
            const rDist = p.dist * 0.75;
            const px = cx + Math.cos(rot) * rDist;
            const py = cy + Math.sin(rot) * (rDist * 0.65);

            ctx.beginPath();
            ctx.arc(px, py, p.size * 0.9, 0, Math.PI * 2);
            ctx.fillStyle = idx % 2 === 0 ? 'rgba(192, 132, 252, 0.7)' : 'rgba(147, 197, 253, 0.7)';
            ctx.fill();
          });
          break;
        }

        // -----------------------------------------------------------------
        // 05: MILKY WAY — BARRED SPIRAL GALAXY
        // -----------------------------------------------------------------
        case 'milky-way': {
          // Rotating Spiral Disc
          const angleOffset = t * 0.15;

          // Glowing Galactic Bulge
          const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 55);
          coreGrad.addColorStop(0, '#ffffff');
          coreGrad.addColorStop(0.3, '#fef08a');
          coreGrad.addColorStop(0.7, 'rgba(56, 189, 248, 0.25)');
          coreGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
          ctx.beginPath();
          ctx.arc(cx, cy, 55, 0, Math.PI * 2);
          ctx.fillStyle = coreGrad;
          ctx.fill();

          // Two main spiral arms
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(angleOffset);

          for (let arm = 0; arm < 2; arm++) {
            const armAngle = arm * Math.PI;
            ctx.beginPath();
            for (let s = 10; s < 130; s += 4) {
              const theta = armAngle + (s / 130) * Math.PI * 2.2;
              const r = s;
              const ax = Math.cos(theta) * r;
              const ay = Math.sin(theta) * (r * 0.55); // Tilted perspective
              if (s === 10) ctx.moveTo(ax, ay);
              else ctx.lineTo(ax, ay);
            }
            ctx.strokeStyle = arm === 0 ? 'rgba(56, 189, 248, 0.35)' : 'rgba(244, 114, 182, 0.3)';
            ctx.lineWidth = 14;
            ctx.stroke();
          }

          // Embedded star points along arms
          particles.forEach((p, idx) => {
            const pTheta = p.angle + (p.dist / 140) * Math.PI * 2;
            const px = Math.cos(pTheta) * p.dist;
            const py = Math.sin(pTheta) * (p.dist * 0.55);

            ctx.beginPath();
            ctx.arc(px, py, p.size * 0.8, 0, Math.PI * 2);
            ctx.fillStyle = idx % 2 === 0 ? '#38bdf8' : '#fed7aa';
            ctx.fill();
          });

          ctx.restore();
          break;
        }

        // -----------------------------------------------------------------
        // 06: SOLAR NEBULA — PROTOPLANETARY DISK
        // -----------------------------------------------------------------
        case 'solar-nebula': {
          // Central infant Sun (Proto-Sun)
          const sunGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 40);
          sunGrad.addColorStop(0, '#ffffff');
          sunGrad.addColorStop(0.3, '#fde047');
          sunGrad.addColorStop(0.7, '#ea580c');
          sunGrad.addColorStop(1, 'rgba(234, 88, 12, 0)');
          ctx.beginPath();
          ctx.arc(cx, cy, 40, 0, Math.PI * 2);
          ctx.fillStyle = sunGrad;
          ctx.fill();

          // Swirling Protoplanetary Rings with Accretion Gaps
          const ringRadii = [50, 75, 105, 135];
          ringRadii.forEach((r, idx) => {
            ctx.save();
            ctx.translate(cx, cy);
            ctx.scale(1, 0.45); // Tilted disk
            ctx.beginPath();
            ctx.arc(0, 0, r, 0, Math.PI * 2);
            ctx.strokeStyle = idx % 2 === 0 ? 'rgba(251, 191, 36, 0.35)' : 'rgba(249, 115, 22, 0.25)';
            ctx.lineWidth = 12;
            ctx.stroke();

            // Condensing protoplanet seeds
            const seedAngle = t * (0.8 / (idx + 1)) + idx * 1.5;
            const sx = Math.cos(seedAngle) * r;
            const sy = Math.sin(seedAngle) * r;
            ctx.beginPath();
            ctx.arc(sx, sy, 3 + idx * 0.8, 0, Math.PI * 2);
            ctx.fillStyle = idx === 1 ? '#38bdf8' : idx === 2 ? '#fbbf24' : '#cbd5e1';
            ctx.fill();

            ctx.restore();
          });
          break;
        }

        // -----------------------------------------------------------------
        // 07: EARLY EARTH — HADEAN MOLTEN WORLD
        // -----------------------------------------------------------------
        case 'early-earth': {
          // Volcanic Hadean Atmosphere Glow
          const earthAtmosphere = ctx.createRadialGradient(cx, cy, 45, cx, cy, 85);
          earthAtmosphere.addColorStop(0, 'rgba(239, 68, 68, 0.35)');
          earthAtmosphere.addColorStop(0.7, 'rgba(249, 115, 22, 0.15)');
          earthAtmosphere.addColorStop(1, 'rgba(2, 3, 8, 0)');
          ctx.beginPath();
          ctx.arc(cx, cy, 85, 0, Math.PI * 2);
          ctx.fillStyle = earthAtmosphere;
          ctx.fill();

          // Rocky Molten Body
          const earthGrad = ctx.createRadialGradient(cx - 15, cy - 15, 5, cx, cy, 55);
          earthGrad.addColorStop(0, '#78350f');
          earthGrad.addColorStop(0.4, '#451a03');
          earthGrad.addColorStop(0.8, '#1c1917');
          earthGrad.addColorStop(1, '#09090b');
          ctx.beginPath();
          ctx.arc(cx, cy, 55, 0, Math.PI * 2);
          ctx.fillStyle = earthGrad;
          ctx.fill();

          // Magma fractures / glowing lava veins
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(t * 0.08);
          ctx.beginPath();
          ctx.arc(0, 0, 53, 0, Math.PI * 2);
          ctx.clip();

          for (let f = 0; f < 5; f++) {
            const fAngle = f * 1.25;
            ctx.beginPath();
            ctx.moveTo(Math.cos(fAngle) * 15, Math.sin(fAngle) * 15);
            ctx.quadraticCurveTo(
              Math.cos(fAngle + 0.5) * 35,
              Math.sin(fAngle + 0.5) * 35,
              Math.cos(fAngle) * 55,
              Math.sin(fAngle) * 55
            );
            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 2.5;
            ctx.shadowColor = '#f97316';
            ctx.shadowBlur = 6;
            ctx.stroke();
          }
          ctx.restore();
          break;
        }

        // -----------------------------------------------------------------
        // 08: MOON IMPACT — THEIA COLLISION DEBRIS RING
        // -----------------------------------------------------------------
        case 'moon-impact': {
          // Central Post-Impact Earth
          const earthBody = ctx.createRadialGradient(cx - 10, cy - 10, 5, cx, cy, 45);
          earthBody.addColorStop(0, '#f97316');
          earthBody.addColorStop(0.5, '#78350f');
          earthBody.addColorStop(1, '#1c1917');
          ctx.beginPath();
          ctx.arc(cx, cy, 45, 0, Math.PI * 2);
          ctx.fillStyle = earthBody;
          ctx.fill();

          // Incandescent Orbiting Debris Ring (Tilted)
          ctx.save();
          ctx.translate(cx, cy);
          ctx.scale(1, 0.4);
          ctx.rotate(-0.35);

          // Glowing debris ring
          ctx.beginPath();
          ctx.arc(0, 0, 95, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(251, 146, 60, 0.45)';
          ctx.lineWidth = 14;
          ctx.shadowColor = '#f97316';
          ctx.shadowBlur = 10;
          ctx.stroke();

          // Coalescing proto-Moon knot
          const moonAngle = t * 0.6;
          const mx = Math.cos(moonAngle) * 95;
          const my = Math.sin(moonAngle) * 95;
          ctx.beginPath();
          ctx.arc(mx, my, 12, 0, Math.PI * 2);
          ctx.fillStyle = '#e2e8f0';
          ctx.shadowColor = '#fdba74';
          ctx.shadowBlur = 8;
          ctx.fill();

          ctx.restore();
          break;
        }

        // -----------------------------------------------------------------
        // 09: PRESENT UNIVERSE — MODERN SOLAR SYSTEM & SKY
        // -----------------------------------------------------------------
        case 'present-universe': {
          // Ambient stellar expanse
          particles.forEach((p, idx) => {
            const px = cx + Math.cos(p.angle) * p.dist * 1.1;
            const py = cy + Math.sin(p.angle) * p.dist * 0.8;
            ctx.beginPath();
            ctx.arc(px, py, p.size * 0.7, 0, Math.PI * 2);
            ctx.fillStyle = idx % 2 === 0 ? 'rgba(56, 189, 248, 0.6)' : 'rgba(255, 255, 255, 0.7)';
            ctx.fill();
          });

          // Sun with corona on left
          const sunX = cx - 55;
          const sunY = cy;
          const sunCorona = ctx.createRadialGradient(sunX, sunY, 15, sunX, sunY, 65);
          sunCorona.addColorStop(0, 'rgba(254, 240, 138, 0.8)');
          sunCorona.addColorStop(0.4, 'rgba(245, 158, 11, 0.35)');
          sunCorona.addColorStop(1, 'rgba(2, 3, 8, 0)');
          ctx.beginPath();
          ctx.arc(sunX, sunY, 65, 0, Math.PI * 2);
          ctx.fillStyle = sunCorona;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(sunX, sunY, 22, 0, Math.PI * 2);
          ctx.fillStyle = '#fef08a';
          ctx.fill();

          // Blue Marble Earth with atmosphere on right
          const earthX = cx + 65;
          const earthY = cy - 10;
          const earthAtm = ctx.createRadialGradient(earthX, earthY, 14, earthX, earthY, 26);
          earthAtm.addColorStop(0, 'rgba(56, 189, 248, 0.6)');
          earthAtm.addColorStop(1, 'rgba(2, 3, 8, 0)');
          ctx.beginPath();
          ctx.arc(earthX, earthY, 26, 0, Math.PI * 2);
          ctx.fillStyle = earthAtm;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(earthX, earthY, 14, 0, Math.PI * 2);
          ctx.fillStyle = '#0284c7';
          ctx.fill();

          // Moon orbiting Earth
          const mAngle = t * 1.2;
          const moonX = earthX + Math.cos(mAngle) * 32;
          const moonY = earthY + Math.sin(mAngle) * 14;
          ctx.beginPath();
          ctx.arc(moonX, moonY, 3.5, 0, Math.PI * 2);
          ctx.fillStyle = '#e2e8f0';
          ctx.fill();
          break;
        }

        // -----------------------------------------------------------------
        // 10: SUN'S FUTURE — 4-STAGE STELLAR EVOLUTION
        // -----------------------------------------------------------------
        case 'sun-future': {
          const stage = futureStageIndex || 0;

          // Stage 0: Sun Today
          if (stage === 0) {
            const sunGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 65);
            sunGrad.addColorStop(0, '#ffffff');
            sunGrad.addColorStop(0.3, '#fde047');
            sunGrad.addColorStop(0.7, 'rgba(245, 158, 11, 0.3)');
            sunGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
            ctx.beginPath();
            ctx.arc(cx, cy, 65, 0, Math.PI * 2);
            ctx.fillStyle = sunGrad;
            ctx.fill();

            ctx.beginPath();
            ctx.arc(cx, cy, 32, 0, Math.PI * 2);
            ctx.fillStyle = '#fef08a';
            ctx.fill();
          }
          // Stage 1: Red Giant
          else if (stage === 1) {
            const pulse = 1 + Math.sin(t * 1.5) * 0.05;
            const rGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, 110 * pulse);
            rGrad.addColorStop(0, '#fbbf24');
            rGrad.addColorStop(0.4, '#ef4444');
            rGrad.addColorStop(0.8, 'rgba(185, 28, 28, 0.3)');
            rGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
            ctx.beginPath();
            ctx.arc(cx, cy, 110 * pulse, 0, Math.PI * 2);
            ctx.fillStyle = rGrad;
            ctx.fill();

            ctx.beginPath();
            ctx.arc(cx, cy, 75 * pulse, 0, Math.PI * 2);
            ctx.fillStyle = '#dc2626';
            ctx.fill();
          }
          // Stage 2: Planetary Nebula
          else if (stage === 2) {
            // Ejected gas shell (Ring-shaped expansion)
            const ringR = 65 + Math.sin(t * 1.2) * 6;
            const nebGrad = ctx.createRadialGradient(cx, cy, 35, cx, cy, ringR + 35);
            nebGrad.addColorStop(0, 'rgba(6, 182, 212, 0.1)');
            nebGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.45)');
            nebGrad.addColorStop(0.8, 'rgba(244, 63, 94, 0.3)');
            nebGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
            ctx.beginPath();
            ctx.arc(cx, cy, ringR + 35, 0, Math.PI * 2);
            ctx.fillStyle = nebGrad;
            ctx.fill();

            // Central nascent white dwarf core
            ctx.beginPath();
            ctx.arc(cx, cy, 6, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.shadowColor = '#38bdf8';
            ctx.shadowBlur = 12;
            ctx.fill();
            ctx.shadowBlur = 0;
          }
          // Stage 3: White Dwarf
          else {
            // Faint, dense violet cooling aura
            const wdGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 45);
            wdGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
            wdGrad.addColorStop(0.2, 'rgba(167, 139, 250, 0.4)');
            wdGrad.addColorStop(0.6, 'rgba(99, 102, 241, 0.1)');
            wdGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
            ctx.beginPath();
            ctx.arc(cx, cy, 45, 0, Math.PI * 2);
            ctx.fillStyle = wdGrad;
            ctx.fill();

            // Tiny ultra-dense Earth-sized nucleus
            ctx.beginPath();
            ctx.arc(cx, cy, 5, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.shadowColor = '#a78bfa';
            ctx.shadowBlur = 10;
            ctx.fill();
            ctx.shadowBlur = 0;
          }
          break;
        }

        default:
          break;
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      isRunning = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [milestone, futureStageIndex, prefersReducedMotion]);

  const isFuture = milestone?.id === 'sun-future';
  const futureStages = milestone?.futureStages || [];

  return (
    <div className={`relative w-full h-full flex flex-col items-center justify-center select-none overflow-hidden ${className}`}>
      {/* Visual Canvas Element */}
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        aria-label={`Visual simulation for ${milestone?.title || 'Cosmic Timeline'}`}
      />

      {/* Interactive Sub-Stage Tabs for Sun's Future (Milestone 10) */}
      {isFuture && futureStages.length > 0 && onSelectFutureStage && (
        <div className="absolute bottom-4 left-4 right-4 z-20 flex justify-center pointer-events-auto">
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 rounded-2xl bg-[#020308]/90 backdrop-blur-xl border border-white/10 shadow-[0_4px_24px_rgba(0,0,0,0.8)] max-w-full">
            {futureStages.map((stage, idx) => {
              const isActive = futureStageIndex === idx;
              return (
                <button
                  key={stage.id}
                  type="button"
                  onClick={() => onSelectFutureStage(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-purple-500/25 border border-purple-400/60 text-purple-200 font-semibold shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                      : 'bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span style={{ color: stage.color }} className="text-sm leading-none">
                    ●
                  </span>
                  <span className="hidden sm:inline">{stage.name}</span>
                  <span className="sm:hidden">{idx + 1}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
