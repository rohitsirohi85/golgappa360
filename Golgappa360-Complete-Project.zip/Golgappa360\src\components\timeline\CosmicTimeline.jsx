import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import TimelineScene from './TimelineScene';
import {
  COSMIC_MILESTONES,
  TIMELINE_ERAS,
  getMilestoneById,
  getMilestoneByIndex,
} from '../../data/timelineData.js';
import {
  getCelestialObjectById,
  CATEGORY_SYMBOLS,
  CATEGORY_LABELS,
} from '../../data/celestialObjects.js';

/**
 * CosmicTimeline — STELLAR 2.0 (Phase U13: Interactive Cosmic Timeline)
 * 
 * Cinematic, full-screen exploration through cosmic history:
 * 1. Big Bang (~13.8 billion years ago)
 * 2. First Atoms & Dark Ages (~380,000 years ABB)
 * 3. First Stars (~100–200 million years ABB)
 * 4. Early Galaxies (~400–800 million years ABB)
 * 5. Milky Way Development (~10–13 billion years ago)
 * 6. Solar System Formation (~4.6 billion years ago)
 * 7. Early Earth Forms (~4.5 billion years ago)
 * 8. Moon Formation (~4.5 billion years ago)
 * 9. Present Day Universe (Now)
 * 10. The Sun's Future (~5 billion years in future)
 * 
 * Features:
 * - Persistent animated COSMIC TIME indicator
 * - PAST / PRESENT / FUTURE era conceptual division
 * - Interactive horizontal scrubber (desktop) & responsive vertical/swipeable journey (mobile)
 * - Category-adaptive procedural canvas visualizer
 * - Seamless bridge navigation to existing STELLAR systems (Universe Map, Solar System, Earth, Moon, Stars, Life Cycle)
 * - Deep linking URL hash support (#timeline=id)
 * - Accessible keyboard shortcuts (ArrowLeft, ArrowRight, Escape)
 */
export default function CosmicTimeline({
  isOpen = true,
  initialMilestoneId = null,
  onClose,
  onEnterPresentUniverse,
  onExploreSolarSystem,
  onExploreEarth,
  onExploreMoon,
  onExploreStars,
  onExploreLifeCycle,
  onOpenObjectDetails,
}) {
  const [activeIndex, setActiveIndex] = useState(() => {
    if (initialMilestoneId) {
      const foundIdx = COSMIC_MILESTONES.findIndex((m) => m.id === initialMilestoneId);
      if (foundIdx !== -1) return foundIdx;
    }
    return 0; // Default to Big Bang
  });

  const [futureStageIndex, setFutureStageIndex] = useState(0);
  const containerRef = useRef(null);
  const scrubberTrackRef = useRef(null);

  const currentMilestone = useMemo(
    () => getMilestoneByIndex(activeIndex),
    [activeIndex]
  );

  // Sync initialMilestoneId when prop changes
  useEffect(() => {
    if (initialMilestoneId) {
      const idx = COSMIC_MILESTONES.findIndex((m) => m.id === initialMilestoneId);
      if (idx !== -1) {
        setActiveIndex(idx);
      }
    }
  }, [initialMilestoneId]);

  // Deep linking: update URL hash when milestone changes
  useEffect(() => {
    if (!isOpen || !currentMilestone) return;
    try {
      window.location.hash = `timeline=${currentMilestone.id}`;
    } catch {
      // Ignore in restricted iframe
    }
  }, [isOpen, currentMilestone]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveIndex((prev) => Math.min(prev + 1, COSMIC_MILESTONES.length - 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Escape') {
        if (onClose) onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Handle milestone selection
  const handleSelectMilestone = (idx) => {
    setActiveIndex(idx);
    if (COSMIC_MILESTONES[idx].id === 'sun-future') {
      setFutureStageIndex(0);
    }
  };

  // Next / Previous navigation
  const handleNext = () => {
    setActiveIndex((prev) => Math.min(prev + 1, COSMIC_MILESTONES.length - 1));
  };

  const handlePrevious = () => {
    setActiveIndex((prev) => Math.max(prev - 1, 0));
  };

  // Reset to Big Bang
  const handleResetToOrigin = () => {
    setActiveIndex(0);
  };

  // Jump to Present Day
  const handleJumpToPresent = () => {
    const presentIdx = COSMIC_MILESTONES.findIndex((m) => m.era === TIMELINE_ERAS.PRESENT);
    if (presentIdx !== -1) setActiveIndex(presentIdx);
  };

  // Jump to Future
  const handleJumpToFuture = () => {
    const futureIdx = COSMIC_MILESTONES.findIndex((m) => m.era === TIMELINE_ERAS.FUTURE);
    if (futureIdx !== -1) setActiveIndex(futureIdx);
  };

  // Bridge Action Execution
  const handleExecuteBridgeAction = useCallback(() => {
    if (!currentMilestone) return;

    const action = currentMilestone.bridgeAction;
    if (!action) return;

    if (currentMilestone.id === 'present-day' && onEnterPresentUniverse) {
      onEnterPresentUniverse();
    } else if (currentMilestone.id === 'solar-system-formation' && onExploreSolarSystem) {
      onExploreSolarSystem();
    } else if (currentMilestone.id === 'earth-forms' && onExploreEarth) {
      onExploreEarth();
    } else if (currentMilestone.id === 'moon-formation' && onExploreMoon) {
      onExploreMoon();
    } else if (currentMilestone.id === 'first-stars' && onExploreStars) {
      onExploreStars();
    } else if (currentMilestone.id === 'sun-future' && onExploreLifeCycle) {
      onExploreLifeCycle();
    } else if (onEnterPresentUniverse) {
      onEnterPresentUniverse();
    }
  }, [
    currentMilestone,
    onEnterPresentUniverse,
    onExploreSolarSystem,
    onExploreEarth,
    onExploreMoon,
    onExploreStars,
    onExploreLifeCycle,
  ]);

  // Related objects data resolution
  const relatedObjects = useMemo(() => {
    if (!currentMilestone?.relatedObjectIds) return [];
    return currentMilestone.relatedObjectIds
      .map((id) => getCelestialObjectById(id))
      .filter(Boolean);
  }, [currentMilestone]);

  if (!isOpen) return null;

  return (
    <section
      id="timeline"
      ref={containerRef}
      className="relative w-full min-h-[92vh] bg-[#020308] text-white flex flex-col justify-between overflow-hidden border-b border-white/5 select-none"
      aria-label="Interactive Cosmic Timeline"
    >
      {/* Ambient background aura keyed to current era / milestone */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none transition-colors duration-700 opacity-20"
        style={{
          background: `radial-gradient(circle at 50% 30%, ${currentMilestone.accentColor} 0%, rgba(2,3,8,0) 70%)`,
        }}
      />

      {/* ======================================================== */}
      {/* 1. TOP HEADER HUD & COSMIC TIME INDICATOR */}
      {/* ======================================================== */}
      <header className="relative z-20 px-4 sm:px-8 pt-5 pb-3 border-b border-white/8 bg-[#020308]/80 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left: Mode Title & Breadcrumb */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300 font-bold text-sm shadow-[0_0_15px_rgba(6,182,212,0.25)] flex-shrink-0">
            ⏳
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-cyan-400 font-semibold">
                COSMIC TIMELINE
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-mono tracking-widest text-slate-300 bg-white/[0.04] border border-white/10">
                13.8 BYR JOURNEY
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className="text-slate-500">Universe</span>
              <span className="text-slate-600">›</span>
              <span className="text-cyan-300 font-medium">Cosmic History</span>
              <span className="text-slate-600">›</span>
              <span className="text-white truncate max-w-[150px] sm:max-w-none">
                {currentMilestone.title}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Persistent COSMIC TIME Indicator */}
        <div className="flex flex-col items-center justify-center px-4 py-1.5 rounded-2xl bg-[#040817]/90 border border-white/10 shadow-[0_4px_20px_rgba(0,0,0,0.6)]">
          <div className="text-[10px] font-mono uppercase tracking-widest text-slate-400 font-semibold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>COSMIC TIME</span>
          </div>
          <div className="text-sm sm:text-base md:text-lg font-mono font-bold tracking-wider text-cyan-200 transition-all">
            {currentMilestone.timeLabel}
          </div>
        </div>

        {/* Right: Quick Era Jump Controls & Close/Back Button */}
        <div className="flex items-center gap-2">
          {/* Era Filter Badges */}
          <div className="hidden lg:flex items-center gap-1 p-1 rounded-xl bg-white/[0.03] border border-white/8 text-xs font-mono">
            <button
              type="button"
              onClick={handleResetToOrigin}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                currentMilestone.era === TIMELINE_ERAS.PAST
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Past
            </button>
            <button
              type="button"
              onClick={handleJumpToPresent}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                currentMilestone.era === TIMELINE_ERAS.PRESENT
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Present
            </button>
            <button
              type="button"
              onClick={handleJumpToFuture}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                currentMilestone.era === TIMELINE_ERAS.FUTURE
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Future
            </button>
          </div>

          {/* Return to Map CTA */}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Return to Universe Map"
              className="px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>← Universe</span>
            </button>
          )}
        </div>
      </header>

      {/* ======================================================== */}
      {/* 2. MAIN CENTER STAGE: VISUAL SCENE & DETAIL PANEL */}
      {/* ======================================================== */}
      <div className="relative z-10 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-8 p-4 sm:p-6 lg:p-8 items-center max-w-7xl mx-auto w-full overflow-hidden">
        {/* Left Column: Category-Adaptive Visual Simulation */}
        <div className="lg:col-span-6 w-full h-[280px] sm:h-[360px] lg:h-[440px] rounded-3xl bg-[#030612]/90 border border-white/10 shadow-[0_15px_50px_rgba(0,0,0,0.8)] overflow-hidden relative flex items-center justify-center group">
          <TimelineScene
            milestone={currentMilestone}
            futureStageIndex={futureStageIndex}
            onSelectFutureStage={setFutureStageIndex}
          />

          {/* Reticle Overlay Labels */}
          <div className="absolute top-4 left-4 z-20 pointer-events-none">
            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-wider border font-bold ${currentMilestone.badgeColor}`}>
              {currentMilestone.eraLabel}
            </span>
          </div>

          <div className="absolute top-4 right-4 z-20 pointer-events-none text-[11px] font-mono text-slate-400 bg-[#020308]/70 px-2 py-0.5 rounded border border-white/5">
            {currentMilestone.number} / 10
          </div>
        </div>

        {/* Right Column: Narrative Detail Panel */}
        <div className="lg:col-span-6 flex flex-col justify-center space-y-4 text-left">
          {/* Header */}
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-cyan-400 font-semibold tracking-widest">
                MILESTONE {currentMilestone.number}
              </span>
              <span className="text-slate-600">//</span>
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                {currentMilestone.era} ERA
              </span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white mb-1">
              {currentMilestone.title}
            </h2>
            <p className="text-xs sm:text-sm font-mono text-amber-300/90 tracking-wide font-medium">
              {currentMilestone.subtitle}
            </p>
          </div>

          {/* Description */}
          <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/8 space-y-3">
            <div>
              <h4 className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold mb-1">
                WHAT HAPPENED
              </h4>
              <p className="text-xs sm:text-sm font-sans text-slate-200 leading-relaxed">
                {currentMilestone.whatHappened}
              </p>
            </div>

            <div className="pt-2 border-t border-white/5">
              <h4 className="text-[11px] font-mono uppercase tracking-wider text-cyan-400 font-semibold mb-1">
                WHY IT MATTERS
              </h4>
              <p className="text-xs sm:text-sm font-sans text-slate-300 leading-relaxed">
                {currentMilestone.whyItMatters}
              </p>
            </div>
          </div>

          {/* Cosmic Fact Card */}
          <div className="p-3.5 rounded-xl bg-amber-500/[0.04] border border-amber-500/20 flex items-start gap-2.5">
            <span className="text-amber-400 text-sm mt-0.5">✦</span>
            <div className="text-xs font-sans text-amber-200/90 leading-relaxed">
              <span className="font-mono uppercase tracking-wider font-semibold text-amber-300 block text-[10px] mb-0.5">
                COSMIC FACT
              </span>
              {currentMilestone.cosmicFact}
            </div>
          </div>

          {/* Related Objects Network */}
          {relatedObjects.length > 0 && (
            <div className="pt-1">
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-2 font-semibold">
                🔗 RELATED CELESTIAL TARGETS
              </div>
              <div className="flex flex-wrap gap-2">
                {relatedObjects.map((obj) => {
                  const symbol = CATEGORY_SYMBOLS[obj.category] || '●';
                  return (
                    <button
                      key={obj.id}
                      type="button"
                      onClick={() => onOpenObjectDetails && onOpenObjectDetails(obj)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/[0.03] hover:bg-cyan-950/40 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-300 hover:text-cyan-200 transition-all cursor-pointer group shadow-sm"
                      title={`Inspect ${obj.name} in Universal Object Details`}
                    >
                      <span style={{ color: obj.colorHex || '#38bdf8' }}>{symbol}</span>
                      <span className="font-semibold text-white group-hover:text-cyan-200">
                        {obj.name}
                      </span>
                      <span className="text-[10px] text-slate-500 group-hover:text-cyan-400">
                        ({CATEGORY_LABELS[obj.category] || obj.category})
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Primary Action Bridge & Next Button */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            {/* Primary Bridge Action */}
            <button
              type="button"
              onClick={handleExecuteBridgeAction}
              className="flex-1 py-2.5 px-4 rounded-xl font-sans font-semibold text-xs tracking-wider uppercase text-cyan-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 hover:from-cyan-300 hover:to-sky-200 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(6,182,212,0.25)] flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>{currentMilestone.bridgeAction.label}</span>
              <span className="text-cyan-950 group-hover:translate-x-1 transition-transform">→</span>
            </button>

            {/* Step to Next Milestone */}
            {activeIndex < COSMIC_MILESTONES.length - 1 && (
              <button
                type="button"
                onClick={handleNext}
                className="py-2.5 px-4 rounded-xl font-mono text-xs text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/10 border border-white/10 hover:border-white/20 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>Next Milestone</span>
                <span>→</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 3. BOTTOM TIMELINE SCRUBBER & MINI-MAP */}
      {/* ======================================================== */}
      <footer className="relative z-20 px-4 sm:px-8 py-4 border-t border-white/8 bg-[#020308]/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto">
          {/* Scrubber Controls Row */}
          <div className="flex items-center justify-between gap-4 mb-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevious}
                disabled={activeIndex === 0}
                aria-label="Previous milestone"
                className={`p-2 rounded-xl border text-xs font-mono transition-all ${
                  activeIndex === 0
                    ? 'border-white/5 text-slate-600 cursor-not-allowed opacity-40'
                    : 'border-white/10 text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer active:scale-95'
                }`}
              >
                ← Prev
              </button>

              <button
                type="button"
                onClick={handleNext}
                disabled={activeIndex === COSMIC_MILESTONES.length - 1}
                aria-label="Next milestone"
                className={`p-2 rounded-xl border text-xs font-mono transition-all ${
                  activeIndex === COSMIC_MILESTONES.length - 1
                    ? 'border-white/5 text-slate-600 cursor-not-allowed opacity-40'
                    : 'border-white/10 text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer active:scale-95'
                }`}
              >
                Next →
              </button>

              <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-slate-400 pl-2">
                <span>STAGE</span>
                <span className="text-cyan-300 font-semibold">{currentMilestone.number}</span>
                <span className="text-slate-600">/</span>
                <span>10</span>
              </div>
            </div>

            {/* Quick Jumps */}
            <div className="flex items-center gap-1.5 text-xs font-mono">
              <button
                type="button"
                onClick={handleResetToOrigin}
                title="Jump to Big Bang"
                className="px-2.5 py-1 rounded-lg bg-white/[0.02] hover:bg-white/[0.06] border border-white/8 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ⟳ Origin
              </button>
              <button
                type="button"
                onClick={handleJumpToPresent}
                title="Jump to Present Day"
                className="px-2.5 py-1 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 text-cyan-200 hover:text-white transition-colors cursor-pointer"
              >
                ⚡ Present Day
              </button>
              <button
                type="button"
                onClick={handleJumpToFuture}
                title="Jump to Sun's Destiny"
                className="px-2.5 py-1 rounded-lg bg-purple-950/40 hover:bg-purple-900/60 border border-purple-500/30 text-purple-200 hover:text-white transition-colors cursor-pointer"
              >
                ✦ Future
              </button>
            </div>
          </div>

          {/* Interactive Horizontal Track (Desktop & Tablet) */}
          <div
            ref={scrubberTrackRef}
            className="relative py-3 overflow-x-auto no-scrollbar"
          >
            {/* Horizontal Line Guide */}
            <div className="relative h-1 bg-white/10 rounded-full my-4 flex items-center justify-between">
              {/* Active progress fill */}
              <div
                style={{
                  width: `${(activeIndex / (COSMIC_MILESTONES.length - 1)) * 100}%`,
                }}
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-rose-500 via-cyan-400 to-purple-500 rounded-full transition-all duration-300"
              />

              {/* Milestone Nodes */}
              {COSMIC_MILESTONES.map((m, idx) => {
                const isActive = activeIndex === idx;
                const isPassed = activeIndex >= idx;

                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => handleSelectMilestone(idx)}
                    className="relative z-10 flex flex-col items-center group cursor-pointer focus:outline-none"
                    aria-label={`Milestone ${m.number}: ${m.title}`}
                  >
                    {/* Glowing Circular Node */}
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200 ${
                        isActive
                          ? 'scale-125 bg-white text-slate-950 font-bold text-[10px] shadow-[0_0_15px_rgba(255,255,255,0.9)] ring-4 ring-cyan-400/40'
                          : isPassed
                          ? 'bg-cyan-400 text-slate-950 font-bold text-[9px]'
                          : 'bg-[#040816] border border-white/20 text-slate-500 group-hover:border-cyan-400/60 group-hover:text-slate-300 text-[9px]'
                      }`}
                    >
                      {m.number}
                    </div>

                    {/* Node Label Below */}
                    <div className="absolute top-8 flex flex-col items-center pointer-events-none whitespace-nowrap">
                      <span
                        className={`text-[11px] font-mono font-medium transition-colors ${
                          isActive
                            ? 'text-cyan-300 font-bold'
                            : 'text-slate-500 group-hover:text-slate-300'
                        }`}
                      >
                        {m.title}
                      </span>
                      <span className="text-[9px] font-mono text-slate-600 hidden md:block">
                        {m.shortTime}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Educational Spacing Disclaimer */}
          <div className="pt-6 sm:pt-7 text-center">
            <p className="text-[10px] font-mono text-slate-500">
              Timeline spacing is optimized for exploration and is not a linear representation of elapsed time. Dates are approximate based on current cosmological models.
            </p>
          </div>
        </div>
      </footer>
    </section>
  );
}
