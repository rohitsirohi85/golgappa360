import { artists } from "../data/artists.js";
import { songs } from "../data/songs.js";
import { albums } from "../data/albums.js";

export const artistService = {
  async getAllArtists() {
    return [...artists];
  },

  async getArtistById(id) {
    const artist = artists.find((a) => a.id === id);
    if (!artist) return null;

    const artistSongs = songs.filter((s) => s.artistId === id);
    const artistAlbums = albums.filter((alb) => alb.artistId === id);

    // Multi-factor Similar Artists determination
    const scoredArtists = artists
      .filter((a) => a.id !== id)
      .map((other) => {
        let score = 0;

        // Shared genres (+40 per shared genre)
        const sharedGenres = other.genres?.filter((g) => artist.genres?.includes(g)) || [];
        score += sharedGenres.length * 40;

        // Shared languages (+30 per shared language)
        const sharedLangs = other.languages?.filter((l) => artist.languages?.includes(l)) || [];
        score += sharedLangs.length * 30;

        // Similar monthly listener tier (+20 if within 50% range)
        const listenerRatio = Math.min(other.monthlyListeners, artist.monthlyListeners) /
          Math.max(other.monthlyListeners, artist.monthlyListeners);
        score += Math.round(listenerRatio * 20);

        return { artist: other, score };
      });

    scoredArtists.sort((a, b) => b.score - a.score);

    const similarArtists = scoredArtists.slice(0, 5).map((item) => item.artist);

    return {
      ...artist,
      songCount: artistSongs.length || artist.songCount || 0,
      albumCount: artistAlbums.length || artist.albumCount || 0,
      songs: artistSongs,
      albums: artistAlbums,
      similarArtists: similarArtists.length ? similarArtists : artists.filter((a) => a.id !== id).slice(0, 4)
    };
  }
};
