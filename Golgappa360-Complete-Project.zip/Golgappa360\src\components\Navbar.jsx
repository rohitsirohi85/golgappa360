import React, { useState, useEffect } from 'react';
import Button from './Button';
import UniversalSearch from './search/UniversalSearch';

/**
 * Navbar — Floating glassmorphic navigation bar
 * Left: ✦ STELLAR
 * Center: Home, Universe Map, Stars, Star Types, Life Cycle, Constellations, Quiz
 * Right: Universal Search ("Search the universe..." + hotkey /) & “Explore →”
 * Features: Scroll detection, glass blur, active state, mobile search & drawer
 */
export default function Navbar({ activeSection = 'home', onNavClick }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const navItems = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'Universe Map', href: '#universe-map', id: 'universe-map' },
    { label: 'Timeline', href: '#timeline', id: 'timeline' },
    { label: 'Stars', href: '#stars', id: 'stars' },
    { label: 'Star Types', href: '#star-types', id: 'star-types' },
    { label: 'Life Cycle', href: '#life-cycle', id: 'life-cycle' },
    { label: 'Constellations', href: '#constellations', id: 'constellations' },
    { label: 'Quiz', href: '#quiz', id: 'quiz' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 25);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent background scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  const handleLinkClick = (e, item) => {
    setMobileMenuOpen(false);
    if (onNavClick) {
      onNavClick(item);
    }
    // Smooth scroll if target exists
    const target = document.querySelector(item.href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ease-in-out ${
          isScrolled
            ? 'py-2.5 sm:py-3 bg-[#020308]/90 backdrop-blur-xl border-b border-white/8 shadow-[0_10px_30px_rgba(0,0,0,0.85)]'
            : 'py-4 sm:py-6 bg-transparent border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-3">
            {/* Left Brand: ✦ STELLAR */}
            <a
              href="#home"
              className="group flex items-center gap-2.5 focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400 rounded-lg py-1 px-1.5 transition-transform duration-200 hover:scale-[1.01] flex-shrink-0"
              aria-label="STELLAR Homepage"
            >
              {/* Celestial Star Glyph */}
              <span className="relative flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/[0.03] border border-white/10 group-hover:border-cyan-400/40 transition-all duration-300">
                <span className="text-amber-300 text-sm font-bold">
                  ✦
                </span>
              </span>

              <div className="flex flex-col">
                <span className="font-display font-semibold text-base sm:text-lg tracking-[0.2em] text-white group-hover:text-cyan-200 transition-colors duration-200">
                  STELLAR
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav
              className="hidden xl:flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/[0.02] border border-white/8 backdrop-blur-md"
              aria-label="Main Navigation"
            >
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={(e) => handleLinkClick(e, item)}
                    className={`relative px-3 py-1.5 text-xs font-sans font-medium tracking-wide transition-colors duration-200 select-none ${
                      isActive
                        ? 'text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {item.label}
                    {/* Subtle active indicator line */}
                    {isActive && (
                      <span
                        aria-hidden="true"
                        className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-4 h-[2px] rounded-full bg-cyan-400/90 shadow-[0_0_8px_rgba(34,211,238,0.5)]"
                      />
                    )}
                  </a>
                );
              })}
            </nav>

            {/* Right Action: Universal Search & Explore */}
            <div className="hidden md:flex items-center gap-2.5 lg:gap-3 flex-shrink-0">
              {/* Desktop Universal Search Pill */}
              <UniversalSearch
                variant="navbar"
                placeholder="Search the universe..."
              />

              <Button
                href="#stars"
                variant="primary"
                size="sm"
                className="hidden sm:inline-flex text-xs px-3.5 py-1.5"
              >
                Explore →
              </Button>
            </div>

            {/* Mobile Actions: Compact Search Icon + Menu Hamburger */}
            <div className="flex items-center gap-2 md:hidden">
              {/* Compact Mobile Search Button */}
              <button
                type="button"
                onClick={() => setMobileSearchOpen(true)}
                className="p-2 rounded-xl bg-white/[0.04] border border-white/15 text-slate-300 hover:text-white hover:border-cyan-400/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 transition-colors"
                aria-label="Search celestial objects"
              >
                <svg className="w-5 h-5 text-cyan-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>

              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-xl bg-white/[0.04] border border-white/15 text-slate-300 hover:text-white hover:border-cyan-400/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 transition-colors"
                aria-expanded={mobileMenuOpen}
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer Overlay */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 top-[60px] bg-[#020308]/95 backdrop-blur-2xl z-40 px-6 py-6 flex flex-col justify-between border-t border-white/8 animate-in fade-in slide-in-from-top-4 duration-300 overflow-y-auto">
            <div className="flex flex-col gap-2">
              {/* Quick Search Button in drawer */}
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setMobileSearchOpen(true);
                }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-white/[0.05] border border-cyan-500/30 text-slate-200 hover:text-white hover:border-cyan-400 text-sm font-sans mb-3 shadow-[0_0_15px_rgba(56,189,248,0.15)]"
              >
                <span className="flex items-center gap-2.5">
                  <svg className="w-4 h-4 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <span>Search the universe...</span>
                </span>
                <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-mono text-cyan-300">/</kbd>
              </button>

              <div className="text-[11px] font-mono uppercase tracking-[0.25em] text-cyan-400/80 mb-1 px-3">
                Navigation Index
              </div>
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={(e) => handleLinkClick(e, item)}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm tracking-wide transition-all ${
                      isActive
                        ? 'bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 font-semibold shadow-[0_0_15px_rgba(56,189,248,0.25)]'
                        : 'text-slate-200 hover:bg-white/5 hover:text-white border border-transparent'
                    }`}
                  >
                    <span>{item.label}</span>
                    <span className="text-slate-500 font-mono text-xs">→</span>
                  </a>
                );
              })}
            </div>

            <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
                <span>STATUS: ONLINE</span>
                <span>EPOCH: J2026.5</span>
              </div>
              <Button
                href="#stars"
                variant="primary"
                size="md"
                className="w-full justify-center text-xs"
                onClick={() => setMobileMenuOpen(false)}
              >
                Explore Stars →
              </Button>
            </div>
          </div>
        )}
      </header>

      {/* Standalone Mobile Search Modal */}
      <UniversalSearch
        variant="modal"
        isOpen={mobileSearchOpen}
        onClose={() => setMobileSearchOpen(false)}
        placeholder="Search the universe..."
      />
    </>
  );
}
