# Golgappa360 — MCA Capstone Project Presentation Outline

> **12-Slide Master Defense Structure**  
> **Project Title:** Golgappa360 — Golgappa Business Intelligence & Sales Analytics System  
> **Candidate:** MCA Final Year Candidate  
> **Academic Session:** 2026

---

### Slide 1: Title & Candidacy
- **Title:** Golgappa360 — Golgappa Business Intelligence & Sales Analytics System
- **Subtitle:** An Enterprise-Grade Multi-Tiered Analytics & Waste Mitigation Platform for Indian Street-Food Vendors
- **Candidate Name & Roll Number:** [Student Name / Roll Number Placeholder]
- **Department:** Master of Computer Applications (MCA)
- **Institution:** [University / Institute Name Placeholder]
- **Academic Advisor:** [Faculty Guide Name Placeholder]
- **Key Badges:** React 19 • Node/Express • MySQL 8.0 • Tableau BI • RFC 4180 Certified

---

### Slide 2: Introduction
- **Domain:** Small-Scale Food Enterprise & Unorganized Street-Food Retailing.
- **Context:** The Indian street-food sector, valued at over $40 billion, accounts for millions of micro-transactions daily. Golgappa (pani puri) stalls are among the highest-velocity food counters in urban centers.
- **Motivation:** Despite substantial turnover, stall operations face severe margin erosion due to manual cash tracking, lack of portion Bill of Materials (BOM) costing, and unmonitored ingredient spoilage.

---

### Slide 3: Problem Statement
- **Operational Blind Spots:** Stall owners rely entirely on manual intuition to decide prep quantities, risking stockouts during peak rushes or food waste on slow days.
- **Untracked Recipe Costs:** Lack of visibility into ingredient price inflation (potatoes, mint, suji, cooking gas) eroding unit contribution margins.
- **Food Spoilage & Breakage:** Up to $8\%$ of raw materials are discarded due to transit breakage (puris) or afternoon oxidation (mint pani).
- **Payment Reconciliation Friction:** Growing shift toward UPI QR payments creates cash flow reconciliation challenges with wholesale mandi suppliers.

---

### Slide 4: Project Objectives
1. **Design a Dual-Engine Analytics Platform:** Provide 100% uptime through a primary MySQL 8.0 relational database and a resilient synthetic analytics store.
2. **Develop Interactive Glassmorphism Dashboards:** Render 7 operational modules in React 19 with real-time KPI filtering and Recharts visualizations.
3. **Establish Unified Accounting Standards:** Enforce strict formulas across SQL, REST APIs, Excel, and Tableau ($₹0.00$ variance).
4. **Implement Food Waste & Spoilage Tracking:** Identify root causes of ingredient loss and generate data-driven prep recommendations.
5. **Deliver Production BI Exports:** Produce certified RFC 4180 CSV exports for Tableau Desktop and Microsoft Excel analysis.

---

### Slide 5: Technology Stack & Dual-Engine Architecture
- **Frontend Tier:** React 19, Vite v8.3, Tailwind CSS v4, Recharts, Lucide React.
  - *Styling Identity:* Premium Dark Glassmorphism (`#171717` canvas, translucent cards, sage green `#A7D78A`, saffron `#EAB64B`).
- **Application & API Tier:** Node.js v24, Express 4.21, `mysql2/promise` connection pooling, custom validation middleware.
- **Persistence Tier (Dual-Engine):**
  - *Primary Engine:* MySQL 8.0 relational database (3NF, foreign keys, 4 views).
  - *Fallback Engine:* In-memory synthetic analytics engine loaded from reproducible CSVs.
- **Business Intelligence Tier:** Tableau Desktop / Public (Logical Relationships) & Microsoft Excel (Power Query, Pivot Tables).

---

### Slide 6: Dataset & Master Data Dictionary
- **Operational Scope:** 6 Months of continuous operations (2026-05-01 to 2026-10-29; 182 days).
- **Core Entities:**
  - `sales.csv`: 31,938 customer order transactions.
  - `products.csv`: 5 golgappa varieties with portion Bill of Materials (BOM) recipes.
  - `ingredients.csv`: 8 raw materials (puris, aloo, vatana, mint, coriander, curd, spices).
  - `inventory_transactions.csv`: 2,391 stock movements (purchases, consumption, waste).
  - `daily_expenses.csv`: 845 stall operating overhead vouchers.
- **Data Governance:** Standardized RFC 4180 encoding, ISO timestamps, and zero duplicate keys.

---

### Slide 7: Microsoft Excel Analysis Workflow
- **Power Query Ingestion:** Direct UTF-8 ingestion from `tableau_sales.csv` preserving ISO dates.
- **Pivot Tables Demonstrated:**
  - Variety revenue & contribution margin matrix.
  - Hourly footfall heatmap matrix (`day_of_week` vs `sale_hour`).
  - UPI vs. Cash tender adoption over time.
- **Verification Formulas:**
  - `=SUMIFS(tableau_sales[net_revenue], tableau_sales[product_name], "Classic Golgappa")`
  - `=XLOOKUP(A2, tableau_products[product_name], tableau_products[ingredient_cost_per_plate])`
- **Audit Parity:** Excel totals match SQL and Tableau benchmarks ($₹1,759,965.00$).

---

### Slide 8: MySQL Database Schema & Analytical Queries
- **Relational Normalization:** 3NF schema with foreign key cascades and check constraints across 6 tables.
- **Analytical Views:**
  - `vw_dashboard_kpis`: High-level turnover and margins.
  - `vw_product_performance`: Variety contribution ranking.
  - `vw_daily_financial_summary`: Daily Net Revenue, COGS, Waste, and Operating Profit.
  - `vw_inventory_status`: Real-time stock runway and alert classification.
- **Master SQL Query Library:** 30 production queries covering CTEs, window functions (`AVG() OVER` 7-day rolling MA), and subqueries.

---

### Slide 9: Tableau Dashboard Design & Semantic Model
- **Logical Relationships (The "Noodle"):** Connects `tableau_sales` to `tableau_products` on `[product_id]` without flat joins, preventing the 76-million row Cartesian explosion fan trap.
- **Four Dashboards Built:**
  1. *Dashboard 1 — Business Overview:* 5 executive KPI cards, daily revenue area chart with 7-day MA, weekday bar chart, and UPI/Cash donut.
  2. *Dashboard 2 — Sales Analytics:* 8-hour heatmap matrix, quantity vs. revenue scatter plot, and dynamic granularity parameter.
  3. *Dashboard 3 — Inventory & Waste:* Stock runway bullet chart, threshold status, and food waste cost breakdown.
  4. *Dashboard 4 — Expenses & Profitability:* Bottom-line stall viability waterfall, monthly P&L, and variety margin comparison.

---

### Slide 10: Key Quantitative Findings
- **Financial Performance:**
  - Net Revenue: **₹1,759,965.00** across 31,938 orders and 47,658 plates sold.
  - Gross Profit: **₹1,267,007.10** (**71.99% margin**).
  - Operating Overheads: ₹126,540.06 (Rent, gas, ice, dona packaging, sanitation).
  - Estimated Operating Profit: **₹1,140,467.04** (**64.80% margin**).
- **Operational Discoveries:**
  - *Evening Commuter Rush:* 58.4% of daily volume occurs between 5:30 PM and 8:30 PM.
  - *Digital Shift:* UPI accounts for 64.6% of orders and 65.5% of turnover.
  - *Food Waste Profile:* Total waste loss was ₹11,626.98 (0.66% of turnover), with puri transit breakage (42.0%) and souring mint water (35.3%) as primary drivers.

---

### Slide 11: Limitations & Future Scope
- **Current Limitations:**
  - Single stall operational scope (Sharma Ji Golgappa Center).
  - Calibrated synthetic dataset used for academic verification.
  - Manual restock entries rather than IoT digital scale automation.
- **Future Roadmap:**
  - Multi-stall franchise centralized monitoring.
  - Automated WhatsApp purchase order dispatch to mandi suppliers when stock hits reorder levels.
  - Machine learning weather-based footfall prediction to adjust prep batches dynamically.

---

### Slide 12: Conclusion & Summary
- **Accomplishments:** Delivered a production-ready, fully responsive business intelligence platform combining modern web development, relational database normalization, and Tableau analytics.
- **Verification:** 100% test pass rate across 70 unit, integration, and reconciliation tests ($₹0.00$ variance).
- **Academic Value:** Demonstrates full-stack software engineering, relational database design, financial accounting, and business intelligence reporting.
- **Q&A Session:** Ready for Viva Voce examination.
