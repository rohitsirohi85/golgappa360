import React, { useState } from 'react';
import { getZoomLevelInfo } from '../../utils/mapScale.js';
import { CATEGORY_SYMBOLS } from '../../data/celestialObjects.js';

/**
 * MapLegend — Minimal Observatory HUD Telemetry & Object Types Legend
 */
export default function MapLegend({
  zoom = 1.0,
  totalObjects = 46,
  className = '',
}) {
  const [showLegendDetails, setShowLegendDetails] = useState(false);
  const zoomInfo = getZoomLevelInfo(zoom);

  const objectTypes = [
    { symbol: CATEGORY_SYMBOLS.STAR, label: 'Star', color: '#f1f5f9' },
    { symbol: CATEGORY_SYMBOLS.CONSTELLATION || '✨', label: 'Constellation', color: '#38bdf8' },
    { symbol: '—', label: 'Pattern Line', color: '#38bdf8' },
    { symbol: CATEGORY_SYMBOLS.WHITE_DWARF, label: 'White Dwarf', color: '#e0f2fe' },
    { symbol: CATEGORY_SYMBOLS.NEUTRON_STAR, label: 'Neutron Star', color: '#c084fc' },
    { symbol: CATEGORY_SYMBOLS.PULSAR, label: 'Pulsar', color: '#22d3ee' },
    { symbol: CATEGORY_SYMBOLS.BLACK_HOLE, label: 'Black Hole', color: '#f59e0b' },
    { symbol: CATEGORY_SYMBOLS.NEBULA, label: 'Nebula', color: '#38bdf8' },
    { symbol: CATEGORY_SYMBOLS.STAR_CLUSTER, label: 'Star Cluster', color: '#60a5fa' },
    { symbol: CATEGORY_SYMBOLS.GALAXY, label: 'Galaxy', color: '#c7d2fe' },
  ];

  return (
    <div className={`flex flex-col gap-2 select-none text-[11px] font-mono text-slate-400 ${className}`}>
      {/* Telemetry HUD Badge */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3 bg-[#020308]/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 shadow-[0_4px_20px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_6px_#22d3ee]" />
          <span className="text-slate-300 font-semibold tracking-wider">
            {zoomInfo.name}
          </span>
          <span className="text-cyan-400 font-medium">
            ({zoom.toFixed(1)}x)
          </span>
        </div>

        <span className="text-slate-600 hidden sm:inline">|</span>

        <div className="hidden sm:flex items-center gap-1.5 text-slate-300">
          <span>{totalObjects} OBJECTS</span>
        </div>

        <span className="text-slate-600 hidden md:inline">|</span>

        {/* Scientific Disclaimer Badge */}
        <span className="hidden md:inline text-[10px] text-slate-400/90 font-mono tracking-tight">
          Illustrative educational visualization — not to scale
        </span>

        {/* Legend Toggle Button */}
        <button
          type="button"
          onClick={() => setShowLegendDetails((prev) => !prev)}
          className="ml-auto text-[10px] text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1 focus:outline-none"
          aria-expanded={showLegendDetails}
        >
          <span>Object Types</span>
          <span className="text-[9px]">{showLegendDetails ? '▲' : '▼'}</span>
        </button>
      </div>

      {/* Expanded Object Types Legend Drawer */}
      {showLegendDetails && (
        <div className="bg-[#020308]/95 backdrop-blur-md px-3.5 py-2.5 rounded-lg border border-white/10 shadow-[0_8px_25px_rgba(0,0,0,0.8)] animate-in fade-in duration-150">
          <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-2 font-semibold flex items-center justify-between">
            <span>Astronomical Object Types</span>
            <span className="text-[9px] text-cyan-400">Map Visual Signatures</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
            {objectTypes.map((item) => (
              <div key={item.label} className="flex items-center gap-1.5">
                <span
                  className="font-bold text-xs"
                  style={{ color: item.color }}
                >
                  {item.symbol}
                </span>
                <span className="text-slate-200">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
