import * as syntheticStore from '../data/syntheticStore.js';

export async function getDatasetSummary(req, res, next) {
  try {
    const raw = syntheticStore.getRawDatasets();

    const datasets = [
      {
        id: 'sales',
        name: 'Sales Transactions (sales.csv)',
        filename: 'sales.csv',
        records: raw.sales.length,
        columns: 7,
        description: 'Individual customer order transactions: sale ID, timestamps, products, plate quantities, unit prices, discounts, and payment methods.',
        tableauReady: true,
        primaryKey: 'sale_id',
        fields: ['sale_id', 'sale_datetime', 'product_id', 'quantity_plates', 'unit_price', 'discount', 'payment_method']
      },
      {
        id: 'products',
        name: 'Menu Products Master (products.csv)',
        filename: 'products.csv',
        records: raw.products.length,
        columns: 5,
        description: 'Menu varieties catalog: product IDs, names, category classifications, selling prices, and standard BOM costs per plate.',
        tableauReady: true,
        primaryKey: 'product_id',
        fields: ['product_id', 'product_name', 'category', 'selling_price', 'ingredient_cost_per_plate']
      },
      {
        id: 'ingredients',
        name: 'Raw Ingredients Master (ingredients.csv)',
        filename: 'ingredients.csv',
        records: raw.ingredients.length,
        columns: 5,
        description: 'Raw ingredients: puris, potatoes, chickpeas, mint, coriander, spices, chutney, and curd with wholesale unit costs and reorder thresholds.',
        tableauReady: true,
        primaryKey: 'ingredient_id',
        fields: ['ingredient_id', 'ingredient_name', 'unit', 'unit_cost', 'reorder_level']
      },
      {
        id: 'inventory_transactions',
        name: 'Inventory Movement Ledger (inventory_transactions.csv)',
        filename: 'inventory_transactions.csv',
        records: raw.inventoryTransactions.length,
        columns: 6,
        description: 'Every physical stock movement: PURCHASES, daily CONSUMPTION, and food WASTAGE with audit reference IDs.',
        tableauReady: true,
        primaryKey: 'transaction_id',
        fields: ['transaction_id', 'transaction_date', 'ingredient_id', 'transaction_type', 'quantity', 'reference_id']
      },
      {
        id: 'daily_expenses',
        name: 'Operating Expenses Ledger (daily_expenses.csv)',
        filename: 'daily_expenses.csv',
        records: raw.dailyExpenses.length,
        columns: 4,
        description: 'Stall operating expenses: rent, packaging dona, utilities/ice, LPG gas, transport freight, and sanitation.',
        tableauReady: true,
        primaryKey: 'expense_id',
        fields: ['expense_id', 'expense_date', 'expense_category', 'amount']
      },
      {
        id: 'daily_sales_summary',
        name: 'Daily Business Summary (daily_sales_summary.csv)',
        filename: 'golgappa360_daily_sales_summary.csv',
        records: 182,
        columns: 10,
        description: '182-day aggregated performance: Net Revenue, COGS, Gross Profit, Expenses, and Operating Profit.',
        tableauReady: true,
        primaryKey: 'fullDate',
        fields: ['fullDate', 'dayOfWeek', 'revenue', 'cogs', 'grossProfit', 'wasteCost', 'expenses', 'operatingProfit', 'plates', 'orders']
      }
    ];

    res.json({
      success: true,
      data: {
        datasets,
        database: {
          name: 'golgappa360',
          schema: '3NF Normalized Schema',
          tablesCount: 6,
          viewsCount: 4
        }
      }
    });
  } catch (err) {
    next(err);
  }
}
