import React from 'react';

export const LoadingSkeleton = ({ type = 'card', count = 1 }) => {
  const items = Array.from({ length: count });

  if (type === 'stat-grid') {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-32 rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-3 shadow-xs">
            <div className="h-3 w-24 bg-[#E4EAE5] rounded"></div>
            <div className="h-8 w-32 bg-[#E4EAE5]/80 rounded"></div>
            <div className="h-3 w-40 bg-[#E4EAE5]/50 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  if (type === 'chart') {
    return (
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-6 space-y-4 animate-pulse shadow-xs">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <div className="h-4 w-40 bg-[#E4EAE5] rounded"></div>
            <div className="h-3 w-56 bg-[#E4EAE5]/60 rounded"></div>
          </div>
          <div className="h-8 w-24 bg-[#E4EAE5]/80 rounded"></div>
        </div>
        <div className="h-64 rounded-lg bg-[#F8FAF8] border border-[#EEF2EF] flex items-center justify-center">
          <div className="text-xs text-[#77847C] font-mono">Loading telemetry stream...</div>
        </div>
      </div>
    );
  }

  if (type === 'table') {
    return (
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-6 space-y-4 animate-pulse shadow-xs">
        <div className="h-5 w-48 bg-[#E4EAE5] rounded"></div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((row) => (
            <div key={row} className="h-12 bg-[#F8FAF8] border border-[#EEF2EF] rounded-lg flex items-center px-4 justify-between">
              <div className="h-3 w-20 bg-[#E4EAE5] rounded"></div>
              <div className="h-3 w-32 bg-[#E4EAE5] rounded"></div>
              <div className="h-3 w-16 bg-[#E4EAE5] rounded"></div>
              <div className="h-3 w-24 bg-[#E4EAE5] rounded"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-pulse">
      {items.map((_, i) => (
        <div key={i} className="h-24 bg-white border border-[#E4EAE5] rounded-xl p-4 space-y-2 shadow-xs">
          <div className="h-4 w-1/3 bg-[#E4EAE5] rounded"></div>
          <div className="h-3 w-1/2 bg-[#E4EAE5]/60 rounded"></div>
        </div>
      ))}
    </div>
  );
};
