# EV SMART: Data Flow Diagrams (DFD)
## Level 0 Context Diagram & Decomposed Level 1 Data Flow Specifications

---

## 1. DFD Level 0: Context Diagram

The Level 0 Context Diagram establishes the global boundary of the **EV SMART** system, detailing the external entities and high-level data streams entering and exiting the core platform.

```mermaid
graph TD
    User["EV Driver"]
    Admin["Fleet Operator / Admin"]
    ESP32["IoT Charging Station (ESP32)"]
    Grid["Utility Grid / Smart Meter"]
    
    System(("0.0<br/>EV SMART<br/>Core Platform"))
    
    %% Driver Flows
    User -->|Registration, Login, Slot Reservation, Start/Stop Cmd| System
    System -->|Available Stations, Booking Conf, Live Telemetry HUD, Invoices| User
    
    %% Admin Flows
    Admin -->|Station/Charger CRUD, Tariff Rules, Remote Override Cmds| System
    System -->|Fleet Status Grid, Energy/Revenue Analytics, Fault Alerts, Audit Logs| Admin
    
    %% IoT Station Flows
    ESP32 -->|Raw Electrical & Thermal Telemetry V, I, P, E, T, PF| System
    System -->|Relay Actuation Cmds, Reboot Cmds, Firmware Sync| ESP32
    
    %% Grid / External Flows
    Grid -->|Grid Load Signals & Base Tariff Schedules| System
    System -->|Demand Shaving Reports & Forecasted Load Curves| Grid
```

---

## 2. DFD Level 1: Decomposed Process Diagram

The Level 1 DFD decomposes the system into 6 core sub-processes, identifying interactions between processes and persistent data stores.

```mermaid
graph TD
    %% External Entities
    User["EV Driver"]
    Admin["Fleet Admin"]
    ESP32["ESP32 IoT Station"]

    %% Processes
    P1(("1.0<br/>Auth & Identity<br/>Management"))
    P2(("2.0<br/>Station & Booking<br/>Management"))
    P3(("3.0<br/>Telemetry Ingestion<br/>& Edge Safety"))
    P4(("4.0<br/>Live Session &<br/>Relay Control"))
    P5(("5.0<br/>AI Optimization &<br/>Anomaly Detection"))
    P6(("6.0<br/>Billing, Wallet &<br/>Analytics"))

    %% Data Stores
    D1[("D1: Users & RBAC")]
    D2[("D2: Stations & Chargers")]
    D3[("D3: Slot Reservations")]
    D4[("D4: Telemetry Timeseries")]
    D5[("D5: Charging Sessions")]
    D6[("D6: Financial Ledger & Invoices")]
    D7[("D7: Immutable Audit Logs")]

    %% Process 1: Auth
    User -->|Credentials| P1
    Admin -->|Admin Credentials| P1
    P1 <-->|Read / Write User Creds| D1
    P1 -->|JWT Claims| User
    P1 -->|Admin Token| Admin
    P1 -->|Auth Audit Events| D7

    %% Process 2: Stations & Bookings
    Admin -->|Station Setup / Tariffs| P2
    P2 <-->|CRUD Stations/Chargers| D2
    User -->|Slot Booking Request| P2
    P2 <-->|Check Overlap & Reserve| D3
    P2 -->|Booking Confirmation| User

    %% Process 3: Telemetry Ingestion
    ESP32 -->|1Hz Sensor Packets V,I,P,T| P3
    P3 -->|Store Raw Metrics| D4
    P3 -->|Telemetry Event Stream| P4
    P3 -->|Vector Extraction| P5

    %% Process 4: Live Session & Relay
    User -->|QR Scan Start / Stop| P4
    Admin -->|Emergency Disconnect| P4
    P4 <-->|Update Charger State| D2
    P4 <-->|Active Session Record| D5
    P4 -->|Relay Actuation Cmd| ESP32
    P4 -->|WebSocket Telemetry Broadcast| User
    P4 -->|Fleet Grid Status Update| Admin

    %% Process 5: AI Engine
    D4 -->|Historical Load Series| P5
    P5 -->|24h Demand Forecast| P2
    P5 -->|Anomaly Score Alert| Admin
    P5 -->|Audit Record| D7

    %% Process 6: Billing & Analytics
    P4 -->|Completed Session Details| P6
    P6 <-->|Read/Update Balances| D6
    P6 -->|Downloadable Invoice| User
    D4 -->|Aggregate Energy Streams| P6
    D5 -->|Historical Revenue| P6
    P6 -->|Operational Analytics Charts| Admin
```

---

## 3. Data Dictionary Summary

| Data Flow Name | Originating Process | Destination Store | Data Elements Included |
| :--- | :--- | :--- | :--- |
| **User Credential Flow** | Driver / Admin | `D1: Users` | `email`, `password_hash`, `role`, `name`, `walletBalance` |
| **Station Registry Flow** | Process 2.0 | `D2: Stations` | `stationId`, `name`, `coordinates`, `chargers[]`, `baseTariff` |
| **Slot Booking Flow** | Process 2.0 | `D3: Reservations`| `bookingId`, `userId`, `chargerId`, `startTime`, `endTime`, `status` |
| **Telemetry Ingestion Flow**| Process 3.0 | `D4: Telemetry` | `timestamp`, `chargerId`, `voltage`, `current`, `power`, `temp`, `pf` |
| **Charging Session Flow** | Process 4.0 | `D5: Sessions` | `sessionId`, `userId`, `chargerId`, `energyDelivered`, `startTime`, `endTime` |
| **Financial Ledger Flow** | Process 6.0 | `D6: Ledger` | `transactionId`, `userId`, `amount`, `type`, `balanceAfter`, `invoicePdf` |
| **Audit Stream Flow** | All Processes | `D7: Audits` | `timestamp`, `actorId`, `ipAddress`, `action`, `resource`, `recordHash` |
