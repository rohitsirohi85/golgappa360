import React, { useState } from 'react';
import {
  Trash2,
  AlertTriangle,
  Lightbulb,
  TrendingDown,
  Sparkles,
  ArrowRight,
  Plus,
  Calendar,
  CheckCircle2,
  DollarSign,
  PieChart as PieIcon,
  Layers
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard, GlassPanel } from '../components/glass/GlassCard';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';

export function WasteAnalysisPage() {
  const { wasteData, inventoryData, handleLogWaste, searchQuery } = useGolgappa();

  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [selectedIngredient, setSelectedIngredient] = useState('1');
  const [wasteQty, setWasteQty] = useState('');
  const [wasteReason, setWasteReason] = useState('Broken Puris (Transit/Handling)');
  const [preventionNotes, setPreventionNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const kpis = wasteData?.kpis || {
    totalWasteCost: 5154,
    totalIncidents: 90,
    avgDailyWaste: 172,
    wasteRatePct: 4.8
  };

  const wasteByReason = wasteData?.wasteByReason || [];
  const wasteByIngredient = wasteData?.wasteByIngredient || [];
  const highWasteDays = wasteData?.highWasteDays || [];
  const recommendations = wasteData?.recommendations || [];
  const logs = wasteData?.recentWasteLogs || wasteData?.logs || [];

  const filteredLogs = logs.filter((log) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    const name = log.ingredient_name || log.ingredient || '';
    const reason = log.reason || '';
    const date = log.date || '';
    return (
      name.toLowerCase().includes(q) ||
      reason.toLowerCase().includes(q) ||
      date.toLowerCase().includes(q)
    );
  });

  const reasonColors = ['#E58B79', '#EAB64B', '#D98768', '#929195'];

  const handleWasteSubmit = async (e) => {
    e.preventDefault();
    if (!wasteQty || Number(wasteQty) <= 0) return;
    setIsSubmitting(true);
    await handleLogWaste({
      ingredient_id: selectedIngredient,
      quantity: Number(wasteQty),
      reason: wasteReason,
      recommendation: preventionNotes
    });
    setIsSubmitting(false);
    setIsLogModalOpen(false);
    setWasteQty('');
    setPreventionNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/[0.08]">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F4F1] font-sans">
            Food Waste & Shrinkage Analytics
          </h2>
          <p className="text-xs text-[#929195] mt-0.5">
            Auditing broken puris, souring flavoured water, and potato spoilage to minimize cash leakages
          </p>
        </div>

        <button
          onClick={() => setIsLogModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#E58B79] text-[#171717] text-xs font-bold hover:bg-[#D47A68] transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          <Trash2 className="w-4 h-4" />
          <span>Log Spoilage Incident</span>
        </button>
      </div>

      {/* KPI Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Total Food Waste Loss</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-[#E58B79] mt-1.5">
            ₹{(kpis.totalWasteCost || 0).toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-[#929195] mt-2">Deducted from monthly gross profit</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Waste Drag Rate (% of COGS)</p>
          <div className="flex items-baseline gap-2 mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1]">{kpis.wasteRatePct}%</h3>
            <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-full border border-[#A7D78A]/30">
              Benchmark &lt; 6%
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">Optimal ratio for open street stall</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Average Daily Wastage</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1] mt-1.5">
            ₹{kpis.avgDailyWaste} / day
          </h3>
          <p className="text-[11px] text-[#929195] mt-2">Mostly puris crushed during burlap transit</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Identified Monthly Savings</p>
          <div className="flex items-baseline gap-2 mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#A7D78A]">₹5,950</h3>
            <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-full border border-[#A7D78A]/30">
              4 Solutions
            </span>
          </div>
          <p className="text-[11px] text-[#929195] mt-2">Adopt rigid totes & split-batch prep</p>
        </GlassCard>
      </div>

      {/* Row 1: Charts - Root Cause Distribution & High Waste Days */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Waste By Root Cause */}
        <div className="lg:col-span-5 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1]">Primary Spoilage & Loss Causes</h3>
              <p className="text-xs text-[#929195]">Financial loss split by operational root cause</p>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E58B79]/15 text-[#E58B79] border border-[#E58B79]/30">
              Audit
            </span>
          </div>

          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={wasteByReason}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="totalCost"
                >
                  {wasteByReason.map((entry, index) => (
                    <Cell key={`reason-${index}`} fill={reasonColors[index % reasonColors.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val, name, props) => [`₹${val} (${props.payload.percentage}%)`, props.payload.reason]}
                  contentStyle={{
                    backgroundColor: 'rgba(28,28,30,0.95)',
                    borderColor: 'rgba(255,255,255,0.15)',
                    borderRadius: '14px',
                    fontSize: '11px',
                    color: '#F5F4F1'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-white/10">
            {wasteByReason.map((r, i) => (
              <div key={r.reason} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: reasonColors[i % reasonColors.length] }} />
                  <span className="text-[#929195] truncate">{r.reason}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0 font-mono">
                  <span className="font-bold text-[#F5F4F1]">₹{r.totalCost}</span>
                  <span className="text-[#929195]">({r.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* High Waste Days Analysis */}
        <div className="lg:col-span-7 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1]">High-Waste Days Outlier Analysis</h3>
              <p className="text-xs text-[#929195]">Dates with preparation mismatches or weather disruptions</p>
            </div>
            <span className="text-[10px] font-bold text-[#B8B7B9] bg-white/[0.08] px-2.5 py-1 rounded-full border border-white/10">
              Top 5 Spikes
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#F5F4F1]">
              <thead className="bg-white/[0.04] text-[#929195] font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-3 rounded-l-xl">Date & Day</th>
                  <th className="px-4 py-3 text-right">Plates Served</th>
                  <th className="px-4 py-3 text-right">Turnover</th>
                  <th className="px-4 py-3 text-right">Waste Cost (₹)</th>
                  <th className="px-4 py-3 text-center">Waste Drag %</th>
                  <th className="px-4 py-3 rounded-r-xl">Primary Root Cause</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {highWasteDays.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-xs text-[#929195]">
                      No high waste anomaly days recorded in the selected date window.
                    </td>
                  </tr>
                ) : (
                  highWasteDays.map((day) => (
                  <tr key={day.date} className="hover:bg-white/[0.04] transition-colors">
                    <td className="px-4 py-3.5 font-semibold">
                      {day.date} <span className="text-[#929195] font-normal">({day.dayOfWeek})</span>
                    </td>
                    <td className="px-4 py-3.5 text-right font-bold">
                      {day.platesSold ?? 0}
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono">
                      ₹{(day.revenue || 0).toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-3.5 text-right font-bold text-[#E58B79] font-mono">
                      ₹{(day.wasteCost || 0).toLocaleString('en-IN')}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        (day.wasteRatioPct || 0) > 7
                          ? 'bg-[#E58B79]/20 text-[#E58B79] border border-[#E58B79]/30'
                          : 'bg-[#EAB64B]/20 text-[#EAB64B] border border-[#EAB64B]/30'
                      }`}>
                        {day.wasteRatioPct ? `${day.wasteRatioPct}%` : '0%'}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-[11px] text-[#929195]">
                      {day.dayOfWeek === 'Sunday' ? 'Excess Weekend Buffer Puris Crushed' : 'Slow Monday Evening Leftover Mint Water'}
                    </td>
                  </tr>
                )))}
              </tbody>
            </table>
          </div>

          <p className="text-[11px] text-[#929195] mt-3 pt-3 border-t border-white/10">
            * Mondays exhibit a higher percentage waste drag (9.8%) due to lower footfall following heavy Sunday over-prep.
          </p>
        </div>
      </div>

      {/* AI / Data-Driven Waste Reduction Recommendations */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-4 h-4 text-[#EAB64B]" />
          <h3 className="text-sm font-bold text-[#F5F4F1] uppercase tracking-wider">
            Data-Driven Waste Reduction Recommendations
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((rec) => (
            <div
              key={rec.id}
              className="glass-card p-5 hover:border-white/20 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <Badge variant={rec.impact === 'High' ? 'danger' : 'warning'} size="sm">
                    {rec.impact} Priority
                  </Badge>
                  <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2.5 py-0.5 rounded-full border border-[#A7D78A]/30">
                    Saves {rec.potentialSavings}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-[#F5F4F1] tracking-tight">{rec.title}</h4>

                <div className="mt-2.5 p-3 bg-white/[0.04] rounded-xl border border-white/10 text-xs text-[#B8B7B9] space-y-1">
                  <p><strong>Observed Finding:</strong> {rec.finding}</p>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-white/10 flex items-start gap-2 text-xs text-[#A7D78A]">
                <ArrowRight className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <p className="font-semibold">{rec.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Log Spoilage Modal */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Record Waste & Breakage Incident"
        subtitle="Maintain accurate audit records for daily cost deduction"
      >
        <form onSubmit={handleWasteSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Discarded Raw Material
            </label>
            <select
              value={selectedIngredient}
              onChange={(e) => setSelectedIngredient(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              {inventoryData?.ingredients?.map((ing) => (
                <option key={ing.id} value={ing.id}>
                  {ing.name} ({ing.unit})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Quantity Discarded
            </label>
            <input
              type="number"
              step="any"
              required
              min="0.1"
              placeholder="e.g. 80 pcs puris or 2.0 kg aloo"
              value={wasteQty}
              onChange={(e) => setWasteQty(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Cause / Reason
            </label>
            <select
              value={wasteReason}
              onChange={(e) => setWasteReason(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              <option value="Broken Puris (Transit/Handling)">Broken Puris (Transit/Handling)</option>
              <option value="Leftover Souring Flavoured Pani">Leftover Souring Flavoured Pani</option>
              <option value="Excess Boiled Potato Mash Souring">Excess Boiled Potato Mash Souring</option>
              <option value="Stale Tamarind Chutney">Stale Tamarind Chutney</option>
              <option value="Dahi Curdling/Over-sour">Dahi Curdling/Over-sour</option>
              <option value="Spillage / Contamination">Spillage / Contamination</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Mitigation Action Note
            </label>
            <input
              type="text"
              placeholder="e.g. Advise morning kitchen helper to boil 5kg fewer potatoes on slow days"
              value={preventionNotes}
              onChange={(e) => setPreventionNotes(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setIsLogModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#929195] hover:text-[#F5F4F1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#E58B79] text-[#171717] hover:bg-[#D47A68] transition-colors shadow-md"
            >
              {isSubmitting ? 'Recording...' : 'Confirm Spoilage Entry'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
