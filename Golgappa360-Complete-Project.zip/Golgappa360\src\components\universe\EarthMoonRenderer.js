/**
 * STELLAR 2.0 — Interactive Earth & Moon Canvas 2D Engine
 * 
 * High-performance, cinematic 60fps renderer for Earth and the Moon:
 * - 3D Spherical Orthographic Projection for rotating Earth with recognizable continents
 * - Dynamic Day / Night terminator with illuminated day hemisphere & night city lights
 * - Multi-layer Rayleigh scattering atmospheric halo & swirly clouds
 * - Geomagnetic dipole field lines visualization
 * - Moon in orbital trajectory around Earth with synchronous tidal locking
 * - Dedicated Moon close-up exploration view with lunar maria, impact craters (Tycho, Copernicus),
 *   Apollo 11 landing landmark, and interactive 8-phase lunar illumination simulator
 * 
 * DISCLAIMER: Illustrative educational visualization — not to physical scale.
 */

// Cache of background stars
let earthSceneStars = null;

function getEarthSceneStars() {
  if (earthSceneStars && earthSceneStars.length === 200) {
    return earthSceneStars;
  }
  const stars = [];
  for (let i = 0; i < 200; i++) {
    stars.push({
      x: (Math.random() - 0.5) * 3000,
      y: (Math.random() - 0.5) * 3000,
      radius: Math.random() * 1.2 + 0.35,
      alpha: Math.random() * 0.65 + 0.25,
      twinkleSpeed: Math.random() * 0.002 + 0.001,
      twinklePhase: Math.random() * Math.PI * 2,
      color: Math.random() > 0.8 ? '#93c5fd' : Math.random() > 0.85 ? '#fde68a' : '#ffffff',
    });
  }
  earthSceneStars = stars;
  return stars;
}

/**
 * Projects a spherical coordinate (latitude, longitude) with central rotation
 * onto a 2D circle with orthographic projection.
 * Returns { x, y, z, visible } where z > 0 indicates front hemisphere.
 */
export function projectSpherePoint(latDeg, lonDeg, rotationRad, radius, cx, cy) {
  const latRad = (latDeg * Math.PI) / 180;
  const lonRad = (lonDeg * Math.PI) / 180 + rotationRad;

  // 3D Cartesian coordinates on unit sphere
  const x = Math.cos(latRad) * Math.sin(lonRad);
  const y = Math.sin(latRad);
  const z = Math.cos(latRad) * Math.cos(lonRad);

  return {
    screenX: cx + x * radius,
    screenY: cy - y * radius, // Canvas Y is inverted
    x,
    y,
    z,
    visible: z > 0.05,
  };
}

/**
 * Major continent polygon outlines (simplified educational geometries)
 */
const CONTINENT_POLYGONS = [
  // North America
  [
    { lat: 70, lon: -160 }, { lat: 70, lon: -130 }, { lat: 60, lon: -90 },
    { lat: 50, lon: -60 }, { lat: 30, lon: -80 }, { lat: 18, lon: -95 },
    { lat: 15, lon: -105 }, { lat: 32, lon: -118 }, { lat: 48, lon: -125 },
    { lat: 60, lon: -140 }, { lat: 65, lon: -168 },
  ],
  // South America
  [
    { lat: 10, lon: -75 }, { lat: 5, lon: -52 }, { lat: -10, lon: -37 },
    { lat: -25, lon: -45 }, { lat: -45, lon: -65 }, { lat: -55, lon: -70 },
    { lat: -40, lon: -75 }, { lat: -20, lon: -72 }, { lat: -5, lon: -80 },
  ],
  // Eurasia
  [
    { lat: 72, lon: 30 }, { lat: 75, lon: 100 }, { lat: 68, lon: 170 },
    { lat: 55, lon: 140 }, { lat: 40, lon: 120 }, { lat: 25, lon: 120 },
    { lat: 20, lon: 110 }, { lat: 10, lon: 105 }, { lat: 15, lon: 80 },
    { lat: 25, lon: 65 }, { lat: 30, lon: 35 }, { lat: 42, lon: 28 },
    { lat: 55, lon: 10 }, { lat: 60, lon: 5 }, { lat: 70, lon: 20 },
  ],
  // Africa
  [
    { lat: 35, lon: -5 }, { lat: 32, lon: 32 }, { lat: 12, lon: 45 },
    { lat: 0, lon: 42 }, { lat: -25, lon: 32 }, { lat: -34, lon: 20 },
    { lat: -20, lon: 12 }, { lat: 5, lon: 8 }, { lat: 5, lon: -10 },
    { lat: 15, lon: -17 }, { lat: 30, lon: -10 },
  ],
  // Australia
  [
    { lat: -12, lon: 130 }, { lat: -15, lon: 145 }, { lat: -25, lon: 152 },
    { lat: -38, lon: 145 }, { lat: -35, lon: 118 }, { lat: -22, lon: 114 },
    { lat: -15, lon: 125 },
  ],
  // Antarctica
  [
    { lat: -70, lon: -180 }, { lat: -68, lon: -90 }, { lat: -65, lon: 0 },
    { lat: -68, lon: 90 }, { lat: -70, lon: 180 }, { lat: -85, lon: 0 },
  ],
];

/**
 * City night lights seed coordinates (for night-side glow)
 */
const CITY_LIGHT_POINTS = [
  // North America
  { lat: 40.7, lon: -74.0 }, { lat: 34.0, lon: -118.2 }, { lat: 41.8, lon: -87.6 }, { lat: 29.7, lon: -95.3 },
  // Europe
  { lat: 48.8, lon: 2.3 }, { lat: 51.5, lon: -0.1 }, { lat: 52.5, lon: 13.4 }, { lat: 41.9, lon: 12.5 },
  // Asia
  { lat: 35.6, lon: 139.6 }, { lat: 31.2, lon: 121.4 }, { lat: 39.9, lon: 116.4 }, { lat: 28.6, lon: 77.2 },
  { lat: 19.0, lon: 72.8 }, { lat: 1.3, lon: 103.8 }, { lat: 22.3, lon: 114.1 },
  // South America & Africa & Australia
  { lat: -23.5, lon: -46.6 }, { lat: -34.6, lon: -58.3 }, { lat: -33.8, lon: 151.2 }, { lat: -37.8, lon: 144.9 },
  { lat: 30.0, lon: 31.2 }, { lat: -26.2, lon: 28.0 },
];

/**
 * Layer 1: Deep cosmic background & distant stars
 */
export function drawEarthSceneBackground(ctx, width, height, camera, time = 0) {
  // Deep space radial gradient (#030614 -> #020308)
  const bgGrad = ctx.createRadialGradient(
    width / 2 - camera.x * camera.zoom * 0.1,
    height / 2 - camera.y * camera.zoom * 0.1,
    40,
    width / 2,
    height / 2,
    Math.max(width, height)
  );
  bgGrad.addColorStop(0, '#040817');
  bgGrad.addColorStop(0.5, '#03050e');
  bgGrad.addColorStop(1, '#020308');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Distant twinkling stars
  const stars = getEarthSceneStars();
  for (let i = 0; i < stars.length; i++) {
    const s = stars[i];
    const sx = width / 2 + (s.x - camera.x * 0.1) * camera.zoom * 0.7;
    const sy = height / 2 + (s.y - camera.y * 0.1) * camera.zoom * 0.7;

    if (sx < -20 || sx > width + 20 || sy < -20 || sy > height + 20) continue;

    const twinkle = Math.sin(time * s.twinkleSpeed + s.twinklePhase);
    const alpha = Math.max(0.1, Math.min(1.0, s.alpha + twinkle * 0.25));

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.arc(sx, sy, s.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

/**
 * Layer 2: Earth Geomagnetic Field Lines (Dipole magnetosphere)
 */
export function drawEarthMagneticField(ctx, cx, cy, r, time = 0) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-0.18); // Axial geomagnetic tilt (~10.5 degrees)

  const lineCount = 5;
  const pulse = Math.sin(time * 0.002) * 3;

  for (let i = 1; i <= lineCount; i++) {
    const spreadX = r * (1.3 + i * 0.42) + pulse * (i * 0.3);
    const spreadY = r * (0.95 + i * 0.38);

    ctx.strokeStyle = `rgba(56, 189, 248, ${0.28 - i * 0.04})`;
    ctx.lineWidth = 1.0;
    ctx.setLineDash([4, 6]);

    // East lobe
    ctx.beginPath();
    ctx.ellipse(0, 0, spreadX, spreadY, 0, -Math.PI * 0.45, Math.PI * 0.45);
    ctx.stroke();

    // West lobe
    ctx.beginPath();
    ctx.ellipse(0, 0, spreadX, spreadY, 0, Math.PI * 0.55, Math.PI * 1.45);
    ctx.stroke();
  }

  // Dipole axis indicator line
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.4)';
  ctx.lineWidth = 0.8;
  ctx.setLineDash([2, 4]);
  ctx.beginPath();
  ctx.moveTo(0, -r * 1.7);
  ctx.lineTo(0, r * 1.7);
  ctx.stroke();

  // Magnetic pole labels
  ctx.font = '500 9px ui-monospace, SFMono-Regular, Menlo, monospace';
  ctx.fillStyle = 'rgba(56, 189, 248, 0.7)';
  ctx.textAlign = 'center';
  ctx.fillText('N (MAG)', 0, -r * 1.75);
  ctx.fillText('S (MAG)', 0, r * 1.85);

  ctx.restore();
}

/**
 * Layer 3: Render Earth's Rotating Globe with Continents, Oceans, Atmosphere & Day/Night
 */
export function drawInteractiveEarth(
  ctx,
  cx,
  cy,
  r,
  earthRotation,
  options = {},
  time = 0
) {
  const {
    showAtmosphere = true,
    showDayNight = true,
    isHovered = false,
    isSelected = false,
  } = options;

  ctx.save();

  // 1. Rayleigh Scattering Atmospheric Outer Halo Glow
  if (showAtmosphere) {
    const auraGrad = ctx.createRadialGradient(cx, cy, r * 0.85, cx, cy, r * 1.35);
    auraGrad.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
    auraGrad.addColorStop(0.4, 'rgba(14, 165, 233, 0.22)');
    auraGrad.addColorStop(0.8, 'rgba(3, 105, 161, 0.08)');
    auraGrad.addColorStop(1, 'rgba(2, 6, 23, 0)');
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 1.35, 0, Math.PI * 2);
    ctx.fill();
  }

  // 2. Earth Sphere Base (Deep Ocean Blue Gradient)
  const oceanGrad = ctx.createRadialGradient(
    cx - r * 0.35,
    cy - r * 0.35,
    r * 0.1,
    cx,
    cy,
    r
  );
  oceanGrad.addColorStop(0, '#38bdf8');
  oceanGrad.addColorStop(0.25, '#0284c7');
  oceanGrad.addColorStop(0.65, '#0369a1');
  oceanGrad.addColorStop(1, '#082f49');

  ctx.fillStyle = oceanGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  // 3. Clip subsequent surface features to the sphere
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();

  // 4. Project and Draw Continents with smooth spherical perspective
  ctx.fillStyle = '#10b981';
  ctx.strokeStyle = '#059669';
  ctx.lineWidth = 1.0;

  for (const polygon of CONTINENT_POLYGONS) {
    const projectedPoints = polygon.map((pt) =>
      projectSpherePoint(pt.lat, pt.lon, earthRotation, r, cx, cy)
    );

    // Only draw polygon if at least some points are visible on the front hemisphere
    const visibleCount = projectedPoints.filter((p) => p.visible).length;
    if (visibleCount >= 2) {
      ctx.beginPath();
      let started = false;
      for (const p of projectedPoints) {
        if (p.visible) {
          if (!started) {
            ctx.moveTo(p.screenX, p.screenY);
            started = true;
          } else {
            ctx.lineTo(p.screenX, p.screenY);
          }
        }
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }

  // Polar ice caps (North & South)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.beginPath();
  ctx.ellipse(cx, cy - r * 0.9, r * 0.45, r * 0.14, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.9, r * 0.5, r * 0.15, 0, 0, Math.PI * 2);
  ctx.fill();

  // 5. Cloud Swirl Layers (Slightly faster rotation for dynamic depth)
  if (showAtmosphere) {
    const cloudAngle = earthRotation * 1.06 + time * 0.0001;
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';

    // Equatorial & temperate cloud bands
    const cloudBands = [
      { lat: 45, lon: -110 }, { lat: 35, lon: -40 }, { lat: 10, lon: 20 },
      { lat: -15, lon: 80 }, { lat: -40, lon: 160 }, { lat: 60, lon: 40 },
    ];
    for (const c of cloudBands) {
      const pt = projectSpherePoint(c.lat, c.lon, cloudAngle, r, cx, cy);
      if (pt.visible) {
        ctx.beginPath();
        ctx.ellipse(pt.screenX, pt.screenY, r * 0.32, r * 0.09, 0.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  // 6. Day / Night Terminator & Night City Lights
  if (showDayNight) {
    // Night Shadow hemisphere gradient (Sun coming from left: cx - r*0.4, cy)
    const shadowGrad = ctx.createRadialGradient(
      cx + r * 0.45,
      cy + r * 0.1,
      r * 0.2,
      cx,
      cy,
      r * 1.05
    );
    shadowGrad.addColorStop(0, 'rgba(2, 4, 12, 0.92)');
    shadowGrad.addColorStop(0.5, 'rgba(3, 7, 18, 0.7)');
    shadowGrad.addColorStop(1, 'rgba(2, 6, 23, 0)');

    ctx.fillStyle = shadowGrad;
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);

    // Night side city lights cluster
    for (const city of CITY_LIGHT_POINTS) {
      const pt = projectSpherePoint(city.lat, city.lon, earthRotation, r, cx, cy);
      // City is on front hemisphere AND in the dark eastern quadrant
      if (pt.visible && pt.screenX > cx - r * 0.1) {
        const distFromCenter = (pt.screenX - cx) / r;
        if (distFromCenter > 0) {
          const intensity = Math.min(1.0, distFromCenter * 1.5);
          ctx.fillStyle = `rgba(254, 240, 138, ${0.75 * intensity})`;
          ctx.shadowColor = '#f59e0b';
          ctx.shadowBlur = 4;
          ctx.beginPath();
          ctx.arc(pt.screenX, pt.screenY, 1.4, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }
    }
  }

  // 7. Atmospheric Inner Rim Limb Glow
  if (showAtmosphere) {
    const limbGrad = ctx.createRadialGradient(cx, cy, r * 0.75, cx, cy, r);
    limbGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    limbGrad.addColorStop(0.85, 'rgba(56, 189, 248, 0.25)');
    limbGrad.addColorStop(1, 'rgba(125, 211, 252, 0.85)');
    ctx.fillStyle = limbGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore(); // Restore sphere clip

  // 8. Hover ring / Selection Reticle for Earth
  if (isSelected) {
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(cx, cy, r + 16, 0, Math.PI * 2);
    ctx.stroke();
  } else if (isHovered) {
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.6)';
    ctx.lineWidth = 1.2;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.arc(cx, cy, r + 12, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Layer 4: Earth's Moon Orbital Track & Orbiting Moon
 */
export function drawEarthOrbitingMoon(
  ctx,
  cx,
  cy,
  earthR,
  moonAngle,
  options = {}
) {
  const {
    showOrbit = true,
    isHovered = false,
    isSelected = false,
  } = options;

  const orbitRadiusX = earthR * 2.85;
  const orbitRadiusY = earthR * 1.35;
  const tilt = -0.25; // 14° orbital inclination

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tilt);

  // 1. Orbital Path Ellipse
  if (showOrbit) {
    ctx.strokeStyle = isSelected
      ? 'rgba(56, 189, 248, 0.55)'
      : isHovered
      ? 'rgba(251, 191, 36, 0.5)'
      : 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = isSelected ? 1.5 : 1.0;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.ellipse(0, 0, orbitRadiusX, orbitRadiusY, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 2. Moon Position along elliptical trajectory
  const mx = Math.cos(moonAngle) * orbitRadiusX;
  const my = Math.sin(moonAngle) * orbitRadiusY;
  const moonR = Math.max(6, earthR * 0.27);

  // Transform coordinates back to unrotated space for drawing Moon
  ctx.restore();

  // Actual screen position of Moon
  const cosT = Math.cos(tilt);
  const sinT = Math.sin(tilt);
  const screenMx = cx + (mx * cosT - my * sinT);
  const screenMy = cy + (mx * sinT + my * cosT);

  ctx.save();

  // Moon soft ambient aura
  const moonAura = ctx.createRadialGradient(screenMx, screenMy, moonR * 0.5, screenMx, screenMy, moonR * 2.0);
  moonAura.addColorStop(0, 'rgba(226, 232, 240, 0.35)');
  moonAura.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = moonAura;
  ctx.beginPath();
  ctx.arc(screenMx, screenMy, moonR * 2.0, 0, Math.PI * 2);
  ctx.fill();

  // Moon Sphere base (grey regolith)
  const moonGrad = ctx.createRadialGradient(
    screenMx - moonR * 0.35,
    screenMy - moonR * 0.35,
    moonR * 0.1,
    screenMx,
    screenMy,
    moonR
  );
  moonGrad.addColorStop(0, '#f1f5f9');
  moonGrad.addColorStop(0.4, '#cbd5e1');
  moonGrad.addColorStop(0.85, '#64748b');
  moonGrad.addColorStop(1, '#334155');
  ctx.fillStyle = moonGrad;
  ctx.beginPath();
  ctx.arc(screenMx, screenMy, moonR, 0, Math.PI * 2);
  ctx.fill();

  // Clip craters to Moon disk
  ctx.save();
  ctx.beginPath();
  ctx.arc(screenMx, screenMy, moonR, 0, Math.PI * 2);
  ctx.clip();

  // Lunar Maria dark basalt patches
  ctx.fillStyle = 'rgba(51, 65, 85, 0.65)';
  ctx.beginPath();
  ctx.ellipse(screenMx - moonR * 0.2, screenMy - moonR * 0.15, moonR * 0.35, moonR * 0.25, 0.2, 0, Math.PI * 2);
  ctx.ellipse(screenMx + moonR * 0.25, screenMy + moonR * 0.2, moonR * 0.3, moonR * 0.2, -0.3, 0, Math.PI * 2);
  ctx.fill();

  // Sun-illuminated Phase Shadow (Sun on left side)
  const phaseGrad = ctx.createLinearGradient(screenMx - moonR, screenMy, screenMx + moonR, screenMy);
  phaseGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
  phaseGrad.addColorStop(0.45, 'rgba(2, 4, 12, 0)');
  phaseGrad.addColorStop(0.75, 'rgba(2, 4, 12, 0.85)');
  phaseGrad.addColorStop(1, 'rgba(2, 4, 12, 0.98)');
  ctx.fillStyle = phaseGrad;
  ctx.fillRect(screenMx - moonR, screenMy - moonR, moonR * 2, moonR * 2);

  ctx.restore();

  // Moon Label & Symbol
  ctx.font = '600 10px ui-monospace, SFMono-Regular, Menlo, monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';

  if (isSelected) {
    ctx.fillStyle = '#38bdf8';
    ctx.shadowColor = '#0284c7';
    ctx.shadowBlur = 6;
    ctx.fillText('🌕 MOON // LUNA', screenMx, screenMy + moonR + 8);
    ctx.shadowBlur = 0;
  } else if (isHovered) {
    ctx.fillStyle = '#fbbf24';
    ctx.shadowColor = '#d97706';
    ctx.shadowBlur = 4;
    ctx.fillText('🌕 MOON', screenMx, screenMy + moonR + 8);
    ctx.shadowBlur = 0;
  } else {
    ctx.fillStyle = 'rgba(226, 232, 240, 0.75)';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 3;
    ctx.fillText('🌕 Moon', screenMx, screenMy + moonR + 8);
  }

  // Hover & selection indicators
  if (isSelected) {
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.arc(screenMx, screenMy, moonR + 8, 0, Math.PI * 2);
    ctx.stroke();
  } else if (isHovered) {
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.6)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(screenMx, screenMy, moonR + 6, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();

  return { screenX: screenMx, screenY: screenMy, radius: moonR };
}

/**
 * Layer 5: Dedicated Lunar Close-Up Exploration View
 * Features high-fidelity lunar maria, crater rays (Tycho, Copernicus), and interactive 8-phase illumination simulator.
 */
export function drawCloseUpMoon(
  ctx,
  cx,
  cy,
  r,
  moonRotation,
  phaseAngle = 0,
  options = {}
) {
  const { isHovered = false, isSelected = false } = options;

  ctx.save();

  // 1. Lunar Regolith Corona Halo
  const haloGrad = ctx.createRadialGradient(cx, cy, r * 0.8, cx, cy, r * 1.25);
  haloGrad.addColorStop(0, 'rgba(226, 232, 240, 0.35)');
  haloGrad.addColorStop(0.5, 'rgba(148, 163, 184, 0.12)');
  haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.25, 0, Math.PI * 2);
  ctx.fill();

  // 2. Moon Basal Sphere (Grey anorthosite crust)
  const baseGrad = ctx.createRadialGradient(
    cx - r * 0.3,
    cy - r * 0.3,
    r * 0.1,
    cx,
    cy,
    r
  );
  baseGrad.addColorStop(0, '#f8fafc');
  baseGrad.addColorStop(0.35, '#cbd5e1');
  baseGrad.addColorStop(0.75, '#64748b');
  baseGrad.addColorStop(1, '#334155');
  ctx.fillStyle = baseGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  // 3. Clip all surface drawings to Moon circle
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();

  // 4. Lunar Maria (Dark Basalt Volcanic Plains)
  ctx.fillStyle = 'rgba(40, 50, 70, 0.72)';

  // Oceanus Procellarum (Ocean of Storms - Large western expanse)
  ctx.beginPath();
  ctx.ellipse(cx - r * 0.45, cy - r * 0.05, r * 0.42, r * 0.55, 0.2 + moonRotation * 0.2, 0, Math.PI * 2);
  ctx.fill();

  // Mare Imbrium (Sea of Rains)
  ctx.beginPath();
  ctx.ellipse(cx - r * 0.2, cy - r * 0.42, r * 0.32, r * 0.28, -0.1, 0, Math.PI * 2);
  ctx.fill();

  // Mare Serenitatis & Mare Tranquillitatis (Apollo 11 Sea of Tranquility)
  ctx.beginPath();
  ctx.ellipse(cx + r * 0.18, cy - r * 0.22, r * 0.25, r * 0.2, 0.3, 0, Math.PI * 2);
  ctx.ellipse(cx + r * 0.32, cy - r * 0.02, r * 0.24, r * 0.22, -0.2, 0, Math.PI * 2);
  ctx.fill();

  // Mare Crisium (Isolated circular sea on east limb)
  ctx.beginPath();
  ctx.ellipse(cx + r * 0.65, cy - r * 0.15, r * 0.16, r * 0.22, 0.1, 0, Math.PI * 2);
  ctx.fill();

  // 5. Impact Craters with Luminous Ejecta Ray Systems
  // Tycho Crater (Southern hemisphere with rays spanning across disk)
  const tychoX = cx - r * 0.12;
  const tychoY = cy + r * 0.62;

  // Tycho ray filaments
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1.0;
  for (let a = 0; a < 10; a++) {
    const rayAngle = (a * Math.PI * 2) / 10 + 0.2;
    ctx.beginPath();
    ctx.moveTo(tychoX, tychoY);
    ctx.lineTo(tychoX + Math.cos(rayAngle) * r * 0.7, tychoY + Math.sin(rayAngle) * r * 0.7);
    ctx.stroke();
  }

  // Tycho Crater Core Rim
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(tychoX, tychoY, r * 0.055, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.arc(tychoX, tychoY, r * 0.035, 0, Math.PI * 2);
  ctx.fill();

  // Copernicus Crater (Center-west bright impact site)
  const copX = cx - r * 0.22;
  const copY = cy - r * 0.12;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.beginPath();
  ctx.arc(copX, copY, r * 0.045, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.arc(copX, copY, r * 0.025, 0, Math.PI * 2);
  ctx.fill();

  // Historic Apollo 11 Landing Site Marker (Tranquility Base)
  const apolloX = cx + r * 0.25;
  const apolloY = cy + r * 0.05;
  ctx.fillStyle = '#38bdf8';
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 6;
  ctx.beginPath();
  ctx.arc(apolloX, apolloY, 2.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // 6. Interactive Moon Phase Optical Terminator Shading
  // Based on phaseAngle (0 = New Moon, PI = Full Moon, 2*PI = cycle)
  const normPhase = ((phaseAngle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  const cosPhase = Math.cos(normPhase); // -1 = Full Moon (inverted), 1 = New Moon

  // Terminator shading mask
  const termGrad = ctx.createLinearGradient(cx - r, cy, cx + r, cy);
  if (normPhase <= Math.PI) {
    // Waxing: Sun light grows from right to left
    const illuminationFrac = (1 - cosPhase) / 2; // 0 to 1
    termGrad.addColorStop(0, 'rgba(2, 4, 12, 0.94)');
    termGrad.addColorStop(Math.max(0, 1 - illuminationFrac), 'rgba(2, 4, 12, 0.88)');
    termGrad.addColorStop(Math.min(1, 1 - illuminationFrac + 0.15), 'rgba(2, 4, 12, 0)');
    termGrad.addColorStop(1, 'rgba(2, 4, 12, 0)');
  } else {
    // Waning: Sun light recedes from right to left
    const illuminationFrac = (1 - cosPhase) / 2;
    termGrad.addColorStop(0, 'rgba(2, 4, 12, 0)');
    termGrad.addColorStop(Math.max(0, illuminationFrac - 0.15), 'rgba(2, 4, 12, 0)');
    termGrad.addColorStop(Math.min(1, illuminationFrac), 'rgba(2, 4, 12, 0.88)');
    termGrad.addColorStop(1, 'rgba(2, 4, 12, 0.94)');
  }

  ctx.fillStyle = termGrad;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);

  ctx.restore(); // Restore clip

  // 7. Apollo 11 Landmark Tooltip Pill
  ctx.save();
  ctx.font = '500 9px ui-monospace, SFMono-Regular, Menlo, monospace';
  ctx.fillStyle = '#38bdf8';
  ctx.textAlign = 'left';
  ctx.fillText('▲ Tranquility Base (Apollo 11, 1969)', apolloX + 6, apolloY + 3);
  ctx.restore();

  // Selection / Hover highlights
  if (isSelected) {
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(cx, cy, r + 18, 0, Math.PI * 2);
    ctx.stroke();
  } else if (isHovered) {
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.6)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx, cy, r + 14, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Hit-testing helper for Earth & Moon view
 */
export function hitTestEarthSystem(
  screenX,
  screenY,
  earthCenter,
  earthR,
  moonScreenPos,
  moonR
) {
  // 1. Check Moon first
  if (moonScreenPos) {
    const distMoon = Math.hypot(screenX - moonScreenPos.screenX, screenY - moonScreenPos.screenY);
    if (distMoon <= Math.max(26, moonR + 10)) {
      return 'moon';
    }
  }

  // 2. Check Earth
  const distEarth = Math.hypot(screenX - earthCenter.x, screenY - earthCenter.y);
  if (distEarth <= earthR + 12) {
    return 'earth';
  }

  return null;
}
