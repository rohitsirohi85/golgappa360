# Golgappa360 — Master Data Dictionary & Semantic Catalog

> **Master of Computer Applications (MCA) Major Capstone Project**  
> **Database Scope:** MySQL 3NF Schema & Tableau Star-Schema CSV Deliverables  
> **Currency Specification:** Indian Rupee (INR ₹)  
> **Temporal Window:** 2026-05-01 to 2026-10-29 (182 Operational Days)

---

## 1. Relational Database Tables (`golgappa360`)

### 1.1 `products` (Menu Varieties Master & BOM)
*Primary Key:* `product_id` | *Total Records:* 5 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `product_id` | `VARCHAR(30)` | No | None | Primary Key | Unique catalog SKU code | `'PROD-001'` |
| `product_name`| `VARCHAR(100)`| No | None | None | Display title of golgappa variety | `'Classic Golgappa'` |
| `category` | `VARCHAR(60)` | No | None | None | Menu classification tier | `'Standard Pani Puri'` |
| `selling_price`| `DECIMAL(10,2)`| No| None | `CHECK > 0` | Menu retail price per plate in INR | `30.00` |
| `ingredient_cost_per_plate`|`DECIMAL(10,2)`|No|None|`CHECK > 0`|Standard recipe BOM cost per plate | `8.40` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Audit creation timestamp | `2026-05-01 00:00:00` |
| `updated_at` | `TIMESTAMP` | Yes | `ON UPDATE` | None | Record update timestamp | `2026-05-01 00:00:00` |

---

### 1.2 `sales` (Customer Order Transaction Header)
*Primary Key:* `sale_id` | *Total Records:* 31,938 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `sale_id` | `VARCHAR(30)` | No | None | Primary Key | Unique invoice identifier | `'SAL-0000001'` |
| `sale_datetime`| `DATETIME` | No | None | Indexed | Exact date & time of payment tender | `'2026-05-01 18:51:40'` |
| `payment_method`|`ENUM('UPI','Cash','Card')`|No|`'UPI'`|Indexed|Payment method tendered | `'UPI'` |
| `discount` | `DECIMAL(10,2)`| No | `0.00` | `CHECK >= 0` | Promotional discount applied (INR) | `0.00` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Ledger insertion timestamp | `2026-05-01 18:51:40` |

---

### 1.3 `sale_items` (Order Itemized Line Items)
*Primary Key:* `sale_item_id` | *Foreign Keys:* `sale_id`, `product_id` | *Total Records:* 31,938 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `sale_item_id` | `VARCHAR(40)` | No | None | Primary Key | Unique line item identifier | `'ITM-0000001-1'` |
| `sale_id` | `VARCHAR(30)` | No | None | FK `sales.sale_id` (CASCADE) | Parent invoice identifier | `'SAL-0000001'` |
| `product_id` | `VARCHAR(30)` | No | None | FK `products.product_id` (RESTRICT) | Variety SKU identifier | `'PROD-001'` |
| `quantity_plates`| `INT` | No | `1` | `CHECK > 0` | Portions ordered in this line | `1` |
| `unit_price` | `DECIMAL(10,2)`| No | None | `CHECK > 0` | Billed price per plate at sale time | `30.00` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Item timestamp | `2026-05-01 18:51:40` |

---

### 1.4 `ingredients` (Raw Material Catalog & Thresholds)
*Primary Key:* `ingredient_id` | *Total Records:* 8 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `ingredient_id`| `VARCHAR(30)` | No | None | Primary Key | Unique raw material identifier | `'ING-001'` |
| `ingredient_name`|`VARCHAR(100)`| No | None | None | Plain ingredient title | `'Suji & Atta Puris'` |
| `unit` | `VARCHAR(20)` | No | None | None | Unit of measure (`pcs`, `kg`, `liters`) | `'pcs'` |
| `unit_cost` | `DECIMAL(10,2)`| No | None | `CHECK > 0` | Wholesale purchase price per unit (INR) | `0.35` |
| `reorder_level`| `DECIMAL(10,2)`| No | `0.00` | `CHECK >= 0`| Safety stock threshold for restock | `2500.00` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Catalog timestamp | `2026-05-01 00:00:00` |
| `updated_at` | `TIMESTAMP` | Yes | `ON UPDATE` | None | Update timestamp | `2026-05-01 00:00:00` |

---

### 1.5 `inventory_transactions` (Stock Movements & Waste Ledger)
*Primary Key:* `transaction_id` | *Foreign Key:* `ingredient_id` | *Total Records:* 2,391 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `transaction_id`|`VARCHAR(40)` | No | None | Primary Key | Ledger movement identifier | `'ITX-000001'` |
| `transaction_date`|`DATE` | No | None | Indexed | Operational date of movement | `'2026-05-01'` |
| `ingredient_id`| `VARCHAR(30)` | No | None | FK `ingredients.ingredient_id` | Stock item moved | `'ING-001'` |
| `transaction_type`|`ENUM('PURCHASE','CONSUMPTION','WASTE')`|No|None|Indexed|Movement nature classification | `'PURCHASE'` |
| `quantity` | `DECIMAL(10,2)`| No | None | `CHECK > 0` | Quantity moved in ingredient unit | `10500.00` |
| `reference_id` | `VARCHAR(50)` | Yes | None | None | Supplier invoice or waste audit tag | `'PO-20260501-INIT'` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Entry timestamp | `2026-05-01 06:00:00` |

---

### 1.6 `daily_expenses` (Stall Operating Overhead Vouchers)
*Primary Key:* `expense_id` | *Total Records:* 845 rows

| Column Name | SQL Data Type | Nullable | Default | Constraints | Description | Example |
|:---|:---|:---:|:---:|:---|:---|:---|
| `expense_id` | `VARCHAR(40)` | No | None | Primary Key | Expense voucher identifier | `'EXP-000001'` |
| `expense_date` | `DATE` | No | None | Indexed | Voucher date | `'2026-05-01'` |
| `expense_category`|`VARCHAR(60)` | No | None | Indexed | Overhead classification category | `'Stall Rent'` |
| `amount` | `DECIMAL(10,2)`| No | None | `CHECK > 0` | Voucher payment in INR | `250.00` |
| `created_at` | `TIMESTAMP` | Yes | `CURRENT_TIMESTAMP` | None | Ledger timestamp | `2026-05-01 23:00:00` |

---

## 2. Tableau Star-Schema CSV Deliverables

All exports are encoded in strict **RFC 4180 UTF-8 standard** with clean numeric formats.

### 2.1 `tableau_sales.csv` (Primary Fact Table)
- **Granularity:** One row per customer order line item.
- **Record Count:** 31,938 rows | **Size:** 5.57 MB | **Columns:** 21.

| Field Name | Data Type | Role | Default Aggregation | Business Definition & Formula | Example |
|:---|:---|:---:|:---:|:---|:---|
| `sale_id` | String | Dimension | None | Unique invoice transaction code | `'SAL-0000001'` |
| `sale_datetime` | DateTime | Dimension | None | ISO timestamp: `YYYY-MM-DD HH:mm:ss` | `'2026-05-01 18:51:40'` |
| `sale_date` | Date | Dimension | None | Calendar date `YYYY-MM-DD` | `'2026-05-01'` |
| `sale_time` | String | Dimension | None | Wall-clock time `HH:mm:ss` | `'18:51:40'` |
| `sale_hour` | Integer | Dimension | None | Operational hour (15 to 22) | `18` |
| `day_of_week` | String | Dimension | None | Monday through Sunday | `'Friday'` |
| `is_weekend` | String | Dimension | None | `'Weekend'` vs `'Weekday'` | `'Weekday'` |
| `product_id` | String | Dimension | None | Foreign key linking to `tableau_products` | `'PROD-001'` |
| `product_name` | String | Dimension | None | Golgappa product title | `'Classic Golgappa'` |
| `category` | String | Dimension | None | Product tier | `'Standard Pani Puri'` |
| `quantity_plates`| Integer | Measure | SUM | Portions ordered in this transaction | `1` |
| `unit_price` | Decimal | Measure | AVG | Menu price per plate (INR) | `30.00` |
| `gross_sales` | Decimal | Measure | SUM | `quantity_plates * unit_price` | `30.00` |
| `discount` | Decimal | Measure | SUM | Direct invoice promotional discount | `0.00` |
| `net_revenue` | Decimal | Measure | SUM | `gross_sales - discount` | `30.00` |
| `ingredient_cost_per_plate`|Decimal|Measure|AVG|Standard BOM cost per portion | `8.40` |
| `cogs` | Decimal | Measure | SUM | `quantity_plates * ingredient_cost_per_plate` | `8.40` |
| `gross_profit` | Decimal | Measure | SUM | `net_revenue - cogs` | `21.60` |
| `gross_margin_pct`| Decimal | Measure | AVG | `(gross_profit / net_revenue) * 100` | `72.00` |
| `payment_method`| String | Dimension | None | Tender method (`UPI`, `Cash`) | `'UPI'` |
| `is_synthetic` | Boolean | Dimension | None | Verification flag (`true`) | `'true'` |

---

### 2.2 `tableau_products.csv` (Dimension Catalog)
- **Granularity:** One row per unique golgappa variety.
- **Record Count:** 5 rows | **Size:** 0.9 KB | **Columns:** 10.

| Field Name | Data Type | Role | Default Aggregation | Description | Example |
|:---|:---|:---:|:---:|:---|:---|
| `product_id` | String | Dimension | None | Primary Key | `'PROD-001'` |
| `product_name` | String | Dimension | None | Item name | `'Classic Golgappa'` |
| `category` | String | Dimension | None | Category classification | `'Standard Pani Puri'` |
| `selling_price` | Decimal | Measure | AVG | Standard price per plate | `30.00` |
| `ingredient_cost_per_plate`| Decimal | Measure | AVG | Recipe Bill of Materials cost | `8.40` |
| `unit_gross_profit`| Decimal | Measure | AVG | `selling_price - ingredient_cost_per_plate` | `21.60` |
| `unit_gross_margin_pct`| Decimal | Measure | AVG | `(unit_gross_profit / selling_price) * 100` | `72.00` |
| `pieces_per_plate`| Integer | Measure | AVG | Puris served per portion | `6` |
| `flavour_profile`| String | Dimension | None | Spice, mint, and water recipe notes | `'Signature Mint Water'`|
| `is_synthetic` | Boolean | Dimension | None | Verification flag | `'true'` |

---

### 2.3 `tableau_inventory.csv` (Operational Fact Table)
- **Granularity:** One row per stock movement ledger transaction.
- **Record Count:** 2,391 rows | **Size:** 314 KB | **Columns:** 13.

| Field Name | Data Type | Role | Default Aggregation | Description | Example |
|:---|:---|:---:|:---:|:---|:---|
| `transaction_id` | String | Dimension | None | Primary Key | `'ITX-000001'` |
| `transaction_date`| Date | Dimension | None | Calendar date of stock event | `'2026-05-01'` |
| `ingredient_id` | String | Dimension | None | Foreign key linking to ingredients | `'ING-001'` |
| `ingredient_name`| String | Dimension | None | Denormalized ingredient title | `'Suji & Atta Puris'` |
| `transaction_type`| String | Dimension | None | Movement type (`PURCHASE`, `CONSUMPTION`, `WASTE`) | `'PURCHASE'` |
| `movement_direction`| String | Dimension | None | `'Inflow'`, `'Outflow'`, or `'Waste Loss'` | `'Inflow'` |
| `quantity` | Decimal | Measure | SUM | Physical volume in ingredient unit | `10500.00` |
| `unit` | String | Dimension | None | Unit of measure (`pcs`, `kg`, `liters`) | `'pcs'` |
| `unit_cost` | Decimal | Measure | AVG | Wholesale cost per unit | `0.35` |
| `extended_cost` | Decimal | Measure | SUM | `quantity * unit_cost` | `3675.00` |
| `reorder_level` | Decimal | Measure | AVG | Minimum stock safety threshold | `2500.00` |
| `reference_id` | String | Dimension | None | Audit voucher code | `'PO-20260501-INIT'` |
| `is_synthetic` | Boolean | Dimension | None | Verification flag | `'true'` |

---

### 2.4 `tableau_daily_summary.csv` (Aggregated P&L Fact Table)
- **Granularity:** One row per operational calendar day.
- **Record Count:** 182 rows | **Size:** 21.0 KB | **Columns:** 17.

| Field Name | Data Type | Role | Default Aggregation | Description & Formula | Example |
|:---|:---|:---:|:---:|:---|:---|
| `sale_date` | Date | Dimension | None | Operational date | `'2026-05-01'` |
| `day_of_week` | String | Dimension | None | Day name (Monday to Sunday) | `'Friday'` |
| `is_weekend` | String | Dimension | None | `'Weekend'` vs `'Weekday'` | `'Weekday'` |
| `orders_count` | Integer | Measure | SUM | `COUNT(DISTINCT sale_id)` | `175` |
| `plates_sold` | Integer | Measure | SUM | `SUM(quantity_plates)` | `261` |
| `gross_sales` | Decimal | Measure | SUM | Gross billed sales turnover | `9670.00` |
| `total_discounts`| Decimal | Measure | SUM | Deducted promotional discounts | `0.00` |
| `net_revenue` | Decimal | Measure | SUM | Net turnover collected | `9670.00` |
| `cogs` | Decimal | Measure | SUM | Recipe ingredient cost of plates sold | `2704.90` |
| `gross_profit` | Decimal | Measure | SUM | `net_revenue - cogs` | `6965.10` |
| `gross_margin_pct`| Decimal | Measure | AVG | `(gross_profit / net_revenue) * 100` | `72.03` |
| `daily_waste_cost`| Decimal | Measure | SUM | Rupee value of food discarded on that day | `65.20` |
| `waste_ratio_pct`| Decimal | Measure | AVG | `(daily_waste_cost / net_revenue) * 100` | `0.67` |
| `operating_expenses`|Decimal | Measure | SUM | Stall rent, packaging, gas, electricity | `695.20` |
| `estimated_operating_profit`|Decimal|Measure|SUM|`gross_profit - operating_expenses` | `6269.90` |
| `operating_margin_pct`|Decimal | Measure | AVG | `(operating_profit / net_revenue) * 100` | `64.84` |
| `is_synthetic` | Boolean | Dimension | None | Verification flag | `'true'` |

---

### 2.5 `tableau_expenses.csv` (Overhead Fact Table)
- **Granularity:** One row per overhead payment voucher.
- **Record Count:** 845 rows | **Size:** 69.2 KB | **Columns:** 7.

| Field Name | Data Type | Role | Default Aggregation | Description | Example |
|:---|:---|:---:|:---:|:---|:---|
| `expense_id` | String | Dimension | None | Primary Key | `'EXP-000001'` |
| `expense_date` | Date | Dimension | None | Voucher payment date | `'2026-05-01'` |
| `day_of_week` | String | Dimension | None | Day name | `'Friday'` |
| `is_weekend` | String | Dimension | None | Weekend flag | `'Weekday'` |
| `expense_category`| String | Dimension | None | Overhead classification | `'Stall Rent'` |
| `amount` | Decimal | Measure | SUM | Voucher amount in INR | `250.00` |
| `is_synthetic` | Boolean | Dimension | None | Verification flag | `'true'` |
