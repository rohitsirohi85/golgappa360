import { api } from './api';
import { DEFAULT_CHARGING_SESSION } from '../data/mockCharging';

export const chargingService = {
  getActiveSession: async () => {
    try {
      const data = await api.get('/charging/active');
      if (data && data._id) {
        return {
          sessionId: data._id,
          stationName: data.stationId?.name || 'Green Valley EV Hub',
          chargerId: data.chargerId?._id || data.chargerId,
          chargerName: data.chargerId?.chargerNumber || 'Charger 01',
          connector: data.chargerId?.connectorType || 'CCS2',
          currentBattery: data.startBattery || 78,
          targetBattery: 80,
          voltage: data.chargerId?.voltage || 233,
          current: data.chargerId?.current || 9.6,
          power: data.chargerId?.power || 2.23,
          energyDelivered: data.energyConsumed || 15.2,
          temperature: data.chargerId?.temperature || 38,
          ratePerKwh: data.chargerId?.pricePerKwh || 10,
          powerCurve: DEFAULT_CHARGING_SESSION.powerCurve,
        };
      }
      return null;
    } catch (err) {
      console.warn('Backend getActiveSession fallback:', err.message);
      return null;
    }
  },

  startSession: async (chargerInfo, vehicleInfo) => {
    try {
      const payload = {
        stationId: chargerInfo?.stationId || '6ab3c24e807570864d6511a0',
        chargerId: chargerInfo?.chargerId || chargerInfo?.id,
        vehicleId: vehicleInfo?.id,
        startBattery: vehicleInfo?.currentBattery || 78,
      };

      const data = await api.post('/charging/start', payload);
      return {
        sessionId: data._id,
        stationName: data.stationId?.name || chargerInfo?.stationName || 'Green Valley EV Hub',
        chargerId: data.chargerId?._id || data.chargerId,
        chargerName: data.chargerId?.chargerNumber || chargerInfo?.chargerName || 'Charger 01',
        currentBattery: data.startBattery || 78,
        targetBattery: 80,
        voltage: 233,
        current: 9.6,
        power: 2.23,
        energyDelivered: 0.1,
        temperature: 38,
        ratePerKwh: data.chargerId?.pricePerKwh || 10,
        powerCurve: DEFAULT_CHARGING_SESSION.powerCurve,
      };
    } catch (err) {
      console.warn('Backend startSession fallback:', err.message);
      return {
        ...DEFAULT_CHARGING_SESSION,
        sessionId: `SES-${Date.now()}`,
      };
    }
  },

  stopSession: async (metrics) => {
    try {
      const payload = {
        sessionId: metrics?.sessionId,
        finalBattery: metrics?.currentBattery || 80,
        energyConsumed: metrics?.energyDelivered || 18.4,
        durationMinutes: Math.max(1, Math.round((metrics?.chargingTimeSec || 2520) / 60)) || 42,
      };

      const data = await api.post('/charging/stop', payload);
      const bill = data.bill;
      return {
        sessionId: data.session?._id || metrics?.sessionId,
        stationName: metrics?.stationName || 'Green Valley EV Hub',
        chargerName: metrics?.chargerName || 'CH-01',
        finalBattery: data.session?.endBattery || 80,
        energyUsed: data.session?.energyConsumed || 18.4,
        durationMinutes: data.session?.duration || 42,
        rate: bill?.pricePerKwh || 10,
        totalAmount: bill?.totalAmount || 184,
        completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
    } catch (err) {
      console.warn('Backend stopSession fallback:', err.message);
      const energy = metrics?.energyDelivered || 18.4;
      const rate = 10;
      return {
        sessionId: metrics?.sessionId || 'SES-2026-9921',
        stationName: metrics?.stationName || 'Green Valley EV Hub',
        chargerName: metrics?.chargerName || 'CH-01',
        finalBattery: 80,
        energyUsed: energy,
        durationMinutes: 42,
        rate,
        totalAmount: Math.round(energy * rate),
        completedAt: '04:42 PM',
      };
    }
  },

  getHistory: async () => {
    try {
      const data = await api.get('/charging/history');
      if (Array.isArray(data) && data.length > 0) {
        return data.map((s) => ({
          id: s._id,
          bookingId: s.bookingId?._id || `SES-${s._id.slice(-6)}`,
          date: new Date(s.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
          time: new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          stationName: s.stationId?.name || 'Green Valley EV Hub',
          chargerName: s.chargerId?.chargerNumber || 'Charger 01',
          energyKwh: s.energyConsumed,
          rate: s.chargerId?.pricePerKwh || 10,
          amount: s.estimatedCost || 184,
          status: s.status === 'completed' ? 'Completed' : 'Cancelled',
          duration: `${s.duration} mins`,
          batteryStart: s.startBattery,
          batteryEnd: s.endBattery,
        }));
      }
      return null;
    } catch (err) {
      console.warn('Backend getHistory fallback:', err.message);
      return null;
    }
  },
};
