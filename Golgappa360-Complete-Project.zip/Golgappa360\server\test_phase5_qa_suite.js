/**
 * Golgappa360 - Phase 5 Final QA, Unit & Integration Test Suite
 * 
 * Verifies:
 * 1. Analytics Calculation Core (Net Revenue, Gross Profit, Margins, Operating Profit)
 * 2. Zero-Denominator & Safe Division Guardrails
 * 3. Empty & Malformed Dataset Handling
 * 4. Missing Product Reference Robustness
 * 5. Date Range Boundary & Edge Case Resolution
 * 6. Inventory Ledger Balancing
 * 7. CSV Export RFC 4180 Compliance & Header Verifications
 * 8. Live HTTP API Endpoints & Status Codes
 * 9. Input Validation Middleware (Bad Dates, Reversed Bounds, Negative Pagination)
 * 10. Database Connection & Driver Status Reporting
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import * as analytics from './src/analytics/golgappaAnalytics.js';
import { getDbStatus } from './src/config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const BASE_URL = 'http://localhost:5000';

async function runTestSuite() {
  console.log('=====================================================================');
  console.log('       Golgappa360 — Phase 5 Comprehensive QA & Test Suite           ');
  console.log('=====================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`[PASS] ${testName}`);
      passed++;
    } else {
      console.error(`[FAIL] ${testName}: ${details}`);
      failed++;
    }
  }

  // -----------------------------------------------------------------
  // GROUP 1: Analytics Pure Calculations & Financial Invariants
  // -----------------------------------------------------------------
  console.log('--- Group 1: Analytics Pure Calculations & Financial Invariants ---');
  
  // Test 1: Safe Division Zero Denominator
  assert(analytics.safeDivide(100, 0) === 0, 'safeDivide(100, 0) returns fallback 0');
  assert(analytics.safeDivide(0, 0) === 0, 'safeDivide(0, 0) returns fallback 0');
  assert(analytics.safeDivide(100, NaN, 5) === 5, 'safeDivide(100, NaN, 5) returns custom fallback');
  assert(analytics.safeDivide(100, Infinity) === 0, 'safeDivide(100, Infinity) returns fallback');

  // Test 2: Standard Financial Formulas
  const sampleSales = [
    { sale_id: 'S1', sale_datetime: '2026-06-01 18:00:00', product_id: 'P1', quantity_plates: 2, unit_price: 30, discount: 5 },
    { sale_id: 'S2', sale_datetime: '2026-06-01 19:00:00', product_id: 'P2', quantity_plates: 1, unit_price: 35, discount: 0 }
  ];
  const prodMap = new Map([
    ['P1', { product_id: 'P1', product_name: 'P1', ingredient_cost_per_plate: 8.4 }],
    ['P2', { product_id: 'P2', product_name: 'P2', ingredient_cost_per_plate: 9.2 }]
  ]);
  const ingMap = new Map();
  const sampleExpenses = [{ expense_id: 'E1', expense_date: '2026-06-01', amount: 20 }];
  const sampleWaste = [];

  const kpis = analytics.calculateKpis({
    sales: sampleSales,
    expenses: sampleExpenses,
    wasteTransactions: sampleWaste,
    productsMap: prodMap,
    ingredientsMap: ingMap
  });

  // Gross = (2*30) + (1*35) = 95
  assert(kpis.grossRevenue === 95, 'Gross Revenue matches sum of quantity * unit_price (95)');
  // Discount = 5
  assert(kpis.totalDiscounts === 5, 'Discounts match direct sum (5)');
  // Net = 95 - 5 = 90
  assert(kpis.totalRevenue === 90, 'Net Revenue = Gross Revenue - Discounts (90)');
  // COGS = (2*8.4) + (1*9.2) = 16.8 + 9.2 = 26.0
  assert(Math.abs(kpis.cogs - 26.0) < 0.001, 'COGS = sum(quantity * BOM cost) (26.0)');
  // Gross Profit = 90 - 26 = 64.0
  assert(Math.abs(kpis.grossProfit - 64.0) < 0.001, 'Gross Profit = Net Revenue - COGS (64.0)');
  // Margin % = (64 / 90) * 100 = 71.11%
  assert(Math.abs(kpis.grossMarginPct - 71.1) < 0.1, 'Gross Margin % = (Gross Profit / Net Revenue) * 100 (~71.1%)');
  // Operating Profit = 64 - 20 = 44.0
  assert(Math.abs(kpis.operatingProfit - 44.0) < 0.001, 'Operating Profit = Gross Profit - Operating Expenses (44.0)');

  // -----------------------------------------------------------------
  // GROUP 2: Empty Dataset & Missing Reference Guardrails
  // -----------------------------------------------------------------
  console.log('\n--- Group 2: Empty Dataset & Missing Reference Guardrails ---');
  
  const emptyKpis = analytics.calculateKpis({
    sales: [],
    expenses: [],
    wasteTransactions: [],
    productsMap: new Map(),
    ingredientsMap: new Map()
  });
  assert(emptyKpis.totalRevenue === 0, 'Empty sales produces 0 revenue without NaN');
  assert(emptyKpis.grossMarginPct === 0, 'Empty sales produces 0 gross margin % without division-by-zero crash');
  assert(emptyKpis.aov === 0, 'Empty sales produces 0 AOV');

  // Missing product reference (unregistered SKU)
  const orphanSales = [
    { sale_id: 'S_ORPHAN', sale_datetime: '2026-06-01 18:00:00', product_id: 'NON_EXISTENT_SKU', quantity_plates: 3, unit_price: 40, discount: 0 }
  ];
  const orphanKpis = analytics.calculateKpis({
    sales: orphanSales,
    expenses: [],
    wasteTransactions: [],
    productsMap: new Map(), // empty map
    ingredientsMap: new Map()
  });
  assert(orphanKpis.totalRevenue === 120, 'Unregistered SKU computes revenue correctly');
  assert(orphanKpis.cogs === 0, 'Unregistered SKU defaults BOM cost to 0 safely without crashing');

  // -----------------------------------------------------------------
  // GROUP 3: Date Range Boundaries & Parsing
  // -----------------------------------------------------------------
  console.log('\n--- Group 3: Date Range Boundaries & Parsing ---');

  const r30 = analytics.resolveDateRange('30d', '2026-10-29');
  assert(r30.endDate === '2026-10-29', '30d range has correct anchor endDate (2026-10-29)');
  assert(r30.startDate === '2026-09-30', '30d range has correct inclusive startDate (2026-09-30)');

  const rToday = analytics.resolveDateRange('today', '2026-10-29');
  assert(rToday.startDate === '2026-10-29' && rToday.endDate === '2026-10-29', 'Today range is single day');

  const rAll = analytics.resolveDateRange('180d', '2026-10-29');
  assert(rAll.startDate === '2026-05-01' && rAll.endDate === '2026-10-29', '180d covers full 6 months from 2026-05-01');

  // Boundary filtering check
  const testFilterSales = [
    { sale_id: '1', sale_datetime: '2026-05-01 15:00:00', product_id: 'P1' },
    { sale_id: '2', sale_datetime: '2026-05-15 15:00:00', product_id: 'P1' },
    { sale_id: '3', sale_datetime: '2026-06-01 15:00:00', product_id: 'P1' }
  ];
  const filtered = analytics.filterSales(testFilterSales, { startDate: '2026-05-01', endDate: '2026-05-15' });
  assert(filtered.length === 2, 'Inclusive date boundary filter returns exactly 2 records');

  // -----------------------------------------------------------------
  // GROUP 4: CSV Export File Existence & RFC 4180 Formatting
  // -----------------------------------------------------------------
  console.log('\n--- Group 4: CSV Export RFC 4180 Compliance & Values ---');

  const tableauFiles = [
    'tableau_sales.csv',
    'tableau_products.csv',
    'tableau_inventory.csv',
    'tableau_daily_summary.csv',
    'tableau_expenses.csv',
    'tableau_data_dictionary.csv'
  ];

  tableauFiles.forEach(f => {
    const p1 = path.join(ROOT_DIR, 'tableau', 'exports', f);
    assert(fs.existsSync(p1), `File exists on disk: tableau/exports/${f}`);
    const content = fs.readFileSync(p1, 'utf8');
    const firstLine = content.split(/\r?\n/)[0];
    assert(firstLine && firstLine.startsWith('"'), `Headers are properly RFC 4180 quoted in ${f}`);
    // Check that numeric currency values are pure numbers, not strings with ₹
    assert(!content.includes('₹'), `Numeric values are clean numbers without formatted currency symbols in ${f}`);
  });

  // -----------------------------------------------------------------
  // GROUP 5: Live API Endpoints & Status Codes
  // -----------------------------------------------------------------
  console.log('\n--- Group 5: Live API Endpoints & Query Validations ---');

  async function apiGet(path) {
    try {
      const res = await fetch(`${BASE_URL}${path}`);
      const contentType = res.headers.get('content-type') || '';
      const isJson = contentType.includes('application/json');
      const data = isJson ? await res.json() : await res.text();
      return { status: res.status, data, contentType };
    } catch (err) {
      return { status: 0, error: err.message };
    }
  }

  // 1. Health
  const hRes = await apiGet('/api/health');
  assert(hRes.status === 200 && hRes.data.status === 'healthy', 'GET /api/health returns 200 healthy');

  // 2. Dashboard Summary
  const sumRes = await apiGet('/api/dashboard/summary?range=30d');
  assert(sumRes.status === 200 && sumRes.data.success, 'GET /api/dashboard/summary returns 200 success');

  // 3. Sales Trend
  const trendRes = await apiGet('/api/dashboard/sales-trend?range=30d');
  assert(trendRes.status === 200 && Array.isArray(trendRes.data.data.trend), 'GET /api/dashboard/sales-trend returns valid trend array');

  // 4. Hourly Sales
  const hourlyRes = await apiGet('/api/dashboard/hourly-sales?range=30d');
  assert(hourlyRes.status === 200 && Array.isArray(hourlyRes.data.data.hourly), 'GET /api/dashboard/hourly-sales returns hourly profile');

  // 5. Paginated Sales
  const salesRes = await apiGet('/api/sales?page=1&limit=5');
  assert(salesRes.status === 200 && salesRes.data.data.sales.length === 5, 'GET /api/sales returns paginated records');

  // 6. Tableau Catalog
  const catRes = await apiGet('/api/reports/tableau/catalog');
  assert(catRes.status === 200 && catRes.data.data.tableauFiles.length === 6, 'GET /api/reports/tableau/catalog returns 6 verified datasets');

  // 7. Tableau Direct Download
  const dlRes = await apiGet('/api/reports/export/tableau/tableau_products.csv');
  assert(dlRes.status === 200 && dlRes.contentType.includes('text/csv'), 'GET /api/reports/export/tableau/tableau_products.csv serves text/csv');

  // 8. Query Validation: Bad Date Format
  const badDateRes = await apiGet('/api/dashboard/summary?startDate=bad-date');
  assert(badDateRes.status === 400 && badDateRes.data.error.includes('YYYY-MM-DD'), 'GET with malformed startDate rejected with 400 Bad Request');

  // 9. Query Validation: Reversed Date Bounds
  const revDateRes = await apiGet('/api/dashboard/summary?startDate=2026-10-29&endDate=2026-05-01');
  assert(revDateRes.status === 400 && revDateRes.data.error.includes('cannot be after'), 'GET with startDate > endDate rejected with 400 Bad Request');

  // 10. Query Validation: Negative Page
  const negPageRes = await apiGet('/api/sales?page=-2');
  assert(negPageRes.status === 400 && negPageRes.data.error.includes('Must be an integer >= 1'), 'GET with page=-2 rejected with 400 Bad Request');

  // 11. Query Validation: Limit Exceeding 500
  const bigLimitRes = await apiGet('/api/sales?limit=9999');
  assert(bigLimitRes.status === 400 && bigLimitRes.data.error.includes('between 1 and 500'), 'GET with limit=9999 rejected with 400 Bad Request');

  // -----------------------------------------------------------------
  // GROUP 6: Database Driver & Connection Audit
  // -----------------------------------------------------------------
  console.log('\n--- Group 6: Database Driver & Connection Audit ---');
  const dbStatus = getDbStatus();
  console.log(`Database Active Mode: ${dbStatus.mode}`);
  console.log(`Active Data Source:   ${dbStatus.activeDataSource}`);
  console.log(`Connection Status:    ${dbStatus.isConnected ? 'MySQL 8.0 Live Connection' : 'In-Memory Calibrated Synthetic Store (Fallback Safe)'}`);
  assert(dbStatus.activeDataSource !== undefined, 'Database manager reports verified active driver status');

  console.log('\n=====================================================================');
  console.log(`QA Test Suite Completed: ${passed} Passed, ${failed} Failed`);
  console.log('=====================================================================\n');

  return { passed, failed };
}

runTestSuite().catch(console.error);
