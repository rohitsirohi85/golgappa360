import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Calendar,
  Bell,
  Menu,
  ChevronDown,
  User,
  CheckCircle2,
  AlertTriangle,
  Info,
  ExternalLink,
  Store,
  RefreshCw,
  Sparkles,
  Inbox,
  RotateCcw,
  UtensilsCrossed
} from 'lucide-react';
import { useGolgappa } from '../../context/GolgappaContext';

export function TopBar({ setMobileOpen }) {
  const {
    activeTab,
    dateRange,
    setDateRange,
    selectedProduct,
    setSelectedProduct,
    searchQuery,
    setSearchQuery,
    isFiltered,
    resetFilters,
    notifications,
    stallSettings,
    loadData,
    loading,
    setActiveTab
  } = useGolgappa();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const notifRef = useRef(null);
  const profileRef = useRef(null);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setIsNotifOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setIsProfileOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const dateOptions = [
    { id: 'today', label: 'Today (Oct 29)' },
    { id: '7d', label: 'Last 7 Days' },
    { id: '30d', label: 'Last 30 Days' },
    { id: '90d', label: 'Last 90 Days (3M)' },
    { id: '180d', label: 'All 6 Months (May - Oct)' }
  ];

  const productOptions = [
    { id: 'all', label: 'All Varieties' },
    { id: 'PROD-001', label: 'Classic Golgappa' },
    { id: 'PROD-002', label: 'Spicy Pani Puri' },
    { id: 'PROD-003', label: 'Sweet Pani Puri' },
    { id: 'PROD-004', label: 'Special Golgappa' },
    { id: 'PROD-005', label: 'Dahi Puri' }
  ];

  const pageHeaders = {
    overview: {
      title: 'Business Overview',
      subtitle: 'Your Golgappa Business at a Glance'
    },
    sales: {
      title: 'Sales & Footfall Engine',
      subtitle: 'Revenue Trajectory & Commuter Surge Analytics'
    },
    menu: {
      title: 'Menu & Product Economics',
      subtitle: 'Recipe Costing, Margins & Variety Performance'
    },
    inventory: {
      title: 'Inventory Management',
      subtitle: 'Real-Time Stock Runway & Mandi Replenishment'
    },
    waste: {
      title: 'Food Waste & Shrinkage',
      subtitle: 'Puri Breakage & Water Spoilage Minimization'
    },
    reports: {
      title: 'Reports & Data Hub',
      subtitle: 'Tableau-Ready CSV Datasets & Production SQL Library'
    },
    settings: {
      title: 'Settings & Database',
      subtitle: 'MySQL 8.0 Parameters & Stall Business Profile'
    }
  };

  const currentHeader = pageHeaders[activeTab] || pageHeaders.overview;

  return (
    <header className="px-5 lg:px-8 pt-6 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      {/* Left: Mobile hamburger & Clean Title Header matching reference */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => setMobileOpen(prev => !prev)}
          className="lg:hidden p-2 rounded-2xl bg-white/[0.08] text-[#F5F4F1] border border-white/10 hover:bg-white/[0.14] transition-colors cursor-pointer"
          aria-label="Toggle Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F5F4F1] font-sans">
            {currentHeader.title}
          </h1>
          <p className="text-xs text-[#929195] font-medium mt-0.5 tracking-normal">
            {currentHeader.subtitle}
          </p>
        </div>
      </div>

      {/* Right Controls: Search, Date Filter, Refresh, Notifications, Avatar */}
      <div className="flex items-center gap-2 sm:gap-3 flex-wrap sm:flex-nowrap">
        {/* Search Input pill */}
        <div className="relative min-w-[180px] sm:min-w-[220px]">
          <Search className="w-4 h-4 text-[#929195] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search metrics, orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/[0.06] text-[#F5F4F1] placeholder-[#929195] text-xs rounded-2xl pl-9 pr-7 py-2 border border-white/12 focus:border-[#A7D78A]/60 focus:bg-white/[0.10] focus:outline-hidden transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[#929195] hover:text-[#F5F4F1]"
            >
              ×
            </button>
          )}
        </div>

        {/* Global Date Filter Pill */}
        <div className="relative">
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/[0.07] border border-white/12 text-xs font-semibold text-[#F5F4F1] hover:border-white/25 transition-colors shadow-xs">
            <Calendar className="w-3.5 h-3.5 text-[#EAB64B]" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-transparent border-none text-xs font-semibold text-[#F5F4F1] focus:outline-hidden cursor-pointer pr-1"
            >
              {dateOptions.map((opt) => (
                <option key={opt.id} value={opt.id} className="text-[#F5F4F1] bg-[#1E1E22] py-1">
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Global Product Filter Pill */}
        <div className="relative hidden sm:block">
          <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-white/[0.07] border border-white/12 text-xs font-semibold text-[#F5F4F1] hover:border-white/25 transition-colors shadow-xs">
            <UtensilsCrossed className="w-3.5 h-3.5 text-[#A7D78A]" />
            <select
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="bg-transparent border-none text-xs font-semibold text-[#F5F4F1] focus:outline-hidden cursor-pointer pr-1"
            >
              {productOptions.map((opt) => (
                <option key={opt.id} value={opt.id} className="text-[#F5F4F1] bg-[#1E1E22] py-1">
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Reset Filters Pill (Visible when any filter is active) */}
        {isFiltered && (
          <button
            onClick={resetFilters}
            title="Reset to default 30-day baseline and all products"
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-[#EAB64B]/15 hover:bg-[#EAB64B]/25 text-[#EAB64B] border border-[#EAB64B]/30 text-xs font-bold transition-all cursor-pointer shadow-xs animate-in fade-in"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        )}

        {/* Refresh button */}
        <button
          onClick={() => loadData()}
          disabled={loading}
          title="Refresh Data from Server"
          className="p-2.5 rounded-2xl bg-white/[0.07] hover:bg-white/[0.12] text-[#B8B7B9] hover:text-[#F5F4F1] border border-white/12 transition-colors cursor-pointer shadow-xs"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#A7D78A]' : ''}`} />
        </button>

        {/* Notifications Icon Pill */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setIsNotifOpen(prev => !prev)}
            className="relative p-2.5 rounded-2xl bg-white/[0.07] hover:bg-white/[0.12] text-[#B8B7B9] hover:text-[#F5F4F1] border border-white/12 transition-colors cursor-pointer shadow-xs"
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#EAB64B] text-[#171717] text-[9px] font-bold flex items-center justify-center ring-2 ring-[#171717]">
                {notifications.length}
              </span>
            )}
          </button>

          {isNotifOpen && (
            <div className="glass-dropdown absolute right-0 mt-3 w-80 sm:w-96 rounded-3xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#F5F4F1] uppercase tracking-wider">
                    Operational Alerts
                  </h4>
                  <p className="text-[11px] text-[#929195]">Real-time footfall & reserve status</p>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#A7D78A]/20 text-[#A7D78A] border border-[#A7D78A]/30">
                  {notifications.length} Active
                </span>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-white/[0.06] p-1">
                {notifications.map((n) => (
                  <div key={n.id} className="p-3 hover:bg-white/[0.05] rounded-2xl transition-colors flex items-start gap-3">
                    <div className="mt-0.5">
                      {n.type === 'warning' && (
                        <div className="w-6 h-6 rounded-lg bg-[#EAB64B]/20 text-[#EAB64B] flex items-center justify-center border border-[#EAB64B]/30">
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </div>
                      )}
                      {n.type === 'info' && (
                        <div className="w-6 h-6 rounded-lg bg-[#A7D78A]/20 text-[#A7D78A] flex items-center justify-center border border-[#A7D78A]/30">
                          <Info className="w-3.5 h-3.5" />
                        </div>
                      )}
                      {n.type === 'alert' && (
                        <div className="w-6 h-6 rounded-lg bg-[#E58B79]/20 text-[#E58B79] flex items-center justify-center border border-[#E58B79]/30">
                          <Sparkles className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-[#F5F4F1] truncate">{n.title}</p>
                        <span className="text-[10px] text-[#929195]">{n.timestamp}</span>
                      </div>
                      <p className="text-[11px] text-[#B8B7B9] mt-0.5 leading-relaxed">{n.message}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="px-4 py-2 border-t border-white/10 text-center">
                <button
                  onClick={() => {
                    setActiveTab('inventory');
                    setIsNotifOpen(false);
                  }}
                  className="text-xs font-bold text-[#A7D78A] hover:underline"
                >
                  Manage Ingredient Reserves →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Profile Avatar Pill matching reference */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setIsProfileOpen(prev => !prev)}
            className="flex items-center gap-2.5 p-1.5 pl-2 rounded-2xl bg-white/[0.07] hover:bg-white/[0.12] border border-white/12 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#A7D78A] to-[#EAB64B] text-[#171717] font-bold text-xs flex items-center justify-center shadow-xs">
              RS
            </div>
            <span className="w-2 h-2 rounded-full bg-[#A7D78A] ring-2 ring-white/10" />
          </button>

          {isProfileOpen && (
            <div className="glass-dropdown absolute right-0 mt-3 w-64 rounded-3xl p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-3 py-2 border-b border-white/10">
                <p className="text-xs font-bold text-[#F5F4F1]">{stallSettings.stallName}</p>
                <p className="text-[11px] text-[#B8B7B9] mt-0.5">{stallSettings.ownerName} (Proprietor)</p>
                <p className="text-[10px] text-[#929195] mt-0.5">{stallSettings.location}</p>
              </div>

              <div className="py-2 space-y-1 text-xs">
                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setIsProfileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-[#B8B7B9] hover:text-[#F5F4F1] hover:bg-white/[0.08] flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <Store className="w-3.5 h-3.5 text-[#A7D78A]" />
                  <span>Stall Configuration</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab('reports');
                    setIsProfileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-[#B8B7B9] hover:text-[#F5F4F1] hover:bg-white/[0.08] flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#EAB64B]" />
                  <span>Tableau & CSV Deliverables</span>
                </button>
              </div>

              <div className="px-3 py-2 border-t border-white/10 text-[10px] text-[#929195] flex items-center justify-between">
                <span>MCA BI Final Project</span>
                <span>MySQL 8.0</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
