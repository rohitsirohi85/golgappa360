import React from 'react';
import { GolgappaProvider, useGolgappa } from './context/GolgappaContext';
import { Layout } from './components/layout/Layout';
import { OverviewPage } from './pages/OverviewPage';
import { SalesAnalyticsPage } from './pages/SalesAnalyticsPage';
import { MenuProductPage } from './pages/MenuProductPage';
import { InventoryPage } from './pages/InventoryPage';
import { WasteAnalysisPage } from './pages/WasteAnalysisPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { LoadingState } from './components/common/LoadingState';

function MainRouter() {
  const { activeTab, loading } = useGolgappa();

  if (loading) {
    return (
      <Layout>
        <LoadingState rows={5} />
      </Layout>
    );
  }

  const renderPage = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewPage />;
      case 'sales':
        return <SalesAnalyticsPage />;
      case 'menu':
        return <MenuProductPage />;
      case 'inventory':
        return <InventoryPage />;
      case 'waste':
        return <WasteAnalysisPage />;
      case 'reports':
        return <ReportsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <OverviewPage />;
    }
  };

  return <Layout>{renderPage()}</Layout>;
}

export function GolgappaApp() {
  return (
    <GolgappaProvider>
      <MainRouter />
    </GolgappaProvider>
  );
}

export default GolgappaApp;
