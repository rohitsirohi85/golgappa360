import React from 'react';
import { useMess } from '../../context/MessContext';
import { Eye, Loader2, Inbox, AlertTriangle } from 'lucide-react';

export const SimulationControlBar = () => {
  const { simulationState, setSimulationState } = useMess();

  return (
    <div className="flex items-center gap-2 p-1.5 px-3 rounded-lg bg-white border border-[#E4EAE5] text-xs shadow-xs">
      <span className="text-[11px] font-medium text-[#77847C] flex items-center gap-1.5 uppercase tracking-wider">
        <Eye className="w-3.5 h-3.5 text-[#16865B]" />
        UI State:
      </span>
      <div className="flex items-center gap-1 bg-[#F8FAF8] p-0.5 rounded-md border border-[#E4EAE5]">
        <button
          onClick={() => setSimulationState('normal')}
          className={`px-2.5 py-1 rounded text-[11px] font-medium transition-all cursor-pointer ${
            simulationState === 'normal'
              ? 'bg-white text-[#16865B] border border-[#C5E5D0] shadow-xs font-semibold'
              : 'text-[#77847C] hover:text-[#25332D]'
          }`}
        >
          Normal
        </button>
        <button
          onClick={() => setSimulationState('loading')}
          className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-all cursor-pointer ${
            simulationState === 'loading'
              ? 'bg-white text-[#B45309] border border-[#FDE68A] shadow-xs font-semibold'
              : 'text-[#77847C] hover:text-[#25332D]'
          }`}
        >
          <Loader2 className="w-3 h-3 animate-spin" />
          Loading
        </button>
        <button
          onClick={() => setSimulationState('empty')}
          className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-all cursor-pointer ${
            simulationState === 'empty'
              ? 'bg-white text-[#0284C7] border border-[#BAE6FD] shadow-xs font-semibold'
              : 'text-[#77847C] hover:text-[#25332D]'
          }`}
        >
          <Inbox className="w-3 h-3" />
          Empty
        </button>
        <button
          onClick={() => setSimulationState('error')}
          className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-all cursor-pointer ${
            simulationState === 'error'
              ? 'bg-white text-[#B91C1C] border border-[#FECACA] shadow-xs font-semibold'
              : 'text-[#77847C] hover:text-[#25332D]'
          }`}
        >
          <AlertTriangle className="w-3 h-3" />
          Error
        </button>
      </div>
    </div>
  );
};
