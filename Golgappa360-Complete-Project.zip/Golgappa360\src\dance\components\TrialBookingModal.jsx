import React, { useState } from 'react';
import { X, Calendar, Clock, CheckCircle, ArrowRight, User, Mail, Phone, Sparkles, Printer } from 'lucide-react';
import { DANCE_PROGRAMS, ACADEMY_CONFIG } from '../data/danceData';

export const TrialBookingModal = ({ isOpen, onClose, initialProgramId = null }) => {
  const [selectedProgram, setSelectedProgram] = useState(
    initialProgramId || DANCE_PROGRAMS[0].id
  );
  const [selectedLevel, setSelectedLevel] = useState('Foundation (Beginner)');
  const [selectedDate, setSelectedDate] = useState('This Thursday (19:00)');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});
  const [submittedPass, setSubmittedPass] = useState(null);

  if (!isOpen) return null;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide your full name.';
    if (!formData.email.trim() || !formData.email.includes('@')) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.phone.trim() || formData.phone.length < 7) {
      newErrors.phone = 'Please provide a valid phone number.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    // Generate unique verifiable trial pass code
    const randomCode =
      'MIA-' +
      Math.floor(1000 + Math.random() * 9000) +
      '-' +
      selectedProgram.substring(0, 3).toUpperCase();

    const activeProgObj = DANCE_PROGRAMS.find((p) => p.id === selectedProgram);

    setSubmittedPass({
      code: randomCode,
      dancerName: formData.name,
      email: formData.email,
      phone: formData.phone,
      programName: activeProgObj ? activeProgObj.name : selectedProgram,
      level: selectedLevel,
      slot: selectedDate,
      issuedAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const currentProgramObj = DANCE_PROGRAMS.find((p) => p.id === selectedProgram) || DANCE_PROGRAMS[0];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="trial-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md overflow-y-auto animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-[#14141B] border border-white/[0.12] rounded-sm p-6 sm:p-8 shadow-2xl my-auto text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#A5A1B2] hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
          aria-label="Close booking modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!submittedPass ? (
          <div>
            {/* Modal Header */}
            <div className="mb-6">
              <span className="font-mono text-xs text-[#8B5CF6] uppercase font-bold tracking-wider block mb-1">
                // COMPLIMENTARY INTRO SESSION
              </span>
              <h3
                id="trial-modal-title"
                className="font-display font-extrabold text-2xl sm:text-3xl text-white uppercase"
              >
                BOOK YOUR TRIAL PASS
              </h3>
              <p className="text-xs sm:text-sm text-[#A5A1B2] mt-1">
                Experience the studio atmosphere, test our sprung flooring, and train with resident artists with zero obligation.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Program Selection */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-2">
                  Select Discipline
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {DANCE_PROGRAMS.map((prog) => (
                    <button
                      type="button"
                      key={prog.id}
                      onClick={() => setSelectedProgram(prog.id)}
                      className={`p-2.5 rounded-sm text-left border text-xs font-sans transition-all focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6] ${
                        selectedProgram === prog.id
                          ? 'bg-[#1B1B26] border-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.25)]'
                          : 'bg-[#0B0B0F] border-white/[0.08] text-[#A5A1B2] hover:text-white hover:border-white/20'
                      }`}
                    >
                      <span className="font-semibold block truncate">{prog.name}</span>
                      <span className="font-mono text-[9px] text-[#A78BFA] opacity-80 block truncate">
                        {prog.intensity}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Level & Slot Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1.5">
                    Experience Level
                  </label>
                  <select
                    value={selectedLevel}
                    onChange={(e) => setSelectedLevel(e.target.value)}
                    className="w-full bg-[#0B0B0F] border border-white/[0.1] rounded-sm px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="Foundation (Beginner)">Level 01 — Foundation (Beginner)</option>
                    <option value="Street Mechanics (Intermediate)">Level 02 — Intermediate Flow</option>
                    <option value="Cypher Intensive (Advanced)">Level 03 — Masterclass / Pro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1.5">
                    Preferred Session Time
                  </label>
                  <select
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full bg-[#0B0B0F] border border-white/[0.1] rounded-sm px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="This Tuesday (18:30)">This Tuesday — 18:30 (Evening)</option>
                    <option value="This Thursday (19:00)">This Thursday — 19:00 (Evening)</option>
                    <option value="This Saturday (11:30)">This Saturday — 11:30 (Morning)</option>
                    <option value="This Sunday (14:00)">This Sunday — 14:00 (Afternoon)</option>
                  </select>
                </div>
              </div>

              {/* Dancer Contact Details */}
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                    Dancer Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="e.g. Jordan Rivera"
                    className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                      errors.name ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                    }`}
                  />
                  {errors.name && (
                    <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.name}</span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="dancer@example.com"
                      className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                        errors.email ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                      }`}
                    />
                    {errors.email && (
                      <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.email}</span>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+1 (555) 000-0000"
                      className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                        errors.phone ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                      }`}
                    />
                    {errors.phone && (
                      <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.phone}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 text-xs font-semibold tracking-widest uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.6)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
                >
                  <span>GENERATE TRIAL PASS VOUCHER</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[10px] text-center text-[#A5A1B2] mt-2 font-mono">
                  100% Free introductory access • No credit card required • Instant voucher
                </p>
              </div>
            </form>
          </div>
        ) : (
          /* Real-time Generated Digital Trial Pass Voucher */
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="font-mono text-xs text-emerald-400 uppercase font-semibold">
                  TRIAL PASS RESERVED
                </span>
                <h3 className="font-display font-black text-2xl text-white uppercase">
                  YOU'RE ON THE FLOOR.
                </h3>
              </div>
            </div>

            {/* The Digital Voucher Card */}
            <div className="p-5 sm:p-6 rounded-sm bg-[#0B0B0F] border-2 border-[#8B5CF6]/50 shadow-[0_0_30px_rgba(139,92,246,0.2)] relative overflow-hidden">
              <div className="flex justify-between items-start border-b border-white/[0.08] pb-4">
                <div>
                  <span className="font-display font-black tracking-tight text-lg text-white">
                    MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
                  </span>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-[#A5A1B2] block">
                    OFFICIAL GUEST TRIAL PASS
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs text-[#8B5CF6] font-bold block">
                    {submittedPass.code}
                  </span>
                  <span className="font-mono text-[9px] text-[#A5A1B2]">VALID 14 DAYS</span>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Dancer</span>
                  <span className="font-sans font-bold text-white text-sm">{submittedPass.dancerName}</span>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Discipline</span>
                  <span className="font-sans font-bold text-[#A78BFA] text-sm">{submittedPass.programName}</span>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Level</span>
                  <span className="font-sans text-white">{submittedPass.level}</span>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Session Slot</span>
                  <span className="font-sans text-white font-medium">{submittedPass.slot}</span>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-dashed border-white/[0.1] text-[10px] font-mono text-[#A5A1B2]">
                <p>📍 Location: {ACADEMY_CONFIG.contact.address}, {ACADEMY_CONFIG.contact.city}</p>
                <p>👟 Dress Code: Clean indoor sneakers or bare feet, athletic attire</p>
                <p>⏱ Check-in: Please arrive 15 minutes prior to class start</p>
              </div>
            </div>

            {/* Voucher Action Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrint}
                className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-white/[0.08] hover:bg-white/[0.15] border border-white/10 rounded-sm transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>SAVE / PRINT PASS</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm transition-colors"
              >
                DONE
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
