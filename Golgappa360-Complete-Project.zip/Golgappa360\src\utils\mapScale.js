/**
 * STELLAR 2.0 — Map Scale & Coordinate Transform Utilities
 */

export const MIN_ZOOM = 0.55;
export const MAX_ZOOM = 4.5;
export const DEFAULT_ZOOM = 1.0;

/**
 * Transforms world coordinates to canvas viewport coordinates.
 */
export function worldToScreen(wx, wy, camera, width, height) {
  const sx = (wx - camera.x) * camera.zoom + width / 2;
  const sy = (wy - camera.y) * camera.zoom + height / 2;
  return { x: sx, y: sy };
}

/**
 * Transforms canvas viewport coordinates to world coordinates.
 */
export function screenToWorld(sx, sy, camera, width, height) {
  const wx = (sx - width / 2) / camera.zoom + camera.x;
  const wy = (sy - height / 2) / camera.zoom + camera.y;
  return { x: wx, y: wy };
}

/**
 * Linear interpolation.
 */
export function lerp(start, end, factor) {
  return start + (end - start) * factor;
}

/**
 * Clamps a number between min and max.
 */
export function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

/**
 * Returns human-readable zoom level category.
 */
export function getZoomLevelInfo(zoom) {
  if (zoom < 1.2) {
    return {
      level: 1,
      name: 'Cosmic View',
      description: 'Broad stellar field & luminous clusters',
      tag: 'LVL 1',
    };
  }
  if (zoom < 2.2) {
    return {
      level: 2,
      name: 'Stellar Region',
      description: 'Constellation corridors & major stars',
      tag: 'LVL 2',
    };
  }
  if (zoom < 3.5) {
    return {
      level: 3,
      name: 'Individual Star',
      description: 'Spectral classifications & telemetry',
      tag: 'LVL 3',
    };
  }
  return {
    level: 4,
    name: 'Star System',
    description: 'Corona radiance & companion dynamics',
    tag: 'LVL 4',
  };
}

/**
 * Detects the star closest to a given screen position within a hit threshold.
 */
export function hitTestStar(screenX, screenY, stars, camera, width, height, hitRadius = 24) {
  let closestStar = null;
  let minDistance = hitRadius;

  for (const star of stars) {
    const screenPos = worldToScreen(star.x, star.y, camera, width, height);
    const dx = screenPos.x - screenX;
    const dy = screenPos.y - screenY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < minDistance) {
      minDistance = dist;
      closestStar = star;
    }
  }

  return closestStar;
}
