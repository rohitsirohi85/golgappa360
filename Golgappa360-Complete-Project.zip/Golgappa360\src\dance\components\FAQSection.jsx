import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ArrowUpRight } from 'lucide-react';
import { FAQ_ITEMS } from '../data/danceData';

export const FAQSection = ({ onOpenTrial }) => {
  const [openIdx, setOpenIdx] = useState(0);

  const toggleItem = (idx) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section
      id="faq"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="Frequently Asked Questions"
    >
      <div className="max-w-4xl mx-auto px-5 sm:px-8">
        
        {/* Header */}
        <div className="text-center max-w-xl mx-auto mb-16">
          <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
            [ 07 // CLARITY & PROTOCOLS ]
          </span>
          <h2 className="editorial-headline text-3xl sm:text-5xl text-[#F5F3F8] uppercase">
            BEFORE YOU <br />
            <span className="text-[#A78BFA]">HIT THE FLOOR.</span>
          </h2>
          <p className="font-sans text-sm text-[#A5A1B2] mt-4">
            Everything you need to know about preparing for your trial session, studio etiquette, and membership.
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-sm bg-[#14141B] border border-white/[0.08] transition-colors overflow-hidden"
              >
                <button
                  onClick={() => toggleItem(idx)}
                  className="w-full py-5 px-6 flex items-center justify-between text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
                  aria-expanded={isOpen}
                >
                  <span className="font-display font-bold text-base sm:text-lg text-[#F5F3F8] pr-4">
                    {item.q}
                  </span>
                  <div
                    className={`p-1.5 rounded-full bg-white/[0.04] text-[#8B5CF6] transition-transform duration-200 flex-shrink-0 ${
                      isOpen ? 'rotate-180 bg-[#8B5CF6]/20' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-sm text-[#A5A1B2] leading-relaxed border-t border-white/[0.04] animate-fade-in">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom Help Note */}
        <div className="mt-12 text-center">
          <p className="text-xs font-mono text-[#A5A1B2]">
            HAVE A SPECIFIC QUESTION ABOUT ACCESS OR ACCESSIBILITY?
          </p>
          <button
            onClick={() => onOpenTrial()}
            className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#8B5CF6] hover:text-[#A78BFA] transition-colors mt-2"
          >
            <span>SPEAK WITH STUDIO CONCIERGE</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </section>
  );
};
