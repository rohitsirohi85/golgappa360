import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';
import { getDbStatus } from '../config/db.js';

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const range = req.query.range || '30d';
    const productId = req.query.product_id || req.query.productId || 'all';
    const overviewData = syntheticStore.getOverviewMetrics(range, productId);
    const dbStatus = getDbStatus();

    res.json({
      success: true,
      data: {
        ...overviewData,
        dbStatus,
        range,
        productId
      }
    });
  } catch (error) {
    console.error('[API /api/overview Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
