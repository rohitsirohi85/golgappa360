import React, { useState } from 'react';
import { ArrowUp, ArrowRight, Music, Send, Check } from 'lucide-react';
import { ACADEMY_CONFIG, DANCE_PROGRAMS } from '../data/danceData';

const InstagramIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

const YoutubeIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
    <polygon points="10 15 15 12 10 9 10 15"/>
  </svg>
);

export const Footer = ({ onOpenTrial }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) return;
    setNewsletterSubscribed(true);
    setNewsletterEmail('');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Classes', href: '#programs' },
    { label: 'Our Story', href: '#about' },
    { label: 'Instructors', href: '#people' },
    { label: 'The Space', href: '#space' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer
      id="contact"
      className="relative bg-[#07070A] border-t border-white/[0.08] text-[#A5A1B2] pt-20 pb-12 overflow-hidden"
      aria-label="Footer & Academy Contact"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Top Grid: Brand Manifesto, Quick Nav, Disciplines, Newsletter */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-16 border-b border-white/[0.08]">
          
          {/* Brand Col */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToTop();
                }}
                className="font-display font-black text-2xl uppercase tracking-[-0.03em] text-[#F5F3F8] hover:text-[#A78BFA] transition-colors block"
              >
                MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
              </a>
              <span className="font-mono text-[10px] tracking-widest text-[#8B5CF6] uppercase block mt-1">
                CONTEMPORARY URBAN MOVEMENT ACADEMY
              </span>
              <p className="mt-4 text-xs sm:text-sm text-[#A5A1B2] leading-relaxed max-w-sm">
                "Every movement tells a story." Dedicated to developing fearless dancers through anatomical precision, street culture, and contemporary artistic agency.
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-white/[0.06] text-xs font-mono space-y-1 text-[#A5A1B2]">
              <p>📍 {ACADEMY_CONFIG.contact.address}</p>
              <p>🏢 {ACADEMY_CONFIG.contact.city}</p>
              <p>⏱ {ACADEMY_CONFIG.contact.hours}</p>
              <p>📞 {ACADEMY_CONFIG.contact.phone}</p>
              <p>✉️ {ACADEMY_CONFIG.contact.email}</p>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-2">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              EXPLORE
            </h4>
            <ul className="space-y-2.5 text-xs">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-white transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6]"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li>
                <button
                  onClick={() => onOpenTrial()}
                  className="text-[#8B5CF6] hover:text-[#A78BFA] transition-colors font-semibold"
                >
                  Book a Trial Pass →
                </button>
              </li>
            </ul>
          </div>

          {/* Programs Index */}
          <div className="lg:col-span-3">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              DISCIPLINES
            </h4>
            <ul className="space-y-2.5 text-xs">
              {DANCE_PROGRAMS.map((prog) => (
                <li key={prog.id}>
                  <a
                    href="#programs"
                    className="hover:text-white transition-colors flex items-center justify-between group"
                  >
                    <span>{prog.name}</span>
                    <span className="font-mono text-[10px] text-[#A5A1B2] group-hover:text-[#8B5CF6]">
                      {prog.intensity.split(' ')[0]}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Subscription Column */}
          <div className="lg:col-span-3">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              THE CYPHER BULLETIN
            </h4>
            <p className="text-xs text-[#A5A1B2] mb-4 leading-relaxed">
              Receive monthly invitations to open studio jams, guest artist masterclasses, and choreography archives.
            </p>

            {newsletterSubscribed ? (
              <div className="p-3.5 rounded-sm bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center gap-2">
                <Check className="w-4 h-4 flex-shrink-0" />
                <span>You are on the guest bulletin list.</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                    className="w-full bg-[#14141B] border border-white/[0.1] rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none focus:border-[#8B5CF6]"
                  />
                  <button
                    type="submit"
                    className="absolute right-1 top-1 bottom-1 px-3 bg-[#8B5CF6] hover:bg-[#A78BFA] text-white rounded-sm transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6]"
                    aria-label="Subscribe to newsletter"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-[10px] font-mono text-[#A5A1B2] block opacity-70">
                  Zero spam. Unsubscribe at any time.
                </span>
              </form>
            )}

            {/* Social Icons */}
            <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="Follow us on Instagram"
              >
                <InstagramIcon className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="Watch our choreographies on YouTube"
              >
                <YoutubeIcon className="w-4 h-4" />
              </a>
              <a
                href="https://spotify.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="Listen to our studio dance playlists on Spotify"
              >
                <Music className="w-4 h-4" />
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Sub-Footer: Copyright, Privacy & Back-to-Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-[#A5A1B2]">
          <div>
            <span>© {new Date().getFullYear()} {ACADEMY_CONFIG.brandName}. All Rights Reserved.</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Terms of Floor</span>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 text-[#F5F3F8] hover:text-[#A78BFA] transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6] py-1"
            >
              <span>BACK TO TOP</span>
              <ArrowUp className="w-3.5 h-3.5 text-[#8B5CF6]" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
