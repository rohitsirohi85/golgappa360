import React, { useState, useEffect, useRef, useMemo } from 'react';
import ObjectVisualRenderer from '../universe/ObjectVisualRenderer';
import {
  ALL_SEARCHABLE_OBJECTS,
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
  CELESTIAL_CATEGORIES,
  getCelestialObjectById,
} from '../../data/celestialObjects.js';
import {
  getComparisonMetrics,
  getComparisonInsights,
  getRelatedComparisons,
} from '../../services/compareService.js';

/**
 * Filter categories for picker
 */
const PICKER_FILTER_CHIPS = [
  { id: 'ALL', label: 'All Objects' },
  { id: CELESTIAL_CATEGORIES.STAR, label: 'Stars' },
  { id: CELESTIAL_CATEGORIES.PLANET, label: 'Planets' },
  { id: CELESTIAL_CATEGORIES.BLACK_HOLE, label: 'Black Holes' },
  { id: CELESTIAL_CATEGORIES.PULSAR, label: 'Pulsars' },
  { id: CELESTIAL_CATEGORIES.WHITE_DWARF, label: 'White Dwarfs' },
  { id: CELESTIAL_CATEGORIES.NEBULA, label: 'Nebulae' },
  { id: CELESTIAL_CATEGORIES.STAR_CLUSTER, label: 'Clusters' },
  { id: CELESTIAL_CATEGORIES.GALAXY, label: 'Galaxies' },
];

/**
 * CosmicCompareModal — STELLAR 2.0 (Phase U12: Cosmic Compare Mode)
 * 
 * Side-by-side celestial comparison observatory:
 * - Compare exactly two celestial objects from existing registry
 * - Category-aware metrics extraction with normalized comparison bars
 * - Dynamic logarithmic scaling for extreme disparities (e.g. Sun vs Betelgeuse)
 * - Factual difference highlights derived strictly from verified data
 * - Target search picker with category filter chips and quick recommendations
 * - Direct "Locate on Map" action for both targets
 * - Contextual related comparison shortcuts
 * - Deep linking URL hash support (#compare=id&vs=id)
 * - Mobile responsive stacked layout & accessible keyboard handling
 */
export default function CosmicCompareModal({
  isOpen,
  onClose,
  initialObjectA = null,
  initialObjectB = null,
  onLocateObject,
}) {
  const [objectA, setObjectA] = useState(initialObjectA);
  const [objectB, setObjectB] = useState(initialObjectB);

  // Slot picker modal/drawer state ('A' | 'B' | null)
  const [pickingSlot, setPickingSlot] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilterCategory, setSelectedFilterCategory] = useState('ALL');

  const modalRef = useRef(null);
  const searchInputRef = useRef(null);

  // Sync initial targets when modal opens or initial props change
  useEffect(() => {
    if (isOpen) {
      if (initialObjectA) setObjectA(initialObjectA);
      if (initialObjectB) setObjectB(initialObjectB);
      // If only A was given and B is empty, prompt user to pick B
      if (initialObjectA && !initialObjectB) {
        setPickingSlot('B');
      } else {
        setPickingSlot(null);
      }
    }
  }, [isOpen, initialObjectA, initialObjectB]);

  // Handle URL hash updating for deep linking
  useEffect(() => {
    if (!isOpen) return;

    if (objectA && objectB) {
      window.location.hash = `compare=${encodeURIComponent(objectA.id)}&vs=${encodeURIComponent(objectB.id)}`;
    } else if (objectA) {
      window.location.hash = `compare=${encodeURIComponent(objectA.id)}`;
    }
  }, [isOpen, objectA, objectB]);

  // Lock body scroll and handle keyboard shortcuts
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        if (pickingSlot) {
          setPickingSlot(null);
        } else {
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, pickingSlot, onClose]);

  // Focus search input when picker opens
  useEffect(() => {
    if (pickingSlot && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [pickingSlot]);

  // Swap objects handler
  const handleSwap = () => {
    setObjectA(objectB);
    setObjectB(objectA);
  };

  // Filtered objects for the picker
  const filteredPickerObjects = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const otherSelectedId = pickingSlot === 'A' ? objectB?.id : objectA?.id;

    return ALL_SEARCHABLE_OBJECTS.filter((item) => {
      // Exclude the other slot's already chosen object
      if (otherSelectedId && item.id === otherSelectedId) return false;

      // Category filter
      if (selectedFilterCategory !== 'ALL' && item.category !== selectedFilterCategory) {
        return false;
      }

      // Query filter
      if (!query) return true;

      const nameMatch = item.name.toLowerCase().includes(query);
      const commonMatch = item.commonName?.toLowerCase().includes(query);
      const constMatch = item.constellation?.toLowerCase().includes(query);
      const catMatch = item.category?.toLowerCase().includes(query);
      const subMatch = item.subtype?.toLowerCase().includes(query);

      return nameMatch || commonMatch || constMatch || catMatch || subMatch;
    });
  }, [searchQuery, selectedFilterCategory, pickingSlot, objectA, objectB]);

  // Quick suggestions for picker
  const pickerSuggestions = useMemo(() => {
    const referenceObj = pickingSlot === 'B' ? objectA : objectB;
    if (!referenceObj) {
      return [
        getCelestialObjectById('sun'),
        getCelestialObjectById('betelgeuse'),
        getCelestialObjectById('earth'),
        getCelestialObjectById('mars'),
        getCelestialObjectById('sagittarius-a-star'),
      ].filter(Boolean);
    }

    // Curated recommendations relative to the selected reference object
    const suggestions = [];
    if (referenceObj.id === 'sun') {
      suggestions.push(
        getCelestialObjectById('betelgeuse'),
        getCelestialObjectById('sirius'),
        getCelestialObjectById('earth'),
        getCelestialObjectById('jupiter')
      );
    } else if (referenceObj.category === CELESTIAL_CATEGORIES.PLANET) {
      suggestions.push(
        getCelestialObjectById(referenceObj.id === 'earth' ? 'mars' : 'earth'),
        getCelestialObjectById('jupiter'),
        getCelestialObjectById('saturn'),
        getCelestialObjectById('sun')
      );
    } else if (referenceObj.category === CELESTIAL_CATEGORIES.BLACK_HOLE) {
      suggestions.push(
        getCelestialObjectById(referenceObj.id === 'sagittarius-a-star' ? 'm87-star' : 'sagittarius-a-star'),
        getCelestialObjectById('cygnus-x1'),
        getCelestialObjectById('crab-pulsar'),
        getCelestialObjectById('sun')
      );
    } else {
      // Suggest objects in the same category or landmark stars
      const sameCat = ALL_SEARCHABLE_OBJECTS.find(
        (o) => o.category === referenceObj.category && o.id !== referenceObj.id
      );
      if (sameCat) suggestions.push(sameCat);
      suggestions.push(
        getCelestialObjectById('sun'),
        getCelestialObjectById('betelgeuse'),
        getCelestialObjectById('sirius')
      );
    }

    return suggestions.filter(Boolean).filter((s) => s.id !== referenceObj.id).slice(0, 4);
  }, [pickingSlot, objectA, objectB]);

  // Select an object into the active picking slot
  const handleSelectSlotObject = (selected) => {
    if (pickingSlot === 'A') {
      setObjectA(selected);
    } else if (pickingSlot === 'B') {
      setObjectB(selected);
    }
    setPickingSlot(null);
    setSearchQuery('');
  };

  // Select an entire comparison pair from related comparisons
  const handleSelectComparisonPair = (pair) => {
    setObjectA(pair.objA);
    setObjectB(pair.objB);
    setPickingSlot(null);
  };

  // Locate an object on the map and close modal
  const handleLocate = (target) => {
    if (!target) return;
    onClose();
    if (onLocateObject) {
      onLocateObject(target);
    }
  };

  // Computed data
  const comparisonMetrics = useMemo(
    () => getComparisonMetrics(objectA, objectB),
    [objectA, objectB]
  );

  const comparisonInsights = useMemo(
    () => getComparisonInsights(objectA, objectB),
    [objectA, objectB]
  );

  const relatedComparisons = useMemo(
    () => getRelatedComparisons(objectA, objectB),
    [objectA, objectB]
  );

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="compare-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget && !pickingSlot) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300 overflow-y-auto"
    >
      {/* Modal Dialog Container */}
      <div
        ref={modalRef}
        className="relative w-full max-w-6xl my-auto rounded-3xl bg-[#03050e]/95 border border-white/10 shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col max-h-[94vh] backdrop-blur-2xl"
      >
        {/* ======================================================== */}
        {/* HEADER BAR */}
        {/* ======================================================== */}
        <div className="flex items-center justify-between px-5 sm:px-8 py-4 border-b border-white/8 bg-[#020308]/85 backdrop-blur-md z-20">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300 font-bold text-sm shadow-[0_0_12px_rgba(6,182,212,0.25)]">
              ⚖️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2
                  id="compare-modal-title"
                  className="font-display text-lg sm:text-xl font-bold tracking-tight text-white"
                >
                  Cosmic Compare Mode
                </h2>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-widest text-cyan-300 bg-cyan-950/60 border border-cyan-400/30">
                  DUAL OBSERVATORY // V2.0
                </span>
              </div>
              <p className="text-xs font-mono text-slate-400 truncate hidden sm:block">
                Contrasting physical, orbital and relativistic metrics across celestial scales
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Swap Button in Header */}
            {objectA && objectB && (
              <button
                type="button"
                onClick={handleSwap}
                aria-label="Swap celestial targets A and B"
                title="Swap Targets A ⇄ B"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                <span>⇄</span>
                <span>Swap Targets</span>
              </button>
            )}

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close compare modal"
              className="w-9 h-9 rounded-full bg-white/[0.03] border border-white/10 text-slate-300 hover:text-white hover:border-cyan-400/50 hover:bg-white/10 flex items-center justify-center transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* ======================================================== */}
        {/* MAIN SCROLLABLE CONTENT */}
        {/* ======================================================== */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">

          {/* ====================================================== */}
          {/* SECTION 1: SIDE-BY-SIDE VISUAL SLOTS */}
          {/* ====================================================== */}
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6 items-stretch">
              {/* TARGET A CARD */}
              <TargetSlotCard
                slotLabel="TARGET A"
                slotBadgeColor="border-cyan-500/40 bg-cyan-950/40 text-cyan-300"
                glowColor={objectA?.colorHex || '#38bdf8'}
                object={objectA}
                onSelectClick={() => setPickingSlot('A')}
                onChangeClick={() => setPickingSlot('A')}
                onClearClick={() => setObjectA(null)}
                onLocateClick={() => handleLocate(objectA)}
              />

              {/* TARGET B CARD */}
              <TargetSlotCard
                slotLabel="TARGET B"
                slotBadgeColor="border-amber-500/40 bg-amber-950/40 text-amber-300"
                glowColor={objectB?.colorHex || '#f59e0b'}
                object={objectB}
                onSelectClick={() => setPickingSlot('B')}
                onChangeClick={() => setPickingSlot('B')}
                onClearClick={() => setObjectB(null)}
                onLocateClick={() => handleLocate(objectB)}
              />
            </div>

            {/* Floating Central Swap Pill (Desktop) */}
            {objectA && objectB && (
              <div className="hidden md:flex absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                <button
                  type="button"
                  onClick={handleSwap}
                  title="Swap Targets A and B"
                  aria-label="Swap Targets"
                  className="w-10 h-10 rounded-full bg-[#030712] border-2 border-white/20 hover:border-cyan-400 text-slate-200 hover:text-white flex items-center justify-center text-sm font-bold shadow-[0_0_20px_rgba(0,0,0,0.8)] hover:scale-110 active:scale-95 transition-all cursor-pointer group"
                >
                  <span className="group-hover:rotate-180 transition-transform duration-300">⇄</span>
                </button>
              </div>
            )}
          </div>

          {/* Swap Button on Mobile */}
          {objectA && objectB && (
            <div className="flex md:hidden justify-center">
              <button
                type="button"
                onClick={handleSwap}
                className="px-4 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs font-mono text-cyan-300 flex items-center gap-2 active:scale-95 transition-transform"
              >
                <span>⇄</span>
                <span>Swap Targets A and B</span>
              </button>
            </div>
          )}

          {/* ====================================================== */}
          {/* SECTION 2: SMART DIFFERENCE HIGHLIGHTS */}
          {/* ====================================================== */}
          {objectA && objectB && comparisonInsights.length > 0 && (
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/20 via-[#060a17]/40 to-amber-950/20 border border-white/10 shadow-lg">
              <div className="flex items-center gap-2 mb-3 text-xs font-mono uppercase tracking-widest text-cyan-300 font-semibold">
                <span className="text-amber-300">✦</span>
                <span>KEY ASTRONOMICAL CONTRASTS</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {comparisonInsights.map((insight, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-white/[0.02] border border-white/8 hover:border-white/15 transition-colors"
                  >
                    <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1.5">
                      <span>•</span>
                      <span>{insight.title}</span>
                    </div>
                    <p className="text-xs sm:text-[13px] font-sans text-slate-300 leading-relaxed">
                      {insight.text}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ====================================================== */}
          {/* SECTION 3: DYNAMIC COMPARISON METRICS TABLE */}
          {/* ====================================================== */}
          <div className="p-4 sm:p-6 rounded-2xl bg-[#02040b]/90 border border-white/8 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-4 border-b border-white/8">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
                  SCIENTIFIC TELEMETRY & COMPARATIVE METRICS
                </span>
              </div>
              <div className="text-[11px] font-mono text-slate-500">
                {objectA && objectB ? 'Dual Comparison' : 'Single Target View — Select 2nd Object'}
              </div>
            </div>

            {/* Metrics List */}
            <div className="space-y-3">
              {comparisonMetrics.map((metric) => (
                <ComparisonMetricRow
                  key={metric.id}
                  metric={metric}
                  objectA={objectA}
                  objectB={objectB}
                />
              ))}

              {comparisonMetrics.length === 0 && (
                <div className="py-12 text-center text-slate-500 font-mono text-xs">
                  Select at least one celestial target to view scientific metrics.
                </div>
              )}
            </div>
          </div>

          {/* ====================================================== */}
          {/* SECTION 4: CURATED RELATED COMPARISONS */}
          {/* ====================================================== */}
          {relatedComparisons.length > 0 && (
            <div className="pt-2">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-slate-400 font-semibold">
                  🔗 EXPLORE RELATED COMPARISONS
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {relatedComparisons.map((pair, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectComparisonPair(pair)}
                    className="p-3 rounded-xl bg-white/[0.02] hover:bg-cyan-950/30 border border-white/8 hover:border-cyan-400/40 text-left transition-all cursor-pointer group flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-mono font-semibold text-slate-200 group-hover:text-cyan-200">
                        {pair.label}
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                        {CATEGORY_LABELS[pair.objA.category]} vs {CATEGORY_LABELS[pair.objB.category]}
                      </div>
                    </div>
                    <span className="text-cyan-400 group-hover:translate-x-1 transition-transform text-xs font-mono">
                      →
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Disclaimer */}
          <div className="pt-2 pb-1 text-center">
            <p className="text-[10px] font-mono text-slate-500">
              Curated educational comparison visualization — not to physical scale. Scientific metrics derived from verified observational records.
            </p>
          </div>
        </div>

        {/* ======================================================== */}
        {/* OBJECT PICKER DRAWER / OVERLAY */}
        {/* ======================================================== */}
        {pickingSlot && (
          <div className="absolute inset-0 z-30 bg-[#020308]/95 backdrop-blur-2xl flex flex-col p-4 sm:p-6 lg:p-8 animate-in fade-in duration-200">
            {/* Picker Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div>
                <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
                  <span>Select Target for</span>
                  <span className={`px-2 py-0.5 rounded text-xs font-mono ${pickingSlot === 'A' ? 'bg-cyan-500/20 text-cyan-300' : 'bg-amber-500/20 text-amber-300'}`}>
                    Slot {pickingSlot}
                  </span>
                </h3>
                <p className="text-xs font-mono text-slate-400 mt-0.5">
                  Choose from stars, planets, black holes, nebulae and galaxies in the catalog
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPickingSlot(null)}
                aria-label="Cancel object picker"
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                Cancel ✕
              </button>
            </div>

            {/* Search Input Bar */}
            <div className="relative mb-3">
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search celestial target by name, constellation, or category..."
                className="w-full py-2.5 pl-10 pr-10 rounded-xl bg-white/[0.04] border border-white/15 focus:border-cyan-400 focus:bg-white/[0.07] text-white text-sm font-sans placeholder:text-slate-500 outline-none transition-all shadow-inner"
              />
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">
                🔍
              </span>
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs font-mono"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-3 no-scrollbar">
              {PICKER_FILTER_CHIPS.map((chip) => {
                const isActive = selectedFilterCategory === chip.id;
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => setSelectedFilterCategory(chip.id)}
                    className={`px-3 py-1 rounded-full text-xs font-mono whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm'
                        : 'bg-white/[0.03] text-slate-400 hover:text-slate-200 border border-white/5 hover:border-white/15'
                    }`}
                  >
                    {chip.label}
                  </button>
                );
              })}
            </div>

            {/* Quick Suggestions (if no search query) */}
            {!searchQuery && pickerSuggestions.length > 0 && (
              <div className="mb-4 p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-2 font-semibold">
                  ⚡ RECOMMENDED TARGETS
                </div>
                <div className="flex flex-wrap gap-2">
                  {pickerSuggestions.map((sug) => (
                    <button
                      key={sug.id}
                      type="button"
                      onClick={() => handleSelectSlotObject(sug)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/[0.04] hover:bg-cyan-950/40 border border-white/10 hover:border-cyan-400/40 text-xs font-mono text-slate-300 hover:text-cyan-200 transition-all cursor-pointer"
                    >
                      <span style={{ color: sug.colorHex || '#38bdf8' }}>
                        {CATEGORY_SYMBOLS[sug.category] || '●'}
                      </span>
                      <span>{sug.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Results Grid */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-2">
              <div className="text-[11px] font-mono text-slate-500 mb-2">
                {filteredPickerObjects.length} targets available
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {filteredPickerObjects.map((obj) => {
                  const symbol = CATEGORY_SYMBOLS[obj.category] || '●';
                  const catLabel = CATEGORY_LABELS[obj.category] || obj.category;
                  return (
                    <button
                      key={obj.id}
                      type="button"
                      onClick={() => handleSelectSlotObject(obj)}
                      className="p-3 rounded-xl bg-white/[0.02] hover:bg-cyan-950/40 border border-white/8 hover:border-cyan-400/50 text-left transition-all cursor-pointer group flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="flex items-center gap-1.5">
                          <span style={{ color: obj.colorHex || '#38bdf8' }} className="text-xs font-bold">
                            {symbol}
                          </span>
                          <span className="font-sans font-semibold text-sm text-white group-hover:text-cyan-200 truncate">
                            {obj.name}
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 truncate mt-0.5">
                          {obj.subtype || catLabel} {obj.constellation ? `• ${obj.constellation}` : ''}
                        </div>
                      </div>
                      <span className="text-cyan-400 text-xs font-mono group-hover:translate-x-0.5 transition-transform flex-shrink-0">
                        Select →
                      </span>
                    </button>
                  );
                })}
              </div>

              {filteredPickerObjects.length === 0 && (
                <div className="py-16 text-center text-slate-500 font-mono text-xs">
                  No celestial objects found matching "{searchQuery}".
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Target Slot Card Component (Object A or Object B)
 */
function TargetSlotCard({
  slotLabel,
  slotBadgeColor,
  glowColor,
  object,
  onSelectClick,
  onChangeClick,
  onClearClick,
  onLocateClick,
}) {
  if (!object) {
    return (
      <div
        onClick={onSelectClick}
        className="rounded-2xl border-2 border-dashed border-white/15 hover:border-cyan-400/50 bg-white/[0.01] hover:bg-white/[0.03] p-8 flex flex-col items-center justify-center text-center transition-all cursor-pointer group min-h-[260px]"
      >
        <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/10 group-hover:border-cyan-400/40 flex items-center justify-center text-xl text-slate-400 group-hover:text-cyan-300 group-hover:scale-110 transition-all mb-3">
          +
        </div>
        <div className="text-xs font-mono uppercase tracking-widest text-slate-400 group-hover:text-cyan-300 font-semibold mb-1">
          {slotLabel} EMPTY
        </div>
        <p className="text-sm font-sans text-slate-300 font-medium">
          Click to choose a target from catalog
        </p>
        <span className="mt-4 px-3.5 py-1.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs font-mono group-hover:border-cyan-400 transition-colors">
          Browse Celestial Objects →
        </span>
      </div>
    );
  }

  const categorySymbol = CATEGORY_SYMBOLS[object.category] || '●';
  const categoryLabel = CATEGORY_LABELS[object.category] || object.category;

  return (
    <div className="relative rounded-2xl bg-[#040714] border border-white/10 p-5 sm:p-6 flex flex-col justify-between overflow-hidden shadow-lg group">
      {/* Ambient background glow */}
      <div
        aria-hidden="true"
        className="absolute -top-12 -right-12 w-48 h-48 rounded-full blur-[80px] opacity-25 pointer-events-none"
        style={{ backgroundColor: glowColor }}
      />

      {/* Top Slot Header: Badge & Actions */}
      <div className="flex items-center justify-between gap-2 mb-4 relative z-10">
        <div className="flex items-center gap-2">
          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-wider border font-bold ${slotBadgeColor}`}>
            {slotLabel}
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/[0.03] border border-white/8 text-[11px] font-mono text-slate-300">
            <span style={{ color: glowColor }}>{categorySymbol}</span>
            <span>{object.subtype || categoryLabel}</span>
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onChangeClick}
            title="Change this target"
            className="px-2 py-1 rounded-lg bg-white/[0.04] hover:bg-white/10 border border-white/10 text-[11px] font-mono text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            Change
          </button>
          <button
            type="button"
            onClick={onClearClick}
            title="Clear target slot"
            className="w-6 h-6 rounded-lg bg-white/[0.04] hover:bg-red-950/40 border border-white/10 hover:border-red-400/40 text-slate-400 hover:text-red-300 flex items-center justify-center text-xs transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Center: Visual Representation & Target Name */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center my-2 relative z-10">
        {/* Visual Simulation Box */}
        <div className="sm:col-span-5 flex items-center justify-center min-h-[140px]">
          <ObjectVisualRenderer object={object} size="inspector" />
        </div>

        {/* Text Info */}
        <div className="sm:col-span-7 flex flex-col justify-center">
          <h3 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white mb-1 truncate">
            {object.name}
          </h3>
          {object.commonName && (
            <p className="text-xs sm:text-sm font-sans text-amber-300/90 italic mb-2 line-clamp-1">
              “{object.commonName}”
            </p>
          )}

          <div className="space-y-1 text-xs font-mono text-slate-400">
            {object.constellation && (
              <div>
                <span className="text-slate-500">Constellation: </span>
                <span className="text-slate-300">{object.constellation}</span>
              </div>
            )}
            {object.distance && (
              <div>
                <span className="text-slate-500">Distance: </span>
                <span className="text-slate-300">{object.distance}</span>
              </div>
            )}
            {object.distanceFromSun && (
              <div>
                <span className="text-slate-500">From Sun: </span>
                <span className="text-slate-300">{object.distanceFromSun}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Slot Action: Locate on Map */}
      <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between relative z-10">
        <button
          type="button"
          onClick={onLocateClick}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/50 hover:bg-cyan-900/70 border border-cyan-400/50 text-cyan-200 hover:text-white text-xs font-mono transition-all cursor-pointer group/loc shadow-sm"
        >
          <span className="text-cyan-400">📍</span>
          <span>Locate {object.name} on Map</span>
          <span className="group-hover/loc:translate-x-0.5 transition-transform text-cyan-400">↗</span>
        </button>

        <span className="text-[10px] font-mono text-slate-500">
          ID: {object.id}
        </span>
      </div>
    </div>
  );
}

/**
 * Metric Comparison Row with Comparative Bar
 */
function ComparisonMetricRow({ metric, objectA, objectB }) {
  const hasA = metric.valA && metric.valA !== '—';
  const hasB = metric.valB && metric.valB !== '—';
  const bars = metric.bars;

  return (
    <div className="p-3 rounded-xl bg-white/[0.015] hover:bg-white/[0.03] border border-white/5 transition-colors">
      {/* Metric Title & Icon */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-sm">{metric.icon}</span>
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
            {metric.label}
          </span>
        </div>

        {bars?.isLogarithmic && (
          <span className="text-[9px] font-mono text-cyan-400/80 uppercase tracking-widest px-1.5 py-0.5 rounded bg-cyan-950/40 border border-cyan-500/20">
            Logarithmic Scale
          </span>
        )}
      </div>

      {/* Side-by-Side Values */}
      <div className="grid grid-cols-2 gap-4 items-baseline mb-2">
        {/* Object A Value */}
        <div className="text-left">
          <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            {objectA?.name || 'Target A'}
          </div>
          <div
            className={`text-xs sm:text-sm font-mono font-medium truncate ${
              hasA ? 'text-cyan-200' : 'text-slate-600'
            }`}
          >
            {hasA ? metric.valA : 'Data unavailable'}
          </div>
        </div>

        {/* Object B Value */}
        <div className="text-right">
          <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            {objectB?.name || 'Target B'}
          </div>
          <div
            className={`text-xs sm:text-sm font-mono font-medium truncate ${
              hasB ? 'text-amber-200' : 'text-slate-600'
            }`}
          >
            {hasB ? metric.valB : 'Data unavailable'}
          </div>
        </div>
      </div>

      {/* Proportional Comparison Bars (if comparable numeric values) */}
      {bars && bars.isComparable && objectA && objectB && (
        <div className="pt-1">
          <div className="grid grid-cols-2 gap-1 items-center">
            {/* Bar A (Cyan) — grows right-to-left towards center */}
            <div className="h-1.5 bg-white/[0.05] rounded-full overflow-hidden flex justify-end">
              <div
                style={{ width: `${bars.pctA}%` }}
                className="h-full bg-gradient-to-l from-cyan-400 to-sky-500 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(6,182,212,0.4)]"
              />
            </div>

            {/* Bar B (Amber) — grows left-to-right from center */}
            <div className="h-1.5 bg-white/[0.05] rounded-full overflow-hidden flex justify-start">
              <div
                style={{ width: `${bars.pctB}%` }}
                className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
