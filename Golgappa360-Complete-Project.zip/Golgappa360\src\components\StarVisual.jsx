import React from 'react';

/**
 * StarVisual — High-fidelity lightweight astronomical star renderer
 * Visually distinguishes stellar classes:
 * - Blue Supergiant: Piercing blue-white core, powerful cyan/blue halo, long diffraction spikes
 * - Yellow Main Sequence: Golden-white core, warm yellow solar halo, convective granulation
 * - Red Supergiant: Deep orange/red convective surface, vast billowing warm halo
 * - White Dwarf: Small, ultra-bright white-blue core, compact high-intensity halo, crisp cross spikes
 * - Red Dwarf: Smaller, dim deep red/orange glow, compact quiet halo
 * - Orange Giant: Swelling amber core, warm orange coronal rim
 */
export default function StarVisual({
  star,
  size = 'md',
  isHovered = false,
  className = '',
}) {
  const type = star?.type || 'Main Sequence';
  const color = star?.visualColor || 'yellow';

  // Dimension presets
  const sizeMap = {
    sm: 'w-12 h-12',
    md: 'w-24 h-24 sm:w-28 sm:h-28',
    lg: 'w-36 h-36 sm:w-44 sm:h-44',
    modal: 'w-48 h-48 sm:w-64 sm:h-64 lg:w-72 lg:h-72',
  };

  const isModal = size === 'modal' || size === 'lg';

  // Archetype configuration based on class & type
  const isWhiteDwarf = type === 'White Dwarf' || color === 'white-dwarf';
  const isRedDwarf = type === 'Red Dwarf' || color === 'red-dwarf';
  const isSupergiant = type === 'Supergiant';
  const isGiant = type === 'Giant';

  // Base scale adjustment for physical star category
  const coreScaleClass = isWhiteDwarf
    ? 'scale-[0.62]'
    : isRedDwarf
    ? 'scale-[0.78]'
    : isSupergiant
    ? 'scale-[1.08]'
    : isGiant
    ? 'scale-[1.02]'
    : 'scale-100';

  // Precise color theme profiles
  const theme = (() => {
    if (isWhiteDwarf) {
      return {
        core: '#ffffff',
        hotspot: '#f0f9ff',
        mantle: '#e0f2fe',
        edge: '#bae6fd',
        limb: '#7dd3fc',
        halo: 'from-white/60 via-cyan-300/35 to-blue-600/15',
        glowColor: 'rgba(224, 242, 254, 0.7)',
        flareColor: '#ffffff',
        spikes: true,
        spikeColor: 'rgba(255, 255, 255, 0.85)',
        haloBlur: 'blur-lg sm:blur-xl',
      };
    }

    if (isRedDwarf) {
      return {
        core: '#fecaca',
        hotspot: '#f87171',
        mantle: '#ef4444',
        edge: '#b91c1c',
        limb: '#450a0a',
        halo: 'from-red-500/30 via-rose-700/20 to-transparent',
        glowColor: 'rgba(239, 68, 68, 0.35)',
        flareColor: '#ef4444',
        spikes: false,
        spikeColor: 'transparent',
        haloBlur: 'blur-md sm:blur-lg',
      };
    }

    if (isSupergiant && (color === 'red')) {
      return {
        core: '#fee2e2',
        hotspot: '#fca5a5',
        mantle: '#ea580c',
        edge: '#dc2626',
        limb: '#7f1d1d',
        halo: 'from-orange-500/50 via-red-600/35 to-rose-950/20',
        glowColor: 'rgba(234, 88, 12, 0.55)',
        flareColor: '#f97316',
        spikes: false,
        spikeColor: 'rgba(249, 115, 22, 0.4)',
        haloBlur: 'blur-2xl sm:blur-3xl',
      };
    }

    if (isSupergiant && (color === 'blue' || color === 'white')) {
      return {
        core: '#ffffff',
        hotspot: '#e0f2fe',
        mantle: '#38bdf8',
        edge: '#0284c7',
        limb: '#075985',
        halo: 'from-sky-400/50 via-cyan-500/35 to-blue-700/20',
        glowColor: 'rgba(56, 189, 248, 0.6)',
        flareColor: '#38bdf8',
        spikes: true,
        spikeColor: 'rgba(56, 189, 248, 0.7)',
        haloBlur: 'blur-2xl sm:blur-3xl',
      };
    }

    if (color === 'blue') {
      return {
        core: '#ffffff',
        hotspot: '#e0f2fe',
        mantle: '#38bdf8',
        edge: '#0284c7',
        limb: '#0c4a6e',
        halo: 'from-sky-400/40 via-cyan-500/25 to-blue-700/15',
        glowColor: 'rgba(56, 189, 248, 0.45)',
        flareColor: '#38bdf8',
        spikes: true,
        spikeColor: 'rgba(56, 189, 248, 0.5)',
        haloBlur: 'blur-xl sm:blur-2xl',
      };
    }

    if (color === 'white') {
      return {
        core: '#ffffff',
        hotspot: '#f8fafc',
        mantle: '#e2e8f0',
        edge: '#94a3b8',
        limb: '#334155',
        halo: 'from-white/50 via-sky-300/30 to-indigo-500/15',
        glowColor: 'rgba(248, 250, 252, 0.5)',
        flareColor: '#e0f2fe',
        spikes: true,
        spikeColor: 'rgba(224, 242, 254, 0.65)',
        haloBlur: 'blur-xl sm:blur-2xl',
      };
    }

    if (color === 'orange') {
      return {
        core: '#fff7ed',
        hotspot: '#fed7aa',
        mantle: '#fb923c',
        edge: '#ea580c',
        limb: '#7c2d12',
        halo: 'from-orange-400/40 via-amber-600/25 to-red-900/15',
        glowColor: 'rgba(251, 146, 60, 0.45)',
        flareColor: '#fb923c',
        spikes: false,
        spikeColor: 'transparent',
        haloBlur: 'blur-xl sm:blur-2xl',
      };
    }

    // Default: Yellow Main Sequence (e.g. Sun, Polaris)
    return {
      core: '#ffffff',
      hotspot: '#fef08a',
      mantle: '#fbbf24',
      edge: '#f59e0b',
      limb: '#b45309',
      halo: 'from-amber-400/45 via-yellow-500/25 to-amber-700/15',
      glowColor: 'rgba(251, 191, 36, 0.45)',
      flareColor: '#fbbf24',
      spikes: false,
      spikeColor: 'rgba(251, 191, 36, 0.4)',
      haloBlur: 'blur-xl sm:blur-2xl',
    };
  })();

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      aria-hidden="true"
    >
      {/* 1. Outer Atmospheric Corona Halo */}
      <div
        className={`absolute rounded-full bg-gradient-to-tr ${theme.halo} ${theme.haloBlur} pointer-events-none transition-all duration-500 ease-out ${
          isModal ? '-inset-10' : '-inset-4'
        } ${isHovered ? 'scale-125 opacity-100' : 'scale-100 opacity-80'}`}
        style={{
          boxShadow: isHovered
            ? `0 0 45px ${theme.glowColor}`
            : `0 0 25px ${theme.glowColor}`,
        }}
      />

      {/* 2. Secondary Diffuse Luminescence Layer */}
      <div
        className={`absolute rounded-full bg-gradient-to-br ${theme.halo} blur-sm pointer-events-none transition-transform duration-700 ${
          isModal ? '-inset-4' : '-inset-1'
        } ${isHovered ? 'scale-115' : 'scale-100'}`}
      />

      {/* 3. Star Core Sphere */}
      <div
        className={`relative rounded-full overflow-hidden transition-all duration-500 ease-out shadow-2xl ${
          sizeMap[size] || sizeMap.md
        } ${coreScaleClass} ${isHovered ? 'scale-105' : ''}`}
        style={{
          boxShadow: `0 0 25px ${theme.glowColor}, inset 0 0 15px rgba(255, 255, 255, 0.6)`,
        }}
      >
        {/* Photosphere 3D Plasma Base Gradient */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle at 35% 32%, ${theme.core} 0%, ${theme.hotspot} 18%, ${theme.mantle} 48%, ${theme.edge} 75%, ${theme.limb} 100%)`,
          }}
        />

        {/* Dynamic Convective Granulation (Smooth CSS rotation) */}
        <div
          className="absolute inset-0 rounded-full opacity-60 mix-blend-color-burn animate-slow-orbit pointer-events-none"
          style={{
            background: `repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0.4) 0deg, transparent 20deg, rgba(0,0,0,0.5) 40deg)`,
          }}
        />

        {/* Secondary Convection Layer */}
        <div
          className="absolute inset-0 rounded-full opacity-50 mix-blend-overlay animate-reverse-orbit pointer-events-none"
          style={{
            background: `repeating-radial-gradient(circle at 45% 45%, transparent 0px, rgba(255,255,255,0.3) 6px, transparent 12px)`,
          }}
        />

        {/* Radiant Inner Hotspot */}
        <div className="absolute top-[22%] left-[26%] w-[38%] h-[38%] rounded-full bg-white/75 blur-[2px] animate-pulse-glow pointer-events-none" />

        {/* Rim Limb-Darkening */}
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            boxShadow: `inset 0 0 18px 4px ${theme.limb}`,
          }}
        />
      </div>

      {/* 4. Optical Diffraction Spikes (for White Dwarf, Blue Supergiants, and prominent White stars) */}
      {theme.spikes && (
        <div
          className={`absolute pointer-events-none transition-opacity duration-300 ${
            isHovered ? 'opacity-90' : 'opacity-45'
          }`}
        >
          {/* Horizontal Spike */}
          <div
            className="h-[1px] -translate-y-1/2"
            style={{
              width: isModal ? '280px' : isWhiteDwarf ? '140px' : '110px',
              background: `linear-gradient(to right, transparent, ${theme.spikeColor}, transparent)`,
            }}
          />
          {/* Vertical Spike */}
          <div
            className="w-[1px] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{
              height: isModal ? '280px' : isWhiteDwarf ? '140px' : '110px',
              background: `linear-gradient(to bottom, transparent, ${theme.spikeColor}, transparent)`,
            }}
          />
        </div>
      )}

      {/* 5. Ambient Micro Particles */}
      <div
        className={`absolute rounded-full pointer-events-none transition-opacity duration-500 ${
          isHovered ? 'opacity-100' : 'opacity-50'
        }`}
        style={{
          width: isModal ? '120%' : '140%',
          height: isModal ? '120%' : '140%',
        }}
      >
        <span
          className="absolute top-1 left-3 w-1 h-1 rounded-full animate-ping"
          style={{
            backgroundColor: theme.flareColor,
            boxShadow: `0 0 6px ${theme.flareColor}`,
            animationDuration: '3.2s',
          }}
        />
        <span
          className="absolute bottom-2 right-4 w-1.5 h-1.5 rounded-full animate-pulse"
          style={{
            backgroundColor: theme.flareColor,
            boxShadow: `0 0 8px ${theme.flareColor}`,
            animationDuration: '2.5s',
          }}
        />
      </div>
    </div>
  );
}
