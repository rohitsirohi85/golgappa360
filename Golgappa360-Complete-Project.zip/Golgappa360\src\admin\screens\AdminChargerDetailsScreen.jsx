import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import { socketService } from '../../services/socketService';
import { useAuth } from '../../context/AuthContext';
import {
  ArrowLeft,
  Zap,
  Cpu,
  Activity,
  Play,
  Square,
  Wrench,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Wifi,
  Thermometer,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export const AdminChargerDetailsScreen = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  const fetchCharger = async () => {
    try {
      setLoading(true);
      const res = await adminService.getChargerDetails(id);
      setData(res);
    } catch (err) {
      console.error('Error fetching charger details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCharger();

    socketService.connect();
    const socket = socketService.socket;
    if (socket) {
      const handleStatus = (evt) => {
        if (data?.charger?.chargerNumber === evt.chargerId) {
          setData((prev) => ({
            ...prev,
            charger: { ...prev.charger, status: evt.status },
          }));
        }
      };

      const handleUpdate = (evt) => {
        if (data?.charger?.chargerNumber === evt.chargerId) {
          setData((prev) => {
            if (!prev) return prev;
            const updatedCharger = {
              ...prev.charger,
              voltage: evt.voltage,
              current: evt.current,
              power: evt.power,
              energy: evt.energy,
              temperature: evt.temperature,
            };
            const newReading = {
              timestamp: new Date().toLocaleTimeString(),
              power: evt.power,
              voltage: evt.voltage,
              current: evt.current,
            };
            const updatedReadings = [...(prev.recentReadings || []).slice(-19), newReading];
            return {
              ...prev,
              charger: updatedCharger,
              recentReadings: updatedReadings,
            };
          });
        }
      };

      socket.on('charger:status', handleStatus);
      socket.on('charger:update', handleUpdate);

      return () => {
        socket.off('charger:status', handleStatus);
        socket.off('charger:update', handleUpdate);
      };
    }
  }, [id, data?.charger?.chargerNumber]);

  const handleControl = async (action) => {
    setActionLoading(true);
    setStatusMessage('');
    try {
      await adminService.controlCharger(id, action);
      setStatusMessage(`Command "${action}" dispatched to hardware controller.`);
      fetchCharger();
    } catch (err) {
      setStatusMessage(`Error: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout pageTitle="Charger Telemetry Detail">
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Connecting to bay sensors...</p>
        </div>
      </AdminLayout>
    );
  }

  const charger = data?.charger;
  const device = data?.device;
  const recentSessions = data?.recentSessions || [];
  const activeAlerts = data?.activeAlerts || [];
  const readings = data?.recentReadings?.map((r) => ({
    time: new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    power: r.power || 0,
    voltage: r.voltage || 230,
    current: r.current || 0,
  })) || [];

  const isCharging = charger?.status === 'charging';
  const isFault = charger?.status === 'fault';
  const isOffline = charger?.status === 'offline';

  return (
    <AdminLayout
      pageTitle={`Bay ${charger?.chargerNumber} Telemetry Console`}
      subtitle={`${charger?.stationId?.name || 'EV Station'} • Hardware & Energy Diagnostics`}
    >
      {/* Back button */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/admin/chargers"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Charger Fleet</span>
        </Link>
        <span
          className={`text-xs uppercase font-bold px-3 py-1 rounded-full ${
            isCharging
              ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
              : isFault
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              : isOffline
              ? 'bg-slate-700 text-slate-300'
              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
          }`}
        >
          {charger?.status}
        </span>
      </div>

      {statusMessage && (
        <div className="mb-6 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
          {statusMessage}
        </div>
      )}

      {/* Hero Bay Profile Card */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-black text-white">{charger?.chargerNumber}</h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {charger?.connectorType}
              </span>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {charger?.powerRating}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Station: <strong className="text-white">{charger?.stationId?.name}</strong> • {charger?.stationId?.city}
            </p>
          </div>

          {/* Remote Control Panel */}
          {isAdmin && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleControl('start')}
                disabled={actionLoading || isCharging}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-40"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start Dispense</span>
              </button>
              <button
                onClick={() => handleControl('stop')}
                disabled={actionLoading || !isCharging}
                className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/30 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-40"
              >
                <Square className="w-3.5 h-3.5" />
                <span>Emergency Stop</span>
              </button>
              <button
                onClick={() => handleControl('maintenance')}
                disabled={actionLoading}
                className="px-4 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-40"
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>Maintenance</span>
              </button>
            </div>
          )}
        </div>

        {/* Live Gauges Row */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Power Rate</span>
            <div className="text-xl font-black text-white mt-1 font-mono">{charger?.power || 0} kW</div>
            <span className="text-[10px] text-emerald-400">Current Output</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Voltage</span>
            <div className="text-xl font-black text-white mt-1 font-mono">{charger?.voltage || 0} V</div>
            <span className="text-[10px] text-slate-500">Grid Potential</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Current</span>
            <div className="text-xl font-black text-white mt-1 font-mono">{charger?.current || 0} A</div>
            <span className="text-[10px] text-slate-500">Flow Rate</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Bay Temperature</span>
            <div
              className={`text-xl font-black mt-1 font-mono ${
                (charger?.temperature || 25) > 60 ? 'text-rose-400' : 'text-white'
              }`}
            >
              {charger?.temperature || 25}°C
            </div>
            <span className="text-[10px] text-slate-500">Thermal Probe</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-center col-span-2 sm:col-span-1">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Energy</span>
            <div className="text-xl font-black text-emerald-400 mt-1 font-mono">
              {charger?.energy || 0} kWh
            </div>
            <span className="text-[10px] text-slate-500">Lifetime Dispensed</span>
          </div>
        </div>
      </div>

      {/* Live Power Waveform Chart */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Power Output Curve (kW)</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Recent Telemetry Samples</span>
        </div>

        <div className="h-64 w-full">
          {readings.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={readings}>
                <defs>
                  <linearGradient id="chargerPowerGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit=" kW" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="power"
                  stroke="#38bdf8"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#chargerPowerGrad)"
                  name="Power (kW)"
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              Awaiting live IoT telemetry samples...
            </div>
          )}
        </div>
      </div>

      {/* Device Hardware Card & Recent Sessions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Associated ESP32 Device */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Attached IoT Hardware Controller</h3>
            </div>
            <span
              className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                device?.status === 'online'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              {device?.status || 'Active'}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Microcontroller</span>
              <span className="font-mono font-bold text-white">{device?.deviceId || 'ESP32-WROOM-32D'}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Firmware Build</span>
              <span className="font-mono text-emerald-400">v3.4.0-RTOS</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">IP Address</span>
              <span className="font-mono text-slate-300">{device?.ipAddress || '192.168.1.101'}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-800">
              <span className="text-slate-400">Wi-Fi Signal (RSSI)</span>
              <div className="flex items-center gap-1.5 font-mono text-slate-300">
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span>{device?.rssi || -58} dBm (Optimal)</span>
              </div>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-slate-400">Watchdog Timeout</span>
              <span className="font-mono text-slate-300">30,000 ms</span>
            </div>
          </div>
        </div>

        {/* Recent Bay Sessions */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">Recent Charging Sessions</h3>
            <span className="text-xs text-slate-400 font-medium">History</span>
          </div>

          <div className="divide-y divide-slate-800">
            {recentSessions.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No recent sessions recorded for this bay.</p>
            ) : (
              recentSessions.map((s) => (
                <div key={s._id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-white block">{s.userId?.name || 'EV User'}</span>
                    <span className="text-[11px] text-slate-500">
                      {new Date(s.createdAt).toLocaleDateString()} • {s.duration || 45} mins
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-emerald-400 font-mono block">
                      {s.energyConsumed || 0} kWh
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">₹{s.cost || 0}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminChargerDetailsScreen;
