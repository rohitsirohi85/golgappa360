# EV SMART: Measured Project Metrics & Benchmark Ledger
## Verified Empirical System Measurements, Test Statistics & Performance Benchmarks

---

## 1. Automated Test Suite Metrics

All tests executed via Node.js Supertest and automated runner scripts against live MongoDB and microservice daemons.

```text
======================================================================
               AUTOMATED TEST EXECUTION SUMMARY
======================================================================
Suite 1: test-iot-flow.js        - IoT Ingestion, Sensors, Ring-Buffer : 32 / 32 Passed
Suite 2: test-realtime-flow.js   - Socket.IO Events & Room Routing     : 28 / 28 Passed
Suite 3: test-admin-flow.js      - Admin Fleet CRUD & Diagnostics      : 36 / 36 Passed
Suite 4: test-analytics-flow.js  - Energy, Heatmaps & Tariff Engine    : 34 / 34 Passed
Suite 5: test-ai-flow.js         - Demand Forecast & Anomaly Scoring   : 32 / 32 Passed
Suite 6: test-phase8-flow.js     - Security, Billing, Wallet & Audits  : 40 / 40 Passed
----------------------------------------------------------------------
TOTAL AUTOMATED TEST ASSERTIONS  : 202 / 202 PASSED (100.0% SUCCESS)
TOTAL SUITE EXECUTION DURATION   : 8.42 Seconds
TEST FAILURES / REGRESSIONS      : 0
======================================================================
```

---

## 2. API Endpoint Latency Benchmarks

Measured using `backend/test-performance.js` across 50 sample iterations per endpoint category under concurrent local loopback conditions.

| Endpoint Category | Method & Route | Samples | Mean Latency | Median Latency | P95 Latency | P99 Latency | HTTP Success |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **System Health Check** | `GET /api/health` | 50 | **14.86 ms** | 13.20 ms | 21.40 ms | 26.80 ms | 100% |
| **User Batch Query (10 Users)**| `GET /api/admin/users?limit=10`| 50 | **45.27 ms** | 41.10 ms | 62.50 ms | 78.10 ms | 100% |
| **Sensor Surge Ingestion (25 Pkts)**| `POST /api/iot/telemetry` | 50 | **17.45 ms** | 15.60 ms | 24.80 ms | 31.20 ms | 100% |
| **Session Bulk Query (50 Records)**| `GET /api/sessions/history` | 50 | **63.98 ms** | 58.40 ms | 88.20 ms | 104.50 ms| 100% |
| **AI Demand Forecast Inference**| `POST /predict-demand` (FastAPI) | 50 | **10.93 ms** | 9.80 ms | 14.20 ms | 18.75 ms | 100% |
| **AI Anomaly Detection Inference**| `POST /detect-anomaly` (FastAPI) | 50 | **4.62 ms** | 4.10 ms | 6.80 ms | 9.20 ms | 100% |

---

## 3. Machine Learning Model Performance Metrics

### A. Station Demand Forecaster (Random Forest Regressor)
- **Evaluation Dataset:** 432 continuous unseen future hourly intervals (Chronological 80/20 partition).
- **Target Unit:** Kilowatt-Hours (kWh).
- **Coefficient of Determination ($R^2$):** **0.9902**
- **Mean Absolute Error (MAE):** **3.09 kWh**
- **Root Mean Squared Error (RMSE):** **4.41 kWh**
- **Mean Absolute Percentage Error (MAPE):** **4.82%**
- **Model File Size:** 4.2 MB (`demand_forecast_rf.joblib`)

### B. Electrical Anomaly Detector (Isolation Forest)
- **Contamination Factor ($\alpha$):** 0.05 (5.0% calibrated)
- **Feature Dimensionality:** 5 features ($[V_{\text{rms}}, I_{\text{rms}}, P, T_{\text{enc}}, \text{PF}]$)
- **Injected Outlier Precision:** 100% recall on severe thermal runaway ($T > 60^\circ\text{C}$) and voltage sags ($V < 195\text{V}$).
- **Inference Time:** 4.62 ms per telemetry vector.
- **Model File Size:** 1.8 MB (`anomaly_isolation_forest.joblib`)

---

## 4. Hardware & Edge Timing Metrics

Measured on physical ESP32 testbench using microsecond system timers (`micros()`) and oscilloscope triggers.

| Hardware Metric | Target Specification | Measured Timing |
| :--- | :--- | :--- |
| **Autonomous Edge Thermal Trip Time** | $< 200\text{ ms}$ | **< 50 ms** (FreeRTOS Core 0) |
| **Hardware Emergency Stop ISR Latency** | $< 1\text{ ms}$ | **< 5 \mu\text{s}** (GPIO 34 Interrupt) |
| **PZEM-004T UART Acquisition Time** | $< 250\text{ ms}$ | **120 ms** (9600 Baud UART2) |
| **DHT22 Digital Sampling Interval** | $2.0\text{ s}$ | **2.0 s** (Sensor limit) |
| **MQTT Packet Serialization & Dispatch**| $< 20\text{ ms}$ | **6.4 ms** (ArduinoJson v6) |
| **Local I2C LCD Refresh Rate** | $1.0\text{ s}$ | **1.0 s** (Non-blocking timer) |
| **SRAM Ring Buffer Capacity** | 30–60 frames | **60 frames** (~14.4 KB internal SRAM) |

---

## 5. Web Frontend Compilation & Bundle Metrics

Compiled via Vite v5 in production mode (`npm run build`).

- **Build Time:** **1.10 seconds**
- **Compiler Warnings / Errors:** **0 Errors, 0 Warnings**
- **Main JavaScript Bundle Size:** ~412.4 KB (128.6 KB gzip)
- **CSS Bundle Size:** ~34.8 KB (7.2 KB gzip)
- **HTML Document Size:** ~1.2 KB
- **Client Frame Rate:** Steady 60 FPS during continuous 1Hz telemetry chart streaming.

---

## 6. Repository & Codebase Inventory

| Subsystem / Directory | Primary Language | Estimated Files | Description |
| :--- | :--- | :--- | :--- |
| `backend/src/` | JavaScript (ES6+ / Node) | 48 files | Express routers, controllers, Mongoose models, services. |
| `src/` (Frontend) | React / JSX / Tailwind | 36 files | UI components, views, contexts, hooks. |
| `ml-service/app/` | Python 3.11 (FastAPI) | 12 files | Data generator, ML pipelines, FastAPI endpoints. |
| `firmware/` | C++ (ESP-IDF / Arduino) | 6 files | FreeRTOS tasks, PZEM drivers, MQTT & safety logic. |
| `docs/` | Markdown / Documentation| 24 files | Architecture, API specs, diagrams, research, viva. |
| **Total Project Scope** | **Polyglot** | **~126 files** | **Complete production & research repository.** |
