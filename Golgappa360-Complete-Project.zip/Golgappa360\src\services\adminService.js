import { adminAnalyticsData } from "../data/analytics";
import { zeroResultSearches } from "../data/searches";
import { songs } from "../data/songs";

export const adminService = {
  async getOverviewKPIs() {
    return adminAnalyticsData.overviewCards;
  },

  async getSearchTimeline() {
    return adminAnalyticsData.searchVolumeTimeline;
  },

  async getLiveLogs() {
    return adminAnalyticsData.recentSearchesLog;
  },

  async getZeroResultSearches() {
    return [...zeroResultSearches];
  },

  async getTopCatalogSongs() {
    return [...songs].sort((a, b) => b.durationSec - a.durationSec).slice(0, 5);
  }
};
