import React, { useMemo } from 'react';
import { resolveStarFromCatalog } from '../../data/constellations';

/**
 * ConstellationDetailPanel — Scientific & cultural dossier for the active constellation
 * Features:
 * - Constellation Identity Header (Name, Title, Abbreviation, Hemisphere, Viewing Season)
 * - Educational Overview ("ABOUT [NAME]")
 * - Interactive Key Stars Selector with real spectroscopic data
 * - Active Star Telemetry Inspector with "Explore Star →" button connecting to Stars Explorer modal
 * - "STORIES WRITTEN IN THE STARS" cultural lore (clearly separated from astronomy)
 * - "WHEN CAN YOU SEE IT?" celestial visibility guide
 * - Deep Sky Treasures (nebulae & clusters)
 */
export default function ConstellationDetailPanel({
  constellation,
  selectedStar,
  onSelectStar,
  onExploreStar,
  onViewOnUniverseMap,
}) {
  // Resolve active star details against STARS_DATA
  const activeStarData = useMemo(() => {
    if (!selectedStar) {
      // Default to focal star or first star
      const focal =
        constellation.mainStars.find((s) => s.isFocal) ||
        constellation.mainStars[0];
      return resolveStarFromCatalog(focal);
    }
    return resolveStarFromCatalog(selectedStar);
  }, [selectedStar, constellation]);

  return (
    <div className="w-full flex flex-col p-6 sm:p-8 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)] space-y-6 text-left">
      {/* 1. Header Identity & Telemetry Strip */}
      <div className="border-b border-white/10 pb-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{
                backgroundColor: constellation.accentColor,
                boxShadow: `0 0 10px ${constellation.accentColor}`,
              }}
            />
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-cyan-400">
              ATLAS ENTRY // {constellation.abbreviation}
            </span>
          </div>

          <span className="text-xs font-mono text-slate-400">
            QUADRANT: <strong className="text-white">{constellation.quadrant}</strong>
          </span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mt-2">
          <h3 className="font-display text-3xl sm:text-4xl font-semibold text-white tracking-tight">
            {constellation.name}
          </h3>
          <span className="text-sm font-mono tracking-widest uppercase text-amber-300/90 font-medium">
            “{constellation.commonTitle}”
          </span>
        </div>

        {/* Quick Astronomical Specs Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-4">
          <div className="px-3 py-2 rounded-xl bg-[#020308]/60 border border-white/8">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              ABBREVIATION
            </span>
            <span className="text-xs font-mono text-white font-bold">
              {constellation.abbreviation} ({constellation.latinName})
            </span>
          </div>

          <div className="px-3 py-2 rounded-xl bg-[#020308]/60 border border-white/8">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              HEMISPHERE
            </span>
            <span className="text-xs font-mono text-cyan-300 font-semibold truncate block">
              {constellation.hemisphere}
            </span>
          </div>

          <div className="px-3 py-2 rounded-xl bg-[#020308]/60 border border-white/8 col-span-2 sm:col-span-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              BEST VIEWING
            </span>
            <span className="text-xs font-mono text-amber-300 font-semibold truncate block">
              {constellation.bestViewingSeason}
            </span>
          </div>
        </div>

        {/* Action: View on Universe Map (STELLAR 2.0 Feature) */}
        {onViewOnUniverseMap && (
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
            <span className="text-[11px] font-mono text-slate-400">
              Interactive 2D celestial map region
            </span>
            <button
              type="button"
              onClick={() => onViewOnUniverseMap(constellation.id)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 hover:border-cyan-400 text-cyan-200 text-xs font-mono font-semibold transition-all cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.25)] group"
              title={`View ${constellation.name} on the interactive Universe Map`}
            >
              <span>✨ View on Universe Map</span>
              <span className="group-hover:translate-x-0.5 transition-transform text-cyan-400">↗</span>
            </button>
          </div>
        )}
      </div>

      {/* 2. Educational Description ("ABOUT [NAME]") */}
      <div>
        <h4 className="text-xs font-mono uppercase tracking-widest text-slate-400 mb-2">
          ABOUT {constellation.name.toUpperCase()}
        </h4>
        <p className="font-sans text-sm text-slate-200/90 leading-relaxed font-normal">
          {constellation.description}
        </p>
      </div>

      {/* 3. KEY STARS Strip & Active Star Telemetry Dossier */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#020308]/60 border border-white/8 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-semibold flex items-center gap-1.5">
            <span>✦</span>
            <span>KEY STARS ({constellation.mainStars.length})</span>
          </h4>
          <span className="text-[10px] font-mono text-slate-500">
            SELECT TO INSPECT
          </span>
        </div>

        {/* Clickable Star Pills */}
        <div className="flex flex-wrap gap-2">
          {constellation.mainStars.map((star) => {
            const isSelected =
              (selectedStar?.id || constellation.mainStars[0].id) === star.id;

            return (
              <button
                key={star.id}
                type="button"
                onClick={() => onSelectStar(star)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-cyan-500/20 text-white border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:border-white/20 hover:text-white'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: star.colorHex }}
                />
                <span className="font-medium">{star.name}</span>
                <span className="text-[10px] text-slate-400">
                  (mag {star.magnitude.toFixed(1)})
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Star Telemetry Inspector */}
        {activeStarData && (
          <div className="mt-4 pt-4 border-t border-white/10 rounded-xl bg-cyan-950/15 p-4 border border-cyan-500/20">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 block">
                  SELECTED STELLAR TELEMETRY
                </span>
                <h5 className="font-display text-xl font-semibold text-white flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: activeStarData.colorHex }}
                  />
                  {activeStarData.name}
                  <span className="text-xs font-mono text-slate-400 font-normal">
                    ({activeStarData.commonName})
                  </span>
                </h5>
              </div>

              {/* "Explore Star →" Button connecting to existing Stars Explorer Modal */}
              <button
                type="button"
                onClick={() => onExploreStar && onExploreStar(activeStarData)}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-400/50 hover:border-cyan-400 text-xs font-mono font-semibold transition-all cursor-pointer shadow-sm group"
              >
                <span>Explore Star</span>
                <span className="group-hover:translate-x-0.5 transition-transform">
                  →
                </span>
              </button>
            </div>

            {/* Scientific Properties Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono">
              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  TYPE
                </span>
                <span className="text-slate-200 font-semibold">{activeStarData.type}</span>
              </div>

              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  TEMPERATURE
                </span>
                <span className="text-amber-300 font-semibold">
                  {activeStarData.temperature}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  DISTANCE
                </span>
                <span className="text-cyan-300 font-semibold">
                  {activeStarData.distance}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  SPECTRAL CLASS
                </span>
                <span className="text-slate-200 font-semibold">
                  {activeStarData.spectralClass}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  CONSTELLATION
                </span>
                <span className="text-slate-200 font-semibold">
                  {constellation.name}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#020308]/60 border border-white/5">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                  APPARENT MAGNITUDE
                </span>
                <span className="text-white font-semibold">
                  {activeStarData.magnitude}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. STORIES WRITTEN IN THE STARS (Mythology clearly separated from science) */}
      <div className="p-4 sm:p-5 rounded-2xl bg-amber-950/15 border border-amber-500/20">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-amber-400 text-sm">📜</span>
          <span className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold">
            STORIES WRITTEN IN THE STARS // CULTURAL MYTHOLOGY
          </span>
          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-200 border border-amber-500/30 hidden sm:inline-block">
            NON-SCIENTIFIC LORE
          </span>
        </div>
        <p className="font-sans text-xs sm:text-sm text-slate-300 leading-relaxed italic">
          &ldquo;{constellation.mythology}&rdquo;
        </p>
      </div>

      {/* 5. WHEN CAN YOU SEE IT? Visibility & Seasonal Guide */}
      <div className="p-4 sm:p-5 rounded-2xl bg-indigo-950/20 border border-indigo-500/20">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-indigo-400 text-sm">🔭</span>
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-300 font-bold">
            WHEN CAN YOU SEE IT? // OBSERVATIONAL GUIDE
          </span>
        </div>
        <p className="font-sans text-xs sm:text-sm text-slate-200 leading-relaxed">
          {constellation.visibilityNotes}
        </p>
      </div>

      {/* 6. Notable Deep Sky Objects in Constellation */}
      {constellation.notableObjects && constellation.notableObjects.length > 0 && (
        <div className="pt-2">
          <h4 className="text-xs font-mono uppercase tracking-widest text-slate-400 mb-3">
            NOTABLE DEEP SKY TREASURES
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {constellation.notableObjects.map((obj, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-black/40 border border-white/5 hover:border-white/15 transition-all text-left"
              >
                <span className="font-display text-xs font-bold text-white block">
                  {obj.name}
                </span>
                <span className="text-[10px] font-mono text-cyan-400 block mt-0.5">
                  {obj.type}
                </span>
                <span className="text-[10px] text-slate-400 block mt-1 leading-snug">
                  {obj.note}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
