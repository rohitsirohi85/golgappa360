import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  Database,
  ExternalLink,
  Table,
  Layers,
  Calendar,
  Filter,
  Code,
  BookOpen,
  Sparkles,
  Terminal,
  BarChart3,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  PieChart,
  Boxes,
  HelpCircle
} from 'lucide-react';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard, GlassPanel } from '../components/glass/GlassCard';
import { Badge } from '../components/common/Badge';

export function ReportsPage() {
  const { reportsData, dateRange } = useGolgappa();

  const [copiedQueryId, setCopiedQueryId] = useState(null);
  const [copiedFieldId, setCopiedFieldId] = useState(null);
  const [selectedSqlCategory, setSelectedSqlCategory] = useState('All');
  const [exportStartDate, setExportStartDate] = useState('2026-05-01');
  const [exportEndDate, setExportEndDate] = useState('2026-10-29');
  const [selectedDatasetToFilter, setSelectedDatasetToFilter] = useState('sales');
  const [activeTableauTab, setActiveTableauTab] = useState('exports');

  // Phase 4: Verified Tableau BI Datasets
  const tableauDatasets = [
    {
      id: 'tableau_sales',
      filename: 'tableau_sales.csv',
      name: 'Tableau Sales Transactions Fact',
      records: 31938,
      columns: 21,
      size: '5.57 MB',
      role: 'Primary Fact Table',
      primaryKey: 'sale_id',
      foreignKey: 'product_id',
      tagColor: 'text-[#A7D78A] bg-[#A7D78A]/15 border-[#A7D78A]/30',
      description: 'Order-level sales grain with gross sales, discounts, net revenue, BOM COGS, and gross profits pre-calculated per plate.'
    },
    {
      id: 'tableau_products',
      filename: 'tableau_products.csv',
      name: 'Tableau Menu Products Master',
      records: 5,
      columns: 10,
      size: '0.9 KB',
      role: 'Dimension Catalog',
      primaryKey: 'product_id',
      foreignKey: 'None',
      tagColor: 'text-[#EAB64B] bg-[#EAB64B]/15 border-[#EAB64B]/30',
      description: 'Golgappa product catalog: categories, selling prices, BOM costs, portion specs, and sensory spice profiles.'
    },
    {
      id: 'tableau_inventory',
      filename: 'tableau_inventory.csv',
      name: 'Tableau Inventory Movements & Waste',
      records: 2391,
      columns: 13,
      size: '314 KB',
      role: 'Operational Fact Table',
      primaryKey: 'transaction_id',
      foreignKey: 'ingredient_id',
      tagColor: 'text-[#D98768] bg-[#D98768]/15 border-[#D98768]/30',
      description: 'Ledger tracking batch PURCHASES, daily CONSUMPTION, and recorded food WASTAGE with extended costs.'
    },
    {
      id: 'tableau_daily_summary',
      filename: 'tableau_daily_summary.csv',
      name: 'Tableau Daily Financial Summary',
      records: 182,
      columns: 17,
      size: '21 KB',
      role: 'Aggregated P&L Fact',
      primaryKey: 'sale_date',
      foreignKey: 'None',
      tagColor: 'text-[#7BC0C0] bg-[#7BC0C0]/15 border-[#7BC0C0]/30',
      description: '182-day aggregated performance: Net Revenue, COGS, Gross Profit, Daily Waste Cost, Overheads, and Operating Profit.'
    },
    {
      id: 'tableau_expenses',
      filename: 'tableau_expenses.csv',
      name: 'Tableau Operating Overheads Ledger',
      records: 845,
      columns: 7,
      size: '69 KB',
      role: 'Overhead Fact Table',
      primaryKey: 'expense_id',
      foreignKey: 'expense_date',
      tagColor: 'text-[#A594F9] bg-[#A594F9]/15 border-[#A594F9]/30',
      description: 'Overhead expense vouchers: Stall rent, packaging donas, electric utilities, LPG gas cylinders, and sanitation fees.'
    },
    {
      id: 'tableau_data_dictionary',
      filename: 'tableau_data_dictionary.csv',
      name: 'Tableau BI Data Dictionary',
      records: 54,
      columns: 8,
      size: '7.8 KB',
      role: 'Semantic Metadata',
      primaryKey: 'field_name',
      foreignKey: 'dataset_name',
      tagColor: 'text-[#F5F4F1] bg-white/[0.08] border-white/15',
      description: 'Complete data dictionary specifying data types, Tableau roles (Dimension/Measure), default aggregations, and business definitions.'
    }
  ];

  // Calculated Fields Reference
  const calculatedFields = [
    {
      id: 'CF-01',
      name: 'Net Revenue',
      formula: 'SUM([Gross Sales]) - SUM([Discount])',
      source: 'tableau_sales',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Net collected turnover after deducting all promotional discounts. Baseline: ₹1,759,965.00.'
    },
    {
      id: 'CF-02',
      name: 'Total Plates Sold',
      formula: 'SUM([Quantity Plates])',
      source: 'tableau_sales',
      format: 'Number (#,##0)',
      purpose: 'Total portion volume served across all menu varieties. Baseline: 47,658 plates.'
    },
    {
      id: 'CF-03',
      name: 'Cost of Goods Sold (COGS)',
      formula: 'SUM([Cogs])',
      source: 'tableau_sales',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Raw material standard BOM ingredient cost for plates served. Baseline: ₹492,957.90.'
    },
    {
      id: 'CF-04',
      name: 'Gross Profit',
      formula: '[Net Revenue] - [Total COGS]',
      source: 'tableau_sales',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Gross contribution margin before stall overhead expenses. Baseline: ₹1,267,007.10.'
    },
    {
      id: 'CF-05',
      name: 'Gross Margin %',
      formula: 'IF [Net Revenue] = 0 THEN 0 ELSE [Gross Profit] / [Net Revenue] END',
      source: 'tableau_sales',
      format: 'Percentage (0.0%)',
      purpose: 'Gross profit percentage efficiency. Baseline: 71.99% (72.0%).'
    },
    {
      id: 'CF-06',
      name: 'Average Selling Price (ASP)',
      formula: 'IF [Total Plates Sold] = 0 THEN 0 ELSE [Net Revenue] / [Total Plates Sold] END',
      source: 'tableau_sales',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Average realized revenue collected per plate served. Baseline: ₹36.93.'
    },
    {
      id: 'CF-07',
      name: 'Food Waste Cost',
      formula: "SUM(IF [Transaction Type] = 'WASTE' THEN [Extended Cost] ELSE 0 END)",
      source: 'tableau_inventory',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Total value of spoiled, sour, or crushed ingredients. Baseline: ₹11,626.98.'
    },
    {
      id: 'CF-08',
      name: 'Estimated Operating Profit',
      formula: '[Gross Profit] - SUM([Operating Expenses])',
      source: 'tableau_daily_summary',
      format: 'Currency (₹ #,##0.00)',
      purpose: 'Bottom-line stall income retained by owner after all overheads. Baseline: ₹1,140,467.04 (64.80%).'
    }
  ];

  // Default SQL Queries
  const sqlQueries = reportsData?.sqlQueries || [
    {
      id: 'Q01',
      title: 'Executive Sales & Profit Margin KPI Summary',
      category: 'Executive & Financial',
      description: 'Computes overall revenue, COGS, gross profit, waste deduction, and net margin across operational history.',
      sql: `SELECT 
    COUNT(DISTINCT s.sale_datetime) AS total_operational_days,
    COUNT(s.sale_id) AS total_order_count,
    SUM(si.quantity_plates) AS total_plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS total_net_revenue,
    ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS total_cogs,
    ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS gross_profit,
    ROUND((((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) / (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount))) * 100, 2) AS gross_margin_pct
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
JOIN products p ON si.product_id = p.product_id;`
    },
    {
      id: 'Q02',
      title: 'Menu Variety Margin & Volume Ranking',
      category: 'Product & Menu',
      description: 'Ranks each golgappa variety by gross margin contribution, quantity sold, and revenue share.',
      sql: `SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.selling_price,
    p.ingredient_cost_per_plate,
    ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_contribution_margin,
    ROUND(((p.selling_price - p.ingredient_cost_per_plate) / p.selling_price) * 100, 1) AS margin_percentage,
    SUM(si.quantity_plates) AS total_plates_sold,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS total_revenue_generated,
    DENSE_RANK() OVER (ORDER BY SUM(si.quantity_plates * si.unit_price) DESC) AS revenue_rank
FROM products p
JOIN sale_items si ON p.product_id = si.product_id
JOIN sales s ON si.sale_id = s.sale_id
GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate
ORDER BY total_revenue_generated DESC;`
    },
    {
      id: 'Q03',
      title: 'Hourly Peak Footfall & Commuter Rush Pattern',
      category: 'Operations & Staffing',
      description: 'Buckets orders into hourly intervals to highlight 5 PM - 8 PM surge periods for prep scheduling.',
      sql: `SELECT 
    HOUR(s.sale_datetime) AS sale_hour,
    CONCAT(HOUR(s.sale_datetime), ':00 - ', HOUR(s.sale_datetime) + 1, ':00') AS time_window,
    COUNT(DISTINCT s.sale_id) AS total_orders,
    SUM(si.quantity_plates) AS total_plates_served,
    ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS revenue_collected
FROM sales s
JOIN sale_items si ON s.sale_id = si.sale_id
GROUP BY HOUR(s.sale_datetime)
ORDER BY total_plates_served DESC;`
    },
    {
      id: 'Q04',
      title: 'Ingredient Shrinkage & Food Waste Ratio (CTE)',
      category: 'Waste & Cost Control',
      description: 'Uses a Common Table Expression to audit raw material loss percentages and financial shrinkage.',
      sql: `WITH WasteAgg AS (
    SELECT 
        ingredient_id,
        SUM(quantity) AS total_wasted_units
    FROM inventory_transactions
    WHERE transaction_type = 'WASTE'
    GROUP BY ingredient_id
)
SELECT 
    i.ingredient_name,
    i.unit,
    i.unit_cost,
    ROUND(COALESCE(w.total_wasted_units, 0), 2) AS total_wasted_units,
    ROUND(COALESCE(w.total_wasted_units, 0) * i.unit_cost, 2) AS total_waste_financial_impact_inr
FROM ingredients i
LEFT JOIN WasteAgg w ON i.ingredient_id = w.ingredient_id
ORDER BY total_waste_financial_impact_inr DESC;`
    },
    {
      id: 'Q05',
      title: 'Digital Payments Shift (UPI vs Cash Adoption)',
      category: 'Executive & Financial',
      description: 'Analyzes digital QR code adoption versus cash flow liquidity.',
      sql: `SELECT 
    payment_method,
    COUNT(sale_id) AS transaction_count,
    ROUND((COUNT(sale_id) / (SELECT COUNT(*) FROM sales)) * 100, 2) AS volume_share_pct,
    ROUND(SUM(discount), 2) AS discounts_applied
FROM sales
GROUP BY payment_method
ORDER BY transaction_count DESC;`
    },
    {
      id: 'Q06',
      title: '7-Day Rolling Moving Average (Window Function)',
      category: 'Forecasting & BI',
      description: 'Calculates 7-day rolling sales trends to eliminate weekend volatility.',
      sql: `WITH DailySales AS (
    SELECT 
        DATE(s.sale_datetime) AS order_date,
        SUM((si.quantity_plates * si.unit_price) - s.discount) AS daily_revenue
    FROM sales s
    JOIN sale_items si ON s.sale_id = si.sale_id
    GROUP BY DATE(s.sale_datetime)
)
SELECT 
    order_date,
    daily_revenue,
    ROUND(AVG(daily_revenue) OVER (
        ORDER BY order_date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_7day_avg_revenue
FROM DailySales
ORDER BY order_date;`
    }
  ];

  const handleCopy = (id, text, isField = false) => {
    navigator.clipboard.writeText(text);
    if (isField) {
      setCopiedFieldId(id);
      setTimeout(() => setCopiedFieldId(null), 2000);
    } else {
      setCopiedQueryId(id);
      setTimeout(() => setCopiedQueryId(null), 2000);
    }
  };

  const handleDownloadTableauCSV = (filename) => {
    const cleanName = filename.endsWith('.csv') ? filename : `${filename}.csv`;
    const url = `/api/reports/export/tableau/${cleanName}`;
    window.open(url, '_blank');
  };

  const handleDownloadAllTableau = () => {
    tableauDatasets.forEach((ds, idx) => {
      setTimeout(() => {
        handleDownloadTableauCSV(ds.filename);
      }, idx * 400);
    });
  };

  const handleDownloadStandardCSV = (datasetId) => {
    const url = `/api/reports/export/${datasetId}`;
    window.open(url, '_blank');
  };

  const handleFilteredDownload = () => {
    const url = `/api/reports/export/${selectedDatasetToFilter}?startDate=${exportStartDate}&endDate=${exportEndDate}`;
    window.open(url, '_blank');
  };

  const categories = ['All', 'Executive & Financial', 'Product & Menu', 'Operations & Staffing', 'Waste & Cost Control', 'Forecasting & BI'];
  const filteredQueries = sqlQueries.filter(q => selectedSqlCategory === 'All' || q.category === selectedSqlCategory);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="pb-3 border-b border-white/[0.08] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F4F1] font-sans">
              Reports & BI Analytics Hub
            </h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#A7D78A]/20 text-[#A7D78A] border border-[#A7D78A]/30">
              Phase 4 Tableau Verified
            </span>
          </div>
          <p className="text-xs text-[#929195] mt-1">
            Tableau Desktop/Public integration, Excel Pivot models, calculated fields reference, and reconciled CSV exports
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-xs">
            <ShieldCheck className="w-4 h-4 text-[#A7D78A]" />
            <span className="text-[#F5F4F1] font-medium">Reconciliation:</span>
            <span className="text-[#A7D78A] font-bold">100% Zero Variance</span>
          </div>
        </div>
      </div>

      {/* SECTION: TABLEAU BUSINESS INTELLIGENCE SUITE */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#EAB64B]" />
              Tableau BI Integration Suite & Exports
            </h3>
            <p className="text-xs text-[#929195]">
              Six star-schema RFC 4180 datasets certified for Tableau Desktop, Tableau Public, and Power BI
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllTableau}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#EAB64B] hover:bg-[#D4A33E] text-[#171717] text-xs font-bold transition-all cursor-pointer shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download All 6 Datasets</span>
            </button>
          </div>
        </div>

        {/* Tableau Navigation Tabs */}
        <div className="flex items-center gap-1.5 border-b border-white/10 pb-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'exports', label: 'Tableau CSV Datasets', icon: FileSpreadsheet },
            { id: 'model', label: 'Data Model & Relationships', icon: Layers },
            { id: 'calculated_fields', label: 'Calculated Fields (8)', icon: Code },
            { id: 'dashboards', label: 'Dashboard Build Guide', icon: BarChart3 },
            { id: 'excel', label: 'Excel Pivot Workflow', icon: Table },
            { id: 'audit', label: 'Reconciliation Audit', icon: ShieldCheck }
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTableauTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTableauTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  active
                    ? 'bg-white/20 text-[#F5F4F1] border border-white/25 shadow-xs'
                    : 'bg-white/[0.04] text-[#929195] hover:text-[#F5F4F1] border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${active ? 'text-[#A7D78A]' : 'text-[#929195]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: TABLEAU EXPORT CARDS */}
        {activeTableauTab === 'exports' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tableauDatasets.map((ds) => (
              <GlassCard
                key={ds.id}
                className="p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded border ${ds.tagColor}`}>
                      {ds.role}
                    </span>
                    <span className="text-xs font-semibold text-[#929195]">
                      {ds.records.toLocaleString()} rows • {ds.columns} cols
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-[#F5F4F1] tracking-tight">{ds.name}</h4>
                  <p className="text-xs text-[#B8B7B9] mt-1.5 leading-relaxed">{ds.description}</p>
                  
                  <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-[#929195] pt-2 border-t border-white/[0.06]">
                    <span>PK: {ds.primaryKey}</span>
                    <span>{ds.size}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#A7D78A] truncate max-w-[140px]">
                    {ds.filename}
                  </span>
                  <button
                    onClick={() => handleDownloadTableauCSV(ds.filename)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.10] hover:bg-white/[0.18] text-[#F5F4F1] border border-white/15 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5 text-[#A7D78A]" />
                    <span>Download CSV</span>
                  </button>
                </div>
              </GlassCard>
            ))}
          </div>
        )}

        {/* TAB 2: DATA MODEL & RELATIONSHIPS */}
        {activeTableauTab === 'model' && (
          <GlassCard className="p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#F5F4F1] flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#A7D78A]" />
                  Tableau Logical Data Model (The "Noodle" Architecture)
                </h4>
                <p className="text-xs text-[#929195] mt-0.5">
                  Connect using Tableau Relationships instead of physical joins to prevent the 76-million row Cartesian explosion
                </p>
              </div>
              <span className="text-xs font-mono text-[#A7D78A] bg-[#A7D78A]/15 px-2.5 py-1 rounded-lg border border-[#A7D78A]/25">
                Tableau 2020.2+ Compatible
              </span>
            </div>

            <div className="p-4 bg-black/50 rounded-2xl border border-white/10 font-mono text-xs text-[#E0E8E3] leading-relaxed overflow-x-auto">
              <pre>{`[tableau_sales.csv]  (Primary Fact: 31,938 rows)
      │
      ├── [Relationship: Many-to-One on product_id] ────────> [tableau_products.csv] (5 varieties)
      │
      ├── [Relationship: Date-grain on sale_date] ──────────> [tableau_daily_summary.csv] (182 days)
      │                                                              │
      │                                                              ├── [Date on expense_date] ───> [tableau_expenses.csv] (845 vouchers)
      │                                                              │
      │                                                              └── [Date on transaction_date] > [tableau_inventory.csv] (2,391 txs)`}</pre>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-white/[0.04] rounded-xl border border-white/10 space-y-2">
                <span className="font-bold text-[#A7D78A] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Recommended Tableau Workflow
                </span>
                <p className="text-[#B8B7B9] leading-relaxed">
                  Drag <code>tableau_sales.csv</code> first to form the primary logical table. Drag <code>tableau_products.csv</code> next to establish a Many:1 relationship on <code>[product_id]</code>. This keeps transactions at their native line-item grain with zero duplicate rows.
                </p>
              </div>

              <div className="p-4 bg-white/[0.04] rounded-xl border border-[#D98768]/30 space-y-2">
                <span className="font-bold text-[#D98768] flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" /> Why Avoid Blind Physical Joins (Fan Trap)
                </span>
                <p className="text-[#B8B7B9] leading-relaxed">
                  Joining <code>tableau_sales</code> (31,938 orders) with <code>tableau_inventory</code> (2,391 stock movements) on date causes a Cartesian product of over 76 million rows, artificially inflating net revenue by 14× and crashing memory.
                </p>
              </div>
            </div>
          </GlassCard>
        )}

        {/* TAB 3: CALCULATED FIELDS */}
        {activeTableauTab === 'calculated_fields' && (
          <GlassCard className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#F5F4F1] flex items-center gap-2">
                  <Code className="w-4 h-4 text-[#A7D78A]" />
                  Master Tableau Calculated Fields (Copy & Paste Ready)
                </h4>
                <p className="text-xs text-[#929195] mt-0.5">
                  Formulas calibrated to match official accounting definitions without aggregate mismatch errors
                </p>
              </div>
              <span className="text-xs font-semibold text-[#929195]">8 Core Calculations</span>
            </div>

            <div className="space-y-3">
              {calculatedFields.map((cf) => (
                <div
                  key={cf.id}
                  className="p-3.5 bg-white/[0.03] rounded-xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded border border-[#A7D78A]/25">
                        {cf.id}
                      </span>
                      <span className="text-xs font-bold text-[#F5F4F1]">{cf.name}</span>
                      <span className="text-[10px] font-mono text-[#929195] px-1.5 py-0.5 rounded bg-white/[0.05]">
                        {cf.format}
                      </span>
                    </div>
                    <div className="p-2 bg-black/60 rounded-lg border border-white/5 font-mono text-xs text-[#EAB64B]">
                      <code>{cf.formula}</code>
                    </div>
                    <p className="text-[11px] text-[#929195]">{cf.purpose}</p>
                  </div>

                  <button
                    onClick={() => handleCopy(cf.id, cf.formula, true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] text-[#F5F4F1] text-xs font-semibold border border-white/12 transition-all cursor-pointer shrink-0 self-start sm:self-auto"
                  >
                    {copiedFieldId === cf.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#A7D78A]" />
                        <span className="text-[#A7D78A]">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-[#B8B7B9]" />
                        <span>Copy Formula</span>
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </GlassCard>
        )}

        {/* TAB 4: DASHBOARD BUILD GUIDE */}
        {activeTableauTab === 'dashboards' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassCard className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[#A7D78A] bg-[#A7D78A]/15 px-2.5 py-0.5 rounded-full border border-[#A7D78A]/25">
                  Dashboard 1
                </span>
                <span className="text-xs text-[#929195]">Owner Executive Pulse</span>
              </div>
              <h4 className="text-sm font-bold text-[#F5F4F1]">Business Overview Dashboard</h4>
              <p className="text-xs text-[#B8B7B9] leading-relaxed">
                Features 5 scorecards (₹1.76M Revenue, 47,658 Plates, ₹1.27M Profit, 72.0% Margin, ₹55.11 AOV), daily dual-axis area chart with 7-day moving average, weekday bar chart, and UPI vs Cash donut.
              </p>
              <div className="text-[11px] text-[#A7D78A] font-mono bg-white/[0.03] p-2.5 rounded-lg border border-white/5">
                Primary Sheet: tableau_sales.csv + tableau_products.csv
              </div>
            </GlassCard>

            <GlassCard className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[#EAB64B] bg-[#EAB64B]/15 px-2.5 py-0.5 rounded-full border border-[#EAB64B]/25">
                  Dashboard 2
                </span>
                <span className="text-xs text-[#929195]">Rush Hours & Elasticity</span>
              </div>
              <h4 className="text-sm font-bold text-[#F5F4F1]">Sales & Footfall Analytics</h4>
              <p className="text-xs text-[#B8B7B9] leading-relaxed">
                Highlights the 6 PM – 8 PM commuter footfall surge with an 8-hour heatmap matrix, product volume versus revenue scatter plot, and a dynamic Granularity Parameter (Daily / Weekly / Monthly).
              </p>
              <div className="text-[11px] text-[#EAB64B] font-mono bg-white/[0.03] p-2.5 rounded-lg border border-white/5">
                Key Visual: [Sale Hour] vs [Day of Week] Heatmap Matrix
              </div>
            </GlassCard>

            <GlassCard className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[#D98768] bg-[#D98768]/15 px-2.5 py-0.5 rounded-full border border-[#D98768]/25">
                  Dashboard 3
                </span>
                <span className="text-xs text-[#929195]">Kitchen Operations & Waste</span>
              </div>
              <h4 className="text-sm font-bold text-[#F5F4F1]">Inventory Runway & Waste Audit</h4>
              <p className="text-xs text-[#B8B7B9] leading-relaxed">
                Monitors on-hand stock balances against reorder thresholds (Critical / Low / Healthy), food waste financial losses (₹11,626.98 total), and daily shrinkage ratios for Suji Puris and Mint Pani.
              </p>
              <div className="text-[11px] text-[#D98768] font-mono bg-white/[0.03] p-2.5 rounded-lg border border-white/5">
                Key Visual: Ingredient Runway Bullet Chart + Shrinkage Bar
              </div>
            </GlassCard>

            <GlassCard className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[#7BC0C0] bg-[#7BC0C0]/15 px-2.5 py-0.5 rounded-full border border-[#7BC0C0]/25">
                  Dashboard 4
                </span>
                <span className="text-xs text-[#929195]">Financial Viability & P&L</span>
              </div>
              <h4 className="text-sm font-bold text-[#F5F4F1]">Expenses & Operating Profitability</h4>
              <p className="text-xs text-[#B8B7B9] leading-relaxed">
                Audits stall bottom-line viability: distinguishes Gross Profit (₹1,267,007) from Operating Profit (₹1,140,467) after ₹126,540 in stall rent, gas, ice, packaging, and freight vouchers.
              </p>
              <div className="text-[11px] text-[#7BC0C0] font-mono bg-white/[0.03] p-2.5 rounded-lg border border-white/5">
                Key Visual: Monthly P&L Waterfall + Dual-Axis Margin Trend
              </div>
            </GlassCard>
          </div>
        )}

        {/* TAB 5: EXCEL PIVOT WORKFLOW */}
        {activeTableauTab === 'excel' && (
          <GlassCard className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#F5F4F1] flex items-center gap-2">
                  <Table className="w-4 h-4 text-[#A7D78A]" />
                  Microsoft Excel Analysis & Cross-Check Workflow
                </h4>
                <p className="text-xs text-[#929195] mt-0.5">
                  How to open CSVs via Power Query, build Pivot Tables, and verify financial totals using SUMIFS
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
              <div className="p-4 bg-white/[0.03] rounded-xl border border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#A7D78A]">1. Import with Power Query</span>
                <p className="text-[11px] text-[#B8B7B9] leading-relaxed">
                  Go to <strong>Data &gt; From Text/CSV</strong>, select <code>tableau_sales.csv</code>, and ensure encoding is <strong>65001: UTF-8</strong>. Click <strong>Load</strong> to avoid auto-formatting errors.
                </p>
              </div>

              <div className="p-4 bg-white/[0.03] rounded-xl border border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#EAB64B]">2. Create Analytical Pivot</span>
                <p className="text-[11px] text-[#B8B7B9] leading-relaxed">
                  Insert a Pivot Table with <code>product_name</code> in Rows, <code>sale_date</code> grouped by Month in Columns, and <code>net_revenue</code> &amp; <code>gross_profit</code> in Values.
                </p>
              </div>

              <div className="p-4 bg-white/[0.03] rounded-xl border border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#D98768]">3. Reconcile with SUMIFS</span>
                <p className="text-[11px] text-[#B8B7B9] leading-relaxed font-mono">
                  =SUMIFS(tableau_sales[net_revenue], tableau_sales[product_name], "Classic Golgappa")
                </p>
              </div>
            </div>
          </GlassCard>
        )}

        {/* TAB 6: RECONCILIATION AUDIT */}
        {activeTableauTab === 'audit' && (
          <GlassCard className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#F5F4F1] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#A7D78A]" />
                  Automated Reconciliation Matrix (15/15 Passed)
                </h4>
                <p className="text-xs text-[#929195] mt-0.5">
                  Direct parity check between underlying synthetic database, application layer, and Tableau CSV files
                </p>
              </div>
              <span className="text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-3 py-1 rounded-full border border-[#A7D78A]/30">
                Variance: ₹0.00
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-white/10 text-[#929195] font-semibold">
                    <th className="pb-2">Audit Metric</th>
                    <th className="pb-2">Source Baseline</th>
                    <th className="pb-2">Tableau CSV Export</th>
                    <th className="pb-2">Variance</th>
                    <th className="pb-2 text-right">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {[
                    { m: 'Sales Orders Count', s: '31,938', e: '31,938', v: '0' },
                    { m: 'Total Plates Sold', s: '47,658', e: '47,658', v: '0' },
                    { m: 'Gross Sales Turnover', s: '₹1,765,505.00', e: '₹1,765,505.00', v: '₹0.00' },
                    { m: 'Promotional Discounts', s: '₹5,540.00', e: '₹5,540.00', v: '₹0.00' },
                    { m: 'Net Revenue', s: '₹1,759,965.00', e: '₹1,759,965.00', v: '₹0.00' },
                    { m: 'Cost of Goods Sold (COGS)', s: '₹492,957.90', e: '₹492,957.90', v: '₹0.00' },
                    { m: 'Gross Profit', s: '₹1,267,007.10', e: '₹1,267,007.10', v: '₹0.00' },
                    { m: 'Gross Margin %', s: '71.99%', e: '71.99%', v: '0.00%' },
                    { m: 'Operating Expenses', s: '₹126,540.06', e: '₹126,540.06', v: '₹0.00' },
                    { m: 'Food Waste Cost', s: '₹11,626.98', e: '₹11,626.98', v: '₹0.00' },
                    { m: 'Estimated Operating Profit', s: '₹1,140,467.04', e: '₹1,140,467.04', v: '₹0.00' },
                    { m: 'Operating Margin %', s: '64.80%', e: '64.80%', v: '0.00%' }
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-white/[0.02]">
                      <td className="py-2.5 font-sans font-medium text-[#F5F4F1]">{row.m}</td>
                      <td className="py-2.5 text-[#B8B7B9]">{row.s}</td>
                      <td className="py-2.5 text-[#A7D78A]">{row.e}</td>
                      <td className="py-2.5 text-[#929195]">{row.v}</td>
                      <td className="py-2.5 text-right">
                        <span className="text-[10px] font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded">
                          PASS
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        )}
      </div>

      {/* SECTION: CUSTOM FILTERED EXPORT TOOL */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-[#F5F4F1] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#EAB64B]" />
              Custom Date-Filtered Dataset Export
            </h3>
            <p className="text-xs text-[#929195]">Extract custom date ranges for specific audit periods</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">Select Dataset</label>
            <select
              value={selectedDatasetToFilter}
              onChange={(e) => setSelectedDatasetToFilter(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              <option value="sales">Sales Transactions (sales.csv)</option>
              <option value="inventory_transactions">Inventory Transactions (inventory_transactions.csv)</option>
              <option value="daily_expenses">Daily Operating Expenses (daily_expenses.csv)</option>
              <option value="daily_sales">Daily Sales Summary (daily_sales_summary.csv)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">Start Date</label>
            <input
              type="date"
              value={exportStartDate}
              onChange={(e) => setExportStartDate(e.target.value)}
              className="w-full p-2 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">End Date</label>
            <input
              type="date"
              value={exportEndDate}
              onChange={(e) => setExportEndDate(e.target.value)}
              className="w-full p-2 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div>
            <button
              onClick={handleFilteredDownload}
              className="w-full py-2.5 px-4 rounded-xl bg-[#EAB64B] text-[#171717] font-bold text-xs hover:bg-[#D4A33E] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>Export Filtered CSV</span>
            </button>
          </div>
        </div>
      </GlassCard>

      {/* SECTION: PRODUCTION SQL QUERY LIBRARY */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-[#A7D78A]" />
              <h3 className="text-sm font-bold text-[#F5F4F1]">
                Production SQL Query Library (MCA Project Architecture)
              </h3>
            </div>
            <p className="text-xs text-[#929195] mt-0.5">
              Production MySQL queries with CTEs, Window Functions, and aggregations for stall operations
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedSqlCategory(c)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedSqlCategory === c
                    ? 'bg-white/20 text-[#F5F4F1] border border-white/25 shadow-xs'
                    : 'bg-white/[0.05] text-[#929195] hover:text-[#F5F4F1] border border-transparent'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Queries Grid */}
        <div className="space-y-4">
          {filteredQueries.map((q) => (
            <GlassCard
              key={q.id}
              className="p-0 overflow-hidden"
            >
              <div className="px-5 py-3.5 bg-white/[0.04] border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2 py-0.5 rounded-md border border-[#A7D78A]/30">
                      {q.id}
                    </span>
                    <h4 className="text-sm font-bold text-[#F5F4F1]">{q.title}</h4>
                    <span className="text-[10px] font-semibold text-[#929195] px-2 py-0.5 rounded bg-white/[0.06] border border-white/10">
                      {q.category}
                    </span>
                  </div>
                  <p className="text-xs text-[#B8B7B9] mt-1">{q.description}</p>
                </div>

                <button
                  onClick={() => handleCopy(q.id, q.sql)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.16] text-[#F5F4F1] text-xs font-semibold border border-white/12 transition-all cursor-pointer shrink-0 self-start sm:self-auto shadow-xs"
                >
                  {copiedQueryId === q.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#A7D78A]" />
                      <span className="text-[#A7D78A]">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#B8B7B9]" />
                      <span>Copy SQL</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code display in dark glass */}
              <div className="p-4 bg-black/60 text-[#E0E8E3] overflow-x-auto font-mono text-xs leading-relaxed select-text">
                <pre>{q.sql}</pre>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
}
