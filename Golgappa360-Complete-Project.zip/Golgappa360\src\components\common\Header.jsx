import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export const Header = ({
  title,
  subtitle,
  showBack = false,
  onBack,
  rightAction,
  className = '',
}) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <div
      className={`
        sticky top-0 z-30 px-4 py-3 bg-[#070B19]/90 backdrop-blur-md
        border-b border-white/[0.06] flex items-center justify-between
        ${className}
      `}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        {showBack && (
          <button
            onClick={handleBack}
            className="p-1.5 -ml-1 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 active:scale-95 transition-all"
            aria-label="Back"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        )}
        <div className="min-w-0">
          <h1 className="text-base font-bold text-white truncate tracking-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="text-[11px] text-slate-400 truncate">{subtitle}</p>
          )}
        </div>
      </div>

      {rightAction && (
        <div className="flex items-center gap-2 shrink-0">{rightAction}</div>
      )}
    </div>
  );
};
