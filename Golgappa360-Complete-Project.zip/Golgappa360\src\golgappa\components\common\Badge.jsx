import React from 'react';

export function Badge({ children, variant = 'neutral', size = 'md', className = '' }) {
  const baseClasses = 'inline-flex items-center font-medium rounded-full transition-colors font-sans';

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-[10px]',
    md: 'px-2.5 py-1 text-xs',
    lg: 'px-3 py-1.5 text-xs font-semibold'
  };

  const variantClasses = {
    success: 'bg-[#A7D78A]/15 text-[#A7D78A] border border-[#A7D78A]/30 font-semibold',
    warning: 'bg-[#EAB64B]/15 text-[#EAB64B] border border-[#EAB64B]/30 font-semibold',
    danger: 'bg-[#E58B79]/15 text-[#E58B79] border border-[#E58B79]/30 font-semibold',
    info: 'bg-white/10 text-[#F5F4F1] border border-white/15 font-semibold',
    neutral: 'bg-white/[0.06] text-[#B8B7B9] border border-white/10',
    saffron: 'bg-[#EAB64B]/20 text-[#EAB64B] border border-[#EAB64B]/35 font-semibold',
    terracotta: 'bg-[#D98768]/18 text-[#D98768] border border-[#D98768]/30 font-semibold'
  };

  return (
    <span className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant] || variantClasses.neutral} ${className}`}>
      {children}
    </span>
  );
}
