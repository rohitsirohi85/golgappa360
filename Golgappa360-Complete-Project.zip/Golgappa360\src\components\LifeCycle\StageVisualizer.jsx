import React from 'react';

/**
 * StageVisualizer — Morphing central stellar lifecycle visualization
 * Renders distinct physical states:
 * - Molecular Cloud: Diffuse gas & dust nursery
 * - Protostar: Growing core with rotating accretion disk
 * - Main Sequence: Thermonuclear hydrostatic equilibrium
 * - Red Giant: Swollen convective orange atmosphere
 * - Supergiant: Gargantuan multi-shell fusion titan
 * - Planetary Nebula: Expanding iridescent gas envelope
 * - Supernova: Cataclysmic core-collapse explosion & shockwave
 * - White Dwarf: Compact degenerate ember with sharp spikes
 * - Neutron Star: Collapsed pulsar with rotating relativistic beams
 * - Black Hole: Event horizon surrounded by warped glowing accretion disk
 */
export default function StageVisualizer({ stage, className = '' }) {
  if (!stage) return null;

  const visualType = stage.visualType || 'main-sequence';

  return (
    <div
      className={`relative flex items-center justify-center select-none w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 ${className}`}
      aria-label={`Visual representation of ${stage.title}`}
    >
      {/* Dynamic Ambient Coronal Aura */}
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-full blur-3xl opacity-40 transition-all duration-700 pointer-events-none"
        style={{ backgroundColor: stage.colorHex }}
      />

      {/* 1. MOLECULAR CLOUD */}
      {visualType === 'nebula' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-4/5 h-4/5 rounded-full bg-gradient-to-tr from-purple-600/35 via-indigo-600/25 to-cyan-500/30 blur-2xl animate-nebula-breath" />
          <div className="absolute w-3/5 h-3/5 rounded-full bg-gradient-to-bl from-amber-500/30 via-purple-700/20 to-transparent blur-xl animate-pulse-glow" />
          {/* Gravitational dust motes */}
          <div className="absolute w-4 h-4 rounded-full bg-cyan-200 blur-[2px] shadow-[0_0_15px_#38bdf8] animate-ping" />
          <div className="absolute top-1/3 left-1/3 w-3 h-3 rounded-full bg-amber-200 blur-[1px] shadow-[0_0_12px_#fbbf24] animate-pulse" />
        </div>
      )}

      {/* 2. PROTOSTAR */}
      {visualType === 'protostar' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          {/* Tilted Accretion Disk */}
          <div
            className="absolute w-64 h-24 sm:w-80 sm:h-28 rounded-full border border-amber-400/50 rotate-[-25deg] animate-spin pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, transparent 35%, rgba(249,115,22,0.3) 70%, transparent 100%)',
              animationDuration: '14s',
            }}
          />
          {/* Infalling gas streams */}
          <div
            className="absolute w-56 h-20 sm:w-72 sm:h-24 rounded-full border border-dashed border-orange-400/40 rotate-[-25deg] pointer-events-none"
          />
          {/* Young Protostellar Core */}
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-tr from-orange-600 via-amber-400 to-yellow-100 shadow-[0_0_40px_#f97316] flex items-center justify-center animate-pulse-glow">
            <div className="w-12 h-12 rounded-full bg-white/80 blur-[2px] animate-pulse" />
          </div>
        </div>
      )}

      {/* 3. MAIN SEQUENCE */}
      {visualType === 'main-sequence' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-44 h-44 sm:w-56 sm:h-56 rounded-full bg-amber-400/25 blur-2xl animate-pulse-glow" />
          <div
            className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full overflow-hidden shadow-2xl"
            style={{
              background: 'radial-gradient(circle at 35% 32%, #ffffff 0%, #fef08a 20%, #fbbf24 50%, #d97706 80%, #78350f 100%)',
              boxShadow: '0 0 45px rgba(251, 191, 36, 0.6), inset 0 0 20px rgba(255, 255, 255, 0.8)',
            }}
          >
            {/* Convective Granulation */}
            <div
              className="absolute inset-0 rounded-full opacity-60 mix-blend-color-burn animate-slow-orbit"
              style={{
                background: 'repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0.4) 0deg, transparent 20deg, rgba(0,0,0,0.5) 40deg)',
              }}
            />
            {/* Thermonuclear Core Flash */}
            <div className="absolute top-[24%] left-[28%] w-12 h-12 rounded-full bg-white/80 blur-[2px] animate-pulse" />
          </div>
        </div>
      )}

      {/* 4. RED GIANT */}
      {visualType === 'red-giant' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-60 h-60 sm:w-72 sm:h-72 rounded-full bg-orange-600/30 blur-3xl animate-pulse-glow" />
          <div
            className="relative w-52 h-52 sm:w-64 sm:h-64 rounded-full overflow-hidden shadow-2xl"
            style={{
              background: 'radial-gradient(circle at 35% 32%, #fff7ed 0%, #fed7aa 20%, #fb923c 45%, #ea580c 75%, #7c2d12 100%)',
              boxShadow: '0 0 50px rgba(249, 115, 22, 0.55), inset 0 0 25px rgba(255, 255, 255, 0.5)',
            }}
          >
            <div
              className="absolute inset-0 rounded-full opacity-70 mix-blend-overlay animate-slow-orbit"
              style={{
                background: 'repeating-radial-gradient(circle at 45% 45%, transparent 0px, rgba(124,45,18,0.4) 10px, transparent 20px)',
              }}
            />
            <div className="absolute inset-0 rounded-full shadow-[inset_0_0_30px_rgba(69,10,10,0.9)]" />
          </div>
        </div>
      )}

      {/* 5. SUPERGIANT */}
      {visualType === 'supergiant' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full bg-rose-600/35 blur-3xl animate-pulse-glow" />
          <div
            className="relative w-56 h-56 sm:w-72 sm:h-72 rounded-full overflow-hidden shadow-2xl"
            style={{
              background: 'radial-gradient(circle at 35% 32%, #fee2e2 0%, #f87171 25%, #dc2626 55%, #991b1b 80%, #450a0a 100%)',
              boxShadow: '0 0 60px rgba(239, 68, 68, 0.65), inset 0 0 30px rgba(255, 255, 255, 0.6)',
            }}
          >
            <div
              className="absolute inset-0 rounded-full opacity-70 mix-blend-color-burn animate-reverse-orbit"
              style={{
                background: 'repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0.4) 0deg, transparent 15deg, rgba(0,0,0,0.6) 30deg)',
              }}
            />
          </div>
        </div>
      )}

      {/* 6. PLANETARY NEBULA */}
      {visualType === 'planetary-nebula' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          {/* Outer Expanding Ionized Shell */}
          <div
            className="absolute w-56 h-56 sm:w-72 sm:h-72 rounded-full border-2 border-cyan-400/40 animate-pulse-glow"
            style={{
              background: 'radial-gradient(circle at center, transparent 35%, rgba(6,182,212,0.25) 60%, rgba(99,102,241,0.35) 85%, transparent 100%)',
            }}
          />
          <div className="absolute w-44 h-44 sm:w-56 sm:h-56 rounded-full border border-indigo-400/30 animate-slow-orbit" />
          {/* Exposed White Dwarf Core */}
          <div className="relative w-8 h-8 rounded-full bg-white shadow-[0_0_25px_#38bdf8] border border-cyan-200">
            <div className="absolute -inset-4 rounded-full bg-cyan-400/30 blur-md animate-ping" style={{ animationDuration: '3s' }} />
          </div>
        </div>
      )}

      {/* 7. SUPERNOVA */}
      {visualType === 'supernova' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          {/* Expanding Shockwave Blast Wave */}
          <div className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full bg-gradient-to-tr from-rose-500/40 via-amber-400/30 to-purple-600/30 blur-2xl animate-ping" style={{ animationDuration: '3.5s' }} />
          {/* Radial Shock Rays */}
          <div className="absolute w-full h-full flex items-center justify-center animate-spin" style={{ animationDuration: '30s' }}>
            <div className="w-[120%] h-[2px] bg-gradient-to-r from-transparent via-amber-200 to-transparent" />
            <div className="h-[120%] w-[2px] bg-gradient-to-b from-transparent via-rose-300 to-transparent" />
            <div className="w-[110%] h-[1px] rotate-45 bg-gradient-to-r from-transparent via-cyan-200 to-transparent" />
            <div className="w-[110%] h-[1px] -rotate-45 bg-gradient-to-r from-transparent via-white to-transparent" />
          </div>
          {/* Detonation Core */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-white shadow-[0_0_60px_#f43f5e] flex items-center justify-center">
            <div className="w-10 h-10 rounded-full bg-yellow-200 blur-sm animate-pulse" />
          </div>
        </div>
      )}

      {/* 8. WHITE DWARF */}
      {visualType === 'white-dwarf' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-36 h-36 rounded-full bg-white/20 blur-2xl" />
          {/* Optical Diffraction Spikes */}
          <div className="absolute w-64 h-[1px] bg-gradient-to-r from-transparent via-white to-transparent" />
          <div className="absolute h-64 w-[1px] bg-gradient-to-b from-transparent via-white to-transparent" />
          {/* Compact Core */}
          <div className="relative w-12 h-12 rounded-full bg-white shadow-[0_0_35px_#ffffff,inset_0_0_10px_#bae6fd] border border-cyan-200 flex items-center justify-center">
            <div className="w-4 h-4 rounded-full bg-cyan-100 blur-[1px] animate-pulse" />
          </div>
        </div>
      )}

      {/* 9. NEUTRON STAR (PULSAR) */}
      {visualType === 'neutron-star' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          <div className="absolute w-32 h-32 rounded-full bg-indigo-500/25 blur-xl" />
          {/* Relativistic Jet Beams */}
          <div className="absolute w-full h-full flex items-center justify-center animate-spin" style={{ animationDuration: '2.5s' }}>
            <div className="w-[1px] h-[130%] bg-gradient-to-b from-transparent via-indigo-300 via-white to-transparent shadow-[0_0_10px_#818cf8]" />
            <div className="w-[10px] h-[130%] bg-gradient-to-b from-transparent via-purple-500/30 to-transparent blur-sm" />
          </div>
          {/* Tiny Ultra-Dense Core */}
          <div className="relative w-6 h-6 rounded-full bg-white shadow-[0_0_30px_#818cf8] border border-indigo-300 flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-purple-200 animate-ping" style={{ animationDuration: '1s' }} />
          </div>
        </div>
      )}

      {/* 10. BLACK HOLE */}
      {visualType === 'black-hole' && (
        <div className="relative w-full h-full flex items-center justify-center animate-in fade-in duration-500">
          {/* Warped Glowing Accretion Ring (Gravitational Lensing) */}
          <div
            className="absolute w-48 h-20 sm:w-60 sm:h-24 rounded-full border-2 border-cyan-400/60 rotate-[-15deg] shadow-[0_0_40px_#38bdf8] pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, transparent 40%, rgba(56,189,248,0.4) 75%, transparent 100%)',
            }}
          />
          <div
            className="absolute w-56 h-16 sm:w-68 sm:h-20 rounded-full border border-sky-300/40 rotate-[15deg] blur-[1px] pointer-events-none"
          />
          {/* Event Horizon (Pure Black Void with Photon Ring) */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-black shadow-[0_0_25px_#38bdf8,inset_0_0_15px_#000000] border border-cyan-400/50 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-black" />
          </div>
        </div>
      )}
    </div>
  );
}
