import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Car,
  BatteryCharging,
  Zap,
  Edit2,
  Plus,
  CheckCircle2,
  Cpu,
  ShieldCheck,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { Modal } from '../components/common/Modal';
import { BatteryIndicator } from '../components/common/BatteryIndicator';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';

export const VehicleManagementScreen = () => {
  const navigate = useNavigate();
  const { vehicle, updateVehicle } = useAuth();
  const { showToast } = useUI();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Edit form state
  const [model, setModel] = useState(vehicle?.model || 'Model 3');
  const [make, setMake] = useState(vehicle?.make || 'Tesla');
  const [batteryCapacity, setBatteryCapacity] = useState(vehicle?.batteryCapacity || 60);
  const [connector, setConnector] = useState(vehicle?.connector || 'CCS2');

  // Add form state
  const [newMake, setNewMake] = useState('');
  const [newModel, setNewModel] = useState('');
  const [newCapacity, setNewCapacity] = useState('');

  const handleSaveEdit = (e) => {
    e?.preventDefault();
    updateVehicle({
      make,
      model,
      batteryCapacity: Number(batteryCapacity),
      connector,
    });
    setIsEditModalOpen(false);
    showToast('Vehicle specifications updated successfully', 'success');
  };

  const handleSaveAdd = (e) => {
    e?.preventDefault();
    if (!newMake || !newModel) {
      showToast('Please specify vehicle brand and model', 'error');
      return;
    }
    updateVehicle({
      make: newMake,
      model: newModel,
      batteryCapacity: Number(newCapacity) || 50,
      currentBattery: 85,
      currentRange: 340,
    });
    setIsAddModalOpen(false);
    showToast(`Added ${newMake} ${newModel} to your garage`, 'success');
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header title="Vehicle Management" showBack onBack={() => navigate(-1)} />

      <div className="px-4 py-4 space-y-5">
        {/* Main Vehicle Card */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Primary Vehicle
            </span>
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Connected
            </span>
          </div>

          <Card glow className="bg-[#0D1527] border-white/10 p-5 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                  My Vehicle
                </span>
                <h2 className="text-xl font-extrabold text-white mt-0.5">
                  {vehicle?.make} {vehicle?.model}
                </h2>
                <span className="text-xs text-slate-400 font-mono">
                  Plate: {vehicle?.licensePlate || 'KA 01 EV 2026'}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-[#00F5A0]/15 text-[#00F5A0] border border-[#00F5A0]/30">
                <Car className="w-6 h-6" />
              </div>
            </div>

            {/* Visual Gauge */}
            <div className="flex items-center justify-around py-2 border-y border-white/10">
              <BatteryIndicator
                percentage={vehicle?.currentBattery || 78}
                range={vehicle?.currentRange || 312}
                size={110}
                strokeWidth={8}
                showRange={false}
              />

              <div className="space-y-1.5 text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">Current Battery:</span>
                  <span className="font-bold text-white text-base font-mono">
                    {vehicle?.currentBattery || 78}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px] block">Estimated Range:</span>
                  <span className="font-bold text-[#00F5A0] text-sm font-mono">
                    {vehicle?.currentRange || 312} km
                  </span>
                </div>
              </div>
            </div>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-xl bg-[#070B19] border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                  Battery Capacity
                </span>
                <span className="font-bold text-white font-mono text-sm mt-0.5 block">
                  {vehicle?.batteryCapacity || 60} kWh
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#070B19] border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                  Connector Standard
                </span>
                <span className="font-bold text-cyan-300 font-mono text-sm mt-0.5 block">
                  {vehicle?.connector || 'CCS2'}
                </span>
              </div>
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          <Button
            size="lg"
            variant="primary"
            fullWidth
            onClick={() => setIsEditModalOpen(true)}
            icon={Edit2}
          >
            Edit Vehicle
          </Button>

          <Button
            size="lg"
            variant="secondary"
            fullWidth
            onClick={() => setIsAddModalOpen(true)}
            icon={Plus}
          >
            Add Vehicle
          </Button>
        </div>
      </div>

      {/* Edit Vehicle Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Vehicle Details"
        subtitle="Modify specifications to adjust battery calculations."
      >
        <form onSubmit={handleSaveEdit} className="space-y-3.5">
          <Input
            label="Make / Brand"
            value={make}
            onChange={(e) => setMake(e.target.value)}
          />
          <Input
            label="Model"
            value={model}
            onChange={(e) => setModel(e.target.value)}
          />
          <Input
            label="Battery Capacity (kWh)"
            type="number"
            value={batteryCapacity}
            onChange={(e) => setBatteryCapacity(e.target.value)}
          />
          <Input
            label="Connector Type"
            value={connector}
            onChange={(e) => setConnector(e.target.value)}
          />

          <div className="flex gap-2.5 pt-3">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => setIsEditModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" fullWidth>
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>

      {/* Add Vehicle Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Vehicle"
        subtitle="Add a secondary vehicle to your EV Smart profile."
      >
        <form onSubmit={handleSaveAdd} className="space-y-3.5">
          <Input
            label="Vehicle Brand"
            placeholder="e.g. Hyundai / Tata / MG"
            value={newMake}
            onChange={(e) => setNewMake(e.target.value)}
            required
          />
          <Input
            label="Vehicle Model"
            placeholder="e.g. Ioniq 5 / Nexon EV"
            value={newModel}
            onChange={(e) => setNewModel(e.target.value)}
            required
          />
          <Input
            label="Battery Capacity (kWh)"
            type="number"
            placeholder="e.g. 50"
            value={newCapacity}
            onChange={(e) => setNewCapacity(e.target.value)}
            required
          />

          <div className="flex gap-2.5 pt-3">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => setIsAddModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" fullWidth>
              Add to Garage
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
