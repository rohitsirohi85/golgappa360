import { api } from './api';
import { MOCK_NOTIFICATIONS } from '../data/mockNotifications';

export const notificationService = {
  getNotifications: async () => {
    try {
      const res = await api.get('/notifications');
      const data = Array.isArray(res) ? res : (res?.data || []);
      if (Array.isArray(data) && data.length > 0) {
        return data.map((n) => ({
          id: n._id,
          type: n.type === 'booking' ? 'booking' : n.type === 'charging' ? 'charging_start' : n.type,
          icon: n.type === 'booking' ? 'bell' : n.type === 'charging' ? 'zap' : 'alert-triangle',
          title: n.title,
          message: n.message,
          time: new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          unread: !n.isRead,
          actionRoute: n.type === 'booking' ? '/bookings' : n.type === 'charging' ? '/live-charging' : '/notifications',
        }));
      }
      return [...MOCK_NOTIFICATIONS];
    } catch (err) {
      console.warn('Backend getNotifications fallback:', err.message);
      return [...MOCK_NOTIFICATIONS];
    }
  },

  markAsRead: async (id) => {
    try {
      if (id && id.match(/^[0-9a-fA-F]{24}$/)) {
        await api.put(`/notifications/${id}/read`);
      }
    } catch (err) {
      console.warn('Backend markAsRead fallback:', err.message);
    }
  },

  markAllRead: async () => {
    try {
      await api.put('/notifications/read-all');
    } catch (err) {
      console.warn('Backend markAllRead fallback:', err.message);
    }
  },
};
