import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/analytics', (req, res) => {
  try {
    const range = req.query.range || '30d';
    const productId = req.query.product_id || req.query.productId || 'all';
    const salesData = syntheticStore.getSalesAnalytics(range, productId);

    res.json({
      success: true,
      data: salesData
    });
  } catch (error) {
    console.error('[API /api/sales/analytics Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
