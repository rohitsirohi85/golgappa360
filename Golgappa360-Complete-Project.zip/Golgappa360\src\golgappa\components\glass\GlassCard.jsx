import React from 'react';

export function GlassCard({
  children,
  className = '',
  elevated = false,
  hoverLift = true,
  onClick,
  ...props
}) {
  return (
    <div
      onClick={onClick}
      className={`
        ${elevated ? 'glass-card-elevated' : 'glass-card'}
        ${hoverLift ? 'hover:-translate-y-0.5 hover:shadow-[0_16px_45px_rgba(0,0,0,0.28)] hover:border-white/20' : ''}
        transition-all duration-200 relative overflow-hidden
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  );
}

export function GlassPanel({ children, className = '', ...props }) {
  return (
    <div
      className={`bg-white/[0.04] backdrop-blur-xl border border-white/10 rounded-2xl p-4 transition-all duration-200 ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function GlassPill({ children, className = '', active = false, onClick, ...props }) {
  return (
    <div
      onClick={onClick}
      className={`
        glass-pill px-3 py-1.5 rounded-full inline-flex items-center gap-2 text-xs font-medium transition-all
        ${active ? 'bg-white/20 text-[#F5F4F1] border-white/30 shadow-xs' : 'text-[#B8B7B9] hover:text-[#F5F4F1] hover:bg-white/12'}
        ${onClick ? 'cursor-pointer' : ''}
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  );
}
