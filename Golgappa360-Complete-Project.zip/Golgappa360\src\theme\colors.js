export const COLORS = {
  primary: '#00F5A0',       // Electric neon green
  primaryDark: '#00C882',
  cyan: '#00E5FF',          // Electric cyan
  navyDark: '#050811',      // Deepest background
  navyBg: '#070B19',        // App background
  surface: '#0D1527',       // Navigation & bars
  card: '#131E35',          // Card backgrounds
  cardHover: '#1A2845',     // Card hover state
  border: 'rgba(255, 255, 255, 0.08)',
  borderLight: 'rgba(255, 255, 255, 0.15)',
  textPrimary: '#FFFFFF',
  textSecondary: '#94A3B8',
  textMuted: '#64748B',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',
};
