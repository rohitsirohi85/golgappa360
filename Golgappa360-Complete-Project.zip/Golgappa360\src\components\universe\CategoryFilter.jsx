import React from 'react';
import { FILTER_OPTIONS, CATEGORY_SYMBOLS } from '../../data/celestialObjects.js';

/**
 * CategoryFilter — Compact category selector bar for celestial object taxonomy
 * 
 * Supports: ALL, STARS, WHITE DWARFS, NEUTRON STARS, PULSARS, BLACK HOLES, NEBULAE, CLUSTERS, GALAXIES
 * On mobile: horizontally scrollable pills with touch drag.
 */
export default function CategoryFilter({
  activeFilter = 'ALL',
  onSelectFilter,
  className = '',
}) {
  return (
    <div
      className={`flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 px-1 select-none ${className}`}
      role="tablist"
      aria-label="Celestial object category filters"
    >
      {FILTER_OPTIONS.map((item) => {
        const isActive = activeFilter === item.id;
        const symbol = item.category ? CATEGORY_SYMBOLS[item.category] : '✦';

        return (
          <button
            key={item.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => onSelectFilter(item.id)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono tracking-wide transition-all duration-200 focus:outline-none focus-visible:ring-1 focus-visible:ring-cyan-400 active:scale-95 ${
              isActive
                ? 'bg-cyan-500/15 border border-cyan-400/60 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.2)] font-semibold'
                : 'bg-[#020308]/80 hover:bg-white/[0.06] border border-white/10 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span
              className={`text-xs ${
                isActive
                  ? 'text-cyan-300'
                  : item.id === 'BLACK_HOLES'
                  ? 'text-amber-400'
                  : item.id === 'PULSARS'
                  ? 'text-cyan-400'
                  : item.id === 'NEBULAE'
                  ? 'text-sky-300'
                  : item.id === 'GALAXIES'
                  ? 'text-indigo-300'
                  : 'text-slate-400'
              }`}
            >
              {symbol}
            </span>
            <span className="whitespace-nowrap">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}
