# EV SMART: Complete System Architecture Specification
## Multi-Tier Distributed System Architecture Diagram & Data Pathways

---

## 1. High-Level Architectural Diagram

![Final Cloud Architecture](FINAL_CLOUD_ARCHITECTURE.png)
![Cloud Deployment Diagram](CLOUD_DEPLOYMENT.png)

```mermaid
graph TD
    subgraph Presentation_Tier ["Presentation Tier (Client Applications)"]
        UI_User["Driver Mobile App (PWA)<br/>React 18 + Tailwind + Vite"]
        UI_Admin["Admin Fleet Portal<br/>React 18 + Recharts + Lucide"]
    end

    subgraph Transport_Tier ["Transport & Messaging Tier"]
        WS_GW["Real-Time Gateway<br/>Socket.IO WebSockets"]
        REST_GW["REST API Gateway<br/>Express.js HTTP (Port 5000)"]
        MQTT_Broker["Message Broker<br/>Eclipse Mosquitto MQTT (Port 1883)"]
    end

    subgraph Application_Tier ["Application & Intelligence Tier"]
        Core_Backend["Node.js / Express Core Backend<br/>Auth, Bookings, Sessions, Fleet"]
        AI_Service["Python FastAPI AI Microservice (Port 8000)<br/>Random Forest + Isolation Forest"]
    end

    subgraph Persistence_Tier ["Persistence Tier"]
        DB_Mongo[("MongoDB Enterprise Database<br/>Timeseries Telemetry, Users, Audits")]
    end

    subgraph Edge_Hardware_Tier ["Physical IoT Edge Tier (ESP32 Controller)"]
        ESP32_Core0["ESP32 Core 0: Safety & Sensors<br/>Autonomous Thermal/Current Trip (<50ms)"]
        ESP32_Core1["ESP32 Core 1: Network & Protocol<br/>MQTT Publisher + HTTP Fallback"]
        Sensors["Sensors: PZEM-004T (V,I,P,E,PF)<br/>DHT22 (Temp/Humidity)"]
        Actuators["Actuators: 30A Optocoupled Relay<br/>Mechanical E-Stop Button<br/>16x2 I2C LCD"]
    end

    %% Client Interactions
    UI_User <-->|WebSocket: telemetry_update| WS_GW
    UI_User <-->|HTTP REST: JWT Auth, Booking, Start/Stop| REST_GW
    UI_Admin <-->|WebSocket: charger_status, alerts| WS_GW
    UI_Admin <-->|HTTP REST: Fleet CRUD, Tariffs, Audits| REST_GW

    %% Gateway to Backend
    WS_GW <-->|Event Ingestion & Broadcast| Core_Backend
    REST_GW <-->|Request Routing & Middleware| Core_Backend

    %% Backend to Database & AI
    Core_Backend <-->|Mongoose ODM Queries| DB_Mongo
    Core_Backend <-->|HTTP Ingestion / Predictions| AI_Service

    %% Hardware to Transport
    Sensors -->|UART2 / 1-Wire| ESP32_Core0
    ESP32_Core0 -->|Relay Trigger / LCD| Actuators
    ESP32_Core0 <-->|FreeRTOS Queue| ESP32_Core1
    ESP32_Core1 <-->|MQTT Publish/Subscribe| MQTT_Broker
    ESP32_Core1 -.->|HTTP REST Failover| REST_GW
    MQTT_Broker <-->|mqtt.js Ingest & Command Dispatch| Core_Backend
```

---

## 2. Subsystem Interaction Matrix

| Flow | Source | Destination | Protocol | Payload Type | Description |
| :---: | :--- | :--- | :--- | :--- | :--- |
| **F1** | Sensors | ESP32 Core 0 | UART2 / GPIO | Raw Electrical & Thermal | Sampled at 1 Hz by FreeRTOS sensor task. |
| **F2** | ESP32 Core 0 | Actuators | GPIO 26 / 34 | Digital Logic Signals | Drives optocoupled relay; checks E-Stop interrupt. |
| **F3** | ESP32 Core 1 | MQTT Broker | MQTT v3.1.1 | JSON Packet | Publishes telemetry to `ev/station/+/charger/+/telemetry`. |
| **F4** | ESP32 Core 1 | REST Gateway | HTTP POST | JSON Payload | Fallback ingestion if MQTT broker is unreachable. |
| **F5** | Core Backend | DB Mongo | TCP (MongoDB) | BSON Documents | Persists users, sessions, telemetry timeseries. |
| **F6** | Core Backend | AI Microservice| HTTP POST | JSON Feature Vector | Requests 24h demand predictions & anomaly scores. |
| **F7** | Core Backend | WebSocket GW | Internal Event| Event Emits | Propagates `telemetry_update` and status transitions. |
| **F8** | WebSocket GW | Client Apps | WebSockets | Real-Time Events | Pushes live telemetry sparklines to active driver HUD. |
