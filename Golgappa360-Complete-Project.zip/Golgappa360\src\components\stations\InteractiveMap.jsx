import React, { useState } from 'react';
import { MapPin, Navigation, Zap, Compass } from 'lucide-react';

export const InteractiveMap = ({
  stations = [],
  selectedStation,
  onStationSelect,
}) => {
  const [activePin, setActivePin] = useState(selectedStation?.id || stations[0]?.id);

  const handlePinClick = (st) => {
    setActivePin(st.id);
    onStationSelect?.(st);
  };

  // Coordinates normalized to 100x100 SVG viewbox
  const pinPositions = [
    { id: 'st_01', x: 48, y: 46, name: 'Green Valley EV Hub' },
    { id: 'st_02', x: 26, y: 32, name: 'City Center EV' },
    { id: 'st_03', x: 74, y: 65, name: 'Tech Park Fast' },
    { id: 'st_04', x: 82, y: 22, name: 'EcoHub Terminal' },
  ];

  return (
    <div className="relative w-full h-56 rounded-3xl overflow-hidden border border-white/10 bg-[#0B1220] shadow-inner select-none">
      {/* SVG Stylized Dark Vector Map */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full object-cover"
        preserveAspectRatio="none"
      >
        {/* Subtle grid lines */}
        <defs>
          <pattern id="mapGrid" width="10" height="10" patternUnits="userSpaceOnUse">
            <path
              d="M 10 0 L 0 0 0 10"
              fill="none"
              stroke="rgba(255, 255, 255, 0.04)"
              strokeWidth="0.5"
            />
          </pattern>
          <linearGradient id="roadGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1E2C4A" />
            <stop offset="100%" stopColor="#152037" />
          </linearGradient>
        </defs>

        <rect width="100" height="100" fill="#0A111F" />
        <rect width="100" height="100" fill="url(#mapGrid)" />

        {/* River / Water body */}
        <path
          d="M 0,78 Q 30,85 50,70 T 100,60 L 100,75 Q 60,88 0,92 Z"
          fill="#0C2038"
          opacity="0.6"
        />

        {/* Park / Green corridor */}
        <path
          d="M 68,10 Q 85,15 90,30 L 95,20 Q 80,5 68,10 Z"
          fill="#0B2625"
          opacity="0.5"
        />

        {/* Arterial Highway network */}
        <path
          d="M 10,0 Q 30,45 60,55 T 100,85"
          fill="none"
          stroke="#1C2D4A"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
        <path
          d="M 0,35 Q 40,30 80,45 T 100,40"
          fill="none"
          stroke="#1C2D4A"
          strokeWidth="2.8"
        />
        <path
          d="M 45,0 L 50,100"
          fill="none"
          stroke="#17243C"
          strokeWidth="2"
        />
        <path
          d="M 20,80 Q 50,75 80,95"
          fill="none"
          stroke="#17243C"
          strokeWidth="1.8"
        />

        {/* User Location Pulse (Blue Beacon) */}
        <circle cx="42" cy="52" r="6" fill="#3B82F6" opacity="0.2">
          <animate
            attributeName="r"
            values="2;8;2"
            dur="2.5s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.6;0.1;0.6"
            dur="2.5s"
            repeatCount="indefinite"
          />
        </circle>
        <circle cx="42" cy="52" r="2.2" fill="#38BDF8" stroke="#ffffff" strokeWidth="0.8" />
      </svg>

      {/* Station Map Pins */}
      {pinPositions.map((pos) => {
        const station = stations.find((s) => s.id === pos.id) || {
          name: pos.name,
          availableChargers: 3,
        };
        const isActive = activePin === pos.id;

        return (
          <div
            key={pos.id}
            onClick={() => handlePinClick(station)}
            style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20"
          >
            {/* Active Radar Ripple */}
            {isActive && (
              <span className="absolute -inset-2 rounded-full bg-[#00F5A0]/20 animate-ping" />
            )}

            {/* Pin Badge */}
            <div
              className={`
                flex items-center gap-1 px-2 py-1 rounded-full border shadow-lg transition-transform duration-200
                ${
                  isActive
                    ? 'bg-[#00F5A0] text-[#050811] border-white scale-110 shadow-[0_0_15px_#00F5A0]'
                    : 'bg-[#0D1527] text-white border-white/20 hover:border-[#00F5A0] hover:scale-105'
                }
              `}
            >
              <Zap
                className={`w-3 h-3 ${isActive ? 'fill-[#050811]' : 'text-[#00F5A0]'}`}
              />
              <span className="text-[10px] font-bold">
                {station.availableChargers || 3}
              </span>
            </div>

            {/* Micro tooltip label */}
            <div
              className={`
                absolute top-full mt-1 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] px-1.5 py-0.5 rounded bg-black/85 text-white border border-white/10 pointer-events-none transition-opacity
                ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}
              `}
            >
              {station.name}
            </div>
          </div>
        );
      })}

      {/* Floating Map Controls & Overlays */}
      <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-20">
        <button
          onClick={() => setActivePin('st_01')}
          className="p-2 rounded-xl bg-[#0D1527]/90 text-slate-300 hover:text-white border border-white/10 shadow backdrop-blur-md"
          title="Recenter to My Location"
        >
          <Navigation className="w-3.5 h-3.5 text-[#00F5A0]" />
        </button>
      </div>

      <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#0D1527]/90 border border-white/10 text-[10px] text-slate-300 backdrop-blur-md z-20">
        <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
        <span>You are near Sector 5</span>
      </div>
    </div>
  );
};
