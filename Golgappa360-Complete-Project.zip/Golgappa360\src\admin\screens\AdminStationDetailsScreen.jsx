import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import { socketService } from '../../services/socketService';
import { useAuth } from '../../context/AuthContext';
import {
  ArrowLeft,
  Building2,
  MapPin,
  Zap,
  Clock,
  DollarSign,
  AlertTriangle,
  Play,
  Square,
  Wrench,
  CheckCircle2,
  ExternalLink,
  ShieldAlert,
  Power,
} from 'lucide-react';

export const AdminStationDetailsScreen = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [station, setStation] = useState(null);
  const [chargers, setChargers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  const fetchStationData = async () => {
    try {
      setLoading(true);
      const [allStations, allChargers] = await Promise.all([
        adminService.getStations(),
        adminService.getChargers('all', id),
      ]);

      const foundStation = allStations.find((s) => s._id === id);
      setStation(foundStation || null);
      if (Array.isArray(allChargers)) {
        setChargers(allChargers);
      }
    } catch (err) {
      console.error('Error fetching station details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStationData();

    socketService.connect();
    const socket = socketService.socket;
    if (socket) {
      const handleChargerStatus = (data) => {
        setChargers((prev) =>
          prev.map((c) =>
            c.chargerNumber === data.chargerId
              ? { ...c, status: data.status, isOnline: data.status !== 'offline' }
              : c
          )
        );
      };

      const handleChargerUpdate = (data) => {
        setChargers((prev) =>
          prev.map((c) =>
            c.chargerNumber === data.chargerId
              ? {
                  ...c,
                  voltage: data.voltage,
                  current: data.current,
                  power: data.power,
                  energy: data.energy,
                  temperature: data.temperature,
                }
              : c
          )
        );
      };

      socket.on('charger:status', handleChargerStatus);
      socket.on('charger:update', handleChargerUpdate);

      return () => {
        socket.off('charger:status', handleChargerStatus);
        socket.off('charger:update', handleChargerUpdate);
      };
    }
  }, [id]);

  const handleChargerControl = async (chargerId, action) => {
    setActionLoading(true);
    setStatusMessage('');
    try {
      await adminService.controlCharger(chargerId, action);
      setStatusMessage(`Command "${action}" successfully dispatched to ${chargerId}.`);
      fetchStationData();
    } catch (err) {
      setStatusMessage(`Error: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout pageTitle="Station Details">
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading station telemetry...</p>
        </div>
      </AdminLayout>
    );
  }

  if (!station) {
    return (
      <AdminLayout pageTitle="Station Not Found">
        <div className="p-8 text-center bg-slate-900 rounded-3xl border border-slate-800">
          <p className="text-slate-400 text-sm mb-4">The requested station could not be found.</p>
          <Link
            to="/admin/stations"
            className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Stations
          </Link>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout
      pageTitle={station.name}
      subtitle={`Station Profile • ${station.city} • ${station.totalChargers} Configured Bays`}
    >
      {/* Back Button & Header */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/admin/stations"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Stations</span>
        </Link>
        <span
          className={`text-xs uppercase font-bold px-3 py-1 rounded-full ${
            station.status === 'active'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
          }`}
        >
          {station.status || 'active'}
        </span>
      </div>

      {statusMessage && (
        <div className="mb-6 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
          {statusMessage}
        </div>
      )}

      {/* Station Overview Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-2">
            <h2 className="text-xl font-black text-white">{station.name}</h2>
            <p className="text-xs text-slate-400 flex items-center gap-2 mt-1.5">
              <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{station.address}, {station.city}</span>
            </p>
            <p className="text-xs text-slate-500 mt-2 font-mono">
              Coordinates: Lat {station.latitude || 12.9279}, Long {station.longitude || 77.6271}
            </p>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Base Tariff</span>
            <div className="text-2xl font-black text-white">₹{station.pricePerKwh}</div>
            <span className="text-xs text-emerald-400 font-medium">Per kilowatt-hour</span>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Operating Hours</span>
            <div className="text-sm font-bold text-white flex items-center gap-2 mt-1">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>{station.openingHours || 'Open 24/7'}</span>
            </div>
            <span className="text-xs text-slate-500 mt-2 block">CCTV & Covered Bay Active</span>
          </div>
        </div>
      </div>

      {/* Charger Bays Assigned to Station */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-bold text-white">
              Assigned Charger Bays ({chargers.length})
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-medium">
            Live real-time telemetry from station sensors
          </span>
        </div>

        {chargers.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center text-xs text-slate-500">
            No chargers registered under this station hub.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {chargers.map((ch) => {
              const isCharging = ch.status === 'charging';
              const isFault = ch.status === 'fault';
              const isOffline = ch.status === 'offline';

              return (
                <div
                  key={ch._id}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className="text-base font-extrabold text-white">{ch.chargerNumber}</span>
                        <p className="text-[11px] text-slate-400">{ch.chargerType || 'Fast Charger'} • {ch.powerRating || '60 kW'}</p>
                      </div>
                      <span
                        className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          isCharging
                            ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                            : isFault
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : isOffline
                            ? 'bg-slate-700 text-slate-300'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}
                      >
                        {ch.status}
                      </span>
                    </div>

                    {/* Sensor Telemetry */}
                    <div className="grid grid-cols-3 gap-2 bg-slate-950/60 rounded-xl p-2.5 my-3 text-center text-xs">
                      <div>
                        <span className="block text-[10px] text-slate-500 uppercase">Power</span>
                        <span className="font-mono font-bold text-white">{ch.power || 0} kW</span>
                      </div>
                      <div>
                        <span className="block text-[10px] text-slate-500 uppercase">Voltage</span>
                        <span className="font-mono font-medium text-slate-300">{ch.voltage || 0} V</span>
                      </div>
                      <div>
                        <span className="block text-[10px] text-slate-500 uppercase">Temp</span>
                        <span
                          className={`font-mono font-bold ${
                            (ch.temperature || 25) > 60 ? 'text-rose-400' : 'text-slate-300'
                          }`}
                        >
                          {ch.temperature || 25}°C
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <Link
                      to={`/admin/chargers/${ch._id}`}
                      className="text-xs text-slate-400 hover:text-white font-medium flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </Link>

                    {isAdmin && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleChargerControl(ch._id, 'start')}
                          disabled={actionLoading || isCharging}
                          title="Remote Force Start"
                          className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 disabled:opacity-40"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleChargerControl(ch._id, 'stop')}
                          disabled={actionLoading || !isCharging}
                          title="Remote Emergency Stop"
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 disabled:opacity-40"
                        >
                          <Square className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleChargerControl(ch._id, 'maintenance')}
                          disabled={actionLoading}
                          title="Set Maintenance Mode"
                          className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 disabled:opacity-40"
                        >
                          <Wrench className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminStationDetailsScreen;
