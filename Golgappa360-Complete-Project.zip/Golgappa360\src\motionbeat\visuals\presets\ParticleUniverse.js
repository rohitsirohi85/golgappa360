import * as THREE from 'three';

/**
 * Particle Universe Preset (High-Performance & High-Impact Visuals)
 * - 45k GPU-friendly particles with dynamic draw ranges for High/Balanced/Low quality
 * - Strong, clearly visible cinematic force fields (swirl vortex & pinch singularity)
 * - Proximity color illumination (particles glow neon cyan/purple near hands)
 * - 3D Holographic Hand Beacons/Nexuses floating at hand positions
 * - Zero-allocation update loop
 */
export class ParticleUniverse {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;
    this.group = new THREE.Group();
    this.particleCount = 45000;
    this.activeParticleCount = 45000;
    this.points = null;
    this.material = null;
    this.geometry = null;

    // 3D Holographic Hand Beacons (Visual representation of hands in 3D universe)
    this.handBeacon1 = null;
    this.handBeacon2 = null;

    this.init();
    this.scene.add(this.group);
  }

  init() {
    this.geometry = new THREE.BufferGeometry();

    const positions = new Float32Array(this.particleCount * 3);
    const colors = new Float32Array(this.particleCount * 3);
    const scales = new Float32Array(this.particleCount);
    const phases = new Float32Array(this.particleCount);
    const speeds = new Float32Array(this.particleCount);

    const colorA = new THREE.Color('#9333ea'); // Neon Purple
    const colorB = new THREE.Color('#2563eb'); // Electric Blue
    const colorC = new THREE.Color('#06b6d4'); // Cyan
    const colorD = new THREE.Color('#c084fc'); // Bright Violet

    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;

      // Galaxy / Nebula spiral distribution
      const radius = Math.pow(Math.random(), 0.6) * 36.0 + 1.2;
      const spinAngle = radius * 0.42;
      const branchAngle = ((i % 4) * (Math.PI * 2) / 4);
      const angle = branchAngle + spinAngle + (Math.random() - 0.5) * 0.65;
      const spreadY = (Math.random() - 0.5) * (14.0 / (1.0 + radius * 0.12));

      positions[i3] = Math.cos(angle) * radius;
      positions[i3 + 1] = spreadY;
      positions[i3 + 2] = Math.sin(angle) * radius;

      const t = Math.min(1.0, radius / 36.0);
      let pColor;
      const randType = Math.random();
      if (randType < 0.35) {
        pColor = colorA.clone().lerp(colorD, Math.random());
      } else if (randType < 0.7) {
        pColor = colorB.clone().lerp(colorC, Math.random());
      } else {
        pColor = colorC.clone().lerp(colorA, t);
      }

      colors[i3] = pColor.r;
      colors[i3 + 1] = pColor.g;
      colors[i3 + 2] = pColor.b;

      scales[i] = Math.random() * 2.2 + 0.8;
      phases[i] = Math.random() * Math.PI * 2;
      speeds[i] = 0.5 + Math.random() * 0.8;
    }

    this.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    this.geometry.setAttribute('aScale', new THREE.BufferAttribute(scales, 1));
    this.geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    this.geometry.setAttribute('aSpeed', new THREE.BufferAttribute(speeds, 1));

    // Custom Shader with strong visual forces and hand illumination
    this.material = new THREE.ShaderMaterial({
      vertexShader: `
        uniform float uTime;
        uniform float uSpeed;
        uniform float uAudioBass;
        uniform float uAudioMid;
        uniform float uAudioTreble;
        uniform float uSensitivity;
        uniform float uPixelRatio;

        uniform vec3 uHand1Pos;
        uniform float uHand1Active;
        uniform float uHand1Pinch;

        uniform vec3 uHand2Pos;
        uniform float uHand2Active;
        uniform float uHand2Pinch;

        attribute float aScale;
        attribute float aPhase;
        attribute float aSpeed;

        varying vec3 vColor;
        varying float vAlpha;
        varying float vHandProximity;

        void main() {
          vColor = color;
          vec3 pos = position;

          // Orbital galactic flow
          float angle = uTime * 0.12 * uSpeed * aSpeed + aPhase;
          float cosA = cos(angle * 0.12);
          float sinA = sin(angle * 0.12);
          vec2 rotXZ = vec2(pos.x * cosA - pos.z * sinA, pos.x * sinA + pos.z * cosA);
          pos.x = rotXZ.x;
          pos.z = rotXZ.y;

          // Real Web Audio Bass pulsation
          float dist = length(pos.xz);
          float bassPulse = 1.0 + (uAudioBass * uSensitivity * 0.65 * sin(dist * 0.28 - uTime * 2.0));
          pos.xz *= bassPulse;

          // Audio Mid-range undulation
          float wave = sin(dist * 0.35 + uTime * 1.5 + aPhase) * (0.8 + uAudioMid * uSensitivity * 2.6);
          pos.y += wave;

          float handProx = 0.0;
          float extraScale = 1.0;

          // 1. Hand 1 Force Field (Cyan Vortex / Singularity)
          if (uHand1Active > 0.5) {
            vec3 diff1 = pos - uHand1Pos;
            float dist1 = length(diff1);
            float radius1 = 22.0;

            if (dist1 < radius1 && dist1 > 0.05) {
              float f1 = 1.0 - (dist1 / radius1);
              f1 = pow(f1, 1.3);

              if (uHand1Pinch > 0.5) {
                // Gravitational Singularity (Pinch pulls thousands of particles into a bright cluster)
                pos -= diff1 * f1 * (0.85 * uSensitivity);
                extraScale += f1 * 2.5;
              } else {
                // Cinematic Swirling Vortex
                float swirlMag = f1 * 9.5 * uSensitivity;
                pos.x += -diff1.y * swirlMag * 0.15;
                pos.y += diff1.x * swirlMag * 0.15;
                pos.z += sin(uTime * 3.5 + dist1) * swirlMag * 0.18;
                extraScale += f1 * 1.6;
              }

              handProx = max(handProx, f1);
            }
          }

          // 2. Hand 2 Force Field (Purple Vortex / Singularity)
          if (uHand2Active > 0.5) {
            vec3 diff2 = pos - uHand2Pos;
            float dist2 = length(diff2);
            float radius2 = 22.0;

            if (dist2 < radius2 && dist2 > 0.05) {
              float f2 = 1.0 - (dist2 / radius2);
              f2 = pow(f2, 1.3);

              if (uHand2Pinch > 0.5) {
                pos -= diff2 * f2 * (0.85 * uSensitivity);
                extraScale += f2 * 2.5;
              } else {
                float swirlMag2 = f2 * 9.5 * uSensitivity;
                pos.x += diff2.y * swirlMag2 * 0.15;
                pos.y += -diff2.x * swirlMag2 * 0.15;
                pos.z += cos(uTime * 3.5 + dist2) * swirlMag2 * 0.18;
                extraScale += f2 * 1.6;
              }

              handProx = max(handProx, f2);
            }
          }

          vHandProximity = handProx;

          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mvPosition;

          // Point size attenuation + Hand proximity boost + Audio treble shimmer
          float trebleBoost = 1.0 + (uAudioTreble * uSensitivity * 0.95);
          gl_PointSize = aScale * (145.0 / -mvPosition.z) * uPixelRatio * trebleBoost * extraScale;

          vAlpha = clamp(1.0 - (-mvPosition.z / 95.0), 0.15, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uColorIntensity;
        varying vec3 vColor;
        varying float vAlpha;
        varying float vHandProximity;

        void main() {
          vec2 coord = gl_PointCoord - vec2(0.5);
          float dist = length(coord);
          if (dist > 0.5) discard;

          float glow = smoothstep(0.5, 0.0, dist);
          glow = pow(glow, 1.5);
          float core = smoothstep(0.18, 0.0, dist);

          vec3 finalColor = vColor * uColorIntensity;

          // Luminous color shift when near tracked hands
          if (vHandProximity > 0.01) {
            vec3 neonShift = vec3(0.0, 0.95, 1.0); // Cyan glow
            finalColor = mix(finalColor, neonShift, vHandProximity * 0.85);
            finalColor += vec3(0.6, 0.8, 1.0) * pow(vHandProximity, 1.8);
          }

          finalColor = mix(finalColor, vec3(1.0, 1.0, 1.0), core * 0.7);

          gl_FragColor = vec4(finalColor, glow * vAlpha);
        }
      `,
      uniforms: {
        uTime: { value: 0 },
        uSpeed: { value: 1.0 },
        uAudioBass: { value: 0 },
        uAudioMid: { value: 0 },
        uAudioTreble: { value: 0 },
        uSensitivity: { value: 1.2 },
        uColorIntensity: { value: 1.25 },
        uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.5) },
        uHand1Pos: { value: new THREE.Vector3(0, 0, 0) },
        uHand1Active: { value: 0.0 },
        uHand1Pinch: { value: 0.0 },
        uHand2Pos: { value: new THREE.Vector3(0, 0, 0) },
        uHand2Active: { value: 0.0 },
        uHand2Pinch: { value: 0.0 },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexColors: true,
    });

    this.points = new THREE.Points(this.geometry, this.material);
    this.group.add(this.points);

    // Create 3D Holographic Hand Beacons
    this.createHandBeacons();

    this.camera.position.set(0, 8, 28);
    this.camera.lookAt(0, 0, 0);
  }

  createHandBeacons() {
    // Beacon 1: Cyan Holographic Ring Nexus
    const beaconGeom1 = new THREE.RingGeometry(1.2, 1.45, 32);
    const beaconMat1 = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.handBeacon1 = new THREE.Mesh(beaconGeom1, beaconMat1);

    // Inner pulsating core
    const innerGeom1 = new THREE.RingGeometry(0.3, 0.55, 24);
    const innerMat1 = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.handBeacon1.add(new THREE.Mesh(innerGeom1, innerMat1));
    this.handBeacon1InnerMat = innerMat1;
    this.scene.add(this.handBeacon1);

    // Beacon 2: Purple Holographic Ring Nexus
    const beaconGeom2 = new THREE.RingGeometry(1.2, 1.45, 32);
    const beaconMat2 = new THREE.MeshBasicMaterial({
      color: 0xc084fc,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.handBeacon2 = new THREE.Mesh(beaconGeom2, beaconMat2);

    const innerGeom2 = new THREE.RingGeometry(0.3, 0.55, 24);
    const innerMat2 = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.handBeacon2.add(new THREE.Mesh(innerGeom2, innerMat2));
    this.handBeacon2InnerMat = innerMat2;
    this.scene.add(this.handBeacon2);
  }

  update(delta, time, audioData, settings, mouse, hand1, hand2) {
    if (!this.material) return;

    const u = this.material.uniforms;
    u.uTime.value = time;
    u.uSpeed.value = settings.speed;
    u.uAudioBass.value = audioData.bass;
    u.uAudioMid.value = audioData.mid;
    u.uAudioTreble.value = audioData.treble;
    u.uSensitivity.value = settings.sensitivity;
    u.uColorIntensity.value = settings.colorIntensity;

    let steerX = mouse.x;
    let steerY = mouse.y;

    // Hand 1 (or mouse fallback)
    if (hand1 && hand1.active) {
      u.uHand1Active.value = 1.0;
      // Stable frustum mapping: X [-25, 25], Y [-15, 15]
      const h1X = hand1.x * 25.0;
      const h1Y = hand1.y * 15.0;
      const h1Z = (hand1.z || 0) * 10.0;
      u.uHand1Pos.value.set(h1X, h1Y, h1Z);
      u.uHand1Pinch.value = hand1.isPinching ? 1.0 : 0.0;
      steerX = hand1.x;
      steerY = hand1.y;

      // Update 3D Holographic Beacon 1
      if (this.handBeacon1) {
        this.handBeacon1.position.set(h1X, h1Y, h1Z);
        this.handBeacon1.rotation.z = time * 2.0;
        const targetScale = hand1.isPinching ? 0.6 : (1.0 + Math.sin(time * 6.0) * 0.15);
        this.handBeacon1.scale.set(targetScale, targetScale, 1.0);
        this.handBeacon1.material.opacity = 0.85;
        this.handBeacon1InnerMat.opacity = hand1.isPinching ? 1.0 : 0.6;
      }
    } else {
      u.uHand1Active.value = 1.0;
      u.uHand1Pos.value.set(mouse.x * 24.0, mouse.y * 14.0, 0.0);
      u.uHand1Pinch.value = 0.0;
      if (this.handBeacon1) {
        this.handBeacon1.material.opacity = THREE.MathUtils.lerp(this.handBeacon1.material.opacity, 0.0, 0.1);
        this.handBeacon1InnerMat.opacity = 0.0;
      }
    }

    // Hand 2
    if (hand2 && hand2.active) {
      u.uHand2Active.value = 1.0;
      const h2X = hand2.x * 25.0;
      const h2Y = hand2.y * 15.0;
      const h2Z = (hand2.z || 0) * 10.0;
      u.uHand2Pos.value.set(h2X, h2Y, h2Z);
      u.uHand2Pinch.value = hand2.isPinching ? 1.0 : 0.0;

      if (this.handBeacon2) {
        this.handBeacon2.position.set(h2X, h2Y, h2Z);
        this.handBeacon2.rotation.z = -time * 2.0;
        const targetScale2 = hand2.isPinching ? 0.6 : (1.0 + Math.cos(time * 6.0) * 0.15);
        this.handBeacon2.scale.set(targetScale2, targetScale2, 1.0);
        this.handBeacon2.material.opacity = 0.85;
        this.handBeacon2InnerMat.opacity = hand2.isPinching ? 1.0 : 0.6;
      }
    } else {
      u.uHand2Active.value = 0.0;
      if (this.handBeacon2) {
        this.handBeacon2.material.opacity = THREE.MathUtils.lerp(this.handBeacon2.material.opacity, 0.0, 0.1);
        this.handBeacon2InnerMat.opacity = 0.0;
      }
    }

    // Galaxy gentle rotation
    this.group.rotation.y = time * 0.04 * settings.speed;
    this.group.rotation.x = Math.sin(time * 0.03) * 0.08 + (steerY * 0.15);
    this.group.rotation.z = Math.cos(time * 0.02) * 0.05 + (steerX * -0.15);

    // Camera responsive parallax
    const targetCamX = steerX * 4.5;
    const targetCamY = 8.0 + steerY * 3.5 + (audioData.bass * 2.0 * settings.sensitivity);
    this.camera.position.x += (targetCamX - this.camera.position.x) * 0.05;
    this.camera.position.y += (targetCamY - this.camera.position.y) * 0.05;
    this.camera.lookAt(0, 0, 0);
  }

  setQuality(qualityLevel) {
    if (!this.geometry) return;
    if (qualityLevel === 'low') {
      this.activeParticleCount = 14000;
    } else if (qualityLevel === 'balanced') {
      this.activeParticleCount = 28000;
    } else {
      this.activeParticleCount = 45000;
    }
    this.geometry.setDrawRange(0, this.activeParticleCount);
  }

  setDensity(densityPercent) {
    if (this.geometry) {
      const activeCount = Math.floor(this.activeParticleCount * Math.max(0.1, Math.min(1.0, densityPercent)));
      this.geometry.setDrawRange(0, activeCount);
    }
  }

  dispose() {
    if (this.points) {
      this.group.remove(this.points);
    }
    if (this.geometry) {
      this.geometry.dispose();
      this.geometry = null;
    }
    if (this.material) {
      this.material.dispose();
      this.material = null;
    }
    if (this.handBeacon1) {
      this.scene.remove(this.handBeacon1);
      this.handBeacon1.geometry.dispose();
      this.handBeacon1.material.dispose();
      this.handBeacon1 = null;
    }
    if (this.handBeacon2) {
      this.scene.remove(this.handBeacon2);
      this.handBeacon2.geometry.dispose();
      this.handBeacon2.material.dispose();
      this.handBeacon2 = null;
    }
    this.scene.remove(this.group);
  }
}
