import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  Zap,
  BatteryCharging,
  AlertTriangle,
  CheckCheck,
  ChevronRight,
  Clock,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Card } from '../components/common/Card';
import { EmptyState } from '../components/common/EmptyState';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const NotificationsScreen = () => {
  const navigate = useNavigate();
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
  } = useEV();
  const { showToast } = useUI();

  const getIcon = (type) => {
    switch (type) {
      case 'booking':
        return <Bell className="w-4 h-4 text-[#00E5FF]" />;
      case 'charging_start':
        return <Zap className="w-4 h-4 text-[#00F5A0]" />;
      case 'charging_complete':
        return <BatteryCharging className="w-4 h-4 text-emerald-400" />;
      case 'alert':
      default:
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
    }
  };

  const handleNotificationClick = (item) => {
    markNotificationAsRead(item.id);
    if (item.actionRoute) {
      navigate(item.actionRoute);
    }
  };

  const handleMarkAll = () => {
    markAllNotificationsAsRead();
    showToast('All notifications marked as read', 'info');
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header
        title="Notification Center"
        showBack
        onBack={() => navigate('/home')}
        rightAction={
          notifications.some((n) => n.unread) && (
            <button
              onClick={handleMarkAll}
              className="text-xs font-semibold text-[#00F5A0] hover:underline flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark Read</span>
            </button>
          )
        }
      />

      <div className="px-4 py-3 space-y-3">
        {notifications.length > 0 ? (
          notifications.map((item) => (
            <Card
              key={item.id}
              hoverable
              onClick={() => handleNotificationClick(item)}
              className={`p-3.5 transition-all ${
                item.unread
                  ? 'border-[#00F5A0]/30 bg-[#12203A]'
                  : 'border-white/5 opacity-85'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-[#0D1527] border border-white/10 shrink-0">
                  {getIcon(item.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h3 className="font-bold text-xs text-white truncate">
                      {item.title}
                    </h3>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 shrink-0">
                      <Clock className="w-3 h-3" />
                      <span>{item.time}</span>
                      {item.unread && (
                        <span className="w-2 h-2 rounded-full bg-[#00F5A0] ml-1" />
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {item.message}
                  </p>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <EmptyState
            icon={Bell}
            title="No Notifications"
            description="You are completely caught up with all charging alerts and status updates."
          />
        )}
      </div>
    </div>
  );
};
