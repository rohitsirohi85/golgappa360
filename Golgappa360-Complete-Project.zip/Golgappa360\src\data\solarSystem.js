/**
 * STELLAR 2.0 — Interactive Solar System Database
 * 
 * Verified astronomical records for the Sun and all eight major planets:
 * Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune.
 * 
 * DISCLAIMER: Illustrative educational visualization — distances and sizes are not to scale.
 */

import { CELESTIAL_CATEGORIES } from './categories.js';

export const PLANET_SUBTYPES = {
  TERRESTRIAL: 'Terrestrial Planet',
  GAS_GIANT: 'Gas Giant',
  ICE_GIANT: 'Ice Giant',
};

/**
 * Verified Solar System Objects
 */
export const SOLAR_SYSTEM_DATA = [
  // ==========================================
  // CENTRAL ANCHOR: THE SUN
  // ==========================================
  {
    id: 'sun',
    name: 'Sun',
    commonName: 'Sol / The Day Star',
    category: CELESTIAL_CATEGORIES.STAR,
    subtype: 'G2V Yellow Dwarf',
    systemName: 'Solar System',
    isSun: true,
    distanceFromSun: '0 AU (0 km)',
    radius: '696,340 km (1.00 × Sun)',
    mass: '1.989 × 10³⁰ kg (1.00 M☉)',
    temperature: '5,778 K (Photosphere) / 15M K (Core)',
    rotationPeriod: '25.38 Earth days (Equator)',
    orbitalPeriod: '≈ 230 million years (Galactic Orbit)',
    age: '≈ 4.60 billion years',
    atmosphere: '73.4% Hydrogen, 25.0% Helium, 1.6% heavier elements',
    description: 'The luminous thermonuclear furnace at the center of our planetary system. Fusing 600 million tons of hydrogen into helium every second in its searing core, it accounts for 99.86% of all mass in the Solar System and binds all eight planets in stable orbital trajectories.',
    interestingFact: 'The Sun accounts for approximately 99.86% of the total mass of the entire Solar System, with Jupiter making up most of the remainder.',
    visualRadius: 32,
    orbitRadius: 0,
    orbitSpeed: 0,
    colorHex: '#fbbf24',
    glowColor: 'rgba(251, 191, 36, 0.55)',
    relatedObjects: ['mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'],
  },

  // ==========================================
  // PLANET 1: MERCURY
  // ==========================================
  {
    id: 'mercury',
    name: 'Mercury',
    commonName: 'The Swift Planet',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.TERRESTRIAL,
    symbol: '☿',
    distanceFromSun: '0.387 AU (57.9 million km)',
    radius: '2,439.7 km (0.383 × Earth)',
    mass: '3.301 × 10²³ kg (0.055 × Earth)',
    temperature: '−180°C to 430°C (100 K to 700 K)',
    orbitalPeriod: '87.97 Earth days',
    rotationPeriod: '58.65 Earth days',
    moons: 0,
    atmosphere: 'Trace exosphere (Oxygen, Sodium, Hydrogen, Helium)',
    description: 'The smallest planet in the Solar System and closest to the Sun. Mercury is a dense, heavily cratered iron-rich world that zips around the Sun faster than any other planet, completing an entire orbit in just 88 Earth days.',
    interestingFact: 'Mercury experiences the most extreme temperature swings in the Solar System, plunging from daytime temperatures of 430°C to nighttime lows of −180°C due to its lack of a substantial atmosphere.',
    visualRadius: 5.5,
    orbitRadius: 75,
    orbitSpeed: 0.04,
    colorHex: '#94a3b8',
    glowColor: 'rgba(148, 163, 184, 0.4)',
    relatedObjects: ['sun', 'venus'],
  },

  // ==========================================
  // PLANET 2: VENUS
  // ==========================================
  {
    id: 'venus',
    name: 'Venus',
    commonName: 'The Morning Star / Evening Star',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.TERRESTRIAL,
    symbol: '♀',
    distanceFromSun: '0.723 AU (108.2 million km)',
    radius: '6,051.8 km (0.949 × Earth)',
    mass: '4.867 × 10²⁴ kg (0.815 × Earth)',
    temperature: '≈ 464°C (737 K, Surface average)',
    orbitalPeriod: '224.70 Earth days',
    rotationPeriod: '243.02 Earth days (Retrograde)',
    moons: 0,
    atmosphere: '96.5% Carbon Dioxide, 3.5% Nitrogen, clouds of Sulfuric Acid',
    description: 'Often called Earth’s twin due to its similar size and density, Venus is enveloped in a crushing, opaque atmosphere 92 times thicker than Earth’s. A runaway greenhouse effect makes its surface the hottest of any planet in the Solar System.',
    interestingFact: 'Venus rotates in retrograde (backwards compared to most planets) so slowly that a single Venusian day (243 Earth days) lasts longer than an entire Venusian year (225 Earth days).',
    visualRadius: 8.5,
    orbitRadius: 115,
    orbitSpeed: 0.028,
    colorHex: '#fef08a',
    glowColor: 'rgba(254, 240, 138, 0.45)',
    relatedObjects: ['sun', 'mercury', 'earth'],
  },

  // ==========================================
  // PLANET 3: EARTH
  // ==========================================
  {
    id: 'earth',
    name: 'Earth',
    commonName: 'The Blue Marble / Terra',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.TERRESTRIAL,
    symbol: '🌍',
    distanceFromSun: '1.000 AU (149.6 million km)',
    radius: '6,371.0 km (1.000 × Earth)',
    mass: '5.972 × 10²⁴ kg (1.000 × Earth)',
    temperature: '−88°C to 58°C (Mean: 15°C / 288 K)',
    orbitalPeriod: '365.25 Earth days (1.000 year)',
    rotationPeriod: '23h 56m 04s (1 Sidereal Day)',
    moons: 1,
    moonNames: 'The Moon (Luna)',
    atmosphere: '78.08% Nitrogen, 20.95% Oxygen, 0.93% Argon, 0.04% CO₂',
    description: 'Our planetary home and the only known oasis of life in the observable universe. Situated comfortably within the Sun’s habitable zone, Earth features active plate tectonics, a protective geomagnetic shield, and vast liquid water oceans covering 71% of its surface.',
    interestingFact: 'Earth is the only planet in the Solar System not named after a Greek or Roman mythological god; its name originates from Old English and Germanic words meaning "ground".',
    visualRadius: 9.0,
    orbitRadius: 160,
    orbitSpeed: 0.02,
    colorHex: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.5)',
    hasLife: true,
    relatedObjects: ['moon', 'sun', 'venus', 'mars'],
  },

  // ==========================================
  // PLANET 4: MARS
  // ==========================================
  {
    id: 'mars',
    name: 'Mars',
    commonName: 'The Red Planet',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.TERRESTRIAL,
    symbol: '♂',
    distanceFromSun: '1.524 AU (227.9 million km)',
    radius: '3,389.5 km (0.532 × Earth)',
    mass: '6.417 × 10²³ kg (0.107 × Earth)',
    temperature: '−140°C to 20°C (Mean: −63°C / 210 K)',
    orbitalPeriod: '686.98 Earth days (1.88 Earth years)',
    rotationPeriod: '24h 37m 22s (1 Sol)',
    moons: 2,
    moonNames: 'Phobos & Deimos',
    atmosphere: '95.3% Carbon Dioxide, 2.7% Nitrogen, 1.6% Argon',
    description: 'A cold, rust-colored desert world featuring dry riverbeds, towering volcanoes, and frozen polar ice caps. Rich in surface iron oxide, Mars possesses Olympus Mons—the largest shield volcano known in the Solar System—and the colossal Valles Marineris canyon network.',
    interestingFact: 'Olympus Mons on Mars stands approximately 21.9 km (13.6 miles) high, making it nearly three times the height of Mount Everest above sea level.',
    visualRadius: 6.8,
    orbitRadius: 210,
    orbitSpeed: 0.015,
    colorHex: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.45)',
    relatedObjects: ['sun', 'earth', 'jupiter'],
  },

  // ==========================================
  // PLANET 5: JUPITER
  // ==========================================
  {
    id: 'jupiter',
    name: 'Jupiter',
    commonName: 'The King of Planets',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.GAS_GIANT,
    symbol: '♃',
    distanceFromSun: '5.204 AU (778.5 million km)',
    radius: '69,911 km (10.97 × Earth)',
    mass: '1.898 × 10²⁷ kg (317.8 × Earth)',
    temperature: '≈ −110°C (163 K, at 1 bar level)',
    orbitalPeriod: '11.86 Earth years (4,333 Earth days)',
    rotationPeriod: '9h 55m 30s (Fastest Planetary Spin)',
    moons: 95,
    moonNames: 'Io, Europa, Ganymede, Callisto, and 91 others',
    atmosphere: '89.8% Hydrogen, 10.2% Helium, traces of Methane, Ammonia',
    description: 'The gravitational titan of our planetary system, possessing more mass than all other planets, moons, and asteroids combined. Driven by internal convection, Jupiter’s vibrant banded atmosphere roils with violent anticyclonic storms, most famously the Great Red Spot.',
    interestingFact: 'Jupiter’s magnetic field is the strongest of any planet in the Solar System, generating magnetospheric auroras thousands of times more energetic than Earth’s.',
    visualRadius: 18.0,
    orbitRadius: 275,
    orbitSpeed: 0.009,
    colorHex: '#fb923c',
    glowColor: 'rgba(251, 146, 60, 0.45)',
    relatedObjects: ['sun', 'mars', 'saturn'],
  },

  // ==========================================
  // PLANET 6: SATURN
  // ==========================================
  {
    id: 'saturn',
    name: 'Saturn',
    commonName: 'The Ringed Jewel',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.GAS_GIANT,
    symbol: '♄',
    distanceFromSun: '9.582 AU (1.434 billion km)',
    radius: '58,232 km (9.14 × Earth)',
    mass: '5.683 × 10²⁶ kg (95.2 × Earth)',
    temperature: '≈ −140°C (133 K, at 1 bar level)',
    orbitalPeriod: '29.46 Earth years (10,759 Earth days)',
    rotationPeriod: '10h 33m 38s',
    moons: 146,
    moonNames: 'Titan, Enceladus, Mimas, Rhea, Iapetus, and 141 others',
    atmosphere: '96.3% Hydrogen, 3.25% Helium, traces of Methane, Ammonia',
    description: 'Celebrated for its awe-inspiring planetary ring system spanning over 282,000 km yet measuring only tens of meters thick. Saturn is a gas giant with an average bulk density less than water, surrounded by an immense court of 146 known moons.',
    interestingFact: 'Saturn’s rings are composed of billions of individual particles of water ice and rock, ranging in size from microscopic dust grains to mountain-sized chunks.',
    visualRadius: 15.0,
    hasRings: true,
    ringInnerRadius: 20.0,
    ringOuterRadius: 32.0,
    orbitRadius: 345,
    orbitSpeed: 0.006,
    colorHex: '#fcd34d',
    glowColor: 'rgba(252, 211, 77, 0.45)',
    relatedObjects: ['sun', 'jupiter', 'uranus'],
  },

  // ==========================================
  // PLANET 7: URANUS
  // ==========================================
  {
    id: 'uranus',
    name: 'Uranus',
    commonName: 'The Tilted Ice Giant',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.ICE_GIANT,
    symbol: '♅',
    distanceFromSun: '19.20 AU (2.871 billion km)',
    radius: '25,362 km (3.98 × Earth)',
    mass: '8.681 × 10²⁵ kg (14.5 × Earth)',
    temperature: '≈ −195°C to −224°C (49 K, Coldest Atmosphere)',
    orbitalPeriod: '84.01 Earth years (30,687 Earth days)',
    rotationPeriod: '17h 14m 24s (Retrograde on its side)',
    axialTilt: '97.77° (Rotates practically on its side)',
    moons: 28,
    moonNames: 'Titania, Oberon, Umbriel, Ariel, Miranda, and 23 others',
    atmosphere: '82.5% Hydrogen, 15.2% Helium, 2.3% Methane (gives cyan tint)',
    description: 'An icy giant world distinguished by an extreme 98° axial tilt, causing it to effectively roll along its orbital plane like a ball. Atmospheric methane absorbs red light, giving Uranus its pristine aquamarine color above deep mantles of water, ammonia, and methane ices.',
    interestingFact: 'Due to its 98° tilt, each pole of Uranus experiences 42 continuous years of uninterrupted sunlight, followed by 42 years of complete darkness during its 84-year orbit.',
    visualRadius: 11.5,
    hasRings: true,
    orbitRadius: 415,
    orbitSpeed: 0.0035,
    colorHex: '#67e8f9',
    glowColor: 'rgba(103, 232, 249, 0.45)',
    relatedObjects: ['sun', 'saturn', 'neptune'],
  },

  // ==========================================
  // PLANET 8: NEPTUNE
  // ==========================================
  {
    id: 'neptune',
    name: 'Neptune',
    commonName: 'The Mystic Blue Giant',
    category: 'PLANET',
    subtype: PLANET_SUBTYPES.ICE_GIANT,
    symbol: '♆',
    distanceFromSun: '30.05 AU (4.495 billion km)',
    radius: '24,622 km (3.86 × Earth)',
    mass: '1.024 × 10²⁶ kg (17.1 × Earth)',
    temperature: '≈ −201°C (72 K, Mean at 1 bar)',
    orbitalPeriod: '164.80 Earth years (60,190 Earth days)',
    rotationPeriod: '16h 06m 36s',
    moons: 16,
    moonNames: 'Triton, Proteus, Nereid, Larissa, and 12 others',
    atmosphere: '80.0% Hydrogen, 19.0% Helium, 1.5% Methane',
    description: 'The outermost major planet in the Solar System, blazing with vivid azure-blue radiance. Despite its immense distance from the Sun, Neptune drives the most violent weather in the Solar System, with supersonic storms churning winds faster than 2,100 km/h.',
    interestingFact: 'Neptune was the first planet located through mathematical prediction rather than empirical observation, after astronomers calculated irregularities in Uranus’s orbit.',
    visualRadius: 11.0,
    orbitRadius: 485,
    orbitSpeed: 0.0022,
    colorHex: '#3b82f6',
    glowColor: 'rgba(59, 130, 246, 0.45)',
    relatedObjects: ['sun', 'uranus'],
  },
];

/**
 * Verified Lunar Telemetry Record (Earth's Moon)
 */
export const MOON_DATA = {
  id: 'moon',
  name: 'Moon',
  commonName: 'Luna / Earth’s Natural Satellite',
  category: 'NATURAL_SATELLITE',
  subtype: 'Natural Satellite',
  symbol: '🌕',
  parentPlanet: 'earth',
  distanceFromEarth: '384,400 km (1.28 light-seconds)',
  distanceFromSun: '1.000 AU (149.6 million km)',
  radius: '1,737.4 km (0.273 × Earth)',
  mass: '7.342 × 10²² kg (0.0123 × Earth)',
  gravity: '1.62 m/s² (0.166 × Earth)',
  temperature: '−130°C to 120°C (Night / Day)',
  orbitalPeriod: '27.32 Earth days (Synchronous)',
  rotationPeriod: '27.32 Earth days (Tidally Locked)',
  atmosphere: 'Extremely tenuous surface boundary exosphere (Helium, Neon, Hydrogen)',
  description: 'Earth’s sole permanent natural satellite and the fifth-largest moon in the Solar System. Locked in synchronous rotation with Earth, the Moon always presents the same face towards our world. Its gravitational pull stabilizes Earth’s axial tilt and governs the rhythm of ocean tides.',
  interestingFact: 'Due to tidal locking, the Moon rotates at the exact same rate as its orbital period around Earth (27.3 days), meaning humanity never saw the lunar far side until the Soviet Luna 3 probe photographed it in 1959.',
  visualRadius: 4.5,
  colorHex: '#e2e8f0',
  glowColor: 'rgba(226, 232, 240, 0.4)',
  relatedObjects: ['earth', 'sun'],
};

/**
 * 8 Canonical Moon Phases for Educational Interactive Controller
 */
export const MOON_PHASES = [
  { id: 'new-moon', name: 'New Moon', symbol: '🌑', illumination: '0%', angle: 0, description: 'The Moon is situated directly between Earth and the Sun; the sunlit side faces away from Earth.' },
  { id: 'waxing-crescent', name: 'Waxing Crescent', symbol: '🌒', illumination: '25%', angle: Math.PI * 0.25, description: 'A slender silver sliver appears on the right edge as the Moon begins orbiting eastward away from the Sun.' },
  { id: 'first-quarter', name: 'First Quarter', symbol: '🌓', illumination: '50%', angle: Math.PI * 0.5, description: 'Half of the lunar near side is illuminated; occurs one quarter of the way through the lunar orbit.' },
  { id: 'waxing-gibbous', name: 'Waxing Gibbous', symbol: '🌔', illumination: '75%', angle: Math.PI * 0.75, description: 'More than half of the near side is illuminated as it approaches maximum solar reflection.' },
  { id: 'full-moon', name: 'Full Moon', symbol: '🌕', illumination: '100%', angle: Math.PI, description: 'The entire lunar near side is brilliantly sunlit as Earth sits between the Sun and the Moon.' },
  { id: 'waning-gibbous', name: 'Waning Gibbous', symbol: '🌖', illumination: '75%', angle: Math.PI * 1.25, description: 'The illuminated portion begins receding toward darkness from the right limb.' },
  { id: 'third-quarter', name: 'Third Quarter', symbol: '🌗', illumination: '50%', angle: Math.PI * 1.5, description: 'The left half of the near side is sunlit; occurs three-quarters through the lunar cycle.' },
  { id: 'waning-crescent', name: 'Waning Crescent', symbol: '🌘', illumination: '25%', angle: Math.PI * 1.75, description: 'A final crescent sliver visible in morning twilight before slipping into the New Moon phase.' },
];

/**
 * Quick lookup map for Solar System objects by ID (including Moon)
 */
export const SOLAR_SYSTEM_MAP = new Map(
  [...SOLAR_SYSTEM_DATA, MOON_DATA].map((obj) => [obj.id, obj])
);

/**
 * Returns a Solar System object by ID.
 */
export function getSolarSystemObjectById(id) {
  return SOLAR_SYSTEM_MAP.get(id) || null;
}
