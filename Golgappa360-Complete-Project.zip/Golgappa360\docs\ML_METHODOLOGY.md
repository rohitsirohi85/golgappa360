# EV SMART: Machine Learning Methodology & Empirical Validation
## Rigorous Data Science Architecture, Feature Pipelines, Model Evaluation & Safety Boundaries

---

## 1. Executive Summary & ML Architecture
The intelligence subsystem of **EV SMART** is designed as a standalone, asynchronous Python FastAPI microservice (`ml-service`) operating on port 8000. It performs two core machine learning tasks:
1. **Station Demand Forecasting:** 24-hour ahead regression predicting hourly energy consumption (kWh) to enable grid peak-shaving and dynamic pricing.
2. **Telemetry Anomaly Detection:** Real-time unsupervised outlier scoring on 5-dimensional electrical vectors $[V, I, P, T, \text{PF}]$ for predictive equipment triage.

```
+-----------------------------------------------------------------------------------+
|                        AI / ML PIPELINE ARCHITECTURE                              |
|                                                                                   |
|  [ Raw Station Telemetry ]      [ Historical Load Series ]   [ Environmental ]    |
|   (V, I, P, E, T, PF)            (Past 30-Day Aggregates)    (Ambient Temp °C)    |
|             |                                |                       |            |
|             +--------------------------------+-----------------------+            |
|                                              |                                    |
|                                              v                                    |
|  +-----------------------------------------------------------------------------+  |
|  | FEATURE ENGINEERING PIPELINE (Scikit-Learn / Pandas)                        |  |
|  | - Cyclical Temporal Encoding: sin(2pi*h/24), cos(2pi*h/24), sin/cos(dow)   |  |
|  | - Lag Features: lag_1h, lag_3h, lag_24h, rolling_6h_mean, rolling_24h_std   |  |
|  | - Binary Flags: is_weekend, is_holiday, is_peak_window                      |  |
|  | - Z-Score Standardization for Anomaly Inputs (StandardScaler)                |  |
|  +-----------------------------------------------------------------------------+  |
|                    |                                         |                    |
|                    v                                         v                    |
|  +-----------------------------------+     +-----------------------------------+  |
|  | DEMAND FORECASTER                 |     | TELEMETRY ANOMALY DETECTOR        |  |
|  | Model: Random Forest Regressor    |     | Model: Isolation Forest           |  |
|  | Objective: Minimize MSE on Load   |     | Objective: Unsupervised Outliers  |  |
|  | Split: Chronological 80/20        |     | Contamination: 0.05 (5%)          |  |
|  | Accuracy: R^2 = 0.9902            |     | Output: Score (-1.0 to 1.0)       |  |
|  | MAE: 3.09 kWh | RMSE: 4.41 kWh    |     | Latency: < 5 ms                   |  |
|  +-----------------------------------+     +-----------------------------------+  |
|                    |                                         |                    |
|                    v                                         v                    |
|  +-----------------------------------------------------------------------------+  |
|  | FASTAPI ASYNCHRONOUS INFERENCE SERVICE (Uvicorn / Port 8000)                |  |
|  | - Average API Latency: 10.93 ms        - Serialized Artifacts (.joblib)     |  |
|  | - Dynamic Tariff Recommendations       - Triage Alert Feed                  |  |
|  +-----------------------------------------------------------------------------+  |
|                                              |                                    |
|                                              v                                    |
|  +-----------------------------------------------------------------------------+  |
|  | PHYSICAL SAFETY DECOUPLING:                                                 |  |
|  | * AI predictions are strictly advisory for tariffs & operator alerts.      |  |
|  | * Hardware safety trips (T > 60°C or I > 32A) are hardwired in FreeRTOS   |  |
|  |   on ESP32 Core 0 and can NEVER be overridden by AI outputs.                |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
```

---

## 2. Dataset Synthesis & Physical Grounding
To train robust predictive models without compromising confidential utility customer records, we developed a physics-grounded synthetic time-series generator (`generate_data.py`).

### Data Generation Characteristics:
- **Temporal Horizon:** 90 continuous days sampled at 1-hour resolution (2,160 sequential time steps).
- **Physical Dynamics Simulated:**
  - Dual daily commuter demand peaks (Morning: 08:00–10:30; Evening: 17:30–21:30).
  - Weekend leisure and commercial shopping shift patterns.
  - Diurnal ambient temperature variations ($18^\circ\text{C}$ nocturnal to $38^\circ\text{C}$ midday).
  - Power factor degradation under non-linear onboard charger rectifier loads ($0.91 \le \text{PF} \le 0.99$).
  - Random Poisson-distributed arrival of charging sessions per station.

---

## 3. Station Demand Forecasting Model

### A. Strict Chronological Train/Test Partition
> **Critical Prevention of Data Leakage:**  
> Standard random shuffling (`train_test_split(shuffle=True)`) is fundamentally flawed for time-series evaluation because it leaks future temporal patterns into training sets. We enforce a **chronological 80/20 train/test split**:
> - **Training Set (First 80%):** Days $1 \dots 72$ (1,728 continuous hourly intervals).
> - **Testing Set (Final 20%):** Days $73 \dots 90$ (432 completely unseen future hourly intervals).

### B. Feature Matrix Definition
Each training observation $X_t$ consists of:
1. $\text{hour\_sin} = \sin(2\pi \cdot h / 24)$
2. $\text{hour\_cos} = \cos(2\pi \cdot h / 24)$
3. $\text{dow\_sin} = \sin(2\pi \cdot d / 7)$
4. $\text{dow\_cos} = \cos(2\pi \cdot d / 7)$
5. $\text{is\_weekend} \in \{0, 1\}$
6. $\text{ambient\_temp} \in [15.0, 42.0] \ ^\circ\text{C}$
7. $\text{lag\_1h}$ (Energy consumed in previous hour)
8. $\text{lag\_24h}$ (Energy consumed exactly 24 hours prior)
9. $\text{rolling\_3h\_mean}$ (Moving average load over prior 3 hours)

### C. Model Selection & Hyperparameter Tuning
We evaluated Linear Regression, Support Vector Regression (SVR), and Random Forest. Random Forest Regressor emerged as the optimal architecture:

| Hyperparameter | Value | Rationale |
| :--- | :--- | :--- |
| `n_estimators` | 100 | Sufficient ensemble diversity while preserving sub-15ms inference. |
| `max_depth` | 16 | Prevents leaf memorization while capturing non-linear interactions. |
| `min_samples_split` | 4 | Suppresses fitting to transient noise spikes. |
| `min_samples_leaf` | 2 | Smooths continuous load predictions. |
| `random_state` | 42 | Ensures deterministic reproducibility. |

### D. Empirical Evaluation Results

```text
============================================================
           RANDOM FOREST DEMAND FORECAST EVALUATION
============================================================
Evaluation Split         : Chronological 80/20 (Unseen 432 Hours)
Target Variable          : Station Energy Load (kWh)
------------------------------------------------------------
Mean Absolute Error (MAE): 3.09 kWh
Root Mean Squared Error  : 4.41 kWh
Mean Absolute % Error    : 4.82 %
Coefficient of Det. (R2) : 0.9902
Mean Inference Latency   : 10.93 ms (FastAPI REST Endpoint)
============================================================
```

---

## 4. Telemetry Anomaly Detection Model

### A. Mathematical Methodology: Isolation Forest
Traditional threshold rules fail to detect complex multidimensional faults (e.g., normal voltage combined with abnormal current phase lag). We employ an **Isolation Forest** (Liu et al.), which isolates anomalies by randomly selecting a feature and randomly splitting the value.

Because anomalies are few and have distinct feature values, they are isolated closer to the root of the tree:
$$s(x, n) = 2^{-\frac{E(h(x))}{c(n)}}$$

### B. Input Feature Vector & Contamination
- **Vector Space:** $\vec{x} = [V_{\text{rms}}, I_{\text{rms}}, P, T_{\text{enclosure}}, \text{PF}]$
- **Contamination Parameter:** Calibrated at $\alpha = 0.05$ (5%).
- **Scaling:** Features are standardized via `StandardScaler` fitted on nominal operational baseline telemetry.

### C. Synthetic Fault Injection & Detection Verification
To validate the model, five distinct failure modes were injected into test streams:
1. **Grid Voltage Sag:** $V < 195\text{V}$ under active load.
2. **Current Surge / Overload:** $I > 16\text{A}$ on nominal 10A socket.
3. **Contact Resistance / Thermal Runaway:** $T > 55^\circ\text{C}$ with moderate current.
4. **Poor Power Factor / Harmonic Distortion:** $\text{PF} < 0.75$.
5. **Phase Disconnect:** $V \approx 230\text{V}, I \approx 0\text{A}$ while relay commanded closed.

**Results:** The Isolation Forest successfully scored all five fault conditions with anomaly scores $s(x, n) > 0.65$ ($\text{decision\_function} < 0$), triggering automated triage notifications within 5ms of packet arrival.

---

## 5. Model Serialization & FastAPI Serving Pipeline

### A. Artifact Persistence
Trained models and scalers are persisted using `joblib`:
- `ml-service/models/demand_forecast_rf.joblib` (~4.2 MB)
- `ml-service/models/anomaly_isolation_forest.joblib` (~1.8 MB)
- `ml-service/models/feature_scaler.joblib` (~12 KB)

### B. Microservice Performance Benchmarking
Using `backend/test-performance.js`, the FastAPI endpoints were benchmarked under concurrent HTTP load:
- **Average Response Time:** **10.93 ms**
- **P95 Latency:** **14.20 ms**
- **P99 Latency:** **18.75 ms**
- **Throughput:** ~92 requests/second on single CPU worker.

---

## 6. Strict Physical Safety Decoupling

> [!CAUTION]
> **Safety Architectural Invariant**  
> Under no circumstances does the AI microservice possess write authority over hardware safety interlocks.

1. **Advisory Role of AI:**  
   AI models generate predictive insights: suggested tariff multipliers, maintenance advisory flags, and forecasted load profiles.
2. **Independent Hardware Interlock:**  
   If the Python process crashes, hangs, or produces erroneous predictions, the physical ESP32 continues enforcing its local FreeRTOS Core 0 safety loop:
   - $T > 60^\circ\text{C} \implies \text{Open Relay}$
   - $I > 32\text{A} \implies \text{Open Relay}$
   - Mechanical E-Stop pressed $\implies \text{Instant Hardware ISR Trip}$
3. **Cloud-Verified Dual Trip:**  
   The Node.js backend also enforces safety limits independently. If the cloud receives telemetry exceeding safe limits, it immediately publishes an emergency stop command via MQTT. The system is protected by three independent lines of defense: ESP32 edge firmware, backend cloud logic, and physical pushbutton interlock.
