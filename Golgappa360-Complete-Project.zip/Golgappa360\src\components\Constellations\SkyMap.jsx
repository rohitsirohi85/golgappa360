import React, { useState, useRef, useMemo } from 'react';

/**
 * SkyMap — Interactive Astronomical Sky Atlas
 * Features:
 * - Dynamic SVG celestial canvas with pan & zoom controls
 * - Right Ascension & Declination coordinate grid
 * - Magnitude-scaled stars (brighter = larger radius & multi-ring radiance)
 * - Animated glowing constellation lines
 * - Star selection with sci-fi HUD reticle & coordinates tracking
 * - Ambient star dust & faint background stars
 * - Magnitude scale legend
 */
export default function SkyMap({
  constellation,
  selectedStarId,
  onSelectStar,
}) {
  // Zoom & Pan transformation state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredStar, setHoveredStar] = useState(null);
  const [prevConstellationId, setPrevConstellationId] = useState(constellation.id);

  const containerRef = useRef(null);

  // Reset zoom & pan when switching constellations
  if (constellation.id !== prevConstellationId) {
    setPrevConstellationId(constellation.id);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }

  // Handle zoom controls
  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.25, 2.2));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.25, 0.75));
  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Mouse pan handlers
  const handleMouseDown = (e) => {
    if (e.button !== 0) return; // Only primary button
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Pre-generate deterministic ambient stars for the backdrop
  const ambientStars = useMemo(() => {
    const list = [];
    const count = 55;
    for (let i = 0; i < count; i++) {
      // Deterministic pseudorandom values based on index
      const x = (i * 137.5) % 960 + 20;
      const y = (i * 97.3) % 760 + 20;
      const r = ((i % 5) + 1) * 0.45 + 0.4;
      const opacity = ((i % 4) + 2) * 0.12;
      list.push({ x, y, r, opacity });
    }
    return list;
  }, []);

  // Compute visual radius based on apparent magnitude
  const getStarRadius = (mag) => {
    if (mag < 0) return 9; // Sirius (-1.46)
    if (mag < 1.0) return 7.5; // Rigel, Betelgeuse
    if (mag < 2.0) return 6; // Shaula, Bellatrix, Alnilam
    if (mag < 2.8) return 4.8; // Mintaka, Merak
    return 3.8; // Faint stars (3.0+)
  };

  // Map star connections to SVG lines
  const starMap = useMemo(() => {
    const map = new Map();
    constellation.mainStars.forEach((star) => map.set(star.id, star));
    return map;
  }, [constellation]);

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[4/3] sm:aspect-[16/11] lg:aspect-[16/10] rounded-3xl glass-surface border border-white/15 overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.8)] select-none group"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
      role="region"
      aria-label={`${constellation.name} interactive sky map`}
    >
      {/* Background Deep Space Gradient & Nebula Mist */}
      <div className="absolute inset-0 bg-[#020308] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.1),rgba(2,3,8,0.98))]" />
      <div
        className="absolute inset-0 opacity-20 pointer-events-none transition-opacity duration-700"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${constellation.accentColor}33 0%, transparent 70%)`,
        }}
      />

      {/* SVG Celestial Chart */}
      <svg
        viewBox="0 0 1000 800"
        className="w-full h-full relative z-10 transition-transform duration-200 ease-out"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        <defs>
          {/* Constellation Line Glow Filter */}
          <filter id="line-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Star Flare Glow Filter */}
          <filter id="star-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Radial Gradient for Selected Reticle */}
          <radialGradient id="reticle-pulse" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={constellation.accentColor} stopOpacity="0.8" />
            <stop offset="100%" stopColor={constellation.accentColor} stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* 1. Subtle Celestial Grid / Coordinate System */}
        <g className="text-slate-700/35 text-[9px] font-mono pointer-events-none">
          {/* Horizontal Declination Lines */}
          {[160, 320, 480, 640].map((y, i) => (
            <g key={`dec-${i}`}>
              <line
                x1="40"
                y1={y}
                x2="960"
                y2={y}
                stroke="currentColor"
                strokeWidth="0.8"
                strokeDasharray="4 8"
              />
              <text x="50" y={y - 6} fill="currentColor">
                DEC {+45 - i * 30}°
              </text>
            </g>
          ))}

          {/* Vertical Right Ascension Lines */}
          {[200, 400, 600, 800].map((x, i) => (
            <g key={`ra-${i}`}>
              <line
                x1={x}
                y1="40"
                x2={x}
                y2="760"
                stroke="currentColor"
                strokeWidth="0.8"
                strokeDasharray="4 8"
              />
              <text x={x + 6} y="750" fill="currentColor">
                RA {String(i * 6).padStart(2, '0')}h
              </text>
            </g>
          ))}

          {/* Outer Border HUD Frame */}
          <rect
            x="40"
            y="40"
            width="920"
            height="720"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
          />
        </g>

        {/* 2. Ambient Faint Background Stars */}
        <g className="pointer-events-none">
          {ambientStars.map((s, idx) => (
            <circle
              key={`ambient-${idx}`}
              cx={s.x}
              cy={s.y}
              r={s.r}
              fill="#ffffff"
              opacity={s.opacity}
            />
          ))}
        </g>

        {/* 3. Connected Constellation Lines */}
        <g filter="url(#line-glow)" className="transition-all duration-700">
          {constellation.connectedStarPattern.map(([starAId, starBId], idx) => {
            const starA = starMap.get(starAId);
            const starB = starMap.get(starBId);
            if (!starA || !starB) return null;

            const isHighlighted =
              selectedStarId === starAId || selectedStarId === starBId;

            return (
              <g key={`line-${idx}`}>
                {/* Thick background glow line */}
                <line
                  x1={starA.x}
                  y1={starA.y}
                  x2={starB.x}
                  y2={starB.y}
                  stroke={constellation.accentColor}
                  strokeWidth={isHighlighted ? 3.5 : 2}
                  strokeOpacity={isHighlighted ? 0.8 : 0.35}
                  strokeLinecap="round"
                  className="transition-all duration-300"
                />
                {/* Core luminous beam */}
                <line
                  x1={starA.x}
                  y1={starA.y}
                  x2={starB.x}
                  y2={starB.y}
                  stroke="#ffffff"
                  strokeWidth={isHighlighted ? 1.5 : 1}
                  strokeOpacity={isHighlighted ? 0.95 : 0.65}
                  strokeLinecap="round"
                  strokeDasharray="2000"
                  strokeDashoffset="0"
                  className="transition-all duration-300"
                />
              </g>
            );
          })}
        </g>

        {/* 4. Interactive Constellation Star Nodes */}
        {constellation.mainStars.map((star) => {
          const isSelected = selectedStarId === star.id;
          const isHovered = hoveredStar === star.id;
          const r = getStarRadius(star.magnitude);

          return (
            <g
              key={star.id}
              onClick={(e) => {
                e.stopPropagation();
                onSelectStar(star);
              }}
              onMouseEnter={() => setHoveredStar(star.id)}
              onMouseLeave={() => setHoveredStar(null)}
              className="cursor-pointer focus:outline-none"
              tabIndex={0}
              role="button"
              aria-label={`${star.name}, magnitude ${star.magnitude}, spectral class ${star.spectralClass}`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectStar(star);
                }
              }}
            >
              {/* Outer Radiance Halo for Bright Stars */}
              <circle
                cx={star.x}
                cy={star.y}
                r={r * 3.2}
                fill={star.glowColor}
                opacity={isSelected ? 0.85 : isHovered ? 0.65 : 0.4}
                className="transition-opacity duration-300 animate-pulse"
              />

              {/* Middle Luminous Halo */}
              <circle
                cx={star.x}
                cy={star.y}
                r={r * 1.8}
                fill={star.colorHex}
                opacity={0.7}
                filter="url(#star-glow)"
              />

              {/* Incandescent Stellar Core */}
              <circle
                cx={star.x}
                cy={star.y}
                r={r}
                fill="#ffffff"
                stroke={star.colorHex}
                strokeWidth={1.5}
                className="transition-transform duration-200"
              />

              {/* Sci-Fi HUD Reticle Brackets when Selected */}
              {isSelected && (
                <g className="animate-spin-slow origin-center" style={{ transformOrigin: `${star.x}px ${star.y}px` }}>
                  {/* Outer Target Circle */}
                  <circle
                    cx={star.x}
                    cy={star.y}
                    r={r + 14}
                    fill="none"
                    stroke={constellation.accentColor}
                    strokeWidth="1.2"
                    strokeDasharray="6 4"
                    opacity="0.9"
                  />
                  {/* Reticle Corner Brackets */}
                  <path
                    d={`M ${star.x - r - 10} ${star.y - r - 4} L ${star.x - r - 10} ${star.y - r - 10} L ${star.x - r - 4} ${star.y - r - 10}`}
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.8"
                  />
                  <path
                    d={`M ${star.x + r + 10} ${star.y - r - 4} L ${star.x + r + 10} ${star.y - r - 10} L ${star.x + r + 4} ${star.y - r - 10}`}
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.8"
                  />
                  <path
                    d={`M ${star.x - r - 10} ${star.y + r + 4} L ${star.x - r - 10} ${star.y + r + 10} L ${star.x - r - 4} ${star.y + r + 10}`}
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.8"
                  />
                  <path
                    d={`M ${star.x + r + 10} ${star.y + r + 4} L ${star.x + r + 10} ${star.y + r + 10} L ${star.x + r + 4} ${star.y + r + 10}`}
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.8"
                  />
                </g>
              )}

              {/* Star Label Annotation */}
              <g
                transform={`translate(${star.x + (star.x > 750 ? -12 : 14)}, ${
                  star.y + (star.y > 650 ? -14 : 4)
                })`}
                className="pointer-events-none select-none"
              >
                {/* Glow shadow for readability */}
                <text
                  x="0"
                  y="0"
                  className={`font-display font-semibold text-xs ${
                    star.x > 750 ? 'text-right' : 'text-left'
                  }`}
                  textAnchor={star.x > 750 ? 'end' : 'start'}
                  fill="#020308"
                  stroke="#020308"
                  strokeWidth="3.5"
                >
                  {star.name}
                </text>
                <text
                  x="0"
                  y="0"
                  className={`font-display font-semibold text-xs ${
                    star.x > 750 ? 'text-right' : 'text-left'
                  }`}
                  textAnchor={star.x > 750 ? 'end' : 'start'}
                  fill={isSelected ? '#ffffff' : isHovered ? '#e0f2fe' : '#cbd5e1'}
                >
                  {star.name}
                </text>

                {/* Subtitle Designation */}
                <text
                  x="0"
                  y="12"
                  className={`font-mono text-[9px] ${
                    star.x > 750 ? 'text-right' : 'text-left'
                  }`}
                  textAnchor={star.x > 750 ? 'end' : 'start'}
                  fill={isSelected ? constellation.accentColor : '#64748b'}
                >
                  {star.bayer} (mag {star.magnitude.toFixed(1)})
                </text>
              </g>
            </g>
          );
        })}
      </svg>

      {/* TOP-LEFT HUD: Celestial Telemetry Status */}
      <div className="absolute top-4 left-4 z-20 pointer-events-none flex flex-col gap-1">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-cyan-300">
          <span
            className="w-2 h-2 rounded-full animate-ping"
            style={{ backgroundColor: constellation.accentColor }}
          />
          <span className="font-semibold uppercase tracking-wider">
            {constellation.name} // {constellation.abbreviation}
          </span>
        </div>
        <span className="text-[9px] font-mono text-slate-400 pl-1">
          RA: {constellation.raRange} | DEC: {constellation.decRange}
        </span>
      </div>

      {/* TOP-RIGHT HUD: Star Magnitude Legend */}
      <div className="absolute top-4 right-4 z-20 pointer-events-none hidden sm:flex flex-col items-end gap-1">
        <div className="px-3 py-1.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-slate-300 flex items-center gap-2">
          <span className="text-white font-bold">BRIGHTER</span>
          <span className="text-cyan-400">✦</span>
          <span className="text-slate-500">──────────</span>
          <span className="text-slate-400">DIMMER</span>
        </div>
        <span className="text-[9px] font-mono text-slate-400 pr-1">
          AREA: {constellation.areaSqDeg} SQ DEG ({constellation.quadrant})
        </span>
      </div>

      {/* BOTTOM-LEFT HUD: Zoom & Field of View Controls */}
      <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2">
        <div className="flex items-center rounded-xl bg-black/70 backdrop-blur-md border border-white/15 p-1 shadow-lg">
          <button
            type="button"
            onClick={handleZoomIn}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-200 hover:text-white hover:bg-white/10 transition-colors text-base font-bold cursor-pointer"
            title="Zoom In"
            aria-label="Zoom In"
          >
            +
          </button>
          <div className="w-px h-4 bg-white/10 mx-0.5" />
          <button
            type="button"
            onClick={handleZoomOut}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-200 hover:text-white hover:bg-white/10 transition-colors text-base font-bold cursor-pointer"
            title="Zoom Out"
            aria-label="Zoom Out"
          >
            −
          </button>
          <div className="w-px h-4 bg-white/10 mx-0.5" />
          <button
            type="button"
            onClick={handleReset}
            className="px-2.5 h-8 rounded-lg flex items-center justify-center text-slate-200 hover:text-white hover:bg-white/10 transition-colors text-[11px] font-mono cursor-pointer"
            title="Reset View"
            aria-label="Reset View"
          >
            Reset
          </button>
        </div>

        <span className="text-[10px] font-mono text-slate-400 bg-black/50 px-2.5 py-1.5 rounded-lg border border-white/5 hidden sm:inline-block">
          ZOOM: {zoom.toFixed(1)}x
        </span>
      </div>

      {/* BOTTOM-RIGHT HUD: Click Helper Tip */}
      <div className="absolute bottom-4 right-4 z-20 pointer-events-none hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-slate-300">
        <span className="text-cyan-400">ℹ</span>
        <span>DRAG TO PAN • CLICK STAR FOR SPECTROSCOPIC DOSSIER</span>
      </div>
    </div>
  );
}
