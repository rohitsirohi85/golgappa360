import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  MapPin,
  Calendar,
  Zap,
  History,
  ChevronRight,
  Car,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { BatteryIndicator } from '../components/common/BatteryIndicator';
import { StationCard } from '../components/stations/StationCard';
import { useAuth } from '../context/AuthContext';
import { useEV } from '../context/EVContext';

export const HomeScreen = () => {
  const navigate = useNavigate();
  const { user, vehicle } = useAuth();
  const { stations, unreadNotificationsCount, isCharging } = useEV();

  const quickActions = [
    {
      id: 'find',
      label: 'Find Charger',
      icon: MapPin,
      color: 'text-[#00F5A0]',
      bgColor: 'bg-[#00F5A0]/10',
      route: '/stations',
    },
    {
      id: 'booking',
      label: 'My Booking',
      icon: Calendar,
      color: 'text-[#00E5FF]',
      bgColor: 'bg-[#00E5FF]/10',
      route: '/bookings',
    },
    {
      id: 'charging',
      label: 'Start Charging',
      icon: Zap,
      color: 'text-amber-400',
      bgColor: 'bg-amber-400/10',
      route: '/live-charging',
      badge: isCharging ? 'Active' : null,
    },
    {
      id: 'history',
      label: 'Charging History',
      icon: History,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
      route: '/history',
    },
  ];

  return (
    <div className="flex flex-col gap-5 px-4 pt-2 select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/profile')}
            className="relative rounded-2xl overflow-hidden border border-white/10 hover:border-[#00F5A0] transition-colors"
          >
            <img
              src={user?.avatar}
              alt={user?.name || 'Suman'}
              className="w-11 h-11 object-cover"
            />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400">Good Morning,</span>
            </div>
            <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-1">
              <span>{user?.name || 'Suman'}</span>
              <span>👋</span>
            </h1>
          </div>
        </div>

        {/* Notifications Icon with Badge */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/notifications')}
            className="relative p-2.5 rounded-2xl bg-[#0D1527] border border-white/10 hover:border-white/20 text-slate-300 hover:text-white transition-all"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#00F5A0] text-[#050811] text-[10px] font-bold shadow-[0_0_8px_#00F5A0]">
                {unreadNotificationsCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Hero Vehicle HUD Card */}
      <Card
        glow
        className="relative overflow-hidden bg-gradient-to-br from-[#101B33] via-[#0E162B] to-[#091021]"
      >
        <div className="flex items-start justify-between mb-2">
          <div>
            <div className="flex items-center gap-1.5 text-xs text-[#00F5A0] font-semibold uppercase tracking-wider">
              <Car className="w-3.5 h-3.5" />
              <span>My Vehicle</span>
            </div>
            <h2 className="text-xl font-extrabold text-white mt-0.5">
              {vehicle?.make || 'Tesla'} {vehicle?.model || 'Model 3'}
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              {vehicle?.batteryCapacity || 60} kWh • {vehicle?.connector || 'CCS2'}
            </span>
          </div>

          <button
            onClick={() => navigate('/vehicle-management')}
            className="text-xs text-slate-400 hover:text-[#00F5A0] flex items-center gap-0.5"
          >
            <span>Manage</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Circular Battery Indicator + Stats */}
        <div className="flex items-center justify-around py-3">
          <BatteryIndicator
            percentage={vehicle?.currentBattery || 78}
            range={vehicle?.currentRange || 312}
            size={135}
            strokeWidth={10}
            isCharging={isCharging}
          />

          <div className="space-y-3">
            <div className="bg-[#070B19]/70 px-3.5 py-2 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Estimated Range
              </span>
              <span className="text-lg font-bold text-white font-mono">
                {vehicle?.currentRange || 312}{' '}
                <span className="text-xs font-normal text-slate-400">km</span>
              </span>
            </div>

            <div className="bg-[#070B19]/70 px-3.5 py-2 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Battery Health
              </span>
              <span className="text-sm font-semibold text-emerald-400 font-mono">
                {vehicle?.health || '98%'} Optimal
              </span>
            </div>
          </div>
        </div>

        {isCharging && (
          <div
            onClick={() => navigate('/live-charging')}
            className="mt-1 p-2.5 rounded-xl bg-[#00F5A0]/10 border border-[#00F5A0]/30 flex items-center justify-between cursor-pointer hover:bg-[#00F5A0]/15 transition-all"
          >
            <div className="flex items-center gap-2 text-xs text-[#00F5A0] font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#00F5A0] animate-ping" />
              <span>Charging in progress at Green Valley</span>
            </div>
            <span className="text-xs font-bold text-[#00F5A0] flex items-center">
              View Live <ChevronRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        )}
      </Card>

      {/* Quick Actions (4 Buttons) */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 gap-2.5">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={() => navigate(action.route)}
                className="relative flex items-center gap-3 p-3.5 rounded-2xl bg-[#0D1527] border border-white/5 hover:border-white/15 hover:bg-[#131E35] transition-all duration-200 text-left active:scale-[0.98]"
              >
                <div className={`p-2.5 rounded-xl ${action.bgColor} ${action.color} shrink-0`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block truncate">
                    {action.label}
                  </span>
                  <span className="text-[10px] text-slate-400">Tap to open</span>
                </div>

                {action.badge && (
                  <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-[#00F5A0] text-[#050811] text-[9px] font-extrabold uppercase">
                    {action.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Nearby Stations */}
      <div className="space-y-3 pb-2">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Nearby Stations
            </h3>
            <span className="text-[11px] text-slate-500">Fast chargers near you</span>
          </div>
          <button
            onClick={() => navigate('/stations')}
            className="text-xs font-semibold text-[#00F5A0] hover:underline flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* Station Cards */}
        <div className="space-y-3">
          {stations.slice(0, 2).map((station) => (
            <StationCard key={station.id} station={station} />
          ))}
        </div>
      </div>
    </div>
  );
};
