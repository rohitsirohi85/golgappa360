import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { UserLayout } from '../components/navigation/UserLayout';

// Phase 1: 19 User Mobile Production Screens
import { SplashScreen } from '../screens/SplashScreen';
import { OnboardingScreen } from '../screens/OnboardingScreen';
import { LoginScreen } from '../screens/LoginScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { HomeScreen } from '../screens/HomeScreen';
import { FindStationsScreen } from '../screens/FindStationsScreen';
import { StationDetailsScreen } from '../screens/StationDetailsScreen';
import { ChargerSelectionScreen } from '../screens/ChargerSelectionScreen';
import { SlotBookingScreen } from '../screens/SlotBookingScreen';
import { BookingConfirmationScreen } from '../screens/BookingConfirmationScreen';
import { MyBookingScreen } from '../screens/MyBookingScreen';
import { LiveChargingScreen } from '../screens/LiveChargingScreen';
import { ChargingCompletedScreen } from '../screens/ChargingCompletedScreen';
import { BillReceiptScreen } from '../screens/BillReceiptScreen';
import { ChargingHistoryScreen } from '../screens/ChargingHistoryScreen';
import { NotificationsScreen } from '../screens/NotificationsScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { VehicleManagementScreen } from '../screens/VehicleManagementScreen';
import { SettingsScreen } from '../screens/SettingsScreen';

export const UserRoutes = () => {
  return (
    <UserLayout>
      <Routes>
        {/* 1. Splash & Onboarding */}
        <Route path="/" element={<SplashScreen />} />
        <Route path="/splash" element={<SplashScreen />} />
        <Route path="/onboarding" element={<OnboardingScreen />} />

        {/* 2. Authentication */}
        <Route path="/login" element={<LoginScreen />} />
        <Route path="/register" element={<RegisterScreen />} />

        {/* 3. Main Dashboard & Discovery */}
        <Route path="/home" element={<HomeScreen />} />
        <Route path="/stations" element={<FindStationsScreen />} />
        <Route path="/station/:id" element={<StationDetailsScreen />} />

        {/* 4. Charger Selection & Slot Booking */}
        <Route
          path="/select-charger/:stationId/:chargerId"
          element={<ChargerSelectionScreen />}
        />
        <Route
          path="/slot-booking/:stationId/:chargerId"
          element={<SlotBookingScreen />}
        />
        <Route
          path="/booking-confirmation/:bookingId"
          element={<BookingConfirmationScreen />}
        />

        {/* 5. Booking Management */}
        <Route path="/bookings" element={<MyBookingScreen />} />

        {/* 6. Live Charging & Invoicing */}
        <Route path="/live-charging" element={<LiveChargingScreen />} />
        <Route path="/charging-complete" element={<ChargingCompletedScreen />} />
        <Route path="/bill" element={<BillReceiptScreen />} />
        <Route path="/history" element={<ChargingHistoryScreen />} />

        {/* 7. Alerts, Profile & Vehicle Settings */}
        <Route path="/notifications" element={<NotificationsScreen />} />
        <Route path="/profile" element={<ProfileScreen />} />
        <Route path="/vehicle-management" element={<VehicleManagementScreen />} />
        <Route path="/settings" element={<SettingsScreen />} />

        {/* /app alias */}
        <Route path="/app" element={<Navigate to="/home" replace />} />

        {/* Fallback to home */}
        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
    </UserLayout>
  );
};

export default UserRoutes;
