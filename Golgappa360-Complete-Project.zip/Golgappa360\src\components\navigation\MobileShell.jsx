import React from 'react';
import { UserLayout } from './UserLayout';

export const MobileShell = (props) => {
  return <UserLayout {...props} />;
};

export default MobileShell;
