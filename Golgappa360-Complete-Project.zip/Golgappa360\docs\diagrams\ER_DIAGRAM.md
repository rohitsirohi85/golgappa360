# EV SMART: Entity-Relationship (ER) Diagram & Data Schema
## Comprehensive Database Schema Design & Relational Mapping in MongoDB

---

## 1. Complete Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    USERS ||--o{ VEHICLES : "owns"
    USERS ||--o{ BOOKINGS : "places"
    USERS ||--o{ CHARGING_SESSIONS : "initiates"
    USERS ||--o{ TRANSACTIONS : "conducts"
    USERS ||--o{ NOTIFICATIONS : "receives"
    USERS ||--o{ REVIEWS : "writes"
    USERS ||--o{ AUDIT_LOGS : "triggers"

    STATIONS ||--|{ CHARGERS : "contains"
    STATIONS ||--o{ STATION_AMENITIES : "features"
    STATIONS ||--o{ REVIEWS : "receives"
    STATIONS ||--o{ TARIFFS : "governed_by"

    CHARGERS ||--o{ BOOKINGS : "reserved_in"
    CHARGERS ||--o{ CHARGING_SESSIONS : "executes"
    CHARGERS ||--o{ TELEMETRY : "generates"
    CHARGERS ||--o{ MAINTENANCE_ALERTS : "logs"
    CHARGERS ||--o{ ANOMALY_EVENTS : "flags"

    CHARGING_SESSIONS ||--|| INVOICES : "settled_by"
    CHARGING_SESSIONS ||--o{ TELEMETRY : "aggregates"
    TRANSACTIONS ||--o| INVOICES : "pays"

    USERS {
        ObjectId _id PK
        string email UK
        string passwordHash
        string fullName
        string phone
        string role "driver | operator | admin"
        number walletBalance
        date createdAt
        date updatedAt
    }

    VEHICLES {
        ObjectId _id PK
        ObjectId userId FK
        string make
        string model
        number batteryCapacityKWh
        string connectorType "Type 2 | CCS2"
        string licensePlate
    }

    STATIONS {
        ObjectId _id PK
        string name
        string address
        string city
        object location "GeoJSON Point [lng, lat]"
        string operatingHours
        number baseTariffPerKWh
        boolean isActive
    }

    CHARGERS {
        ObjectId _id PK
        ObjectId stationId FK
        string chargerIdentifier "CH-01"
        string connectorType "Type 2 | CCS2"
        number maxPowerKW
        string status "AVAILABLE | CHARGING | FAULTED | OFFLINE"
        string esp32MacAddress
        number firmwareVersion
        number totalOperatingHours
    }

    BOOKINGS {
        ObjectId _id PK
        ObjectId userId FK
        ObjectId chargerId FK
        ObjectId stationId FK
        date startTime
        date endTime
        string status "PENDING | CONFIRMED | CANCELLED | COMPLETED"
        number estimatedCost
    }

    CHARGING_SESSIONS {
        ObjectId _id PK
        ObjectId userId FK
        ObjectId chargerId FK
        ObjectId stationId FK
        date startTime
        date endTime
        number totalEnergyKWh
        number peakPowerKW
        number totalCost
        string status "ACTIVE | COMPLETED | EMERGENCY_STOPPED"
        string terminationReason
    }

    TELEMETRY {
        ObjectId _id PK
        ObjectId chargerId FK
        ObjectId sessionId FK
        date timestamp
        number voltageV
        number currentA
        number powerKW
        number energyTotalKWh
        number temperatureC
        number powerFactor
        number frequencyHz
    }

    INVOICES {
        ObjectId _id PK
        ObjectId sessionId FK UK
        ObjectId userId FK
        string invoiceNumber UK
        number energyDeliveredKWh
        number baseRatePerKWh
        number dynamicMultiplier
        number energySubtotal
        number platformFee
        number taxGST
        number grandTotal
        string paymentStatus "PAID | PENDING"
        date issuedAt
    }

    TRANSACTIONS {
        ObjectId _id PK
        ObjectId userId FK
        ObjectId invoiceId FK
        string transactionType "WALLET_TOPUP | SESSION_DEBIT | REFUND"
        number amount
        number balanceAfter
        string gatewayReference
        string status "SUCCESS | FAILED"
        date createdAt
    }

    TARIFFS {
        ObjectId _id PK
        ObjectId stationId FK
        string name
        number baseRatePerKWh
        number peakMultiplier
        number offPeakMultiplier
        array peakWindows "[17-22]"
        array offPeakWindows "[0-6]"
        boolean aiDynamicPricingEnabled
    }

    MAINTENANCE_ALERTS {
        ObjectId _id PK
        ObjectId chargerId FK
        string severity "INFO | WARNING | CRITICAL"
        string alertCode "OVER_TEMP | RELAY_DEGRADATION"
        string description
        number healthScore
        boolean isResolved
        date resolvedAt
    }

    ANOMALY_EVENTS {
        ObjectId _id PK
        ObjectId chargerId FK
        ObjectId telemetryId FK
        date timestamp
        number anomalyScore
        string detectedAnomalyType "VOLTAGE_SAG | HARMONIC_SPIKE"
        object telemetrySnapshot
    }

    AUDIT_LOGS {
        ObjectId _id PK
        ObjectId actorId FK
        string actorRole
        string ipAddress
        string action "TARIFF_UPDATE | REMOTE_STOP | USER_DEACTIVATE"
        string targetResource
        object stateDelta
        string integrityHash
        date timestamp
    }

    NOTIFICATIONS {
        ObjectId _id PK
        ObjectId userId FK
        string title
        string message
        string channel "IN_APP | PUSH | SMS"
        boolean isRead
        date createdAt
    }

    REVIEWS {
        ObjectId _id PK
        ObjectId userId FK
        ObjectId stationId FK
        number rating "1 to 5"
        string comment
        date createdAt
    }

    STATION_AMENITIES {
        ObjectId _id PK
        ObjectId stationId FK
        boolean hasRestroom
        boolean hasCafe
        boolean hasWiFi
        boolean has24HourSecurity
        boolean isCoveredParking
    }
```

---

## 2. Key Database Indexes & Optimizations

1. **Station Geolocation Index:**  
   `stations.createIndex({ location: "2dsphere" })` — Accelerates radius distance geospatial queries for nearby station discovery.
2. **Compound Charger Telemetry Index:**  
   `telemetry.createIndex({ chargerId: 1, timestamp: -1 })` — Optimizes sub-second retrieval of the latest streaming electrical readings.
3. **Session Active Filtering Index:**  
   `charging_sessions.createIndex({ chargerId: 1, status: 1 })` — Ensures instantaneous detection of active sessions during incoming telemetry parsing.
4. **Booking Conflict Interlock Index:**  
   `bookings.createIndex({ chargerId: 1, startTime: 1, endTime: 1 })` — Prevents overbooking race conditions across concurrent client requests.
5. **Audit Trail Chronological Index:**  
   `audit_logs.createIndex({ timestamp: -1 })` — Accelerates security compliance inspection and incident forensics.
