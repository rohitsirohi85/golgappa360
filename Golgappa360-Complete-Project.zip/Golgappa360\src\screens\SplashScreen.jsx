import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, ArrowRight } from 'lucide-react';

export const SplashScreen = () => {
  const navigate = useNavigate();
  const [pulseLevel, setPulseLevel] = useState(0);

  useEffect(() => {
    // Pulse animation counter
    const timer = setInterval(() => {
      setPulseLevel((p) => (p >= 100 ? 0 : p + 25));
    }, 400);

    // Auto navigate after 2.5 seconds (or user can tap immediately)
    const navTimer = setTimeout(() => {
      navigate('/onboarding');
    }, 2800);

    return () => {
      clearInterval(timer);
      clearTimeout(navTimer);
    };
  }, [navigate]);

  return (
    <div
      onClick={() => navigate('/onboarding')}
      className="relative min-h-[100dvh] w-full flex flex-col items-center justify-between p-6 text-center bg-gradient-to-b from-[#050811] via-[#070B19] to-[#0A1224] select-none cursor-pointer"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-[#00F5A0]/10 blur-3xl pointer-events-none" />

      {/* Top Tag */}
      <div className="pt-8">
        <span className="text-[11px] font-mono tracking-widest uppercase text-slate-400 border border-white/10 px-3 py-1 rounded-full bg-white/5">
          AI & IoT Connected
        </span>
      </div>

      {/* Center Branding & Logo */}
      <div className="flex flex-col items-center">
        {/* Glowing Logo Icon */}
        <div className="relative mb-6">
          {/* Subtle charging ripple ring */}
          <div className="absolute -inset-4 rounded-full border-2 border-[#00F5A0]/20 animate-ping opacity-75" />
          <div className="absolute -inset-8 rounded-full border border-[#00E5FF]/10 animate-pulse" />

          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-[#0D182E] to-[#142345] border border-[#00F5A0]/40 flex items-center justify-center shadow-[0_0_40px_rgba(0,245,160,0.35)]">
            <Zap className="w-12 h-12 text-[#00F5A0] fill-[#00F5A0] drop-shadow-[0_0_15px_#00F5A0]" />
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-white mb-2">
          EV <span className="text-[#00F5A0]">Smart</span>
        </h1>

        <p className="text-sm font-medium text-slate-400 tracking-wide">
          Charge Smarter. Drive Further.
        </p>

        {/* Subtle charging progress bar */}
        <div className="w-40 h-1.5 bg-[#131E35] rounded-full mt-8 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#00E5FF] to-[#00F5A0] transition-all duration-300 rounded-full"
            style={{ width: `${Math.max(15, pulseLevel)}%` }}
          />
        </div>
      </div>

      {/* Bottom Action / Skip */}
      <div className="w-full pb-4">
        <button
          onClick={() => navigate('/onboarding')}
          className="flex items-center justify-center gap-2 mx-auto text-xs font-semibold text-slate-400 hover:text-[#00F5A0] transition-colors py-2 px-4 rounded-xl hover:bg-white/5"
        >
          <span>Tap to continue</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
