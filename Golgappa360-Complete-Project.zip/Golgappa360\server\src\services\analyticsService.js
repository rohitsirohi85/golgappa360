/**
 * Golgappa360 - Centralized Business Analytics Service
 * 
 * Implements dual-engine architecture:
 * 1. Primary Engine: MySQL 8.0 with parameterized queries & normalized views
 * 2. High-Fidelity Fallback: Seeded in-memory synthetic data engine (Phase 2)
 * 
 * Enforces identical accounting rules across both engines:
 * - Net Revenue = Gross Sales − Discounts
 * - Gross Profit = Net Revenue − COGS
 * - Gross Margin (%) = (Gross Profit ÷ Net Revenue) × 100
 * - Estimated Operating Profit = Gross Profit − Applicable Operating Expenses
 */

import { executeQuery, getDbStatus } from '../config/db.js';
import * as syntheticStore from '../data/syntheticStore.js';
import * as analytics from '../analytics/golgappaAnalytics.js';

export class AnalyticsService {
  /**
   * Helper to check if MySQL is live and ready
   */
  static isMySQLActive() {
    return getDbStatus().isConnected;
  }

  /**
   * 1. Dashboard Summary KPIs
   */
  static async getDashboardSummary({ range = '30d', startDate, endDate, productId = 'all' }) {
    const dates = startDate && endDate ? { startDate, endDate, label: `${startDate} to ${endDate}` } : analytics.resolveDateRange(range);

    if (this.isMySQLActive()) {
      try {
        let sql = `
          SELECT 
            COUNT(DISTINCT s.sale_id) AS totalOrders,
            COALESCE(SUM(si.quantity_plates), 0) AS totalPlatesSold,
            COALESCE(SUM(si.quantity_plates * si.unit_price), 0.00) AS grossRevenue,
            COALESCE(SUM(s.discount), 0.00) AS totalDiscounts,
            COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0.00) AS totalRevenue,
            COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00) AS cogs,
            COALESCE(
              (SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - 
              SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0.00
            ) AS grossProfit
          FROM sales s
          JOIN sale_items si ON s.sale_id = si.sale_id
          JOIN products p ON si.product_id = p.product_id
          WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?
        `;
        const params = [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`];

        if (productId && productId !== 'all') {
          sql += ` AND si.product_id = ?`;
          params.push(productId);
        }

        const [kpiRow] = await executeQuery(sql, params);

        // Fetch operating expenses in period
        const [expRow] = await executeQuery(
          `SELECT COALESCE(SUM(amount), 0.00) AS totalExpenses FROM daily_expenses WHERE expense_date >= ? AND expense_date <= ?`,
          [dates.startDate, dates.endDate]
        );

        // Fetch waste cost in period
        const [wasteRow] = await executeQuery(
          `SELECT COALESCE(SUM(t.quantity * i.unit_cost), 0.00) AS totalWasteCost, COALESCE(SUM(t.quantity), 0) AS totalWasteQty
           FROM inventory_transactions t
           JOIN ingredients i ON t.ingredient_id = i.ingredient_id
           WHERE t.transaction_type = 'WASTE' AND t.transaction_date >= ? AND t.transaction_date <= ?`,
          [dates.startDate, dates.endDate]
        );

        const netRev = Number(kpiRow.totalRevenue) || 0;
        const grossProf = Number(kpiRow.grossProfit) || 0;
        const exp = Number(expRow.totalExpenses) || 0;
        const wasteCost = Number(wasteRow.totalWasteCost) || 0;
        const plates = Number(kpiRow.totalPlatesSold) || 0;
        const orders = Number(kpiRow.totalOrders) || 0;

        return {
          source: 'mysql',
          kpis: {
            grossRevenue: Number(kpiRow.grossRevenue) || 0,
            totalDiscounts: Number(kpiRow.totalDiscounts) || 0,
            totalRevenue: netRev,
            totalPlatesSold: plates,
            totalOrders: orders,
            aov: analytics.safeDivide(netRev, orders),
            asp: analytics.safeDivide(netRev, plates),
            cogs: Number(kpiRow.cogs) || 0,
            grossProfit: grossProf,
            grossMarginPct: Number((analytics.safeDivide(grossProf, netRev) * 100).toFixed(1)),
            operatingExpenses: exp,
            operatingProfit: Number((grossProf - exp).toFixed(2)),
            operatingMarginPct: Number((analytics.safeDivide(grossProf - exp, netRev) * 100).toFixed(1)),
            totalWasteCost: wasteCost,
            totalWasteQty: Number(wasteRow.totalWasteQty) || 0,
            wasteRatePct: Number((analytics.safeDivide(wasteCost, netRev) * 100).toFixed(1))
          },
          filterMeta: { ...dates, productId }
        };
      } catch (err) {
        console.warn('[AnalyticsService MySQL fallback note]', err.message);
      }
    }

    // Fallback: In-memory Synthetic Store
    const overview = syntheticStore.getOverviewMetrics(range, productId);
    return {
      source: 'synthetic_store',
      kpis: overview.kpis,
      filterMeta: { ...dates, productId }
    };
  }

  /**
   * 2. Sales Trend (Daily / Weekly / Monthly time series)
   */
  static async getSalesTrend({ range = '30d', startDate, endDate, productId = 'all', granularity = 'daily' }) {
    const dates = startDate && endDate ? { startDate, endDate } : analytics.resolveDateRange(range);

    if (this.isMySQLActive()) {
      try {
        let sql = `
          SELECT 
            DATE(s.sale_datetime) AS fullDate,
            DAYNAME(s.sale_datetime) AS dayOfWeek,
            COUNT(DISTINCT s.sale_id) AS orders,
            SUM(si.quantity_plates) AS plates,
            ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS revenue,
            ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS cogs,
            ROUND((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS grossProfit
          FROM sales s
          JOIN sale_items si ON s.sale_id = si.sale_id
          JOIN products p ON si.product_id = p.product_id
          WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?
        `;
        const params = [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`];
        if (productId && productId !== 'all') {
          sql += ` AND si.product_id = ?`;
          params.push(productId);
        }
        sql += ` GROUP BY DATE(s.sale_datetime), DAYNAME(s.sale_datetime) ORDER BY fullDate ASC`;

        const rows = await executeQuery(sql, params);
        return {
          source: 'mysql',
          trend: rows.map(r => ({
            ...r,
            date: String(r.fullDate).slice(5),
            dayOfWeek: String(r.dayOfWeek).slice(0, 3)
          }))
        };
      } catch (err) {
        console.warn('[AnalyticsService MySQL trend fallback note]', err.message);
      }
    }

    const overview = syntheticStore.getOverviewMetrics(range, productId);
    return {
      source: 'synthetic_store',
      trend: overview.dailySalesChart
    };
  }

  /**
   * 3. Hourly Sales Profile
   */
  static async getHourlySales({ range = '30d', startDate, endDate, productId = 'all' }) {
    const dates = startDate && endDate ? { startDate, endDate } : analytics.resolveDateRange(range);

    if (this.isMySQLActive()) {
      try {
        let sql = `
          SELECT 
            EXTRACT(HOUR FROM s.sale_datetime) AS hour24,
            COUNT(DISTINCT s.sale_id) AS orders,
            SUM(si.quantity_plates) AS plates,
            ROUND(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 2) AS revenue,
            ROUND(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 2) AS cogs
          FROM sales s
          JOIN sale_items si ON s.sale_id = si.sale_id
          JOIN products p ON si.product_id = p.product_id
          WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?
        `;
        const params = [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`];
        if (productId && productId !== 'all') {
          sql += ` AND si.product_id = ?`;
          params.push(productId);
        }
        sql += ` GROUP BY EXTRACT(HOUR FROM s.sale_datetime) ORDER BY hour24 ASC`;

        const rows = await executeQuery(sql, params);
        const mapped = rows.map(r => {
          const h = r.hour24;
          const displayH = h > 12 ? h - 12 : h;
          const period = h >= 12 ? 'PM' : 'AM';
          let intensity = 'Standard Rush';
          if (h === 18) intensity = 'Peak Commuter Rush';
          else if (h === 19) intensity = 'Peak Family Chaat';
          return {
            ...r,
            hour: `${displayH}:00 ${period}`,
            footfallIntensity: intensity
          };
        });
        return { source: 'mysql', hourly: mapped };
      } catch (err) {
        console.warn('[AnalyticsService MySQL hourly fallback note]', err.message);
      }
    }

    const overview = syntheticStore.getOverviewMetrics(range, productId);
    return {
      source: 'synthetic_store',
      hourly: overview.hourlySalesProfile
    };
  }

  /**
   * 4. Sales Orders with Pagination & Filtering
   */
  static async getSalesList({ page = 1, limit = 50, startDate, endDate, productId = 'all', paymentMethod }) {
    const offset = (Number(page) - 1) * Number(limit);
    const dates = startDate && endDate ? { startDate, endDate } : analytics.resolveDateRange('30d');

    if (this.isMySQLActive()) {
      try {
        let countSql = `SELECT COUNT(DISTINCT s.sale_id) AS total FROM sales s JOIN sale_items si ON s.sale_id = si.sale_id WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?`;
        let dataSql = `
          SELECT 
            s.sale_id,
            s.sale_datetime,
            s.payment_method,
            s.discount,
            si.product_id,
            p.product_name,
            si.quantity_plates,
            si.unit_price,
            ROUND((si.quantity_plates * si.unit_price) - s.discount, 2) AS net_amount,
            ROUND(si.quantity_plates * p.ingredient_cost_per_plate, 2) AS cogs,
            ROUND(((si.quantity_plates * si.unit_price) - s.discount) - (si.quantity_plates * p.ingredient_cost_per_plate), 2) AS gross_profit
          FROM sales s
          JOIN sale_items si ON s.sale_id = si.sale_id
          JOIN products p ON si.product_id = p.product_id
          WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?
        `;
        const params = [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`];

        if (productId && productId !== 'all') {
          countSql += ` AND si.product_id = ?`;
          dataSql += ` AND si.product_id = ?`;
          params.push(productId);
        }
        if (paymentMethod && paymentMethod !== 'all') {
          countSql += ` AND s.payment_method = ?`;
          dataSql += ` AND s.payment_method = ?`;
          params.push(paymentMethod);
        }

        const [countRes] = await executeQuery(countSql, params);
        const total = countRes ? countRes.total : 0;

        dataSql += ` ORDER BY s.sale_datetime DESC LIMIT ? OFFSET ?`;
        const listParams = [...params, Number(limit), Number(offset)];
        const rows = await executeQuery(dataSql, listParams);

        return {
          source: 'mysql',
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total,
            totalPages: Math.ceil(total / Number(limit))
          },
          sales: rows
        };
      } catch (err) {
        console.warn('[AnalyticsService MySQL sales list fallback note]', err.message);
      }
    }

    const rawSales = syntheticStore.getRawDatasets().sales;
    const filtered = analytics.filterSales(rawSales, {
      startDate: dates.startDate,
      endDate: dates.endDate,
      productId
    }).filter(s => !paymentMethod || paymentMethod === 'all' || s.payment_method === paymentMethod);

    const paged = filtered.slice(offset, offset + Number(limit));
    const productsMap = new Map(syntheticStore.getRawDatasets().products.map(p => [p.product_id, p]));

    return {
      source: 'synthetic_store',
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: filtered.length,
        totalPages: Math.ceil(filtered.length / Number(limit))
      },
      sales: paged.map(s => {
        const prod = productsMap.get(s.product_id);
        const netAmt = (s.quantity_plates * s.unit_price) - s.discount;
        const cogs = s.quantity_plates * (prod ? prod.ingredient_cost_per_plate : 0);
        return {
          sale_id: s.sale_id,
          sale_datetime: s.sale_datetime,
          payment_method: s.payment_method,
          discount: s.discount,
          product_id: s.product_id,
          product_name: prod ? prod.product_name : s.product_id,
          quantity_plates: s.quantity_plates,
          unit_price: s.unit_price,
          net_amount: Number(netAmt.toFixed(2)),
          cogs: Number(cogs.toFixed(2)),
          gross_profit: Number((netAmt - cogs).toFixed(2))
        };
      })
    };
  }

  /**
   * 5. Product Performance Ranking
   */
  static async getProductPerformance({ range = '180d', startDate, endDate }) {
    const dates = startDate && endDate ? { startDate, endDate } : analytics.resolveDateRange(range);

    if (this.isMySQLActive()) {
      try {
        const sql = `
          SELECT 
            p.product_id,
            p.product_name,
            p.category,
            p.selling_price,
            p.ingredient_cost_per_plate,
            ROUND(p.selling_price - p.ingredient_cost_per_plate, 2) AS unit_margin,
            COALESCE(SUM(si.quantity_plates), 0) AS plates_sold,
            ROUND(COALESCE(SUM(si.quantity_plates * si.unit_price), 0), 2) AS gross_revenue,
            ROUND(COALESCE(SUM(s.discount), 0), 2) AS discounts,
            ROUND(COALESCE(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0), 2) AS net_revenue,
            ROUND(COALESCE(SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0), 2) AS cogs,
            ROUND(COALESCE((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate), 0), 2) AS gross_profit,
            ROUND(
              COALESCE(
                (((SUM(si.quantity_plates * si.unit_price) - SUM(s.discount)) - SUM(si.quantity_plates * p.ingredient_cost_per_plate)) /
                NULLIF(SUM(si.quantity_plates * si.unit_price) - SUM(s.discount), 0)) * 100, 
                0.0
              ), 1
            ) AS gross_margin_pct
          FROM products p
          LEFT JOIN sale_items si ON p.product_id = si.product_id
          LEFT JOIN sales s ON si.sale_id = s.sale_id AND s.sale_datetime >= ? AND s.sale_datetime <= ?
          GROUP BY p.product_id, p.product_name, p.category, p.selling_price, p.ingredient_cost_per_plate
          ORDER BY net_revenue DESC
        `;
        const rows = await executeQuery(sql, [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`]);
        return { source: 'mysql', products: rows };
      } catch (err) {
        console.warn('[AnalyticsService MySQL product performance fallback note]', err.message);
      }
    }

    const sa = syntheticStore.getSalesAnalytics(range);
    return {
      source: 'synthetic_store',
      products: sa.productPerformance
    };
  }

  /**
   * 6. Payment Breakdown (UPI vs Cash)
   */
  static async getPaymentBreakdown({ range = '30d', startDate, endDate }) {
    const dates = startDate && endDate ? { startDate, endDate } : analytics.resolveDateRange(range);

    if (this.isMySQLActive()) {
      try {
        const sql = `
          SELECT 
            s.payment_method,
            COUNT(s.sale_id) AS orders,
            ROUND(SUM((si.quantity_plates * si.unit_price) - s.discount), 2) AS revenue
          FROM sales s
          JOIN sale_items si ON s.sale_id = si.sale_id
          WHERE s.sale_datetime >= ? AND s.sale_datetime <= ?
          GROUP BY s.payment_method
          ORDER BY revenue DESC
        `;
        const rows = await executeQuery(sql, [`${dates.startDate} 00:00:00`, `${dates.endDate} 23:59:59`]);
        const totalOrders = rows.reduce((acc, r) => acc + Number(r.orders), 0);
        const totalRev = rows.reduce((acc, r) => acc + Number(r.revenue), 0);

        const mapped = rows.map(r => ({
          method: r.payment_method === 'UPI' ? 'UPI (QR & Apps)' : 'Cash Currency',
          rawMethod: r.payment_method,
          orders: Number(r.orders),
          revenue: Number(r.revenue),
          countSharePct: Number((analytics.safeDivide(Number(r.orders), totalOrders) * 100).toFixed(1)),
          revenueSharePct: Number((analytics.safeDivide(Number(r.revenue), totalRev) * 100).toFixed(1)),
          color: r.payment_method === 'UPI' ? '#A7D78A' : '#EAB64B'
        }));

        return { source: 'mysql', paymentBreakdown: mapped };
      } catch (err) {
        console.warn('[AnalyticsService MySQL payment breakdown fallback note]', err.message);
      }
    }

    const sa = syntheticStore.getSalesAnalytics(range);
    return {
      source: 'synthetic_store',
      paymentBreakdown: sa.paymentBreakdown
    };
  }

  /**
   * 7. Products Catalog
   */
  static async getProducts({ category }) {
    if (this.isMySQLActive()) {
      try {
        let sql = `SELECT * FROM products`;
        const params = [];
        if (category && category !== 'All') {
          sql += ` WHERE category = ?`;
          params.push(category);
        }
        sql += ` ORDER BY product_id ASC`;
        const rows = await executeQuery(sql, params);
        return { source: 'mysql', products: rows };
      } catch (err) {
        console.warn('[AnalyticsService MySQL products catalog fallback note]', err.message);
      }
    }

    const raw = syntheticStore.getRawDatasets().products;
    const filtered = category && category !== 'All' ? raw.filter(p => p.category === category) : raw;
    return { source: 'synthetic_store', products: filtered };
  }

  /**
   * 8. Single Product Details
   */
  static async getProductById(id) {
    if (this.isMySQLActive()) {
      try {
        const [prod] = await executeQuery(`SELECT * FROM products WHERE product_id = ?`, [id]);
        if (prod) {
          const [salesSummary] = await executeQuery(
            `SELECT SUM(si.quantity_plates) AS total_sold, ROUND(SUM(si.quantity_plates * si.unit_price), 2) AS total_revenue
             FROM sale_items si WHERE si.product_id = ?`,
            [id]
          );
          return { source: 'mysql', product: { ...prod, ...salesSummary } };
        }
      } catch (err) {
        console.warn('[AnalyticsService MySQL product by id fallback note]', err.message);
      }
    }

    const raw = syntheticStore.getRawDatasets().products;
    const found = raw.find(p => p.product_id === id);
    return { source: 'synthetic_store', product: found || null };
  }

  /**
   * 9. Inventory Status & Runway
   */
  static async getInventorySummary() {
    if (this.isMySQLActive()) {
      try {
        const rows = await executeQuery(`SELECT * FROM vw_inventory_status ORDER BY current_stock ASC`);
        const totalValue = rows.reduce((acc, r) => acc + (Number(r.inventory_value) || 0), 0);
        const lowStockCount = rows.filter(r => r.stock_status === 'Low' || r.stock_status === 'Critical').length;
        return {
          source: 'mysql',
          ingredients: rows.map(r => ({
            id: r.ingredient_id,
            code: r.ingredient_id,
            name: r.ingredient_name,
            unit: r.unit,
            cost_per_unit: Number(r.unit_cost),
            minimum_threshold: Number(r.reorder_level),
            current_stock: Number(r.current_stock),
            inventory_value: Number(r.inventory_value),
            status: r.stock_status,
            daysRunway: Math.max(1, Math.round(Number(r.current_stock) / (Number(r.total_consumed) / 182 || 1)))
          })),
          totalInventoryValue: Number(totalValue.toFixed(2)),
          lowStockCount
        };
      } catch (err) {
        console.warn('[AnalyticsService MySQL inventory summary fallback note]', err.message);
      }
    }

    const inv = syntheticStore.getInventoryData();
    return {
      source: 'synthetic_store',
      ingredients: inv.ingredients,
      totalInventoryValue: inv.totalInventoryValue,
      lowStockCount: inv.lowStockCount
    };
  }

  /**
   * 10. Inventory Transactions Ledger (Paginated)
   */
  static async getInventoryTransactions({ page = 1, limit = 50, ingredientId, type, startDate, endDate }) {
    const offset = (Number(page) - 1) * Number(limit);

    if (this.isMySQLActive()) {
      try {
        let countSql = `SELECT COUNT(*) AS total FROM inventory_transactions WHERE 1=1`;
        let dataSql = `
          SELECT 
            t.transaction_id,
            t.transaction_date,
            t.ingredient_id,
            i.ingredient_name,
            t.transaction_type,
            t.quantity,
            i.unit,
            ROUND(t.quantity * i.unit_cost, 2) AS transaction_cost,
            t.reference_id
          FROM inventory_transactions t
          JOIN ingredients i ON t.ingredient_id = i.ingredient_id
          WHERE 1=1
        `;
        const params = [];

        if (ingredientId) {
          countSql += ` AND t.ingredient_id = ?`;
          dataSql += ` AND t.ingredient_id = ?`;
          params.push(ingredientId);
        }
        if (type) {
          countSql += ` AND t.transaction_type = ?`;
          dataSql += ` AND t.transaction_type = ?`;
          params.push(type);
        }
        if (startDate && endDate) {
          countSql += ` AND t.transaction_date >= ? AND t.transaction_date <= ?`;
          dataSql += ` AND t.transaction_date >= ? AND t.transaction_date <= ?`;
          params.push(startDate, endDate);
        }

        const [countRes] = await executeQuery(countSql, params);
        const total = countRes ? countRes.total : 0;

        dataSql += ` ORDER BY t.transaction_date DESC, t.transaction_id DESC LIMIT ? OFFSET ?`;
        const listParams = [...params, Number(limit), Number(offset)];
        const rows = await executeQuery(dataSql, listParams);

        return {
          source: 'mysql',
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total,
            totalPages: Math.ceil(total / Number(limit))
          },
          transactions: rows
        };
      } catch (err) {
        console.warn('[AnalyticsService MySQL inventory transactions fallback note]', err.message);
      }
    }

    const raw = syntheticStore.getRawDatasets().inventoryTransactions;
    const ingMap = new Map(syntheticStore.getRawDatasets().ingredients.map(i => [i.ingredient_id, i]));

    let filtered = raw;
    if (ingredientId) filtered = filtered.filter(t => t.ingredient_id === ingredientId);
    if (type) filtered = filtered.filter(t => t.transaction_type === type);
    if (startDate && endDate) filtered = filtered.filter(t => t.transaction_date >= startDate && t.transaction_date <= endDate);

    const paged = filtered.slice(offset, offset + Number(limit));

    return {
      source: 'synthetic_store',
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: filtered.length,
        totalPages: Math.ceil(filtered.length / Number(limit))
      },
      transactions: paged.map(t => {
        const ing = ingMap.get(t.ingredient_id);
        return {
          transaction_id: t.transaction_id,
          transaction_date: t.transaction_date,
          ingredient_id: t.ingredient_id,
          ingredient_name: ing ? ing.ingredient_name : t.ingredient_id,
          transaction_type: t.transaction_type,
          quantity: t.quantity,
          unit: ing ? ing.unit : '',
          transaction_cost: Number(((t.quantity || 0) * (ing ? ing.unit_cost : 0)).toFixed(2)),
          reference_id: t.reference_id
        };
      })
    };
  }

  /**
   * 11. Waste Analysis Summary
   */
  static async getWasteSummary({ range = '180d' }) {
    const wst = syntheticStore.getWasteData(range);
    return {
      source: this.isMySQLActive() ? 'mysql_hybrid' : 'synthetic_store',
      ...wst
    };
  }
}
