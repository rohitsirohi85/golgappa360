import React, { useState, useMemo } from 'react';
import { RECENT_MEAL_RECORDS } from '../../data/mockWasteData';
import { StatusBadge } from '../common/StatusBadge';
import { Search, Filter, ArrowUpDown, ChevronRight, Utensils, RefreshCw } from 'lucide-react';
import { EmptyState } from '../common/EmptyState';

export const RecentMealsTable = ({ records: propRecords, onRecordClick, isLoading, onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [mealFilter, setMealFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortField, setSortField] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');

  // Normalize records whether from backend or fallback mock
  const rawRecords = propRecords && propRecords.length > 0 ? propRecords : RECENT_MEAL_RECORDS;

  const normalizedRecords = useMemo(() => {
    return rawRecords.map((r) => {
      const id = r.record_id || r.id;
      const date = r.date;
      const mealType = r.meal_type ? r.meal_type.charAt(0).toUpperCase() + r.meal_type.slice(1) : r.mealType;
      const menu = r.menu || r.menu_category ? (r.menu || r.menu_category.replace('_', ' ').toUpperCase()) : 'Standard Meal';
      const headcount = r.expected_attendance || r.actualHeadcount || r.attendance || 800;
      const registered = r.registeredStudents || 1000;
      const preparedKg = r.food_prepared_kg !== undefined ? r.food_prepared_kg : r.preparedKg;
      const wastedKg = r.food_waste_kg !== undefined ? r.food_waste_kg : r.wastedKg;
      const wastePct = r.food_waste_pct !== undefined ? r.food_waste_pct : r.wastePct;
      const weather = r.weather_condition || r.weather || 'Clear';
      
      let status = 'optimal';
      if (wastePct > 13.0) status = 'excessive';
      else if (wastePct > 10.0) status = 'moderate';

      return {
        id,
        date,
        mealType,
        menu,
        actualHeadcount: headcount,
        registeredStudents: registered,
        preparedKg,
        wastedKg,
        wastePct,
        weather,
        status,
        raw: r,
      };
    });
  }, [rawRecords]);

  const filteredRecords = useMemo(() => {
    return normalizedRecords.filter((rec) => {
      const matchesSearch =
        rec.menu.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.weather.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesMeal = mealFilter === 'All' || rec.mealType.toLowerCase() === mealFilter.toLowerCase();
      const matchesStatus = statusFilter === 'All' || rec.status === statusFilter;

      return matchesSearch && matchesMeal && matchesStatus;
    }).sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (sortDirection === 'asc') {
        return valA > valB ? 1 : -1;
      } else {
        return valA < valB ? 1 : -1;
      }
    });
  }, [normalizedRecords, searchTerm, mealFilter, statusFilter, sortField, sortDirection]);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  return (
    <div className="rounded-xl bg-white border border-[#E4EAE5] shadow-xs overflow-hidden">
      {/* Table Header and Controls */}
      <div className="p-5 border-b border-[#E4EAE5] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
              <Utensils className="w-4 h-4 text-[#16865B]" />
              Recent Meal Telemetry & Records
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                Backend Integrated
              </span>
            </h3>
            <p className="text-xs text-[#77847C] mt-0.5">
              Service records showing prepared batch weight, student turnout, and waste ratios from /api/data/records
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {onRefresh && (
              <button
                onClick={onRefresh}
                disabled={isLoading}
                className="p-1.5 rounded-lg border border-[#E4EAE5] bg-[#F8FAF8] text-[#77847C] hover:text-[#16865B] transition-colors cursor-pointer"
                title="Refresh records from backend"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#16865B]' : ''}`} />
              </button>
            )}
            <span className="text-xs font-mono text-[#77847C]">
              Showing {filteredRecords.length} records
            </span>
          </div>
        </div>

        {/* Filters and Search Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#77847C]" />
            <input
              type="text"
              placeholder="Search by menu (e.g., Rice, Curry, Dosa) or record ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#25332D] placeholder-[#77847C] focus:outline-none focus:border-[#16865B] transition-colors"
            />
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <Filter className="w-3.5 h-3.5 text-[#77847C]" />
              <span className="text-[#77847C] text-[11px]">Meal:</span>
              <select
                value={mealFilter}
                onChange={(e) => setMealFilter(e.target.value)}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Meals</option>
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Statuses</option>
                <option value="optimal">Optimal (&lt;10%)</option>
                <option value="moderate">Moderate (10-13%)</option>
                <option value="excessive">Excessive (&gt;13%)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Table Content */}
      {filteredRecords.length === 0 ? (
        <div className="p-8">
          <EmptyState
            title="No Matching Meal Records"
            description="No records matched your filter or search query. Try clearing filters or searching another keyword."
            actionLabel="Clear Filters"
            onAction={() => {
              setSearchTerm('');
              setMealFilter('All');
              setStatusFilter('All');
            }}
          />
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#E4EAE5] bg-[#F8FAF8] text-[#77847C] uppercase text-[11px] font-medium tracking-wider">
                <th
                  onClick={() => handleSort('date')}
                  className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Date & Meal</span>
                    <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                  </div>
                </th>
                <th className="py-3 px-4">Menu Items</th>
                <th
                  onClick={() => handleSort('actualHeadcount')}
                  className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Headcount</span>
                    <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('preparedKg')}
                  className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Prep (kg)</span>
                    <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('wastedKg')}
                  className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Waste (kg)</span>
                    <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('wastePct')}
                  className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Waste %</span>
                    <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Efficiency Status</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF2EF]">
              {filteredRecords.map((record) => (
                <tr
                  key={record.id}
                  className="hover:bg-[#F8FAF8] transition-colors group cursor-default"
                >
                  <td className="py-3.5 px-4 font-medium text-[#25332D] whitespace-nowrap">
                    <div className="flex flex-col">
                      <span className="font-mono text-[#25332D]">{record.date}</span>
                      <span className="text-[11px] text-[#16865B] font-semibold">{record.mealType}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-[#25332D] max-w-xs truncate" title={record.menu}>
                    <div className="font-normal truncate">{record.menu}</div>
                    <span className="text-[10px] text-[#77847C] font-mono">{record.weather}</span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-[#25332D] whitespace-nowrap">
                    <span className="text-[#25332D] font-medium">{record.actualHeadcount}</span>
                    <span className="text-[#77847C] text-[10px] ml-1">students</span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-[#25332D] whitespace-nowrap">
                    {record.preparedKg} kg
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-semibold text-[#B91C1C] whitespace-nowrap">
                    {record.wastedKg} kg
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold whitespace-nowrap">
                    <span
                      className={
                        record.wastePct > 13
                          ? 'text-[#B91C1C]'
                          : record.wastePct > 10
                          ? 'text-[#D97706]'
                          : 'text-[#16865B]'
                      }
                    >
                      {record.wastePct}%
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center whitespace-nowrap">
                    <StatusBadge status={record.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => onRecordClick && onRecordClick(record)}
                      className="p-1 rounded text-[#77847C] hover:text-[#16865B] hover:bg-[#E9F6EE] transition-colors cursor-pointer"
                      title="Inspect record details"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Table Footer */}
      <div className="p-3 bg-[#F8FAF8] border-t border-[#E4EAE5] flex flex-wrap items-center justify-between text-[11px] text-[#77847C] px-5">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#16865B]"></span> Optimal (&lt;10%)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#D97706]"></span> Moderate (10-13%)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#DC2626]"></span> Excessive (&gt;13%)
          </span>
        </div>
        <span className="text-[#77847C] font-mono">
          Connected to FastAPI /api/data/records
        </span>
      </div>
    </div>
  );
};
