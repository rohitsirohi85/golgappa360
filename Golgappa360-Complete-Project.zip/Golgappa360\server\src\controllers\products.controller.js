import { AnalyticsService } from '../services/analyticsService.js';

export async function getProducts(req, res, next) {
  try {
    const { category } = req.query;
    const result = await AnalyticsService.getProducts({ category });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}

export async function getProductById(req, res, next) {
  try {
    const { id } = req.params;
    const result = await AnalyticsService.getProductById(id);
    if (!result.product) {
      return res.status(404).json({
        success: false,
        error: `Product with ID '${id}' not found.`
      });
    }
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}
