import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Calendar,
  Users,
  Scale,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  RefreshCw,
  HelpCircle,
  AlertCircle,
  Database,
  BarChart3,
} from 'lucide-react';
import { useMess } from '../context/MessContext';
import { messApi } from '../services/messApiService';

export const PredictWastePage = () => {
  const { navigateTo } = useMess();

  // Form input states
  const [targetDate, setTargetDate] = useState(() => {
    const d = new Date(2026, 9, 29); // Oct 29, 2026
    return d.toISOString().split('T')[0];
  });
  const [mealType, setMealType] = useState('lunch');
  const [menuCategory, setMenuCategory] = useState('rice_grains');
  const [weatherCondition, setWeatherCondition] = useState('clear');
  const [expectedAttendance, setExpectedAttendance] = useState('850');
  const [foodPreparedKg, setFoodPreparedKg] = useState('520');
  const [costPerKg, setCostPerKg] = useState('75');
  const [notes, setNotes] = useState('Regular mid-week hostel service');

  // Computed weekday derived from date
  const [computedWeekday, setComputedWeekday] = useState('Thursday');

  useEffect(() => {
    if (targetDate) {
      try {
        const parts = targetDate.split('-');
        if (parts.length === 3) {
          const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
          const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          setComputedWeekday(dayNames[d.getDay()] || 'Wednesday');
        }
      } catch (_) {
        setComputedWeekday('Wednesday');
      }
    }
  }, [targetDate]);

  // Client-side validation errors & warnings
  const [fieldErrors, setFieldErrors] = useState({});
  const [plausibilityWarning, setPlausibilityWarning] = useState(null);

  // Submission & Async states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [predictionResult, setPredictionResult] = useState(null);
  const [apiError, setApiError] = useState(null);
  const [successNotice, setSuccessNotice] = useState(null);

  // Historical benchmark data states
  const [historicalBenchmark, setHistoricalBenchmark] = useState({
    isLoading: false,
    checked: false,
    matchingCount: 0,
    avgPreparedKg: 0,
    avgWasteKg: 0,
    avgWastePct: 0,
  });

  // Configurable Recommendation Engine Parameters
  const [targetWastePct, setTargetWastePct] = useState(7.0);
  const [safetyBufferPct, setSafetyBufferPct] = useState(8.0);

  // Real-time plausibility validation
  useEffect(() => {
    const att = parseInt(expectedAttendance, 10);
    const prep = parseFloat(foodPreparedKg);
    if (!isNaN(att) && att > 0 && !isNaN(prep) && prep > 0) {
      const portion = prep / att;
      if (portion < 0.20) {
        setPlausibilityWarning(
          `Portion allocation is very low (${(portion * 1000).toFixed(0)}g / student). Risk of meal shortage before service completes.`
        );
      } else if (portion > 1.20) {
        setPlausibilityWarning(
          `Portion allocation is very high (${portion.toFixed(2)} kg / student). Substantial post-service excess likely.`
        );
      } else {
        setPlausibilityWarning(null);
      }
    } else {
      setPlausibilityWarning(null);
    }
  }, [expectedAttendance, foodPreparedKg]);

  // Validate form inputs
  const validateForm = () => {
    const errors = {};
    if (!targetDate) errors.date = 'Service date is required';
    
    const att = parseInt(expectedAttendance, 10);
    if (isNaN(att) || att < 50 || att > 2500) {
      errors.expectedAttendance = 'Attendance must be between 50 and 2,500 students';
    }

    const prep = parseFloat(foodPreparedKg);
    if (isNaN(prep) || prep < 1.0 || prep > 2000.0) {
      errors.foodPreparedKg = 'Prepared food quantity must be between 1.0 and 2,000.0 kg';
    }

    const cost = parseFloat(costPerKg);
    if (isNaN(cost) || cost < 1.0 || cost > 1000.0) {
      errors.costPerKg = 'Cost per kg must be between ₹1.00 and ₹1,000.00';
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Fetch historical benchmark comparison
  const fetchHistoricalComparison = async (meal, menu) => {
    setHistoricalBenchmark((prev) => ({ ...prev, isLoading: true, checked: true }));
    try {
      const res = await messApi.getDataRecords({
        meal_type: meal,
        menu_category: menu,
        page_size: 100,
      });

      const records = res.records || [];
      if (records.length > 0) {
        const totalPrep = records.reduce((sum, r) => sum + (r.food_prepared_kg || 0), 0);
        const totalWaste = records.reduce((sum, r) => sum + (r.food_waste_kg || 0), 0);
        const avgPrep = totalPrep / records.length;
        const avgWaste = totalWaste / records.length;
        const avgPct = avgPrep > 0 ? (avgWaste / avgPrep) * 100 : 0;

        setHistoricalBenchmark({
          isLoading: false,
          checked: true,
          matchingCount: records.length,
          avgPreparedKg: Math.round(avgPrep * 10) / 10,
          avgWasteKg: Math.round(avgWaste * 10) / 10,
          avgWastePct: Math.round(avgPct * 10) / 10,
        });
      } else {
        setHistoricalBenchmark({
          isLoading: false,
          checked: true,
          matchingCount: 0,
          avgPreparedKg: 0,
          avgWasteKg: 0,
          avgWastePct: 0,
        });
      }
    } catch (err) {
      console.warn('Historical comparison fetch failed:', err);
      setHistoricalBenchmark((prev) => ({ ...prev, isLoading: false, matchingCount: 0 }));
    }
  };

  // Quick preset scenario handler
  const handleApplyPreset = (preset) => {
    if (preset === 'realistic_lunch') {
      setTargetDate('2026-10-29');
      setMealType('lunch');
      setMenuCategory('rice_grains');
      setWeatherCondition('clear');
      setExpectedAttendance('850');
      setFoodPreparedKg('520');
      setCostPerKg('75');
      setNotes('Typical mid-week lunch batch');
    } else if (preset === 'rainy_feast') {
      setTargetDate('2026-10-30');
      setMealType('dinner');
      setMenuCategory('special_feast');
      setWeatherCondition('rainy');
      setExpectedAttendance('920');
      setFoodPreparedKg('680');
      setCostPerKg('120');
      setNotes('Monsoon Friday Biryani feast');
    } else if (preset === 'light_breakfast') {
      setTargetDate('2026-11-02');
      setMealType('breakfast');
      setMenuCategory('continental_light');
      setWeatherCondition('clear');
      setExpectedAttendance('640');
      setFoodPreparedKg('290');
      setCostPerKg('50');
      setNotes('Early week light breakfast');
    } else if (preset === 'lower_boundary') {
      setTargetDate('2026-11-03');
      setMealType('breakfast');
      setMenuCategory('continental_light');
      setWeatherCondition('clear');
      setExpectedAttendance('50');
      setFoodPreparedKg('25');
      setCostPerKg('40');
      setNotes('Boundary test: Minimum attendance (50 students)');
    } else if (preset === 'upper_boundary') {
      setTargetDate('2026-11-08');
      setMealType('lunch');
      setMenuCategory('curry_dal');
      setWeatherCondition('overcast');
      setExpectedAttendance('2500');
      setFoodPreparedKg('1500');
      setCostPerKg('95');
      setNotes('Boundary test: Maximum capacity (2500 students)');
    }
  };

  // Form submission handler
  const handleSubmit = async (e) => {
    if (e) e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setApiError(null);
    setSuccessNotice(null);

    const payload = {
      date: targetDate,
      weekday: computedWeekday,
      meal_type: mealType.toLowerCase(),
      menu_category: menuCategory,
      weather_condition: weatherCondition,
      expected_attendance: parseInt(expectedAttendance, 10),
      food_prepared_kg: parseFloat(foodPreparedKg),
      cost_per_kg: parseFloat(costPerKg),
      notes: notes.trim() || undefined,
    };

    try {
      const response = await messApi.predictWaste(payload);
      setPredictionResult(response);
      setSuccessNotice({
        predictionId: response.prediction_id,
        timestamp: new Date().toLocaleTimeString(),
      });

      fetchHistoricalComparison(payload.meal_type, payload.menu_category);
    } catch (err) {
      console.error('Prediction API call failed:', err);
      setApiError(err.message || 'Error occurred while calling /api/predict');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Separate Transparent Preparation Recommendation Computation
  const computeTransparentRecommendation = () => {
    if (!predictionResult?.prediction) return null;

    const predWasteKg = predictionResult.prediction.predicted_waste_kg;
    const plannedPrepKg = parseFloat(foodPreparedKg);
    const att = parseInt(expectedAttendance, 10);
    const unitCost = parseFloat(costPerKg);

    const estimatedConsumptionKg = Math.max(0, plannedPrepKg - predWasteKg);
    const minPortionPerStudent = mealType === 'breakfast' ? 0.35 : 0.50;
    const absoluteMinBatchKg = Math.round(att * minPortionPerStudent * 10) / 10;
    const targetRatio = Math.max(0.70, 1.0 - targetWastePct / 100);
    const baseTargetBatchKg = estimatedConsumptionKg / targetRatio;
    const bufferedBatchKg = baseTargetBatchKg * (1.0 + safetyBufferPct / 100);

    const maxTrimCapKg = plannedPrepKg * 0.75;
    const lowerBoundKg = Math.max(absoluteMinBatchKg, maxTrimCapKg);

    let recommendedBatchKg = Math.min(plannedPrepKg, Math.max(lowerBoundKg, bufferedBatchKg));
    recommendedBatchKg = Math.round(recommendedBatchKg * 10) / 10;

    const potentialReductionKg = Math.max(0, Math.round((plannedPrepKg - recommendedBatchKg) * 10) / 10);
    const potentialCostSaving = Math.round(potentialReductionKg * unitCost);

    return {
      plannedPrepKg,
      estimatedConsumptionKg: Math.round(estimatedConsumptionKg * 10) / 10,
      recommendedBatchKg,
      potentialReductionKg,
      potentialCostSaving,
      absoluteMinBatchKg,
      targetWastePct,
      safetyBufferPct,
      minPortionPerStudent,
      isTrimCapped: recommendedBatchKg === lowerBoundKg && lowerBoundKg === maxTrimCapKg,
      isFloorCapped: recommendedBatchKg === absoluteMinBatchKg,
    };
  };

  const rec = computeTransparentRecommendation();
  const pred = predictionResult?.prediction;

  return (
    <div className="space-y-6 pb-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#16865B]" />
            Food Waste Predictor & Kitchen Batch Optimizer
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              Live Scikit-learn Pipeline
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            Statistical regression forecasting combined with a transparent, safety-buffered batch recommendation engine.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="flex items-center gap-2 text-xs text-[#25332D] bg-white border border-[#E4EAE5] px-3 py-1.5 rounded-lg shadow-xs">
            <Database className="w-4 h-4 text-[#16865B]" />
            <span className="font-mono text-[11px]">Storage: SQLite (data/smartmess.db)</span>
          </div>
        </div>
      </div>

      {/* Preset Scenario Buttons */}
      <div className="p-3 rounded-xl bg-white border border-[#E4EAE5] shadow-xs flex flex-wrap items-center gap-2 text-xs">
        <span className="text-[#77847C] font-medium">Quick Test Scenarios:</span>
        <button
          type="button"
          onClick={() => handleApplyPreset('realistic_lunch')}
          className="px-2.5 py-1 rounded bg-[#F8FAF8] hover:bg-white text-[#25332D] border border-[#E4EAE5] transition-colors cursor-pointer shadow-2xs"
        >
          🍛 Realistic Mid-Week Lunch
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('rainy_feast')}
          className="px-2.5 py-1 rounded bg-[#F8FAF8] hover:bg-white text-[#25332D] border border-[#E4EAE5] transition-colors cursor-pointer shadow-2xs"
        >
          🌧️ Rainy Friday Feast
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('light_breakfast')}
          className="px-2.5 py-1 rounded bg-[#F8FAF8] hover:bg-white text-[#25332D] border border-[#E4EAE5] transition-colors cursor-pointer shadow-2xs"
        >
          🥐 Monday Light Breakfast
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('lower_boundary')}
          className="px-2.5 py-1 rounded bg-[#E9F6EE] text-[#16865B] hover:bg-[#D8F0E1] transition-colors border border-[#C5E5D0] cursor-pointer font-mono text-[11px] shadow-2xs"
        >
          Min Boundary (50 Headcount)
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('upper_boundary')}
          className="px-2.5 py-1 rounded bg-[#E9F6EE] text-[#16865B] hover:bg-[#D8F0E1] transition-colors border border-[#C5E5D0] cursor-pointer font-mono text-[11px] shadow-2xs"
        >
          Max Boundary (2,500 Headcount)
        </button>
      </div>

      {/* Main Grid: Form (Left 6 Cols) and Results Panel (Right 6 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Container */}
        <div className="lg:col-span-6 space-y-4">
          <form
            onSubmit={handleSubmit}
            className="rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-4 shadow-xs"
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
              <h3 className="text-sm font-semibold text-[#25332D] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#16865B]" />
                Service Parameters Form
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                Zero Target Leakage
              </span>
            </div>

            {/* Field 1: Target Date & Computed Day of Week */}
            <div>
              <label className="block text-xs font-medium text-[#25332D] mb-1">
                Meal Service Date & Day of Week <span className="text-[#DC2626]">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="relative">
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className={`w-full bg-[#F8FAF8] border rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:bg-white ${
                      fieldErrors.date ? 'border-[#DC2626]' : 'border-[#E4EAE5] focus:border-[#16865B]'
                    }`}
                  />
                  {fieldErrors.date && (
                    <span className="text-[11px] text-[#DC2626] mt-1 block">{fieldErrors.date}</span>
                  )}
                </div>
                <div className="flex items-center px-3 py-2 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-xs text-[#25332D]">
                  <Calendar className="w-3.5 h-3.5 text-[#16865B] mr-2 shrink-0" />
                  <span className="font-mono text-[#16865B] font-semibold">{computedWeekday}</span>
                  <span className="text-[#77847C] text-[10px] ml-1.5">(Auto-derived)</span>
                </div>
              </div>
            </div>

            {/* Field 2 & 3: Meal Type & Menu Category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#25332D] mb-1">
                  Meal Service Window <span className="text-[#DC2626]">*</span>
                </label>
                <select
                  value={mealType}
                  onChange={(e) => setMealType(e.target.value)}
                  className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:border-[#16865B] focus:bg-white cursor-pointer"
                >
                  <option value="breakfast">Breakfast (Morning Service)</option>
                  <option value="lunch">Lunch (Afternoon Service)</option>
                  <option value="dinner">Dinner (Evening Service)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#25332D] mb-1">
                  Primary Menu Category <span className="text-[#DC2626]">*</span>
                </label>
                <select
                  value={menuCategory}
                  onChange={(e) => setMenuCategory(e.target.value)}
                  className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:border-[#16865B] focus:bg-white cursor-pointer font-mono"
                >
                  <option value="rice_grains">rice_grains (Rice, Pulao, Dal)</option>
                  <option value="roti_breads">roti_breads (Roti, Naan, Paratha)</option>
                  <option value="curry_dal">curry_dal (Paneer, Chana, Gravy)</option>
                  <option value="continental_light">continental_light (Poha, Upma, Idli)</option>
                  <option value="special_feast">special_feast (Biryani, Feast Menu)</option>
                </select>
              </div>
            </div>

            {/* Field 4: Weather Condition */}
            <div>
              <label className="block text-xs font-medium text-[#25332D] mb-1">
                Forecasted Weather Condition <span className="text-[#DC2626]">*</span>
              </label>
              <select
                value={weatherCondition}
                onChange={(e) => setWeatherCondition(e.target.value)}
                className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:border-[#16865B] focus:bg-white cursor-pointer font-mono"
              >
                <option value="clear">clear (Normal Sunny / Dry)</option>
                <option value="overcast">overcast (Cloudy / Normal Turnout)</option>
                <option value="rainy">rainy (Heavy Rain / Reduced Turnout)</option>
                <option value="extreme_heat">extreme_heat (Hot Afternoon / Lower Appetite)</option>
                <option value="cold">cold (Winter Cold Wave)</option>
              </select>
            </div>

            {/* Field 5: Expected Attendance */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-medium text-[#25332D] flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-[#16865B]" />
                  Expected Student Attendance (Headcount) <span className="text-[#DC2626]">*</span>
                </label>
                <span className="font-mono text-xs text-[#77847C] font-medium">
                  Valid: 50 – 2,500
                </span>
              </div>
              <input
                type="number"
                min="50"
                max="2500"
                step="1"
                value={expectedAttendance}
                onChange={(e) => setExpectedAttendance(e.target.value)}
                placeholder="e.g. 850"
                className={`w-full bg-[#F8FAF8] border rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:bg-white font-mono ${
                  fieldErrors.expectedAttendance ? 'border-[#DC2626]' : 'border-[#E4EAE5] focus:border-[#16865B]'
                }`}
              />
              {fieldErrors.expectedAttendance && (
                <span className="text-[11px] text-[#DC2626] mt-1 block">{fieldErrors.expectedAttendance}</span>
              )}
            </div>

            {/* Field 6: Planned Food Preparation (kg) */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-medium text-[#25332D] flex items-center gap-1.5">
                  <Scale className="w-3.5 h-3.5 text-[#0284C7]" />
                  Planned Food Preparation Quantity (kg) <span className="text-[#DC2626]">*</span>
                </label>
                <span className="font-mono text-xs text-[#77847C] font-medium">
                  Valid: 1.0 – 2,000.0 kg
                </span>
              </div>
              <input
                type="number"
                min="1.0"
                max="2000.0"
                step="0.5"
                value={foodPreparedKg}
                onChange={(e) => setFoodPreparedKg(e.target.value)}
                placeholder="e.g. 520"
                className={`w-full bg-[#F8FAF8] border rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:bg-white font-mono ${
                  fieldErrors.foodPreparedKg ? 'border-[#DC2626]' : 'border-[#E4EAE5] focus:border-[#16865B]'
                }`}
              />
              {fieldErrors.foodPreparedKg && (
                <span className="text-[11px] text-[#DC2626] mt-1 block">{fieldErrors.foodPreparedKg}</span>
              )}
            </div>

            {/* Field 7: Estimated Food Cost per kg */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-medium text-[#25332D] flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-[#D97706]" />
                  Estimated Food Cost per Kilogram (INR ₹) <span className="text-[#DC2626]">*</span>
                </label>
                <span className="font-mono text-xs text-[#77847C] font-medium">
                  Valid: ₹1.00 – ₹1,000.00
                </span>
              </div>
              <input
                type="number"
                min="1.0"
                max="1000.0"
                step="1"
                value={costPerKg}
                onChange={(e) => setCostPerKg(e.target.value)}
                placeholder="e.g. 75"
                className={`w-full bg-[#F8FAF8] border rounded-lg px-3 py-2 text-xs text-[#25332D] focus:outline-none focus:bg-white font-mono ${
                  fieldErrors.costPerKg ? 'border-[#DC2626]' : 'border-[#E4EAE5] focus:border-[#16865B]'
                }`}
              />
              {fieldErrors.costPerKg && (
                <span className="text-[11px] text-[#DC2626] mt-1 block">{fieldErrors.costPerKg}</span>
              )}
            </div>

            {/* Field 8: Staff Notes */}
            <div>
              <label className="block text-xs font-medium text-[#25332D] mb-1">
                Operational Notes / Audit Tag (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Mid-semester exam day, special sports lunch..."
                className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-3 py-2 text-xs text-[#25332D] placeholder-[#77847C] focus:outline-none focus:border-[#16865B] focus:bg-white"
              />
            </div>

            {/* Plausibility Warning */}
            {plausibilityWarning && (
              <div className="p-3 rounded-lg bg-[#FFFBEB] border border-[#FDE68A] text-[#B45309] text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
                <span>{plausibilityWarning}</span>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-[#16865B] hover:bg-[#126E4A] text-white transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Executing Scikit-learn Pipeline Inference...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Predict Food Waste & Generate Recommendation
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Backend Error Banner */}
          {apiError && (
            <div className="p-4 rounded-xl bg-[#FEF2F2] border border-[#FECACA] text-[#991B1B] text-xs flex items-start gap-3 shadow-xs">
              <AlertCircle className="w-5 h-5 text-[#DC2626] shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block text-[#991B1B]">Inference Request Failed</strong>
                <p className="mt-0.5 text-[#B91C1C]">{apiError}</p>
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="mt-2 text-xs text-[#991B1B] underline hover:text-[#7F1D1D] cursor-pointer"
                >
                  Retry Prediction
                </button>
              </div>
            </div>
          )}

          {/* Persistence Toast */}
          {successNotice && (
            <div className="p-3.5 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] text-[#16865B] text-xs flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#16865B] shrink-0" />
                <div>
                  <span className="font-semibold text-[#16865B]">Inference Successful & Logged</span>
                  <div className="font-mono text-[10px] text-[#55635C]">
                    ID: {successNotice.predictionId} ({successNotice.timestamp})
                  </div>
                </div>
              </div>
              <button
                onClick={() => navigateTo('history')}
                className="text-[11px] underline text-[#16865B] hover:text-[#126E4A] font-medium cursor-pointer"
              >
                View History →
              </button>
            </div>
          )}
        </div>

        {/* Output & Recommendation Container (Right 6 Cols) */}
        <div className="lg:col-span-6 space-y-5">
          {pred ? (
            <>
              {/* SECTION A: REAL SCALA/PYTHON ML PREDICTION DISPLAY */}
              <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#16865B] font-semibold">
                      Trained Scikit-learn Inference
                    </span>
                    <h3 className="text-base font-bold text-[#25332D] mt-0.5">
                      Predicted Food Waste & Cost Loss
                    </h3>
                  </div>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                      pred.high_waste_risk
                        ? 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]'
                        : 'bg-[#E9F6EE] text-[#16865B] border-[#C5E5D0]'
                    }`}
                  >
                    {pred.high_waste_risk ? '⚠️ High Waste Risk' : '✅ Low Risk'}
                  </span>
                </div>

                {/* Primary Metric: Predicted Waste in kg and % */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
                    <span className="text-[#77847C] text-xs font-medium block mb-1">
                      Predicted Waste (kg):
                    </span>
                    <div className="text-3xl font-bold font-mono text-[#16865B]">
                      {pred.predicted_waste_kg} kg
                    </div>
                    <div className="text-xs font-mono text-[#D97706] mt-1 font-semibold">
                      {pred.predicted_waste_pct}% of planned preparation
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
                    <span className="text-[#77847C] text-xs font-medium block mb-1">
                      Estimated Financial Loss:
                    </span>
                    <div className="text-3xl font-bold font-mono text-[#B91C1C]">
                      ₹{pred.predicted_cost_loss_inr.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-[#77847C] font-mono mt-1">
                      Formula: {pred.predicted_waste_kg} kg × ₹{costPerKg}/kg
                    </div>
                  </div>
                </div>

                {/* Documented Cost Calculation Explanation */}
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-xs text-[#25332D] space-y-1">
                  <span className="font-semibold text-[#25332D] block text-[11px] uppercase tracking-wider">
                    Documented Cost Calculation:
                  </span>
                  <div className="font-mono text-xs text-[#16865B] bg-white px-2.5 py-1.5 rounded border border-[#E4EAE5] font-semibold">
                    Financial Waste Loss (₹) = Predicted Waste ({pred.predicted_waste_kg} kg) × Cost/kg (₹{costPerKg}) = ₹{pred.predicted_cost_loss_inr.toLocaleString()}
                  </div>
                  <p className="text-[11px] text-[#77847C] pt-1">
                    Represents the direct monetary loss of unconsumed kitchen inventory and cooked ingredients.
                  </p>
                </div>

                {/* Model Serving Metadata */}
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-[11px] text-[#77847C] flex items-center justify-between font-mono">
                  <span>Serving Pipeline: {pred.model_name}</span>
                  <span className="text-[#16865B] font-semibold">{pred.model_version}</span>
                </div>

                {/* Clear Explanation of Prediction */}
                <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 font-semibold text-[#25332D]">
                    <HelpCircle className="w-4 h-4 text-[#16865B]" />
                    <span>Inference Factor Breakdown & Explanation</span>
                  </div>
                  <ul className="space-y-1.5 text-[#55635C] list-disc list-inside">
                    <li>
                      <strong>Headcount Ratio:</strong> Planned quantity provides {(parseFloat(foodPreparedKg) / parseInt(expectedAttendance, 10)).toFixed(2)} kg/student vs historical consumption average.
                    </li>
                    <li>
                      <strong>Menu Profile ({menuCategory}):</strong> Menu item attributes historically dictate plate discard levels during {mealType} services.
                    </li>
                    <li>
                      <strong>Weather Factor ({weatherCondition}):</strong> {weatherCondition === 'rainy' ? 'Rainy weather dampens turnout by 12–16%, increasing surplus residue.' : 'Dry weather allows stable turnout without attendance penalties.'}
                    </li>
                    <li>
                      <strong>Risk Threshold Check:</strong> Predicted discard ({pred.predicted_waste_kg} kg) {pred.high_waste_risk ? 'exceeds' : 'remains below'} the 75th percentile benchmark ({pred.threshold_used_kg} kg).
                    </li>
                  </ul>
                </div>

                {/* Historical Comparison */}
                <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2 text-xs">
                  <div className="flex items-center justify-between pb-1 border-b border-[#EEF2EF]">
                    <span className="font-semibold text-[#25332D] flex items-center gap-1.5">
                      <BarChart3 className="w-4 h-4 text-[#0284C7]" />
                      Historical Benchmark Comparison
                    </span>
                    <span className="text-[10px] font-mono text-[#77847C]">
                      {historicalBenchmark.matchingCount} Relevant Records
                    </span>
                  </div>

                  {historicalBenchmark.isLoading ? (
                    <div className="py-2 flex items-center gap-2 text-[#77847C]">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#16865B]" />
                      <span>Matching historical service records...</span>
                    </div>
                  ) : historicalBenchmark.matchingCount > 0 ? (
                    <div className="space-y-2">
                      <p className="text-[#25332D]">
                        Comparing against <strong>{historicalBenchmark.matchingCount} historical records</strong> for <span className="text-[#16865B] font-mono font-semibold">{mealType}</span> serving <span className="text-[#0284C7] font-mono font-semibold">{menuCategory}</span>:
                      </p>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                        <div className="p-2 rounded-lg bg-white border border-[#E4EAE5]">
                          <span className="text-[#77847C] text-[10px] block">Historical Avg Waste:</span>
                          <span className="text-[#25332D] font-bold">{historicalBenchmark.avgWasteKg} kg</span> ({historicalBenchmark.avgWastePct}%)
                        </div>
                        <div className="p-2 rounded-lg bg-white border border-[#E4EAE5]">
                          <span className="text-[#77847C] text-[10px] block">Variance from Benchmark:</span>
                          <span className={`font-bold ${pred.predicted_waste_kg < historicalBenchmark.avgWasteKg ? 'text-[#16865B]' : 'text-[#B91C1C]'}`}>
                            {pred.predicted_waste_kg < historicalBenchmark.avgWasteKg ? '▼ ' : '▲ '}
                            {Math.abs(pred.predicted_waste_kg - historicalBenchmark.avgWasteKg).toFixed(1)} kg
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-2.5 rounded-lg bg-white border border-[#E4EAE5] text-[#77847C] text-xs">
                      No relevant historical benchmark records found for the specific combination of <span className="text-[#25332D] font-mono">{mealType}</span> and <span className="text-[#25332D] font-mono">{menuCategory}</span>.
                    </div>
                  )}
                </div>
              </div>

              {/* SECTION B: SEPARATE TRANSPARENT PREPARATION RECOMMENDATION ENGINE */}
              {rec && (
                <div className="rounded-xl bg-white border border-[#C5E5D0] p-5 space-y-4 shadow-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                    <div>
                      <span className="text-[10px] font-mono uppercase tracking-wider text-[#16865B] font-semibold">
                        Separate Operational Heuristic
                      </span>
                      <h3 className="text-base font-bold text-[#25332D] mt-0.5 flex items-center gap-2">
                        <Scale className="w-5 h-5 text-[#16865B]" />
                        Transparent Preparation Recommendation
                      </h3>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                      Safety-Buffered
                    </span>
                  </div>

                  {/* Configurable Sliders for Recommendation */}
                  <div className="p-3.5 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-3">
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#25332D] block">
                      Configurable Policy Targets:
                    </span>

                    {/* Target Waste Slider */}
                    <div>
                      <div className="flex justify-between items-center text-xs mb-1">
                        <span className="text-[#77847C]">Acceptable Waste Target Rate:</span>
                        <span className="font-mono font-bold text-[#16865B]">{targetWastePct.toFixed(1)}%</span>
                      </div>
                      <input
                        type="range"
                        min="3.0"
                        max="12.0"
                        step="0.5"
                        value={targetWastePct}
                        onChange={(e) => setTargetWastePct(parseFloat(e.target.value))}
                        className="w-full accent-[#16865B] cursor-pointer"
                      />
                      <div className="flex justify-between text-[10px] text-[#77847C] font-mono mt-0.5">
                        <span>3% (Strict)</span>
                        <span>7% (Standard)</span>
                        <span>12% (Permissive)</span>
                      </div>
                    </div>

                    {/* Safety Buffer Slider */}
                    <div>
                      <div className="flex justify-between items-center text-xs mb-1">
                        <span className="text-[#77847C]">Contingency Safety Buffer (Zero-Shortage Allowance):</span>
                        <span className="font-mono font-bold text-[#0284C7]">{safetyBufferPct.toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="5.0"
                        max="20.0"
                        step="1.0"
                        value={safetyBufferPct}
                        onChange={(e) => setSafetyBufferPct(parseFloat(e.target.value))}
                        className="w-full accent-[#0284C7] cursor-pointer"
                      />
                      <div className="flex justify-between text-[10px] text-[#77847C] font-mono mt-0.5">
                        <span>5% min buffer</span>
                        <span>8% recommended</span>
                        <span>20% max buffer</span>
                      </div>
                    </div>
                  </div>

                  {/* Recommended Output Card */}
                  <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#25332D] font-medium">Recommended Kitchen Batch:</span>
                      <span className="text-2xl font-bold font-mono text-[#16865B]">
                        {rec.recommendedBatchKg} kg
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-[#EEF2EF]">
                      <div>
                        <span className="text-[#77847C] text-[10px]">Potential Surplus Trim:</span>
                        <div className="font-mono text-[#25332D] font-semibold">
                          {rec.potentialReductionKg > 0 ? `${rec.potentialReductionKg} kg` : '0.0 kg (Batch optimal)'}
                        </div>
                      </div>
                      <div>
                        <span className="text-[#77847C] text-[10px]">Estimated Expenditure Reduction:</span>
                        <div className="font-mono text-[#16865B] font-semibold">
                          {rec.potentialCostSaving > 0 ? `₹${rec.potentialCostSaving.toLocaleString()}` : '₹0'}
                        </div>
                      </div>
                    </div>

                    {/* Limits & Guardrails Enforced */}
                    <div className="pt-2 border-t border-[#EEF2EF] text-[11px] text-[#77847C] space-y-1">
                      <div className="flex justify-between">
                        <span>Zero-Shortage Floor Portion:</span>
                        <span className="font-mono text-[#25332D]">{rec.absoluteMinBatchKg} kg ({rec.minPortionPerStudent} kg/diner)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Maximum Trimming Cap:</span>
                        <span className="font-mono text-[#25332D]">25% maximum batch reduction</span>
                      </div>
                      {rec.isFloorCapped && (
                        <div className="text-[#D97706] text-[10px]">
                          🛡️ Nutrition floor limit active: Trimming stopped to prevent under-feeding students.
                        </div>
                      )}
                      {rec.isTrimCapped && (
                        <div className="text-[#D97706] text-[10px]">
                          🛡️ Trimming cap active: Reduction limited to 25% of planned volume for kitchen continuity.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Documented Assumptions & Disclaimers */}
                  <div className="p-3.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-2 text-xs">
                    <span className="font-semibold text-[#25332D] block text-[11px] uppercase tracking-wider">
                      Documented Assumptions & Disclaimers:
                    </span>
                    <ol className="list-decimal list-inside space-y-1 text-[#55635C] text-[11px]">
                      <li>
                        <strong>Decoupled from ML:</strong> This recommendation is an operational optimization heuristic, distinct from the statistical linear regression model.
                      </li>
                      <li>
                        <strong>Food Availability Guaranteed:</strong> A {safetyBufferPct}% safety buffer is added on top of estimated consumption ({rec.estimatedConsumptionKg} kg) so diners are never turned away.
                      </li>
                      <li>
                        <strong>No Guaranteed Savings:</strong> Stated financial reductions (₹{rec.potentialCostSaving.toLocaleString()}) are simulated scenarios assuming expected attendance holds. Savings are not guaranteed.
                      </li>
                      <li>
                        <strong>Deterministic Policy:</strong> No uncalculated statistical confidence intervals are assumed; bounds are dictated by the configured safety buffer and portion limits.
                      </li>
                    </ol>
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Standby State */
            <div className="rounded-xl bg-white border border-[#E4EAE5] p-8 text-center space-y-3 shadow-xs">
              <div className="w-12 h-12 rounded-full bg-[#E9F6EE] text-[#16865B] flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-semibold text-[#25332D]">Simulator Ready</h4>
              <p className="text-xs text-[#77847C] max-w-sm mx-auto leading-relaxed">
                Fill in the meal parameters on the left or click a Quick Test Scenario, then click Predict to view ML forecasts, documented cost losses, and safety-buffered kitchen recommendations.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
