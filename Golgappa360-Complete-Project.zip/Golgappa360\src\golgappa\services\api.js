// =====================================================================
// Golgappa360 - Client API Service Layer (Phase 3 Complete)
// Communicates with Node/Express backend on /api with dual-engine fallback.
// =====================================================================

const API_BASE = '/api';

function buildQuery(params = {}) {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([key, val]) => {
    if (val !== undefined && val !== null && val !== '') {
      q.append(key, val);
    }
  });
  const str = q.toString();
  return str ? `?${str}` : '';
}

// -------------------------------------------------------------
// System Health
// -------------------------------------------------------------
export async function fetchHealth() {
  const res = await fetch(`${API_BASE}/health`);
  if (!res.ok) throw new Error(`Health check failed: ${res.statusText}`);
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 Canonical: 1. Dashboard Endpoints
// -------------------------------------------------------------
export async function fetchDashboardSummary(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/dashboard/summary${query}`);
  if (!res.ok) throw new Error(`Dashboard summary failed: ${res.statusText}`);
  return res.json();
}

export async function fetchSalesTrend(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/dashboard/sales-trend${query}`);
  if (!res.ok) throw new Error(`Sales trend failed: ${res.statusText}`);
  return res.json();
}

export async function fetchHourlySales(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/dashboard/hourly-sales${query}`);
  if (!res.ok) throw new Error(`Hourly sales failed: ${res.statusText}`);
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 Canonical: 2. Sales Endpoints
// -------------------------------------------------------------
export async function fetchSales(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/sales${query}`);
  if (!res.ok) throw new Error(`Sales fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchProductPerformance(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/sales/product-performance${query}`);
  if (!res.ok) throw new Error(`Product performance failed: ${res.statusText}`);
  return res.json();
}

export async function fetchPaymentBreakdown(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/sales/payment-breakdown${query}`);
  if (!res.ok) throw new Error(`Payment breakdown failed: ${res.statusText}`);
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 Canonical: 3. Product Endpoints
// -------------------------------------------------------------
export async function fetchProducts(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/products${query}`);
  if (!res.ok) throw new Error(`Products fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchProductById(id) {
  const res = await fetch(`${API_BASE}/products/${encodeURIComponent(id)}`);
  if (!res.ok) throw new Error(`Product fetch failed for ID '${id}': ${res.statusText}`);
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 Canonical: 4. Inventory Endpoints
// -------------------------------------------------------------
export async function fetchInventorySummary() {
  const res = await fetch(`${API_BASE}/inventory/summary`);
  if (!res.ok) throw new Error(`Inventory summary failed: ${res.statusText}`);
  return res.json();
}

export async function fetchInventoryTransactions(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/inventory/transactions${query}`);
  if (!res.ok) throw new Error(`Inventory transactions failed: ${res.statusText}`);
  return res.json();
}

export async function restockInventory(ingredientId, quantityAdded, notes = '') {
  const res = await fetch(`${API_BASE}/inventory/restock`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ingredient_id: ingredientId,
      quantity_added: quantityAdded,
      notes
    })
  });
  if (!res.ok) throw new Error('Failed to restock inventory');
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 Canonical: 5. Food Waste Endpoints
// -------------------------------------------------------------
export async function fetchWasteSummary(params = {}) {
  const query = buildQuery(params);
  const res = await fetch(`${API_BASE}/waste/summary${query}`);
  if (!res.ok) throw new Error(`Waste summary failed: ${res.statusText}`);
  return res.json();
}

export async function logWaste(wasteData) {
  const res = await fetch(`${API_BASE}/waste/log`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(wasteData)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to log food waste');
  }
  return res.json();
}

// -------------------------------------------------------------
// Phase 3 & 4 Canonical: 6. Reports & Export Endpoints
// -------------------------------------------------------------
export async function fetchDatasetSummary() {
  const res = await fetch(`${API_BASE}/reports/dataset-summary`);
  if (!res.ok) throw new Error(`Dataset summary failed: ${res.statusText}`);
  return res.json();
}

export async function fetchTableauCatalog() {
  const res = await fetch(`${API_BASE}/reports/tableau/catalog`);
  if (!res.ok) throw new Error(`Tableau catalog failed: ${res.statusText}`);
  return res.json();
}

export function getExportDownloadUrl(datasetId, params = {}) {
  const query = buildQuery(params);
  return `${API_BASE}/reports/export/${encodeURIComponent(datasetId)}${query}`;
}

export function getTableauDownloadUrl(filename) {
  const cleanName = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  return `${API_BASE}/reports/export/tableau/${encodeURIComponent(cleanName)}`;
}

// -------------------------------------------------------------
// Backwards Compatibility Aliases (Phase 1 & Phase 2 UI)
// -------------------------------------------------------------
export async function fetchOverview(range = '30d', productId = 'all') {
  const query = buildQuery({ range, product_id: productId });
  const res = await fetch(`${API_BASE}/overview${query}`);
  if (!res.ok) throw new Error(`Overview fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchSalesAnalytics(range = '30d', productId = 'all') {
  const query = buildQuery({ range, product_id: productId });
  const res = await fetch(`${API_BASE}/sales/analytics${query}`);
  if (!res.ok) throw new Error(`Sales analytics fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchMenuItems(range = '180d') {
  const query = buildQuery({ range });
  const res = await fetch(`${API_BASE}/menu${query}`);
  if (!res.ok) throw new Error(`Menu fetch failed: ${res.statusText}`);
  return res.json();
}

export async function createMenuItem(itemData) {
  const res = await fetch(`${API_BASE}/menu`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(itemData)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create menu item');
  }
  return res.json();
}

export async function updateMenuItem(id, updates) {
  const res = await fetch(`${API_BASE}/menu/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) throw new Error('Failed to update menu item');
  return res.json();
}

export async function fetchInventory() {
  const res = await fetch(`${API_BASE}/inventory`);
  if (!res.ok) throw new Error(`Inventory fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchWasteData(range = '180d') {
  const query = buildQuery({ range });
  const res = await fetch(`${API_BASE}/waste${query}`);
  if (!res.ok) throw new Error(`Waste data fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchReportsSummary() {
  const res = await fetch(`${API_BASE}/reports/summary`);
  if (!res.ok) throw new Error(`Reports summary fetch failed: ${res.statusText}`);
  return res.json();
}

export async function fetchSettings() {
  const res = await fetch(`${API_BASE}/settings`);
  if (!res.ok) throw new Error(`Settings fetch failed: ${res.statusText}`);
  return res.json();
}

export async function updateStallSettings(settings) {
  const res = await fetch(`${API_BASE}/settings/stall`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings)
  });
  if (!res.ok) throw new Error('Failed to update stall settings');
  return res.json();
}

export async function testDbConnection(config) {
  const res = await fetch(`${API_BASE}/settings/test-db`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config)
  });
  if (!res.ok) throw new Error('Database test endpoint failed');
  return res.json();
}

export async function resetDemoData() {
  const res = await fetch(`${API_BASE}/settings/reset-demo`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Reset demo data failed');
  return res.json();
}
