# Golgappa360 — Tableau & Excel Business Intelligence Guide
## Golgappa Business Intelligence & Sales Analytics System (MCA Project Data Deliverable)

### 1. Executive Summary & Architecture Overview
This document serves as the formal Data Dictionary, Relational Mapping, and Visualization Blueprint for **Golgappa360**. The platform records micro-transactional and operational metrics for an Indian street food vendor specializing in multiple varieties of Pani Puri (Golgappa), Chaat, and custom artisanal waters (Teekha, Khatta Meetha, Hing, Pudina).

---

### 2. Dataset Catalog & Schema Reference

#### A. `golgappa_daily_sales_summary.csv`
*Primary granularity: One record per operating business day.*
- `Date` (Date): Operational date (`YYYY-MM-DD`).
- `Day_Of_Week` (String): Day name (`Monday` through `Sunday`).
- `Total_Orders` (Integer): Total distinct customer bills processed.
- `Total_Plates_Sold` (Integer): Cumulative count of golgappa and chaat plates served.
- `Gross_Revenue_INR` (Float): Total monetary turnover before expense deductions.
- `Total_COGS_INR` (Float): Cost of Goods Sold (raw material direct cost).
- `Gross_Profit_INR` (Float): Calculated as `Gross_Revenue_INR - Total_COGS_INR`.
- `Gross_Margin_Pct` (Float): `(Gross_Profit_INR / Gross_Revenue_INR) * 100`.
- `Daily_Waste_Cost_INR` (Float): Cumulative financial loss from discarded puris, sour water, and mashed potatoes.
- `Net_Estimated_Profit_INR` (Float): `Gross_Profit_INR - Daily_Waste_Cost_INR`.
- `Waste_Rate_Pct` (Float): `(Daily_Waste_Cost_INR / Total_COGS_INR) * 100`.
- `UPI_Revenue_INR` (Float): Revenue settled via QR UPI (PhonePe, Google Pay, Paytm).
- `Cash_Revenue_INR` (Float): Physical currency collected at counter.
- `AOV_INR` (Float): Average Order Value (`Gross_Revenue_INR / Total_Orders`).

#### B. `golgappa_sales_transactions.csv`
*Primary granularity: One record per customer invoice.*
- `Transaction_ID` (String): Unique invoice number (`TXN-20261029-XXX`).
- `Timestamp` (DateTime): ISO 8601 timestamp with IST offset.
- `Time` (String): HH:MM format for quick grouping.
- `Customer_Type` (String): `Dine-in` or `Takeaway`.
- `Items_Summary` (String): Readable summary of items ordered.
- `Total_Plates` (Integer): Count of plates in order.
- `Gross_Amount_INR` (Float): Ticket invoice total.
- `Cost_INR` (Float): Total ingredient cost.
- `Profit_INR` (Float): Net item profit.
- `Payment_Method` (String): `UPI`, `Cash`, or `Card`.
- `Status` (String): `Completed` or `Refunded`.

#### C. `golgappa_menu_and_margins.csv`
*Primary granularity: One record per menu item.*
- `Item_Code` (String): Primary SKU identifier.
- `Name` (String): Full product name with plate size.
- `Category` (String): Product category (`Classic`, `Flavoured Specials`, `Chaat & Loaded`).
- `Flavour_Profile` (String): Dominant taste profile.
- `Pieces_Per_Plate` (Integer): Standard portion count (6 or 5 pieces).
- `Selling_Price_INR` (Float): Counter selling price.
- `Cost_Price_INR` (Float): Unit recipe COGS.
- `Unit_Margin_INR` (Float): `Selling_Price - Cost_Price`.
- `Gross_Margin_Pct` (Float): Percentage contribution margin.

#### D. `golgappa_inventory_stock.csv`
*Primary granularity: One record per raw ingredient.*
- `Ingredient_Code` (String): Inventory SKU (`ING-PURI`, `ING-ALOO`, etc.).
- `Name` (String): Ingredient trade name.
- `Category` (String): Produce, Dry Savories, Dairy, Spices, Bakery.
- `Unit` (String): Unit of measure (`pcs`, `kg`, `liters`).
- `Current_Stock` (Float): Real-time balance.
- `Minimum_Threshold` (Float): Critical reserve safety level.
- `Reorder_Level` (Float): Restock trigger point.
- `Unit_Cost_INR` (Float): Purchase cost per unit from mandi/depot.
- `Daily_Avg_Consumption` (Float): Rolling daily demand.
- `Status` (String): `Optimal`, `Low`, or `Critical`.

#### E. `golgappa_food_waste_log.csv`
*Primary granularity: One record per waste audit incident.*
- `Log_ID` (String): Incident audit ID.
- `Date` (Date): Audit date.
- `Ingredient_Name` (String): Discarded ingredient.
- `Quantity_Wasted` (Float): Exact quantity discarded.
- `Unit` (String): Measurement unit.
- `Unit_Cost_INR` (Float): Replacement cost.
- `Estimated_Waste_Cost_INR` (Float): `Quantity_Wasted * Unit_Cost_INR`.
- `Reason` (String): Categorized root cause.
- `Severity` (String): `Normal` or `High`.
- `Recommended_Action` (String): Prescriptive mitigation guidance.

#### F. `golgappa_hourly_footfall_patterns.csv`
*Primary granularity: One record per operational hour.*
- `Hour_24` (Integer): 24-hour index (15 to 22).
- `Hour_Label` (String): Friendly format (`4:00 PM`, `5:00 PM`, etc.).
- `Order_Count` (Integer): Total orders completed in hour.
- `Plates_Served` (Integer): Total plate volume served.
- `Revenue_Collected_INR` (Float): Total revenue in hour.
- `COGS_INR` (Float): Direct ingredient expense.
- `Rush_Intensity` (String): Rush classification tag.

---

### 3. Step-by-Step Tableau Import & Dashboard Construction

1. **Launch Tableau Desktop or Tableau Public**.
2. Under **Connect** > **To a File**, click **Text file** and select `golgappa_daily_sales_summary.csv`.
3. In the Data Source canvas, drag `golgappa_food_waste_log.csv` and connect using a **Left Join** or **Relationship** on `[Date] = [Date]`.
4. Create the following Calculated Fields in Tableau:
   - `[Net Operating Margin %]`:
     ```tableau
     (SUM([Gross Profit INR]) - SUM([Estimated Waste Cost INR])) / SUM([Gross Revenue INR]) * 100
     ```
   - `[Wastage Financial Drag %]`:
     ```tableau
     SUM([Estimated Waste Cost INR]) / SUM([Total COGS INR]) * 100
     ```
   - `[Weekend Indicator]`:
     ```tableau
     IF [Day Of Week] = 'Saturday' OR [Day Of Week] = 'Sunday' THEN 'Weekend Rush' ELSE 'Weekday Regular' END
     ```
5. **Recommended Tableau Dashboards to Build**:
   - **Sheet 1: Executive Revenue & Waste Waterfall**: Dual-axis line & bar chart showing Gross Revenue, COGS, and Waste penalty.
   - **Sheet 2: Hourly Commuter Footfall Heatmap**: Columns = `[Hour Label]`, Rows = `[Day Of Week]`, Color = `SUM([Plates Served])`.
   - **Sheet 3: Flavour Matrix Scatter Plot**: X-axis = `[Gross Margin Pct]`, Y-axis = `[Total Units Sold]`, Size = `[Gross Revenue]`.
   - **Sheet 4: Ingredient Shrinkage Tree Map**: Hierarchy = `[Category] > [Ingredient Name]`, Size = `[Estimated Waste Cost INR]`.
