/**
 * Golgappa360 - Safe Global Error Handler Middleware
 */

export function errorHandler(err, req, res, next) {
  console.error('[API Server Error]', {
    method: req.method,
    path: req.path,
    query: req.query,
    error: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });

  // Never leak raw internal SQL errors to clients in production
  const safeMessage = process.env.NODE_ENV === 'development'
    ? err.message || 'Internal Server Error'
    : 'An internal database or analytics service error occurred. Please verify your query parameters.';

  res.status(err.status || 500).json({
    success: false,
    error: safeMessage,
    errorCode: err.code || 'INTERNAL_ERROR',
    timestamp: new Date().toISOString()
  });
}
