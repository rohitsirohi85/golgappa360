import React from 'react';
import { Sparkles, Waves, Compass, ChevronLeft, Zap, Palette, Layers } from 'lucide-react';

export const PresetPanel = ({
  activePreset,
  onSelectPreset,
  isOpen,
  onToggle,
}) => {
  const presets = [
    {
      id: 'particle-universe',
      name: 'Particle Universe',
      subtitle: 'GPU Cosmic Nebula',
      description: '45,000+ GPU particles flowing in an orbital harmonic field with audio bass surge & custom GLSL shaders.',
      icon: Sparkles,
      color: 'from-purple-500 to-cyan-400',
      tag: 'Procedural 3D',
      stats: '45k Particles • Additive',
    },
    {
      id: 'energy-waves',
      name: 'Energy Waves',
      subtitle: 'Harmonic Terrain Ribbon',
      description: 'Undulating dynamic wireframe matrix displaced by real Web Audio FFT frequency bins and mathematical waves.',
      icon: Waves,
      color: 'from-blue-500 to-cyan-300',
      tag: 'Dynamic Mesh',
      stats: '8k Vertices • Wireframe',
    },
    {
      id: 'neon-tunnel',
      name: 'Neon Tunnel',
      subtitle: 'Warp Cyber Corridor',
      description: 'Repeating polygonal geometric rings with infinite Z-depth, forward velocity warp, and kick-synced expansion.',
      icon: Compass,
      color: 'from-purple-600 to-pink-500',
      tag: 'Infinite Z-Space',
      stats: '36 Rings • Lasers',
    },
  ];

  if (!isOpen) return null;

  return (
    <aside className="w-80 border-r border-white/10 mb-panel flex flex-col z-20 transition-all duration-300 h-full overflow-hidden select-none">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h2 className="font-semibold text-sm text-slate-100 uppercase tracking-wider font-mono">
            Visual Presets
          </h2>
        </div>
        <button
          onClick={onToggle}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Collapse Panel"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Preset List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 mb-scrollbar">
        <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 px-1 flex items-center gap-1.5">
          <Zap className="w-3 h-3 text-cyan-400" />
          <span>Active Scenes ({presets.length})</span>
        </div>

        {presets.map((preset) => {
          const Icon = preset.icon;
          const isActive = activePreset === preset.id;

          return (
            <div
              key={preset.id}
              onClick={() => onSelectPreset(preset.id)}
              className={`p-3.5 rounded-xl border cursor-pointer mb-preset-card transition-all ${
                isActive
                  ? 'mb-preset-active'
                  : 'bg-black/40 border-white/5 hover:border-cyan-500/30'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-br ${
                      preset.color
                    } ${isActive ? 'shadow-md shadow-cyan-500/20' : 'opacity-80'}`}
                  >
                    <Icon className="w-4 h-4 text-black" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white tracking-wide">
                      {preset.name}
                    </h3>
                    <p className="text-[10px] text-cyan-400/90 font-mono">
                      {preset.subtitle}
                    </p>
                  </div>
                </div>

                <span
                  className={`text-[9px] font-mono px-2 py-0.5 rounded-full border ${
                    isActive
                      ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300 font-semibold'
                      : 'bg-white/5 border-white/10 text-slate-400'
                  }`}
                >
                  {preset.tag}
                </span>
              </div>

              <p className="text-[11px] text-slate-300/80 leading-relaxed line-clamp-2 mb-2 font-sans">
                {preset.description}
              </p>

              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-2 border-t border-white/5">
                <span>{preset.stats}</span>
                <span className={isActive ? 'text-cyan-400 font-semibold' : 'text-slate-500'}>
                  {isActive ? '● ACTIVE ENGINE' : 'SELECT'}
                </span>
              </div>
            </div>
          );
        })}

        {/* Studio Note */}
        <div className="mt-4 p-3 rounded-xl bg-purple-950/20 border border-purple-500/20 text-slate-300">
          <div className="flex items-center gap-1.5 text-purple-300 font-mono text-[11px] font-semibold mb-1">
            <Palette className="w-3.5 h-3.5" />
            <span>Harmonic Palette</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            Deep void black background with calibrated neon purple (#9333ea), electric blue (#2563eb), and cyan (#06b6d4) spectral lighting.
          </p>
        </div>
      </div>
    </aside>
  );
};
