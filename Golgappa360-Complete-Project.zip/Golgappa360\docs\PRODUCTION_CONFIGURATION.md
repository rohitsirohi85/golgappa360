# EV SMART — Production Deployment & Configuration Manual

**Document Version:** `1.0.0-RC1`  
**Target OS:** Ubuntu 22.04 LTS / Debian 12 / Containerized Linux  
**Runtime:** Node.js 20.x LTS, Python 3.11, Nginx 1.24+  
**Classification:** DevOps / Systems Administration Manual  

---

## 1. Production Architecture Overview

In a live production environment, EV SMART components are orchestrated behind an Nginx reverse proxy with SSL termination, PM2 process supervision, and managed cloud services (MongoDB Atlas and Cloud MQTT):

```
                        HTTPS / WSS (Port 443)
                                  │
                                  ▼
                   ┌──────────────────────────────┐
                   │       Nginx Reverse Proxy    │
                   │  - SSL/TLS Termination       │
                   │  - Let's Encrypt Certbot     │
                   │  - Static Asset Caching      │
                   └──────────────┬───────────────┘
                                  │
         ┌────────────────────────┼────────────────────────┐
         │ /api/*, /socket.io/*   │ / (Static PWA)         │ /predict/*
         ▼                        ▼                        ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│ Node.js Backend  │    │ Prebuilt Vite    │    │ Python ML Engine │
│ (PM2 Cluster)    │    │ Web Artifacts    │    │ (Uvicorn Systemd)│
│ Port 5000        │    │ /var/www/evsmart │    │ Port 8000        │
└──────────────────┘    └──────────────────┘    └──────────────────┘
```

---

## 2. Server Provisioning & Prerequisites

Run the following commands on a clean Ubuntu 22.04 LTS server:

```bash
# 1. Update OS packages
sudo apt update && sudo apt upgrade -y

# 2. Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx git ufw

# 3. Install Python 3.11 & virtualenv
sudo apt install -y python3 python3-pip python3-venv

# 4. Install PM2 Process Manager globally
sudo npm install -g pm2
```

---

## 3. Firewall Configuration (UFW)

Enforce strict inbound network boundaries:
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP (Let's Encrypt validation)
sudo ufw allow 443/tcp   # HTTPS & WSS
sudo ufw allow 8883/tcp  # MQTTS (if self-hosting MQTT broker)
sudo ufw enable
```

---

## 4. PM2 Process Supervision Configuration

Create `ecosystem.config.cjs` in the project root:

```javascript
module.exports = {
  apps: [
    {
      name: 'evsmart-backend',
      cwd: './backend',
      script: 'src/server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 5000,
      },
      max_memory_restart: '500M',
      restart_delay: 3000,
      time: true,
    },
    {
      name: 'evsmart-ml',
      cwd: './ml-service',
      script: 'python3',
      args: '-m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 2',
      interpreter: 'none',
      restart_delay: 5000,
      time: true,
    },
  ],
};
```

Start the supervised services:
```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

---

## 5. Nginx Production Reverse Proxy Configuration

Create `/etc/nginx/sites-available/evsmart.conf`:

```nginx
# Upstream clusters
upstream backend_cluster {
    server 127.0.0.1:5000;
    keepalive 64;
}

upstream ml_cluster {
    server 127.0.0.1:8000;
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name app.evsmart.com api.evsmart.com admin.evsmart.com;
    return 301 https://$host$request_uri;
}

# Master HTTPS Server Block
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.evsmart.com;

    # SSL Certificates (managed by Certbot)
    ssl_certificate /etc/letsencrypt/live/api.evsmart.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.evsmart.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Client payload limit
    client_max_body_size 5M;

    # API Routing
    location /api/ {
        proxy_pass http://backend_cluster;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket Real-Time Routing
    location /socket.io/ {
        proxy_pass http://backend_cluster;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }
}
```

Enable site and restart Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/evsmart.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

Obtain Let's Encrypt SSL certificates automatically:
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d api.evsmart.com -d app.evsmart.com
```

---

## 6. Frontend Production Build & Deployment

Build the optimized Vite bundle for production hosting:
```bash
cd d:\antigravty
npm run build
```
Upload the generated `dist/` directory contents to `/var/www/evsmart/dist` on your production web server.

---

## 7. Production Hardening Checklist

- [x] **Disable Demo Mode:** Set `DEMO_MODE=false` in `backend/.env`.
- [x] **Cryptographic Secret Generation:**
  ```bash
  openssl rand -base64 48
  ```
  Set output as `JWT_SECRET`.
- [x] **Atlas Cloud Database:** Set `MONGODB_URI` pointing to secure Atlas replica set with TLS enabled.
- [x] **Strict CORS Origin:** Limit `CORS_ORIGIN` strictly to live domains (`https://app.evsmart.com,https://admin.evsmart.com`).
- [x] **Rate Limiting:** Global rate limiters active (`generalApiLimiter: 100/15m`, `authLimiter: 5/15m`, `mlLimiter: 20/m`).
- [x] **Secure IoT Broker:** Connect via TLS on port `8883` with client certificate verification.
