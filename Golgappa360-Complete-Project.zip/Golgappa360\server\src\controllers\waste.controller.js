import { AnalyticsService } from '../services/analyticsService.js';

export async function getSummary(req, res, next) {
  try {
    const { range = '180d' } = req.query;
    const result = await AnalyticsService.getWasteSummary({ range });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}
