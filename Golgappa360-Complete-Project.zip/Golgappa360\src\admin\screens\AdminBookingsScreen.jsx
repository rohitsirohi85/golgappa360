import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  CalendarCheck,
  Search,
  Filter,
  Clock,
  Building2,
  Zap,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';

export const AdminBookingsScreen = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const data = await adminService.getBookings();
      if (Array.isArray(data)) {
        setBookings(data);
      }
    } catch (err) {
      console.error('Error fetching bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const filteredBookings = bookings.filter((b) => {
    const matchesSearch =
      b.userId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.stationId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.chargerId?.chargerNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b._id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <AdminLayout
      pageTitle="Reservation Management"
      subtitle="Fleet-wide slot reservations, driver booking schedules & slot fulfillment"
    >
      {/* Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by customer, booking ID, bay..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            {['all', 'confirmed', 'active', 'completed', 'cancelled'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg capitalize font-semibold transition-colors ${
                  statusFilter === st
                    ? 'bg-emerald-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchBookings}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Bookings Table */}
      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading booking ledger...</p>
        </div>
      ) : filteredBookings.length === 0 ? (
        <div className="h-64 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-slate-500 text-xs">
          <CalendarCheck className="w-10 h-10 mb-2 text-slate-700" />
          <p>No slot bookings matching search.</p>
        </div>
      ) : (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                  <th className="py-4 px-6 font-bold">Booking ID</th>
                  <th className="py-4 px-6 font-bold">Driver / User</th>
                  <th className="py-4 px-6 font-bold">Station & Bay</th>
                  <th className="py-4 px-6 font-bold">Slot Time</th>
                  <th className="py-4 px-6 font-bold">Status</th>
                  <th className="py-4 px-6 font-bold text-right">Fee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredBookings.map((b) => (
                  <tr key={b._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-4 px-6 font-mono text-slate-400">
                      {b._id.slice(-6).toUpperCase()}
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-bold text-white block">{b.userId?.name || 'EV Driver'}</span>
                      <span className="text-[11px] text-slate-500 font-mono">{b.userId?.email}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-semibold text-white block">{b.stationId?.name || 'EV Hub'}</span>
                      <span className="text-[11px] text-emerald-400 font-mono">
                        {b.chargerId?.chargerNumber || 'CH-01'}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>
                          {new Date(b.slotStartTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}{' '}
                          -{' '}
                          {new Date(b.slotEndTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500">
                        {new Date(b.date || b.slotStartTime).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${
                          b.status === 'confirmed'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : b.status === 'active'
                            ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                            : b.status === 'completed'
                            ? 'bg-slate-800 text-slate-300'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right font-mono font-bold text-white">
                      ₹{b.bookingFee || 50}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminBookingsScreen;
