import React, { useState } from 'react';
import { ArrowUpRight, Clock, Activity, Zap, CheckCircle2, ChevronRight } from 'lucide-react';
import { DANCE_PROGRAMS } from '../data/danceData';

export const ProgramsSection = ({ onOpenTrial }) => {
  const [activeProgramId, setActiveProgramId] = useState(DANCE_PROGRAMS[0].id);

  const activeProgram =
    DANCE_PROGRAMS.find((p) => p.id === activeProgramId) || DANCE_PROGRAMS[0];

  return (
    <section
      id="programs"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="Dance Disciplines & Programs"
    >
      {/* Background ambient spotlight */}
      <div className="pointer-events-none absolute bottom-10 right-0 w-[500px] h-[500px] bg-[#8B5CF6]/10 rounded-full blur-[140px]" />

      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/[0.08]">
          <div>
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ 03 // CURATED DISCIPLINES ]
            </span>
            <h2 className="editorial-headline text-3xl sm:text-5xl lg:text-6xl text-[#F5F3F8] uppercase">
              FIVE DISCIPLINES. <br />
              <span className="text-[#A78BFA]">ONE ARTISTIC STANDARD.</span>
            </h2>
          </div>
          <p className="font-sans text-sm sm:text-base text-[#A5A1B2] max-w-md leading-relaxed">
            From underground street battles to avant-garde theater stages. Each curriculum is constructed around physiological foundation, musical pocket, and personal style.
          </p>
        </div>

        {/* Interactive Discipline Switcher Bar (Desktop & Tablet) */}
        <div className="mt-10 flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 border-b border-white/[0.08]">
          {DANCE_PROGRAMS.map((prog, idx) => {
            const isActive = prog.id === activeProgramId;
            return (
              <button
                key={prog.id}
                onClick={() => setActiveProgramId(prog.id)}
                className={`flex-shrink-0 flex items-center gap-3 px-5 py-3 rounded-sm font-sans text-xs sm:text-sm tracking-wider uppercase font-semibold transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
                  isActive
                    ? 'bg-[#14141B] text-white border-b-2 border-[#8B5CF6] shadow-[0_4px_20px_rgba(139,92,246,0.15)]'
                    : 'text-[#A5A1B2] hover:text-[#F5F3F8] hover:bg-white/[0.03]'
                }`}
              >
                <span className={`font-mono text-[11px] ${isActive ? 'text-[#8B5CF6]' : 'opacity-60'}`}>
                  0{idx + 1}
                </span>
                <span>{prog.name}</span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Expressive Editorial Showcase for the Selected Program */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Left Column: Expressive Large Imagery & Style Badges */}
          <div className="lg:col-span-6 relative flex flex-col">
            <div className="relative w-full aspect-[4/5] sm:aspect-[16/11] lg:aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#14141B] shadow-2xl">
              <img
                key={activeProgram.image}
                src={activeProgram.image}
                alt={`${activeProgram.name} dance discipline showcase photograph`}
                loading="lazy"
                className="w-full h-full object-cover object-center filter contrast-[1.1] brightness-[0.92] transition-all duration-500 scale-100 hover:scale-[1.02]"
              />

              {/* Edge Gradient and Film Grain */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-[#0B0B0F]/30 to-transparent opacity-90 pointer-events-none" />
              <div className="film-grain absolute inset-0 pointer-events-none" />

              {/* Top Badges */}
              <div className="absolute top-5 left-5 right-5 flex items-center justify-between pointer-events-none z-10">
                <span className="font-mono text-[10px] font-semibold text-white bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-sm border border-white/10 tracking-widest uppercase">
                  {activeProgram.badge}
                </span>
                <span className="font-mono text-[10px] text-[#A78BFA] bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-sm border border-[#8B5CF6]/30 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3 h-3 text-[#8B5CF6]" />
                  {activeProgram.tempoRange}
                </span>
              </div>

              {/* Bottom Image Caption Overlay */}
              <div className="absolute bottom-6 left-6 right-6 z-10 pointer-events-none">
                <span className="font-mono text-xs text-[#8B5CF6] uppercase tracking-widest block mb-1">
                  FACULTY LEAD // {activeProgram.leadInstructor}
                </span>
                <h3 className="font-display font-black text-2xl sm:text-3xl text-white uppercase tracking-tight">
                  {activeProgram.subtitle}
                </h3>
              </div>
            </div>

            {/* Quick Metrics Strip below image */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="p-4 rounded-sm bg-[#14141B] border border-white/[0.07] flex items-center gap-3">
                <Zap className="w-4 h-4 text-[#8B5CF6] flex-shrink-0" />
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Energy Profile</span>
                  <span className="font-sans text-xs font-semibold text-white">{activeProgram.intensity}</span>
                </div>
              </div>
              <div className="p-4 rounded-sm bg-[#14141B] border border-white/[0.07] flex items-center gap-3">
                <Clock className="w-4 h-4 text-[#8B5CF6] flex-shrink-0" />
                <div>
                  <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Weekly Slots</span>
                  <span className="font-sans text-xs font-semibold text-white">{activeProgram.schedulePreview}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Deep Curriculum Architecture & Action */}
          <div className="lg:col-span-6 flex flex-col justify-between p-6 sm:p-8 rounded-sm bg-[#14141B] border border-white/[0.08]">
            <div>
              {/* Program Header */}
              <div className="flex items-center gap-2 mb-3">
                <span className="font-mono text-xs text-[#8B5CF6] font-bold">DISCIPLINE OVERVIEW</span>
              </div>
              <h3 className="font-display font-extrabold text-3xl sm:text-4xl text-[#F5F3F8] uppercase tracking-tight">
                {activeProgram.name}
              </h3>
              <p className="mt-2 text-sm sm:text-base font-medium text-[#A78BFA]">
                {activeProgram.tagline}
              </p>

              {/* Full Description */}
              <p className="mt-5 text-sm text-[#A5A1B2] leading-relaxed">
                {activeProgram.description}
              </p>

              {/* Syllabus Highlights */}
              <div className="mt-8">
                <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
                  CORE MOVEMENT SYLLABUS
                </h4>
                <div className="space-y-3">
                  {activeProgram.highlights.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] mt-0.5 flex-shrink-0" />
                      <span className="text-xs sm:text-sm text-[#F5F3F8] leading-snug">
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Progression Levels */}
              <div className="mt-8 pt-6 border-t border-white/[0.08]">
                <h4 className="font-mono text-xs uppercase tracking-wider text-[#A5A1B2] font-semibold mb-3">
                  PROGRESSION STAGES
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeProgram.levels.map((lvl, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-sm bg-[#0B0B0F] border border-white/[0.08] text-xs font-mono text-[#F5F3F8]"
                    >
                      <span className="text-[#8B5CF6] font-bold">0{idx + 1}</span>
                      {lvl}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Booking Trigger */}
            <div className="mt-8 pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div>
                <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Next Intake Cycle</span>
                <span className="font-sans text-xs font-semibold text-white">Enrollment Open — Limited Floor Slots</span>
              </div>

              <button
                onClick={() => onOpenTrial(activeProgram.id)}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs font-semibold tracking-widest uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all duration-200 rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.5)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              >
                <span>BOOK A TRIAL FOR {activeProgram.name.toUpperCase()}</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
