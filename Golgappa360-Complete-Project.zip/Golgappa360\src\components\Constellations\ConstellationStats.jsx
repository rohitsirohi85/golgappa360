import React, { useMemo } from 'react';
import {
  getTotalOfficialConstellationsCount,
  getFeaturedConstellationsCount,
  getTotalCatalogedConstellationStarsCount,
} from '../../data/constellations';

/**
 * ConstellationStats — Dynamic statistics strip for the Constellation Atlas
 * Values are dynamically computed from datasets rather than hardcoded.
 */
export default function ConstellationStats() {
  const stats = useMemo(() => [
    {
      value: getTotalOfficialConstellationsCount(),
      label: 'OFFICIAL CONSTELLATIONS',
      sublabel: 'IAU Standard Celestial Sphere',
    },
    {
      value: getFeaturedConstellationsCount(),
      label: 'FEATURED HERE',
      sublabel: 'Interactive High-Res Atlases',
    },
    {
      value: getTotalCatalogedConstellationStarsCount(),
      label: 'MAJOR STARS MAPPED',
      sublabel: 'Real Spectroscopic Telemetry',
    },
    {
      value: '1',
      label: 'SHARED NIGHT SKY',
      sublabel: 'One Human Perspective',
    },
  ], []);

  return (
    <div className="w-full max-w-5xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {stats.map((stat, idx) => (
        <div
          key={idx}
          className="p-4 sm:p-5 rounded-2xl glass-surface border border-white/10 hover:border-cyan-500/30 transition-all text-center flex flex-col justify-center items-center shadow-md group"
        >
          <span className="font-display text-2xl sm:text-3xl lg:text-4xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-sky-400 group-hover:scale-105 transition-transform duration-300">
            {stat.value}
          </span>
          <span className="text-[11px] sm:text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold mt-1">
            {stat.label}
          </span>
          <span className="text-[10px] font-mono text-slate-500 mt-0.5 hidden sm:block">
            {stat.sublabel}
          </span>
        </div>
      ))}
    </div>
  );
}
