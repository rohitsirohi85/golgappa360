import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import StarField from '../components/StarField';
import Hero from '../components/Hero';
import UniverseMap from '../components/universe/UniverseMap';
import ErrorBoundary from '../components/ErrorBoundary';
import IntroSection from '../components/IntroSection';
import StarsExplorer from '../components/StarsExplorer';
import StarTypesSection from '../components/StarTypesSection';
import LifeCycleSection from '../components/LifeCycleSection';
import ConstellationsSection from '../components/ConstellationsSection';
import QuizSection from '../components/QuizSection';
import Footer from '../components/Footer';
import CosmicTimeline from '../components/timeline/CosmicTimeline';
import StarModal from '../components/StarModal';
import { getCelestialObjectById } from '../data/celestialObjects.js';
import { getConstellationById } from '../data/constellations.js';

/**
 * Home Page — STELLAR Exploration Platform
 * Orchestrates Navbar, dynamic StarField, Hero, Intro, StarsExplorer,
 * StarTypesSection (Stellar Classification & Types),
 * LifeCycleSection (Stellar Evolution & Life Cycle),
 * ConstellationsSection (Constellation Explorer Atlas),
 * QuizSection (Cosmic Mission Quiz & Knowledge Hub), and Footer.
 * 
 * Supports deep linking via URL hash (#object=id, #constellation=id).
 */
export default function Home() {
  const [activeSection, setActiveSection] = useState('home');
  const [externalSelectedStar, setExternalSelectedStar] = useState(null);
  const [externalSelectedConstellation, setExternalSelectedConstellation] = useState(null);
  const [timelineMilestoneId, setTimelineMilestoneId] = useState(null);
  const [timelineModalObject, setTimelineModalObject] = useState(null);

  // Track active section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 220;
      const sections = [
        'home',
        'universe-map',
        'timeline',
        'intro',
        'stars',
        'star-types',
        'life-cycle',
        'constellations',
        'quiz',
      ];

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle URL hash deep-linking on initial mount and hashchange
  useEffect(() => {
    const handleHashNavigation = () => {
      const hash = window.location.hash;
      if (!hash) return;

      if (hash.startsWith('#object=')) {
        const targetId = hash.replace('#object=', '').trim().toLowerCase();
        const obj = getCelestialObjectById(targetId);
        if (obj) {
          const mapElement = document.getElementById('universe-map');
          if (mapElement) {
            mapElement.scrollIntoView({ behavior: 'smooth' });
          }
          setTimeout(() => {
            window.dispatchEvent(
              new CustomEvent('stellar:locate-object', { detail: obj })
            );
          }, 350);
        }
      } else if (hash.startsWith('#constellation=')) {
        const constId = hash.replace('#constellation=', '').trim().toLowerCase();
        const constellation = getConstellationById(constId);
        if (constellation) {
          const mapElement = document.getElementById('universe-map');
          if (mapElement) {
            mapElement.scrollIntoView({ behavior: 'smooth' });
          }
          setTimeout(() => {
            window.dispatchEvent(
              new CustomEvent('stellar:locate-constellation', { detail: constellation })
            );
          }, 350);
        }
      } else if (hash.startsWith('#timeline')) {
        const raw = hash.replace('#timeline=', '').replace('#timeline', '').trim().toLowerCase();
        if (raw) {
          setTimelineMilestoneId(raw);
        }
        const timelineElement = document.getElementById('timeline');
        if (timelineElement) {
          timelineElement.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };

    // Slight delay on initial load to ensure DOM & canvas listeners are mounted
    const timer = setTimeout(handleHashNavigation, 250);
    window.addEventListener('hashchange', handleHashNavigation);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('hashchange', handleHashNavigation);
    };
  }, []);

  // Listen for custom stellar:open-timeline navigation event
  useEffect(() => {
    const handleTimelineEvent = (e) => {
      const milestoneId = typeof e.detail === 'string' ? e.detail : e.detail?.id;
      if (milestoneId) {
        setTimelineMilestoneId(milestoneId);
      }
      const timelineElement = document.getElementById('timeline');
      if (timelineElement) {
        timelineElement.scrollIntoView({ behavior: 'smooth' });
      }
    };

    window.addEventListener('stellar:open-timeline', handleTimelineEvent);
    return () => window.removeEventListener('stellar:open-timeline', handleTimelineEvent);
  }, []);

  // When a user selects an example star from Star Types, Life Cycle, Constellations, or Quiz sections
  const handleSelectStarFromExternal = (star) => {
    setExternalSelectedStar(star);
    const starsElement = document.getElementById('stars');
    if (starsElement) {
      starsElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleClearExternalStar = () => {
    setExternalSelectedStar(null);
  };

  // When a user clicks "View on Universe Map" from Constellations section
  const handleSelectConstellationFromExternal = (constellationId) => {
    setExternalSelectedConstellation(constellationId);
    const mapElement = document.getElementById('universe-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleClearExternalConstellation = () => {
    setExternalSelectedConstellation(null);
  };

  // Timeline Action Handlers (Phase U13)
  const handleTimelineEnterPresentUniverse = () => {
    const mapElement = document.getElementById('universe-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleTimelineExploreSolarSystem = () => {
    const sunObj = getCelestialObjectById('sun');
    const mapElement = document.getElementById('universe-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
    if (sunObj) {
      setTimeout(() => {
        window.dispatchEvent(
          new CustomEvent('stellar:locate-object', { detail: sunObj })
        );
      }, 350);
    }
  };

  const handleTimelineExploreEarth = () => {
    const earthObj = getCelestialObjectById('earth');
    const mapElement = document.getElementById('universe-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
    if (earthObj) {
      setTimeout(() => {
        window.dispatchEvent(
          new CustomEvent('stellar:locate-object', { detail: earthObj })
        );
      }, 350);
    }
  };

  const handleTimelineExploreMoon = () => {
    const moonObj = getCelestialObjectById('moon');
    const mapElement = document.getElementById('universe-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
    if (moonObj) {
      setTimeout(() => {
        window.dispatchEvent(
          new CustomEvent('stellar:locate-object', { detail: moonObj })
        );
      }, 350);
    }
  };

  const handleTimelineExploreStars = () => {
    const starsElement = document.getElementById('stars');
    if (starsElement) {
      starsElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleTimelineExploreLifeCycle = () => {
    const lifeCycleElement = document.getElementById('life-cycle');
    if (lifeCycleElement) {
      lifeCycleElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#020308] text-slate-100 flex flex-col selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* Dynamic Animated Star Field Background */}
      <StarField />

      {/* Floating Glassmorphic Navbar with Universal Search */}
      <Navbar activeSection={activeSection} />

      {/* Main Content Area */}
      <main className="relative z-10 flex-grow">
        {/* Full-Screen Cinematic Hero */}
        <Hero />

        {/* Interactive Universe Map (STELLAR 2.0 Feature) */}
        <ErrorBoundary
          fallback={
            <section
              id="universe-map"
              className="py-16 text-center text-slate-400 bg-[#020308] border-b border-white/5"
            >
              <div className="max-w-md mx-auto p-6 rounded-xl border border-white/10 bg-white/[0.02]">
                <div className="text-cyan-400 text-xl mb-2 font-mono">✦</div>
                <h3 className="text-white font-display text-lg font-semibold mb-1">
                  Universe visualization temporarily unavailable.
                </h3>
                <p className="text-xs font-mono text-slate-400">
                  Please refresh the page or explore the star catalog below.
                </p>
              </div>
            </section>
          }
        >
          <UniverseMap
            onOpenExternalStar={handleSelectStarFromExternal}
            externalSelectedConstellation={externalSelectedConstellation}
            onClearExternalConstellation={handleClearExternalConstellation}
          />
        </ErrorBoundary>

        {/* Interactive Cosmic Timeline (STELLAR 2.0 Phase U13) */}
        <ErrorBoundary
          fallback={
            <section
              id="timeline"
              className="py-16 text-center text-slate-400 bg-[#020308] border-b border-white/5"
            >
              <div className="max-w-md mx-auto p-6 rounded-xl border border-white/10 bg-white/[0.02]">
                <div className="text-cyan-400 text-xl mb-2 font-mono">⏳</div>
                <h3 className="text-white font-display text-lg font-semibold mb-1">
                  Cosmic Timeline temporarily unavailable.
                </h3>
              </div>
            </section>
          }
        >
          <CosmicTimeline
            initialMilestoneId={timelineMilestoneId}
            onEnterPresentUniverse={handleTimelineEnterPresentUniverse}
            onExploreSolarSystem={handleTimelineExploreSolarSystem}
            onExploreEarth={handleTimelineExploreEarth}
            onExploreMoon={handleTimelineExploreMoon}
            onExploreStars={handleTimelineExploreStars}
            onExploreLifeCycle={handleTimelineExploreLifeCycle}
            onOpenObjectDetails={(obj) => setTimelineModalObject(obj)}
          />
        </ErrorBoundary>

        {/* Introduction Section ("EVERY STAR HAS A STORY.") */}
        <IntroSection />

        {/* Stars Explorer (Phase 2 Interactive Stellar Observatory) */}
        <StarsExplorer
          externalSelectedStar={externalSelectedStar}
          onClearExternalStar={handleClearExternalStar}
        />

        {/* Star Types & Stellar Classification (Phase 3 Interactive Experience) */}
        <StarTypesSection onSelectStarFromTypes={handleSelectStarFromExternal} />

        {/* Life of a Star & Stellar Evolution (Phase 4 Interactive Experience) */}
        <LifeCycleSection onSelectStarFromLifeCycle={handleSelectStarFromExternal} />

        {/* Constellation Explorer & Night Sky Atlas (Phase 5 Interactive Experience) */}
        <ConstellationsSection
          onSelectStarFromConstellation={handleSelectStarFromExternal}
          onViewConstellationOnMap={handleSelectConstellationFromExternal}
        />

        {/* Cosmic Mission Quiz & Knowledge Hub (Phase 6 Interactive Experience) */}
        <QuizSection onExploreStar={handleSelectStarFromExternal} />
      </main>

      {/* Timeline Related Target Details Modal */}
      {timelineModalObject && (
        <StarModal
          object={timelineModalObject}
          isOpen={!!timelineModalObject}
          onClose={() => setTimelineModalObject(null)}
          onLocateOnMap={(obj) => {
            setTimelineModalObject(null);
            const mapElement = document.getElementById('universe-map');
            if (mapElement) {
              mapElement.scrollIntoView({ behavior: 'smooth' });
            }
            setTimeout(() => {
              window.dispatchEvent(
                new CustomEvent('stellar:locate-object', { detail: obj })
              );
            }, 350);
          }}
        />
      )}

      {/* Minimalist Premium Footer */}
      <Footer />
    </div>
  );
}
