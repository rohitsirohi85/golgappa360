import React from 'react';
import { Inbox, RotateCcw } from 'lucide-react';

export const EmptyState = ({
  title = 'No Records Found',
  description = 'There are currently no data entries matching your query or filter criteria.',
  actionLabel = 'Reset Filters',
  onAction,
  icon: Icon = Inbox,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-10 text-center rounded-xl bg-white border border-dashed border-[#D2DDD4] shadow-xs">
      <div className="p-3.5 rounded-full bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] mb-4">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-base font-semibold text-[#25332D] tracking-tight">
        {title}
      </h3>
      <p className="mt-1 text-xs text-[#77847C] max-w-sm">
        {description}
      </p>
      {onAction && (
        <button
          onClick={onAction}
          className="mt-5 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] hover:bg-[#D8F0E1] transition-all cursor-pointer shadow-xs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          {actionLabel}
        </button>
      )}
    </div>
  );
};
