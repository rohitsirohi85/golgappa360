import React from 'react';
import { BottomNavigation } from './BottomNavigation';

export const UserBottomNavigation = () => {
  return <BottomNavigation />;
};

export default UserBottomNavigation;
