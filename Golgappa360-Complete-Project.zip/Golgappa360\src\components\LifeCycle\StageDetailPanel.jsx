import React from 'react';
import { STARS_DATA } from '../../data/stars';

/**
 * StageDetailPanel — Scientific explanation panel for active lifecycle stage
 * Displays:
 * - STAGE NAME & SUBTITLE
 * - Short explanation
 * - KEY PROCESS
 * - TIMESCALE / DURATION
 * - TEMPERATURE / CONDITION
 * - WHAT HAPPENS NEXT?
 * - Connected real star examples (linked to Stars Explorer)
 */
export default function StageDetailPanel({ stage, onExploreStar }) {
  if (!stage) return null;

  // Find related real star objects from STARS_DATA
  const relatedStars = (stage.relatedStarIds || [])
    .map((id) => STARS_DATA.find((s) => s.id === id))
    .filter(Boolean);

  return (
    <div className="w-full flex flex-col text-left p-6 sm:p-8 lg:p-10 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
      {/* Top Header Badge */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-6 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <span
            className="w-2.5 h-2.5 rounded-full animate-pulse"
            style={{ backgroundColor: stage.colorHex, boxShadow: `0 0 10px ${stage.colorHex}` }}
          />
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-cyan-400">
            PHASE {stage.stepNumber} // STELLAR DOSSIER
          </span>
        </div>

        <span className="text-xs font-mono text-slate-400">
          TIMESCALE: <strong className="text-white">{stage.timescale}</strong>
        </span>
      </div>

      {/* Stage Name & Subtitle */}
      <div className="mb-6">
        <h3 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-2">
          {stage.title}
        </h3>
        <p className="text-sm font-mono tracking-widest uppercase text-amber-300/90 font-medium">
          “{stage.subtitle}”
        </p>
      </div>

      {/* Short Narrative Explanation */}
      <p className="font-sans text-base sm:text-lg text-slate-200/90 leading-relaxed font-normal mb-8 max-w-3xl">
        {stage.shortExplanation}
      </p>

      {/* Scientific Telemetry Properties Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {/* Key Process */}
        <div className="p-4 rounded-2xl bg-[#020308]/60 border border-white/8">
          <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 block mb-1">
            KEY PROCESS
          </span>
          <p className="font-sans text-sm text-slate-200 leading-relaxed font-medium">
            {stage.keyProcess}
          </p>
        </div>

        {/* Temperature & Thermodynamic Condition */}
        <div className="p-4 rounded-2xl bg-[#020308]/60 border border-white/8">
          <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 block mb-1">
            TEMPERATURE / CONDITION
          </span>
          <p className="font-sans text-sm text-slate-200 leading-relaxed font-medium">
            {stage.temperatureCondition}
          </p>
        </div>

        {/* Main Material State */}
        <div className="p-4 rounded-2xl bg-[#020308]/60 border border-white/8 md:col-span-2">
          <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-1">
            MATERIAL COMPOSITION
          </span>
          <p className="font-sans text-sm text-slate-300 leading-relaxed">
            {stage.mainMaterial}
          </p>
        </div>
      </div>

      {/* WHAT HAPPENS NEXT? Callout */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/20 via-indigo-950/20 to-transparent border border-cyan-500/30 mb-8">
        <div className="flex items-center gap-2 mb-2 text-xs font-mono uppercase tracking-widest text-cyan-300 font-semibold">
          <span>▸</span>
          <span>WHAT HAPPENS NEXT?</span>
        </div>
        <p className="font-sans text-sm text-slate-200/90 leading-relaxed">
          {stage.whatHappensNext}
        </p>
      </div>

      {/* Real Stars In This Stage */}
      {relatedStars.length > 0 && (
        <div className="pt-6 border-t border-white/10">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
              REAL CATALOG EXAMPLES IN THIS PHASE:
            </span>
          </div>

          <div className="flex flex-wrap gap-3">
            {relatedStars.map((star) => (
              <button
                key={star.id}
                type="button"
                onClick={() => onExploreStar && onExploreStar(star)}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-surface border border-white/15 hover:border-cyan-400/50 hover:bg-white/10 text-xs font-mono text-slate-200 hover:text-white transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 shadow-sm"
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: star.colorHex }}
                />
                <span className="font-medium text-white">{star.name}</span>
                <span className="text-slate-400">({star.constellation})</span>
                <span className="text-cyan-400">↗</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
