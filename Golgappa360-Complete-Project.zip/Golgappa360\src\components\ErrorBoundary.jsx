import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('STELLAR Observatory Error Caught:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div className="min-h-screen bg-[#030712] flex flex-col items-center justify-center p-6 text-white text-center">
          <div className="w-16 h-16 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(6,182,212,0.2)]">
            <span className="text-2xl text-cyan-400">✦</span>
          </div>

          <h2 className="font-display text-2xl font-bold tracking-tight mb-2">
            Telemetry Interruption
          </h2>
          <p className="text-sm text-slate-400 font-mono max-w-md mb-6">
            {this.state.error?.message || 'An unexpected stellar anomaly occurred.'}
          </p>

          <button
            onClick={this.handleReload}
            className="px-6 py-2.5 rounded-full bg-gradient-to-r from-sky-400 to-indigo-500 text-slate-950 font-semibold text-sm shadow-[0_0_20px_rgba(56,189,248,0.4)] hover:shadow-[0_0_30px_rgba(56,189,248,0.6)] transition-all cursor-pointer"
          >
            Re-align Observatory
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
