/**
 * Golgappa360 - Synthetic Data Store & Analytics Query Bridge
 * 
 * Ingests the 6-month synthetic dataset from data/synthetic/ and powers all API routes
 * using the centralized analytics calculation engine.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import * as analytics from '../analytics/golgappaAnalytics.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SYNTHETIC_DATA_DIR = path.resolve(__dirname, '../../../data/synthetic');

// In-memory indexed datasets
let products = [];
let ingredients = [];
let sales = [];
let inventoryTransactions = [];
let dailyExpenses = [];

let productsMap = new Map();
let ingredientsMap = new Map();

/**
 * Fast RFC-compliant CSV parser
 */
function parseCSV(content) {
  const lines = content.trim().split('\n').filter(l => l.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };

  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  const rows = [];

  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i];
    const values = [];
    let insideQuote = false;
    let currentVal = '';

    for (let c = 0; c < rawLine.length; c++) {
      const ch = rawLine[c];
      if (ch === '"') {
        insideQuote = !insideQuote;
      } else if (ch === ',' && !insideQuote) {
        values.push(currentVal.trim());
        currentVal = '';
      } else {
        currentVal += ch;
      }
    }
    values.push(currentVal.trim());

    const rowObj = {};
    headers.forEach((h, idx) => {
      let val = values[idx] || '';
      if (val.startsWith('"') && val.endsWith('"')) {
        val = val.slice(1, -1).replace(/""/g, '"');
      }
      rowObj[h] = val;
    });
    rows.push(rowObj);
  }

  return { headers, rows };
}

/**
 * Initializes and loads all 5 synthetic CSV files
 */
export function loadSyntheticDataset() {
  console.log('[SyntheticStore] Ingesting 6-month synthetic dataset from:', SYNTHETIC_DATA_DIR);

  // 1. products.csv
  const prodPath = path.join(SYNTHETIC_DATA_DIR, 'products.csv');
  if (fs.existsSync(prodPath)) {
    const parsed = parseCSV(fs.readFileSync(prodPath, 'utf8'));
    products = parsed.rows.map(p => ({
      product_id: p.product_id,
      product_name: p.product_name,
      category: p.category,
      selling_price: parseFloat(p.selling_price),
      ingredient_cost_per_plate: parseFloat(p.ingredient_cost_per_plate)
    }));
    productsMap = new Map(products.map(p => [p.product_id, p]));
  }

  // 2. ingredients.csv
  const ingPath = path.join(SYNTHETIC_DATA_DIR, 'ingredients.csv');
  if (fs.existsSync(ingPath)) {
    const parsed = parseCSV(fs.readFileSync(ingPath, 'utf8'));
    ingredients = parsed.rows.map(ing => ({
      ingredient_id: ing.ingredient_id,
      ingredient_name: ing.ingredient_name,
      unit: ing.unit,
      unit_cost: parseFloat(ing.unit_cost),
      reorder_level: parseFloat(ing.reorder_level)
    }));
    ingredientsMap = new Map(ingredients.map(i => [i.ingredient_id, i]));
  }

  // 3. sales.csv
  const salesPath = path.join(SYNTHETIC_DATA_DIR, 'sales.csv');
  if (fs.existsSync(salesPath)) {
    const parsed = parseCSV(fs.readFileSync(salesPath, 'utf8'));
    sales = parsed.rows.map(s => ({
      sale_id: s.sale_id,
      sale_datetime: s.sale_datetime,
      product_id: s.product_id,
      quantity_plates: parseInt(s.quantity_plates, 10),
      unit_price: parseFloat(s.unit_price),
      discount: parseFloat(s.discount || 0),
      payment_method: s.payment_method
    }));
  }

  // 4. inventory_transactions.csv
  const invPath = path.join(SYNTHETIC_DATA_DIR, 'inventory_transactions.csv');
  if (fs.existsSync(invPath)) {
    const parsed = parseCSV(fs.readFileSync(invPath, 'utf8'));
    inventoryTransactions = parsed.rows.map(tx => ({
      transaction_id: tx.transaction_id,
      transaction_date: tx.transaction_date,
      ingredient_id: tx.ingredient_id,
      transaction_type: tx.transaction_type,
      quantity: parseFloat(tx.quantity),
      reference_id: tx.reference_id
    }));
  }

  // 5. daily_expenses.csv
  const expPath = path.join(SYNTHETIC_DATA_DIR, 'daily_expenses.csv');
  if (fs.existsSync(expPath)) {
    const parsed = parseCSV(fs.readFileSync(expPath, 'utf8'));
    dailyExpenses = parsed.rows.map(e => ({
      expense_id: e.expense_id,
      expense_date: e.expense_date,
      expense_category: e.expense_category,
      amount: parseFloat(e.amount)
    }));
  }

  console.log(`[SyntheticStore] Loaded: ${products.length} products, ${ingredients.length} ingredients, ${sales.length} sales, ${inventoryTransactions.length} inventory txs, ${dailyExpenses.length} expenses.`);
}

// Automatically load on import
loadSyntheticDataset();

/**
 * Overview Metrics Endpoint
 */
export function getOverviewMetrics(rangeKey = '30d', productId = 'all') {
  const { startDate, endDate, label } = analytics.resolveDateRange(rangeKey);

  // Filter sales, expenses, waste
  const filteredSales = analytics.filterSales(sales, { startDate, endDate, productId });
  const filteredExpenses = analytics.filterExpenses(dailyExpenses, { startDate, endDate });
  const filteredWaste = analytics.filterInventoryTransactions(inventoryTransactions, {
    startDate,
    endDate,
    types: 'WASTE'
  });

  // Calculate standard KPIs
  const kpis = analytics.calculateKpis({
    sales: filteredSales,
    expenses: filteredExpenses,
    wasteTransactions: filteredWaste,
    productsMap,
    ingredientsMap
  });

  // Daily Trend for area chart
  const dailySalesChart = analytics.calculateDailyTrend(
    filteredSales,
    filteredExpenses,
    filteredWaste,
    productsMap,
    ingredientsMap
  );

  // Hourly profile for active rush chart
  const hourlySalesProfile = analytics.calculateHourlyProfile(filteredSales, productsMap);

  // Top products ranking
  const productSalesDistribution = analytics.calculateProductPerformance(filteredSales, products);

  // Recent 10 transactions
  const recentTransactions = filteredSales.slice(-10).reverse().map(s => {
    const prod = productsMap.get(s.product_id);
    const itemCost = prod ? prod.ingredient_cost_per_plate : 0;
    const amount = (s.quantity_plates * s.unit_price) - s.discount;
    const cost = s.quantity_plates * itemCost;
    const profit = amount - cost;
    const time = s.sale_datetime ? s.sale_datetime.split(' ')[1]?.slice(0, 5) : '19:00';

    return {
      id: s.sale_id,
      time,
      timestamp: s.sale_datetime,
      customerType: s.quantity_plates >= 3 ? 'Takeaway' : 'Dine-in',
      itemsSummary: `${s.quantity_plates}x ${prod ? prod.product_name : s.product_id}`,
      totalPlates: s.quantity_plates,
      amount: Number(amount.toFixed(2)),
      cost: Number(cost.toFixed(2)),
      profit: Number(profit.toFixed(2)),
      paymentMethod: s.payment_method,
      status: 'Completed'
    };
  });

  // Inventory low stock check
  const inventoryStatus = analytics.calculateInventoryStatus(ingredients, inventoryTransactions, endDate);

  return {
    kpis,
    dailySalesChart,
    hourlySalesProfile,
    productSalesDistribution,
    recentTransactions,
    activeLowStockCount: inventoryStatus.lowStockCount,
    filterMeta: {
      rangeKey,
      startDate,
      endDate,
      label,
      productId,
      totalRecordsAnalyzed: filteredSales.length
    }
  };
}

/**
 * Sales Analytics Endpoint
 */
export function getSalesAnalytics(rangeKey = '30d', productId = 'all') {
  const { startDate, endDate, label } = analytics.resolveDateRange(rangeKey);

  const filteredSales = analytics.filterSales(sales, { startDate, endDate, productId });
  const filteredExpenses = analytics.filterExpenses(dailyExpenses, { startDate, endDate });
  const filteredWaste = analytics.filterInventoryTransactions(inventoryTransactions, {
    startDate,
    endDate,
    types: 'WASTE'
  });

  const kpis = analytics.calculateKpis({
    sales: filteredSales,
    expenses: filteredExpenses,
    wasteTransactions: filteredWaste,
    productsMap,
    ingredientsMap
  });

  const dailySalesChart = analytics.calculateDailyTrend(
    filteredSales,
    filteredExpenses,
    filteredWaste,
    productsMap,
    ingredientsMap
  );

  const monthlySalesChart = analytics.calculateMonthlyTrend(dailySalesChart);
  const hourlySalesProfile = analytics.calculateHourlyProfile(filteredSales, productsMap);
  const dayOfWeekTrends = analytics.calculateWeekdayProfile(filteredSales);
  const productPerformance = analytics.calculateProductPerformance(filteredSales, products);
  const paymentBreakdown = analytics.calculatePaymentMethods(filteredSales);

  return {
    kpis,
    dailySalesChart,
    monthlySalesChart,
    hourlySalesProfile,
    dayOfWeekTrends,
    paymentBreakdown,
    productPerformance,
    productSalesDistribution: productPerformance,
    filterMeta: {
      rangeKey,
      startDate,
      endDate,
      label,
      productId,
      totalSalesCount: filteredSales.length
    }
  };
}

/**
 * Menu & Product Management Endpoint
 */
export function getMenuData(rangeKey = '180d') {
  const { startDate, endDate } = analytics.resolveDateRange(rangeKey);
  const filteredSales = analytics.filterSales(sales, { startDate, endDate });
  const ranked = analytics.calculateProductPerformance(filteredSales, products);

  // Group into categories
  const categoriesMap = new Map();
  ranked.forEach(item => {
    if (!categoriesMap.has(item.category)) {
      categoriesMap.set(item.category, {
        id: item.category.toLowerCase().replace(/\s+/g, '-'),
        name: item.category,
        count: 0
      });
    }
    categoriesMap.get(item.category).count += 1;
  });

  const highlights = {
    topRevenueItem: ranked[0] || null,
    topMarginItem: [...ranked].sort((a, b) => b.gross_margin_pct - a.gross_margin_pct)[0] || null,
    bottomItem: [...ranked].sort((a, b) => a.net_revenue - b.net_revenue)[0] || null,
    averageMargin: Number((ranked.reduce((acc, i) => acc + i.gross_margin_pct, 0) / (ranked.length || 1)).toFixed(1))
  };

  return {
    items: ranked.map(r => ({
      id: r.product_id,
      item_code: r.product_id,
      item_name: r.product_name,
      name: r.product_name,
      category: r.category,
      selling_price: r.selling_price,
      cost_price: r.ingredient_cost_per_plate,
      margin_pct: r.gross_margin_pct,
      plates_sold: r.plates_sold,
      total_revenue: r.net_revenue,
      total_cogs: r.cogs,
      gross_profit: r.gross_profit,
      status: 'Active'
    })),
    categories: Array.from(categoriesMap.values()),
    highlights
  };
}

/**
 * Inventory Endpoint
 */
export function getInventoryData(upToDate = null) {
  const status = analytics.calculateInventoryStatus(ingredients, inventoryTransactions, upToDate);

  // Formatted ledger of recent 50 inventory transactions
  const recentLedger = inventoryTransactions.slice(-50).reverse().map(tx => {
    const ing = ingredientsMap.get(tx.ingredient_id);
    return {
      id: tx.transaction_id,
      date: tx.transaction_date,
      ingredient_id: tx.ingredient_id,
      ingredient_name: ing ? ing.ingredient_name : tx.ingredient_id,
      type: tx.transaction_type,
      quantity: tx.quantity,
      unit: ing ? ing.unit : '',
      reference_id: tx.reference_id,
      cost: Number(((tx.quantity || 0) * (ing ? ing.unit_cost : 0)).toFixed(2))
    };
  });

  return {
    ingredients: status.ingredients,
    ledger: recentLedger,
    lowStockCount: status.lowStockCount,
    totalInventoryValue: status.totalInventoryValue
  };
}

/**
 * Food Waste Endpoint
 */
export function getWasteData(rangeKey = '180d') {
  const { startDate, endDate } = analytics.resolveDateRange(rangeKey);
  const filteredSales = analytics.filterSales(sales, { startDate, endDate });
  const filteredWaste = analytics.filterInventoryTransactions(inventoryTransactions, {
    startDate,
    endDate,
    types: 'WASTE'
  });

  const totalNetRevenue = filteredSales.reduce((acc, s) => acc + (s.quantity_plates * s.unit_price - s.discount), 0);
  const wasteAnalytics = analytics.calculateWasteAnalytics(filteredWaste, ingredientsMap, totalNetRevenue);

  // Precompute daily sales for fast lookup
  const dailySalesMap = new Map();
  filteredSales.forEach(s => {
    const d = s.sale_datetime ? s.sale_datetime.slice(0, 10) : s.date;
    const current = dailySalesMap.get(d) || { platesSold: 0, revenue: 0 };
    current.platesSold += (s.quantity_plates || 0);
    current.revenue += ((s.quantity_plates || 0) * (s.unit_price || 0) - (s.discount || 0));
    dailySalesMap.set(d, current);
  });

  // High waste days
  const dailyWasteMap = new Map();
  filteredWaste.forEach(tx => {
    const ing = ingredientsMap.get(tx.ingredient_id);
    const cost = tx.quantity * (ing ? ing.unit_cost : 0);
    dailyWasteMap.set(tx.transaction_date, (dailyWasteMap.get(tx.transaction_date) || 0) + cost);
  });

  const highWasteDays = Array.from(dailyWasteMap.entries())
    .map(([date, wasteCost]) => {
      const daySales = dailySalesMap.get(date) || { platesSold: 0, revenue: 0 };
      const wasteRatioPct = daySales.revenue > 0 ? Number(((wasteCost / daySales.revenue) * 100).toFixed(1)) : 0;
      return {
        date,
        dayOfWeek: new Date(`${date}T12:00:00+05:30`).toLocaleDateString('en-US', { weekday: 'long' }),
        wasteCost: Number(wasteCost.toFixed(2)),
        platesSold: daySales.platesSold,
        revenue: Math.round(daySales.revenue),
        wasteRatioPct
      };
    })
    .sort((a, b) => b.wasteCost - a.wasteCost)
    .slice(0, 10);

  // Actionable smart recommendations
  const recommendations = [
    {
      id: 'REC-01',
      title: 'Adopt Cushioned Food-Grade Crates for Puri Logistics',
      impact: 'High',
      potentialSavings: '₹2,450 / month',
      finding: 'Transit and handling breakage accounts for ~42% of all stall food wastage (avg 115 puris crushed daily).',
      action: 'Replace soft burlap sacks with stacked rigid food-grade plastic bins with bubble liners.'
    },
    {
      id: 'REC-02',
      title: 'Implement Staged Pani Mixing (Split Batching)',
      impact: 'High',
      potentialSavings: '₹1,800 / month',
      finding: 'Weekdays consistently leave 2.5L to 3.2L of oxidized, souring mint pani unsold at 10 PM.',
      action: 'Cap initial 3 PM batch at 18 Liters. Prepare the remaining 8 Liters only if 6 PM footfall reaches 150 plates.'
    },
    {
      id: 'REC-03',
      title: 'Two-Stage Potato Boiling Schedule',
      impact: 'Medium',
      potentialSavings: '₹950 / month',
      finding: 'Boiled potato mash loses moisture and develops slight fermentation aroma by 9 PM on warm days.',
      action: 'Boil 65% of required potatoes at 2:30 PM. Boil remaining 35% at 6:30 PM for peak dinner orders.'
    },
    {
      id: 'REC-04',
      title: 'Chilled Curd Temperature Monitoring',
      impact: 'Medium',
      potentialSavings: '₹750 / month',
      finding: 'Dahi Puri curd souring occurs rapidly if the counter ice tub temperature rises above 10°C.',
      action: 'Use insulated secondary ice sleeves around dahi clay matkas during peak outdoor hours.'
    }
  ];

  return {
    kpis: wasteAnalytics.kpis,
    wasteByIngredient: wasteAnalytics.wasteByIngredient,
    wasteByReason: wasteAnalytics.wasteByReason,
    highWasteDays,
    recommendations,
    recentWasteLogs: filteredWaste.slice(-30).reverse().map(tx => {
      const ing = ingredientsMap.get(tx.ingredient_id);
      return {
        id: tx.transaction_id,
        date: tx.transaction_date,
        ingredient_name: ing ? ing.ingredient_name : tx.ingredient_id,
        quantity: tx.quantity,
        unit: ing ? ing.unit : '',
        estimatedCost: Number((tx.quantity * (ing ? ing.unit_cost : 0)).toFixed(2)),
        reason: tx.reference_id
      };
    })
  };
}

/**
 * Access raw datasets for CSV export and Tableau downloads
 */
export function getRawDatasets() {
  return {
    products,
    ingredients,
    sales,
    inventoryTransactions,
    dailyExpenses
  };
}

/**
 * Reset dataset back to fresh state
 */
export function resetToBaseline() {
  loadSyntheticDataset();
  return true;
}
