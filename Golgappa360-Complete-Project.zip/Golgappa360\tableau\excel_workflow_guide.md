# Golgappa360 — Excel Analysis & Verification Workflow Guide

This guide describes how to open, format, analyze, and cross-reconcile the **Golgappa360** CSV exports inside **Microsoft Excel** (Excel 2016, 2019, 2021, and Microsoft 365).

---

## 1. Importing CSV Datasets into Microsoft Excel

All exported CSV files are formatted in strict **RFC 4180 standard** with **UTF-8 encoding**, allowing seamless import without text-truncation or encoding corruption.

### Best Practice Import Method (Power Query / Data Tab)
Do not simply double-click large CSVs in Windows Explorer, as Excel may guess date formats incorrectly. Instead:

1. Launch Microsoft Excel and create a blank workbook.
2. Go to the **Data** tab on the Ribbon > **Get & Transform Data > From Text/CSV**.
3. Select `tableau_sales.csv` (or any other exported CSV).
4. In the preview dialog:
   - **File Origin:** `65001: Unicode (UTF-8)`.
   - **Delimiter:** `Comma`.
   - **Data Type Detection:** `Based on first 200 rows`.
5. Click **Load** (or **Transform Data** to inspect column data types in Power Query).

---

## 2. Formatting Columns for Financial Analysis

Once loaded, apply standard Excel number formatting:

| Column Header | Excel Data Format | Custom Format Code |
|:---|:---|:---|
| `sale_datetime` | Date & Time | `yyyy-mm-dd hh:mm:ss` |
| `sale_date`, `expense_date` | Short Date | `yyyy-mm-dd` |
| `quantity_plates` | Integer | `#,##0` |
| `unit_price`, `gross_sales`, `discount`, `net_revenue`, `cogs`, `gross_profit` | Currency (Indian Rupee) | `[₹-439] #,##0.00` or `₹ #,##0.00` |
| `gross_margin_pct`, `waste_ratio_pct` | Percentage | `0.0%` |

---

## 3. Building Core Analytical Pivot Tables

### Pivot Table 1: Monthly Product Variety Revenue & Margins
1. Select the `tableau_sales` table.
2. Go to **Insert > PivotTable > New Worksheet**.
3. Configure the fields:
   - **Rows:** `product_name`
   - **Columns:** `sale_date` (Right-click date > Group by **Months**)
   - **Values:**
     - `Sum of quantity_plates` (Format: `#,##0`)
     - `Sum of net_revenue` (Format: `₹ #,##0.00`)
     - `Sum of gross_profit` (Format: `₹ #,##0.00`)
4. **Calculated Field for Margin %:**
   - On the PivotTable Analyze ribbon, click **Fields, Items & Sets > Calculated Field**.
   - Name: `Weighted_Gross_Margin_Pct`
   - Formula: `='gross_profit' / 'net_revenue'`
   - Number format: `0.0%`

---

### Pivot Table 2: Hourly Footfall Rush Matrix (Heatmap)
1. In a new worksheet, insert a Pivot Table from `tableau_sales`.
2. Configure:
   - **Rows:** `day_of_week` (Sort: Monday to Sunday)
   - **Columns:** `sale_hour` (15, 16, 17, 18, 19, 20, 21, 22)
   - **Values:** `Sum of quantity_plates`
3. **Apply Conditional Formatting:**
   - Select the matrix data cells.
   - Go to **Home > Conditional Formatting > Color Scales**.
   - Choose the **3-Color Scale (Soft Grey to Green or Amber)**.
   - *Result:* Immediately visualizes the peak commuter rush between 18:00 and 20:00 on Fridays and Saturdays.

---

### Pivot Table 3: Payment Tender Mix (UPI vs. Cash by Month)
1. **Rows:** `sale_date` (Grouped by Month).
2. **Columns:** `payment_method` (`UPI`, `Cash`).
3. **Values:** `Sum of net_revenue` and `Count of sale_id`.
4. Right-click Value > **Show Values As > % of Row Total** to observe the shift toward digital payments.

---

### Pivot Table 4: Raw Ingredient Consumption vs. Food Waste
1. Select the `tableau_inventory` table.
2. Configure:
   - **Rows:** `ingredient_name`, `unit`
   - **Columns:** `transaction_type` (`PURCHASE`, `CONSUMPTION`, `WASTE`)
   - **Values:** `Sum of quantity` and `Sum of extended_cost`.

---

## 4. Key Excel Formulas & Template Syntax

### 1. Conditional Revenue by Variety (`SUMIFS`)
Compute total net revenue for Classic Golgappa on weekends:
```excel
=SUMIFS(
    tableau_sales[net_revenue],
    tableau_sales[product_name], "Classic Golgappa",
    tableau_sales[is_weekend], "Weekend"
)
```

### 2. High-Value Order Count (`COUNTIFS`)
Count how many orders had 3 or more plates:
```excel
=COUNTIFS(
    tableau_sales[quantity_plates], ">=3"
)
```

### 3. Dynamic Menu BOM Cost Lookup (`XLOOKUP` / `VLOOKUP`)
Retrieve the standard BOM cost for a product from the catalog:
```excel
=XLOOKUP(
    A2, 
    tableau_products[product_name], 
    tableau_products[ingredient_cost_per_plate], 
    0
)
```
*Legacy VLOOKUP fallback:*
```excel
=VLOOKUP(A2, tableau_products!$B$2:$E$6, 4, FALSE)
```

### 4. Zero-Division Protected Margin Calculation (`IFERROR`)
```excel
=IFERROR(
    (SUM(tableau_sales[gross_profit]) / SUM(tableau_sales[net_revenue])), 
    0
)
```

### 5. Average Order Ticket during Peak Hours (`AVERAGEIFS`)
Calculate average plate order amount between 6 PM and 8 PM:
```excel
=AVERAGEIFS(
    tableau_sales[net_revenue],
    tableau_sales[sale_hour], ">=18",
    tableau_sales[sale_hour], "<=20"
)
```

---

## 5. Cross-Checking Totals Across Excel, SQL, and Tableau

To ensure data integrity, create a dedicated **Reconciliation** worksheet in Excel and populate this balance-check table:

| Verification Metric | Excel Formula | Expected Benchmark Value | Discrepancy Status |
|:---|:---|:---:|:---:|
| **Total Net Revenue** | `=SUM(tableau_sales[net_revenue])` | `₹ 17,59,965.00` | `0.00 [MATCH]` |
| **Total Gross Turnover** | `=SUM(tableau_sales[gross_sales])` | `₹ 17,65,505.00` | `0.00 [MATCH]` |
| **Total Discounts** | `=SUM(tableau_sales[discount])` | `₹ 5,540.00` | `0.00 [MATCH]` |
| **Total Plates Sold** | `=SUM(tableau_sales[quantity_plates])` | `47,658` | `0 [MATCH]` |
| **Total COGS** | `=SUM(tableau_sales[cogs])` | `₹ 4,92,957.90` | `0.00 [MATCH]` |
| **Gross Profit** | `=SUM(tableau_sales[gross_profit])` | `₹ 12,67,007.10` | `0.00 [MATCH]` |
| **Operating Expenses** | `=SUM(tableau_expenses[amount])` | `₹ 126,540.06` | `0.00 [MATCH]` |
| **Food Waste Cost** | `=SUMIFS(tableau_inventory[extended_cost], tableau_inventory[transaction_type], "WASTE")` | `₹ 11,626.98` | `0.00 [MATCH]` |
| **Estimated Operating Profit** | `=[Gross Profit] - [Operating Expenses]` | `₹ 11,40,467.04` | `0.00 [MATCH]` |

If any cell displays a non-zero variance, check whether date filters are active or if double-counting occurred from joining rather than using separate worksheets.
