# Golgappa360 — Master Viva Voce Questions & Answers Guide

> **Master of Computer Applications (MCA) Examination & Project Defense**  
> **Topic:** Golgappa360 Business Intelligence & Sales Analytics System  
> **Coverage:** Full-Stack Web Development, Data Analytics, Relational Database Normalization, Tableau BI, and Financial Accounting

---

### Section 1: Business Intelligence & Data Analytics Fundamentals

#### Q01: What is the primary objective of Golgappa360, and what problem does it solve?
**Answer:** Golgappa360 is a specialized business intelligence system for small-scale Indian street-food stalls (specifically golgappa/pani puri vendors). Conventional food stalls operate on intuition without tracking recipe costs, rush-hour demand spikes, food spoilage, or digital payments. Golgappa360 provides automated analytics for revenue tracking, Bill of Materials (BOM) recipe costing, food waste minimization, and operating profitability.

#### Q02: What is the difference between Gross Revenue and Net Revenue in this system?
**Answer:**
- **Gross Revenue (Gross Turnover):** Total sales value calculated as $\sum(\text{Quantity Plates} \times \text{Unit Price})$.
- **Net Revenue:** Actual revenue collected after deducting promotional customer discounts:
  $$\text{Net Revenue} = \text{Gross Revenue} - \text{Discounts}$$
In our 6-month dataset, Gross Turnover is ₹1,765,505.00, Discounts are ₹5,540.00, and Net Revenue is ₹1,759,965.00.

#### Q03: What is Cost of Goods Sold (COGS), and how is it calculated for a food stall?
**Answer:** COGS represents the direct raw material cost required to prepare the plates served to customers:
$$\text{COGS} = \sum(\text{Quantity Plates Sold} \times \text{Unit Ingredient BOM Cost})$$
For a standard plate of Classic Golgappa (selling at ₹30), the BOM cost is ₹8.40 (6 puris, potato-chana mash, mint water, and packaging dona). COGS does **not** include stall rent or electricity.

#### Q04: How do Gross Profit and Estimated Operating Profit differ?
**Answer:**
- **Gross Profit:** Net Revenue minus COGS (direct ingredient costs). Total: **₹1,267,007.10** (71.99% margin).
- **Estimated Operating Profit:** Bottom-line profit remaining after deducting operational overhead vouchers (stall rent, packaging disposables, LPG commercial gas, power/ice utilities, and municipal fees):
  $$\text{Operating Profit} = \text{Gross Profit} - \text{Operating Expenses}$$
Total Operating Profit: **₹1,140,467.04** (64.80% margin) after ₹126,540.06 in expenses.

#### Q05: Why must raw material purchases not be recorded directly as operating expenses on the P&L?
**Answer:** Raw material purchases are balance-sheet inventory assets until they are consumed or wasted. Recording purchases directly on the P&L would distort monthly profit during bulk-buying cycles. Only consumed ingredients (COGS) and recorded spoilage (waste cost) are expensed in the matching accounting period.

---

### Section 2: Relational Database & SQL Engineering

#### Q06: Explain how the Golgappa360 database satisfies Third Normal Form (3NF).
**Answer:**
1. **1NF:** All attributes contain atomic values (orders decomposed into line items; ISO timestamps; no repeating groups).
2. **2NF:** All non-key attributes in `sale_items` depend fully on the primary key, with product metadata isolated in `products`.
3. **3NF:** No transitive dependencies exist. In `inventory_transactions`, unit cost and reorder thresholds are stored in `ingredients`, not duplicated across transaction rows.

#### Q07: What is the purpose of the analytical view `vw_daily_financial_summary`?
**Answer:** `vw_daily_financial_summary` materializes daily financial KPIs by aggregating sales headers, line items, product BOM costs, expense vouchers, and waste logs using Common Table Expressions (CTEs) at the calendar-day grain (`DATE(sale_datetime)`). It enables sub-second dashboard rendering and direct Tableau feeds without executing complex joins on the fly.

#### Q08: How do you calculate a 7-day rolling moving average in MySQL 8.0?
**Answer:** Using the SQL window function `AVG() OVER()` with an explicit frame specification:
```sql
SELECT 
    order_date,
    daily_revenue,
    ROUND(AVG(daily_revenue) OVER (
        ORDER BY order_date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_7day_avg_revenue
FROM DailySeries;
```

#### Q09: What is a Common Table Expression (CTE), and where is it used in this project?
**Answer:** A CTE is a named temporary result set defined with the `WITH` clause that exists only during query execution. In Golgappa360, CTEs are used in `server/sql/analytics_queries.sql` (e.g. Query 16 for multi-stage customer basket size analysis and Query 17 for ingredient shrinkage breakdowns) to improve readability and query optimization compared to nested subqueries.

#### Q10: How does the system handle database connectivity failures?
**Answer:** The system uses a **Dual-Engine architecture**. In `server/src/config/db.js`, the connection pool tests connectivity on startup. If MySQL credentials are unset or the service is offline, `getDbStatus()` flags `isConnected = false`. The backend then routes queries through `syntheticStore.js`, an in-memory analytics engine loaded from the calibrated CSV dataset, ensuring 100% application uptime.

---

### Section 3: Web Application Architecture (React 19 & Express)

#### Q11: Describe the component architecture of the frontend.
**Answer:** The frontend is built with React 19 and Vite using functional components and hooks:
- **`GolgappaProvider` (`GolgappaContext.jsx`):** Central state store for active tab, date ranges, product filters, real-time KPI data, and mutations.
- **`Layout.jsx`:** Persistent dark glassmorphism application shell with responsive sidebar rail and top navigation.
- **Pages (7):** `OverviewPage`, `SalesAnalyticsPage`, `MenuProductPage`, `InventoryPage`, `WasteAnalysisPage`, `ReportsPage`, and `SettingsPage`.
- **Reusable Glass Components:** `GlassCard`, `StatCard`, `Badge`, `Modal`, `LoadingState`, and `EmptyState`.

#### Q12: How does navigation work without causing page reloads?
**Answer:** Navigation is managed through URL hash synchronization in `GolgappaContext.jsx`. Clicking a sidebar item updates `activeTab` and pushes the hash (e.g. `/#sales`, `/#reports`) to the browser history via `window.history.pushState`. The application listens for `hashchange` and `popstate` events, supporting deep-linking and browser Back/Forward navigation.

#### Q13: What security measures are implemented in the Express backend?
**Answer:**
1. **Parameterized Queries:** All SQL calls use `?` parameter placeholders to prevent SQL injection.
2. **Input Validation Middleware:** `validateDateRange` validates `YYYY-MM-DD` syntax and date chronology; `validatePagination` restricts `page` and `limit`.
3. **Error Sanitization:** `errorHandler.js` logs raw database errors internally while returning safe JSON messages.
4. **Environment Isolation:** Database credentials are read from `.env` and excluded from git via `.gitignore`.

#### Q14: How does the backend prevent division-by-zero crashes?
**Answer:** All analytical calculations use the pure utility `safeDivide(numerator, denominator, fallback = 0)`. If the denominator is `0`, `NaN`, `null`, or non-finite, the function safely returns `0` rather than causing runtime crashes.

---

### Section 4: Tableau Business Intelligence & Data Modeling

#### Q15: What is a "Tableau Logical Relationship" (the Noodle), and how does it differ from a Physical Join?
**Answer:** Introduced in Tableau 2020.2, a Logical Relationship connects tables at their native grains without merging them into a flat physical table in advance. Tableau queries each table independently and performs dynamic joins at the level of detail defined by the worksheet dimensions, preventing row inflation.

#### Q16: What is a "Fan Trap" (Cartesian product), and how did you prevent it?
**Answer:** A fan trap occurs when two distinct one-to-many fact tables (e.g. `tableau_sales` with 31,938 rows and `tableau_inventory` with 2,391 rows) are physically joined on a shared key (`sale_date`). This multiplies every order by every inventory movement, generating over 76 million duplicate rows and inflating revenue by 14×. In Golgappa360, this is prevented by relating tables via Tableau Logical Relationships rather than physical joins.

#### Q17: What is the difference between a Dimension and a Measure in Tableau?
**Answer:**
- **Dimension (Blue pill):** Categorical, qualitative, or temporal data used to slice, group, and segment data (e.g. `[Product Name]`, `[Category]`, `[Payment Method]`, `[Sale Date]`, `[Sale Hour]`).
- **Measure (Green pill):** Numerical, quantitative data that can be aggregated mathematically using `SUM`, `AVG`, or `COUNT` (e.g. `[Gross Sales]`, `[Net Revenue]`, `[COGS]`, `[Quantity Plates]`).

#### Q18: Why must margin formulas in Tableau use aggregate expressions instead of row-level expressions?
**Answer:**
- **Row-Level (Incorrect):** `[Gross Profit] / [Net Revenue]` computes a percentage per row. Dragging it to a view causes Tableau to sum those percentages (e.g. $72\% + 72\% = 144\%$).
- **Aggregate (Correct):** `SUM([Gross Profit]) / SUM([Net Revenue])` sums all profits, sums all revenues, and then calculates the true weighted gross margin percentage.

#### Q19: How did you implement dynamic metric switching in Tableau?
**Answer:**
1. Created a String Parameter `[Select Metric]` with options: `"Net Revenue"`, `"Plates Sold"`, `"Gross Profit"`.
2. Created a calculated field using a `CASE` statement:
   ```tableau
   CASE [Select Metric]
     WHEN "Net Revenue" THEN [Net Revenue]
     WHEN "Plates Sold" THEN [Total Plates Sold]
     WHEN "Gross Profit" THEN [Gross Profit]
   END
   ```
3. Placed this calculated field on the Rows shelf, allowing users to switch chart metrics via a dropdown.

---

### Section 5: Microsoft Excel Analytics & Verification

#### Q20: How do you safely import large CSV datasets into Excel without corrupting dates?
**Answer:** Use **Data > Get Data > From Text/CSV** (Power Query) instead of double-clicking the file. Specify **File Origin: 65001: Unicode (UTF-8)** and ensure column data types for timestamps and dates are set explicitly to prevent ambiguous day/month conversions.

#### Q21: How do `SUMIF` and `SUMIFS` differ, and give an example from the project?
**Answer:**
- `SUMIF` evaluates a single condition.
- `SUMIFS` evaluates multiple simultaneous criteria:
  ```excel
  =SUMIFS(
      tableau_sales[net_revenue],
      tableau_sales[product_name], "Classic Golgappa",
      tableau_sales[is_weekend], "Weekend"
  )
  ```
This computes total weekend revenue specifically for the Classic Golgappa variety.

#### Q22: How does `XLOOKUP` improve on `VLOOKUP` in menu costing models?
**Answer:**
- `VLOOKUP` requires the lookup key to be in the first column of the range and uses fragile numeric column index offsets.
- `XLOOKUP` looks in any column, returns any corresponding column, defaults to exact match, and provides a built-in fallback:
  ```excel
  =XLOOKUP(A2, tableau_products[product_name], tableau_products[ingredient_cost_per_plate], 0)
  ```

---

### Section 6: Inventory, Spoilage & Project Limitations

#### Q23: How is on-hand inventory balance calculated in the ledger?
**Answer:**
$$\text{Current Stock} = \sum(\text{PURCHASE}) - \sum(\text{CONSUMPTION}) - \sum(\text{WASTE})$$
Purchases add to stock, kitchen recipe preparation subtracts consumption, and damaged or spoiled items subtract waste.

#### Q24: What are the primary root causes of food waste identified in the project?
**Answer:**
1. **Crushed Puris in Transit & Storage (42.0% of waste loss):** Caused by soft burlap bags during transit; mitigated by recommending rigid food-grade plastic bins with bubble liners.
2. **Leftover Souring Mint Pani (35.3% of waste loss):** Caused by over-batching mint water on slow weekday afternoons; mitigated by two-stage split preparation (capping 3 PM batch at 18L).
3. **Fermented Potato-Vatana Mash (22.7% of waste loss):** Caused by warm ambient counter temperatures by 9 PM.

#### Q25: What are the current limitations of Golgappa360, and what are future enhancement opportunities?
**Answer:**
- **Current Limitations:** Uses calibrated synthetic data rather than live IoT scale sensors; local MySQL credentials require manual configuration; single-stall scope.
- **Future Enhancements:** Multi-stall franchise aggregation, automated WhatsApp inventory reorder triggers to mandi suppliers, integration with digital smart weighing scales, and predictive weather-based footfall forecasting.
