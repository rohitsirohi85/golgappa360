import React, { useState } from 'react';
import { STELLAR_FAMILIES } from '../../data/stellarTypes';

/**
 * StellarFamilyCards — "THE STELLAR FAMILY"
 * Clarifies the fundamental astrophysical distinction between:
 * - Spectral Class (Temperature & Color: O B A F G K M)
 * - Stellar Family (Evolutionary stage, mass, & internal structure)
 * Features 7 interactive cards with animated visuals, expansion states, and examples.
 */
export default function StellarFamilyCards({ onExploreStar }) {
  const [selectedId, setSelectedId] = useState('yellow-dwarf');

  const handleCardClick = (id) => {
    setSelectedId(selectedId === id ? null : id);
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Section Sub-Heading */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-cyan-500/20 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>EVOLUTIONARY STRUCTURES</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          THE STELLAR FAMILY
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/80 leading-relaxed max-w-2xl mx-auto">
          While spectral classes classify a star’s <strong className="text-cyan-300">surface temperature and color</strong>,
          stellar families describe a star’s <strong className="text-amber-300">evolutionary stage, mass, internal physics, and destiny</strong>.
        </p>
      </div>

      {/* Cards Grid */}
      <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 sm:gap-6 items-stretch">
        {STELLAR_FAMILIES.map((family) => {
          const isSelected = selectedId === family.id;
          const isDimmed = selectedId !== null && !isSelected;

          return (
            <div
              key={family.id}
              onClick={() => handleCardClick(family.id)}
              className={`group relative flex flex-col justify-between rounded-2xl glass-surface-interactive p-5 sm:p-6 transition-all duration-300 cursor-pointer select-none overflow-hidden ${
                isSelected
                  ? 'scale-[1.02] border-cyan-400/60 shadow-[0_15px_40px_rgba(0,0,0,0.8),0_0_30px_-5px_var(--glow)] z-20'
                  : isDimmed
                  ? 'opacity-70 hover:opacity-100 hover:scale-[1.01]'
                  : 'hover:-translate-y-1'
              }`}
              style={{
                '--glow': family.glowColor,
                borderColor: isSelected ? family.colorHex : 'rgba(255, 255, 255, 0.08)',
              }}
            >
              {/* Spectral Ambient Backing */}
              <div
                aria-hidden="true"
                className="absolute top-0 right-0 w-36 h-36 rounded-full blur-3xl opacity-0 transition-opacity duration-500 pointer-events-none group-hover:opacity-15"
                style={{ backgroundColor: family.colorHex }}
              />

              {/* Top Visual Emblem */}
              <div className="relative w-full h-32 sm:h-36 flex items-center justify-center mb-4 rounded-xl bg-gradient-to-b from-white/[0.03] to-transparent border border-white/[0.04]">
                {/* Visual Sphere */}
                <div
                  className="relative rounded-full transition-transform duration-500"
                  style={{
                    width:
                      family.id === 'white-dwarf'
                        ? '32px'
                        : family.id === 'neutron-star'
                        ? '20px'
                        : family.id === 'red-dwarf'
                        ? '44px'
                        : family.id === 'yellow-dwarf'
                        ? '56px'
                        : family.id === 'blue-giant'
                        ? '72px'
                        : family.id === 'red-giant'
                        ? '80px'
                        : '92px',
                    height:
                      family.id === 'white-dwarf'
                        ? '32px'
                        : family.id === 'neutron-star'
                        ? '20px'
                        : family.id === 'red-dwarf'
                        ? '44px'
                        : family.id === 'yellow-dwarf'
                        ? '56px'
                        : family.id === 'blue-giant'
                        ? '72px'
                        : family.id === 'red-giant'
                        ? '80px'
                        : '92px',
                    backgroundColor: family.colorHex,
                    boxShadow: `0 0 30px ${family.glowColor}, inset 0 0 10px rgba(255, 255, 255, 0.7)`,
                  }}
                >
                  {/* Pulsar Beam for Neutron Star */}
                  {family.id === 'neutron-star' && (
                    <div
                      aria-hidden="true"
                      className="absolute inset-0 flex items-center justify-center pointer-events-none animate-spin"
                      style={{ animationDuration: '4s' }}
                    >
                      <div className="w-[120px] h-[1px] bg-gradient-to-r from-transparent via-purple-300 to-transparent" />
                      <div className="h-[120px] w-[1px] bg-gradient-to-b from-transparent via-purple-300 to-transparent" />
                    </div>
                  )}
                </div>

                {/* Top Corner Stage Pill */}
                <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full glass-surface border border-white/10 text-[9px] font-mono text-slate-300 tracking-wider">
                  {family.evolutionaryStage.split(' ')[0]}
                </div>
              </div>

              {/* Title & Subtitle */}
              <div>
                <div className="flex items-baseline justify-between gap-1 mb-1">
                  <h4 className="font-display text-xl font-semibold text-white group-hover:text-cyan-200 transition-colors">
                    {family.name}
                  </h4>
                </div>

                <p className="text-xs font-mono text-amber-300/90 mb-3 italic">
                  {family.subtitle}
                </p>

                {/* Primary Telemetry Specs */}
                <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-[#020308]/60 border border-white/8 mb-3 text-[11px] font-mono">
                  <div>
                    <span className="text-[9px] text-slate-400 uppercase block mb-0.5">SIZE</span>
                    <span className="text-slate-200 font-medium truncate block">{family.typicalSize}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 uppercase block mb-0.5">TEMP</span>
                    <span className="text-cyan-300 font-medium truncate block">{family.temperature}</span>
                  </div>
                </div>

                {/* Short Explanation */}
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed mb-3">
                  {family.shortExplanation}
                </p>

                {/* Expanded Details on Selection */}
                {isSelected && (
                  <div className="mt-3 pt-3 border-t border-white/10 space-y-2.5 text-xs animate-in fade-in duration-300">
                    <div>
                      <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 block mb-0.5">
                        ASTROPHYSICAL CONTEXT:
                      </span>
                      <p className="text-slate-300/90 leading-relaxed">
                        {family.extendedDetails}
                      </p>
                    </div>

                    <div className="p-2 rounded-lg bg-white/5 border border-white/5 font-mono text-[11px]">
                      <div className="text-slate-400">DESTINY: <span className="text-white">{family.destiny}</span></div>
                      <div className="text-slate-400 mt-1">DENSITY: <span className="text-amber-300">{family.density}</span></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer: Example Star Link */}
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">
                  EXAMPLE: <strong className="text-white font-medium">{family.exampleStar.split(',')[0]}</strong>
                </span>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onExploreStar) {
                      onExploreStar(family.exampleStar.split(',')[0].trim());
                    }
                  }}
                  className="text-cyan-400 hover:text-cyan-300 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1 focus:outline-none focus-visible:underline"
                >
                  <span>{isSelected ? 'Inspect Star' : 'Explore'}</span>
                  <span>▸</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
