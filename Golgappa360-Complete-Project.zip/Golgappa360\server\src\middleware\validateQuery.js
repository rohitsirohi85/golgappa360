/**
 * Golgappa360 - Query Parameter Validation Middleware
 */

export function validateDateRange(req, res, next) {
  const { startDate, endDate, range } = req.query;

  // Validate ISO YYYY-MM-DD date format if provided
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

  if (startDate && !dateRegex.test(startDate)) {
    return res.status(400).json({
      success: false,
      error: `Invalid startDate format: '${startDate}'. Expected YYYY-MM-DD.`
    });
  }

  if (endDate && !dateRegex.test(endDate)) {
    return res.status(400).json({
      success: false,
      error: `Invalid endDate format: '${endDate}'. Expected YYYY-MM-DD.`
    });
  }

  if (startDate && endDate && startDate > endDate) {
    return res.status(400).json({
      success: false,
      error: `Invalid date boundaries: startDate (${startDate}) cannot be after endDate (${endDate}).`
    });
  }

  // Validate standard range keys
  const validRanges = ['today', '7d', '30d', '90d', '3m', '180d', '6m', 'all'];
  if (range && !validRanges.includes(range.toLowerCase())) {
    // If not one of the standard presets, check if custom range is given
    if (!startDate || !endDate) {
      return res.status(400).json({
        success: false,
        error: `Invalid range parameter: '${range}'. Allowed presets: ${validRanges.join(', ')}.`
      });
    }
  }

  next();
}

export function validatePagination(req, res, next) {
  const { page, limit } = req.query;

  if (page !== undefined) {
    const pageNum = parseInt(page, 10);
    if (isNaN(pageNum) || pageNum < 1) {
      return res.status(400).json({
        success: false,
        error: `Invalid page parameter: '${page}'. Must be an integer >= 1.`
      });
    }
  }

  if (limit !== undefined) {
    const limitNum = parseInt(limit, 10);
    if (isNaN(limitNum) || limitNum < 1 || limitNum > 500) {
      return res.status(400).json({
        success: false,
        error: `Invalid limit parameter: '${limit}'. Must be between 1 and 500.`
      });
    }
  }

  next();
}
