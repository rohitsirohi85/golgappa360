# EV SMART: Comprehensive Screenshot & Visual Demonstration Guide
## Standardized Catalog of 20 Critical System Views for Reports and Viva

---

## 1. Overview & Guidelines
This guide provides precise documentation for capturing 20 standardized screenshots of the **EV SMART** platform. These views represent the complete operational lifecycle across the Driver Mobile App, Admin Fleet Management Dashboard, Real-Time IoT Telemetry, and AI Analytics.

### Image Naming Convention:
Save all captured screenshots in `docs/screenshots/` using the format:  
`SHOT_[01-20]_[VIEW_NAME].png` (e.g., `SHOT_05_ACTIVE_CHARGING_HUD.png`).

---

## 2. Catalog of 20 Standardized System Views

### View 01: Driver Authentication & Onboarding
- **Filename:** `SHOT_01_USER_LOGIN.png`
- **Route / URL:** `http://localhost:5173/login`
- **Key UI Elements:** Email/password input fields, "Remember Me" toggle, Role selector badge, Demo Driver quick-fill button, Clean card styling with EV gradient.
- **Purpose:** Demonstrates secure JWT authentication, input validation, and password masking.
- **How to Trigger:** Navigate to `/login`. Click the "Demo Driver" quick-fill button to auto-populate credentials (`driver@evsmart.com`).

---

### View 02: Interactive Station Map & Discovery
- **Filename:** `SHOT_02_STATION_MAP.png`
- **Route / URL:** `http://localhost:5173/` or `http://localhost:5173/stations`
- **Key UI Elements:** Search bar (city/station filter), interactive Leaflet/Map view, station pin clusters, quick cards displaying real-time connector availability badges (e.g., "3 of 4 Available").
- **Purpose:** Demonstrates driver station discovery, distance calculation, and live availability indicators.
- **How to Trigger:** Log in as Driver; land on main dashboard. Zoom into active cluster; filter by "Fast Charger (CCS2)".

---

### View 03: Station Details & Connector Selector
- **Filename:** `SHOT_03_STATION_DETAILS.png`
- **Route / URL:** `http://localhost:5173/stations/:stationId`
- **Key UI Elements:** Station photograph banner, operating hours, base pricing tariffs (₹/kWh), list of individual chargers with real-time status badges (Available/Occupied), and "Book Now" CTA buttons.
- **Purpose:** Shows granular charger connector capabilities (Power rating kW, connector standard).
- **How to Trigger:** Click on "Downtown Supercharger Hub" from the station map list.

---

### View 04: Time-Slot Booking & Reservation Modal
- **Filename:** `SHOT_04_SLOT_RESERVATION.png`
- **Route / URL:** `Modal overlay on /stations/:stationId`
- **Key UI Elements:** Date picker, visual 30-minute time-slot selector grid, vehicle model selector, estimated charging cost preview, and "Confirm Booking" action.
- **Purpose:** Validates conflict-free scheduling engine preventing double-booking of physical chargers.
- **How to Trigger:** On station details, click "Reserve Slot" on Charger #1. Select an open future 1-hour slot and click preview.

---

### View 05: Active Charging Session Cockpit (Live HUD)
- **Filename:** `SHOT_05_ACTIVE_CHARGING_HUD.png`
- **Route / URL:** `http://localhost:5173/charging/:sessionId`
- **Key UI Elements:** Circular charging progress gauge (SOC %), digital dials for Voltage (231.4 V), Current (15.8 A), Power (3.66 kW), Accumulated Energy (12.4 kWh), Elapsed Time (00:34:12), and Current Billing Cost (₹148.80).
- **Purpose:** Proves real-time edge-to-cloud telemetry delivery via WebSockets without manual page refresh.
- **How to Trigger:** Start a session via QR scan or "Start Demo Session" button while virtual/real ESP32 is streaming telemetry.

---

### View 06: Live Telemetry Sparklines & Waveforms
- **Filename:** `SHOT_06_TELEMETRY_CHARTS.png`
- **Route / URL:** `Component within /charging/:sessionId`
- **Key UI Elements:** Real-time SVG time-series graphs displaying continuous power draw (kW) and current (A) over the last 60 seconds with 1Hz streaming updates.
- **Purpose:** Demonstrates live signal smoothing, sub-second latency, and responsive charting.
- **How to Trigger:** Scroll down on the active charging screen during an ongoing charging session.

---

### View 07: Session Complete & Digital Receipt Modal
- **Filename:** `SHOT_07_SESSION_RECEIPT.png`
- **Route / URL:** `Modal overlay on /charging/:sessionId`
- **Key UI Elements:** "Charging Complete" checkmark, final energy delivered (kWh), duration, itemized cost breakdown (Base energy + Peak multiplier + GST), transaction ID, and "Download PDF Invoice" button.
- **Purpose:** Proves end-of-session settlement, automated wallet debit, and receipt generation.
- **How to Trigger:** Click "Stop Charging" button; confirm the action.

---

### View 08: Digital Wallet & Balance Top-Up
- **Filename:** `SHOT_08_USER_WALLET.png`
- **Route / URL:** `http://localhost:5173/wallet`
- **Key UI Elements:** Large wallet balance display (e.g., ₹1,250.00), quick top-up buttons (₹200, ₹500, ₹1000), simulated UPI/Card payment modal, and recent credit/debit transaction ledger.
- **Purpose:** Demonstrates financial ledger integrity, sandbox transactions, and pre-paid balance tracking.
- **How to Trigger:** Click "Wallet" in the driver navbar; click "Top-Up ₹500".

---

### View 09: User Charging History & Export
- **Filename:** `SHOT_09_CHARGING_HISTORY.png`
- **Route / URL:** `http://localhost:5173/history`
- **Key UI Elements:** Chronological table/cards of past charging sessions, filter by date range, station name, total kWh, amount paid, and action buttons to view/download receipts.
- **Purpose:** Shows historical session persistence in MongoDB and user transparency.
- **How to Trigger:** Click "History" in driver navigation menu.

---

### View 10: Admin Fleet Authentication Portal
- **Filename:** `SHOT_10_ADMIN_LOGIN.png`
- **Route / URL:** `http://localhost:5173/admin/login`
- **Key UI Elements:** Enterprise dark-theme portal, administrative badge, MFA badge indicator, "Demo Admin" quick-fill button (`admin@evsmart.com`).
- **Purpose:** Demonstrates role-based security isolation between driver and admin access boundaries.
- **How to Trigger:** Navigate directly to `/admin/login` or log out from user mode.

---

### View 11: Admin Fleet Executive Overview
- **Filename:** `SHOT_11_ADMIN_OVERVIEW.png`
- **Route / URL:** `http://localhost:5173/admin`
- **Key UI Elements:** Top KPI cards: Total Stations (4), Active Chargers (16), Total Energy Delivered Today (412.8 kWh), Network Revenue (₹5,340), System Health Status (100% Operational).
- **Purpose:** Provides high-level operational visibility for charging network operators.
- **How to Trigger:** Log in with admin credentials.

---

### View 12: Multi-Station Live Charger Grid
- **Filename:** `SHOT_12_FLEET_GRID.png`
- **Route / URL:** `http://localhost:5173/admin/chargers`
- **Key UI Elements:** Matrix of all network chargers organized by station, showing real-time state badges (Green: Available, Blue: Charging, Red: Faulted, Gray: Offline) with active power draw figures.
- **Purpose:** Demonstrates scalable multi-charger fleet monitoring.
- **How to Trigger:** Click "Chargers" in the Admin sidebar navigation.

---

### View 13: Live Charger Diagnostics & Remote Control
- **Filename:** `SHOT_13_CHARGER_DIAGNOSTICS.png`
- **Route / URL:** `http://localhost:5173/admin/chargers/:chargerId`
- **Key UI Elements:** Real-time sensor metrics (V, I, P, Enclosure Temp), ESP32 Wi-Fi RSSI signal meter, firmware version, and administrative actions ("Reboot Controller", "Force Relay Open", "Simulate Overcurrent").
- **Purpose:** Proves bidirectional cloud-to-hardware control and remote triage capabilities.
- **How to Trigger:** Click "Manage" on any active charger card in the grid.

---

### View 14: System Fault Log & Triage Center
- **Filename:** `SHOT_14_FAULT_TRIAGE.png`
- **Route / URL:** `http://localhost:5173/admin/faults`
- **Key UI Elements:** Chronological fault table with severity tags (CRITICAL, WARNING, INFO), timestamps, affected charger ID, root cause description (e.g., "Enclosure Over-Temperature 64.2°C"), and "Acknowledge / Clear Fault" buttons.
- **Purpose:** Shows automated fault tracking, safety cutoff notifications, and resolution workflow.
- **How to Trigger:** Click "Faults & Alerts" in Admin navigation.

---

### View 15: Energy Consumption & Load Analytics
- **Filename:** `SHOT_15_ENERGY_ANALYTICS.png`
- **Route / URL:** `http://localhost:5173/admin/analytics/energy`
- **Key UI Elements:** Interactive Bar/Area charts showing 24-hour aggregate energy consumption (kWh), peak vs off-peak power delivery, and day-over-day energy trends.
- **Purpose:** Demonstrates analytical data aggregation pipelines in Node.js and MongoDB.
- **How to Trigger:** Navigate to "Analytics" -> "Energy Consumption".

---

### View 16: Station Utilization Heatmap
- **Filename:** `SHOT_16_UTILIZATION_HEATMAP.png`
- **Route / URL:** `http://localhost:5173/admin/analytics/utilization`
- **Key UI Elements:** 24x7 matrix (Hours 00:00 to 23:00 vs Days Mon–Sun) color-coded from light green (low occupancy) to deep red (100% capacity), identifying grid congestion periods.
- **Purpose:** Shows charging behavior patterns to guide capacity expansion and grid upgrades.
- **How to Trigger:** Navigate to "Analytics" -> "Station Utilization".

---

### View 17: AI 24-Hour Ahead Demand Forecast
- **Filename:** `SHOT_17_AI_DEMAND_FORECAST.png`
- **Route / URL:** `http://localhost:5173/admin/ai/demand`
- **Key UI Elements:** Dual-series curve chart plotting Historical Actual Demand vs. Random Forest Predicted Load for the next 24 hours, confidence interval band, and calculated peak hour warnings.
- **Purpose:** Proves operational AI microservice integration ($R^2 \approx 0.9902$) for grid load balancing.
- **How to Trigger:** Click "AI Intelligence" -> "Demand Forecasting".

---

### View 18: AI Telemetry Anomaly Detection View
- **Filename:** `SHOT_18_AI_ANOMALY_DETECTION.png`
- **Route / URL:** `http://localhost:5173/admin/ai/anomalies`
- **Key UI Elements:** Scatter plot / time-series display showing normal telemetry clusters and highlighted red outlier points flagged by the Isolation Forest model (e.g., voltage sags or harmonic surges).
- **Purpose:** Demonstrates unsupervised machine learning identifying electrical defects before catastrophic failure.
- **How to Trigger:** Click "AI Intelligence" -> "Anomaly Detection".

---

### View 19: Dynamic Tariff & Peak Pricing Manager
- **Filename:** `SHOT_19_DYNAMIC_TARIFFS.png`
- **Route / URL:** `http://localhost:5173/admin/tariffs`
- **Key UI Elements:** Tariff rule configuration card: Base Rate (₹/kWh), Peak Multiplier ($1.4\times$), Off-Peak Discount ($0.8\times$), AI Dynamic Pricing Toggle, and preview of hourly price distribution.
- **Purpose:** Proves smart grid load shifting by economically incentivizing off-peak EV charging.
- **How to Trigger:** Click "Tariffs & Pricing" in Admin navigation.

---

### View 20: Tamper-Evident Security Audit Log
- **Filename:** `SHOT_20_SECURITY_AUDIT_LOG.png`
- **Route / URL:** `http://localhost:5173/admin/audit-logs`
- **Key UI Elements:** Searchable audit trail listing timestamp, actor (admin/user email), IP address, action performed (`TARIFF_UPDATE`, `EMERGENCY_SHUTDOWN`, `ROLE_CHANGE`), and cryptographic record hash.
- **Purpose:** Demonstrates compliance, cybersecurity auditability, and administrative accountability.
- **How to Trigger:** Click "Security & Audit" in Admin navigation.
