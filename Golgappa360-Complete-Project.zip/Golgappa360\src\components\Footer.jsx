import React from 'react';

/**
 * Footer — Minimal premium footer
 * Logo: ✦ STELLAR
 * Text: “Look up. Wonder more.”
 * Copyright: © 2026 STELLAR
 */
export default function Footer() {
  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Stars', href: '#stars' },
    { label: 'Star Types', href: '#star-types' },
    { label: 'Life Cycle', href: '#life-cycle' },
    { label: 'Constellations', href: '#constellations' },
    { label: 'Quiz', href: '#quiz' },
  ];

  return (
    <footer className="relative border-t border-white/10 py-12 sm:py-16 bg-[#02040a]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          {/* Logo Brand & Tagline */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <a
              href="#home"
              className="flex items-center gap-2.5 text-white hover:text-cyan-300 transition-colors cursor-pointer"
            >
              <span className="text-amber-400 text-lg font-bold">✦</span>
              <span className="font-display font-bold text-lg tracking-[0.2em]">
                STELLAR
              </span>
            </a>
            <span className="hidden sm:inline text-slate-700">|</span>
            <p className="text-sm text-slate-400 font-light italic">
              “Look up. Wonder more.”
            </p>
          </div>

          {/* Navigation Links */}
          <nav aria-label="Footer navigation">
            <ul className="flex flex-wrap justify-center items-center gap-4 sm:gap-6 text-xs font-mono text-slate-400">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-cyan-300 transition-colors uppercase tracking-wider"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        {/* Bottom Bar: Copyright & Subtle Status */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500">
          <span>© 2026 STELLAR — All astronomical data derived from standard catalogues.</span>

          {/* Status Indicator */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 border border-white/5 text-[11px] text-emerald-400/90">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="tracking-widest uppercase">ALL SYSTEMS NOMINAL</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
