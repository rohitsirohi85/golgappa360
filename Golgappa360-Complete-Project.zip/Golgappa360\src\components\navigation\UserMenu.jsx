import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  User,
  Heart,
  ListMusic,
  History,
  BarChart3,
  Settings,
  LogOut,
  ChevronDown,
  ShieldAlert
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useFavorites } from "../../context/FavoritesContext";

export const UserMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentUser, logout } = useAuth();
  const { favoritesCount } = useFavorites();
  const menuRef = useRef(null);
  const navigate = useNavigate();

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!currentUser) return null;

  const handleLogout = async () => {
    setIsOpen(false);
    await logout();
    navigate("/login");
  };

  return (
    <div className="relative" ref={menuRef}>
      {/* Trigger button */}
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-2 p-1 rounded-xl hover:bg-white/[0.06] transition-colors cursor-pointer group"
        aria-label="User navigation menu"
        aria-expanded={isOpen}
      >
        <div className="w-8 h-8 rounded-xl overflow-hidden ring-1 ring-purple-500/40 group-hover:ring-purple-400 transition-all">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="hidden lg:flex flex-col text-left">
          <span className="text-xs font-bold text-white leading-none truncate max-w-[100px]">
            {currentUser.name}
          </span>
          <span className="text-[10px] text-purple-400 font-mono leading-tight truncate max-w-[100px]">
            @{currentUser.username}
          </span>
        </div>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 hidden sm:block ${
            isOpen ? "rotate-180 text-white" : ""
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-60 p-1.5 rounded-2xl glass-dropdown z-50 animate-in fade-in slide-in-from-top-2 duration-150">
          {/* User Header */}
          <div className="px-3 py-2.5 border-b border-white/10 mb-1">
            <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
            <p className="text-[11px] text-purple-400 font-mono truncate">@{currentUser.username}</p>
            <p className="text-[10px] text-slate-400 truncate mt-0.5">{currentUser.email}</p>
          </div>

          {/* Menu Items */}
          <Link
            to="/profile"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <User className="w-4 h-4 text-purple-400" />
            <span>Profile</span>
          </Link>

          <Link
            to="/favorites"
            onClick={() => setIsOpen(false)}
            className="flex items-center justify-between px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Heart className="w-4 h-4 text-rose-400" />
              <span>Favorites</span>
            </div>
            {favoritesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-mono">
                {favoritesCount}
              </span>
            )}
          </Link>

          <Link
            to="/playlists"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <ListMusic className="w-4 h-4 text-cyan-400" />
            <span>Playlists</span>
          </Link>

          <Link
            to="/history"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <History className="w-4 h-4 text-slate-400" />
            <span>Search History</span>
          </Link>

          <Link
            to="/analytics"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <span>Analytics</span>
          </Link>

          <Link
            to="/settings"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-200 hover:text-white hover:bg-white/[0.08] rounded-xl transition-colors"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span>Settings</span>
          </Link>

          <div className="my-1 border-t border-white/10" />

          {currentUser.role === "admin" && (
            <Link
              to="/admin"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-amber-300 hover:bg-amber-500/10 rounded-xl transition-colors"
            >
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Admin Console</span>
            </Link>
          )}

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors text-left cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      )}
    </div>
  );
};
