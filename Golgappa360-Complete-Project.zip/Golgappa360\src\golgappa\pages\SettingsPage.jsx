import React, { useState } from 'react';
import {
  Settings,
  Database,
  Store,
  ShieldCheck,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Server,
  Key,
  Save,
  RotateCcw,
  Sparkles,
  Sliders,
  DollarSign,
  TrendingUp,
  Percent,
  MapPin,
  User,
  Smartphone
} from 'lucide-react';
import { useGolgappa } from '../context/GolgappaContext';
import { Badge } from '../components/common/Badge';
import { GlassCard } from '../components/glass/GlassCard';
import { GlassButton } from '../components/glass/GlassControls';

export function SettingsPage() {
  const {
    stallSettings,
    setStallSettings,
    dbStatus,
    backendOnline,
    handleTestDatabase,
    handleResetDemoData
  } = useGolgappa();

  // Local stall form state
  const [stallForm, setStallForm] = useState({ ...stallSettings });
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Database Connection test state
  const [dbConfig, setDbConfig] = useState({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '',
    database: 'golgappa360'
  });
  const [testingDb, setTestingDb] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [resetting, setResetting] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const handleSaveStall = (e) => {
    e.preventDefault();
    setStallSettings(stallForm);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const onTestDb = async () => {
    setTestingDb(true);
    setTestResult(null);
    const result = await handleTestDatabase(dbConfig);
    setTestingDb(false);
    setTestResult(result);
  };

  const onResetDemo = async () => {
    if (!window.confirm('Reset all sales, inventory and food waste records back to the fresh 30-day baseline?')) return;
    setResetting(true);
    await handleResetDemoData();
    setResetting(false);
    setResetSuccess(true);
    setTimeout(() => setResetSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2.5">
            <h2 className="text-xl sm:text-2xl font-extrabold font-['Manrope'] tracking-tight text-[#F5F4F1]">
              System Configuration & Settings
            </h2>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#A7D78A]/15 text-[#A7D78A] border border-[#A7D78A]/25">
              Admin Control
            </span>
          </div>
          <p className="text-xs text-[#929195] mt-1 font-sans">
            Stall business profile, MySQL database connection parameters, operational thresholds, and data reset tools.
          </p>
        </div>
      </div>

      {/* Database Connection Settings */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center justify-between pb-3.5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/[0.08] text-[#A7D78A] border border-white/12 flex items-center justify-center shadow-inner">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold font-['Manrope'] text-[#F5F4F1]">MySQL 8.0 Database Connection</h3>
              <p className="text-xs text-[#929195]">Configure credentials for the local or cloud MySQL instance</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant={dbStatus?.isConnected ? 'success' : backendOnline ? 'warning' : 'neutral'}>
              {dbStatus?.isConnected
                ? 'MySQL 8.0 Connected'
                : backendOnline
                ? 'High-Fidelity Engine Active'
                : 'Offline Fallback'}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Host</label>
            <input
              type="text"
              value={dbConfig.host}
              onChange={(e) => setDbConfig({ ...dbConfig, host: e.target.value })}
              className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Port</label>
            <input
              type="number"
              value={dbConfig.port}
              onChange={(e) => setDbConfig({ ...dbConfig, port: Number(e.target.value) })}
              className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Database User</label>
            <input
              type="text"
              value={dbConfig.user}
              onChange={(e) => setDbConfig({ ...dbConfig, user: e.target.value })}
              className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Database Password</label>
            <input
              type="password"
              placeholder="Enter MySQL root password"
              value={dbConfig.password}
              onChange={(e) => setDbConfig({ ...dbConfig, password: e.target.value })}
              className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] placeholder-[#929195] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Database Name</label>
            <input
              type="text"
              value={dbConfig.database}
              onChange={(e) => setDbConfig({ ...dbConfig, database: e.target.value })}
              className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
            />
          </div>
        </div>

        {/* Test Result Message Box */}
        {testResult && (
          <div
            className={`p-3.5 rounded-xl text-xs flex items-start gap-2.5 border backdrop-blur-md ${
              testResult.serverAccessible
                ? 'bg-emerald-500/10 text-emerald-200 border-emerald-500/25'
                : 'bg-amber-500/10 text-amber-200 border-amber-500/25'
            }`}
          >
            {testResult.serverAccessible ? (
              <CheckCircle2 className="w-4 h-4 text-[#A7D78A] shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#EAB64B] shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-semibold text-[#F5F4F1]">
                {testResult.serverAccessible ? 'MySQL Authentication Verified' : 'Connection Notice'}
              </p>
              <p className="mt-0.5 leading-relaxed text-[#B8B7B9]">{testResult.message}</p>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
          <p className="text-[11px] text-[#929195] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#A7D78A] animate-pulse"></span>
            MySQL service status: <strong className="text-[#F5F4F1] font-mono">Running on local port 3306</strong>
          </p>
          <GlassButton
            onClick={onTestDb}
            disabled={testingDb}
            variant="default"
            className="self-end sm:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testingDb ? 'animate-spin' : ''}`} />
            <span>{testingDb ? 'Verifying...' : 'Test MySQL Connection'}</span>
          </GlassButton>
        </div>
      </GlassCard>

      {/* Stall Profile Form */}
      <form onSubmit={handleSaveStall}>
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-3.5 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-white/[0.08] text-[#EAB64B] border border-white/12 flex items-center justify-center shadow-inner">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold font-['Manrope'] text-[#F5F4F1]">Stall Business Profile</h3>
                <p className="text-xs text-[#929195]">Identity, location, and operational thresholds</p>
              </div>
            </div>

            {saveSuccess && (
              <span className="text-xs font-semibold text-[#A7D78A] flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#A7D78A]/15 border border-[#A7D78A]/30">
                <CheckCircle2 className="w-3.5 h-3.5" /> Saved Successfully!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Stall Trade Name</label>
              <input
                type="text"
                required
                value={stallForm.stallName}
                onChange={(e) => setStallForm({ ...stallForm, stallName: e.target.value })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Proprietor / Owner Name</label>
              <input
                type="text"
                required
                value={stallForm.ownerName}
                onChange={(e) => setStallForm({ ...stallForm, ownerName: e.target.value })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Stall Physical Location</label>
              <input
                type="text"
                required
                value={stallForm.location}
                onChange={(e) => setStallForm({ ...stallForm, location: e.target.value })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">UPI VPA Handle</label>
              <input
                type="text"
                value={stallForm.upiVpa}
                onChange={(e) => setStallForm({ ...stallForm, upiVpa: e.target.value })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Default Pieces Per Plate</label>
              <input
                type="number"
                min="4"
                max="10"
                value={stallForm.defaultPlatePieces}
                onChange={(e) => setStallForm({ ...stallForm, defaultPlatePieces: Number(e.target.value) })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Target Gross Margin (%)</label>
              <input
                type="number"
                min="50"
                max="90"
                step="0.5"
                value={stallForm.targetGrossMarginPct || 70}
                onChange={(e) => setStallForm({ ...stallForm, targetGrossMarginPct: Number(e.target.value) })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#B8B7B9] mb-1.5">Food Waste Alert Threshold (%)</label>
              <input
                type="number"
                min="1"
                max="20"
                step="0.1"
                value={stallForm.wasteWarningThresholdPct || 5.0}
                onChange={(e) => setStallForm({ ...stallForm, wasteWarningThresholdPct: Number(e.target.value) })}
                className="w-full bg-white/[0.05] border border-white/12 text-[#F5F4F1] focus:border-[#A7D78A]/60 focus:bg-white/[0.08] rounded-xl text-xs py-2.5 px-3.5 transition-all outline-hidden"
              />
            </div>
          </div>

          <div className="flex justify-end pt-3">
            <GlassButton type="submit" variant="primary">
              <Save className="w-3.5 h-3.5" />
              <span>Save Stall Profile</span>
            </GlassButton>
          </div>
        </GlassCard>
      </form>

      {/* Demo Reset Tool */}
      <GlassCard className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-rose-500/20 bg-rose-500/[0.03]">
        <div>
          <h3 className="text-sm font-bold font-['Manrope'] text-[#F5F4F1] flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-[#D98768]" />
            Reset Baseline MCA Dataset
          </h3>
          <p className="text-xs text-[#929195] mt-1 max-w-lg">
            Reload fresh 30-day transactional history, 8 ingredients, 6 golgappa varieties, and 90 food waste audit logs.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {resetSuccess && (
            <span className="text-xs font-semibold text-[#A7D78A] flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Data Reset!
            </span>
          )}
          <GlassButton
            onClick={onResetDemo}
            disabled={resetting}
            variant="danger"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${resetting ? 'animate-spin' : ''}`} />
            <span>{resetting ? 'Resetting...' : 'Reload Demo Data'}</span>
          </GlassButton>
        </div>
      </GlassCard>
    </div>
  );
}
