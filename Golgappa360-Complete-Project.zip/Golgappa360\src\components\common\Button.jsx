import React from 'react';

export const Button = ({
  children,
  variant = 'primary', // 'primary', 'secondary', 'outline', 'danger', 'ghost', 'accent'
  size = 'md',        // 'sm', 'md', 'lg'
  icon: Icon,
  iconPosition = 'left',
  fullWidth = false,
  disabled = false,
  loading = false,
  className = '',
  onClick,
  type = 'button',
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 select-none active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none focus:outline-none';

  const sizeStyles = {
    sm: 'text-xs px-3 py-1.5 gap-1.5',
    md: 'text-sm px-4 py-2.5 gap-2',
    lg: 'text-base px-5 py-3.5 gap-2.5 font-semibold',
  };

  const variantStyles = {
    primary:
      'bg-[#00F5A0] text-[#050811] hover:bg-[#00D88E] shadow-[0_0_20px_-3px_rgba(0,245,160,0.4)] font-semibold',
    secondary:
      'bg-[#131E35] text-white hover:bg-[#1A2845] border border-white/10 hover:border-white/20',
    outline:
      'border border-[#00F5A0]/40 text-[#00F5A0] hover:bg-[#00F5A0]/10 hover:border-[#00F5A0]',
    danger:
      'bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25',
    ghost:
      'text-slate-300 hover:text-white hover:bg-white/5',
    accent:
      'bg-[#00E5FF] text-[#050811] hover:bg-[#00C2D8] shadow-[0_0_20px_-3px_rgba(0,229,255,0.4)] font-semibold',
  };

  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={`
        ${baseStyles}
        ${sizeStyles[size] || sizeStyles.md}
        ${variantStyles[variant] || variantStyles.primary}
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
      {...props}
    >
      {loading ? (
        <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
      ) : (
        Icon && iconPosition === 'left' && <Icon className="w-4 h-4 shrink-0" />
      )}
      <span>{children}</span>
      {!loading && Icon && iconPosition === 'right' && (
        <Icon className="w-4 h-4 shrink-0" />
      )}
    </button>
  );
};
