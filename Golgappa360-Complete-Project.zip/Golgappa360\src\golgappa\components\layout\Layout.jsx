import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

export function Layout({ children }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#171717] text-[#F5F4F1] font-sans antialiased p-2 sm:p-4 lg:p-6 flex items-center justify-center">
      {/* Large Rounded Translucent Application Shell matching reference image */}
      <div className="w-full max-w-[1600px] min-h-[94vh] rounded-[28px] lg:rounded-[36px] bg-[rgba(34,34,37,0.92)] backdrop-blur-2xl border border-white/10 shadow-[0_25px_70px_rgba(0,0,0,0.55)] flex flex-col lg:flex-row relative overflow-hidden">
        {/* Subtle Ambient Radial Backlights */}
        <div className="absolute -top-32 -left-32 w-[550px] h-[550px] rounded-full bg-[radial-gradient(circle,rgba(234,182,75,0.12)_0%,rgba(217,135,104,0.08)_40%,transparent_70%)] pointer-events-none" />
        <div className="absolute top-1/4 -right-32 w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle,rgba(167,215,138,0.09)_0%,rgba(48,48,50,0)_70%)] pointer-events-none" />
        <div className="absolute -bottom-40 left-1/3 w-[650px] h-[650px] rounded-full bg-[radial-gradient(circle,rgba(234,182,75,0.06)_0%,transparent_70%)] pointer-events-none" />

        {/* Sidebar Component */}
        <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 z-10 relative overflow-y-auto max-h-[94vh]">
          <TopBar setMobileOpen={setMobileOpen} />

          <main className="flex-1 px-4 sm:px-6 lg:px-8 pb-8 w-full max-w-7xl mx-auto space-y-6">
            {children}
          </main>

          {/* Minimalist Translucent Footer */}
          <footer className="px-6 lg:px-8 py-3.5 border-t border-white/[0.06] text-xs text-[#929195] flex flex-col sm:flex-row items-center justify-between gap-2 mt-auto">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#F5F4F1]">Golgappa360</span>
              <span className="text-[#929195]">•</span>
              <span className="text-[11px]">Glassmorphism Street-Food Intelligence Platform</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-[#B8B7B9]">
              <span>MCA Data Analytics</span>
              <span>•</span>
              <span className="text-[#A7D78A] font-semibold">MySQL 8.0 Live</span>
              <span>•</span>
              <span className="text-[#EAB64B] font-semibold">Tableau Ready</span>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
