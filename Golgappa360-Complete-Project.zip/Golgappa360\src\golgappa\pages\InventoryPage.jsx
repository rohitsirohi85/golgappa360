import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Package,
  Layers,
  ArrowDownRight,
  TrendingDown,
  ShoppingBag,
  IndianRupee,
  Clock,
  RefreshCw
} from 'lucide-react';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard } from '../components/glass/GlassCard';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';

export function InventoryPage() {
  const { inventoryData, handleRestockInventory, searchQuery } = useGolgappa();

  const [isRestockOpen, setIsRestockOpen] = useState(false);
  const [selectedIngredient, setSelectedIngredient] = useState('1');
  const [qtyToAdd, setQtyToAdd] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const ingredients = inventoryData?.ingredients || [];
  const ledger = inventoryData?.ledger || [];
  const lowStockCount = inventoryData?.lowStockCount || 0;
  const totalValue = inventoryData?.totalInventoryValue || 7120;

  const filteredIngredients = ingredients.filter((ing) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    const name = ing.name || '';
    const code = ing.code || ing.id || '';
    const cat = ing.category || '';
    return (
      name.toLowerCase().includes(q) ||
      code.toLowerCase().includes(q) ||
      cat.toLowerCase().includes(q)
    );
  });

  const handleRestockSubmit = async (e) => {
    e.preventDefault();
    if (!qtyToAdd || Number(qtyToAdd) <= 0) return;
    setIsSubmitting(true);
    await handleRestockInventory(selectedIngredient, Number(qtyToAdd), notes);
    setIsSubmitting(false);
    setIsRestockOpen(false);
    setQtyToAdd('');
    setNotes('');
  };

  const openRestockForItem = (id) => {
    setSelectedIngredient(String(id));
    setIsRestockOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/[0.08]">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F4F1] font-sans">
            Inventory & Raw Material Stock
          </h2>
          <p className="text-xs text-[#929195] mt-0.5">
            Real-time track of puris, aloo, vatana, mint-coriander, chutneys, dairy & spice reserves
          </p>
        </div>

        <button
          onClick={() => setIsRestockOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#A7D78A] text-[#171717] text-xs font-bold hover:bg-[#96C679] transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Restock Raw Materials</span>
        </button>
      </div>

      {/* KPI Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Total Raw Stock Valuation</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1] mt-1.5">
            ₹{totalValue.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-[#929195] mt-2">Active wholesale inventory on stall</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Critical / Low Stock Alerts</p>
          <div className="flex items-baseline gap-2 mt-1.5">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#EAB64B]">
              {lowStockCount} {lowStockCount === 1 ? 'Ingredient' : 'Ingredients'}
            </h3>
            {lowStockCount > 0 && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EAB64B]/20 text-[#EAB64B] border border-[#EAB64B]/40">
                Action Required
              </span>
            )}
          </div>
          <p className="text-[11px] text-[#929195] mt-2">Fresh Mint & Coriander below reserve</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Puri Stock On Counter</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-[#A7D78A] mt-1.5">
            {ingredients.find(i => i.code === 'ING-PURI')?.current_stock?.toLocaleString('en-IN') || '3,450'} pcs
          </h3>
          <p className="text-[11px] text-[#929195] mt-2">Sufficient for ~575 plates (1.9 days runway)</p>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-[11px] font-semibold text-[#929195] uppercase tracking-wider">Boiled Potato Reserves</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-[#F5F4F1] mt-1.5">
            {ingredients.find(i => i.code === 'ING-ALOO')?.current_stock || '28.5'} kg
          </h3>
          <p className="text-[11px] text-[#929195] mt-2">Azadpur Mandi Grade A crop</p>
        </GlassCard>
      </div>

      {/* Low Stock Warning Banner if any */}
      {lowStockCount > 0 && (
        <div className="glass-card bg-[#EAB64B]/10 border border-[#EAB64B]/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#EAB64B]/25 text-[#EAB64B] flex items-center justify-center shrink-0 mt-0.5 border border-[#EAB64B]/30">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#EAB64B] uppercase tracking-wider">
                Low Stock Safety Threshold Warning
              </h4>
              <p className="text-xs text-[#B8B7B9] mt-0.5">
                Fresh Mint & Coriander balance has dipped to <strong>3.2 kg</strong> (Safety reserve limit: 3.0 kg). Daily burn is 4.8 kg. Order replenishment before 6 PM rush.
              </p>
            </div>
          </div>
          <button
            onClick={() => openRestockForItem(4)}
            className="px-4 py-2 rounded-xl bg-[#EAB64B] text-[#171717] text-xs font-bold hover:bg-[#D4A33E] transition-all shrink-0 shadow-md cursor-pointer"
          >
            Restock Mint Now
          </button>
        </div>
      )}

      {/* Main Stock Table Glass Card */}
      <GlassCard className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] tracking-tight">
              Ingredient Inventory Ledger & Thresholds
            </h3>
            <p className="text-xs text-[#929195]">
              Current stock balances, minimum replenishment thresholds, and estimated days runway
            </p>
          </div>
          <span className="text-xs font-semibold text-[#929195]">
            8 Tracked Ingredients
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#F5F4F1]">
            <thead className="bg-white/[0.04] text-[#929195] font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3.5 rounded-l-xl">Code</th>
                <th className="px-4 py-3.5">Ingredient Name</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5 text-right">Current Stock</th>
                <th className="px-4 py-3.5 text-right">Min Threshold</th>
                <th className="px-4 py-3.5 text-right">Reorder Level</th>
                <th className="px-4 py-3.5 text-right">Daily Burn</th>
                <th className="px-4 py-3.5 text-center">Runway</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-4 py-3.5 text-center rounded-r-xl">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              {filteredIngredients.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-xs text-[#929195]">
                    No ingredients found matching your search. Try adjusting the query.
                  </td>
                </tr>
              ) : (
                filteredIngredients.map((ing) => {
                const isLow = ing.status === 'Low' || ing.status === 'Critical';
                return (
                  <tr key={ing.id} className="hover:bg-white/[0.04] transition-colors">
                    <td className="px-4 py-4 font-mono font-bold text-[#A7D78A]">
                      {ing.code}
                    </td>
                    <td className="px-4 py-4">
                      <p className="font-bold text-[#F5F4F1] text-sm">{ing.name}</p>
                      <p className="text-[11px] text-[#929195]">{ing.supplier || 'Wholesale Supplier'}</p>
                    </td>
                    <td className="px-4 py-4">
                      <span className="px-2 py-0.5 rounded-md bg-white/[0.08] text-[#B8B7B9] text-[11px] font-medium">
                        {ing.category || (ing.unit === 'pcs' ? 'Bakery Puri' : 'Raw Produce')}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <span className={`text-sm font-bold ${isLow ? 'text-[#EAB64B]' : 'text-[#F5F4F1]'}`}>
                        {Number(ing.current_stock || 0).toLocaleString('en-IN')} {ing.unit}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right text-[#929195] font-mono">
                      {ing.minimum_threshold || ing.reorder_level} {ing.unit}
                    </td>
                    <td className="px-4 py-4 text-right text-[#B8B7B9] font-mono">
                      {ing.reorder_level || ing.minimum_threshold} {ing.unit}
                    </td>
                    <td className="px-4 py-4 text-right font-semibold text-[#F5F4F1]">
                      ~{ing.total_consumed ? (ing.total_consumed / 182).toFixed(1) : (ing.daily_consumption_avg || 2.5)} {ing.unit}/day
                    </td>
                    <td className="px-4 py-4 text-center">
                      <span className={`font-bold ${isLow ? 'text-[#E58B79]' : 'text-[#A7D78A]'}`}>
                        {ing.daysRunway || 5} days
                      </span>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <Badge variant={isLow ? 'warning' : 'success'} size="sm">
                        {ing.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <button
                        onClick={() => openRestockForItem(ing.id)}
                        className="px-3 py-1 rounded-xl bg-white/[0.08] hover:bg-white/[0.16] text-[#A7D78A] border border-white/12 text-xs font-semibold transition-all cursor-pointer"
                      >
                        + Restock
                      </button>
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Restock Modal */}
      <Modal
        isOpen={isRestockOpen}
        onClose={() => setIsRestockOpen(false)}
        title="Restock Raw Material Inventory"
        subtitle="Record mandi supply arrivals or in-house kitchen preparations"
      >
        <form onSubmit={handleRestockSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Select Ingredient
            </label>
            <select
              value={selectedIngredient}
              onChange={(e) => setSelectedIngredient(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              {ingredients.map((ing) => (
                <option key={ing.id} value={ing.id}>
                  {ing.name} ({ing.unit}) — Current Stock: {ing.current_stock}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Quantity Received / Added
            </label>
            <input
              type="number"
              step="any"
              required
              min="0.1"
              placeholder="e.g. 1000 puris or 15 kg aloo"
              value={qtyToAdd}
              onChange={(e) => setQtyToAdd(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Supplier Invoice / Restock Notes
            </label>
            <input
              type="text"
              placeholder="e.g. Delivery from Gupta Puri Suppliers, Khari Baoli"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setIsRestockOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#929195] hover:text-[#F5F4F1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#A7D78A] text-[#171717] hover:bg-[#96C679] transition-colors shadow-md"
            >
              {isSubmitting ? 'Recording...' : 'Update Inventory Balance'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
