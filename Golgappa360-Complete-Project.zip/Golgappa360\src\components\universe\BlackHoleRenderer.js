/**
 * STELLAR 2.0 — Interactive Black Hole Canvas 2D Engine (U7)
 * 
 * Renders a scientifically educational, relativistic-inspired black hole visualization:
 * - Layer 1: Deep cosmic void & background starfield
 * - Layer 2: Gravitational Lensing & Spacetime Deflection (Einstein arcs & lensed star displacement)
 * - Layer 3: Relativistic Bipolar Jets (Collimated plasma outflow along spin axis)
 * - Layer 4: Warped Upper & Lower Accretion Disk (Lensed light passing over/under the horizon)
 * - Layer 5: Ultra-sharp Golden Photon Ring (Photons trapped in unstable circular orbits)
 * - Layer 6: Pitch-black Event Horizon (Pure absorption shadow, light cannot escape)
 * - Layer 7: Front Accretion Disk with Relativistic Doppler Asymmetry (Approaching limb brightened)
 * - Layer 8: Interactive Hotspot Brackets & Scientific Telemetry Callouts
 * 
 * DISCLAIMER: Scientific visualization — not to scale. Illustrative educational visualization.
 */

// Deterministic seed for reproducible background starfield
const STARS_COUNT = 240;
const BACKGROUND_STARS = Array.from({ length: STARS_COUNT }, (_, i) => {
  const seed = (i * 9301 + 49297) % 233280;
  const rnd1 = seed / 233280;
  const rnd2 = ((seed * 9301 + 49297) % 233280) / 233280;
  const rnd3 = ((seed * 1337 + 7919) % 233280) / 233280;

  return {
    angle: rnd1 * Math.PI * 2,
    distFactor: 0.15 + rnd2 * 0.85, // 0.15 to 1.0 from center
    baseSize: 0.8 + rnd3 * 1.6,
    baseAlpha: 0.25 + rnd2 * 0.65,
    twinkleSpeed: 0.0015 + rnd1 * 0.003,
    phase: rnd3 * Math.PI * 2,
    color: rnd3 > 0.8 ? '#93c5fd' : rnd3 > 0.6 ? '#fef08a' : '#f8fafc',
  };
});

/**
 * 1. Deep Space Cosmic Void & Background Atmosphere
 */
export function drawBlackHoleBackground(ctx, width, height, camera, time) {
  // Deep space base
  ctx.fillStyle = '#010206';
  ctx.fillRect(0, 0, width, height);

  // Subtle radial vignette centered on canvas
  const cx = width / 2;
  const cy = height / 2;
  const maxDim = Math.max(width, height);

  const bgGrad = ctx.createRadialGradient(cx, cy, maxDim * 0.1, cx, cy, maxDim * 0.75);
  bgGrad.addColorStop(0, 'rgba(4, 7, 20, 0.6)');
  bgGrad.addColorStop(0.5, 'rgba(2, 4, 12, 0.85)');
  bgGrad.addColorStop(1, '#010206');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Faint warm accretion haze in ambient space
  const hazeGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, maxDim * 0.45);
  hazeGrad.addColorStop(0, 'rgba(245, 158, 11, 0.035)');
  hazeGrad.addColorStop(0.5, 'rgba(234, 88, 12, 0.018)');
  hazeGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = hazeGrad;
  ctx.fillRect(0, 0, width, height);
}

/**
 * 2. Background Starfield with Relativistic Gravitational Lensing
 * 
 * Mass warps spacetime, deflecting light rays radially outward from the shadow
 * and stretching background stars into tangential Einstein arcs.
 */
export function drawLensedStars(ctx, width, height, cx, cy, shadowR, showLensing, time) {
  const maxRadius = Math.max(width, height) * 0.65;
  const einsteinR = shadowR * 1.45;

  ctx.save();

  for (let i = 0; i < BACKGROUND_STARS.length; i++) {
    const s = BACKGROUND_STARS[i];
    const origDist = s.distFactor * maxRadius;
    const origX = cx + Math.cos(s.angle) * origDist;
    const origY = cy + Math.sin(s.angle) * origDist * 0.85;

    // Twinkle alpha modulation
    const twinkle = 0.7 + 0.3 * Math.sin(time * s.twinkleSpeed + s.phase);
    const alpha = Math.max(0.1, Math.min(1.0, s.baseAlpha * twinkle));

    if (!showLensing) {
      // Standard unlensed star
      if (origDist > shadowR * 0.95) {
        ctx.fillStyle = s.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(origX, origY, s.baseSize, 0, Math.PI * 2);
        ctx.fill();
      }
      continue;
    }

    // Gravitational Lensing Displacement:
    // Deflection pushes apparent images radially outward: r' = r + r_E^2 / r
    const distToCenter = Math.hypot(origX - cx, origY - cy);

    // If star falls directly into event horizon shadow, it is absorbed
    if (distToCenter < shadowR * 0.9) {
      continue;
    }

    // Radial deflection
    const deflection = (einsteinR * einsteinR) / Math.max(distToCenter, 1);
    const lensedDist = distToCenter + deflection * 0.42;

    const angle = Math.atan2(origY - cy, origX - cx);
    const lensedX = cx + Math.cos(angle) * lensedDist;
    const lensedY = cy + Math.sin(angle) * lensedDist;

    // If close to Einstein radius, stretch tangentially into an arc
    const proximity = Math.abs(distToCenter - einsteinR) / einsteinR;
    if (proximity < 0.55 && distToCenter > shadowR * 1.1) {
      const arcLen = (1 - proximity) * 0.22; // Arc angle span in radians
      ctx.strokeStyle = s.color;
      ctx.lineWidth = s.baseSize * 1.2;
      ctx.globalAlpha = alpha * 0.9;
      ctx.beginPath();
      ctx.arc(cx, cy, lensedDist, angle - arcLen / 2, angle + arcLen / 2);
      ctx.stroke();
    } else {
      ctx.fillStyle = s.color;
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.arc(lensedX, lensedY, s.baseSize, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Faint Einstein Ring glow halo around the black hole if lensing is enabled
  if (showLensing) {
    const ringGrad = ctx.createRadialGradient(cx, cy, shadowR * 1.25, cx, cy, shadowR * 1.7);
    ringGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    ringGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.08)');
    ringGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = ringGrad;
    ctx.globalAlpha = 1.0;
    ctx.beginPath();
    ctx.arc(cx, cy, shadowR * 1.7, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * 3. Collimated Bipolar Relativistic Plasma Jets (M87* & Cygnus X-1)
 */
export function drawBipolarJets(ctx, cx, cy, shadowR, time, hasJets) {
  if (!hasJets) return;

  ctx.save();
  const jetLength = shadowR * 4.8;
  const pulse = Math.sin(time * 0.003) * 0.1;

  // North Jet (pointing upward)
  const jetGradN = ctx.createLinearGradient(cx, cy, cx, cy - jetLength);
  jetGradN.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
  jetGradN.addColorStop(0.15, 'rgba(168, 85, 247, 0.45)');
  jetGradN.addColorStop(0.5, 'rgba(99, 102, 241, 0.25)');
  jetGradN.addColorStop(0.85, 'rgba(56, 189, 248, 0.1)');
  jetGradN.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = jetGradN;
  ctx.beginPath();
  ctx.moveTo(cx - shadowR * 0.18, cy);
  ctx.lineTo(cx - shadowR * 0.55 * (1 + pulse), cy - jetLength);
  ctx.lineTo(cx + shadowR * 0.55 * (1 + pulse), cy - jetLength);
  ctx.lineTo(cx + shadowR * 0.18, cy);
  ctx.closePath();
  ctx.fill();

  // South Jet (pointing downward)
  const jetGradS = ctx.createLinearGradient(cx, cy, cx, cy + jetLength);
  jetGradS.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
  jetGradS.addColorStop(0.15, 'rgba(168, 85, 247, 0.45)');
  jetGradS.addColorStop(0.5, 'rgba(99, 102, 241, 0.25)');
  jetGradS.addColorStop(0.85, 'rgba(56, 189, 248, 0.1)');
  jetGradS.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = jetGradS;
  ctx.beginPath();
  ctx.moveTo(cx - shadowR * 0.18, cy);
  ctx.lineTo(cx - shadowR * 0.55 * (1 + pulse), cy + jetLength);
  ctx.lineTo(cx + shadowR * 0.55 * (1 + pulse), cy + jetLength);
  ctx.lineTo(cx + shadowR * 0.18, cy);
  ctx.closePath();
  ctx.fill();

  // Central synchrotron shock knots along the jet
  const knotY1 = cy - jetLength * 0.35 + Math.sin(time * 0.002) * 5;
  const knotGrad = ctx.createRadialGradient(cx, knotY1, 0, cx, knotY1, shadowR * 0.45);
  knotGrad.addColorStop(0, 'rgba(255, 255, 255, 0.85)');
  knotGrad.addColorStop(0.4, 'rgba(192, 132, 252, 0.4)');
  knotGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = knotGrad;
  ctx.beginPath();
  ctx.arc(cx, knotY1, shadowR * 0.45, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * 4. Warped Upper & Lower Accretion Disk (Lensed Back Limb)
 * 
 * Due to extreme gravitational lensing, the back of the disk appears bent
 * upward OVER the black hole and downward UNDER the black hole, creating
 * the iconic relativistic arch seen in general relativity simulations (Interstellar/EHT).
 */
export function drawWarpedBackDisk(
  ctx,
  cx,
  cy,
  shadowR,
  diskOuterR,
  rotationAngle,
  options = {}
) {
  const { showAccretionDisk = true, isHighlighted = false } = options;
  if (!showAccretionDisk) return;

  ctx.save();

  const diskInnerR = shadowR * 1.15;
  const archHeight = shadowR * 1.85;

  // 4a. Upper Warped Arch (Back of disk bent over the top of the event horizon)
  ctx.save();
  ctx.beginPath();
  // Clip to area above the equatorial horizon center
  ctx.rect(cx - diskOuterR * 1.4, cy - archHeight * 1.4, diskOuterR * 2.8, archHeight * 1.4);
  ctx.clip();

  // Create arched ellipse
  const archGrad = ctx.createRadialGradient(cx, cy, diskInnerR, cx, cy, archHeight);
  archGrad.addColorStop(0, isHighlighted ? 'rgba(254, 240, 138, 0.95)' : 'rgba(254, 240, 138, 0.85)'); // Hot inner edge
  archGrad.addColorStop(0.25, 'rgba(245, 158, 11, 0.7)');
  archGrad.addColorStop(0.65, 'rgba(234, 88, 12, 0.4)');
  archGrad.addColorStop(0.9, 'rgba(185, 28, 28, 0.15)');
  archGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = archGrad;
  ctx.beginPath();
  ctx.ellipse(cx, cy, diskOuterR * 0.95, archHeight, 0, Math.PI, 0, false);
  ctx.ellipse(cx, cy, diskInnerR, diskInnerR * 0.9, 0, 0, Math.PI, true);
  ctx.closePath();
  ctx.fill();

  // Doppler brightening on the left side of the upper arch (approaching gas)
  const dopplerGrad = ctx.createRadialGradient(cx - diskOuterR * 0.4, cy - archHeight * 0.4, 0, cx - diskOuterR * 0.4, cy - archHeight * 0.4, diskOuterR * 0.6);
  dopplerGrad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
  dopplerGrad.addColorStop(0.5, 'rgba(254, 240, 138, 0.15)');
  dopplerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = dopplerGrad;
  ctx.fill();

  ctx.restore();

  // 4b. Lower Warped Arc (Secondary inverted mirage below the horizon)
  ctx.save();
  ctx.beginPath();
  ctx.rect(cx - diskOuterR * 1.2, cy + shadowR * 0.75, diskOuterR * 2.4, archHeight * 0.7);
  ctx.clip();

  const lowerArchGrad = ctx.createRadialGradient(cx, cy, shadowR * 1.1, cx, cy, archHeight * 0.85);
  lowerArchGrad.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
  lowerArchGrad.addColorStop(0.5, 'rgba(234, 88, 12, 0.25)');
  lowerArchGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = lowerArchGrad;
  ctx.beginPath();
  ctx.ellipse(cx, cy, diskOuterR * 0.85, archHeight * 0.8, 0, 0, Math.PI, false);
  ctx.ellipse(cx, cy, diskInnerR, diskInnerR * 0.85, 0, Math.PI, 0, true);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.restore();
}

/**
 * 5. Ultra-Sharp Golden Photon Ring
 * 
 * At r ≈ 1.5 r_s, photons orbit multiple times before escaping to the observer.
 */
export function drawPhotonRing(ctx, cx, cy, shadowR, time, isHighlighted) {
  ctx.save();

  const photonR = shadowR * 1.05;
  const pulse = Math.sin(time * 0.0025) * 0.05;

  // Outer soft glow
  const glowGrad = ctx.createRadialGradient(cx, cy, photonR * 0.92, cx, cy, photonR * 1.22);
  glowGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
  glowGrad.addColorStop(0.4, isHighlighted ? 'rgba(254, 240, 138, 0.7)' : 'rgba(253, 224, 71, 0.45)');
  glowGrad.addColorStop(0.7, 'rgba(245, 158, 11, 0.2)');
  glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, photonR * 1.22, 0, Math.PI * 2);
  ctx.fill();

  // Razor-sharp brilliant core ring
  ctx.strokeStyle = isHighlighted ? '#ffffff' : 'rgba(254, 243, 199, 0.95)';
  ctx.lineWidth = isHighlighted ? 2.5 : 1.4 + pulse;
  ctx.shadowColor = '#f59e0b';
  ctx.shadowBlur = isHighlighted ? 18 : 10;
  ctx.beginPath();
  ctx.arc(cx, cy, photonR, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}

/**
 * 6. Pitch-Black Event Horizon (The Black Hole Shadow)
 * 
 * Pure absorption void: escape velocity exceeds c, light cannot escape.
 */
export function drawEventHorizon(ctx, cx, cy, shadowR, isHighlighted) {
  ctx.save();

  // Pitch black central void
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(cx, cy, shadowR, 0, Math.PI * 2);
  ctx.fill();

  // Deep optical shadow boundary
  ctx.strokeStyle = isHighlighted ? 'rgba(245, 158, 11, 0.75)' : 'rgba(0, 0, 0, 0.9)';
  ctx.lineWidth = isHighlighted ? 2.0 : 1.0;
  ctx.stroke();

  if (isHighlighted) {
    // Subtle internal targeting reticle when selected
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(cx, cy, shadowR * 0.88, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * 7. Front Relativistic Accretion Disk with Doppler Asymmetry
 * 
 * Tilted elliptical disk in front of the lower half of the black hole.
 * Left limb (approaching) is boosted by relativistic beaming into intense white-gold.
 * Right limb (receding) is dimmed and redshifted into dark orange-amber.
 */
export function drawFrontAccretionDisk(
  ctx,
  cx,
  cy,
  shadowR,
  diskOuterR,
  rotationAngle,
  options = {}
) {
  const { showAccretionDisk = true, isHighlighted = false } = options;
  if (!showAccretionDisk) return;

  ctx.save();

  const diskInnerR = shadowR * 1.15;
  const diskTilt = 0.38; // Vertical foreshortening of the ellipse
  const tiltAngle = -0.08; // Subtle roll tilt in radians

  ctx.translate(cx, cy);
  ctx.rotate(tiltAngle);

  // Clip to front lower half of disk (y >= -shadowR * 0.15)
  ctx.save();
  ctx.beginPath();
  ctx.rect(-diskOuterR * 1.3, -shadowR * 0.12, diskOuterR * 2.6, diskOuterR * 1.4);
  ctx.clip();

  // Layer 1: Base Elliptical Disk Gradient
  const diskGrad = ctx.createRadialGradient(0, 0, diskInnerR, 0, 0, diskOuterR);
  diskGrad.addColorStop(0, isHighlighted ? 'rgba(255, 255, 255, 0.95)' : 'rgba(254, 240, 138, 0.9)'); // White-hot inner boundary
  diskGrad.addColorStop(0.2, 'rgba(251, 191, 36, 0.85)');
  diskGrad.addColorStop(0.5, 'rgba(245, 158, 11, 0.65)');
  diskGrad.addColorStop(0.8, 'rgba(220, 38, 38, 0.35)');
  diskGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = diskGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, diskOuterR, diskOuterR * diskTilt, 0, 0, Math.PI * 2);
  ctx.ellipse(0, 0, diskInnerR, diskInnerR * diskTilt, 0, Math.PI * 2, 0, true);
  ctx.closePath();
  ctx.fill();

  // Layer 2: Swirling Rotating Plasma Filaments
  const filamentCount = 12;
  for (let i = 0; i < filamentCount; i++) {
    const fAngle = rotationAngle + (i * Math.PI * 2) / filamentCount;
    const r1 = diskInnerR + (diskOuterR - diskInnerR) * ((i % 4) / 4);
    const r2 = diskInnerR + (diskOuterR - diskInnerR) * (((i % 4) + 1) / 4);

    const x1 = Math.cos(fAngle) * r1;
    const y1 = Math.sin(fAngle) * r1 * diskTilt;
    const x2 = Math.cos(fAngle + 0.3) * r2;
    const y2 = Math.sin(fAngle + 0.3) * r2 * diskTilt;

    if (y1 > -shadowR * 0.1 && y2 > -shadowR * 0.1) {
      ctx.strokeStyle = i % 2 === 0 ? 'rgba(254, 243, 199, 0.45)' : 'rgba(249, 115, 22, 0.35)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.quadraticCurveTo(x1 * 1.1, y1 * 1.1, x2, y2);
      ctx.stroke();
    }
  }

  // Layer 3: Relativistic Doppler Boosting (Approaching Left Limb)
  // Approaching gas moving toward observer is beamed to high luminosity
  const boostX = -diskOuterR * 0.48;
  const boostY = diskOuterR * diskTilt * 0.25;
  const dopplerGrad = ctx.createRadialGradient(boostX, boostY, 0, boostX, boostY, diskOuterR * 0.65);
  dopplerGrad.addColorStop(0, 'rgba(255, 255, 255, 0.65)'); // Blue-white peak
  dopplerGrad.addColorStop(0.35, 'rgba(254, 240, 138, 0.45)');
  dopplerGrad.addColorStop(0.7, 'rgba(245, 158, 11, 0.15)');
  dopplerGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = dopplerGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, diskOuterR, diskOuterR * diskTilt, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore(); // Restore clip
  ctx.restore(); // Restore rotation/translation
}

/**
 * 8. Interactive Hotspot Callouts & Scientific HUD Brackets
 */
export function drawHotspotCallouts(
  ctx,
  cx,
  cy,
  shadowR,
  diskOuterR,
  activeHotspotId,
  hoveredHotspotId,
  showLabels = true
) {
  if (!showLabels) return;

  ctx.save();

  const hotspots = [
    {
      id: 'event-horizon',
      name: 'EVENT HORIZON',
      sub: 'r_s = 2GM/c²',
      x: cx - shadowR * 0.3,
      y: cy + shadowR * 0.25,
      targetX: cx,
      targetY: cy,
      align: 'right',
      color: '#f59e0b',
    },
    {
      id: 'photon-ring',
      name: 'PHOTON RING',
      sub: 'r ≈ 1.5 r_s',
      x: cx + shadowR * 1.35,
      y: cy - shadowR * 0.9,
      targetX: cx + shadowR * 1.05 * Math.cos(-Math.PI / 4),
      targetY: cy + shadowR * 1.05 * Math.sin(-Math.PI / 4),
      align: 'left',
      color: '#fef08a',
    },
    {
      id: 'accretion-disk',
      name: 'ACCRETION DISK',
      sub: 'T ≈ 10⁶ – 10¹¹ K',
      x: cx - diskOuterR * 0.85,
      y: cy + diskOuterR * 0.28,
      targetX: cx - diskOuterR * 0.65,
      targetY: cy + diskOuterR * 0.18,
      align: 'right',
      color: '#f97316',
    },
    {
      id: 'gravitational-lensing',
      name: 'GRAVITATIONAL LENSING',
      sub: 'Einstein Curvature',
      x: cx + diskOuterR * 0.72,
      y: cy - diskOuterR * 0.42,
      targetX: cx + diskOuterR * 0.52,
      targetY: cy - diskOuterR * 0.26,
      align: 'left',
      color: '#38bdf8',
    },
  ];

  for (const h of hotspots) {
    const isSelected = activeHotspotId === h.id;
    const isHovered = hoveredHotspotId === h.id;
    const isFocused = isSelected || isHovered;

    const mainColor = isFocused ? '#ffffff' : h.color;
    const alpha = isFocused ? 1.0 : 0.65;

    // Leader line from anchor to target
    ctx.strokeStyle = mainColor;
    ctx.lineWidth = isFocused ? 1.5 : 1.0;
    ctx.globalAlpha = alpha;
    ctx.setLineDash(isFocused ? [] : [3, 3]);

    ctx.beginPath();
    ctx.moveTo(h.targetX, h.targetY);
    ctx.lineTo(h.x, h.y);
    ctx.stroke();
    ctx.setLineDash([]);

    // Target pinpoint dot
    ctx.fillStyle = mainColor;
    ctx.beginPath();
    ctx.arc(h.targetX, h.targetY, isFocused ? 3.5 : 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Callout badge pill
    const padX = 7;
    const padY = 4;
    ctx.font = '600 10px ui-monospace, SFMono-Regular, Menlo, monospace';
    const textWidth = ctx.measureText(h.name).width;

    const badgeX = h.align === 'left' ? h.x + 6 : h.x - textWidth - padX * 2 - 6;
    const badgeY = h.y - 10;
    const badgeW = textWidth + padX * 2;
    const badgeH = 20;

    // Badge background
    ctx.fillStyle = isSelected
      ? 'rgba(245, 158, 11, 0.25)'
      : isHovered
      ? 'rgba(255, 255, 255, 0.15)'
      : 'rgba(3, 6, 18, 0.75)';
    ctx.strokeStyle = isFocused ? h.color : 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1;

    ctx.beginPath();
    ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4);
    ctx.fill();
    ctx.stroke();

    // Badge text
    ctx.fillStyle = isFocused ? '#ffffff' : h.color;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(h.name, badgeX + padX, badgeY + badgeH / 2);
  }

  ctx.restore();
}

/**
 * Hit-testing helper for cursor interactions
 */
export function getBlackHoleHitFeature(x, y, cx, cy, shadowR, diskOuterR) {
  const dist = Math.hypot(x - cx, y - cy);

  // 1. Event horizon (inside shadow)
  if (dist <= shadowR * 0.98) {
    return 'event-horizon';
  }

  // 2. Photon ring (narrow band right on shadow boundary)
  if (dist > shadowR * 0.98 && dist <= shadowR * 1.25) {
    return 'photon-ring';
  }

  // 3. Accretion disk (near equatorial plane)
  const dy = Math.abs(y - cy);
  const dx = Math.abs(x - cx);
  if (dist <= diskOuterR * 1.15 && dy <= diskOuterR * 0.45) {
    return 'accretion-disk';
  }

  // 4. Gravitational lensing (outer area above/below or around outer boundary)
  if (dist <= diskOuterR * 1.5) {
    return 'gravitational-lensing';
  }

  return null;
}
