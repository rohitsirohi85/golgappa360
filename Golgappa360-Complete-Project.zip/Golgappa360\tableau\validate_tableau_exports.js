/**
 * Golgappa360 - Tableau Export Validation & Reconciliation Script
 * 
 * Verifies 100% mathematical and relational parity between:
 * 1. Raw synthetic/MySQL source data
 * 2. Exported Tableau CSV datasets
 * 3. Application analytics layer
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT_DIR = path.resolve(__dirname, '..');
const EXPORTS_DIR = path.join(ROOT_DIR, 'tableau', 'exports');
const SYNTHETIC_DIR = path.join(ROOT_DIR, 'data', 'synthetic');

function parseCSV(filePath) {
  const content = fs.readFileSync(filePath, 'utf8').trim();
  const lines = content.split(/\r?\n/);
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).filter(l => l.trim()).map(line => {
    const values = [];
    let insideQuotes = false;
    let currentVal = '';
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(currentVal.trim().replace(/^"|"$/g, ''));
        currentVal = '';
      } else {
        currentVal += char;
      }
    }
    values.push(currentVal.trim().replace(/^"|"$/g, ''));
    const obj = {};
    headers.forEach((h, i) => {
      obj[h] = values[i] !== undefined ? values[i] : '';
    });
    return obj;
  });
}

export function runValidation() {
  console.log('=====================================================================');
  console.log('       Golgappa360 - Tableau Export Reconciliation Audit             ');
  console.log('=====================================================================\n');

  // Load raw source datasets
  const rawSales = parseCSV(path.join(SYNTHETIC_DIR, 'sales.csv'));
  const rawProducts = parseCSV(path.join(SYNTHETIC_DIR, 'products.csv'));
  const rawIngredients = parseCSV(path.join(SYNTHETIC_DIR, 'ingredients.csv'));
  const rawInventory = parseCSV(path.join(SYNTHETIC_DIR, 'inventory_transactions.csv'));
  const rawExpenses = parseCSV(path.join(SYNTHETIC_DIR, 'daily_expenses.csv'));

  const rawProdMap = new Map(rawProducts.map(p => [p.product_id, p]));
  const rawIngMap = new Map(rawIngredients.map(i => [i.ingredient_id, i]));

  // 1. Calculate Source Totals
  let srcGrossSales = 0;
  let srcDiscounts = 0;
  let srcNetRevenue = 0;
  let srcPlatesSold = 0;
  let srcCogs = 0;

  rawSales.forEach(s => {
    const q = parseInt(s.quantity_plates, 10);
    const p = parseFloat(s.unit_price);
    const d = parseFloat(s.discount);
    const prod = rawProdMap.get(s.product_id);
    const cp = prod ? parseFloat(prod.ingredient_cost_per_plate) : 0;

    srcGrossSales += q * p;
    srcDiscounts += d;
    srcNetRevenue += (q * p) - d;
    srcPlatesSold += q;
    srcCogs += q * cp;
  });

  const srcGrossProfit = srcNetRevenue - srcCogs;

  let srcExpenses = 0;
  rawExpenses.forEach(e => {
    srcExpenses += parseFloat(e.amount);
  });

  let srcWasteCost = 0;
  let srcWasteUnits = 0;
  let srcPurchaseUnits = 0;
  let srcConsumptionUnits = 0;

  rawInventory.forEach(tx => {
    const q = parseFloat(tx.quantity);
    const ing = rawIngMap.get(tx.ingredient_id);
    const cost = ing ? parseFloat(ing.unit_cost) : 0;
    if (tx.transaction_type === 'WASTE') {
      srcWasteCost += q * cost;
      srcWasteUnits += q;
    } else if (tx.transaction_type === 'PURCHASE') {
      srcPurchaseUnits += q;
    } else if (tx.transaction_type === 'CONSUMPTION') {
      srcConsumptionUnits += q;
    }
  });

  const srcOperatingProfit = srcGrossProfit - srcExpenses;

  // 2. Load Exported Tableau Datasets
  const tabSales = parseCSV(path.join(EXPORTS_DIR, 'tableau_sales.csv'));
  const tabProducts = parseCSV(path.join(EXPORTS_DIR, 'tableau_products.csv'));
  const tabInventory = parseCSV(path.join(EXPORTS_DIR, 'tableau_inventory.csv'));
  const tabDaily = parseCSV(path.join(EXPORTS_DIR, 'tableau_daily_summary.csv'));
  const tabExpenses = parseCSV(path.join(EXPORTS_DIR, 'tableau_expenses.csv'));
  const tabDict = parseCSV(path.join(EXPORTS_DIR, 'tableau_data_dictionary.csv'));

  // 3. Calculate Exported Totals
  let expGrossSales = 0;
  let expDiscounts = 0;
  let expNetRevenue = 0;
  let expPlatesSold = 0;
  let expCogs = 0;
  let expGrossProfit = 0;

  const saleIdSet = new Set();
  let duplicateSales = 0;

  tabSales.forEach(s => {
    if (saleIdSet.has(s.sale_id)) duplicateSales++;
    saleIdSet.add(s.sale_id);

    expGrossSales += parseFloat(s.gross_sales);
    expDiscounts += parseFloat(s.discount);
    expNetRevenue += parseFloat(s.net_revenue);
    expPlatesSold += parseInt(s.quantity_plates, 10);
    expCogs += parseFloat(s.cogs);
    expGrossProfit += parseFloat(s.gross_profit);
  });

  let expExpenses = 0;
  tabExpenses.forEach(e => {
    expExpenses += parseFloat(e.amount);
  });

  let expWasteCost = 0;
  let expWasteUnits = 0;
  let expPurchaseUnits = 0;
  let expConsumptionUnits = 0;

  tabInventory.forEach(tx => {
    const q = parseFloat(tx.quantity);
    if (tx.transaction_type === 'WASTE') {
      expWasteCost += parseFloat(tx.extended_cost);
      expWasteUnits += q;
    } else if (tx.transaction_type === 'PURCHASE') {
      expPurchaseUnits += q;
    } else if (tx.transaction_type === 'CONSUMPTION') {
      expConsumptionUnits += q;
    }
  });

  // Daily Summary Check
  let dailySummaryNetRevenue = 0;
  let dailySummaryPlates = 0;
  let dailySummaryCogs = 0;
  let dailySummaryGrossProfit = 0;
  let dailySummaryExpenses = 0;
  let dailySummaryWaste = 0;
  let dailySummaryOperatingProfit = 0;

  tabDaily.forEach(d => {
    dailySummaryNetRevenue += parseFloat(d.net_revenue);
    dailySummaryPlates += parseInt(d.plates_sold, 10);
    dailySummaryCogs += parseFloat(d.cogs);
    dailySummaryGrossProfit += parseFloat(d.gross_profit);
    dailySummaryExpenses += parseFloat(d.operating_expenses);
    dailySummaryWaste += parseFloat(d.daily_waste_cost);
    dailySummaryOperatingProfit += parseFloat(d.estimated_operating_profit);
  });

  // Check results
  const checks = [
    {
      metric: 'Sales Orders Count',
      source: rawSales.length,
      exported: tabSales.length,
      diff: Math.abs(rawSales.length - tabSales.length),
      unit: 'orders'
    },
    {
      metric: 'Plates Sold Volume',
      source: srcPlatesSold,
      exported: expPlatesSold,
      diff: Math.abs(srcPlatesSold - expPlatesSold),
      unit: 'plates'
    },
    {
      metric: 'Gross Sales Turnover',
      source: srcGrossSales,
      exported: expGrossSales,
      diff: Math.abs(srcGrossSales - expGrossSales),
      unit: 'INR'
    },
    {
      metric: 'Promotional Discounts',
      source: srcDiscounts,
      exported: expDiscounts,
      diff: Math.abs(srcDiscounts - expDiscounts),
      unit: 'INR'
    },
    {
      metric: 'Net Revenue',
      source: srcNetRevenue,
      exported: expNetRevenue,
      diff: Math.abs(srcNetRevenue - expNetRevenue),
      unit: 'INR'
    },
    {
      metric: 'Cost of Goods Sold (COGS)',
      source: srcCogs,
      exported: expCogs,
      diff: Math.abs(srcCogs - expCogs),
      unit: 'INR'
    },
    {
      metric: 'Gross Profit',
      source: srcGrossProfit,
      exported: expGrossProfit,
      diff: Math.abs(srcGrossProfit - expGrossProfit),
      unit: 'INR'
    },
    {
      metric: 'Total Operating Expenses',
      source: srcExpenses,
      exported: expExpenses,
      diff: Math.abs(srcExpenses - expExpenses),
      unit: 'INR'
    },
    {
      metric: 'Recorded Food Waste Cost',
      source: srcWasteCost,
      exported: expWasteCost,
      diff: Math.abs(srcWasteCost - expWasteCost),
      unit: 'INR'
    },
    {
      metric: 'Purchased Inventory Volume',
      source: srcPurchaseUnits,
      exported: expPurchaseUnits,
      diff: Math.abs(srcPurchaseUnits - expPurchaseUnits),
      unit: 'units'
    },
    {
      metric: 'Consumed Inventory Volume',
      source: srcConsumptionUnits,
      exported: expConsumptionUnits,
      diff: Math.abs(srcConsumptionUnits - expConsumptionUnits),
      unit: 'units'
    },
    {
      metric: 'Daily Summary Net Revenue Alignment',
      source: expNetRevenue,
      exported: dailySummaryNetRevenue,
      diff: Math.abs(expNetRevenue - dailySummaryNetRevenue),
      unit: 'INR'
    },
    {
      metric: 'Daily Summary Gross Profit Alignment',
      source: expGrossProfit,
      exported: dailySummaryGrossProfit,
      diff: Math.abs(expGrossProfit - dailySummaryGrossProfit),
      unit: 'INR'
    },
    {
      metric: 'Daily Summary Expenses Alignment',
      source: expExpenses,
      exported: dailySummaryExpenses,
      diff: Math.abs(expExpenses - dailySummaryExpenses),
      unit: 'INR'
    },
    {
      metric: 'Daily Summary Operating Profit Alignment',
      source: srcOperatingProfit,
      exported: dailySummaryOperatingProfit,
      diff: Math.abs(srcOperatingProfit - dailySummaryOperatingProfit),
      unit: 'INR'
    }
  ];

  let hasDiscrepancy = false;

  console.log('-----------------------------------------------------------------------------------------------------');
  console.log(
    'METRIC'.padEnd(42) +
    'SOURCE BASELINE'.padEnd(18) +
    'EXPORTED CSV'.padEnd(18) +
    'VARIANCE'.padEnd(14) +
    'STATUS'
  );
  console.log('-----------------------------------------------------------------------------------------------------');

  checks.forEach(c => {
    const isPassing = c.diff < 0.01;
    if (!isPassing) hasDiscrepancy = true;
    const statusStr = isPassing ? '[PASS]' : '[FAIL]';
    const srcStr = typeof c.source === 'number' && !Number.isInteger(c.source) ? c.source.toFixed(2) : String(c.source);
    const expStr = typeof c.exported === 'number' && !Number.isInteger(c.exported) ? c.exported.toFixed(2) : String(c.exported);
    const diffStr = c.diff.toFixed(2);

    console.log(
      c.metric.padEnd(42) +
      srcStr.padEnd(18) +
      expStr.padEnd(18) +
      diffStr.padEnd(14) +
      statusStr
    );
  });
  console.log('-----------------------------------------------------------------------------------------------------\n');

  // Verify file counts
  console.log('--- File Integrity Audit ---');
  console.log(`tableau_sales.csv:          ${tabSales.length} rows (Duplicates: ${duplicateSales})`);
  console.log(`tableau_products.csv:       ${tabProducts.length} rows`);
  console.log(`tableau_inventory.csv:      ${tabInventory.length} rows`);
  console.log(`tableau_daily_summary.csv:  ${tabDaily.length} rows (182 Operational Days)`);
  console.log(`tableau_expenses.csv:       ${tabExpenses.length} rows`);
  console.log(`tableau_data_dictionary.csv:${tabDict.length} field specifications`);

  console.log('\n=====================================================================');
  if (!hasDiscrepancy && duplicateSales === 0) {
    console.log('RESULT: 100% RECONCILIATION SUCCESS - ZERO DISCREPANCIES DETECTED');
  } else {
    console.log('RESULT: DISCREPANCY DETECTED IN VALIDATION');
  }
  console.log('=====================================================================\n');

  return {
    success: !hasDiscrepancy && duplicateSales === 0,
    checks,
    fileStats: {
      sales: tabSales.length,
      products: tabProducts.length,
      inventory: tabInventory.length,
      dailySummary: tabDaily.length,
      expenses: tabExpenses.length,
      dictionary: tabDict.length
    },
    totals: {
      netRevenue: expNetRevenue,
      grossProfit: expGrossProfit,
      operatingProfit: srcOperatingProfit,
      cogs: expCogs,
      expenses: expExpenses,
      wasteCost: expWasteCost,
      platesSold: expPlatesSold,
      ordersCount: tabSales.length
    }
  };
}

if (process.argv[1] && process.argv[1].endsWith('validate_tableau_exports.js')) {
  runValidation();
}
