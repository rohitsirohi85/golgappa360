import * as THREE from 'three';

/**
 * Neon Tunnel Preset
 * Infinite repeating glowing polygonal geometry with deep perspective,
 * warp-speed laser streaks, and dual-hand steering & acceleration.
 */
export class NeonTunnel {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;
    this.group = new THREE.Group();

    this.ringCount = 36;
    this.ringSpacing = 4.0;
    this.tunnelLength = this.ringCount * this.ringSpacing;
    this.rings = [];
    this.laserParticles = null;
    this.laserGeometry = null;
    this.laserMaterial = null;

    this.init();
    this.scene.add(this.group);
  }

  init() {
    const colors = [
      new THREE.Color('#9333ea'),
      new THREE.Color('#3b82f6'),
      new THREE.Color('#06b6d4'),
      new THREE.Color('#c084fc'),
    ];

    const ringShapeSides = 6;
    const ringRadius = 7.5;

    for (let i = 0; i < this.ringCount; i++) {
      const ringGeom = new THREE.RingGeometry(ringRadius - 0.15, ringRadius, ringShapeSides, 1);
      const ringColor = colors[i % colors.length];

      const ringMat = new THREE.MeshBasicMaterial({
        color: ringColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
      });

      const ringMesh = new THREE.Mesh(ringGeom, ringMat);

      const innerGeom = new THREE.RingGeometry(ringRadius * 0.7 - 0.08, ringRadius * 0.7, ringShapeSides, 1);
      const innerMat = new THREE.MeshBasicMaterial({
        color: colors[(i + 1) % colors.length],
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending,
      });
      const innerMesh = new THREE.Mesh(innerGeom, innerMat);
      ringMesh.add(innerMesh);

      const spokeGeom = new THREE.BufferGeometry();
      const spokeVertices = new Float32Array([
        0, 0, 0,
        Math.cos(0) * ringRadius, Math.sin(0) * ringRadius, 0,
        0, 0, 0,
        Math.cos(Math.PI) * ringRadius, Math.sin(Math.PI) * ringRadius, 0,
      ]);
      spokeGeom.setAttribute('position', new THREE.BufferAttribute(spokeVertices, 3));
      const spokeMat = new THREE.LineBasicMaterial({
        color: colors[(i + 2) % colors.length],
        transparent: true,
        opacity: 0.25,
        blending: THREE.AdditiveBlending,
      });
      const spokeLine = new THREE.LineSegments(spokeGeom, spokeMat);
      ringMesh.add(spokeLine);

      const zPos = -i * this.ringSpacing;
      ringMesh.position.set(0, 0, zPos);
      ringMesh.rotation.z = (i * 0.12);

      this.rings.push({
        mesh: ringMesh,
        baseZ: zPos,
        index: i,
        material: ringMat,
        innerMaterial: innerMat,
        spokeMaterial: spokeMat,
        baseColor: ringColor.clone(),
      });

      this.group.add(ringMesh);
    }

    const particleCount = 2000;
    this.laserGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const pColors = new Float32Array(particleCount * 3);
    const pVelocities = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      const angle = Math.random() * Math.PI * 2;
      const rad = 1.0 + Math.random() * (ringRadius - 1.2);

      positions[i3] = Math.cos(angle) * rad;
      positions[i3 + 1] = Math.sin(angle) * rad;
      positions[i3 + 2] = -Math.random() * this.tunnelLength;

      const pCol = colors[Math.floor(Math.random() * colors.length)];
      pColors[i3] = pCol.r;
      pColors[i3 + 1] = pCol.g;
      pColors[i3 + 2] = pCol.b;

      pVelocities[i] = 15.0 + Math.random() * 35.0;
    }

    this.laserGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.laserGeometry.setAttribute('color', new THREE.BufferAttribute(pColors, 3));
    this.laserVelocities = pVelocities;

    this.laserMaterial = new THREE.PointsMaterial({
      size: 1.4,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.laserParticles = new THREE.Points(this.laserGeometry, this.laserMaterial);
    this.group.add(this.laserParticles);

    this.camera.position.set(0, 0, 5);
    this.camera.lookAt(0, 0, -40);
  }

  update(delta, time, audioData, settings, mouse, hand1, hand2) {
    let steerX = mouse.x;
    let steerY = mouse.y;
    let speedBoost = 1.0;

    if (hand1 && hand1.active) {
      steerX = hand1.x;
      steerY = hand1.y;
      if (hand1.isPinching) speedBoost += 0.8;
    }

    if (hand2 && hand2.active) {
      // Hand 2 vertical position modulates warp boost
      speedBoost += Math.max(0, (hand2.y + 1.0) * 0.7);
      if (hand2.isPinching) speedBoost += 1.2;
    }

    const moveSpeed = ((24.0 * settings.speed) + (audioData.bass * 25.0 * settings.sensitivity)) * speedBoost;

    for (let r of this.rings) {
      r.mesh.position.z += moveSpeed * delta;

      if (r.mesh.position.z > 8.0) {
        r.mesh.position.z -= this.tunnelLength;
      }

      const distFromCam = Math.abs(r.mesh.position.z - 5.0);
      const audioPulse = 1.0 + (audioData.bass * 0.45 * settings.sensitivity * Math.exp(-distFromCam * 0.05));
      r.mesh.scale.set(audioPulse, audioPulse, 1.0);

      r.mesh.rotation.z = (r.index * 0.12) + (time * 0.4 * settings.speed) + (audioData.mid * 1.5 * settings.sensitivity);

      const depthAlpha = Math.max(0.05, 1.0 - (distFromCam / (this.tunnelLength * 0.95)));
      r.material.opacity = depthAlpha * 0.85 * settings.colorIntensity;
      r.innerMaterial.opacity = depthAlpha * 0.65 * settings.colorIntensity;

      if (audioData.kickBeat) {
        r.material.color.setRGB(1.0, 0.4, 1.0);
      } else {
        r.material.color.lerp(r.baseColor, 0.12);
      }
    }

    if (this.laserGeometry) {
      const posAttr = this.laserGeometry.attributes.position;
      const posArray = posAttr.array;

      for (let i = 0; i < posArray.length / 3; i++) {
        const i3 = i * 3;
        const speed = ((this.laserVelocities[i] * settings.speed) + (audioData.treble * 40.0 * settings.sensitivity)) * speedBoost;
        posArray[i3 + 2] += speed * delta;

        if (posArray[i3 + 2] > 6.0) {
          posArray[i3 + 2] = -this.tunnelLength;
        }
      }
      posAttr.needsUpdate = true;
    }

    const targetCamX = steerX * 3.2;
    const targetCamY = steerY * 2.8;
    this.camera.position.x += (targetCamX - this.camera.position.x) * 0.08;
    this.camera.position.y += (targetCamY - this.camera.position.y) * 0.08;

    const lookTargetX = steerX * 6.5;
    const lookTargetY = steerY * 5.5;
    this.camera.lookAt(lookTargetX, lookTargetY, -50);
    this.camera.rotation.z = -steerX * 0.22;
  }

  setQuality(qualityLevel) {
    if (this.laserGeometry) {
      let activeCount = 2000;
      if (qualityLevel === 'low') activeCount = 800;
      else if (qualityLevel === 'balanced') activeCount = 1400;
      this.laserGeometry.setDrawRange(0, activeCount);
    }
  }

  setDensity(densityPercent) {
    if (this.laserGeometry) {
      const activeCount = Math.floor(2000 * Math.max(0.2, Math.min(1.0, densityPercent)));
      this.laserGeometry.setDrawRange(0, activeCount);
    }
  }

  dispose() {
    for (let r of this.rings) {
      r.mesh.geometry.dispose();
      r.material.dispose();
      r.innerMaterial.dispose();
      r.spokeMaterial.dispose();
      this.group.remove(r.mesh);
    }
    this.rings = [];

    if (this.laserParticles) {
      this.group.remove(this.laserParticles);
      this.laserGeometry.dispose();
      this.laserMaterial.dispose();
      this.laserParticles = null;
    }

    this.scene.remove(this.group);
  }
}
