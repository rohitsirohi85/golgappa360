import React, { useState } from 'react';
import QuizIntro from './Quiz/QuizIntro';
import QuizQuestion from './Quiz/QuizQuestion';
import QuizResults from './Quiz/QuizResults';
import CosmicKnowledgeHub from './Quiz/CosmicKnowledgeHub';
import { generateQuiz } from '../data/quizQuestions';

/**
 * QuizSection — "COSMIC MISSION / OBSERVATORY CHALLENGE" (Phase 6)
 * Orchestrates:
 * 1. Quiz Mode Selection & Mission Intro (Easy, Intermediate, Expert)
 * 2. Active 10-Question Interactive Mission with Real-Time Feedback
 * 3. Cinematic Results Screen with Cosmic Profile Scorecard & Local Storage Best Score
 * 4. Cosmic Knowledge Hub ("ONE MORE THING…") Random Fact Discovery
 */
export default function QuizSection({ onExploreStar }) {
  const [quizState, setQuizState] = useState('intro'); // 'intro' | 'playing' | 'results'
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  // Initialize best score and saved difficulty from localStorage lazily
  const [difficulty, setDifficulty] = useState(() => {
    try {
      const savedDiff = localStorage.getItem('stellar_quiz_difficulty');
      return savedDiff && ['easy', 'intermediate', 'expert'].includes(savedDiff)
        ? savedDiff
        : 'intermediate';
    } catch {
      return 'intermediate';
    }
  });

  const [bestScore, setBestScore] = useState(() => {
    try {
      const savedScore = localStorage.getItem('stellar_quiz_best_score');
      return savedScore !== null ? parseInt(savedScore, 10) : null;
    } catch {
      return null;
    }
  });

  const handleSelectDifficulty = (diff) => {
    setDifficulty(diff);
    try {
      localStorage.setItem('stellar_quiz_difficulty', diff);
    } catch {
      // Ignore
    }
  };

  const handleStartMission = () => {
    const newQuestions = generateQuiz(difficulty, 10);
    setQuestions(newQuestions);
    setCurrentQuestionIndex(0);
    setScore(0);
    setQuizState('playing');
  };

  const handleAnswerSubmit = (isCorrect) => {
    if (isCorrect) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      // Mission Complete -> Results
      setQuizState('results');
      const finalScore = score;
      if (bestScore === null || finalScore > bestScore) {
        setBestScore(finalScore);
        try {
          localStorage.setItem('stellar_quiz_best_score', String(finalScore));
        } catch {
          // Ignore
        }
      }
    }
  };

  const handleRetry = () => {
    handleStartMission();
  };

  const handleResetBestScore = () => {
    setBestScore(null);
    try {
      localStorage.removeItem('stellar_quiz_best_score');
    } catch {
      // Ignore
    }
  };

  return (
    <section
      id="quiz"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Galactic Gradients */}
      <div
        aria-hidden="true"
        className="absolute top-1/3 -left-40 w-[600px] h-[600px] rounded-full bg-indigo-950/20 blur-[150px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-1/4 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-950/20 blur-[150px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-20 sm:space-y-28">
        {/* 1. Main Quiz Experience View */}
        {quizState === 'intro' && (
          <QuizIntro
            selectedDifficulty={difficulty}
            onSelectDifficulty={handleSelectDifficulty}
            onStartMission={handleStartMission}
            bestScore={bestScore}
            onResetBestScore={handleResetBestScore}
          />
        )}

        {quizState === 'playing' && questions.length > 0 && (
          <QuizQuestion
            question={questions[currentQuestionIndex]}
            currentIndex={currentQuestionIndex}
            totalQuestions={questions.length}
            difficulty={difficulty}
            onAnswerSubmit={handleAnswerSubmit}
            onNextQuestion={handleNextQuestion}
          />
        )}

        {quizState === 'results' && (
          <QuizResults
            score={score}
            totalQuestions={questions.length || 10}
            difficulty={difficulty}
            onRetry={handleRetry}
            bestScore={bestScore}
            onResetBestScore={handleResetBestScore}
          />
        )}

        {/* 2. Cosmic Knowledge Hub ("ONE MORE THING…") */}
        <CosmicKnowledgeHub onExploreStar={onExploreStar} />
      </div>
    </section>
  );
}
