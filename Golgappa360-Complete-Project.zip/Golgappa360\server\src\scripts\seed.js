import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

async function seedMySQL() {
  const host = process.env.DB_HOST || 'localhost';
  const port = Number(process.env.DB_PORT) || 3306;
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || '';
  const database = process.env.DB_NAME || 'golgappa360_db';

  console.log(`Connecting to MySQL on ${host}:${port} as ${user}...`);

  try {
    const conn = await mysql.createConnection({
      host,
      port,
      user,
      password,
      multipleStatements: true
    });

    console.log('Connected! Executing schema.sql...');
    const schemaPath = path.resolve(__dirname, '../../sql/schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf-8');

    await conn.query(schemaSql);
    console.log(`Database '${database}' and tables initialized successfully!`);

    await conn.changeUser({ database });

    // Seed Categories
    console.log('Seeding categories...');
    await conn.query(`
      INSERT IGNORE INTO categories (category_id, category_name, description, display_order) VALUES
      (1, 'Classic Pani Puri', 'Traditional crispy puris with spiced water and potato-vatana filling', 1),
      (2, 'Flavoured Specials', 'Signature pani varieties: Extra Teekha, Sweet Tamarind, and Hing', 2),
      (3, 'Chaat & Loaded Puris', 'Curd, sev, and rich chutney loaded savories', 3),
      (4, 'Custom & Dry Add-ons', 'Sukha puri, masala puris, and extra boondi refills', 4);
    `);

    // Seed Menu Items
    console.log('Seeding menu items...');
    await conn.query(`
      INSERT IGNORE INTO menu_items (item_id, item_code, item_name, category_id, flavour_profile, pieces_per_plate, selling_price, cost_price) VALUES
      (1, 'REG-01', 'Regular Golgappa (6 pcs)', 1, 'Teekha & Khatta Mix', 6, 30.00, 8.40),
      (2, 'SPICY-02', 'Spicy Teekha Pani Puri (6 pcs)', 2, 'Fiery Pudina Teekha', 6, 35.00, 9.20),
      (3, 'SWEET-03', 'Sweet Meetha Pani Puri (6 pcs)', 2, 'Khatta Meetha Tamarind', 6, 35.00, 9.80),
      (4, 'HING-04', 'Special Hing & Jeera Golgappa (6 pcs)', 2, 'Royal Asafoetida & Cumin', 6, 40.00, 10.50),
      (5, 'DAHI-05', 'Dahi Puri Deluxe (5 pcs)', 3, 'Creamy Dahi & Sev', 5, 60.00, 18.00),
      (6, 'SUKHA-06', 'Sukha Puri / Masala Puri (6 pcs)', 4, 'Crunchy Dry Chaat', 6, 25.00, 6.50);
    `);

    // Seed Ingredients
    console.log('Seeding ingredients...');
    await conn.query(`
      INSERT IGNORE INTO ingredients (ingredient_id, ingredient_code, ingredient_name, category, unit, current_stock, minimum_threshold, reorder_level, unit_cost) VALUES
      (1, 'ING-PURI', 'Suji & Atta Puris', 'Bakery', 'pcs', 3450.00, 1500.00, 2500.00, 0.35),
      (2, 'ING-ALOO', 'Potatoes (Aloo)', 'Produce', 'kg', 28.50, 15.00, 25.00, 24.00),
      (3, 'ING-CHANA', 'White Chickpeas (Safed Vatana)', 'Legumes', 'kg', 18.00, 10.00, 20.00, 68.00),
      (4, 'ING-MINT-COR', 'Fresh Mint & Coriander (Pudina & Dhaniya)', 'Produce', 'kg', 3.20, 3.00, 6.00, 45.00),
      (5, 'ING-IMLI', 'Tamarind & Jaggery Chutney Base', 'Sauces', 'kg', 8.50, 5.00, 10.00, 85.00),
      (6, 'ING-SEV', 'Fine Nylon Sev', 'Dry Savories', 'kg', 6.80, 4.00, 8.00, 125.00),
      (7, 'ING-DAHI', 'Fresh Thick Curd (Dahi)', 'Dairy', 'kg', 8.00, 6.00, 12.00, 65.00),
      (8, 'ING-SPICE-MIX', 'Special Chaat & Hing Masala Mix', 'Spices', 'kg', 4.10, 2.00, 5.00, 280.00);
    `);

    console.log('Seed completed successfully!');
    await conn.end();
  } catch (err) {
    console.error('MySQL Seeding failed:', err.message);
    process.exit(1);
  }
}

seedMySQL();
