import React, { useState, useEffect } from 'react';
import { COSMIC_FACTS } from '../../data/stellarEvolutionPaths';

/**
 * CosmicFacts — Rotating interactive "COSMIC FACT" panel
 * Highlights core astrophysical insights with manual next/prev controls and auto-timer.
 */
export default function CosmicFacts() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % COSMIC_FACTS.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const currentFact = COSMIC_FACTS[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + COSMIC_FACTS.length) % COSMIC_FACTS.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % COSMIC_FACTS.length);
  };

  return (
    <div className="w-full max-w-3xl mx-auto rounded-2xl glass-surface border border-white/10 p-5 sm:p-6 shadow-xl relative overflow-hidden select-none">
      {/* Accent Gradient Glow */}
      <div
        aria-hidden="true"
        className="absolute top-0 right-0 w-44 h-44 rounded-full blur-3xl opacity-15 pointer-events-none transition-colors duration-500"
        style={{ backgroundColor: currentFact.accent }}
      />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left Side: Icon & Content */}
        <div className="flex items-start gap-4">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold shrink-0 transition-colors duration-300"
            style={{
              backgroundColor: `${currentFact.accent}20`,
              color: currentFact.accent,
              border: `1px solid ${currentFact.accent}40`,
            }}
          >
            <span>{currentFact.icon}</span>
          </div>

          <div className="text-left">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-cyan-400 font-semibold">
                COSMIC FACT
              </span>
              <span className="text-slate-600">//</span>
              <span className="text-[11px] font-mono text-slate-300 font-medium">
                {currentFact.title}
              </span>
            </div>

            <p className="text-sm text-slate-200/90 leading-relaxed font-normal">
              {currentFact.fact}
            </p>
          </div>
        </div>

        {/* Right Side: Navigation & Counter */}
        <div className="flex items-center justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5 shrink-0">
          <button
            type="button"
            onClick={handlePrev}
            aria-label="Previous cosmic fact"
            className="w-8 h-8 rounded-full glass-surface border border-white/10 hover:border-white/30 text-slate-300 hover:text-white flex items-center justify-center text-xs transition-colors cursor-pointer"
          >
            ←
          </button>

          <span className="text-[11px] font-mono text-slate-400 px-1">
            0{currentIndex + 1} / 0{COSMIC_FACTS.length}
          </span>

          <button
            type="button"
            onClick={handleNext}
            aria-label="Next cosmic fact"
            className="w-8 h-8 rounded-full glass-surface border border-white/10 hover:border-white/30 text-slate-300 hover:text-white flex items-center justify-center text-xs transition-colors cursor-pointer"
          >
            →
          </button>
        </div>
      </div>
    </div>
  );
}
