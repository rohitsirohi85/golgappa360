import React from 'react';
import {
  Info,
  GraduationCap,
  Cpu,
  Database,
  CheckCircle2,
  FileCode2,
  ShieldCheck,
  Target,
  Workflow,
  Sparkles,
} from 'lucide-react';

export const AboutProjectPage = () => {
  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-[#16865B]" />
            About SmartMess AI
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              MCA Major Project
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            System architecture, academic project specifications, problem statement, and engineering roadmap.
          </p>
        </div>

        <div className="text-xs font-mono text-[#16865B] bg-[#E9F6EE] border border-[#C5E5D0] px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs font-medium">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Academic Evaluation Year: 2026</span>
        </div>
      </div>

      {/* Hero Overview Card */}
      <div className="rounded-xl bg-white border border-[#C5E5D0] p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2 text-[#16865B] text-xs font-semibold uppercase tracking-wider mb-2">
          <Sparkles className="w-4 h-4" />
          Master of Computer Applications (MCA) Final Capstone Project
        </div>
        <h3 className="text-xl sm:text-2xl font-extrabold text-[#25332D] tracking-tight">
          SmartMess AI — Intelligent Food Waste Prediction & Prevention System
        </h3>
        <p className="text-xs sm:text-sm text-[#55635C] mt-3 leading-relaxed max-w-3xl">
          An end-to-end intelligent decision-support system designed to forecast institutional hostel mess meal attendance, calculate dynamic batch cooking requirements, and reduce post-service food waste through predictive machine learning.
        </p>

        <div className="mt-6 pt-5 border-t border-[#EEF2EF] grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <span className="text-[#77847C] text-[10px] block">Project Status</span>
            <span className="text-[#16865B] font-bold text-sm">Full-Stack Complete</span>
          </div>
          <div>
            <span className="text-[#77847C] text-[10px] block">Serving Pipeline</span>
            <span className="text-[#25332D] font-bold text-sm">Linear Regression OLS</span>
          </div>
          <div>
            <span className="text-[#77847C] text-[10px] block">Backend API & DB</span>
            <span className="text-[#0284C7] font-bold text-sm">FastAPI + SQLite</span>
          </div>
          <div>
            <span className="text-[#77847C] text-[10px] block">Frontend Architecture</span>
            <span className="text-[#25332D] font-bold text-sm">React 19 + Vite</span>
          </div>
        </div>
      </div>

      {/* Problem Statement vs Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-3 shadow-xs">
          <div className="flex items-center gap-2 text-[#DC2626] font-semibold text-xs uppercase tracking-wider">
            <Target className="w-4 h-4" />
            The Core Problem
          </div>
          <h4 className="text-base font-bold text-[#25332D]">
            Unpredictable Turnout & Static Kitchen Batching
          </h4>
          <p className="text-xs text-[#77847C] leading-relaxed">
            University mess contractors prepare standardized food volumes assuming 100% capacity. However, factors like inclement weather, exam schedules, weekend travel, and menu fatigue cause attendance to fluctuate significantly.
          </p>
          <ul className="space-y-1.5 text-xs text-[#25332D] pt-2 border-t border-[#EEF2EF]">
            <li className="flex items-center gap-2 text-[#B91C1C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#DC2626] shrink-0"></span>
              Severe financial leakage (~₹1.4 Lakhs/month per 1,000 students)
            </li>
            <li className="flex items-center gap-2 text-[#B91C1C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#DC2626] shrink-0"></span>
              Substantial methane emissions generated in municipal landfills
            </li>
            <li className="flex items-center gap-2 text-[#B91C1C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#DC2626] shrink-0"></span>
              Zero feedback loops to inform the head chef before cooking starts
            </li>
          </ul>
        </div>

        <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-3 shadow-xs">
          <div className="flex items-center gap-2 text-[#16865B] font-semibold text-xs uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4" />
            The SmartMess AI Solution
          </div>
          <h4 className="text-base font-bold text-[#25332D]">
            Predictive Intelligence & Batch Optimization
          </h4>
          <p className="text-xs text-[#77847C] leading-relaxed">
            SmartMess AI ingests historical check-in curves, weather forecasts, holiday calendars, and recipe carb weights to generate calibrated batch cooking recommendations hours before prep starts.
          </p>
          <ul className="space-y-1.5 text-xs text-[#25332D] pt-2 border-t border-[#EEF2EF]">
            <li className="flex items-center gap-2 text-[#16865B]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#16865B] shrink-0"></span>
              Reduces avoidable post-service waste to below 7%
            </li>
            <li className="flex items-center gap-2 text-[#16865B]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#16865B] shrink-0"></span>
              Automated chef advisories (e.g. 2-phase staggered rice cooking)
            </li>
            <li className="flex items-center gap-2 text-[#16865B]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#16865B] shrink-0"></span>
              Transparent safety buffer preserving student food availability
            </li>
          </ul>
        </div>
      </div>

      {/* System Architecture Flow Diagram */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
          <div>
            <h3 className="text-base font-bold text-[#25332D] flex items-center gap-2">
              <Workflow className="w-4 h-4 text-[#16865B]" />
              End-to-End System Architecture
            </h3>
            <p className="text-xs text-[#77847C] mt-0.5">
              Multi-tiered modular design separating frontend visualization, inference service, and hardware sensors
            </p>
          </div>
          <span className="text-xs font-mono text-[#16865B] bg-[#E9F6EE] px-2.5 py-1 rounded border border-[#C5E5D0]">
            Modular Pipeline
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2">
            <div className="w-7 h-7 rounded-lg bg-white border border-[#C5E5D0] text-[#16865B] flex items-center justify-center font-bold text-xs font-mono shadow-2xs">
              01
            </div>
            <h5 className="text-xs font-bold text-[#25332D] uppercase tracking-wider">
              Data Ingestion
            </h5>
            <p className="text-[11px] text-[#77847C] leading-normal">
              Biometric mess entry, OpenWeatherMap precipitation API, academic calendar schedule, and recipe menu database.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2">
            <div className="w-7 h-7 rounded-lg bg-white border border-[#BAE6FD] text-[#0284C7] flex items-center justify-center font-bold text-xs font-mono shadow-2xs">
              02
            </div>
            <h5 className="text-xs font-bold text-[#25332D] uppercase tracking-wider">
              ML Feature Pipeline
            </h5>
            <p className="text-[11px] text-[#77847C] leading-normal">
              Rolling 14-day attendance lag, weekend-eve penalty factor, carb-density weight, and rainfall severity weighting.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2">
            <div className="w-7 h-7 rounded-lg bg-white border border-[#C5E5D0] text-[#16865B] flex items-center justify-center font-bold text-xs font-mono shadow-2xs">
              03
            </div>
            <h5 className="text-xs font-bold text-[#25332D] uppercase tracking-wider">
              Inference Engine
            </h5>
            <p className="text-[11px] text-[#77847C] leading-normal">
              Trained Linear Regression pipeline predicting meal waste (MAE 20.50 kg) with safety-buffered portion optimization.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5] space-y-2">
            <div className="w-7 h-7 rounded-lg bg-white border border-[#FDE68A] text-[#D97706] flex items-center justify-center font-bold text-xs font-mono shadow-2xs">
              04
            </div>
            <h5 className="text-xs font-bold text-[#25332D] uppercase tracking-wider">
              Chef UI & IoT Validation
            </h5>
            <p className="text-[11px] text-[#77847C] leading-normal">
              Real-time analytics dashboard, kitchen portion recommendations, and post-service waste log audit trail.
            </p>
          </div>
        </div>
      </div>

      {/* Tech Stack Components */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-6 space-y-4 shadow-xs">
        <h3 className="text-base font-bold text-[#25332D] flex items-center gap-2">
          <FileCode2 className="w-4 h-4 text-[#16865B]" />
          Technical Stack Specifications
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
            <span className="text-[10px] text-[#77847C] uppercase font-mono block">Frontend Core</span>
            <span className="text-[#25332D] font-bold text-xs mt-1 block">React 19 + Vite</span>
            <span className="text-[10px] text-[#77847C] mt-0.5 block">Fast HMR & modular JSX</span>
          </div>

          <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
            <span className="text-[10px] text-[#77847C] uppercase font-mono block">Styling System</span>
            <span className="text-[#16865B] font-bold text-xs mt-1 block">Tailwind CSS</span>
            <span className="text-[10px] text-[#77847C] mt-0.5 block">Light Fresh SaaS Palette</span>
          </div>

          <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
            <span className="text-[10px] text-[#77847C] uppercase font-mono block">Data Visualization</span>
            <span className="text-[#0284C7] font-bold text-xs mt-1 block">Recharts 3.x</span>
            <span className="text-[10px] text-[#77847C] mt-0.5 block">Area, Bar, Donut, Line</span>
          </div>

          <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
            <span className="text-[10px] text-[#77847C] uppercase font-mono block">Backend & ML</span>
            <span className="text-[#16865B] font-bold text-xs mt-1 block">FastAPI + Scikit-Learn</span>
            <span className="text-[10px] text-[#77847C] mt-0.5 block">SQLite persistence</span>
          </div>
        </div>
      </div>

      {/* Academic Disclaimer Footer Note */}
      <div className="p-4 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] text-xs text-[#55635C] leading-relaxed flex items-start gap-3 shadow-xs">
        <Info className="w-4 h-4 text-[#16865B] shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-[#16865B]">Academic Evaluation Compliance:</span>
          <p className="mt-0.5">
            This application represents the complete <strong>MCA Major Capstone Project (SmartMess AI)</strong>. In compliance with strict ethical standards, all model benchmarks, telemetry records, and predictions operate on a reproducible 1,000-record synthetic mess dataset with zero target leakage. No actual live student personal data or proprietary institutional records are exposed.
          </p>
        </div>
      </div>
    </div>
  );
};
