import React from 'react';
import { Sparkles, Info } from 'lucide-react';
import { useMess } from '../../context/MessContext';

export const SyntheticDataBadge = ({ size = 'md', interactive = true }) => {
  const { setIsDemoModalOpen } = useMess();

  if (size === 'sm') {
    return (
      <span
        onClick={interactive ? () => setIsDemoModalOpen(true) : undefined}
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 ${
          interactive ? 'cursor-pointer hover:bg-emerald-500/20 transition-colors' : ''
        }`}
        title="Phase 1: Synthetic benchmark data for academic demonstration"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        Synthetic Demo Data
      </span>
    );
  }

  return (
    <div
      onClick={interactive ? () => setIsDemoModalOpen(true) : undefined}
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900/90 text-emerald-300 border border-emerald-500/30 shadow-sm shadow-emerald-950/20 ${
        interactive ? 'cursor-pointer hover:border-emerald-400 hover:bg-slate-800/90 transition-all' : ''
      }`}
    >
      <div className="flex items-center gap-1.5">
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <span className="font-semibold tracking-wide uppercase text-[11px] text-emerald-400">
          Synthetic Demo Data
        </span>
      </div>
      <span className="text-slate-500">|</span>
      <span className="text-slate-400 hidden sm:inline text-[11px]">
        Phase 1 UI Prototype
      </span>
      {interactive && (
        <Info className="w-3.5 h-3.5 text-slate-400 hover:text-emerald-300 ml-0.5" />
      )}
    </div>
  );
};
