import express from 'express';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const invData = syntheticStore.getInventoryData();
    res.json({
      success: true,
      data: invData
    });
  } catch (error) {
    console.error('[API /api/inventory Error]', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/restock', (req, res) => {
  try {
    const { ingredient_id, quantity_added } = req.body;
    if (!ingredient_id || !quantity_added) {
      return res.status(400).json({ success: false, error: 'Ingredient ID and quantity are required.' });
    }

    // Refresh and return latest inventory data
    const invData = syntheticStore.getInventoryData();
    res.json({ success: true, data: invData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
