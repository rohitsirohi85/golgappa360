# EV SMART: Technical Risk Register & Mitigation Strategy
## Engineering Failure Mode and Effects Analysis (FMEA) for IoT & Cloud EV Infrastructure

---

## 1. Risk Evaluation Matrix

Risks are quantified using standard Severity ($S: 1-5$) and Probability ($P: 1-5$) scoring, where:
$$\text{Risk Priority Number (RPN)} = S \times P$$
- **High Risk:** $\text{RPN} \ge 15$ (Mandatory hardware/architectural interlock)
- **Medium Risk:** $8 \le \text{RPN} < 15$ (Software mitigation & watchdog timer)
- **Low Risk:** $\text{RPN} < 8$ (Logging, monitoring & alert generation)

---

## 2. Comprehensive Risk Register

| Risk ID | Failure Mode / Threat Scenario | Root Cause | Severity (1-5) | Prob. (1-5) | RPN | Implemented Architectural Mitigation | Verification Method |
| :--- | :--- | :--- | :---: | :---: | :---: | :--- | :--- |
| **RSK-01** | **Wi-Fi Connectivity Loss during Active Charging** | RF interference, router reboot, or DHCP lease expiration on the edge. | 4 | 4 | **16** | **Edge-Decoupled FreeRTOS Safety:** Core 0 safety loop runs independently of Wi-Fi. An internal 60-frame SRAM ring buffer caches telemetry and flushes upon reconnect. | Physical Wi-Fi disconnect test during live session. |
| **RSK-02** | **Relay Mechanical Contact Weld / Failure** | High inrush inductive current causing electrical arcing across Songle relay contacts. | 5 | 2 | **10** | **Dual Disconnect Hierarchy:** Snubber RC circuit across contacts; hardware E-Stop button cuts coil power; overcurrent alerts operator to isolate upstream breaker. | Inrush surge clamping & E-Stop verification. |
| **RSK-03** | **Enclosure Over-Temperature & Fire Hazard** | High contact resistance, poor terminal crimping, or ambient heat surge. | 5 | 3 | **15** | **Autonomous Thermal Trip:** DHT22 monitored every 100ms. If $T > 60^\circ\text{C}$, relay forced open locally in $<50\text{ms}$ with audible buzzer. | Heat-gun thermal trip test on physical testbed. |
| **RSK-04** | **PZEM-004T Sensor Drift / UART Desync** | Electrical noise on UART RX/TX lines or sensor internal power rail glitch. | 3 | 2 | **6** | **Software Watchdog & Checksum Validation:** Modbus-RTU CRC16 checksum checking; automatic software UART re-initialization if 5 consecutive frames fail. | Noise injection on UART lines test. |
| **RSK-05** | **Cloud Backend or Database Crash** | Server OOM, unhandled exception, or MongoDB connection timeout. | 4 | 2 | **8** | **Edge Resilience & Mongoose Retry:** ESP32 maintains safe relay state; Mongoose buffers outgoing mutations in memory; PM2/Docker auto-restarts backend. | Backend daemon process kill / auto-restart test. |
| **RSK-06** | **AI Microservice Latency Spike or Crash** | Heavy computational load, memory leak, or Python process termination. | 3 | 2 | **6** | **Safety Decoupling & Graceful Fallback:** AI service is advisory only. If FastAPI is unreachable, backend falls back to static time-of-use tariffs without interrupting charging. | AI process kill test during active session. |
| **RSK-07** | **High-Voltage Mains Shock Hazard** | Exposed terminal blocks or accidental operator contact during lab demonstration. | 5 | 1 | **5** | **Galvanic Isolation & Acrylic Enclosure:** 3.3V logic completely isolated via EL817 optocouplers; high-voltage AC terminals housed in sealed, insulated acrylic chassis. | Visual safety inspection & insulation resistance test. |
| **RSK-08** | **Brute-Force API Credential Attack** | Malicious bot attempting dictionary attacks on `/api/auth/login`. | 3 | 4 | **12** | **Rate Limiting & bcrypt Hashing:** `express-rate-limit` throttles IPs exceeding 100 req/15 min with HTTP 429; bcrypt salted hashing prevents rainbow table lookups. | Simulated attack runner (120 req / 30s). |
| **RSK-09** | **Concurrent Slot Overbooking Conflict** | Two drivers submitting simultaneous booking requests for the identical slot. | 3 | 3 | **9** | **Atomic MongoDB Transactions:** `findOneAndUpdate` with overlapping interval exclusion ensures only one transaction commits; runner receives HTTP 409. | Concurrency race-condition test suite. |
| **RSK-10** | **Wallet Double-Spending / Negative Balance**| Simultaneous session stops attempting to debit funds from depleted wallet. | 4 | 2 | **8** | **Atomic Conditional Decrement:** `$inc: { balance: -amount }` with condition `{ balance: { $gte: amount } }` prevents balances dropping below zero. | Multi-threaded wallet debit test. |

---

## 3. Residual Risk Statement
With the implementation of the above architectural and physical safeguards, all critical failure modes ($\text{RPN} \ge 15$) have been brought down to acceptable operational tolerances for an academic laboratory testbed.
