export const DEFAULT_CHARGING_SESSION = {
  sessionId: 'SES-2026-9921',
  stationName: 'Green Valley EV Hub',
  chargerId: 'CH-01',
  chargerName: 'Charger 01',
  connector: 'CCS2',
  initialBattery: 42,
  currentBattery: 78,
  targetBattery: 80,
  voltage: 233,       // V
  current: 9.6,       // A
  power: 2.23,        // kW
  energyDelivered: 15.2, // kWh
  temperature: 38,    // °C
  chargingTimeSec: 1935, // 32 minutes 15 seconds
  estimatedRemainingMin: 18,
  ratePerKwh: 10,
  powerCurve: [
    { time: '00:00', power: 0.0 },
    { time: '05:00', power: 2.20 },
    { time: '10:00', power: 2.24 },
    { time: '15:00', power: 2.25 },
    { time: '20:00', power: 2.23 },
    { time: '25:00', power: 2.22 },
    { time: '30:00', power: 2.23 },
    { time: '32:15', power: 2.23 },
  ],
};
