import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import { socketService } from '../../services/socketService';
import {
  AlertTriangle,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Check,
  RefreshCw,
  X,
  FileCheck,
} from 'lucide-react';

export const AdminAlertsScreen = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [resolving, setResolving] = useState(false);
  const [message, setMessage] = useState('');

  const fetchAlerts = async () => {
    try {
      setLoading(true);
      const data = await adminService.getAlerts(severityFilter, statusFilter);
      if (Array.isArray(data)) {
        setAlerts(data);
      }
    } catch (err) {
      console.error('Error fetching alerts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();

    // Listen for live faults via Socket.IO
    socketService.connect();
    const socket = socketService.socket;
    if (socket) {
      const handleFault = (fault) => {
        setAlerts((prev) => [fault, ...prev.filter((a) => a._id !== fault._id)]);
      };
      socket.on('charger:fault', handleFault);
      return () => socket.off('charger:fault', handleFault);
    }
  }, [severityFilter, statusFilter]);

  const handleAcknowledge = async (id) => {
    try {
      const res = await adminService.acknowledgeAlert(id);
      setMessage(`Alert acknowledged successfully.`);
      setAlerts((prev) =>
        prev.map((a) => (a._id === id ? { ...a, status: 'acknowledged' } : a))
      );
    } catch (err) {
      setMessage(`Error: ${err.message}`);
    }
  };

  const handleResolve = async (e) => {
    e.preventDefault();
    if (!selectedAlert) return;
    setResolving(true);
    try {
      await adminService.resolveAlert(selectedAlert._id, resolutionNotes);
      setMessage(`Alert ${selectedAlert._id} resolved and recorded in audit log.`);
      setAlerts((prev) =>
        prev.map((a) =>
          a._id === selectedAlert._id ? { ...a, status: 'resolved', resolutionNotes } : a
        )
      );
      setSelectedAlert(null);
      setResolutionNotes('');
    } catch (err) {
      setMessage(`Resolve error: ${err.message}`);
    } finally {
      setResolving(false);
    }
  };

  return (
    <AdminLayout
      pageTitle="System Alerts & Safety Faults"
      subtitle="Real-time IoT safety trip monitor, thermal thresholds & fault acknowledgment workflow"
    >
      {message && (
        <div className="mb-4 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex justify-between items-center">
          <span>{message}</span>
          <button onClick={() => setMessage('')} className="text-slate-400 hover:text-white">
            &times;
          </button>
        </div>
      )}

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
        <div className="flex flex-wrap items-center gap-3">
          {/* Severity filter */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            <span className="px-2 text-slate-500 uppercase text-[10px] font-bold">Severity:</span>
            {['all', 'critical', 'warning', 'info'].map((sev) => (
              <button
                key={sev}
                onClick={() => setSeverityFilter(sev)}
                className={`px-3 py-1 rounded-lg capitalize font-semibold transition-colors ${
                  severityFilter === sev
                    ? 'bg-emerald-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          {/* Status filter */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            <span className="px-2 text-slate-500 uppercase text-[10px] font-bold">Status:</span>
            {['all', 'active', 'acknowledged', 'resolved'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-lg capitalize font-semibold transition-colors ${
                  statusFilter === st
                    ? 'bg-emerald-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchAlerts}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Alerts Table */}
      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading system safety alerts...</p>
        </div>
      ) : alerts.length === 0 ? (
        <div className="h-64 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-slate-500 text-xs">
          <CheckCircle2 className="w-10 h-10 mb-2 text-emerald-500/40" />
          <p>No safety faults matching selected filters.</p>
        </div>
      ) : (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                  <th className="py-4 px-6 font-bold">Severity</th>
                  <th className="py-4 px-6 font-bold">Bay / Station</th>
                  <th className="py-4 px-6 font-bold">Fault Type</th>
                  <th className="py-4 px-6 font-bold">Message & Telemetry</th>
                  <th className="py-4 px-6 font-bold">Reported Time</th>
                  <th className="py-4 px-6 font-bold">Status</th>
                  <th className="py-4 px-6 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {alerts.map((a) => {
                  const isCritical = a.severity === 'critical';
                  const isWarning = a.severity === 'warning';
                  const isActive = a.status === 'active';
                  const isAcknowledged = a.status === 'acknowledged';

                  return (
                    <tr key={a._id} className="hover:bg-slate-800/40 transition-colors">
                      {/* Severity */}
                      <td className="py-4 px-6">
                        <span
                          className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full inline-block ${
                            isCritical
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : isWarning
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                          }`}
                        >
                          {a.severity}
                        </span>
                      </td>

                      {/* Bay / Station */}
                      <td className="py-4 px-6">
                        <span className="font-extrabold text-white block">{a.chargerId}</span>
                        <span className="text-[11px] text-slate-400">{a.stationName || 'EV Station'}</span>
                      </td>

                      {/* Fault Type */}
                      <td className="py-4 px-6 font-mono font-semibold text-slate-300">
                        {a.type}
                      </td>

                      {/* Message & Sensor Values */}
                      <td className="py-4 px-6">
                        <p className="font-medium text-slate-200 line-clamp-1">{a.message}</p>
                        <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono mt-0.5">
                          {a.temperature && <span>Temp: {a.temperature}°C</span>}
                          {a.voltage && <span>Volt: {a.voltage}V</span>}
                          {a.current && <span>Current: {a.current}A</span>}
                        </div>
                      </td>

                      {/* Time */}
                      <td className="py-4 px-6 text-slate-400 text-[11px] whitespace-nowrap">
                        {new Date(a.createdAt).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>

                      {/* Status */}
                      <td className="py-4 px-6">
                        <span
                          className={`text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse'
                              : isAcknowledged
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {a.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {isActive && (
                            <button
                              onClick={() => handleAcknowledge(a._id)}
                              className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-semibold text-[11px] transition-colors"
                              title="Acknowledge fault"
                            >
                              Acknowledge
                            </button>
                          )}
                          {a.status !== 'resolved' && (
                            <button
                              onClick={() => setSelectedAlert(a)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold text-[11px] transition-colors"
                              title="Mark resolved"
                            >
                              Resolve
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Resolution Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Resolve Safety Alert</h3>
                  <p className="text-xs text-slate-400 font-mono">Bay: {selectedAlert.chargerId}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedAlert(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleResolve} className="space-y-4">
              <div>
                <span className="text-slate-400 text-xs block mb-1">Fault Description:</span>
                <p className="text-xs text-white bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  {selectedAlert.message}
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1.5">
                  Resolution Notes / Action Taken
                </label>
                <textarea
                  rows="3"
                  required
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  placeholder="e.g. Inspected cooling fan assembly. Temperature verified normal at 32°C. Disconnect switch reset."
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedAlert(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resolving}
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all disabled:opacity-50"
                >
                  {resolving ? 'Recording...' : 'Confirm Resolution'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminAlertsScreen;
