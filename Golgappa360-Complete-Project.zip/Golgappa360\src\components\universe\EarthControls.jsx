import React from 'react';

/**
 * EarthControls — Interactive HUD controls for Earth Exploration (Phase U6)
 * 
 * Features:
 * - Back to Solar System navigation
 * - Direct portal: Explore Moon
 * - Rotation play/pause
 * - Major astronomy feature toggles:
 *   - Atmosphere (Rayleigh scattering & cloud layer)
 *   - Day / Night (terminator shadow & city night lights)
 *   - Moon Orbit (orbital track & Moon position)
 *   - Magnetic Field (geomagnetic dipole shield lines)
 * - Zoom & Reset view controls
 */
export default function EarthControls({
  onBackToSolarSystem,
  onExploreMoon,
  isRotating,
  onToggleRotation,
  showAtmosphere,
  onToggleAtmosphere,
  showDayNight,
  onToggleDayNight,
  showMoonOrbit,
  onToggleMoonOrbit,
  showMagneticField,
  onToggleMagneticField,
  onZoomIn,
  onZoomOut,
  onResetView,
  className = '',
}) {
  return (
    <div className={`flex flex-col gap-2.5 ${className}`}>
      {/* Top Primary Actions Bar */}
      <div className="flex flex-wrap items-center gap-2 bg-[#020308]/85 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.85)]">
        {/* Back to Solar System */}
        <button
          type="button"
          onClick={onBackToSolarSystem}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-cyan-400/40 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer group"
          title="Return to the Solar System view"
        >
          <span className="text-cyan-400 group-hover:-translate-x-0.5 transition-transform">←</span>
          <span>SOLAR SYSTEM</span>
        </button>

        {/* Explore Moon Action Button */}
        <button
          type="button"
          onClick={onExploreMoon}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/90 border border-cyan-400/60 text-cyan-200 hover:text-white text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.3)] group"
          title="Explore Earth's Moon (Luna)"
        >
          <span>🌕</span>
          <span>EXPLORE MOON</span>
          <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform">→</span>
        </button>

        <div className="h-4 w-[1px] bg-white/10 mx-0.5 hidden sm:block" />

        {/* Rotation Play / Pause */}
        <button
          type="button"
          onClick={onToggleRotation}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-mono transition-all cursor-pointer ${
            isRotating
              ? 'bg-white/[0.04] hover:bg-white/[0.08] border-white/10 text-slate-200'
              : 'bg-amber-500/20 border-amber-500/40 text-amber-200'
          }`}
          title={isRotating ? 'Pause Earth rotation' : 'Resume Earth rotation'}
        >
          <span>{isRotating ? '⏸' : '▶'}</span>
          <span className="hidden sm:inline">{isRotating ? 'PAUSE' : 'PLAY'}</span>
        </button>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onZoomIn}
            className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
            title="Zoom in (+)"
          >
            +
          </button>
          <button
            type="button"
            onClick={onZoomOut}
            className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
            title="Zoom out (−)"
          >
            −
          </button>
          <button
            type="button"
            onClick={onResetView}
            className="px-2.5 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer flex items-center gap-1"
            title="Reset Earth view"
          >
            <span>⟲</span>
            <span className="hidden md:inline">RESET</span>
          </button>
        </div>
      </div>

      {/* Feature Toggles Strip */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 px-1 bg-[#020308]/75 backdrop-blur-md rounded-xl border border-white/5 max-w-full">
        {/* Atmosphere Toggle */}
        <button
          type="button"
          onClick={onToggleAtmosphere}
          className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            showAtmosphere
              ? 'bg-cyan-500/20 border border-cyan-400/50 text-cyan-200'
              : 'bg-white/[0.02] border border-white/5 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle Earth atmosphere halo & cloud layer"
        >
          <span>☁</span>
          <span>ATMOSPHERE</span>
          <span className="text-[10px] font-bold">{showAtmosphere ? 'ON' : 'OFF'}</span>
        </button>

        {/* Day / Night Cycle Toggle */}
        <button
          type="button"
          onClick={onToggleDayNight}
          className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            showDayNight
              ? 'bg-amber-500/20 border border-amber-400/50 text-amber-200'
              : 'bg-white/[0.02] border border-white/5 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle Day/Night terminator & city lights"
        >
          <span>🌓</span>
          <span>DAY / NIGHT</span>
          <span className="text-[10px] font-bold">{showDayNight ? 'ON' : 'OFF'}</span>
        </button>

        {/* Moon Orbit Toggle */}
        <button
          type="button"
          onClick={onToggleMoonOrbit}
          className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            showMoonOrbit
              ? 'bg-purple-500/20 border border-purple-400/50 text-purple-200'
              : 'bg-white/[0.02] border border-white/5 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle Moon orbital track & position"
        >
          <span>○</span>
          <span>MOON ORBIT</span>
          <span className="text-[10px] font-bold">{showMoonOrbit ? 'ON' : 'OFF'}</span>
        </button>

        {/* Magnetic Field Toggle */}
        <button
          type="button"
          onClick={onToggleMagneticField}
          className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            showMagneticField
              ? 'bg-indigo-500/20 border border-indigo-400/50 text-indigo-200'
              : 'bg-white/[0.02] border border-white/5 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle geomagnetic dipole shield lines"
        >
          <span>🧲</span>
          <span>MAGNETIC FIELD</span>
          <span className="text-[10px] font-bold">{showMagneticField ? 'ON' : 'OFF'}</span>
        </button>
      </div>
    </div>
  );
}
