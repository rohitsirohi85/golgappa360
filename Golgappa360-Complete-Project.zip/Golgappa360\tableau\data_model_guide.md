# Golgappa360 — Tableau Data Model & Architecture Guide

This guide details how to configure, relate, and structure the Golgappa360 dataset inside **Tableau Desktop** and **Tableau Public** (versions 2020.2+ through 2024.x) using modern **Tableau Logical Relationships (the "Noodle")** instead of rigid physical joins.

---

## 1. High-Level Data Model Architecture

The Golgappa360 analytical universe comprises five tabular datasets. These datasets represent distinct business grains that must **not** be flattened into a single table:

```
                                  ┌────────────────────────┐
                                  │   tableau_products     │
                                  │   (Dimension Catalog)  │
                                  └───────────┬────────────┘
                                              │ 1:Many
                                              │ Relationship: [product_id]
                                              ▼
┌─────────────────────────┐       ┌────────────────────────┐
│  tableau_daily_summary  │       │     tableau_sales      │
│  (Aggregated P&L Fact)  │       │   (Primary Fact Table) │
└───────────┬─────────────┘       └───────────┬────────────┘
            │                                 │
            │ Relationship on [sale_date]     │ Both share common
            │ (Date-level grain)              │ Date dimensions
            ▼                                 ▼
┌──────────────────────────────────────────────────────────┐
│                   Shared Time Dimension                  │
│                [sale_date] / [expense_date]              │
└───────────┬─────────────────────────────────┬────────────┘
            │                                 │
            │ Relationship on Date            │ Relationship on Date
            ▼                                 ▼
┌─────────────────────────┐       ┌────────────────────────┐
│    tableau_expenses     │       │   tableau_inventory    │
│    (Overhead Ledger)    │       │   (Movement & Waste)   │
└─────────────────────────┘       └───────────┬────────────┘
                                              │
                                              │ Relationship: [ingredient_id]
                                              ▼
                                  ┌────────────────────────┐
                                  │  Ingredients Catalog   │
                                  │  (Raw Material Master) │
                                  └────────────────────────┘
```

---

## 2. File Roles & Primary Table Identification

### Primary Fact Table: `tableau_sales.csv`
- **Role:** Primary transaction grain for customer orders, plate volumes, revenues, and order-level margins.
- **Grain:** One row per customer order plate line item.
- **Record Count:** 31,938 rows.
- **Primary Key:** `sale_id`.
- **Foreign Keys:** `product_id` (links to `tableau_products.csv`), `sale_date` (links to temporal dimensions).

### Dimension Catalog: `tableau_products.csv`
- **Role:** Product master defining variety categories, standard selling prices, ingredient BOM costs per plate, and portion pieces per plate.
- **Grain:** One row per unique menu variety.
- **Record Count:** 5 rows.
- **Primary Key:** `product_id`.

### Operational Fact Table: `tableau_inventory.csv`
- **Role:** Stock movements, batch purchases, kitchen consumption, and recorded food waste incidents.
- **Grain:** One row per inventory movement transaction.
- **Record Count:** 2,391 rows.
- **Primary Key:** `transaction_id`.
- **Foreign Key:** `ingredient_id`.

### Executive Aggregated Fact: `tableau_daily_summary.csv`
- **Role:** High-level daily business performance synthesizing Net Revenue, COGS, Gross Profit, Food Waste Cost, Operating Expenses, and Estimated Operating Profit.
- **Grain:** One row per operational calendar day.
- **Record Count:** 182 rows (full 6-month period).
- **Primary Key:** `sale_date`.

### Overhead Ledger: `tableau_expenses.csv`
- **Role:** Operational expense vouchers (Stall Rent, Packaging/Dona, LPG Gas, Power/Ice Utilities, Sanitation Fee).
- **Grain:** One row per expense payment.
- **Record Count:** 845 rows.
- **Primary Key:** `expense_id`.
- **Foreign Key:** `expense_date`.

---

## 3. How to Connect Files in Tableau Desktop / Public

### Step 1: Open Tableau and Create Connection
1. Launch Tableau Desktop or Tableau Public.
2. Under **Connect > To a File**, select **Text file**.
3. Navigate to `tableau/exports/` (or `data/tableau/`) and select `tableau_sales.csv`.
4. This places `tableau_sales` as the root logical table on the Data Source canvas.

### Step 2: Establish the Product Relationship (The Noodle)
1. In the left connections pane, click **Add** (or drag `tableau_products.csv` onto the canvas).
2. Drag `tableau_products.csv` to the right of `tableau_sales`.
3. Tableau will draw a flexible **relationship line ("noodle")**.
4. In the relationship dialog, verify the matching fields:
   $$\text{[tableau\_sales].[product\_id]} = \text{[tableau\_products].[product\_id]}$$
5. Cardinality: **Many-to-One** (`tableau_sales` is Many, `tableau_products` is One).

### Step 3: Handling Daily Summaries, Expenses, and Inventory
**CRITICAL BEST PRACTICE:** Do **not** drag `tableau_inventory` or `tableau_expenses` directly as physical joins to `tableau_sales`!

Instead, choose between two Tableau architectures depending on your workbook structure:

#### Option A: Multi-Table Logical Model (Recommended for Integrated Dashboards)
1. On the same canvas, relate `tableau_daily_summary.csv` to `tableau_sales.csv`:
   $$\text{[tableau\_sales].[sale\_date]} = \text{[tableau\_daily\_summary].[sale\_date]}$$
2. Relate `tableau_expenses.csv` to `tableau_daily_summary.csv`:
   $$\text{[tableau\_expenses].[expense\_date]} = \text{[tableau\_daily\_summary].[sale\_date]}$$
3. Relate `tableau_inventory.csv` to `tableau_daily_summary.csv`:
   $$\text{[tableau\_inventory].[transaction\_date]} = \text{[tableau\_daily\_summary].[sale\_date]}$$

#### Option B: Separate Data Sources (Recommended for Dedicated Worksheets)
Create three clean, isolated Data Sources in Tableau:
1. **Source 1: Sales & Products BI:** `tableau_sales` related to `tableau_products` (powers Dashboard 1 & Dashboard 2).
2. **Source 2: Daily P&L & Profitability:** `tableau_daily_summary` (powers Dashboard 4).
3. **Source 3: Inventory & Food Waste Ledger:** `tableau_inventory` (powers Dashboard 3).

---

## 4. Why You Must NEVER Blindly Join Sales & Inventory (The Fan Trap)

### The Cartesian Explosion Hazard
A classic business intelligence mistake is joining every available table into a single flat view:
```sql
-- DANGEROUS ANTI-PATTERN: DO NOT RUN THIS IN TABLEAU PHYSICAL JOINS
SELECT * 
FROM tableau_sales s
INNER JOIN tableau_inventory i ON s.sale_date = i.transaction_date;
```

### What Happens If You Do This?
- On 2026-05-01, there were **175 customer orders** in `tableau_sales`.
- On that same day, there were **14 inventory transactions** in `tableau_inventory`.
- An inner or left join duplicates every order 14 times, and every inventory transaction 175 times!
- Daily Net Revenue of ₹9,670.00 becomes **₹135,380.00** (inflated by 14×).
- Waste cost on that day becomes multiplied by 175×.
- Across 6 months, joining 31,938 sales with 2,391 inventory rows creates over **76 million rows**, crashing Tableau's memory buffer and producing completely fabricated financial figures.

### How Tableau Logical Relationships Solve This
Modern Tableau relationships do **not** flatten tables in advance. Tableau queries each table at its native grain:
- When you drag `[Net Revenue]` from `tableau_sales`, Tableau computes `SUM([Net Revenue])` across the 31,938 sales rows ($₹1,759,965.00$).
- When you drag `[Extended Cost]` from `tableau_inventory` where `[transaction_type] = 'WASTE'`, Tableau aggregates only across the 90 waste rows ($₹11,626.98$).
- Zero duplication, zero fan traps.

---

## 5. Dimensions vs. Measures Classification

Tableau automatically classifies fields upon import. Verify and adjust data types and roles according to this semantic dictionary:

### 1. Dimensions (Blue Pills — Categorical / Discrete)
- **Identifiers:** `[sale_id]`, `[product_id]`, `[transaction_id]`, `[expense_id]`, `[reference_id]`
- **Dates & Temporal Attributes:**
  - `[sale_datetime]` (Set to Date & Time)
  - `[sale_date]`, `[transaction_date]`, `[expense_date]` (Set to Date)
  - `[sale_hour]` (Integer, convert to Dimension)
  - `[day_of_week]`, `[is_weekend]` (Strings)
- **Product Categorization:** `[product_name]`, `[category]`, `[flavour_profile]`
- **Tender & Movements:** `[payment_method]`, `[transaction_type]`, `[movement_direction]`, `[expense_category]`
- **Inventory Units:** `[ingredient_name]`, `[unit]`
- **Audit Flag:** `[is_synthetic]`

### 2. Measures (Green Pills — Quantitative / Continuous)
- **Transaction Quantities:** `[quantity_plates]`, `[quantity]`
- **Revenue & Financial Values (Currency INR):**
  - `[unit_price]`, `[gross_sales]`, `[discount]`, `[net_revenue]`
  - `[ingredient_cost_per_plate]`, `[cogs]`, `[gross_profit]`
  - `[unit_cost]`, `[extended_cost]`
  - `[amount]` (Operating expenses)
  - `[daily_waste_cost]`, `[estimated_operating_profit]`
- **Percentages & Ratios:** `[gross_margin_pct]`, `[waste_ratio_pct]`, `[operating_margin_pct]`, `[unit_gross_margin_pct]`
- **Operational Thresholds:** `[reorder_level]`, `[pieces_per_plate]`
