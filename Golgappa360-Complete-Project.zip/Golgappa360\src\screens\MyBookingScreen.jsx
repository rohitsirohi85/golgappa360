import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Plus, AlertTriangle } from 'lucide-react';
import { Header } from '../components/common/Header';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { BookingCard } from '../components/booking/BookingCard';
import { EmptyState } from '../components/common/EmptyState';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const MyBookingScreen = () => {
  const navigate = useNavigate();
  const { bookings, cancelBooking } = useEV();
  const { showToast } = useUI();

  const [activeTab, setActiveTab] = useState('upcoming'); // 'upcoming', 'completed', 'cancelled'
  const [bookingToCancel, setBookingToCancel] = useState(null);

  const tabs = [
    { id: 'upcoming', label: 'Upcoming', count: bookings.filter((b) => b.status === 'Confirmed').length },
    { id: 'completed', label: 'Completed', count: bookings.filter((b) => b.status === 'Completed').length },
    { id: 'cancelled', label: 'Cancelled', count: bookings.filter((b) => b.status === 'Cancelled').length },
  ];

  const currentBookings = bookings.filter((b) => {
    if (activeTab === 'upcoming') return b.status === 'Confirmed';
    if (activeTab === 'completed') return b.status === 'Completed';
    if (activeTab === 'cancelled') return b.status === 'Cancelled';
    return true;
  });

  const handleConfirmCancel = () => {
    if (bookingToCancel) {
      cancelBooking(bookingToCancel.id);
      showToast(`Booking ${bookingToCancel.id} cancelled`, 'info');
      setBookingToCancel(null);
    }
  };

  const handleNavigateMap = (booking) => {
    showToast(`Navigating to ${booking.stationName}`, 'info');
    navigate('/stations');
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header
        title="My Bookings"
        rightAction={
          <button
            onClick={() => navigate('/stations')}
            className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-xl bg-[#00F5A0]/15 text-[#00F5A0] border border-[#00F5A0]/30 hover:bg-[#00F5A0]/25 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Slot</span>
          </button>
        }
      />

      <div className="px-4 py-3 space-y-4">
        {/* Tab Pills */}
        <div className="flex p-1 bg-[#0D1527] rounded-2xl border border-white/10">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex-1 py-2 text-xs font-semibold rounded-xl transition-all duration-200 flex items-center justify-center gap-1.5
                  ${
                    isActive
                      ? 'bg-[#15223C] text-white border border-white/10 shadow'
                      : 'text-slate-400 hover:text-white'
                  }
                `}
              >
                <span>{tab.label}</span>
                {tab.count > 0 && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-[#00F5A0] text-[#050811] font-bold' : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bookings List */}
        <div className="space-y-3">
          {currentBookings.length > 0 ? (
            currentBookings.map((booking) => (
              <BookingCard
                key={booking.id}
                booking={booking}
                onCancel={(b) => setBookingToCancel(b)}
                onNavigateMap={handleNavigateMap}
              />
            ))
          ) : (
            <EmptyState
              icon={Calendar}
              title={`No ${activeTab} bookings`}
              description={
                activeTab === 'upcoming'
                  ? 'You have no pending reservations. Discover nearby stations to book a slot.'
                  : `There are currently no ${activeTab} charging reservations in your log.`
              }
              actionLabel={activeTab === 'upcoming' ? 'Find Charging Station' : undefined}
              onAction={activeTab === 'upcoming' ? () => navigate('/stations') : undefined}
            />
          )}
        </div>
      </div>

      {/* Cancel Confirmation Modal */}
      <Modal
        isOpen={Boolean(bookingToCancel)}
        onClose={() => setBookingToCancel(null)}
        title="Cancel Reservation?"
        subtitle="Are you sure you want to release this charging slot?"
      >
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Release of Bay: {bookingToCancel?.chargerName}</p>
              <p className="text-[11px] text-rose-300/80 mt-0.5">
                This slot will immediately become available for other EV drivers. No cancellation fee applies for Phase 1.
              </p>
            </div>
          </div>

          <div className="flex gap-2.5 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => setBookingToCancel(null)}
            >
              Keep Slot
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleConfirmCancel}
            >
              Confirm Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
