import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CheckCircle2,
  Zap,
  Clock,
  Flame,
  Receipt,
  Star,
  Home,
  ThumbsUp,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const ChargingCompletedScreen = () => {
  const navigate = useNavigate();
  const { completedSession } = useEV();
  const { showToast } = useUI();

  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [feedbackTag, setFeedbackTag] = useState('Clean & Fast');

  const session = completedSession || {
    finalBattery: 80,
    energyUsed: 18.4,
    durationMinutes: 42,
    totalAmount: 184,
  };

  const handleRateSubmit = () => {
    setIsRatingModalOpen(false);
    showToast(`Thank you! Submitted ${rating}-star rating`, 'success');
  };

  return (
    <div className="flex flex-col min-h-full justify-between p-6 select-none bg-gradient-to-b from-[#051122] via-[#070B19] to-[#040711]">
      <div className="space-y-6 pt-4 text-center">
        {/* Animated Green Check Badge */}
        <div className="relative inline-flex items-center justify-center">
          <div className="absolute -inset-3 rounded-full bg-[#00F5A0]/20 animate-ping opacity-60" />
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#0D2E25] to-[#125845] border-2 border-[#00F5A0] flex items-center justify-center shadow-[0_0_30px_rgba(0,245,160,0.4)]">
            <CheckCircle2 className="w-10 h-10 text-[#00F5A0]" />
          </div>
        </div>

        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Charging Complete!
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
            Your EV battery has reached the targeted level. Cable is safe to unplug.
          </p>
        </div>

        {/* Big Battery Badge */}
        <div className="inline-flex items-baseline gap-1 py-2 px-5 rounded-2xl bg-[#00F5A0]/10 border border-[#00F5A0]/30 shadow-[0_0_15px_rgba(0,245,160,0.15)]">
          <span className="text-3xl font-extrabold font-mono text-white">
            {session.finalBattery}%
          </span>
          <span className="text-xs font-bold text-[#00F5A0] uppercase tracking-wide">
            Battery Ready
          </span>
        </div>

        {/* Session Summary Card */}
        <Card glow className="bg-[#0D1527] border-white/10 p-5 text-left space-y-3.5">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-white/10">
            <span className="text-slate-400">Station / Bay:</span>
            <span className="font-bold text-white">
              {session.stationName || 'Green Valley EV Hub'}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-[#00F5A0]" />
              <span>Energy Delivered:</span>
            </span>
            <span className="font-bold text-white font-mono text-sm">
              {session.energyUsed} kWh
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#00E5FF]" />
              <span>Charging Duration:</span>
            </span>
            <span className="font-bold text-white font-mono text-sm">
              {session.durationMinutes} minutes
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-2 border-t border-white/10">
            <span className="text-slate-400">Total Billed:</span>
            <span className="text-xl font-extrabold text-[#00F5A0] font-mono">
              ₹{session.totalAmount}
            </span>
          </div>
        </Card>
      </div>

      {/* Buttons */}
      <div className="space-y-2.5 pt-6">
        <Button
          size="lg"
          fullWidth
          onClick={() => navigate('/bill')}
          icon={Receipt}
        >
          View Bill
        </Button>

        <div className="grid grid-cols-2 gap-2.5">
          <Button
            variant="secondary"
            onClick={() => setIsRatingModalOpen(true)}
            icon={Star}
          >
            Rate Experience
          </Button>

          <Button
            variant="outline"
            onClick={() => navigate('/home')}
            icon={Home}
          >
            Back to Home
          </Button>
        </div>
      </div>

      {/* Rate Experience Modal */}
      <Modal
        isOpen={isRatingModalOpen}
        onClose={() => setIsRatingModalOpen(false)}
        title="Rate Your Experience"
        subtitle="Help us optimize station charging speeds and availability."
      >
        <div className="space-y-4 text-center">
          {/* 5-Star Rating Buttons */}
          <div className="flex justify-center gap-2 py-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="p-1 text-slate-500 hover:text-amber-400 transition-colors"
              >
                <Star
                  className={`w-7 h-7 ${
                    star <= rating
                      ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]'
                      : 'text-slate-600'
                  }`}
                />
              </button>
            ))}
          </div>

          <p className="text-xs font-semibold text-amber-400">
            {rating === 5 ? 'Excellent & Seamless' : rating >= 4 ? 'Very Good' : 'Could Be Improved'}
          </p>

          {/* Feedback Pills */}
          <div className="flex flex-wrap justify-center gap-2 pt-1">
            {['Clean Station', 'Fast Speed', 'Easy Parking', 'Clear Instructions'].map(
              (tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setFeedbackTag(tag)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                    feedbackTag === tag
                      ? 'bg-[#00F5A0]/20 text-[#00F5A0] border-[#00F5A0]'
                      : 'bg-[#0D1527] text-slate-400 border-white/10'
                  }`}
                >
                  {tag}
                </button>
              )
            )}
          </div>

          <div className="pt-3">
            <Button fullWidth onClick={handleRateSubmit} icon={ThumbsUp}>
              Submit Feedback
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
