import React, { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  Search,
  Sparkles,
  Flame,
  Heart,
  LogIn,
  UserPlus
} from "lucide-react";
import { Logo } from "../common/Logo";
import { useFavorites } from "../../context/FavoritesContext";
import { useAuth } from "../../context/AuthContext";
import { QuickSearchModal } from "./QuickSearchModal";
import { UserMenu } from "./UserMenu";

export const Navbar = () => {
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const { favoritesCount } = useFavorites();
  const { isAuthenticated } = useAuth();

  // Global Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/search", label: "Search" },
    { to: "/trending", label: "Trending", icon: Flame },
    { to: "/ai-search", label: "AI Search", icon: Sparkles, highlight: true }
  ];

  return (
    <>
      <header className="sticky top-0 z-30 w-full bg-[#08090d]/80 backdrop-blur-xl border-b border-white/[0.08] transition-all duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Brand Logo */}
          <div className="shrink-0">
            <Logo />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? "bg-white/[0.08] text-white shadow-inner"
                      : "text-slate-400 hover:text-white hover:bg-white/[0.04]"
                  } ${link.highlight ? "text-purple-300 font-bold" : ""}`
                }
              >
                {link.icon && <link.icon className="w-4 h-4 text-purple-400" />}
                <span>{link.label}</span>
              </NavLink>
            ))}
          </nav>

          {/* Right Side: Quick Search, Favorites, User Menu / Auth Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick search shortcut button */}
            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/10 hover:border-purple-500/40 hover:bg-white/[0.08] text-slate-400 hover:text-slate-200 text-xs transition-all cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-purple-400" />
              <span>Search lyrics...</span>
              <kbd className="hidden lg:inline-block px-1.5 py-0.5 rounded bg-white/10 text-[10px] text-slate-300 font-mono">
                Ctrl K
              </kbd>
            </button>

            {isAuthenticated ? (
              <>
                {/* Favorites Icon with Count Badge */}
                <Link
                  to="/favorites"
                  className="relative p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/[0.06] transition-colors"
                  aria-label="Favorites"
                >
                  <Heart className="w-5 h-5" />
                  {favoritesCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-rose-500 text-[10px] font-extrabold text-white flex items-center justify-center shadow-lg shadow-rose-500/40">
                      {favoritesCount}
                    </span>
                  )}
                </Link>

                {/* Reusable User Menu */}
                <UserMenu />
              </>
            ) : (
              /* Logged Out State */
              <div className="flex items-center gap-2">
                <Link
                  to="/login"
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/[0.06] transition-all"
                >
                  <LogIn className="w-3.5 h-3.5 text-purple-400" />
                  <span>Log In</span>
                </Link>

                <Link
                  to="/register"
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-purple-600/30 transition-all active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register</span>
                </Link>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Global Quick Search Modal */}
      <QuickSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
      />
    </>
  );
};
