import React, { useState } from 'react';
import { ArrowUpRight, Quote, Sparkles, X, Calendar } from 'lucide-react';
import { INSTRUCTORS } from '../data/danceData';

export const InstructorsSection = ({ onOpenTrial }) => {
  const [selectedInstructor, setSelectedInstructor] = useState(null);

  return (
    <section
      id="people"
      className="relative py-24 sm:py-32 bg-[#0B0B0F] border-t border-white/[0.08] overflow-hidden"
      aria-label="The People and Faculty"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/[0.08]">
          <div>
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ 04 // THE PEOPLE ]
            </span>
            <h2 className="editorial-headline text-3xl sm:text-5xl lg:text-6xl text-[#F5F3F8] uppercase">
              ARTISTS. <br />
              <span className="text-[#A78BFA]">NOT JUST INSTRUCTORS.</span>
            </h2>
          </div>
          <p className="font-sans text-sm sm:text-base text-[#A5A1B2] max-w-md leading-relaxed">
            Our faculty members are active movement researchers, battle champions, and choreographers who live on the floor. Every mentor brings decades of physical mastery directly to your training.
          </p>
        </div>

        {/* Instructors Editorial Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {INSTRUCTORS.map((instructor, idx) => (
            <div
              key={instructor.id}
              className="group relative flex flex-col justify-between rounded-sm bg-[#14141B] border border-white/[0.08] hover:border-[#8B5CF6]/50 transition-all duration-300 overflow-hidden"
            >
              {/* Image Container with Cinematic Crop & Grain */}
              <div className="relative aspect-[3/4] overflow-hidden bg-[#1B1B26]">
                <img
                  src={instructor.image}
                  alt={`Portrait of ${instructor.name}, ${instructor.role}`}
                  loading="lazy"
                  className="w-full h-full object-cover object-top filter grayscale contrast-125 group-hover:grayscale-0 group-hover:contrast-100 transition-all duration-500 scale-100 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#14141B] via-transparent to-transparent opacity-90 pointer-events-none" />
                <div className="film-grain absolute inset-0 pointer-events-none" />

                {/* Faculty Index Tag */}
                <div className="absolute top-3 left-3 z-10 pointer-events-none">
                  <span className="font-mono text-[9px] text-[#A78BFA] bg-black/70 backdrop-blur-sm px-2 py-1 rounded border border-white/10 uppercase tracking-widest">
                    FACULTY // 0{idx + 1}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <span className="font-mono text-[10px] text-[#8B5CF6] uppercase tracking-wider block mb-1">
                    {instructor.discipline}
                  </span>
                  <h3 className="font-display font-bold text-xl text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors">
                    {instructor.name}
                  </h3>
                  <p className="text-xs text-[#A5A1B2] mt-1 font-medium">
                    {instructor.role}
                  </p>

                  {/* Philosophy Quote */}
                  <blockquote className="mt-4 pt-4 border-t border-white/[0.06] text-xs italic text-[#A5A1B2] leading-relaxed">
                    "{instructor.quote}"
                  </blockquote>

                  {/* Focus Tags */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {instructor.focusTags.slice(0, 3).map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-white/[0.04] text-[#A5A1B2] border border-white/5"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Profile Trigger Button */}
                <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center justify-between">
                  <span className="font-mono text-[10px] text-[#A5A1B2]">
                    {instructor.experience}
                  </span>
                  <button
                    onClick={() => setSelectedInstructor(instructor)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#8B5CF6] group-hover:text-[#A78BFA] transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#8B5CF6] py-1"
                    aria-label={`View bio for ${instructor.name}`}
                  >
                    <span>VIEW PROFILE</span>
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Instructor Detail Modal */}
      {selectedInstructor && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="instructor-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in"
          onClick={() => setSelectedInstructor(null)}
        >
          <div
            className="relative w-full max-w-2xl bg-[#14141B] border border-white/[0.12] rounded-sm p-6 sm:p-8 shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setSelectedInstructor(null)}
              className="absolute top-4 right-4 p-2 text-[#A5A1B2] hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              aria-label="Close instructor profile"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              <div className="sm:col-span-5 relative aspect-[3/4] rounded-sm overflow-hidden border border-white/10">
                <img
                  src={selectedInstructor.image}
                  alt={selectedInstructor.name}
                  className="w-full h-full object-cover filter grayscale contrast-110"
                />
              </div>

              <div className="sm:col-span-7 flex flex-col justify-between">
                <div>
                  <span className="font-mono text-xs text-[#8B5CF6] uppercase font-semibold">
                    {selectedInstructor.discipline}
                  </span>
                  <h3
                    id="instructor-modal-title"
                    className="font-display font-extrabold text-2xl sm:text-3xl text-white uppercase mt-1"
                  >
                    {selectedInstructor.name}
                  </h3>
                  <p className="text-xs text-[#A5A1B2] mt-0.5">
                    {selectedInstructor.role}
                  </p>

                  <p className="mt-4 text-xs sm:text-sm text-[#F5F3F8] leading-relaxed">
                    {selectedInstructor.bioPlaceholder}
                  </p>

                  <div className="mt-4 p-3 rounded-sm bg-[#0B0B0F] border border-white/[0.08]">
                    <span className="font-mono text-[10px] text-[#A78BFA] uppercase block mb-1">
                      TEACHING PHILOSOPHY
                    </span>
                    <p className="text-xs italic text-[#A5A1B2]">
                      "{selectedInstructor.quote}"
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-white/[0.08] flex items-center justify-between gap-4">
                  <span className="font-mono text-xs text-[#A5A1B2]">
                    {selectedInstructor.experience}
                  </span>
                  <button
                    onClick={() => {
                      setSelectedInstructor(null);
                      onOpenTrial();
                    }}
                    className="px-5 py-2.5 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm shadow-[0_0_15px_rgba(139,92,246,0.5)]"
                  >
                    TRAIN WITH {selectedInstructor.name.split(' ')[0].toUpperCase()}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
