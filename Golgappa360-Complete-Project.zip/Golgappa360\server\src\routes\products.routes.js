import express from 'express';
import * as productsController from '../controllers/products.controller.js';

const router = express.Router();

router.get('/', productsController.getProducts);
router.get('/:id', productsController.getProductById);

export default router;
