# EV SMART: Complete Technology Stack Specification
## Visual Architectural Stack from Bare-Metal Hardware to Presentation Tier

---

## 1. Complete Technology Stack Diagram

```mermaid
graph TD
    subgraph L5 ["5. Presentation & Client Tier"]
        T_React["React 18 (Single Page App)"]
        T_Vite["Vite v5 (Build Tool & HMR)"]
        T_Tailwind["Tailwind CSS v3 (Utility Styling)"]
        T_Charts["Recharts (Real-Time SVG Telemetry)"]
        T_Icons["Lucide React (Icon System)"]
        T_PWA["Progressive Web App (Service Worker)"]
    end

    subgraph L4 ["4. Application & Intelligence Tier"]
        T_Node["Node.js v20 LTS (Runtime)"]
        T_Express["Express.js v4 (REST Routing)"]
        T_Socket["Socket.IO (WebSocket Server)"]
        T_FastAPI["FastAPI (Python 3.11 Async Microservice)"]
        T_Uvicorn["Uvicorn (ASGI Web Server)"]
        T_Scikit["Scikit-Learn (Random Forest & Isolation Forest)"]
        T_Pandas["Pandas / NumPy (Feature Engineering)"]
        T_Joblib["Joblib (Model Artifact Serialization)"]
    end

    subgraph L3 ["3. Persistence & Messaging Tier"]
        T_Mongo["MongoDB Enterprise Server v7.0"]
        T_Mongoose["Mongoose ODM (Schema & Validation)"]
        T_Mosquitto["Eclipse Mosquitto MQTT Broker v2.0"]
        T_MqttClient["mqtt.js (Node.js MQTT Client)"]
    end

    subgraph L2 ["2. Security, Testing & DevOps Tier"]
        T_JWT["JSON Web Tokens (HMAC-SHA256)"]
        T_Bcrypt["bcryptjs (10 Salt Rounds)"]
        T_Helmet["Helmet HTTP Security Headers"]
        T_RateLimit["express-rate-limit (IP Throttling)"]
        T_Supertest["Supertest / Mocha (202 Test Assertions)"]
        T_Artillery["Artillery (Load & Concurrency Testing)"]
    end

    subgraph L1 ["1. Embedded IoT & Edge Hardware Tier"]
        T_ESP32["ESP32-WROOM-32 (Dual-Core 240MHz Xtensa)"]
        T_FreeRTOS["FreeRTOS (Deterministic Dual-Core Task Scheduling)"]
        T_Cpp["C++ / Arduino Core / ESP-IDF"]
        T_PZEM["PZEM-004T v3.0 (AC Energy & Power Metering via UART2)"]
        T_DHT["DHT22 (Digital Temp & Humidity on GPIO 4)"]
        T_Relay["Songle 30A 250VAC Optocoupled Relay (GPIO 26)"]
        T_EStop["Mechanical Emergency Pushbutton (GPIO 34 Hardware ISR)"]
        T_LCD["16x2 I2C Character Display (GPIO 21/22)"]
    end

    L1 --> L3
    L1 --> L4
    L3 --> L4
    L2 --> L4
    L4 --> L5
```

---

## 2. Technology Inventory & Version Matrix

| Layer | Component | Version | Role in EV SMART Architecture |
| :--- | :--- | :--- | :--- |
| **Edge Hardware** | ESP32-WROOM-32 | Rev 1 | 32-bit dual-core microcontroller orchestrating sensors & relay. |
| **Edge OS** | FreeRTOS | Kernel v10.x | Dual-core scheduling: Core 0 (Safety), Core 1 (Network). |
| **Edge Firmware** | C++ / Arduino | C++14 | Sensor sampling, JSON serialization, autonomous thermal trips. |
| **Sensors** | PZEM-004T v3.0 | Hardware v3.0| AC power, RMS voltage, current, power factor, energy meter. |
| **Sensors** | DHT22 (AM2302) | Hardware | Ambient and enclosure temperature/humidity monitoring. |
| **Actuators** | 30A Relay Module | 5V Coil / 30A | Optocoupled AC power switching to EV connector. |
| **Transport** | Eclipse Mosquitto | v2.0.18 | High-throughput, low-overhead MQTT broker (Port 1883). |
| **Transport** | Socket.IO | v4.7.4 | Bidirectional 1Hz real-time event broadcasting to clients. |
| **Backend Core** | Node.js | v20.11.x LTS | Central asynchronous event loop and API orchestration engine. |
| **Backend Framework**| Express.js | v4.18.2 | REST API routing, controller middleware, and error handling. |
| **Database** | MongoDB Server | v7.0.x | Relational-like document store for users, stations, telemetry. |
| **Database ODM** | Mongoose | v8.1.1 | Schema modeling, compound indexing, atomic queries. |
| **AI Runtime** | Python | v3.11.7 | High-performance scientific computing environment. |
| **AI Framework** | FastAPI | v0.109.2 | Asynchronous ASGI web framework for ML inference endpoints. |
| **Machine Learning**| Scikit-learn | v1.4.0 | Random Forest Regressor & Isolation Forest anomaly model. |
| **Frontend Framework**| React | v18.2.0 | Component-based UI for mobile driver app & admin dashboard. |
| **Build Tool** | Vite | v5.1.0 | Ultra-fast frontend bundler (1.10s production build time). |
| **CSS System** | Tailwind CSS | v3.4.1 | Utility-first responsive design system with zero runtime overhead.|
| **Charting Engine** | Recharts | v2.12.0 | SVG charting for live telemetry streams & energy analytics. |
| **Security** | bcryptjs / JWT | v2.4.3 / v9.0.2| Password hashing (10 rounds) and HMAC-SHA256 authorization. |
| **Test Engine** | Supertest / Node | v6.3.4 | Automated integration testing (202 passed assertions). |
