import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  CheckCircle2,
  Navigation,
  Calendar,
  ArrowRight,
  Copy,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const BookingConfirmationScreen = () => {
  const navigate = useNavigate();
  const { bookingId } = useParams();
  const { bookings } = useEV();
  const { showToast } = useUI();

  // Find booking or use default
  const booking =
    bookings.find((b) => b.id === bookingId) || bookings[0] || {
      id: 'EV20260924001',
      stationName: 'Green Valley EV Hub',
      chargerName: 'CH-01',
      date: '24 Sep 2026',
      time: '04:00 PM – 05:00 PM',
      rate: 10,
    };

  const handleCopyId = () => {
    navigator.clipboard?.writeText(booking.id);
    showToast('Booking ID copied to clipboard!', 'success');
  };

  const handleAddToCalendar = () => {
    showToast('Added EV Charging Slot to your Device Calendar', 'success');
  };

  const handleDirections = () => {
    showToast('Navigation started to ' + booking.stationName, 'info');
    navigate('/stations');
  };

  return (
    <div className="flex flex-col min-h-full justify-between p-6 select-none bg-gradient-to-b from-[#060D1E] via-[#070B19] to-[#040711]">
      <div className="space-y-6 pt-4 text-center">
        {/* Animated Success Badge */}
        <div className="relative inline-flex items-center justify-center">
          <div className="absolute -inset-3 rounded-full bg-[#00F5A0]/20 animate-ping opacity-60" />
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#0D2A24] to-[#124B3E] border-2 border-[#00F5A0] flex items-center justify-center shadow-[0_0_30px_rgba(0,245,160,0.4)]">
            <CheckCircle2 className="w-10 h-10 text-[#00F5A0]" />
          </div>
        </div>

        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Booking Confirmed!
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
            Your charger bay has been reserved. Please arrive within 15 minutes of your slot time.
          </p>
        </div>

        {/* Digital Ticket / Summary Card */}
        <Card glow className="bg-[#0D1527] border-white/10 p-5 text-left relative overflow-hidden">
          {/* Subtle Top Notch Visual */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Booking ID
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-sm font-bold font-mono text-[#00F5A0]">
                  {booking.id}
                </span>
                <button
                  onClick={handleCopyId}
                  className="text-slate-400 hover:text-white p-0.5"
                  title="Copy ID"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Confirmed</span>
            </div>
          </div>

          {/* Details Grid */}
          <div className="py-3 space-y-2.5 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Station:</span>
              <span className="font-bold text-white text-right max-w-[200px] truncate">
                {booking.stationName}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Charger Bay:</span>
              <span className="font-bold text-[#00E5FF] font-mono">
                {booking.chargerName || 'CH-01'}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Reserved Date:</span>
              <span className="font-semibold text-white">{booking.date}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Time Slot:</span>
              <span className="font-semibold text-emerald-400 font-mono">
                {booking.time}
              </span>
            </div>
          </div>

          {/* QR Code Placeholder */}
          <div className="mt-2 pt-3 border-t border-dashed border-white/10 flex flex-col items-center justify-center p-3 rounded-xl bg-[#080E1C]">
            {/* High Tech Stylized QR Code SVG */}
            <div className="w-28 h-28 bg-white p-2 rounded-xl shadow-md flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                {/* 3 Position Corners */}
                <rect x="5" y="5" width="26" height="26" fill="#070B19" rx="3" />
                <rect x="9" y="9" width="18" height="18" fill="white" rx="2" />
                <rect x="13" y="13" width="10" height="10" fill="#070B19" />

                <rect x="69" y="5" width="26" height="26" fill="#070B19" rx="3" />
                <rect x="73" y="9" width="18" height="18" fill="white" rx="2" />
                <rect x="77" y="13" width="10" height="10" fill="#070B19" />

                <rect x="5" y="69" width="26" height="26" fill="#070B19" rx="3" />
                <rect x="9" y="73" width="18" height="18" fill="white" rx="2" />
                <rect x="13" y="77" width="10" height="10" fill="#070B19" />

                {/* Simulated Matrix Bits */}
                <rect x="36" y="10" width="6" height="6" fill="#070B19" />
                <rect x="46" y="18" width="6" height="6" fill="#070B19" />
                <rect x="56" y="10" width="6" height="6" fill="#070B19" />
                <rect x="36" y="36" width="12" height="12" fill="#070B19" rx="2" />
                <rect x="52" y="36" width="6" height="6" fill="#070B19" />
                <rect x="62" y="44" width="8" height="8" fill="#070B19" />
                <rect x="36" y="52" width="6" height="6" fill="#070B19" />
                <rect x="46" y="60" width="6" height="6" fill="#070B19" />
                <rect x="68" y="68" width="8" height="8" fill="#070B19" />
                <rect x="80" y="76" width="6" height="6" fill="#070B19" />
                <rect x="40" y="78" width="8" height="8" fill="#070B19" />
              </svg>
            </div>
            <span className="text-[10px] text-slate-400 mt-2 font-mono">
              Scan at station kiosk to unlock charger
            </span>
          </div>
        </Card>
      </div>

      {/* Buttons */}
      <div className="space-y-2.5 pt-6">
        <Button
          size="lg"
          fullWidth
          onClick={handleDirections}
          icon={Navigation}
        >
          Get Directions
        </Button>

        <div className="grid grid-cols-2 gap-2.5">
          <Button
            variant="secondary"
            onClick={() => navigate('/bookings')}
            icon={ArrowRight}
            iconPosition="right"
          >
            View Booking
          </Button>

          <Button
            variant="outline"
            onClick={handleAddToCalendar}
            icon={Calendar}
          >
            Add to Calendar
          </Button>
        </div>
      </div>
    </div>
  );
};
