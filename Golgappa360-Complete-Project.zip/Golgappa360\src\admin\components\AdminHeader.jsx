import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  Zap,
  Menu,
  Bell,
  LogOut,
  ShieldCheck,
  AlertTriangle,
  User,
  Radio,
} from 'lucide-react';

export const AdminHeader = ({
  pageTitle = 'Fleet Management',
  subtitle = '',
  socketStatus = 'connected',
  activeAlerts = [],
  onMenuToggle,
}) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [alertsOpen, setAlertsOpen] = useState(false);

  const isAdmin = user?.role === 'admin';
  const roleName = isAdmin ? 'Super Admin' : 'Fleet Operator';

  const handleLogout = () => {
    logout();
    navigate('/admin/login', { replace: true });
  };

  return (
    <header className="h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 px-4 md:px-8 flex items-center justify-between sticky top-0 z-30 select-none">
      {/* Left: Mobile Menu & Page Titles */}
      <div className="flex items-center gap-3">
        {onMenuToggle && (
          <button
            onClick={onMenuToggle}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Toggle Sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div className="flex items-center gap-2 md:gap-3">
          <div className="hidden lg:flex items-center gap-2 pr-3 border-r border-slate-800">
            <span className="font-extrabold tracking-tight text-white text-sm">EV SMART</span>
            <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ADMIN PANEL
            </span>
          </div>

          <div>
            <h1 className="text-sm md:text-base font-bold text-white tracking-tight leading-tight">
              {pageTitle}
            </h1>
            {subtitle && (
              <p className="text-[11px] text-slate-400 hidden sm:block truncate max-w-md">
                {subtitle}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Right: Actions, Live Indicator, Alerts, Admin Profile & Logout */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Real-time Socket Indicator */}
        <div
          className={`flex items-center gap-2 px-2.5 sm:px-3 py-1 rounded-full border text-xs font-medium ${
            socketStatus === 'connected'
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              : socketStatus === 'reconnecting'
              ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
          }`}
          title={`IoT Telemetry Stream: ${socketStatus}`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              socketStatus === 'connected'
                ? 'bg-emerald-400 animate-pulse'
                : socketStatus === 'reconnecting'
                ? 'bg-amber-400 animate-ping'
                : 'bg-rose-400'
            }`}
          />
          <span className="hidden md:inline font-mono text-[11px]">
            {socketStatus === 'connected' ? 'LIVE IoT STREAM' : socketStatus.toUpperCase()}
          </span>
        </div>

        {/* Notifications / Alerts Popover */}
        <div className="relative">
          <button
            onClick={() => setAlertsOpen(!alertsOpen)}
            className="relative p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800 transition-colors"
            title="System Alerts & Faults"
          >
            <Bell className="w-4 h-4" />
            {activeAlerts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center animate-bounce">
                {activeAlerts.length}
              </span>
            )}
          </button>

          {alertsOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-4 z-50">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Active Alerts ({activeAlerts.length})
                </span>
                <Link
                  to="/admin/alerts"
                  onClick={() => setAlertsOpen(false)}
                  className="text-xs text-emerald-400 hover:underline font-medium"
                >
                  View All
                </Link>
              </div>
              <div className="divide-y divide-slate-800/60 max-h-64 overflow-y-auto">
                {activeAlerts.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">
                    All chargers nominal. Zero active alerts.
                  </p>
                ) : (
                  activeAlerts.slice(0, 4).map((a) => (
                    <div key={a._id} className="py-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-rose-400">{a.chargerId || a.chargerNumber || 'System'}</span>
                        <span className="text-[10px] text-slate-500">{a.type || a.alertType}</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">{a.message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Admin Profile Info */}
        <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-xs font-bold">
            {user?.name ? user.name[0].toUpperCase() : 'A'}
          </div>
          <div className="flex flex-col text-left">
            <span className="text-xs font-semibold text-white leading-tight">
              {user?.name || 'Administrator'}
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 leading-tight">
              {roleName}
            </span>
          </div>
        </div>

        {/* Dedicated Admin Logout */}
        <button
          onClick={handleLogout}
          className="p-2 rounded-xl text-rose-400 hover:text-white hover:bg-rose-500/20 border border-slate-800 hover:border-rose-500/30 transition-all flex items-center gap-1.5 text-xs font-semibold"
          title="Sign Out of Admin Panel"
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden lg:inline">Logout</span>
        </button>
      </div>
    </header>
  );
};

export default AdminHeader;
