/**
 * STELLAR 2.0 — Universal Search Service
 * 
 * Central search index, fuzzy/typo-tolerant matching, scientific alias resolution,
 * category filtering, and search history persistence.
 */

import {
  ALL_SEARCHABLE_OBJECTS,
  CELESTIAL_CATEGORIES,
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
} from '../data/celestialObjects.js';
import { CONSTELLATIONS_DATA } from '../data/constellations.js';
import { SOLAR_SYSTEM_DATA, MOON_DATA } from '../data/solarSystem.js';
import { COSMIC_MILESTONES } from '../data/timelineData.js';

// Local storage key for recent search history
export const RECENT_SEARCHES_STORAGE_KEY = 'stellar_recent_searches';
export const MAX_RECENT_SEARCHES = 6;

// Popular celestial suggestions for the empty search state
export const POPULAR_SUGGESTIONS = [
  { id: 'sirius', name: 'Sirius', category: CELESTIAL_CATEGORIES.STAR, label: 'Brightest Star' },
  { id: 'orion', name: 'Orion', category: CELESTIAL_CATEGORIES.CONSTELLATION, label: 'The Hunter' },
  { id: 'mars', name: 'Mars', category: CELESTIAL_CATEGORIES.PLANET, label: 'The Red Planet' },
  { id: 'jupiter', name: 'Jupiter', category: CELESTIAL_CATEGORIES.PLANET, label: 'Gas Giant King' },
  { id: 'andromeda-galaxy', name: 'Andromeda Galaxy', category: CELESTIAL_CATEGORIES.GALAXY, label: 'Nearest Spiral Galaxy' },
  { id: 'sagittarius-a-star', name: 'Sagittarius A*', category: CELESTIAL_CATEGORIES.BLACK_HOLE, label: 'Milky Way Core BH' },
];

// Search filter categories
export const SEARCH_CATEGORIES = [
  { id: 'ALL', label: 'All' },
  { id: 'STARS', label: 'Stars' },
  { id: 'PLANETS', label: 'Planets' },
  { id: 'CONSTELLATIONS', label: 'Constellations' },
  { id: 'NEBULAE', label: 'Nebulae' },
  { id: 'BLACK_HOLES', label: 'Black Holes' },
  { id: 'GALAXIES', label: 'Galaxies' },
  { id: 'TIMELINE', label: 'Timeline' },
  { id: 'OTHER', label: 'Other' },
];

// Verified scientific and cultural aliases table
export const SCIENTIFIC_ALIASES = {
  'sun': ['sol', 'day star', 'central star', 'yellow dwarf'],
  'moon': ['luna', 'the moon', 'earth moon', 'selene'],
  'mercury': ['swift planet', 'hermes'],
  'venus': ['morning star', 'evening star', 'aphrodite'],
  'earth': ['terra', 'blue marble', 'gaia'],
  'mars': ['red planet', 'ares'],
  'jupiter': ['jove', 'gas giant king', 'zeus'],
  'saturn': ['ringed planet', 'cronus'],
  'uranus': ['cælus', 'ice giant'],
  'neptune': ['poseidon', 'blue giant'],
  'polaris': ['north star', 'pole star', 'lodestar', 'alpha ursae minoris', 'dhruva tara'],
  'sirius': ['dog star', 'alpha canis majoris', 'aschere', 'canis major star'],
  'sirius-b': ['the pup', 'white dwarf companion', 'pup star'],
  'betelgeuse': ['alpha orionis', 'red supergiant', 'orion shoulder', 'betelguese'],
  'rigel': ['beta orionis', 'blue supergiant', 'orion foot'],
  'bellatrix': ['gamma orionis', 'amazon star'],
  'alnitak': ['zeta orionis', 'orion belt'],
  'alnilam': ['epsilon orionis', 'orion belt'],
  'mintaka': ['delta orionis', 'orion belt'],
  'saiph': ['kappa orionis'],
  'aldebaran': ['alpha tauri', 'eye of taurus', 'red giant'],
  'antares': ['alpha scorpii', 'heart of scorpius', 'rival of mars'],
  'vega': ['alpha lyrae', 'harp star'],
  'altair': ['alpha aquilae', 'flying eagle'],
  'deneb': ['alpha cygni', 'cygnus tail', 'summer triangle'],
  'proxima-centauri': ['alpha centauri c', 'closest star', 'red dwarf'],
  'alpha-centauri-a': ['rigil kentaurus'],
  'alpha-centauri-b': ['toliman'],
  'sagittarius-a-star': ['sgr a*', 'sgra*', 'sgr a', 'milky way central black hole', 'supermassive black hole', 'galactic center'],
  'm87-star': ['messier 87', 'virgo a', 'm87', 'event horizon telescope', 'eht black hole', 'first imaged black hole'],
  'cygnus-x1': ['cyg x-1', 'cygx1', 'stellar mass black hole', 'x-ray binary black hole', 'hawking bet'],
  'crab-pulsar': ['psr b0531+21', 'crab nebula pulsar', 'supernova 1054'],
  'vela-pulsar': ['psr b0833-45', 'vela supernova remnant'],
  'pleiades': ['seven sisters', 'm45', 'messier 45', 'subaru', 'open cluster'],
  'andromeda-galaxy': ['m31', 'messier 31', 'ngc 224', 'andromeda spiral'],
  'triangulum-galaxy': ['m33', 'messier 33', 'triangulum spiral'],
  'orion-nebula': ['m42', 'messier 42', 'ngc 1976', 'stellar nursery'],
  'ring-nebula': ['m57', 'messier 57', 'ngc 6720', 'planetary nebula'],
  'crab-nebula': ['m1', 'messier 1', 'ngc 1952'],
  'hercules-cluster': ['m13', 'messier 13', 'great globular cluster in hercules', 'ngc 6205'],
  'orion': ['the hunter', 'hunter constellation'],
  'ursa-major': ['great bear', 'big dipper', 'saptarishi', 'the plough'],
  'canis-major': ['greater dog', 'big dog constellation'],
  'scorpius': ['the scorpion', 'scorpion constellation', 'scorpio'],
  'cassiopeia': ['the celestial queen', 'queen of the heavens', 'w constellation'],
  'leo': ['the lion', 'lion constellation'],
};

/**
 * Normalizes all items from the master datasets into a fast searchable index
 */
export function buildSearchIndex() {
  const index = [];
  const seenIds = new Set();

  for (const obj of ALL_SEARCHABLE_OBJECTS) {
    if (!obj || !obj.id || seenIds.has(obj.id)) continue;
    seenIds.add(obj.id);

    const aliases = SCIENTIFIC_ALIASES[obj.id] || [];
    const normalized = {
      ...obj,
      searchTerms: [
        obj.name.toLowerCase(),
        (obj.commonName || '').toLowerCase(),
        (obj.latinName || '').toLowerCase(),
        (obj.subtype || obj.type || '').toLowerCase(),
        (obj.category || '').toLowerCase(),
        (obj.constellation || obj.relatedConstellation || '').toLowerCase(),
        (obj.spectralClass || '').toLowerCase(),
        ...aliases.map((a) => a.toLowerCase()),
      ].filter(Boolean),
      aliases,
    };
    index.push(normalized);
  }

  // Index Cosmic Timeline Milestones (Phase U13)
  for (const m of COSMIC_MILESTONES) {
    if (!m || !m.id) continue;
    const timelineObj = {
      id: `timeline-${m.id}`,
      milestoneId: m.id,
      name: m.title,
      commonName: m.subtitle,
      category: 'TIMELINE',
      subtype: `Milestone ${m.number} • ${m.timeLabel}`,
      timeLabel: m.timeLabel,
      colorHex: m.accentColor || '#38bdf8',
      isTimeline: true,
      searchTerms: [
        m.title.toLowerCase(),
        m.subtitle.toLowerCase(),
        'timeline',
        'cosmic timeline',
        m.timeLabel.toLowerCase(),
        m.era.toLowerCase(),
        m.eraLabel.toLowerCase(),
      ],
      aliases: ['timeline', 'cosmic history', m.timeLabel],
    };
    index.push(timelineObj);
  }

  return index;
}

// Cached singleton index
let cachedSearchIndex = null;
export function getSearchIndex() {
  if (!cachedSearchIndex) {
    cachedSearchIndex = buildSearchIndex();
  }
  return cachedSearchIndex;
}

/**
 * Fast Levenshtein distance for typo tolerance
 */
export function levenshteinDistance(s1, s2) {
  if (s1 === s2) return 0;
  if (!s1.length) return s2.length;
  if (!s2.length) return s1.length;

  const row = [];
  for (let i = 0; i <= s2.length; i++) row[i] = i;

  for (let i = 1; i <= s1.length; i++) {
    let prev = i;
    for (let j = 1; j <= s2.length; j++) {
      let val;
      if (s1[i - 1] === s2[j - 1]) {
        val = row[j - 1];
      } else {
        val = Math.min(row[j - 1] + 1, prev + 1, row[j] + 1);
      }
      row[j - 1] = prev;
      prev = val;
    }
    row[s2.length] = prev;
  }
  return row[s2.length];
}

/**
 * Category filter helper
 */
export function matchesCategoryFilter(item, filterCategory) {
  if (!filterCategory || filterCategory === 'ALL') return true;

  const cat = item.category;
  switch (filterCategory) {
    case 'STARS':
      return cat === CELESTIAL_CATEGORIES.STAR;
    case 'PLANETS':
      return cat === CELESTIAL_CATEGORIES.PLANET || cat === CELESTIAL_CATEGORIES.NATURAL_SATELLITE || item.isSun;
    case 'CONSTELLATIONS':
      return cat === CELESTIAL_CATEGORIES.CONSTELLATION || item.isConstellation;
    case 'NEBULAE':
      return cat === CELESTIAL_CATEGORIES.NEBULA;
    case 'BLACK_HOLES':
      return cat === CELESTIAL_CATEGORIES.BLACK_HOLE;
    case 'GALAXIES':
      return cat === CELESTIAL_CATEGORIES.GALAXY;
    case 'TIMELINE':
      return item.isTimeline || cat === 'TIMELINE' || cat === CELESTIAL_CATEGORIES.TIMELINE;
    case 'OTHER':
      return (
        cat === CELESTIAL_CATEGORIES.WHITE_DWARF ||
        cat === CELESTIAL_CATEGORIES.NEUTRON_STAR ||
        cat === CELESTIAL_CATEGORIES.PULSAR ||
        cat === CELESTIAL_CATEGORIES.STAR_CLUSTER
      );
    default:
      return true;
  }
}

/**
 * Universal search function with fuzzy matching, typo tolerance, alias resolution,
 * and category filtering.
 * 
 * @param {string} rawQuery
 * @param {string} filterCategory - 'ALL' | 'STARS' | 'PLANETS' | etc.
 * @param {number} maxResults
 * @returns {Array} Matched items sorted by relevance score
 */
export function searchCelestialObjects(rawQuery = '', filterCategory = 'ALL', maxResults = 12) {
  const query = (rawQuery || '').trim().toLowerCase();
  const index = getSearchIndex();

  if (!query) return [];

  const results = [];

  for (const item of index) {
    if (!matchesCategoryFilter(item, filterCategory)) continue;

    const nameLower = item.name.toLowerCase();
    const commonLower = (item.commonName || '').toLowerCase();
    const latinLower = (item.latinName || '').toLowerCase();
    let score = 0;

    // 1. Exact name match (Highest priority)
    if (nameLower === query) {
      score += 100;
    }
    // 2. Name starts with query
    else if (nameLower.startsWith(query)) {
      score += 70;
    }
    // 3. Name contains query
    else if (nameLower.includes(query)) {
      score += 50;
    }
    // 4. Common or Latin name exact / starts with
    else if (commonLower.startsWith(query) || latinLower.startsWith(query)) {
      score += 45;
    }
    else if (commonLower.includes(query) || latinLower.includes(query)) {
      score += 35;
    }

    // 5. Check aliases
    for (const alias of item.aliases || []) {
      const aliasLower = alias.toLowerCase();
      if (aliasLower === query) {
        score += 80;
        break;
      } else if (aliasLower.startsWith(query)) {
        score += 40;
        break;
      } else if (aliasLower.includes(query)) {
        score += 30;
        break;
      }
    }

    // 6. Check constellation or subtype
    const constellationLower = (item.constellation || item.relatedConstellation || '').toLowerCase();
    const subtypeLower = (item.subtype || item.type || '').toLowerCase();
    if (constellationLower.includes(query)) {
      score += 25;
    }
    if (subtypeLower.includes(query)) {
      score += 20;
    }

    // 7. Typo tolerance (Levenshtein) if query length >= 3 and no match found yet
    if (score === 0 && query.length >= 3) {
      // Compare query with name and word tokens
      const nameWords = nameLower.split(/\s+/);
      let bestDist = 999;

      for (const word of nameWords) {
        const d = levenshteinDistance(query, word);
        if (d < bestDist) bestDist = d;
      }

      // Also compare with aliases
      for (const alias of item.aliases || []) {
        for (const word of alias.toLowerCase().split(/\s+/)) {
          const d = levenshteinDistance(query, word);
          if (d < bestDist) bestDist = d;
        }
      }

      // Threshold: length 3-5 allows distance 1; length >= 6 allows distance 2
      const maxAllowed = query.length >= 6 ? 2 : 1;
      if (bestDist <= maxAllowed) {
        score += (maxAllowed - bestDist + 1) * 15;
      }
    }

    if (score > 0) {
      results.push({ item, score });
    }
  }

  // Sort results descending by score
  results.sort((a, b) => b.score - a.score);

  return results.slice(0, maxResults).map((r) => r.item);
}

/**
 * Groups search results by overarching category
 */
export function groupSearchResults(results = []) {
  const groups = {
    STARS: [],
    PLANETS: [],
    CONSTELLATIONS: [],
    BLACK_HOLES: [],
    DEEP_SKY: [],
  };

  for (const item of results) {
    if (item.category === CELESTIAL_CATEGORIES.STAR) {
      groups.STARS.push(item);
    } else if (
      item.category === CELESTIAL_CATEGORIES.PLANET ||
      item.category === CELESTIAL_CATEGORIES.NATURAL_SATELLITE ||
      item.isSun
    ) {
      groups.PLANETS.push(item);
    } else if (item.isConstellation || item.category === CELESTIAL_CATEGORIES.CONSTELLATION) {
      groups.CONSTELLATIONS.push(item);
    } else if (item.category === CELESTIAL_CATEGORIES.BLACK_HOLE) {
      groups.BLACK_HOLES.push(item);
    } else {
      groups.DEEP_SKY.push(item);
    }
  }

  return groups;
}

// ==========================================
// SEARCH HISTORY (localStorage)
// ==========================================

export function getRecentSearches() {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(RECENT_SEARCHES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn('Failed to parse stellar_recent_searches from localStorage', err);
    return [];
  }
}

export function addRecentSearch(item) {
  if (!item || !item.id || typeof window === 'undefined') return;
  try {
    const current = getRecentSearches();
    // Remove if already exists
    const filtered = current.filter((r) => r.id !== item.id);
    const compactItem = {
      id: item.id,
      name: item.name,
      commonName: item.commonName || item.latinName || '',
      category: item.category,
      subtype: item.subtype || item.type || '',
      colorHex: item.colorHex || '#38bdf8',
      isConstellation: !!item.isConstellation,
      isSun: !!item.isSun,
    };
    const updated = [compactItem, ...filtered].slice(0, MAX_RECENT_SEARCHES);
    localStorage.setItem(RECENT_SEARCHES_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to save stellar_recent_searches to localStorage', err);
  }
}

export function clearRecentSearches() {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(RECENT_SEARCHES_STORAGE_KEY);
  } catch (err) {
    console.warn('Failed to clear stellar_recent_searches from localStorage', err);
  }
}

export function removeRecentSearch(id) {
  if (!id || typeof window === 'undefined') return;
  try {
    const current = getRecentSearches();
    const updated = current.filter((r) => r.id !== id);
    localStorage.setItem(RECENT_SEARCHES_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to remove item from stellar_recent_searches', err);
  }
}

/**
 * Universal Navigation Dispatcher
 * Dispatches navigation requests consistently to Universe Map and page sections
 */
export function dispatchCelestialNavigation(obj) {
  if (!obj || typeof window === 'undefined') return;

  // Add to recent searches
  addRecentSearch(obj);

  // If this is a timeline milestone item
  if (obj.isTimeline || obj.category === 'TIMELINE' || obj.category === CELESTIAL_CATEGORIES.TIMELINE) {
    const milestoneId = obj.milestoneId || (obj.id ? obj.id.replace('timeline-', '') : 'big-bang');
    try {
      window.location.hash = `timeline=${milestoneId}`;
    } catch {}

    const timelineElem = document.getElementById('timeline');
    if (timelineElem) {
      timelineElem.scrollIntoView({ behavior: 'smooth' });
    }

    window.dispatchEvent(
      new CustomEvent('stellar:open-timeline', {
        detail: milestoneId,
      })
    );
    return;
  }

  // Update URL hash for deep linking (without causing reload)
  try {
    const hash = obj.isConstellation ? `#constellation=${obj.id}` : `#object=${obj.id}`;
    if (window.history && window.history.replaceState) {
      window.history.replaceState(null, '', hash);
    }
  } catch {
    // Ignore history state issues in non-standard environments
  }

  // Smooth scroll to universe map if needed
  const mapElem = document.getElementById('universe-map');
  if (mapElem) {
    mapElem.scrollIntoView({ behavior: 'smooth' });
  }

  // Dispatch custom event for UniverseMap
  if (obj.isConstellation || obj.category === CELESTIAL_CATEGORIES.CONSTELLATION) {
    window.dispatchEvent(
      new CustomEvent('stellar:locate-constellation', {
        detail: obj,
      })
    );
  } else {
    window.dispatchEvent(
      new CustomEvent('stellar:locate-object', {
        detail: obj,
      })
    );
  }
}
