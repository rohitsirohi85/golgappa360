/**
 * STELLAR 2.0 — Celestial Map Coordinates & Atlas Mapping Layer
 * 
 * Maps the 31 stars from STARS_DATA to logical 2D world coordinates
 * on the interactive celestial map, preserving constellation shapes,
 * relative neighbor relationships, and level-of-detail tiers.
 * 
 * DISCLAIMER: Illustrative educational visualization — not to scale.
 */

import { STARS_DATA } from '../data/stars.js';

// Tier 1: Primary Navigational Beacons (Visible at all zoom levels)
// Tier 2: Major Constellation Anchor Stars (Visible at medium zoom)
// Tier 3: Secondary & Companion Stars (Visible at high zoom)
export const STAR_COORDINATES = {
  // Solar System Origin
  'sun': { x: 0, y: 0, tier: 1, baseRadius: 7, hasDiffraction: true },

  // Centaurus (Nearest Stellar Neighbors)
  'proxima-centauri': { x: 80, y: 70, tier: 2, baseRadius: 3.5, hasDiffraction: false },

  // Canis Major (Southeast of Orion)
  'sirius': { x: 170, y: 220, tier: 1, baseRadius: 7.5, hasDiffraction: true },
  'sirius-b': { x: 188, y: 232, tier: 3, baseRadius: 2.8, hasDiffraction: false },
  'adhara': { x: 215, y: 310, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'wezen': { x: 250, y: 360, tier: 2, baseRadius: 4.5, hasDiffraction: false },

  // Orion (Equatorial Winter Masterpiece)
  'betelgeuse': { x: -390, y: 220, tier: 1, baseRadius: 7.2, hasDiffraction: true },
  'bellatrix': { x: -270, y: 230, tier: 2, baseRadius: 5.2, hasDiffraction: false },
  'mintaka': { x: -290, y: 300, tier: 2, baseRadius: 4.6, hasDiffraction: false },
  'alnilam': { x: -330, y: 310, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'alnitak': { x: -370, y: 320, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'saiph': { x: -390, y: 400, tier: 2, baseRadius: 4.6, hasDiffraction: false },
  'rigel': { x: -270, y: 390, tier: 1, baseRadius: 7.0, hasDiffraction: true },

  // Taurus (Northwest of Orion)
  'aldebaran': { x: -470, y: 150, tier: 1, baseRadius: 6.2, hasDiffraction: true },

  // Ursa Minor (Celestial North)
  'polaris': { x: 0, y: -480, tier: 1, baseRadius: 6.5, hasDiffraction: true },

  // Ursa Major (The Big Dipper Asterism)
  'dubhe': { x: -250, y: -420, tier: 2, baseRadius: 5.0, hasDiffraction: false },
  'merak': { x: -260, y: -340, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'alioth': { x: -160, y: -320, tier: 2, baseRadius: 5.2, hasDiffraction: false },
  'mizar': { x: -100, y: -340, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'alkaid': { x: -40, y: -370, tier: 2, baseRadius: 5.0, hasDiffraction: false },

  // Cassiopeia (The Northern 'W')
  'caph': { x: 200, y: -490, tier: 2, baseRadius: 4.8, hasDiffraction: false },
  'schedar': { x: 260, y: -450, tier: 2, baseRadius: 5.2, hasDiffraction: false },
  'gamma-cas': { x: 320, y: -470, tier: 2, baseRadius: 5.0, hasDiffraction: false },

  // Boötes (Follow the Arc to Arcturus)
  'arcturus': { x: -140, y: -140, tier: 1, baseRadius: 6.8, hasDiffraction: true },

  // Virgo (Speed on to Spica)
  'spica': { x: -210, y: 40, tier: 1, baseRadius: 5.8, hasDiffraction: true },

  // Leo (Spring Sky)
  'regulus': { x: -430, y: -70, tier: 2, baseRadius: 5.5, hasDiffraction: false },
  'denebola': { x: -340, y: -130, tier: 2, baseRadius: 4.6, hasDiffraction: false },

  // Scorpius (Southern Summer Sky)
  'antares': { x: 360, y: 170, tier: 1, baseRadius: 7.0, hasDiffraction: true },
  'shaula': { x: 450, y: 240, tier: 2, baseRadius: 4.8, hasDiffraction: false },

  // Cygnus & Lyra (Summer Triangle Navigators)
  'deneb': { x: 350, y: -330, tier: 1, baseRadius: 6.2, hasDiffraction: true },
  'vega': { x: 250, y: -260, tier: 1, baseRadius: 7.0, hasDiffraction: true },
};

/**
 * Enriched star list combining original STARS_DATA with celestial coordinates.
 */
export const MAP_STARS = STARS_DATA.map((star) => {
  const coord = STAR_COORDINATES[star.id] || {
    x: (Math.random() - 0.5) * 600,
    y: (Math.random() - 0.5) * 600,
    tier: 2,
    baseRadius: 4.5,
    hasDiffraction: false,
  };

  return {
    ...star,
    ...coord,
  };
});

/**
 * Constellation line patterns connecting mapped stars.
 */
export const CONSTELLATION_LINES = [
  // Orion
  { id: 'orion-1', from: 'betelgeuse', to: 'bellatrix', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-2', from: 'betelgeuse', to: 'alnitak', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-3', from: 'bellatrix', to: 'mintaka', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-4', from: 'mintaka', to: 'alnilam', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-5', from: 'alnilam', to: 'alnitak', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-6', from: 'alnitak', to: 'saiph', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-7', from: 'mintaka', to: 'rigel', constellation: 'Orion', constellationId: 'orion' },
  { id: 'orion-8', from: 'saiph', to: 'rigel', constellation: 'Orion', constellationId: 'orion' },

  // Ursa Major (Big Dipper)
  { id: 'uma-1', from: 'dubhe', to: 'merak', constellation: 'Ursa Major', constellationId: 'ursa-major' },
  { id: 'uma-2', from: 'merak', to: 'alioth', constellation: 'Ursa Major', constellationId: 'ursa-major' },
  { id: 'uma-3', from: 'alioth', to: 'mizar', constellation: 'Ursa Major', constellationId: 'ursa-major' },
  { id: 'uma-4', from: 'mizar', to: 'alkaid', constellation: 'Ursa Major', constellationId: 'ursa-major' },
  { id: 'uma-5', from: 'dubhe', to: 'alioth', constellation: 'Ursa Major', constellationId: 'ursa-major' },

  // Cassiopeia
  { id: 'cas-1', from: 'caph', to: 'schedar', constellation: 'Cassiopeia', constellationId: 'cassiopeia' },
  { id: 'cas-2', from: 'schedar', to: 'gamma-cas', constellation: 'Cassiopeia', constellationId: 'cassiopeia' },

  // Canis Major
  { id: 'cma-1', from: 'sirius', to: 'adhara', constellation: 'Canis Major', constellationId: 'canis-major' },
  { id: 'cma-2', from: 'adhara', to: 'wezen', constellation: 'Canis Major', constellationId: 'canis-major' },
  { id: 'cma-3', from: 'sirius', to: 'sirius-b', constellation: 'Canis Major', constellationId: 'canis-major', isFaintHint: true },

  // Leo
  { id: 'leo-1', from: 'regulus', to: 'denebola', constellation: 'Leo', constellationId: 'leo' },

  // Scorpius
  { id: 'sco-1', from: 'antares', to: 'shaula', constellation: 'Scorpius', constellationId: 'scorpius' },

  // Summer Triangle navigation hint
  { id: 'summer-1', from: 'vega', to: 'deneb', constellation: 'Summer Triangle', constellationId: 'summer-triangle', isFaintHint: true },

  // Pointer stars hint: Merak -> Dubhe pointing toward Polaris
  { id: 'pointer-1', from: 'dubhe', to: 'polaris', constellation: 'Polar Alignment', constellationId: 'polar-alignment', isFaintHint: true },
];

/**
 * Constellation watermark labels and navigational bounds centered over each stellar group.
 */
export const CONSTELLATION_REGIONS = [
  { id: 'orion', name: 'ORION', label: 'Orion', x: -330, y: 310, zoomMin: 1.1, framingZoom: 1.45, radius: 190 },
  { id: 'ursa-major', name: 'URSA MAJOR', label: 'Ursa Major', x: -160, y: -360, zoomMin: 1.1, framingZoom: 1.4, radius: 210 },
  { id: 'cassiopeia', name: 'CASSIOPEIA', label: 'Cassiopeia', x: 260, y: -470, zoomMin: 1.1, framingZoom: 1.6, radius: 160 },
  { id: 'canis-major', name: 'CANIS MAJOR', label: 'Canis Major', x: 210, y: 290, zoomMin: 1.1, framingZoom: 1.5, radius: 170 },
  { id: 'scorpius', name: 'SCORPIUS', label: 'Scorpius', x: 400, y: 200, zoomMin: 1.1, framingZoom: 1.55, radius: 170 },
  { id: 'leo', name: 'LEO', label: 'Leo', x: -385, y: -100, zoomMin: 1.1, framingZoom: 1.6, radius: 160 },
  { id: 'solar-system', name: 'SOLAR SYSTEM', label: 'Solar System', x: 0, y: 35, zoomMin: 1.3, framingZoom: 1.8, radius: 100 },
  { id: 'summer-triangle', name: 'SUMMER TRIANGLE', label: 'Summer Triangle', x: 300, y: -300, zoomMin: 1.2, framingZoom: 1.4, radius: 200 },
];

/**
 * Ambient deep-space nebula clouds that provide rich cinematic depth and parallax.
 */
export const NEBULA_REGIONS = [
  { x: -350, y: 330, radius: 260, color: 'rgba(56, 189, 248, 0.055)' }, // Orion Nebula complex
  { x: 390, y: 190, radius: 220, color: 'rgba(239, 68, 68, 0.045)' },  // Antares / Scorpius cloud
  { x: 280, y: -300, radius: 240, color: 'rgba(99, 102, 241, 0.05)' }, // Cygnus / Lyra milky way rift
  { x: -200, y: -370, radius: 230, color: 'rgba(168, 85, 247, 0.04)' }, // Northern galactic haze
];

/**
 * Deterministic background micro-stars for deep-space parallax.
 */
const SEED = 42;
function pseudoRandom(s) {
  const x = Math.sin(s) * 10000;
  return x - Math.floor(x);
}

export const BACKGROUND_STARS = Array.from({ length: 320 }, (_, i) => {
  const r1 = pseudoRandom(SEED + i * 5);
  const r2 = pseudoRandom(SEED + i * 5 + 1);
  const r3 = pseudoRandom(SEED + i * 5 + 2);
  const r4 = pseudoRandom(SEED + i * 5 + 3);

  return {
    x: (r1 - 0.5) * 2400,
    y: (r2 - 0.5) * 2000,
    radius: 0.6 + r3 * 1.4,
    baseAlpha: 0.2 + r4 * 0.5,
    twinkleSpeed: 0.002 + r3 * 0.003,
    phase: r1 * Math.PI * 2,
  };
});
