import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Zap,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ChevronRight,
  BatteryCharging,
  Sparkles,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { StatusBadge } from '../components/common/StatusBadge';
import { useEV } from '../context/EVContext';
import { useAuth } from '../context/AuthContext';

export const ChargerSelectionScreen = () => {
  const navigate = useNavigate();
  const { stationId, chargerId } = useParams();
  const { stations, selectedStation, selectedCharger, setSelectedCharger } = useEV();
  const { vehicle } = useAuth();

  const station = stations.find((s) => s.id === stationId) || selectedStation || stations[0];
  const charger =
    station.chargers?.find((c) => c.id === chargerId) || selectedCharger || station.chargers[0];

  const handleContinue = () => {
    setSelectedCharger(charger);
    navigate(`/slot-booking/${station.id}/${charger.id}`);
  };

  return (
    <div className="flex flex-col min-h-full justify-between pb-6 select-none">
      <div>
        <Header title="Charger Specifications" showBack onBack={() => navigate(-1)} />

        <div className="px-4 py-4 space-y-4">
          {/* Station Context pill */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0D1527] border border-white/5 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase tracking-wide">
                Target Station
              </span>
              <span className="font-bold text-white text-sm">{station.name}</span>
            </div>
            <span className="text-slate-400 font-mono">{station.distance}</span>
          </div>

          {/* Hero Charger Card */}
          <Card glow className="bg-gradient-to-br from-[#121E36] to-[#0A1224] p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-[#00F5A0]/15 border border-[#00F5A0]/40 text-[#00F5A0] shadow-[0_0_15px_rgba(0,245,160,0.25)]">
                  <Zap className="w-6 h-6 fill-[#00F5A0]" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    {charger.name}
                  </h2>
                  <span className="text-xs text-slate-400">{charger.type}</span>
                </div>
              </div>

              <StatusBadge status={charger.status} />
            </div>

            {/* Detailed Spec List */}
            <div className="space-y-3 pt-3 border-t border-white/10">
              <div className="flex items-center justify-between text-sm py-1">
                <span className="text-slate-400 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#00F5A0]" />
                  <span>Power Output</span>
                </span>
                <span className="font-bold text-white font-mono text-base">
                  {charger.power}
                </span>
              </div>

              <div className="flex items-center justify-between text-sm py-1 border-t border-white/5">
                <span className="text-slate-400 flex items-center gap-2">
                  <BatteryCharging className="w-4 h-4 text-[#00E5FF]" />
                  <span>Connector Type</span>
                </span>
                <span className="font-bold text-white font-mono">
                  {charger.connector} (Fast DC)
                </span>
              </div>

              <div className="flex items-center justify-between text-sm py-1 border-t border-white/5">
                <span className="text-slate-400 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Energy Tariff</span>
                </span>
                <span className="font-bold text-[#00F5A0] font-mono text-base">
                  ₹{charger.rate}/kWh
                </span>
              </div>

              <div className="flex items-center justify-between text-sm py-1 border-t border-white/5">
                <span className="text-slate-400 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Estimated Charging Time</span>
                </span>
                <span className="font-bold text-amber-300 font-mono">
                  {charger.estimatedTime || '35–45 min'}
                </span>
              </div>
            </div>
          </Card>

          {/* Vehicle Compatibility Banner */}
          <div className="p-4 rounded-2xl bg-[#0D1527] border border-white/10 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#00F5A0] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-white">
                Compatible with {vehicle?.make} {vehicle?.model}
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Your vehicle supports {vehicle?.connector} protocol. Estimated top-up from 20% to 80% takes approx. 38 minutes at {charger.power}.
              </p>
            </div>
          </div>

          {/* AI Charger Recommendation Badge (Section 19) */}
          <div className="p-3.5 rounded-2xl bg-purple-950/20 border border-purple-500/30 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-white">AI Optimal Charger Recommendation</h4>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">
                  Recommended
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Selected for optimal power throughput ({charger.power}), low thermal stress profile, and direct {charger.connector} standard match with your vehicle.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-4 pt-2">
        <Button
          size="lg"
          fullWidth
          onClick={handleContinue}
          icon={ChevronRight}
          iconPosition="right"
        >
          Continue to Booking
        </Button>
      </div>
    </div>
  );
};
