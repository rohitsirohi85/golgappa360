import dotenv from 'dotenv';
import app from './app.js';
import { initDbPool } from './config/db.js';

dotenv.config();

const PORT = process.env.PORT || 5000;

async function startServer() {
  await initDbPool();
  app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`  Golgappa360 Backend API (Phase 3) is live on port ${PORT}`);
    console.log(`  Health Endpoint: http://localhost:${PORT}/api/health`);
    console.log(`=======================================================`);
  });
}

startServer();
