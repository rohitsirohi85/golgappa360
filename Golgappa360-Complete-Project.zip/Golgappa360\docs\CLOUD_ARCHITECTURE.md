# EV SMART — Cloud Architecture & Production Infrastructure

**Document Version:** `1.0.0-RC1`  
**Target Environment:** Production Cloud Infrastructure (AWS / GCP / DigitalOcean / MongoDB Atlas)  
**Classification:** Technical Architecture Specification  

---

## 1. Executive Summary

The **EV SMART** system is engineered as an enterprise-grade, distributed IoT and AI-driven electric vehicle charging network platform. This document outlines the target cloud deployment topology, network security zones, high availability provisions, microservice decoupling, and real-time streaming pipelines.

![Cloud Deployment Diagram](diagrams/CLOUD_DEPLOYMENT.png)

![Final Cloud Architecture](diagrams/FINAL_CLOUD_ARCHITECTURE.png)

```
                              INTERNET (Public Users & Devices)
                                             │
                       ┌─────────────────────┴─────────────────────┐
                       │                                           │
                       ▼                                           ▼
             📱 iPhone Client (PWA/Expo)               💻 Admin Web Dashboard
             [https://app.evsmart.com]                [https://admin.evsmart.com]
                       │                                           │
                       └─────────────────────┬─────────────────────┘
                                             │ HTTPS / WSS
                                             ▼
                             ┌───────────────────────────────┐
                             │   Cloudflare / Edge CDN       │
                             │  - DDoS Protection & WAF      │
                             │  - SSL/TLS 1.3 Termination    │
                             │  - Rate Limiting (Edge-tier)  │
                             └───────────────┬───────────────┘
                                             │ HTTPS / WSS
                                             ▼
                             ┌───────────────────────────────┐
                             │     Nginx Ingress / ALB       │
                             │  - Reverse Proxy              │
                             │  - Sticky Sessions (SocketIO) │
                             │  - Path Routing (/api, /sock) │
                             └───────────────┬───────────────┘
                                             │
                 ┌───────────────────────────┴───────────────────────────┐
                 │ Private Virtual Cloud Network (VPC)                   │
                 │                                                       │
                 ▼                                                       ▼
  ┌─────────────────────────────┐                         ┌─────────────────────────────┐
  │   Node.js Backend Fleet     │    HTTP Internal RPC    │   Python AI/ML Service      │
  │   (Express + Socket.IO)     │ ◄─────────────────────► │   (FastAPI + Scikit-Learn)  │
  │   Ports: 5000 (Internal)    │     Port: 8000 (VPC)    │   Demand, Anomaly, Health   │
  └──────────────┬──────────────┘                         └─────────────────────────────┘
                 │
         ┌───────┴───────────────────────┬───────────────────────────────┐
         ▼                               ▼                               ▼
┌──────────────────────────────┐ ┌──────────────────────────────┐ ┌──────────────────────────────┐
│  MongoDB Atlas Replica Set   │ │ Cloud MQTT Broker (TLS 8883) │ │ External Cloud Gateways      │
│  - Multi-AZ High Availability│ │ (HiveMQ / EMQX Cloud)        │ │ - Razorpay / Stripe (Billing)│
│  - Automatic Failover        │ │ - Mutual TLS / X.509 Auth    │ │ - SendGrid / Twilio (Notif)  │
│  - Automated Point-in-Time   │ │ - QOS 1 Guaranteed Delivery  │ │ - OpenStreetMap / Tile Server│
│  - Encrypted at Rest & Transit│ │ - Real-Time Telemetry Stream │ │                              │
└──────────────────────────────┘ └──────────────┬───────────────┘ └──────────────────────────────┘
                                                ▲
                                                │ MQTTS / TLS
                                                │
                                    ┌───────────┴───────────┐
                                    │ IoT ESP32 Fleet       │
                                    │ Hardware Charging Hubs│
                                    └───────────────────────┘
```

---

## 2. Infrastructure Tiers & Security Zones

The architecture separates concerns across three isolated network tiers:

### 2.1 Edge & Public Perimeter (Zone 1)
- **Cloudflare Edge Network:** Manages DNS, provides Anycast DDoS protection, handles TLS 1.3 termination, and enforces edge rate limiting.
- **SSL/TLS Certificates:** Let's Encrypt / Cloudflare Universal SSL with strict HSTS, TLS 1.2 minimum, modern cipher suites.
- **CORS Policies:** Configured via `CORS_ORIGIN` to accept only authorized origins (`https://app.evsmart.com`, `https://admin.evsmart.com`) while rejecting unauthorized web clients.

### 2.2 Application DMZ & Load Balancing (Zone 2)
- **Ingress Controller / Nginx Reverse Proxy:**
  - Routes traffic by hostname and path (`/api/*` to Node.js backend, `/` to static frontend storage).
  - Handles WebSocket upgrades (`Upgrade: websocket`) with 60-second keep-alive timeouts.
  - Rate limiting buffers (100 req/sec peak burst per IP).
- **Application Containers:**
  - `evsmart-backend`: Containerized Node.js 20 LTS runtime orchestrated via Docker Compose or Kubernetes Deployments (minimum 2 replicas for zero-downtime rolling updates).
  - `evsmart-ml`: Containerized Python 3.11 FastAPI microservice running Uvicorn workers.

### 2.3 Private Persistence & IoT Ingestion (Zone 3 - Private VPC)
- **MongoDB Atlas Cluster:**
  - Dedicated M10+ replica set across 3 Availability Zones (AZ).
  - IP Access Whitelist restricted strictly to VPC NAT Gateway Elastic IPs.
  - Encryption at rest (AES-256) and TLS transit enforcement (`ssl=true`).
- **Cloud MQTT Broker (MQTTS Port 8883):**
  - HiveMQ Cloud or EMQX Cloud managed cluster.
  - Clients (ESP32 microcontrollers and backend gateway) authenticate using token credentials and TLS client verification.
  - Topics segregated by charger ID (`chargers/+/status`, `chargers/+/telemetry`, `chargers/+/commands`).

---

## 3. Microservice Specifications

| Microservice | Technology | Port (Internal) | Responsibilities | Resiliency Strategy |
| :--- | :--- | :--- | :--- | :--- |
| **API Core Gateway** | Node.js / Express | `5000` | REST API, Auth (JWT), Bookings, Sessions, Invoicing, Real-Time Socket.IO | PM2 Cluster / Docker Autoscaling, Health probes |
| **AI / ML Service** | Python / FastAPI | `8000` | Demand forecasting, Anomaly detection, Predictive maintenance scoring | Circuit Breaker: Backend falls back to heuristic baseline if offline |
| **IoT Bridge** | Node.js MQTT Worker | `N/A` (Internal) | Subscribes to MQTTS broker, decodes sensor frames, triggers DB persistence & Socket.IO broadcasts | Automatic reconnection with exponential backoff |
| **Offline Watchdog** | Node.js Cron Timer | `N/A` (In-process) | Polls heartbeat timestamps every 10s; flags chargers inactive after 30s | Memory-efficient single timer loop |

---

## 4. Real-Time Telemetry Pipeline

```mermaid
sequenceDiagram
    autonumber
    participant ESP32 as ESP32 Hardware
    participant Broker as Cloud MQTT Broker (TLS 8883)
    participant Backend as Node.js Core Backend
    participant Atlas as MongoDB Atlas
    participant Client as iPhone & Admin Web (Socket.IO)

    ESP32->>Broker: MQTTS PUBLISH chargers/CH-01/telemetry (V, I, P, E, Temp)
    Broker->>Backend: Ingest Telemetry Payload
    Backend->>Backend: Validate Schema & Physics Bounds
    par Persistent Storage
        Backend->>Atlas: Update Charger State & Log Sensor Reading
    and Real-Time Streaming
        Backend->>Client: Socket.IO emit "charger:telemetry" (CH-01)
    end
    Client-->>Client: Update Live Gauges (kW, kWh, SoC, Temp)
```

---

## 5. High Availability, Failover & Scalability

1. **Stateful WebSocket Handling:** Nginx ingress uses IP-hash or cookie-based sticky sessions for WebSocket connections, ensuring Socket.IO handshakes stay pinned to the correct worker instance.
2. **Database Failover:** MongoDB Atlas provides automated leader election with failover times typically `< 3` seconds. The Node.js Mongoose connection pool automatically recovers without requiring service restart.
3. **AI Microservice Decoupling:** The Node.js backend communicates with the Python ML microservice over an asynchronous HTTP circuit-breaker client (`mlClient.js`). If the ML microservice experiences latency or becomes unreachable, the backend gracefully falls back to mathematical heuristic baselines without disrupting active user sessions or billing operations.
4. **Zero-Downtime Deployment:** Utilizes rolling blue/green deployments where new containers must pass the `/api/health` readiness probe before traffic is switched.

---

## 6. Disaster Recovery & Backup Plan

- **Database Snapshots:** MongoDB Atlas continuous cloud backups with 1-minute RPO (Recovery Point Objective) and 35-day point-in-time recovery.
- **Configuration as Code:** All infrastructure configurations (Docker Compose, Nginx conf, environment templates) are versioned in Git without hardcoded secrets.
- **Monitoring & Pager Escalation:** Integrated with health probes at `/api/health` checking database, memory, and service dependencies.
