export const DEFAULT_USER = {
  id: 'usr_01',
  name: 'Suman',
  email: 'suman@example.com',
  phone: '+91 98765 43210',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&h=200&q=80',
  memberSince: 'January 2025',
  totalChargingSessions: 24,
  totalEnergyConsumed: '348.6 kWh',
  co2Saved: '142 kg',
};
