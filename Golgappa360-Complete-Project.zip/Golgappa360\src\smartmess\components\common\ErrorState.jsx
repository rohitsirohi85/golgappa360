import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export const ErrorState = ({
  title = 'Failed to Load Analytics Stream',
  message = 'A temporary error occurred while querying the mess telemetry service. Check your connection or restart the local service.',
  onRetry,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-10 text-center rounded-xl bg-[#FEF2F2] border border-[#FECACA] shadow-xs">
      <div className="p-3.5 rounded-full bg-white text-[#DC2626] border border-[#FECACA] mb-4 shadow-xs">
        <AlertTriangle className="w-6 h-6" />
      </div>
      <h3 className="text-base font-semibold text-[#991B1B] tracking-tight">
        {title}
      </h3>
      <p className="mt-1 text-xs text-[#B91C1C] max-w-md font-mono">
        {message}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-5 inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium bg-[#DC2626] text-white hover:bg-[#B91C1C] transition-colors cursor-pointer shadow-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Retry Connection
        </button>
      )}
    </div>
  );
};
