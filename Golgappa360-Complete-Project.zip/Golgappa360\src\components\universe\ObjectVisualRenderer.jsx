import React from 'react';
import StarVisual from '../StarVisual';
import { CELESTIAL_CATEGORIES } from '../../data/celestialObjects.js';

/**
 * ObjectVisualRenderer — Category-adaptive visual simulation component
 * 
 * Renders authentic, lightweight visual representations for:
 * - Stars (Main Sequence, Red Giants, Supergiants, Red Dwarfs via StarVisual)
 * - White Dwarfs (Compact white point with violet aura)
 * - Neutron Stars (Ultra-dense thermal pinpoint)
 * - Pulsars (Rotating twin synchrotron beam cones & pulse rings)
 * - Black Holes (Pitch-black event horizon, Doppler accretion disk & photon ring)
 * - Nebulae (Billowing organic clouds & Ring Nebula donut shell)
 * - Star Clusters (Collective reflection haze with embedded member stars)
 * - Galaxies (Tilted spiral disc with galactic core and dust lanes)
 */
export default function ObjectVisualRenderer({
  object,
  size = 'modal',
  className = '',
}) {
  if (!object) return null;

  const category = object.category || CELESTIAL_CATEGORIES.STAR;

  // For Stars and standard stellar types, delegate to StarVisual
  if (
    category === CELESTIAL_CATEGORIES.STAR ||
    object.type === 'Main Sequence' ||
    object.type === 'Giant' ||
    object.type === 'Supergiant' ||
    object.type === 'Red Dwarf'
  ) {
    return <StarVisual star={object} size={size} isHovered={true} className={className} />;
  }

  // Dimension container classes
  const containerSize =
    size === 'modal' || size === 'lg'
      ? 'w-48 h-48 sm:w-64 sm:h-64 lg:w-72 lg:h-72'
      : 'w-24 h-24 sm:w-28 sm:h-28';

  return (
    <div
      className={`relative flex items-center justify-center select-none ${containerSize} ${className}`}
      aria-label={`Visual simulation of ${object.name}`}
    >
      {/* 1. BLACK HOLE VISUAL */}
      {category === CELESTIAL_CATEGORIES.BLACK_HOLE && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Gravitational Lensing Outer Warp Aura */}
          <div className="absolute w-[85%] h-[85%] rounded-full bg-amber-500/15 blur-2xl animate-pulse pointer-events-none" />

          {/* Relativistic Accretion Disk (Tilted glowing ellipse with Doppler asymmetry) */}
          <div className="absolute w-[95%] h-[42%] rounded-full -rotate-[22deg] bg-gradient-to-r from-amber-200 via-amber-500/80 to-rose-600/40 blur-sm shadow-[0_0_35px_rgba(245,158,11,0.6)] flex items-center justify-start pl-6">
            {/* Doppler Brightening on Approaching Limb */}
            <div className="w-16 h-8 rounded-full bg-white/70 blur-md" />
          </div>

          {/* Golden Photon Sphere Ring */}
          <div className="absolute w-[44%] h-[44%] rounded-full border border-amber-300 shadow-[0_0_15px_#fde047]" />

          {/* Pitch-Black Event Horizon (Pure absorption void) */}
          <div className="relative w-[38%] h-[38%] rounded-full bg-black shadow-[inset_0_0_10px_rgba(245,158,11,0.4)] border border-amber-400/30 z-10" />
        </div>
      )}

      {/* 2. PULSAR VISUAL */}
      {category === CELESTIAL_CATEGORIES.PULSAR && (
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
          {/* Expanding Concentric Radio Pulse Waves */}
          <div className="absolute w-36 h-36 rounded-full border border-cyan-400/30 animate-ping duration-1000 pointer-events-none" />
          <div className="absolute w-28 h-28 rounded-full border border-cyan-400/40 animate-pulse pointer-events-none" />

          {/* Sweeping Twin Synchrotron Radiation Beams (45 deg angle) */}
          <div className="absolute w-full h-4 rotate-45 bg-gradient-to-r from-cyan-400/0 via-cyan-300 to-cyan-400/0 blur-[2px] opacity-85" />
          <div className="absolute w-4 h-full rotate-45 bg-gradient-to-b from-cyan-400/0 via-cyan-300 to-cyan-400/0 blur-[2px] opacity-85" />

          {/* Relativistic Jet Core Halo */}
          <div className="absolute w-24 h-24 rounded-full bg-cyan-500/25 blur-xl pointer-events-none" />

          {/* Ultra-Dense Core Point */}
          <div className="relative w-6 h-6 rounded-full bg-white shadow-[0_0_20px_#22d3ee,0_0_35px_#38bdf8] border border-cyan-200 z-10" />
        </div>
      )}

      {/* 3. NEUTRON STAR VISUAL */}
      {category === CELESTIAL_CATEGORIES.NEUTRON_STAR && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Intense Blistering Thermal Violet/Cyan Corona */}
          <div className="absolute w-40 h-40 rounded-full bg-purple-600/20 blur-2xl animate-pulse pointer-events-none" />
          <div className="absolute w-24 h-24 rounded-full bg-cyan-400/30 blur-lg pointer-events-none" />

          {/* Ultra-Compact High-Intensity Core */}
          <div className="relative w-5 h-5 rounded-full bg-white shadow-[0_0_18px_#c084fc,0_0_30px_#ffffff] border border-purple-200 z-10" />
        </div>
      )}

      {/* 4. WHITE DWARF VISUAL */}
      {category === CELESTIAL_CATEGORIES.WHITE_DWARF && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Diamond-White Ultraviolet Corona */}
          <div className="absolute w-36 h-36 rounded-full bg-sky-400/25 blur-xl pointer-events-none" />
          <div className="absolute w-24 h-24 rounded-full bg-white/40 blur-md pointer-events-none" />

          {/* Crisp 4-Point Diffraction Cross */}
          <div className="absolute w-36 h-[1.5px] bg-white/80 shadow-[0_0_8px_white]" />
          <div className="absolute h-36 w-[1.5px] bg-white/80 shadow-[0_0_8px_white]" />

          {/* Compact White Dwarf Core */}
          <div className="relative w-8 h-8 rounded-full bg-white shadow-[0_0_25px_#e0f2fe,0_0_40px_#7dd3fc] border border-sky-100 z-10" />
        </div>
      )}

      {/* 5. NEBULA VISUAL */}
      {category === CELESTIAL_CATEGORIES.NEBULA && (
        <div className="relative w-full h-full flex items-center justify-center">
          {object.id === 'ring-nebula' ? (
            // Hollow Donut Planetary Nebula Shell
            <div className="relative w-44 h-44 rounded-full border-[18px] border-emerald-400/70 blur-[3px] shadow-[0_0_40px_rgba(52,211,153,0.5),inset_0_0_25px_rgba(56,189,248,0.5)] flex items-center justify-center">
              {/* Central White Dwarf Remnant */}
              <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_8px_white]" />
            </div>
          ) : (
            // Diffuse Billowing Multi-Lobe Stellar Nursery (Orion, Crab, Carina)
            <div className="relative w-full h-full flex items-center justify-center">
              <div
                className="absolute w-44 h-44 rounded-full blur-2xl opacity-60 animate-pulse pointer-events-none"
                style={{ backgroundColor: object.colorHex || '#38bdf8' }}
              />
              <div className="absolute w-36 h-28 -rotate-12 rounded-full bg-indigo-500/40 blur-xl pointer-events-none" />
              <div className="absolute w-28 h-36 rotate-45 rounded-full bg-purple-500/35 blur-xl pointer-events-none" />

              {/* Embedded Star Nursery Points */}
              <div className="relative z-10 flex gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_6px_white]" />
                <span className="w-2 h-2 rounded-full bg-cyan-200 shadow-[0_0_8px_cyan]" />
                <span className="w-1 h-1 rounded-full bg-white shadow-[0_0_6px_white]" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* 6. STAR CLUSTER VISUAL */}
      {category === CELESTIAL_CATEGORIES.STAR_CLUSTER && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Collective Reflection Nebula Haze */}
          <div className="absolute w-44 h-44 rounded-full bg-blue-500/20 blur-2xl pointer-events-none" />

          {/* Embedded Star Cluster Geometry (e.g. Pleiades Seven Sisters) */}
          <div className="relative z-10 w-36 h-36">
            <span className="absolute top-8 left-14 w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_10px_white]" />
            <span className="absolute top-14 left-8 w-2 h-2 rounded-full bg-sky-200 shadow-[0_0_8px_white]" />
            <span className="absolute top-16 left-22 w-2 h-2 rounded-full bg-white shadow-[0_0_8px_white]" />
            <span className="absolute top-22 left-12 w-1.5 h-1.5 rounded-full bg-cyan-100 shadow-[0_0_6px_white]" />
            <span className="absolute top-24 left-20 w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_6px_white]" />
            <span className="absolute top-10 left-24 w-1.5 h-1.5 rounded-full bg-sky-100 shadow-[0_0_6px_white]" />
            <span className="absolute top-6 left-6 w-1 h-1 rounded-full bg-white shadow-[0_0_4px_white]" />
          </div>
        </div>
      )}

      {/* 7. GALAXY VISUAL */}
      {category === CELESTIAL_CATEGORIES.GALAXY && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Tilted Elliptical Spiral Arms Disc */}
          <div className="absolute w-52 h-24 -rotate-[28deg] rounded-full bg-gradient-to-r from-indigo-500/20 via-sky-300/35 to-purple-500/20 blur-md shadow-[0_0_35px_rgba(147,197,253,0.35)] flex items-center justify-center">
            {/* Dark Interstellar Dust Lane */}
            <div className="w-44 h-2 rounded-full bg-black/40 blur-[1px]" />
          </div>

          {/* Golden Galactic Core Bulge */}
          <div className="relative w-16 h-12 -rotate-[28deg] rounded-full bg-gradient-to-r from-amber-100 via-amber-300 to-amber-100 blur-sm shadow-[0_0_20px_#fef08a] z-10" />
        </div>
      )}

      {/* 8. PLANET VISUAL */}
      {category === CELESTIAL_CATEGORIES.PLANET && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Ambient planetary backlight */}
          <div
            className="absolute w-40 h-40 rounded-full blur-2xl opacity-40 pointer-events-none"
            style={{ backgroundColor: object.colorHex || '#38bdf8' }}
          />

          {/* SATURN WITH TILTED 3D RINGS */}
          {object.id === 'saturn' ? (
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Back half of rings (behind planet) */}
              <div
                className="absolute w-56 h-20 -rotate-[22deg] rounded-full border-[10px] border-amber-300/60 shadow-[0_0_20px_rgba(252,211,77,0.3)] pointer-events-none"
                style={{
                  clipPath: 'polygon(0% 0%, 100% 0%, 100% 50%, 0% 50%)',
                }}
              />
              <div
                className="absolute w-44 h-15 -rotate-[22deg] rounded-full border-[8px] border-amber-200/80 shadow-[0_0_15px_rgba(252,211,77,0.4)] pointer-events-none"
                style={{
                  clipPath: 'polygon(0% 0%, 100% 0%, 100% 50%, 0% 50%)',
                }}
              />

              {/* Saturn Spherical Body */}
              <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-amber-100 via-amber-400 to-amber-800 shadow-[inset_-8px_-8px_16px_rgba(0,0,0,0.8),0_0_30px_rgba(251,191,36,0.4)] border border-amber-300/30 overflow-hidden z-10">
                {/* Horizontal cloud bands */}
                <div className="absolute top-4 left-0 right-0 h-2 bg-amber-600/40" />
                <div className="absolute top-10 left-0 right-0 h-3 bg-amber-700/30" />
                <div className="absolute top-16 left-0 right-0 h-2 bg-amber-800/40" />
              </div>

              {/* Front half of rings (in front of planet) */}
              <div
                className="absolute w-56 h-20 -rotate-[22deg] rounded-full border-[10px] border-amber-300/75 shadow-[0_0_25px_rgba(252,211,77,0.5)] pointer-events-none z-20"
                style={{
                  clipPath: 'polygon(0% 50%, 100% 50%, 100% 100%, 0% 100%)',
                }}
              />
              <div
                className="absolute w-44 h-15 -rotate-[22deg] rounded-full border-[8px] border-amber-200/90 shadow-[0_0_20px_rgba(252,211,77,0.6)] pointer-events-none z-20"
                style={{
                  clipPath: 'polygon(0% 50%, 100% 50%, 100% 100%, 0% 100%)',
                }}
              />
            </div>
          ) : object.id === 'earth' ? (
            /* EARTH: Blue marble oceans, emerald continents, cloud swirls & Moon */
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Cyan atmospheric edge scattering */}
              <div className="absolute w-32 h-32 rounded-full bg-cyan-400/25 blur-lg pointer-events-none" />

              {/* Earth Sphere */}
              <div className="relative w-28 h-28 rounded-full bg-gradient-to-br from-sky-400 via-blue-600 to-slate-900 shadow-[inset_-10px_-10px_20px_rgba(0,0,0,0.85),0_0_25px_rgba(56,189,248,0.4)] border border-cyan-400/40 overflow-hidden z-10">
                {/* Continents */}
                <div className="absolute top-4 left-3 w-10 h-14 rounded-full bg-emerald-500/80 -rotate-12 blur-[1px]" />
                <div className="absolute bottom-3 right-4 w-9 h-11 rounded-full bg-emerald-600/80 rotate-45 blur-[1px]" />
                {/* Weather Clouds */}
                <div className="absolute top-2 left-0 right-0 h-4 bg-white/60 blur-[2px] rounded-full -rotate-6" />
                <div className="absolute top-12 left-2 w-20 h-5 bg-white/70 blur-[2px] rounded-full rotate-12" />
                <div className="absolute bottom-4 left-4 w-18 h-4 bg-white/50 blur-[2px] rounded-full -rotate-12" />
              </div>

              {/* Orbiting Moon */}
              <div className="absolute w-44 h-22 rounded-full border border-white/10 -rotate-12 pointer-events-none">
                <span className="absolute -top-1.5 right-6 w-3.5 h-3.5 rounded-full bg-slate-200 shadow-[0_0_8px_white] border border-slate-400" />
              </div>
            </div>
          ) : object.id === 'jupiter' ? (
            /* JUPITER: Giant gas bands & Great Red Spot */
            <div className="relative w-36 h-36 rounded-full bg-gradient-to-br from-amber-100 via-amber-600 to-amber-950 shadow-[inset_-12px_-12px_24px_rgba(0,0,0,0.9),0_0_35px_rgba(245,158,11,0.35)] border border-amber-400/30 overflow-hidden">
              <div className="absolute top-5 left-0 right-0 h-4 bg-amber-800/60" />
              <div className="absolute top-11 left-0 right-0 h-3 bg-amber-900/50" />
              <div className="absolute top-16 left-0 right-0 h-5 bg-amber-800/70" />
              <div className="absolute top-24 left-0 right-0 h-4 bg-amber-900/60" />
              {/* Great Red Spot */}
              <div className="absolute top-21 right-6 w-7 h-4 rounded-full bg-red-600 shadow-[0_0_6px_#ef4444] border border-red-400" />
            </div>
          ) : object.id === 'mars' ? (
            /* MARS: Rust red with polar cap */
            <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-red-400 via-red-600 to-red-950 shadow-[inset_-8px_-8px_18px_rgba(0,0,0,0.85),0_0_25px_rgba(239,68,68,0.4)] border border-red-500/30 overflow-hidden">
              {/* Polar Ice Cap */}
              <div className="absolute top-0 left-6 right-6 h-3 rounded-b-full bg-white shadow-[0_0_8px_white]" />
              {/* Dark Basalt Terrain */}
              <div className="absolute top-9 left-4 w-12 h-8 rounded-full bg-red-950/70 blur-[1px] rotate-12" />
            </div>
          ) : object.id === 'uranus' ? (
            /* URANUS: Aquamarine ice giant with tilted vertical ring */
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="absolute w-18 h-40 rounded-full border border-cyan-300/40 rotate-12 pointer-events-none" />
              <div className="relative w-26 h-26 rounded-full bg-gradient-to-br from-cyan-200 via-cyan-400 to-cyan-900 shadow-[inset_-8px_-8px_18px_rgba(0,0,0,0.8),0_0_25px_rgba(103,232,249,0.45)] border border-cyan-300/40" />
            </div>
          ) : object.id === 'neptune' ? (
            /* NEPTUNE: Azure blue with storm streaks */
            <div className="relative w-26 h-26 rounded-full bg-gradient-to-br from-blue-400 via-blue-600 to-blue-950 shadow-[inset_-8px_-8px_18px_rgba(0,0,0,0.85),0_0_25px_rgba(59,130,246,0.45)] border border-blue-400/40 overflow-hidden">
              <div className="absolute top-6 left-2 w-16 h-1.5 bg-blue-200/80 rounded-full blur-[0.5px] -rotate-6" />
              <div className="absolute top-15 right-3 w-14 h-1.5 bg-blue-100/90 rounded-full blur-[0.5px] rotate-6" />
              <div className="absolute top-10 left-5 w-5 h-3 rounded-full bg-slate-950/70" />
            </div>
          ) : object.id === 'venus' ? (
            /* VENUS: Sulfur amber swirling clouds */
            <div className="relative w-26 h-26 rounded-full bg-gradient-to-br from-yellow-200 via-amber-500 to-amber-950 shadow-[inset_-8px_-8px_18px_rgba(0,0,0,0.85),0_0_25px_rgba(245,158,11,0.4)] border border-amber-300/40 overflow-hidden">
              <div className="absolute top-5 left-0 right-0 h-4 bg-yellow-300/30 blur-[1px] rotate-6" />
              <div className="absolute top-13 left-0 right-0 h-5 bg-amber-600/30 blur-[1px] -rotate-6" />
            </div>
          ) : object.id === 'moon' || category === CELESTIAL_CATEGORIES.NATURAL_SATELLITE ? (
            /* MOON: Grey regolith with volcanic maria & Tycho crater rays */
            <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-slate-200 via-slate-400 to-slate-800 shadow-[inset_-8px_-8px_18px_rgba(0,0,0,0.85),0_0_25px_rgba(226,232,240,0.35)] border border-slate-300/40 overflow-hidden">
              {/* Lunar Maria dark basalt plains */}
              <div className="absolute top-4 left-3 w-10 h-10 rounded-full bg-slate-900/60 blur-[1px]" />
              <div className="absolute top-10 right-4 w-8 h-8 rounded-full bg-slate-900/50 blur-[1px]" />
              <div className="absolute bottom-5 left-6 w-9 h-6 rounded-full bg-slate-900/55 blur-[1px]" />
              {/* Tycho Crater in south with ray system */}
              <div className="absolute bottom-3 left-8 w-2 h-2 rounded-full bg-white shadow-[0_0_6px_white]" />
              <div className="absolute bottom-2 left-6 w-8 h-[1px] bg-white/40 rotate-12" />
              <div className="absolute bottom-2 left-7 w-8 h-[1px] bg-white/40 -rotate-25" />
            </div>
          ) : (
            /* MERCURY & OTHER TERRESTRIAL: Cratered slate */
            <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-slate-300 via-slate-500 to-slate-900 shadow-[inset_-6px_-6px_14px_rgba(0,0,0,0.85),0_0_20px_rgba(148,163,184,0.35)] border border-slate-400/30 overflow-hidden">
              <div className="absolute top-3 left-4 w-3.5 h-3.5 rounded-full bg-slate-700/60" />
              <div className="absolute bottom-4 right-3 w-3 h-3 rounded-full bg-slate-800/70" />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
