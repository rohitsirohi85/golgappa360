import React from 'react';
import { useMess, NAV_ITEMS } from '../../context/MessContext';
import { Sidebar } from './Sidebar';
import { TopHeader } from './TopHeader';
import { InfoModal } from '../common/InfoModal';
import {
  LayoutDashboard,
  Sparkles,
  Database,
  FlaskConical,
  TrendingDown,
  History,
  Info,
  X,
  Leaf,
  GraduationCap,
} from 'lucide-react';

const iconMap = {
  LayoutDashboard,
  Sparkles,
  Database,
  FlaskConical,
  TrendingDown,
  History,
  Info,
};

export const MainLayout = ({ children }) => {
  const {
    isSidebarCollapsed,
    isMobileMenuOpen,
    toggleMobileMenu,
    activeTab,
    navigateTo,
  } = useMess();

  return (
    <div className="min-h-screen bg-[#F8FAF8] text-[#25332D] flex flex-col font-sans selection:bg-[#E9F6EE] selection:text-[#16865B]">
      {/* Desktop Left Sidebar */}
      <Sidebar />

      {/* Mobile Drawer Backdrop */}
      {isMobileMenuOpen && (
        <div
          onClick={toggleMobileMenu}
          className="fixed inset-0 z-40 bg-[#25332D]/30 backdrop-blur-xs md:hidden animate-in fade-in duration-200"
        />
      )}

      {/* Mobile Slide-over Drawer */}
      <div
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-white border-r border-[#E4EAE5] p-5 flex flex-col justify-between transition-transform duration-300 md:hidden shadow-lg ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-[#E4EAE5]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#E9F6EE] text-[#16865B] flex items-center justify-center">
                <Leaf className="w-4 h-4" />
              </div>
              <div>
                <span className="font-semibold text-[#25332D] text-sm">
                  SmartMess <span className="text-[#16865B] font-mono text-xs">AI</span>
                </span>
                <p className="text-[10px] text-[#77847C]">
                  Food Waste Intelligence
                </p>
              </div>
            </div>

            <button
              onClick={toggleMobileMenu}
              className="p-1.5 rounded-lg text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8] transition-colors cursor-pointer"
              aria-label="Close menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <nav className="mt-4 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = iconMap[item.icon] || LayoutDashboard;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#E9F6EE] text-[#16865B] font-semibold'
                      : 'text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#16865B]' : 'text-[#77847C]'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-xs space-y-1">
          <div className="flex items-center gap-1.5 text-[#16865B] font-semibold text-[11px]">
            <GraduationCap className="w-3.5 h-3.5" />
            MCA Major Project
          </div>
          <p className="text-[10px] text-[#77847C]">
            Academic Evaluation 2026
          </p>
        </div>
      </div>

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ${
          isSidebarCollapsed ? 'md:ml-16' : 'md:ml-60'
        }`}
      >
        {/* Top Header */}
        <TopHeader />

        {/* Dynamic Page Content with generous whitespace (28-36px horizontal padding) */}
        <main className="flex-1 px-6 sm:px-8 lg:px-9 py-7 max-w-7xl w-full mx-auto">
          {children}
        </main>

        {/* Clean Light Footer */}
        <footer className="mt-auto border-t border-[#E4EAE5] bg-white px-6 sm:px-8 lg:px-9 py-4 text-xs text-[#77847C]">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-[#25332D]">SmartMess AI</span>
              <span>— Intelligent Food Waste Prediction & Prevention System</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-mono text-[#77847C]">
              <span className="text-[#16865B] font-medium">FastAPI + React 19</span>
              <span>•</span>
              <span>MCA Major Project 2026</span>
            </div>
          </div>
        </footer>
      </div>

      {/* Academic Disclaimer Modal */}
      <InfoModal />
    </div>
  );
};
