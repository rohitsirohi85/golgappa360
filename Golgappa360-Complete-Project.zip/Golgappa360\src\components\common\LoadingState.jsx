import React from "react";

export const LoadingState = ({ count = 4, type = "card" }) => {
  if (type === "table") {
    return (
      <div className="w-full space-y-3 animate-pulse">
        {Array.from({ length: count }).map((_, i) => (
          <div key={i} className="h-14 bg-white/[0.03] border border-white/[0.05] rounded-xl flex items-center px-4 gap-4">
            <div className="w-8 h-8 rounded-lg bg-white/[0.08]" />
            <div className="flex-1 space-y-1.5">
              <div className="h-4 bg-white/[0.08] rounded w-1/3" />
              <div className="h-3 bg-white/[0.04] rounded w-1/4" />
            </div>
            <div className="w-12 h-3 bg-white/[0.05] rounded" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 animate-pulse">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white/[0.03] border border-white/[0.05] rounded-2xl p-3.5 space-y-3">
          <div className="w-full aspect-square rounded-xl bg-white/[0.08]" />
          <div className="space-y-2">
            <div className="h-4 bg-white/[0.08] rounded w-3/4" />
            <div className="h-3 bg-white/[0.05] rounded w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );
};
