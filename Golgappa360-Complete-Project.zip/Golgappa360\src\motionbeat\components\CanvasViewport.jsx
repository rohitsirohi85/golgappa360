import React, { useEffect, useRef, useState } from 'react';
import { VisualEngine } from '../visuals/VisualEngine';
import { PerformanceHUD } from './PerformanceHUD';
import { gestureInterface } from '../tracking/gestureInterface';

export const CanvasViewport = ({
  visualEngineRef,
  audioEngine,
  activePreset,
  settings,
  showHUD,
  audioPlaying,
  bpm = 124,
  trackingMode = 'mouse',
  handCount = 0,
  inferenceFps = 0,
  inferenceLatencyMs = 0,
  graphicsQuality = 'high',
  cameraStatus = 'off',
  onQualityAutoChange,
}) => {
  const containerRef = useRef(null);
  const [telemetry, setTelemetry] = useState({
    fps: 60,
    preset: 'particle-universe',
    triangles: 0,
    points: 45000,
    calls: 1,
    quality: 'high',
  });
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Instantiate decoupled VisualEngine
    const engine = new VisualEngine(containerRef.current);
    visualEngineRef.current = engine;

    if (audioEngine) {
      engine.setAudioDataProvider(() => audioEngine.getAudioData());
    }

    engine.onTelemetryUpdate = (data) => {
      setTelemetry((prev) => ({ ...prev, ...data }));
      if (data.quality && data.quality !== graphicsQuality && onQualityAutoChange) {
        onQualityAutoChange(data.quality);
      }
    };

    const handleMove = (e) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      const clampedX = Math.max(-1, Math.min(1, nx));
      const clampedY = Math.max(-1, Math.min(1, ny));
      setMousePos({ x: clampedX, y: clampedY });
      gestureInterface.setMouseFallback(clampedX, clampedY);
    };

    const container = containerRef.current;
    container.addEventListener('mousemove', handleMove);

    return () => {
      container.removeEventListener('mousemove', handleMove);
      engine.dispose();
      visualEngineRef.current = null;
    };
  }, [audioEngine]);

  useEffect(() => {
    if (visualEngineRef.current) {
      visualEngineRef.current.setPreset(activePreset);
    }
  }, [activePreset]);

  useEffect(() => {
    if (visualEngineRef.current) {
      visualEngineRef.current.updateSettings(settings);
    }
  }, [settings]);

  useEffect(() => {
    if (visualEngineRef.current) {
      visualEngineRef.current.setGraphicsQuality(graphicsQuality);
    }
  }, [graphicsQuality]);

  return (
    <div
      ref={containerRef}
      className="relative flex-1 w-full h-full overflow-hidden bg-[#030308] cursor-crosshair select-none"
    >
      <PerformanceHUD
        showHUD={showHUD}
        fps={telemetry.fps}
        preset={activePreset}
        mousePos={mousePos}
        audioPlaying={audioPlaying}
        bpm={bpm}
        triangles={telemetry.triangles}
        points={telemetry.points}
        trackingMode={trackingMode}
        handCount={handCount}
        inferenceFps={inferenceFps}
        inferenceLatencyMs={inferenceLatencyMs}
        graphicsQuality={graphicsQuality}
        cameraStatus={cameraStatus}
      />
    </div>
  );
};
