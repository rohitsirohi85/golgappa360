import React, { createContext, useContext, useState, useEffect } from 'react';
import { MOCK_STATIONS } from '../data/mockStations';
import { MOCK_BOOKINGS } from '../data/mockBookings';
import { DEFAULT_CHARGING_SESSION } from '../data/mockCharging';
import { MOCK_HISTORY } from '../data/mockHistory';
import { MOCK_NOTIFICATIONS } from '../data/mockNotifications';

import { stationService } from '../services/stationService';
import { bookingService } from '../services/bookingService';
import { chargingService } from '../services/chargingService';
import { notificationService } from '../services/notificationService';
import { sensorService } from '../services/sensorService';
import { socketService } from '../services/socketService';

const EVContext = createContext();

export const EVProvider = ({ children }) => {
  const [stations, setStations] = useState(MOCK_STATIONS);
  const [selectedStation, setSelectedStation] = useState(MOCK_STATIONS[0]);
  const [selectedCharger, setSelectedCharger] = useState(MOCK_STATIONS[0]?.chargers?.[0]);
  const [bookings, setBookings] = useState(MOCK_BOOKINGS);
  const [history, setHistory] = useState(MOCK_HISTORY);
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [socketStatus, setSocketStatus] = useState(socketService.getStatus());

  // Live Charging State
  const [isCharging, setIsCharging] = useState(true);
  const [chargingSession, setChargingSession] = useState(DEFAULT_CHARGING_SESSION);
  const [completedSession, setCompletedSession] = useState({
    bookingId: 'EV20260924001',
    stationName: 'Green Valley EV Hub',
    chargerName: 'CH-01',
    finalBattery: 80,
    energyUsed: 18.4,
    durationMinutes: 42,
    rate: 10,
    totalAmount: 184,
    completedAt: '24 Sep 2026, 04:42 PM',
  });

  // Fetch initial data from MongoDB backend on startup
  useEffect(() => {
    const fetchBackendData = async () => {
      try {
        const fetchedStations = await stationService.getStations();
        if (fetchedStations && fetchedStations.length > 0) {
          setStations(fetchedStations);
          setSelectedStation(fetchedStations[0]);
          if (fetchedStations[0]?.chargers?.length > 0) {
            setSelectedCharger(fetchedStations[0].chargers[0]);
          }
        }

        const token = localStorage.getItem('ev_smart_token') || localStorage.getItem('token');
        if (token) {
          const fetchedBookings = await bookingService.getMyBookings();
          if (fetchedBookings && fetchedBookings.length > 0) {
            setBookings(fetchedBookings);
          }

          const fetchedNotifs = await notificationService.getNotifications();
          if (fetchedNotifs && fetchedNotifs.length > 0) {
            setNotifications(fetchedNotifs);
          }

          const fetchedHistory = await chargingService.getHistory();
          if (fetchedHistory && fetchedHistory.length > 0) {
            setHistory(fetchedHistory);
          }
        }
      } catch (err) {
        console.warn('Backend data sync fallback to local cache:', err);
      }
    };

    fetchBackendData();

    // Initialize Socket.IO connection & listeners
    socketService.connect();
    const unsubStatus = socketService.onStatusChange(setSocketStatus);

    const handleStationUpdate = (data) => {
      if (!data || !data.stationId) return;
      setStations((prev) =>
        prev.map((st) => {
          if (st.id === data.stationId || st._id === data.stationId) {
            return {
              ...st,
              availableChargers: data.availableChargers !== undefined ? data.availableChargers : st.availableChargers,
              totalChargers: data.totalChargers !== undefined ? data.totalChargers : st.totalChargers,
            };
          }
          return st;
        })
      );
    };

    const handleNewNotification = (notif) => {
      setNotifications((prev) => [notif, ...(Array.isArray(prev) ? prev : [])]);
    };

    const unsubStation = socketService.on('station:update', handleStationUpdate);
    const unsubNotif = socketService.on('notification:new', handleNewNotification);

    return () => {
      if (typeof unsubStatus === 'function') unsubStatus();
      if (typeof unsubStation === 'function') unsubStation();
      if (typeof unsubNotif === 'function') unsubNotif();
      if (typeof socketService.off === 'function') {
        socketService.off('station:update', handleStationUpdate);
        socketService.off('notification:new', handleNewNotification);
      }
    };
  }, []);

  // Ticking simulation for live charging screen + periodic telemetry sync
  useEffect(() => {
    let interval = null;
    if (isCharging) {
      interval = setInterval(() => {
        setChargingSession((prev) => {
          const newSec = prev.chargingTimeSec + 1;
          const newEnergy = +(prev.energyDelivered + 0.002).toFixed(2);
          const delta = (Math.random() - 0.5) * 0.04;
          const newPower = +(Math.max(2.18, Math.min(2.32, prev.power + delta))).toFixed(2);

          return {
            ...prev,
            chargingTimeSec: newSec,
            energyDelivered: newEnergy,
            power: newPower,
          };
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCharging]);

  // Booking functions connected to backend
  const addBooking = async (bookingData) => {
    const bookingPayload = {
      stationId: selectedStation?.id || 'st_01',
      stationName: selectedStation?.name || 'Green Valley EV Hub',
      stationAddress: selectedStation?.address || 'Plot 42, Silicon Gateway',
      chargerId: selectedCharger?.id || 'CH-01',
      chargerName: selectedCharger?.name || 'Charger 01',
      power: selectedCharger?.power || '60 kW',
      connector: selectedCharger?.connector || 'CCS2',
      date: bookingData.date || '24 Sep 2026',
      time: bookingData.time || '04:00 PM – 05:00 PM',
      rate: selectedCharger?.rate || 10,
      estimatedCost: (selectedCharger?.rate || 10) * 18,
    };

    const newBooking = await bookingService.createBooking(bookingPayload);
    setBookings((prev) => [newBooking, ...(Array.isArray(prev) ? prev : [])]);

    // Push local notification banner
    const newNotif = {
      id: `notif_${Date.now()}`,
      type: 'booking',
      icon: 'bell',
      title: 'Booking Confirmed',
      message: `Your slot at ${newBooking.stationName} (${newBooking.chargerName}) is confirmed for ${newBooking.date}, ${newBooking.time}.`,
      time: 'Just now',
      unread: true,
      actionRoute: '/bookings',
    };
    setNotifications((prev) => [newNotif, ...(Array.isArray(prev) ? prev : [])]);

    return newBooking;
  };

  const cancelBooking = async (bookingId) => {
    await bookingService.cancelBooking(bookingId);

    setBookings((prev) =>
      Array.isArray(prev) ? prev.map((b) => (b.id === bookingId ? { ...b, status: 'Cancelled' } : b)) : []
    );

    setHistory((prev) =>
      Array.isArray(prev) ? prev.map((h) => (h.bookingId === bookingId ? { ...h, status: 'Cancelled' } : h)) : []
    );

    const cancelledNotif = {
      id: `notif_${Date.now()}`,
      type: 'alert',
      icon: 'alert-triangle',
      title: 'Booking Cancelled',
      message: `Booking ${bookingId} has been cancelled successfully.`,
      time: 'Just now',
      unread: true,
      actionRoute: '/bookings',
    };
    setNotifications((prev) => [cancelledNotif, ...(Array.isArray(prev) ? prev : [])]);
  };

  // Charging controls
  const startCharging = async (charger = selectedCharger, station = selectedStation) => {
    setIsCharging(true);
    setChargingSession((prev) => ({
      ...prev,
      stationName: station?.name || prev.stationName,
      chargerId: charger?.id || prev.chargerId,
      chargerName: charger?.name || prev.chargerName,
      chargingTimeSec: 0,
      energyDelivered: 0.1,
    }));

    // Async backend session start
    chargingService.startSession(charger, station).catch(console.warn);

    const notif = {
      id: `notif_${Date.now()}`,
      type: 'charging_start',
      icon: 'zap',
      title: 'Charging Started',
      message: `Charging in progress at ${station?.name || 'Green Valley EV Hub'}. Telemetry live.`,
      time: 'Just now',
      unread: true,
      actionRoute: '/live-charging',
    };
    setNotifications((prev) => [notif, ...(Array.isArray(prev) ? prev : [])]);
  };

  const stopCharging = async () => {
    setIsCharging(false);
    const energy = chargingSession.energyDelivered > 1.0 ? chargingSession.energyDelivered : 18.4;
    const rate = chargingSession.ratePerKwh || 10;
    const totalAmount = Math.round(energy * rate);
    const duration = Math.max(1, Math.round(chargingSession.chargingTimeSec / 60)) || 42;

    const completed = {
      bookingId: 'EV20260924001',
      stationName: chargingSession.stationName || 'Green Valley EV Hub',
      chargerName: chargingSession.chargerName || 'CH-01',
      finalBattery: chargingSession.targetBattery || 80,
      energyUsed: energy,
      durationMinutes: duration,
      rate,
      totalAmount,
      completedAt: '24 Sep 2026, 04:42 PM',
    };

    setCompletedSession(completed);

    // Async backend session stop & bill calculation
    chargingService.stopSession({
      ...chargingSession,
      currentBattery: completed.finalBattery,
      energyDelivered: energy,
    }).catch(console.warn);

    const historyItem = {
      id: `HIST-${Date.now()}`,
      bookingId: completed.bookingId,
      date: '24 Sep 2026',
      time: '04:00 PM - 04:42 PM',
      stationName: completed.stationName,
      chargerName: completed.chargerName,
      energyKwh: energy,
      rate,
      amount: totalAmount,
      status: 'Completed',
      duration: `${duration} mins`,
      connector: 'CCS2',
      batteryStart: chargingSession.initialBattery || 42,
      batteryEnd: completed.finalBattery,
      invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
    };
    setHistory((prev) => [historyItem, ...(Array.isArray(prev) ? prev : [])]);

    const completeNotif = {
      id: `notif_${Date.now()}`,
      type: 'charging_complete',
      icon: 'battery-charging',
      title: 'Charging Complete',
      message: `Vehicle reached target ${completed.finalBattery}%. Total: ₹${totalAmount}.`,
      time: 'Just now',
      unread: true,
      actionRoute: '/history',
    };
    setNotifications((prev) => [completeNotif, ...(Array.isArray(prev) ? prev : [])]);

    return completed;
  };

  const updateChargingTarget = (newTarget) => {
    setChargingSession((prev) => ({ ...prev, targetBattery: newTarget }));
  };

  const markNotificationAsRead = (id) => {
    notificationService.markAsRead(id);
    setNotifications((prev) =>
      Array.isArray(prev) ? prev.map((n) => (n.id === id ? { ...n, unread: false } : n)) : []
    );
  };

  const markAllNotificationsAsRead = () => {
    notificationService.markAllRead();
    setNotifications((prev) => (Array.isArray(prev) ? prev.map((n) => ({ ...n, unread: false })) : []));
  };

  const unreadNotificationsCount = Array.isArray(notifications)
    ? notifications.filter((n) => n.unread).length
    : 0;

  return (
    <EVContext.Provider
      value={{
        stations,
        selectedStation,
        setSelectedStation,
        selectedCharger,
        setSelectedCharger,
        bookings,
        addBooking,
        cancelBooking,
        history,
        notifications,
        unreadNotificationsCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        // Live charging
        isCharging,
        chargingSession,
        completedSession,
        startCharging,
        stopCharging,
        updateChargingTarget,
        // Real-Time Socket
        socketStatus,
        socketService,
      }}
    >
      {children}
    </EVContext.Provider>
  );
};

export const useEV = () => {
  const context = useContext(EVContext);
  if (!context) {
    throw new Error('useEV must be used within an EVProvider');
  }
  return context;
};
