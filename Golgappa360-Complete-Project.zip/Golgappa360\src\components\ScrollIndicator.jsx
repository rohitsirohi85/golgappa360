import React from 'react';

/**
 * ScrollIndicator — Minimal animated prompt at the bottom of the Hero section
 */
export default function ScrollIndicator({ targetId = '#intro', className = '' }) {
  const handleClick = (e) => {
    e.preventDefault();
    const target = document.querySelector(targetId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <a
      href={targetId}
      onClick={handleClick}
      aria-label="Scroll to explore"
      className={`group inline-flex flex-col items-center gap-2 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-lg p-2 transition-all duration-300 ${className}`}
    >
      <span className="text-[11px] tracking-[0.3em] font-mono uppercase text-slate-400/80 group-hover:text-cyan-300 transition-colors duration-300">
        SCROLL TO EXPLORE
      </span>

      <div className="w-5 h-8 rounded-full border border-slate-700 group-hover:border-cyan-400/60 flex items-start justify-center p-1 transition-colors duration-300">
        <div className="w-1 h-2 rounded-full bg-cyan-400 animate-scroll-bounce shadow-[0_0_8px_#38bdf8]" />
      </div>

      <svg
        className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition-all duration-300 transform group-hover:translate-y-1"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth="2"
      >
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
      </svg>
    </a>
  );
}
