import React from 'react';
import { Info } from 'lucide-react';
import { useMess } from '../../context/MessContext';

export const SyntheticDataBadge = ({ size = 'md', interactive = true, showSubtext = false }) => {
  const { setIsDemoModalOpen } = useMess();

  return (
    <button
      type="button"
      onClick={interactive ? () => setIsDemoModalOpen(true) : undefined}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#E9F6EE] text-[#16865B] border border-[#D1EAD8] transition-colors ${
        interactive ? 'cursor-pointer hover:bg-[#DCF2E4]' : ''
      }`}
      title="Click to view Academic Disclaimer & Dataset Details"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-[#16865B]" />
      <span className="text-[11px] font-medium tracking-tight">
        Synthetic Demo Data
      </span>
      {interactive && (
        <Info className="w-3 h-3 text-[#16865B]/70 ml-0.5" />
      )}
    </button>
  );
};
