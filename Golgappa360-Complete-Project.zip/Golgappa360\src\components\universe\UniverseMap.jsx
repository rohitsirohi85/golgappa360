import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import {
  ALL_CELESTIAL_OBJECTS,
  ALL_SEARCHABLE_OBJECTS,
  getCelestialObjectById,
} from '../../data/celestialObjects.js';
import { SOLAR_SYSTEM_DATA, MOON_DATA, MOON_PHASES } from '../../data/solarSystem.js';
import {
  MIN_ZOOM,
  MAX_ZOOM,
  DEFAULT_ZOOM,
  clamp,
  lerp,
  hitTestStar,
  screenToWorld,
} from '../../utils/mapScale.js';
import {
  drawBackground,
  drawBackgroundStars,
  drawConstellationLines,
  drawConstellationRegionAura,
  drawConstellationLabels,
  drawCelestialObjects,
  drawSelectionReticle,
  drawHoverRing,
} from './StarRenderer.js';
import { CONSTELLATIONS_DATA, getConstellationById } from '../../data/constellations.js';
import { CONSTELLATION_REGIONS } from '../../utils/mapCoordinates.js';
import ConstellationInspector from './ConstellationInspector';
import ConstellationBar from './ConstellationBar';
import {
  drawSolarBackground,
  drawSolarOrbits,
  drawCentralSun,
  drawPlanets,
  hitTestSolarObject,
  getPlanetWorldPosition,
} from './SolarSystemRenderer.js';
import {
  drawEarthSceneBackground,
  drawEarthMagneticField,
  drawInteractiveEarth,
  drawEarthOrbitingMoon,
  drawCloseUpMoon,
  hitTestEarthSystem,
} from './EarthMoonRenderer.js';
import {
  BLACK_HOLES_CATALOG,
  BLACK_HOLE_FEATURES,
  BLACK_HOLE_TYPES,
} from '../../data/blackHoles.js';
import {
  drawBlackHoleBackground,
  drawLensedStars,
  drawBipolarJets,
  drawWarpedBackDisk,
  drawPhotonRing,
  drawEventHorizon,
  drawFrontAccretionDisk,
  drawHotspotCallouts,
  getBlackHoleHitFeature,
} from './BlackHoleRenderer.js';
import CosmicNavigationHud from './CosmicNavigationHud';
import CosmicDiscoveryCard from './CosmicDiscoveryCard';
import CosmicCompareModal from '../compare/CosmicCompareModal';
import { selectCuratedDiscovery, getSessionDiscoveryCount } from '../../services/discoveryService.js';
import UniverseControls from './UniverseControls';
import SolarSystemControls from './SolarSystemControls';
import EarthControls from './EarthControls';
import MoonControls from './MoonControls';
import MoonPhaseBar from './MoonPhaseBar';
import BlackHoleControls from './BlackHoleControls';
import BlackHoleHotspots from './BlackHoleHotspots';
import UniverseSearch from './UniverseSearch';
import CategoryFilter from './CategoryFilter';
import ObjectInspector from './ObjectInspector';
import MapLegend from './MapLegend';
import StarModal from '../StarModal';

/**
 * UniverseMap — STELLAR 2.0 (Phase U6: Earth & Moon Experience)
 * 
 * High-performance 2D Canvas exploration platform supporting:
 * 1. UNIVERSE ATLAS (Phase U2, U3, U4):
 *    - Stars, white dwarfs, neutron stars, pulsars, black holes, nebulae, clusters, galaxies
 * 2. SOLAR SYSTEM (Phase U5):
 *    - Central Sun + 8 major planets with interactive orbits and time controls
 * 3. EARTH & MOON SYSTEM (Phase U6):
 *    - Interactive 3D spherical rotating Earth with recognizable continents, day/night cycle,
 *      Rayleigh scattering atmospheric halo, cloud layers, and geomagnetic dipole shield
 *    - Moon orbiting Earth with tidal synchronization
 * 4. MOON EXPLORATION (Phase U6):
 *    - Lunar close-up observatory with maria (Tranquility Base), impact craters (Tycho, Copernicus),
 *      and interactive 8-phase lunar illumination simulator
 * 
 * DISCLAIMER: Illustrative educational visualization — not to physical scale.
 */
export default function UniverseMap({
  onOpenExternalStar = null,
  externalSelectedConstellation = null,
  onClearExternalConstellation = null,
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);

  // View Mode: 'universe' | 'solar-system' | 'earth' | 'moon'
  const [viewMode, setViewMode] = useState('universe');

  // Active Constellation state (Phase U8)
  const [selectedConstellation, setSelectedConstellation] = useState(null);

  // Camera state: position (world x, y) & zoom
  const cameraRef = useRef({ x: 0, y: 0, zoom: DEFAULT_ZOOM });
  const targetCameraRef = useRef({ x: 0, y: 0, zoom: DEFAULT_ZOOM });

  // Solar System simulation clock
  const solarTimeRef = useRef(0);
  const lastTimeRef = useRef(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [speedFactor, setSpeedFactor] = useState(1.0);
  const [showOrbits, setShowOrbits] = useState(true);

  // Earth simulation state
  const earthRotationRef = useRef(0);
  const [isEarthRotating, setIsEarthRotating] = useState(true);
  const [showAtmosphere, setShowAtmosphere] = useState(true);
  const [showDayNight, setShowDayNight] = useState(true);
  const [showMoonOrbit, setShowMoonOrbit] = useState(true);
  const [showMagneticField, setShowMagneticField] = useState(false);
  const moonOrbitAngleRef = useRef(0);

  // Moon simulation state
  const moonRotationRef = useRef(0);
  const [isMoonRotating, setIsMoonRotating] = useState(true);
  const [activeMoonPhaseIndex, setActiveMoonPhaseIndex] = useState(4); // Default to Full Moon

  // Cached screen positions for hit-testing in Earth view
  const lastMoonScreenPosRef = useRef(null);

  // Black Hole simulation state (Phase U7)
  const [blackHoleObject, setBlackHoleObject] = useState(() => BLACK_HOLES_CATALOG[0]);
  const blackHoleRotationRef = useRef(0);
  const [isBlackHoleRotating, setIsBlackHoleRotating] = useState(true);
  const [blackHoleSpeedFactor, setBlackHoleSpeedFactor] = useState(1.0);
  const [showAccretionDisk, setShowAccretionDisk] = useState(true);
  const [showLensing, setShowLensing] = useState(true);
  const [showPhotonRing, setShowPhotonRing] = useState(true);
  const [showJets, setShowJets] = useState(true);
  const [showHotspots, setShowHotspots] = useState(true);
  const [activeHotspotId, setActiveHotspotId] = useState('event-horizon');
  const [hoveredHotspotId, setHoveredHotspotId] = useState(null);

  // Interaction tracking refs
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const dragStartCameraRef = useRef({ x: 0, y: 0 });
  const touchDistanceRef = useRef(null);
  const movedDistanceRef = useRef(0);

  // React state for HUD & UI panels
  const [currentZoom, setCurrentZoom] = useState(DEFAULT_ZOOM);
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [selectedObject, setSelectedObject] = useState(null);
  const [hoveredObject, setHoveredObject] = useState(null);

  // Universal Object Details modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeModalObject, setActiveModalObject] = useState(null);

  // Cosmic Discovery Mode state (Phase U11)
  const [isDiscoveryOpen, setIsDiscoveryOpen] = useState(false);
  const [isDiscoveryScanning, setIsDiscoveryScanning] = useState(false);
  const [discoveredObject, setDiscoveredObject] = useState(null);
  const [discoveryCategory, setDiscoveryCategory] = useState('ALL');
  const [discoveryCount, setDiscoveryCount] = useState(() => getSessionDiscoveryCount());

  // Cosmic Compare Mode state (Phase U12)
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [compareObjectA, setCompareObjectA] = useState(null);
  const [compareObjectB, setCompareObjectB] = useState(null);

  // Central Sun and Earth object references
  const sunObject = useMemo(() => SOLAR_SYSTEM_DATA.find((o) => o.id === 'sun') || null, []);
  const earthObject = useMemo(() => SOLAR_SYSTEM_DATA.find((o) => o.id === 'earth') || null, []);

  // Quick lookup map for constellation rendering in universe view
  const starMap = useMemo(() => {
    const map = {};
    for (const obj of ALL_CELESTIAL_OBJECTS) {
      map[obj.id] = obj;
    }
    return map;
  }, []);

  // Smooth camera navigation helper
  const navigateTo = useCallback((x, y, zoom, immediate = false) => {
    targetCameraRef.current = {
      x,
      y,
      zoom: clamp(zoom, MIN_ZOOM, MAX_ZOOM),
    };
    if (immediate) {
      cameraRef.current = { ...targetCameraRef.current };
      setCurrentZoom(targetCameraRef.current.zoom);
    }
  }, []);

  // Transition / Camera Flight: SELECT CONSTELLATION (Phase U8)
  const handleSelectConstellation = useCallback((constellationOrId, shouldPan = true) => {
    if (!constellationOrId) {
      setSelectedConstellation(null);
      return;
    }

    let constObj = null;
    if (typeof constellationOrId === 'string') {
      const lower = constellationOrId.toLowerCase().trim();
      constObj =
        CONSTELLATIONS_DATA.find(
          (c) =>
            c.id.toLowerCase() === lower ||
            c.name.toLowerCase() === lower ||
            c.name.toLowerCase().replace(/\s+/g, '-') === lower
        ) || getConstellationById(constellationOrId);
    } else {
      constObj =
        getConstellationById(constellationOrId.id) ||
        CONSTELLATIONS_DATA.find((c) => c.id === constellationOrId.id) ||
        constellationOrId;
    }

    if (!constObj) return;

    if (viewMode !== 'universe') {
      setViewMode('universe');
    }

    setSelectedConstellation(constObj);
    setSelectedObject(null);
    setIsModalOpen(false);

    if (shouldPan) {
      const reg =
        CONSTELLATION_REGIONS.find(
          (r) =>
            r.id === constObj.id ||
            r.name.toLowerCase() === constObj.name?.toLowerCase() ||
            r.label?.toLowerCase() === constObj.name?.toLowerCase()
        ) || { x: constObj.x || 0, y: constObj.y || 0, framingZoom: 1.45 };

      const isDesktop = window.innerWidth >= 768;
      const offsetX = isDesktop ? 45 / (reg.framingZoom || 1.45) : 0;
      navigateTo(reg.x + offsetX, reg.y, reg.framingZoom || 1.45);
    }
  }, [viewMode, navigateTo]);

  // Two-way navigation: Explore Constellation from Star or external call
  const handleExploreConstellation = useCallback((constellationNameOrId) => {
    if (!constellationNameOrId) return;
    const lower = constellationNameOrId.toLowerCase().trim();
    const found = CONSTELLATIONS_DATA.find(
      (c) =>
        c.id.toLowerCase() === lower ||
        c.name.toLowerCase() === lower ||
        c.name.toLowerCase().replace(/\s+/g, '-') === lower ||
        c.latinName?.toLowerCase() === lower
    );
    if (found) {
      handleSelectConstellation(found, true);
    }
  }, [handleSelectConstellation]);

  // Center camera on a specific planet or celestial object
  const handleSelectObject = useCallback((obj, shouldPan = true) => {
    if (!obj) {
      setSelectedObject(null);
      return;
    }

    if (obj.isConstellation || obj.category === 'CONSTELLATION') {
      handleSelectConstellation(obj, shouldPan);
      return;
    }

    setSelectedObject(obj);
    if (!shouldPan) return;

    if (viewMode === 'solar-system') {
      if (obj.isSun || obj.id === 'sun') {
        navigateTo(0, 0, Math.max(cameraRef.current.zoom, 1.3));
      } else if (obj.category === 'PLANET') {
        const pos = getPlanetWorldPosition(obj, solarTimeRef.current, speedFactor);
        const targetZoom = Math.max(cameraRef.current.zoom, 2.2);
        navigateTo(pos.x, pos.y, targetZoom);
      }
    } else if (viewMode === 'earth' || viewMode === 'moon') {
      navigateTo(0, 0, 1.0);
    } else {
      const isDesktop = window.innerWidth >= 768;
      const offsetX = isDesktop ? 60 / Math.max(1.8, targetCameraRef.current.zoom) : 0;
      const targetZoom = Math.max(cameraRef.current.zoom, 2.2);
      navigateTo(obj.x + offsetX, obj.y, targetZoom);
    }
  }, [viewMode, speedFactor, navigateTo, handleSelectConstellation]);

  // Two-way navigation: Select Member Star from Constellation Inspector
  const handleSelectStarFromConstellation = useCallback((starRef) => {
    if (!starRef) return;
    const starObj = ALL_CELESTIAL_OBJECTS.find(
      (s) => s.id === starRef.id || s.id === starRef.starId || s.name.toLowerCase() === starRef.name.toLowerCase()
    );
    if (starObj) {
      handleSelectObject(starObj, true);
    } else {
      handleSelectObject(starRef, true);
    }
  }, [handleSelectObject]);

  // Transition: ENTER SOLAR SYSTEM
  const handleEnterSolarSystem = useCallback((targetPlanet = null) => {
    setViewMode('solar-system');
    setSelectedConstellation(null);
    if (targetPlanet) {
      setSelectedObject(targetPlanet);
      if (targetPlanet.isSun || targetPlanet.id === 'sun') {
        navigateTo(0, 0, 1.2);
      } else {
        const pos = getPlanetWorldPosition(targetPlanet, solarTimeRef.current, speedFactor);
        navigateTo(pos.x, pos.y, 2.2);
      }
    } else {
      navigateTo(0, 0, 0.95);
      setSelectedObject(null);
    }
  }, [speedFactor, navigateTo]);

  // Transition: ENTER EARTH EXPLORATION VIEW
  const handleExploreEarth = useCallback(() => {
    setViewMode('earth');
    setSelectedConstellation(null);
    setSelectedObject(earthObject);
    navigateTo(0, 0, 1.0);
  }, [earthObject, navigateTo]);

  // Transition: ENTER MOON EXPLORATION VIEW
  const handleExploreMoon = useCallback(() => {
    setViewMode('moon');
    setSelectedConstellation(null);
    setSelectedObject(MOON_DATA);
    navigateTo(0, 0, 1.0);
  }, [navigateTo]);

  // Transition: BACK TO EARTH
  const handleBackToEarth = useCallback(() => {
    setViewMode('earth');
    setSelectedConstellation(null);
    setSelectedObject(earthObject);
    navigateTo(0, 0, 1.0);
  }, [earthObject, navigateTo]);

  // Transition: BACK TO SOLAR SYSTEM
  const handleBackToSolarSystem = useCallback(() => {
    setViewMode('solar-system');
    setSelectedConstellation(null);
    setSelectedObject(earthObject);
    const pos = getPlanetWorldPosition(earthObject, solarTimeRef.current, speedFactor);
    navigateTo(pos.x, pos.y, 2.0);
  }, [earthObject, speedFactor, navigateTo]);

  // Transition: BACK TO UNIVERSE MAP
  const handleBackToUniverse = useCallback(() => {
    setViewMode('universe');
    navigateTo(0, 0, DEFAULT_ZOOM);
    setSelectedObject(null);
    setSelectedConstellation(null);
    setHoveredObject(null);
  }, [navigateTo]);

  // Transition: ENTER BLACK HOLE VIEW (Phase U7)
  const handleExploreBlackHole = useCallback((targetBH = null) => {
    let bh = targetBH;
    if (!bh) {
      if (selectedObject?.category === 'BLACK_HOLE') {
        bh = selectedObject;
      } else {
        bh = BLACK_HOLES_CATALOG[0];
      }
    }
    setBlackHoleObject(bh);
    setSelectedObject(bh);
    setSelectedConstellation(null);
    setViewMode('black-hole');
    navigateTo(0, 0, 1.0, true);
    setIsModalOpen(false);
  }, [selectedObject, navigateTo]);

  // Transition: BACK TO BLACK HOLE
  const handleBackToBlackHole = useCallback(() => {
    setViewMode('black-hole');
    navigateTo(0, 0, 1.0);
  }, [navigateTo]);

  // Guided Cosmic Discovery Mode (Phase U11)
  const handleStartDiscovery = useCallback((category = null) => {
    const cat = category || discoveryCategory;
    setIsDiscoveryOpen(true);
    setIsDiscoveryScanning(true);

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const scanDuration = prefersReducedMotion ? 250 : 1200;

    const target = selectCuratedDiscovery(cat, selectedObject?.id);
    setDiscoveredObject(target);

    setTimeout(() => {
      setIsDiscoveryScanning(false);
      setDiscoveryCount(getSessionDiscoveryCount());
      if (target) {
        if (target.isConstellation || target.category === 'CONSTELLATION') {
          if (viewMode !== 'universe') setViewMode('universe');
          handleSelectConstellation(target, true);
        } else if (target.id === 'moon') {
          handleExploreMoon();
        } else if (target.id === 'earth') {
          handleExploreEarth();
        } else if (target.category === 'PLANET' || target.isSun || target.id === 'sun') {
          handleEnterSolarSystem(target);
        } else {
          if (viewMode !== 'universe') setViewMode('universe');
          handleSelectObject(target, true);
        }
      }
    }, scanDuration);
  }, [discoveryCategory, selectedObject, viewMode, handleSelectConstellation, handleExploreMoon, handleExploreEarth, handleEnterSolarSystem, handleSelectObject]);

  const handleDiscoverAnother = useCallback(() => {
    handleStartDiscovery(discoveryCategory);
  }, [handleStartDiscovery, discoveryCategory]);

  const handleCloseDiscovery = useCallback(() => {
    setIsDiscoveryOpen(false);
    setIsDiscoveryScanning(false);
  }, []);

  const handleDiscoverRandom = handleStartDiscovery;

  // Reset view to origin
  const handleResetView = useCallback(() => {
    if (viewMode === 'black-hole') {
      navigateTo(0, 0, 1.0);
    } else if (viewMode === 'solar-system') {
      navigateTo(0, 0, 0.95);
    } else if (viewMode === 'earth' || viewMode === 'moon') {
      navigateTo(0, 0, 1.0);
    } else if (selectedConstellation) {
      handleSelectConstellation(selectedConstellation, true);
    } else {
      navigateTo(0, 0, DEFAULT_ZOOM);
    }
  }, [viewMode, selectedConstellation, handleSelectConstellation, navigateTo]);

  // Zoom controls
  const handleZoomIn = useCallback(() => {
    const newZoom = clamp(targetCameraRef.current.zoom * 1.35, MIN_ZOOM, MAX_ZOOM);
    targetCameraRef.current.zoom = newZoom;
  }, []);

  const handleZoomOut = useCallback(() => {
    const newZoom = clamp(targetCameraRef.current.zoom / 1.35, MIN_ZOOM, MAX_ZOOM);
    targetCameraRef.current.zoom = newZoom;
  }, []);

  // Center on current selected object
  const handleCenterSelected = useCallback(() => {
    if (selectedObject) {
      handleSelectObject(selectedObject, true);
    }
  }, [selectedObject, handleSelectObject]);

  // Solar System Play / Pause & Speed controls
  const handleTogglePlay = useCallback(() => {
    setIsPlaying((prev) => !prev);
  }, []);

  const handleChangeSpeed = useCallback(() => {
    setSpeedFactor((prev) => {
      if (prev === 0.5) return 1.0;
      if (prev === 1.0) return 2.0;
      return 0.5;
    });
  }, []);

  const handleToggleOrbits = useCallback(() => {
    setShowOrbits((prev) => !prev);
  }, []);

  // Earth Toggles
  const handleToggleEarthRotation = useCallback(() => {
    setIsEarthRotating((prev) => !prev);
  }, []);

  const handleToggleMoonRotation = useCallback(() => {
    setIsMoonRotating((prev) => !prev);
  }, []);

  // Context-aware Back navigation (Phase U10)
  const handleHudBack = useCallback(() => {
    if (viewMode === 'moon') {
      handleBackToEarth();
    } else if (viewMode === 'earth') {
      handleBackToSolarSystem();
    } else if (viewMode === 'solar-system') {
      if (selectedObject && selectedObject.id !== 'sun') {
        setSelectedObject(null);
        navigateTo(0, 0, 0.95);
      } else {
        handleBackToUniverse();
      }
    } else if (viewMode === 'black-hole') {
      handleBackToUniverse();
    } else if (selectedConstellation) {
      if (selectedObject) {
        setSelectedObject(null);
        handleSelectConstellation(selectedConstellation, true);
      } else {
        handleBackToUniverse();
      }
    } else if (selectedObject) {
      setSelectedObject(null);
    }
  }, [viewMode, selectedObject, selectedConstellation, handleBackToEarth, handleBackToSolarSystem, handleBackToUniverse, handleSelectConstellation, navigateTo]);

  // Visible object count telemetry (Phase U10)
  const visibleObjectsCount = useMemo(() => {
    if (viewMode === 'solar-system') {
      return 9; // 8 major planets + central Sun
    }
    if (viewMode === 'earth') {
      return 2; // Earth + Moon
    }
    if (viewMode === 'moon') {
      return 1; // Lunar Observatory
    }
    if (viewMode === 'black-hole') {
      return 1; // Active Black Hole System
    }
    if (selectedConstellation) {
      return selectedConstellation.mainStars?.length || 8;
    }

    const canvas = canvasRef.current;
    if (!canvas) return ALL_CELESTIAL_OBJECTS.length;

    const width = canvas.width / (window.devicePixelRatio || 1);
    const height = canvas.height / (window.devicePixelRatio || 1);
    const cam = cameraRef.current;

    let count = 0;
    for (const obj of ALL_CELESTIAL_OBJECTS) {
      if (activeCategory !== 'ALL' && activeCategory !== 'CONSTELLATIONS' && obj.category !== activeCategory) {
        continue;
      }
      const sx = (obj.x - cam.x) * cam.zoom + width / 2;
      const sy = (obj.y - cam.y) * cam.zoom + height / 2;
      if (sx >= -40 && sx <= width + 40 && sy >= -40 && sy <= height + 40) {
        count++;
      }
    }
    return Math.max(1, count);
  }, [viewMode, selectedConstellation, activeCategory, currentZoom]);

  // Open full details modal (Universal Object Details System)
  const handleOpenFullModal = useCallback((obj) => {
    setActiveModalObject(obj);
    setIsModalOpen(true);
    if (onOpenExternalStar && obj.isStar) {
      onOpenExternalStar(obj);
    }
  }, [onOpenExternalStar]);

  // Modal previous / next navigation across active objects
  const activeDataset = useMemo(() => {
    if (viewMode === 'black-hole') {
      return BLACK_HOLES_CATALOG;
    }
    if (viewMode === 'earth' || viewMode === 'moon') {
      return [earthObject, MOON_DATA];
    }
    return viewMode === 'solar-system' ? SOLAR_SYSTEM_DATA : ALL_CELESTIAL_OBJECTS;
  }, [viewMode, earthObject]);

  const handlePreviousModalObject = useCallback(() => {
    if (!activeModalObject) return;
    const currentIndex = activeDataset.findIndex((s) => s.id === activeModalObject.id);
    const prevIndex = (currentIndex - 1 + activeDataset.length) % activeDataset.length;
    const nextObj = activeDataset[prevIndex];
    setActiveModalObject(nextObj);
    handleSelectObject(nextObj, true);
  }, [activeModalObject, activeDataset, handleSelectObject]);

  const handleNextModalObject = useCallback(() => {
    if (!activeModalObject) return;
    const currentIndex = activeDataset.findIndex((s) => s.id === activeModalObject.id);
    const nextIndex = (currentIndex + 1) % activeDataset.length;
    const nextObj = activeDataset[nextIndex];
    setActiveModalObject(nextObj);
    handleSelectObject(nextObj, true);
  }, [activeModalObject, activeDataset, handleSelectObject]);

  // Locate on map trigger from within modal or inspector
  const handleLocateOnMap = useCallback((obj) => {
    setIsModalOpen(false);
    if (
      obj.category === 'BLACK_HOLE' ||
      obj.category === 'STAR' ||
      obj.category === 'WHITE_DWARF' ||
      obj.category === 'NEUTRON_STAR' ||
      obj.category === 'PULSAR' ||
      obj.category === 'NEBULA' ||
      obj.category === 'STAR_CLUSTER' ||
      obj.category === 'GALAXY'
    ) {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectObject(obj, true);
    } else if (obj.id === 'moon') {
      handleExploreMoon();
    } else if (obj.id === 'earth') {
      handleExploreEarth();
    } else if (obj.category === 'PLANET' || obj.isSun || obj.id === 'sun') {
      handleEnterSolarSystem(obj);
    } else {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectObject(obj, true);
    }
  }, [viewMode, handleExploreMoon, handleExploreEarth, handleEnterSolarSystem, handleSelectObject]);

  // Switch modal target when clicking a related object
  const handleSelectRelatedObject = useCallback((obj) => {
    setActiveModalObject(obj);
    if (obj.category === 'BLACK_HOLE' && viewMode === 'black-hole') {
      handleExploreBlackHole(obj);
    } else if (obj.id === 'moon') {
      handleExploreMoon();
    } else if (obj.id === 'earth') {
      handleExploreEarth();
    } else if (obj.category === 'PLANET' || obj.isSun || obj.id === 'sun') {
      handleEnterSolarSystem(obj);
    } else {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectObject(obj, true);
    }
  }, [viewMode, handleExploreBlackHole, handleExploreMoon, handleExploreEarth, handleEnterSolarSystem, handleSelectObject]);

  // Handle global search selection
  const handleSearchSelect = useCallback((obj) => {
    if (obj.isConstellation || obj.category === 'CONSTELLATION') {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectConstellation(obj, true);
    } else if (obj.id === 'moon') {
      handleExploreMoon();
    } else if (obj.id === 'earth') {
      handleExploreEarth();
    } else if (obj.category === 'PLANET') {
      handleEnterSolarSystem(obj);
    } else if (obj.id === 'sun') {
      if (viewMode === 'solar-system') {
        handleSelectObject(obj, true);
      } else {
        handleEnterSolarSystem(obj);
      }
    } else {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectObject(obj, true);
    }
  }, [viewMode, handleSelectConstellation, handleExploreMoon, handleExploreEarth, handleEnterSolarSystem, handleSelectObject]);

  // Handle external constellation selection (e.g. from Constellations section "View on Universe Map")
  useEffect(() => {
    if (externalSelectedConstellation) {
      if (viewMode !== 'universe') {
        setViewMode('universe');
      }
      handleSelectConstellation(externalSelectedConstellation, true);
      if (onClearExternalConstellation) {
        onClearExternalConstellation();
      }
    }
  }, [externalSelectedConstellation, viewMode, handleSelectConstellation, onClearExternalConstellation]);

  // Listen for locate events dispatched from external sections
  useEffect(() => {
    const handleLocateEvent = (e) => {
      if (e.detail) {
        if (e.detail.isConstellation || e.detail.category === 'CONSTELLATION') {
          if (viewMode !== 'universe') {
            setViewMode('universe');
          }
          handleSelectConstellation(e.detail, true);
        } else if (e.detail.id === 'moon') {
          handleExploreMoon();
        } else if (e.detail.id === 'earth') {
          handleExploreEarth();
        } else if (e.detail.category === 'PLANET' || e.detail.isSun) {
          handleEnterSolarSystem(e.detail);
        } else {
          if (viewMode !== 'universe') {
            setViewMode('universe');
          }
          handleSelectObject(e.detail, true);
        }
      }
    };

    const handleConstellationEvent = (e) => {
      if (e.detail) {
        if (viewMode !== 'universe') {
          setViewMode('universe');
        }
        handleSelectConstellation(e.detail, true);
      }
    };

    window.addEventListener('stellar:locate-object', handleLocateEvent);
    window.addEventListener('stellar:locate-constellation', handleConstellationEvent);
    return () => {
      window.removeEventListener('stellar:locate-object', handleLocateEvent);
      window.removeEventListener('stellar:locate-constellation', handleConstellationEvent);
    };
  }, [viewMode, handleSelectConstellation, handleExploreMoon, handleExploreEarth, handleEnterSolarSystem, handleSelectObject]);

  // ==========================================
  // COSMIC COMPARE MODE (Phase U12)
  // ==========================================
  const handleOpenCompare = useCallback((objA = null, objB = null) => {
    setCompareObjectA(objA || selectedObject || null);
    setCompareObjectB(objB || null);
    setIsCompareOpen(true);
  }, [selectedObject]);

  const handleLocateFromCompare = useCallback((target) => {
    setIsCompareOpen(false);
    if (!target) return;
    handleLocateOnMap(target);
  }, [handleLocateOnMap]);

  // URL Hash Listener for deep linking (#compare=id&vs=id) & Custom Event
  useEffect(() => {
    const parseHash = () => {
      const hash = window.location.hash;
      if (!hash || !hash.includes('compare=')) return;

      const compareMatch = hash.match(/compare=([^&]+)/);
      const vsMatch = hash.match(/vs=([^&]+)/);

      if (compareMatch) {
        const idA = decodeURIComponent(compareMatch[1]);
        const objA = getCelestialObjectById(idA);
        const objB = vsMatch ? getCelestialObjectById(decodeURIComponent(vsMatch[1])) : null;

        if (objA) {
          setCompareObjectA(objA);
          setCompareObjectB(objB || null);
          setIsCompareOpen(true);
        }
      }
    };

    const handleCompareEvent = (e) => {
      if (e.detail) {
        handleOpenCompare(e.detail.objA || e.detail, e.detail.objB || null);
      }
    };

    parseHash();
    window.addEventListener('hashchange', parseHash);
    window.addEventListener('stellar:open-compare', handleCompareEvent);
    return () => {
      window.removeEventListener('hashchange', parseHash);
      window.removeEventListener('stellar:open-compare', handleCompareEvent);
    };
  }, [handleOpenCompare]);

  // ==========================================
  // COSMIC TIMELINE MODE (Phase U13)
  // ==========================================
  const handleOpenTimeline = useCallback((milestoneId = null) => {
    const timelineElem = document.getElementById('timeline');
    if (timelineElem) {
      timelineElem.scrollIntoView({ behavior: 'smooth' });
    }
    if (milestoneId) {
      window.dispatchEvent(
        new CustomEvent('stellar:open-timeline', { detail: milestoneId })
      );
    }
  }, []);

  // ==========================================
  // CANVAS RENDERING LOOP & ANIMATION
  // ==========================================
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId;

    const render = (time) => {
      // 1. Time delta calculation
      const delta = lastTimeRef.current ? Math.min(64, time - lastTimeRef.current) : 16;
      lastTimeRef.current = time;

      // Update simulation clocks
      if (isPlaying && viewMode === 'solar-system') {
        solarTimeRef.current += delta * speedFactor;
      }
      if (isEarthRotating && viewMode === 'earth') {
        earthRotationRef.current += delta * 0.00035;
        moonOrbitAngleRef.current += delta * 0.00012;
      }
      if (isMoonRotating && viewMode === 'moon') {
        moonRotationRef.current += delta * 0.00025;
      }
      if (isBlackHoleRotating && viewMode === 'black-hole') {
        blackHoleRotationRef.current += delta * 0.00065 * blackHoleSpeedFactor;
      }

      // 2. Camera smooth lerping
      const lerpSpeed = 0.12;
      const cam = cameraRef.current;
      const target = targetCameraRef.current;

      cam.x = lerp(cam.x, target.x, lerpSpeed);
      cam.y = lerp(cam.y, target.y, lerpSpeed);
      cam.zoom = lerp(cam.zoom, target.zoom, lerpSpeed);

      if (Math.abs(cam.zoom - currentZoom) > 0.05) {
        setCurrentZoom(cam.zoom);
      }

      // 3. Clear & Render View Layers
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);

      ctx.save();
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      if (viewMode === 'earth') {
        // ==================================================
        // PHASE U6: EARTH EXPLORATION VIEW
        // ==================================================
        drawEarthSceneBackground(ctx, width, height, cam, time);

        const cx = width / 2 + (0 - cam.x) * cam.zoom;
        const cy = height / 2 + (0 - cam.y) * cam.zoom;
        const earthR = Math.max(45, 115 * cam.zoom);

        // Magnetic Field Dipole Shield
        if (showMagneticField) {
          drawEarthMagneticField(ctx, cx, cy, earthR, time);
        }

        // Rotating Earth Globe
        drawInteractiveEarth(
          ctx,
          cx,
          cy,
          earthR,
          earthRotationRef.current,
          {
            showAtmosphere,
            showDayNight,
            isHovered: hoveredObject?.id === 'earth',
            isSelected: selectedObject?.id === 'earth',
          },
          time
        );

        // Orbiting Moon
        const moonPos = drawEarthOrbitingMoon(
          ctx,
          cx,
          cy,
          earthR,
          moonOrbitAngleRef.current,
          {
            showOrbit: showMoonOrbit,
            isHovered: hoveredObject?.id === 'moon',
            isSelected: selectedObject?.id === 'moon',
          },
          time
        );
        lastMoonScreenPosRef.current = moonPos;
      } else if (viewMode === 'moon') {
        // ==================================================
        // PHASE U6: MOON EXPLORATION VIEW
        // ==================================================
        drawEarthSceneBackground(ctx, width, height, cam, time);

        const cx = width / 2 + (0 - cam.x) * cam.zoom;
        const cy = height / 2 + (0 - cam.y) * cam.zoom - 20;
        const moonR = Math.max(50, 125 * cam.zoom);
        const phaseAngle = MOON_PHASES[activeMoonPhaseIndex]?.angle || 0;

        drawCloseUpMoon(
          ctx,
          cx,
          cy,
          moonR,
          moonRotationRef.current,
          phaseAngle,
          {
            isHovered: hoveredObject?.id === 'moon',
            isSelected: selectedObject?.id === 'moon',
          },
          time
        );
      } else if (viewMode === 'solar-system') {
        // ==================================================
        // PHASE U5: SOLAR SYSTEM VIEW
        // ==================================================
        drawSolarBackground(ctx, width, height, cam, time);

        drawSolarOrbits(
          ctx,
          width,
          height,
          cam,
          SOLAR_SYSTEM_DATA,
          showOrbits,
          hoveredObject?.id,
          selectedObject?.id
        );

        drawCentralSun(
          ctx,
          width,
          height,
          cam,
          sunObject,
          time,
          hoveredObject?.id === 'sun',
          selectedObject?.id === 'sun'
        );

        drawPlanets(
          ctx,
          width,
          height,
          cam,
          SOLAR_SYSTEM_DATA,
          solarTimeRef.current,
          speedFactor,
          hoveredObject?.id,
          selectedObject?.id
        );
      } else if (viewMode === 'black-hole') {
        // ==================================================
        // PHASE U7: BLACK HOLE EXPERIENCE
        // ==================================================
        drawBlackHoleBackground(ctx, width, height, cam, time);

        const cx = width / 2 + (0 - cam.x) * cam.zoom;
        const cy = height / 2 + (0 - cam.y) * cam.zoom;

        const bhType = (blackHoleObject?.blackHoleType || 'supermassive').toUpperCase();
        const typeConfig = BLACK_HOLE_TYPES[bhType] || BLACK_HOLE_TYPES.SUPERMASSIVE;
        const scaleMult = typeConfig.visualScale;

        const shadowR = Math.max(30, 85 * cam.zoom * scaleMult);
        const diskOuterR = shadowR * typeConfig.diskWidth;

        // 1. Background stars with Gravitational Lensing
        drawLensedStars(ctx, width, height, cx, cy, shadowR, showLensing, time);

        // 2. Collimated Bipolar Relativistic Jets
        if (showJets && (blackHoleObject?.hasJets ?? false)) {
          drawBipolarJets(ctx, cx, cy, shadowR, time, true);
        }

        // 3. Warped Back Accretion Disk (Over and under the horizon via lensing)
        drawWarpedBackDisk(ctx, cx, cy, shadowR, diskOuterR, blackHoleRotationRef.current, {
          showAccretionDisk,
          isHighlighted: activeHotspotId === 'accretion-disk' || activeHotspotId === 'gravitational-lensing',
        });

        // 4. Razor-Sharp Golden Photon Ring
        if (showPhotonRing) {
          drawPhotonRing(ctx, cx, cy, shadowR, time, activeHotspotId === 'photon-ring');
        }

        // 5. Pitch-Black Event Horizon Void
        drawEventHorizon(ctx, cx, cy, shadowR, activeHotspotId === 'event-horizon');

        // 6. Front Relativistic Accretion Disk (Doppler asymmetry & rotating filaments)
        drawFrontAccretionDisk(ctx, cx, cy, shadowR, diskOuterR, blackHoleRotationRef.current, {
          showAccretionDisk,
          isHighlighted: activeHotspotId === 'accretion-disk',
        });

        // 7. Hotspot HUD Callouts
        if (showHotspots) {
          drawHotspotCallouts(ctx, cx, cy, shadowR, diskOuterR, activeHotspotId, hoveredHotspotId, true);
        }
      } else {
        // ==================================================
        // PHASE U2-U4 & U8: UNIVERSE MAP VIEW
        // ==================================================
        drawBackground(ctx, width, height, cam);
        drawBackgroundStars(ctx, width, height, cam, time);
        drawConstellationRegionAura(ctx, width, height, cam, selectedConstellation, time);
        drawConstellationLines(ctx, width, height, cam, starMap, activeCategory, selectedConstellation?.id);
        drawConstellationLabels(ctx, width, height, cam, selectedConstellation?.id);
        drawCelestialObjects(
          ctx,
          width,
          height,
          cam,
          ALL_CELESTIAL_OBJECTS,
          selectedObject?.id,
          hoveredObject?.id,
          activeCategory,
          time,
          selectedConstellation?.id
        );

        if (hoveredObject && (!selectedObject || hoveredObject.id !== selectedObject.id)) {
          drawHoverRing(ctx, width, height, cam, hoveredObject);
        }
        if (selectedObject) {
          drawSelectionReticle(ctx, width, height, cam, selectedObject, time);
        }
      }

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [
    viewMode,
    starMap,
    sunObject,
    earthObject,
    selectedObject,
    selectedConstellation,
    hoveredObject,
    currentZoom,
    activeCategory,
    isPlaying,
    speedFactor,
    showOrbits,
    isEarthRotating,
    showAtmosphere,
    showDayNight,
    showMoonOrbit,
    showMagneticField,
    isMoonRotating,
    activeMoonPhaseIndex,
    blackHoleObject,
    isBlackHoleRotating,
    blackHoleSpeedFactor,
    showAccretionDisk,
    showLensing,
    showPhotonRing,
    showJets,
    showHotspots,
    activeHotspotId,
    hoveredHotspotId,
  ]);

  // ==========================================
  // RESPONSIVE CANVAS RESIZE
  // ==========================================
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const rect = container.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;

      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const resizeObserver = new ResizeObserver(handleResize);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      resizeObserver.disconnect();
    };
  }, []);

  // ==========================================
  // MOUSE & POINTER INTERACTION HANDLERS
  // ==========================================
  const handlePointerDown = (e) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    dragStartCameraRef.current = {
      x: cameraRef.current.x,
      y: cameraRef.current.y,
    };
    movedDistanceRef.current = 0;

    const canvas = canvasRef.current;
    if (canvas) {
      canvas.setPointerCapture(e.pointerId);
    }
  };

  const handlePointerMove = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;

    if (isDraggingRef.current) {
      const dx = (e.clientX - dragStartRef.current.x) / cameraRef.current.zoom;
      const dy = (e.clientY - dragStartRef.current.y) / cameraRef.current.zoom;

      movedDistanceRef.current += Math.hypot(e.movementX || 0, e.movementY || 0);

      // In Earth, Moon, or Black Hole view, dragging rotates the view directly!
      if (viewMode === 'earth') {
        earthRotationRef.current += (e.movementX || 0) * 0.007;
      } else if (viewMode === 'moon') {
        moonRotationRef.current += (e.movementX || 0) * 0.007;
      } else if (viewMode === 'black-hole') {
        blackHoleRotationRef.current += (e.movementX || 0) * 0.007;
      } else {
        const newX = dragStartCameraRef.current.x - dx;
        const newY = dragStartCameraRef.current.y - dy;

        cameraRef.current.x = newX;
        cameraRef.current.y = newY;
        targetCameraRef.current.x = newX;
        targetCameraRef.current.y = newY;
      }
    } else {
      // Hover hit-test according to active view mode
      let hit = null;
      if (viewMode === 'black-hole') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom;
        const bhType = (blackHoleObject?.blackHoleType || 'supermassive').toUpperCase();
        const typeConfig = BLACK_HOLE_TYPES[bhType] || BLACK_HOLE_TYPES.SUPERMASSIVE;
        const shadowR = Math.max(30, 85 * cameraRef.current.zoom * typeConfig.visualScale);
        const diskOuterR = shadowR * typeConfig.diskWidth;

        const feature = getBlackHoleHitFeature(screenX, screenY, cx, cy, shadowR, diskOuterR);
        setHoveredHotspotId(feature);
        if (feature) {
          hit = { ...blackHoleObject, feature };
        }
      } else if (viewMode === 'earth') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom;
        const earthR = Math.max(45, 115 * cameraRef.current.zoom);
        const moonPos = lastMoonScreenPosRef.current;
        const moonR = moonPos ? moonPos.radius : 18;

        const hitTarget = hitTestEarthSystem(screenX, screenY, { x: cx, y: cy }, earthR, moonPos, moonR);
        if (hitTarget === 'moon') hit = MOON_DATA;
        else if (hitTarget === 'earth') hit = earthObject;
      } else if (viewMode === 'moon') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom - 20;
        const moonR = Math.max(50, 125 * cameraRef.current.zoom);
        if (Math.hypot(screenX - cx, screenY - cy) <= moonR + 10) {
          hit = MOON_DATA;
        }
      } else if (viewMode === 'solar-system') {
        hit = hitTestSolarObject(
          screenX,
          screenY,
          SOLAR_SYSTEM_DATA,
          cameraRef.current,
          rect.width,
          rect.height,
          solarTimeRef.current,
          speedFactor,
          26
        );
      } else {
        hit = hitTestStar(
          screenX,
          screenY,
          ALL_CELESTIAL_OBJECTS,
          cameraRef.current,
          rect.width,
          rect.height,
          26
        );
      }

      setHoveredObject(hit);

      if (canvas) {
        canvas.style.cursor = hit ? 'pointer' : 'grab';
      }
    }
  };

  const handlePointerUp = (e) => {
    const canvas = canvasRef.current;
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }

    if (movedDistanceRef.current < 8) {
      const rect = canvas.getBoundingClientRect();
      const screenX = e.clientX - rect.left;
      const screenY = e.clientY - rect.top;

      let hit = null;
      if (viewMode === 'black-hole') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom;
        const bhType = (blackHoleObject?.blackHoleType || 'supermassive').toUpperCase();
        const typeConfig = BLACK_HOLE_TYPES[bhType] || BLACK_HOLE_TYPES.SUPERMASSIVE;
        const shadowR = Math.max(30, 85 * cameraRef.current.zoom * typeConfig.visualScale);
        const diskOuterR = shadowR * typeConfig.diskWidth;

        const feature = getBlackHoleHitFeature(screenX, screenY, cx, cy, shadowR, diskOuterR);
        if (feature) {
          setActiveHotspotId(feature);
        }
      } else if (viewMode === 'earth') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom;
        const earthR = Math.max(45, 115 * cameraRef.current.zoom);
        const moonPos = lastMoonScreenPosRef.current;
        const moonR = moonPos ? moonPos.radius : 18;

        const hitTarget = hitTestEarthSystem(screenX, screenY, { x: cx, y: cy }, earthR, moonPos, moonR);
        if (hitTarget === 'moon') hit = MOON_DATA;
        else if (hitTarget === 'earth') hit = earthObject;
      } else if (viewMode === 'moon') {
        const cx = rect.width / 2 + (0 - cameraRef.current.x) * cameraRef.current.zoom;
        const cy = rect.height / 2 + (0 - cameraRef.current.y) * cameraRef.current.zoom - 20;
        const moonR = Math.max(50, 125 * cameraRef.current.zoom);
        if (Math.hypot(screenX - cx, screenY - cy) <= moonR + 10) {
          hit = MOON_DATA;
        }
      } else if (viewMode === 'solar-system') {
        hit = hitTestSolarObject(
          screenX,
          screenY,
          SOLAR_SYSTEM_DATA,
          cameraRef.current,
          rect.width,
          rect.height,
          solarTimeRef.current,
          speedFactor,
          28
        );
      } else {
        hit = hitTestStar(
          screenX,
          screenY,
          ALL_CELESTIAL_OBJECTS,
          cameraRef.current,
          rect.width,
          rect.height,
          28
        );
      }

      if (hit) {
        handleSelectObject(hit, true);
      }
    }

    isDraggingRef.current = false;
    touchDistanceRef.current = null;
  };

  // Wheel zoom handler
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleWheel = (e) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const cursorX = e.clientX - rect.left;
      const cursorY = e.clientY - rect.top;

      const cam = cameraRef.current;
      const currentZ = cam.zoom;

      const worldPos = screenToWorld(cursorX, cursorY, cam, rect.width, rect.height);
      const zoomFactor = Math.exp(-e.deltaY * 0.0018);
      const newZoom = clamp(currentZ * zoomFactor, MIN_ZOOM, MAX_ZOOM);

      const newCamX = worldPos.x - (cursorX - rect.width / 2) / newZoom;
      const newCamY = worldPos.y - (cursorY - rect.height / 2) / newZoom;

      targetCameraRef.current = {
        x: newCamX,
        y: newCamY,
        zoom: newZoom,
      };
      cameraRef.current = {
        x: newCamX,
        y: newCamY,
        zoom: newZoom,
      };
      setCurrentZoom(newZoom);
    };

    canvas.addEventListener('wheel', handleWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', handleWheel);
  }, []);

  // Touch pinch-to-zoom
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleTouchMove = (e) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const t1 = e.touches[0];
        const t2 = e.touches[1];
        const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);

        if (touchDistanceRef.current !== null) {
          const ratio = dist / touchDistanceRef.current;
          const newZoom = clamp(
            targetCameraRef.current.zoom * ratio,
            MIN_ZOOM,
            MAX_ZOOM
          );
          targetCameraRef.current.zoom = newZoom;
          cameraRef.current.zoom = newZoom;
          setCurrentZoom(newZoom);
        }
        touchDistanceRef.current = dist;
      }
    };

    const handleTouchEnd = () => {
      touchDistanceRef.current = null;
    };

    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd);
    return () => {
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  // Keyboard accessibility & Shortcuts (Phase U10)
  const handleKeyDown = (e) => {
    const panStep = 60 / cameraRef.current.zoom;
    if (e.key === 'ArrowLeft') {
      if (viewMode === 'earth') earthRotationRef.current -= 0.08;
      else if (viewMode === 'moon') moonRotationRef.current -= 0.08;
      else if (viewMode === 'black-hole') blackHoleRotationRef.current -= 0.08;
      else targetCameraRef.current.x -= panStep;
    } else if (e.key === 'ArrowRight') {
      if (viewMode === 'earth') earthRotationRef.current += 0.08;
      else if (viewMode === 'moon') moonRotationRef.current += 0.08;
      else if (viewMode === 'black-hole') blackHoleRotationRef.current += 0.08;
      else targetCameraRef.current.x += panStep;
    } else if (e.key === 'ArrowUp') {
      targetCameraRef.current.y -= panStep;
    } else if (e.key === 'ArrowDown') {
      targetCameraRef.current.y += panStep;
    } else if (e.key === '+' || e.key === '=') {
      handleZoomIn();
    } else if (e.key === '-' || e.key === '_') {
      handleZoomOut();
    } else if (e.key === 'r' || e.key === 'R') {
      handleResetView();
    } else if (e.key === 'c' || e.key === 'C') {
      if (selectedObject) handleCenterSelected();
    } else if (e.key === 'd' || e.key === 'D') {
      handleStartDiscovery();
    } else if (e.key === 'Escape') {
      if (isDiscoveryOpen) {
        handleCloseDiscovery();
      } else {
        setSelectedObject(null);
        if (isModalOpen) setIsModalOpen(false);
      }
    }
  };

  // Window-level Keyboard Shortcuts for quick exploration (Phase U10, U11)
  useEffect(() => {
    const handleGlobalKeyDown = (e) => {
      const targetTag = (e.target.tagName || '').toLowerCase();
      if (targetTag === 'input' || targetTag === 'textarea' || e.target.isContentEditable) {
        return;
      }

      if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        handleZoomIn();
      } else if (e.key === '-' || e.key === '_') {
        e.preventDefault();
        handleZoomOut();
      } else if (e.key === 'r' || e.key === 'R') {
        e.preventDefault();
        handleResetView();
      } else if (e.key === 'c' || e.key === 'C') {
        if (selectedObject) {
          e.preventDefault();
          handleCenterSelected();
        }
      } else if (e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        handleStartDiscovery();
      } else if (e.key === 'Escape') {
        if (isDiscoveryOpen) {
          e.preventDefault();
          handleCloseDiscovery();
          return;
        }
        if (selectedObject) {
          e.preventDefault();
          setSelectedObject(null);
        }
        if (isModalOpen) {
          e.preventDefault();
          setIsModalOpen(false);
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [handleZoomIn, handleZoomOut, handleResetView, handleCenterSelected, handleStartDiscovery, handleCloseDiscovery, selectedObject, isModalOpen, isDiscoveryOpen]);

  return (
    <section
      id="universe-map"
      className="relative w-full py-16 sm:py-24 bg-[#020308] border-b border-white/5 overflow-hidden"
      aria-label="Interactive Universe Map and Solar System"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-6 sm:mb-8">
          <div>
            {/* Hierarchical Breadcrumb Navigation */}
            <div className="flex flex-wrap items-center gap-2 mb-3">
              {viewMode === 'black-hole' ? (
                <div className="inline-flex items-center gap-1.5 p-1 rounded-xl bg-white/[0.03] border border-white/10 backdrop-blur-md text-xs font-mono">
                  <button
                    type="button"
                    onClick={handleBackToUniverse}
                    className="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    🌌 UNIVERSE
                  </button>
                  <span className="text-slate-600">/</span>
                  <span className="px-2.5 py-1 rounded-lg text-amber-300 font-semibold bg-amber-500/15 border border-amber-500/30">
                    🕳️ BLACK HOLES
                  </span>
                  <span className="text-slate-600">/</span>
                  <span className="px-2.5 py-1 rounded-lg text-white font-semibold">
                    {blackHoleObject?.name || 'Sagittarius A*'}
                  </span>
                </div>
              ) : viewMode === 'earth' || viewMode === 'moon' ? (
                <div className="inline-flex items-center gap-1.5 p-1 rounded-xl bg-white/[0.03] border border-white/10 backdrop-blur-md text-xs font-mono">
                  <button
                    type="button"
                    onClick={handleBackToUniverse}
                    className="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition-colors"
                  >
                    🌌 UNIVERSE
                  </button>
                  <span className="text-slate-600">/</span>
                  <button
                    type="button"
                    onClick={handleBackToSolarSystem}
                    className="px-2.5 py-1 rounded-lg text-amber-300 hover:text-white transition-colors"
                  >
                    🪐 SOLAR SYSTEM
                  </button>
                  <span className="text-slate-600">/</span>
                  <button
                    type="button"
                    onClick={handleBackToEarth}
                    className={`px-2.5 py-1 rounded-lg transition-colors ${
                      viewMode === 'earth'
                        ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/40 font-semibold'
                        : 'text-sky-300 hover:text-white'
                    }`}
                  >
                    🌍 EARTH
                  </button>
                  {viewMode === 'moon' && (
                    <>
                      <span className="text-slate-600">/</span>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-200/15 text-white border border-white/20 font-semibold">
                        🌕 MOON
                      </span>
                    </>
                  )}
                </div>
              ) : (
                <div className="inline-flex items-center p-1 rounded-xl bg-white/[0.03] border border-white/10 backdrop-blur-md">
                  <button
                    type="button"
                    onClick={handleBackToUniverse}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer ${
                      viewMode === 'universe' && !selectedConstellation
                        ? 'bg-cyan-500/20 border border-cyan-400/50 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span>UNIVERSE ATLAS</span>
                  </button>
                  {selectedConstellation && (
                    <>
                      <span className="text-slate-600">/</span>
                      <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 text-xs font-mono font-semibold shadow-[0_0_12px_rgba(6,182,212,0.25)]">
                        <span>✨</span>
                        <span>{selectedConstellation.name.toUpperCase()}</span>
                      </span>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => handleEnterSolarSystem()}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer ${
                      viewMode === 'solar-system'
                        ? 'bg-amber-500/20 border border-amber-400/50 text-amber-200 shadow-[0_0_15px_rgba(251,191,36,0.3)]'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-amber-300">🪐</span>
                    <span>SOLAR SYSTEM</span>
                  </button>
                </div>
              )}
            </div>

            {/* Title */}
            <h2 className="text-3xl sm:text-5xl font-display font-bold tracking-tight text-white leading-tight">
              {viewMode === 'black-hole' ? (
                <>
                  THE{' '}
                  <span className="bg-gradient-to-r from-amber-400 via-orange-300 to-rose-400 bg-clip-text text-transparent">
                    BLACK HOLE
                  </span>
                </>
              ) : viewMode === 'moon' ? (
                <>
                  THE{' '}
                  <span className="bg-gradient-to-r from-slate-200 via-white to-slate-400 bg-clip-text text-transparent">
                    MOON // LUNA
                  </span>
                </>
              ) : viewMode === 'earth' ? (
                <>
                  PLANET{' '}
                  <span className="bg-gradient-to-r from-cyan-300 via-sky-200 to-emerald-300 bg-clip-text text-transparent">
                    EARTH
                  </span>
                </>
              ) : viewMode === 'solar-system' ? (
                <>
                  OUR{' '}
                  <span className="bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500 bg-clip-text text-transparent">
                    SOLAR SYSTEM
                  </span>
                </>
              ) : selectedConstellation ? (
                <>
                  CONSTELLATION{' '}
                  <span className="bg-gradient-to-r from-cyan-300 via-sky-200 to-blue-400 bg-clip-text text-transparent">
                    {selectedConstellation.name.toUpperCase()}
                  </span>
                </>
              ) : (
                <>
                  EXPLORE THE{' '}
                  <span className="bg-gradient-to-r from-cyan-300 via-sky-200 to-indigo-300 bg-clip-text text-transparent">
                    UNIVERSE
                  </span>
                </>
              )}
            </h2>

            {/* Subtitle */}
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl font-sans">
              {viewMode === 'black-hole'
                ? `Relativistic spacetime distortion, event horizon shadow, and superheated accretion plasma around ${blackHoleObject?.name || 'Sagittarius A*'}.`
                : viewMode === 'moon'
                ? "Earth's tidally locked satellite featuring lunar maria (Tranquility Base), impact craters (Tycho, Copernicus), and interactive phases."
                : viewMode === 'earth'
                ? 'Interactive rotating globe with day/night terminator, atmospheric scattering, swirly clouds, and Moon orbit.'
                : viewMode === 'solar-system'
                ? 'Interactive planetary orbits around the Sun: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.'
                : selectedConstellation
                ? `Exploring the ${selectedConstellation.name} (${selectedConstellation.commonTitle}) region — apparent celestial pattern observed from Earth.`
                : 'Navigate through an interactive map of stars, constellations, black holes, nebulae, pulsars, star clusters, and galaxies.'}
            </p>
          </div>

          {/* Scientific Disclaimer Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.02] border border-white/10 text-[11px] font-mono text-slate-400">
            <span className="text-amber-400 text-xs">ℹ</span>
            <span>
              {viewMode === 'black-hole'
                ? 'Scientific visualization — not to physical scale.'
                : viewMode === 'moon' || viewMode === 'earth'
                ? 'Illustrative educational visualization.'
                : selectedConstellation
                ? 'Constellation lines represent apparent patterns in Earth’s sky; connected stars are not necessarily physically close.'
                : 'Illustrative visualization — not to physical scale.'}
            </span>
          </div>
        </div>

        {/* Category Filters Bar & Constellation Quick Selector (Universe View Only) */}
        {viewMode === 'universe' && (
          <div className="mb-4 space-y-2.5">
            <CategoryFilter
              activeFilter={activeCategory}
              onSelectFilter={(catId) => setActiveCategory(catId)}
            />
            <ConstellationBar
              selectedConstellationId={selectedConstellation?.id}
              onSelectConstellation={(id) => handleSelectConstellation(id, true)}
            />
          </div>
        )}

        {/* Map Interactive Canvas Shell */}
        <div
          ref={containerRef}
          tabIndex={0}
          onKeyDown={handleKeyDown}
          aria-label="Interactive astronomical canvas. Drag to rotate or pan, scroll to zoom, click to select."
          className="relative w-full h-[540px] sm:h-[620px] lg:h-[700px] rounded-2xl overflow-hidden border border-white/10 bg-[#020308] shadow-[0_20px_60px_rgba(0,0,0,0.85)] focus:outline-none focus:ring-1 focus:ring-cyan-400/40 select-none group"
        >
          {/* Main 2D Canvas */}
          <canvas
            ref={canvasRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="w-full h-full block cursor-grab active:cursor-grabbing touch-none"
          />

          {/* Top Control Bar: Search & Discovery / Mode Controls */}
          <div className="absolute top-4 left-4 right-4 z-30 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
            {/* Global Search across all stars, deep-sky objects, planets, and Moon */}
            <div className="pointer-events-auto flex items-center gap-2">
              <UniverseSearch
                objects={ALL_SEARCHABLE_OBJECTS}
                onSelectObject={handleSearchSelect}
              />
              <button
                type="button"
                onClick={() => handleStartDiscovery()}
                aria-label="Discover something in the universe (Hotkey: D)"
                title="Let the universe choose your next destination (D)"
                className="hidden sm:flex items-center gap-1.5 h-8 px-3 rounded-lg bg-gradient-to-r from-cyan-950/80 via-blue-950/80 to-indigo-950/80 hover:from-cyan-900/90 hover:to-blue-900/90 backdrop-blur-md border border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white shadow-[0_0_15px_rgba(6,182,212,0.2)] active:scale-95 transition-all text-xs font-mono select-none cursor-pointer"
              >
                <span className="text-amber-300">✦</span>
                <span>DISCOVER SOMETHING</span>
              </button>
            </div>

            {/* Top Right Controls Deck depending on viewMode */}
            <div className="pointer-events-auto">
              {viewMode === 'black-hole' ? (
                <BlackHoleControls
                  currentObject={blackHoleObject}
                  onSelectObject={(bh) => {
                    setBlackHoleObject(bh);
                    setSelectedObject(bh);
                    navigateTo(0, 0, 1.0);
                  }}
                  isPlaying={isBlackHoleRotating}
                  onTogglePlay={() => setIsBlackHoleRotating((p) => !p)}
                  speedFactor={blackHoleSpeedFactor}
                  onChangeSpeed={() =>
                    setBlackHoleSpeedFactor((p) => (p === 0.5 ? 1.0 : p === 1.0 ? 2.0 : 0.5))
                  }
                  onResetView={handleResetView}
                  showAccretionDisk={showAccretionDisk}
                  onToggleAccretionDisk={() => setShowAccretionDisk((p) => !p)}
                  showLensing={showLensing}
                  onToggleLensing={() => setShowLensing((p) => !p)}
                  showPhotonRing={showPhotonRing}
                  onTogglePhotonRing={() => setShowPhotonRing((p) => !p)}
                  showJets={showJets}
                  onToggleJets={() => setShowJets((p) => !p)}
                  showHotspots={showHotspots}
                  onToggleHotspots={() => setShowHotspots((p) => !p)}
                />
              ) : viewMode === 'moon' ? (
                <MoonControls
                  onBackToEarth={handleBackToEarth}
                  onBackToSolarSystem={handleBackToSolarSystem}
                  onBackToUniverse={handleBackToUniverse}
                  isRotating={isMoonRotating}
                  onToggleRotation={handleToggleMoonRotation}
                  onZoomIn={handleZoomIn}
                  onZoomOut={handleZoomOut}
                  onResetView={handleResetView}
                />
              ) : viewMode === 'earth' ? (
                <EarthControls
                  onBackToSolarSystem={handleBackToSolarSystem}
                  onExploreMoon={handleExploreMoon}
                  isRotating={isEarthRotating}
                  onToggleRotation={handleToggleEarthRotation}
                  showAtmosphere={showAtmosphere}
                  onToggleAtmosphere={() => setShowAtmosphere((p) => !p)}
                  showDayNight={showDayNight}
                  onToggleDayNight={() => setShowDayNight((p) => !p)}
                  showMoonOrbit={showMoonOrbit}
                  onToggleMoonOrbit={() => setShowMoonOrbit((p) => !p)}
                  showMagneticField={showMagneticField}
                  onToggleMagneticField={() => setShowMagneticField((p) => !p)}
                  onZoomIn={handleZoomIn}
                  onZoomOut={handleZoomOut}
                  onResetView={handleResetView}
                />
              ) : viewMode === 'solar-system' ? (
                <SolarSystemControls
                  onBackToUniverse={handleBackToUniverse}
                  isPlaying={isPlaying}
                  onTogglePlay={handleTogglePlay}
                  speedFactor={speedFactor}
                  onChangeSpeed={handleChangeSpeed}
                  showOrbits={showOrbits}
                  onToggleOrbits={handleToggleOrbits}
                  onZoomIn={handleZoomIn}
                  onZoomOut={handleZoomOut}
                  onResetView={handleResetView}
                  onSelectPlanet={(planet) => handleSelectObject(planet, true)}
                  selectedPlanetId={selectedObject?.id}
                  planets={SOLAR_SYSTEM_DATA}
                />
              ) : (
                <UniverseControls
                  onZoomIn={handleZoomIn}
                  onZoomOut={handleZoomOut}
                  onResetView={handleResetView}
                  onCenterSelected={handleCenterSelected}
                  onDiscoverRandom={handleDiscoverRandom}
                  onOpenCompare={() => handleOpenCompare(selectedObject || null, null)}
                  onOpenTimeline={() => handleOpenTimeline()}
                  hasSelectedStar={!!selectedObject}
                />
              )}
            </div>
          </div>

          {/* COSMIC NAVIGATION HUD (Phase U10) */}
          <div className="absolute top-16 left-4 z-20 pointer-events-none max-w-[calc(100%-2rem)]">
            <CosmicNavigationHud
              viewMode={viewMode}
              selectedObject={selectedObject}
              selectedConstellation={selectedConstellation}
              blackHoleObject={blackHoleObject}
              currentZoom={currentZoom}
              visibleObjectsCount={visibleObjectsCount}
              onZoomIn={handleZoomIn}
              onZoomOut={handleZoomOut}
              onResetView={handleResetView}
              onCenterSelected={handleCenterSelected}
              onDiscover={handleStartDiscovery}
              onCompare={() => handleOpenCompare(selectedObject || null, null)}
              onOpenTimeline={() => handleOpenTimeline()}
              onBack={handleHudBack}
              onNavigateToUniverse={handleBackToUniverse}
              onNavigateToSolarSystem={() => handleEnterSolarSystem()}
              onNavigateToEarth={handleExploreEarth}
              onNavigateToMoon={handleExploreMoon}
              onNavigateToConstellation={(c) => handleSelectConstellation(c, true)}
              onNavigateToObject={(obj) => handleSelectObject(obj, true)}
              className="pointer-events-auto"
            />
          </div>

          {/* Black Hole Interactive Information & Educational Hotspots Deck */}
          {viewMode === 'black-hole' && (
            <div className="absolute top-16 sm:top-20 right-4 z-20 pointer-events-auto max-h-[calc(100%-8rem)] overflow-y-auto no-scrollbar">
              <BlackHoleHotspots
                activeHotspotId={activeHotspotId}
                onSelectHotspot={(fId) => setActiveHotspotId(fId)}
                currentObject={blackHoleObject}
              />
            </div>
          )}

          {/* Bottom HUD: Telemetry / Moon Phase Controller */}
          <div className="absolute bottom-4 left-4 right-4 z-30 flex flex-col sm:flex-row sm:items-end justify-between gap-3 pointer-events-none">
            <div className="pointer-events-auto">
              {viewMode === 'black-hole' ? (
                <div className="flex flex-wrap items-center gap-2">
                  <div className="px-3.5 py-2 rounded-xl bg-[#020308]/85 backdrop-blur-xl border border-white/10 text-xs font-mono text-slate-300 shadow-[0_8px_32px_rgba(0,0,0,0.85)] flex flex-wrap items-center gap-2 sm:gap-3">
                    <span className="text-amber-400 font-semibold">🕳️ {blackHoleObject?.name}</span>
                    <span className="text-slate-600">|</span>
                    <span className="text-amber-200 uppercase">{blackHoleObject?.blackHoleType || 'Supermassive'}</span>
                    <span className="text-slate-600">|</span>
                    <span className="text-slate-400">{blackHoleObject?.mass}</span>
                    <span className="text-slate-600 hidden sm:inline">|</span>
                    <span className="text-cyan-300 hidden sm:inline">{blackHoleObject?.distance}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleBackToUniverse}
                    className="px-2.5 py-2 rounded-xl bg-[#020308]/85 hover:bg-white/10 backdrop-blur-xl border border-white/10 text-slate-300 hover:text-white transition-all text-xs font-mono cursor-pointer flex items-center gap-1.5"
                  >
                    <span>← Back to Universe</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLocateOnMap(blackHoleObject)}
                    className="px-2.5 py-2 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/80 backdrop-blur-xl border border-cyan-400/50 text-cyan-200 transition-all text-xs font-mono cursor-pointer flex items-center gap-1.5"
                  >
                    <span>📍 Locate On Map</span>
                  </button>
                </div>
              ) : viewMode === 'moon' ? (
                <MoonPhaseBar
                  activePhaseIndex={activeMoonPhaseIndex}
                  onSelectPhase={(idx) => setActiveMoonPhaseIndex(idx)}
                />
              ) : viewMode === 'earth' ? (
                <div className="px-3.5 py-2 rounded-xl bg-[#020308]/85 backdrop-blur-xl border border-white/10 text-xs font-mono text-slate-300 shadow-[0_8px_32px_rgba(0,0,0,0.85)] flex items-center gap-3">
                  <span className="text-cyan-400 font-semibold">🌍 EARTH SYSTEM</span>
                  <span className="text-slate-600">|</span>
                  <span>1.000 AU</span>
                  <span className="text-slate-600">|</span>
                  <span className="text-slate-400">1 NATURAL SATELLITE</span>
                </div>
              ) : viewMode === 'solar-system' ? (
                <div className="px-3.5 py-2 rounded-xl bg-[#020308]/85 backdrop-blur-xl border border-white/10 text-xs font-mono text-slate-300 shadow-[0_8px_32px_rgba(0,0,0,0.85)] flex items-center gap-3">
                  <span className="text-amber-400 font-semibold">☀️ SOLAR SYSTEM</span>
                  <span className="text-slate-600">|</span>
                  <span>ZOOM {(currentZoom * 100).toFixed(0)}%</span>
                  <span className="text-slate-600">|</span>
                  <span className="text-cyan-300">8 PLANETS + SUN</span>
                </div>
              ) : (
                <MapLegend zoom={currentZoom} totalObjects={ALL_CELESTIAL_OBJECTS.length} />
              )}
            </div>

            {/* Subtle Navigation Guide Prompt */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded bg-[#020308]/75 backdrop-blur-md border border-white/5 text-[10px] font-mono text-slate-400 pointer-events-auto">
              <span>{viewMode === 'earth' || viewMode === 'moon' || viewMode === 'black-hole' ? 'DRAG TO ROTATE' : 'DRAG TO PAN'}</span>
              <span className="text-slate-600">•</span>
              <span>SCROLL TO ZOOM</span>
              <span className="text-slate-600">•</span>
              <span>CLICK TO SELECT</span>
            </div>
          </div>

          {/* Floating Object / Constellation Inspector (Desktop Card / Mobile Bottom Sheet) */}
          {selectedObject ? (
            <ObjectInspector
              object={selectedObject}
              onClose={() => setSelectedObject(null)}
              onOpenFullModal={handleOpenFullModal}
              onEnterSolarSystem={handleEnterSolarSystem}
              onExploreEarth={handleExploreEarth}
              onExploreMoon={handleExploreMoon}
              onExploreBlackHole={handleExploreBlackHole}
              onExploreConstellation={handleExploreConstellation}
              onLocateOnMap={handleLocateOnMap}
              onDiscoverAnother={handleDiscoverAnother}
              onCompare={(obj) => handleOpenCompare(obj, null)}
              viewMode={viewMode}
            />
          ) : selectedConstellation ? (
            <ConstellationInspector
              constellation={selectedConstellation}
              onClose={() => setSelectedConstellation(null)}
              onSelectStar={handleSelectStarFromConstellation}
              onOpenStarModal={handleOpenFullModal}
              onFocusRegion={() => handleSelectConstellation(selectedConstellation, true)}
            />
          ) : null}
        </div>
      </div>

      {/* Cosmic Discovery Mode Guided Modal (Phase U11) */}
      <CosmicDiscoveryCard
        isOpen={isDiscoveryOpen}
        isScanning={isDiscoveryScanning}
        discoveredObject={discoveredObject}
        activeCategory={discoveryCategory}
        onSelectCategory={(cat) => {
          setDiscoveryCategory(cat);
          handleStartDiscovery(cat);
        }}
        onDiscoverAnother={handleDiscoverAnother}
        onExplore={() => {
          setIsDiscoveryOpen(false);
        }}
        onClose={handleCloseDiscovery}
        discoveryCount={discoveryCount}
      />

      {/* Universal Object Details System (supporting all celestial targets, planets, and the Moon) */}
      <StarModal
        object={activeModalObject}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onPrevious={handlePreviousModalObject}
        onNext={handleNextModalObject}
        onSelectObject={handleSelectRelatedObject}
        onLocateOnMap={handleLocateOnMap}
        onExploreEarth={handleExploreEarth}
        onExploreMoon={handleExploreMoon}
        onExploreBlackHole={handleExploreBlackHole}
        onExploreConstellation={handleExploreConstellation}
        onCompare={(obj) => handleOpenCompare(obj, null)}
        currentIndex={
          activeModalObject
            ? activeDataset.findIndex((s) => s.id === activeModalObject.id)
            : 0
        }
        totalCount={activeDataset.length}
      />

      {/* Cosmic Compare Mode Modal (Phase U12) */}
      <CosmicCompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        initialObjectA={compareObjectA}
        initialObjectB={compareObjectB}
        onLocateObject={handleLocateFromCompare}
      />
    </section>
  );
}
