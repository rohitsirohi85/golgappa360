import React from 'react';
import { X, ShieldAlert, Sparkles, CheckCircle, Database, Cpu, Layers } from 'lucide-react';
import { useMess } from '../../context/MessContext';
import { SYNTHETIC_DATA_METADATA } from '../../data/mockWasteData';

export const InfoModal = () => {
  const { isDemoModalOpen, setIsDemoModalOpen } = useMess();

  if (!isDemoModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#25332D]/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white border border-[#E4EAE5] p-6 sm:p-8 text-[#25332D] shadow-2xl"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#E4EAE5]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
                Synthetic Demo Data Notice
                <span className="text-[11px] font-mono font-normal px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                  {SYNTHETIC_DATA_METADATA.datasetVersion}
                </span>
              </h2>
              <p className="text-xs text-[#77847C] mt-0.5">
                Academic Evaluation & UI/UX Demonstration Protocol
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsDemoModalOpen(false)}
            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#25332D] hover:bg-[#F8FAF8] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="mt-5 space-y-4 text-xs text-[#25332D] leading-relaxed">
          <div className="p-4 rounded-xl bg-[#E9F6EE]/60 border border-[#C5E5D0] text-[#16865B] flex gap-3">
            <Sparkles className="w-5 h-5 text-[#16865B] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#16865B] text-sm">
                Project Evaluation Notice
              </p>
              <p className="mt-1 text-[#25332D]">
                All telemetry records, daily waste numbers, cost calculations, and predictive graphs rendered in this interface are generated from a <strong>synthetic benchmark generator</strong>. They are designed for UI/UX testing, workflow validation, and academic review.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
              <div className="flex items-center gap-2 text-[#25332D] font-semibold mb-1">
                <Database className="w-4 h-4 text-[#0284C7]" />
                Data Origin
              </div>
              <p className="text-[11px] text-[#77847C]">
                Parametric stochastic simulation modeling typical 1,000-student hostel mess attendance patterns, meal-prep curves, and seasonal weather dips.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
              <div className="flex items-center gap-2 text-[#25332D] font-semibold mb-1">
                <Cpu className="w-4 h-4 text-[#16865B]" />
                ML Models
              </div>
              <p className="text-[11px] text-[#77847C]">
                Trained scikit-learn models (Linear Regression, Decision Tree, KNN, Logistic Regression, Gaussian NB, SVM, and K-Means) hosted via FastAPI backend.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#F8FAF8] border border-[#E4EAE5]">
            <h4 className="text-xs font-semibold text-[#25332D] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#16865B]" />
              MCA Project Roadmap
            </h4>
            <ul className="space-y-1.5 text-[11px] text-[#77847C]">
              <li className="flex items-center gap-2 text-[#16865B] font-medium">
                <CheckCircle className="w-3.5 h-3.5 text-[#16865B]" />
                <strong>Phase 1:</strong> Frontend UI/UX, responsive analytics dashboard, data visualizers.
              </li>
              <li className="flex items-center gap-2 text-[#16865B] font-medium">
                <CheckCircle className="w-3.5 h-3.5 text-[#16865B]" />
                <strong>Phase 2 & 3:</strong> Synthetic dataset generation & complete ML pipeline (Regression, Classification, Clustering).
              </li>
              <li className="flex items-center gap-2 text-[#16865B] font-medium">
                <CheckCircle className="w-3.5 h-3.5 text-[#16865B]" />
                <strong>Phase 4 & 5:</strong> FastAPI microservice, SQLite persistence, and full frontend-backend integration.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-[#E4EAE5] flex justify-end">
          <button
            onClick={() => setIsDemoModalOpen(false)}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-[#16865B] hover:bg-[#126E4A] text-white transition-colors cursor-pointer shadow-xs"
          >
            I Understand & Acknowledge
          </button>
        </div>
      </div>
    </div>
  );
};
