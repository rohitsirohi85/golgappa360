import { playlists } from "../data/playlists";
import { songs } from "../data/songs";

export const playlistService = {
  async getAllPlaylists() {
    return [...playlists];
  },

  async getPlaylistById(id) {
    const playlist = playlists.find((p) => p.id === id);
    if (!playlist) return null;

    const playlistSongs = playlist.songIds
      .map((sid) => songs.find((s) => s.id === sid))
      .filter(Boolean);

    return {
      ...playlist,
      songs: playlistSongs
    };
  },

  async createPlaylist({ title, description = "", coverUrl = "" }) {
    const newPlaylist = {
      id: `pl-${Date.now()}`,
      title,
      description: description || "Custom user created playlist",
      coverUrl: coverUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
      songIds: [],
      curator: "You",
      followers: "Private",
      isUserCreated: true
    };
    playlists.push(newPlaylist);
    return newPlaylist;
  }
};
