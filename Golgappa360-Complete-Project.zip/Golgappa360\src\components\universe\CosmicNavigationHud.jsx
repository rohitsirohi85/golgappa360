import React, { useState, useEffect } from 'react';

/**
 * CosmicNavigationHud — STELLAR 2.0 (Phase U10: Cosmic Navigation HUD)
 * 
 * Minimal, premium astronomical HUD delivering spatial awareness:
 * - Dynamic clickable breadcrumbs (UNIVERSE › REGION › CONSTELLATION / OBJECT › SOLAR SYSTEM › EARTH › MOON)
 * - Current location indicator (IBM Plex Mono)
 * - Real-time interface zoom indicator (ZOOM 1.4×)
 * - Visible object count telemetry
 * - Active exploration mode badge (UNIVERSE MAP, CONSTELLATION, SOLAR SYSTEM, PLANET, NATURAL SATELLITE, BLACK HOLE)
 * - Context-aware quick controls (+, −, ⟳ Reset, ◎ Center Selected, ⌨ Keyboard help)
 * - Collapsible toggle ([−] / [+]) with mobile compact default
 * - Educational disclaimer label
 */
export default function CosmicNavigationHud({
  viewMode = 'universe',
  selectedObject = null,
  selectedConstellation = null,
  blackHoleObject = null,
  currentZoom = 1.0,
  visibleObjectsCount = 0,
  onZoomIn,
  onZoomOut,
  onResetView,
  onCenterSelected,
  onDiscover = null,
  onCompare = null,
  onOpenTimeline = null,
  onBack,
  onNavigateToUniverse,
  onNavigateToSolarSystem,
  onNavigateToEarth,
  onNavigateToMoon,
  onNavigateToConstellation,
  onNavigateToObject,
  className = '',
}) {
  // Collapse state: default to true on mobile, false on desktop
  const [isCollapsed, setIsCollapsed] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth < 768;
    }
    return false;
  });

  const [showKeyboardHelp, setShowKeyboardHelp] = useState(false);

  // -------------------------------------------------------------
  // 1. COMPUTE DYNAMIC BREADCRUMBS & ACTIVE LOCATION
  // -------------------------------------------------------------
  let locationLabel = 'UNIVERSE';
  let modeLabel = 'UNIVERSE MAP';
  let modeBadgeColor = 'text-cyan-300 border-cyan-400/40 bg-cyan-500/15';
  let backLabel = null;
  const breadcrumbs = [];

  // Always begins with UNIVERSE root
  breadcrumbs.push({
    id: 'universe',
    label: 'UNIVERSE',
    icon: '🌌',
    isActive: viewMode === 'universe' && !selectedConstellation && !selectedObject,
    onClick: onNavigateToUniverse,
  });

  if (viewMode === 'black-hole') {
    modeLabel = 'BLACK HOLE';
    modeBadgeColor = 'text-amber-300 border-amber-500/40 bg-amber-500/15';
    locationLabel = (blackHoleObject?.name || 'BLACK HOLE').toUpperCase();
    breadcrumbs.push({
      id: 'black-hole-category',
      label: 'BLACK HOLES',
      icon: '🕳️',
      isActive: false,
      onClick: onNavigateToUniverse,
    });
    breadcrumbs.push({
      id: 'black-hole-target',
      label: (blackHoleObject?.name || 'BLACK HOLE').toUpperCase(),
      icon: '⊚',
      isActive: true,
      onClick: null,
    });
    backLabel = 'Back to Universe';
  } else if (viewMode === 'moon') {
    modeLabel = 'NATURAL SATELLITE';
    modeBadgeColor = 'text-slate-200 border-white/30 bg-white/10';
    locationLabel = 'MOON (LUNA)';
    breadcrumbs.push({
      id: 'solar-system',
      label: 'SOLAR SYSTEM',
      icon: '🪐',
      isActive: false,
      onClick: onNavigateToSolarSystem,
    });
    breadcrumbs.push({
      id: 'earth',
      label: 'EARTH',
      icon: '🌍',
      isActive: false,
      onClick: onNavigateToEarth,
    });
    breadcrumbs.push({
      id: 'moon',
      label: 'MOON',
      icon: '🌕',
      isActive: true,
      onClick: null,
    });
    backLabel = 'Back to Earth';
  } else if (viewMode === 'earth') {
    modeLabel = 'PLANET';
    modeBadgeColor = 'text-sky-300 border-sky-400/40 bg-sky-500/15';
    locationLabel = 'EARTH';
    breadcrumbs.push({
      id: 'solar-system',
      label: 'SOLAR SYSTEM',
      icon: '🪐',
      isActive: false,
      onClick: onNavigateToSolarSystem,
    });
    breadcrumbs.push({
      id: 'earth',
      label: 'EARTH',
      icon: '🌍',
      isActive: true,
      onClick: null,
    });
    backLabel = 'Back to Solar System';
  } else if (viewMode === 'solar-system') {
    modeLabel = 'SOLAR SYSTEM';
    modeBadgeColor = 'text-amber-300 border-amber-400/40 bg-amber-500/15';
    if (selectedObject && selectedObject.id !== 'sun') {
      locationLabel = selectedObject.name.toUpperCase();
      breadcrumbs.push({
        id: 'solar-system',
        label: 'SOLAR SYSTEM',
        icon: '🪐',
        isActive: false,
        onClick: onNavigateToSolarSystem,
      });
      breadcrumbs.push({
        id: selectedObject.id,
        label: selectedObject.name.toUpperCase(),
        icon: '●',
        isActive: true,
        onClick: null,
      });
      backLabel = 'Back to Solar System';
    } else {
      locationLabel = 'SOLAR SYSTEM';
      breadcrumbs.push({
        id: 'solar-system',
        label: 'SOLAR SYSTEM',
        icon: '🪐',
        isActive: true,
        onClick: null,
      });
      backLabel = 'Back to Universe';
    }
  } else if (selectedConstellation) {
    modeLabel = 'CONSTELLATION VIEW';
    modeBadgeColor = 'text-cyan-300 border-cyan-400/40 bg-cyan-500/15';
    breadcrumbs.push({
      id: selectedConstellation.id,
      label: selectedConstellation.name.toUpperCase(),
      icon: '✨',
      isActive: !selectedObject,
      onClick: () => onNavigateToConstellation && onNavigateToConstellation(selectedConstellation),
    });

    if (selectedObject) {
      locationLabel = selectedObject.name.toUpperCase();
      breadcrumbs.push({
        id: selectedObject.id,
        label: selectedObject.name.toUpperCase(),
        icon: '●',
        isActive: true,
        onClick: null,
      });
      backLabel = `Back to ${selectedConstellation.name}`;
    } else {
      locationLabel = selectedConstellation.name.toUpperCase();
      backLabel = 'Back to Universe';
    }
  } else if (selectedObject) {
    modeLabel = 'CELESTIAL OBJECT';
    modeBadgeColor = 'text-cyan-300 border-cyan-400/40 bg-cyan-500/15';
    locationLabel = selectedObject.name.toUpperCase();
    breadcrumbs.push({
      id: selectedObject.id,
      label: selectedObject.name.toUpperCase(),
      icon: '●',
      isActive: true,
      onClick: null,
    });
    backLabel = 'Back to Universe Overview';
  }

  const hasSelectedTarget = !!selectedObject;

  // Normalized zoom representation
  const formattedZoom = `${currentZoom.toFixed(1)}×`;

  return (
    <nav
      aria-label="Cosmic Exploration HUD"
      className={`select-none pointer-events-auto transition-all duration-200 ${className}`}
    >
      {/* -------------------------------------------------------------
          COLLAPSED MINIMAL STRIP (Maximum Canvas Visibility)
          ------------------------------------------------------------- */}
      {isCollapsed ? (
        <div className="flex items-center gap-2 p-1.5 rounded-xl bg-[#020308]/90 backdrop-blur-xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.85)] text-xs font-mono animate-in fade-in duration-150">
          {/* Back button if deeper than universe */}
          {backLabel && (
            <button
              type="button"
              onClick={onBack}
              aria-label={`Navigate back: ${backLabel}`}
              title={backLabel}
              className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white border border-white/10 transition-colors flex items-center gap-1 text-[11px]"
            >
              <span>←</span>
              <span className="hidden sm:inline">BACK</span>
            </button>
          )}

          {/* Current Location Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/[0.03] border border-white/5 text-slate-200">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">LOC:</span>
            <span className="font-semibold text-white tracking-wide truncate max-w-[120px] sm:max-w-[180px]">
              {locationLabel}
            </span>
          </div>

          {/* Zoom Level */}
          <div className="hidden sm:flex items-center gap-1 px-2 py-1 text-[11px] text-slate-300">
            <span className="text-slate-500 text-[10px]">ZOOM</span>
            <span className="text-cyan-300 font-semibold">{formattedZoom}</span>
          </div>

          {/* Mini Quick Controls */}
          <div className="flex items-center gap-0.5 border-l border-white/10 pl-1.5">
            <button
              type="button"
              onClick={onZoomIn}
              aria-label="Zoom in (+)"
              title="Zoom In (+)"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-slate-300 hover:text-white text-sm font-bold active:scale-95 transition-all"
            >
              +
            </button>
            <button
              type="button"
              onClick={onZoomOut}
              aria-label="Zoom out (-)"
              title="Zoom Out (-)"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-slate-300 hover:text-white text-sm font-bold active:scale-95 transition-all"
            >
              −
            </button>
            <button
              type="button"
              onClick={onResetView}
              aria-label="Reset View (R)"
              title="Reset View (R)"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-slate-300 hover:text-white text-xs active:scale-95 transition-all"
            >
              ⟳
            </button>
            {onDiscover && (
              <button
                type="button"
                onClick={onDiscover}
                aria-label="Discover (D)"
                title="Discover Something (D)"
                className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-amber-300 hover:text-amber-200 text-xs active:scale-95 transition-all"
              >
                ✦
              </button>
            )}
          </div>

          {/* Expand HUD Toggle */}
          <button
            type="button"
            onClick={() => setIsCollapsed(false)}
            aria-label="Expand Cosmic Navigation HUD"
            title="Expand Navigation HUD"
            className="px-2 py-1 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-400/40 text-cyan-200 text-[11px] font-semibold flex items-center gap-1 transition-colors"
          >
            <span>[+]</span>
            <span className="hidden sm:inline">HUD</span>
          </button>
        </div>
      ) : (
        /* -------------------------------------------------------------
           EXPANDED PREMIUM COSMIC NAVIGATION HUD
           ------------------------------------------------------------- */
        <div className="flex flex-col gap-2 p-3 sm:p-3.5 rounded-2xl bg-[#020308]/92 backdrop-blur-2xl border border-white/15 shadow-[0_12px_40px_rgba(0,0,0,0.9)] max-w-full sm:max-w-2xl animate-in fade-in zoom-in-95 duration-150">
          {/* Row 1: Back Navigation + Dynamic Interactive Breadcrumbs + Collapse */}
          <div className="flex items-center justify-between gap-2 border-b border-white/8 pb-2">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {/* Back Button */}
              {backLabel && (
                <button
                  type="button"
                  onClick={onBack}
                  aria-label={`Navigate back: ${backLabel}`}
                  title={backLabel}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 text-cyan-200 hover:text-white text-[11px] font-mono flex items-center gap-1.5 transition-colors flex-shrink-0 cursor-pointer shadow-sm"
                >
                  <span className="text-xs">←</span>
                  <span className="font-semibold uppercase tracking-wider">BACK</span>
                </button>
              )}

              {/* Dynamic Clickable Breadcrumb Trail */}
              <div className="flex items-center gap-1 text-xs font-mono">
                {breadcrumbs.map((crumb, idx) => {
                  const isLast = idx === breadcrumbs.length - 1;
                  return (
                    <React.Fragment key={crumb.id}>
                      {idx > 0 && <span className="text-slate-600 px-0.5">›</span>}
                      {crumb.isActive ? (
                        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white font-semibold border border-white/20 whitespace-nowrap shadow-sm">
                          <span className="mr-1">{crumb.icon}</span>
                          {crumb.label}
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={crumb.onClick}
                          aria-label={`Navigate to ${crumb.label}`}
                          className="px-2 py-0.5 rounded-md text-slate-400 hover:text-cyan-200 hover:bg-white/5 transition-colors whitespace-nowrap cursor-pointer"
                        >
                          <span className="mr-1 opacity-70">{crumb.icon}</span>
                          {crumb.label}
                        </button>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Minimize / Collapse Button */}
            <button
              type="button"
              onClick={() => setIsCollapsed(true)}
              aria-label="Minimize HUD [−]"
              title="Minimize HUD to compact mode"
              className="p-1 px-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 text-xs font-mono transition-colors flex-shrink-0"
            >
              [−]
            </button>
          </div>

          {/* Row 2: Location, Mode, Zoom, Objects Visible, Quick Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-0.5">
            {/* Left Telemetry Group */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs font-mono">
              {/* CURRENT LOCATION */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">
                  LOCATION
                </span>
                <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white font-semibold tracking-wide">
                  {locationLabel}
                </span>
              </div>

              {/* EXPLORATION MODE */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">
                  MODE
                </span>
                <span className={`px-2 py-0.5 rounded border text-[10px] font-semibold tracking-wider ${modeBadgeColor}`}>
                  {modeLabel}
                </span>
              </div>

              {/* ZOOM LEVEL */}
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest">
                  ZOOM
                </span>
                <span className="text-cyan-300 font-semibold">{formattedZoom}</span>
              </div>

              {/* VISIBLE OBJECT COUNT */}
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest">
                  VISIBLE
                </span>
                <span className="text-amber-300 font-semibold">{visibleObjectsCount}</span>
              </div>
            </div>

            {/* Right Quick Controls Dock */}
            <div className="flex items-center gap-1.5">
              {/* Zoom In & Out */}
              <div className="flex items-center rounded-lg bg-white/5 border border-white/10 p-0.5">
                <button
                  type="button"
                  onClick={onZoomIn}
                  aria-label="Zoom In (+)"
                  title="Zoom In (+)"
                  className="w-7 h-7 flex items-center justify-center rounded text-slate-300 hover:text-white hover:bg-white/10 active:scale-95 transition-all text-sm font-bold"
                >
                  +
                </button>
                <span className="w-px h-3.5 bg-white/10" aria-hidden="true" />
                <button
                  type="button"
                  onClick={onZoomOut}
                  aria-label="Zoom Out (-)"
                  title="Zoom Out (-)"
                  className="w-7 h-7 flex items-center justify-center rounded text-slate-300 hover:text-white hover:bg-white/10 active:scale-95 transition-all text-sm font-bold"
                >
                  −
                </button>
              </div>

              {/* Context-Aware Reset View */}
              <button
                type="button"
                onClick={onResetView}
                aria-label="Reset View (R)"
                title="Reset View to Overview (R)"
                className="h-7 px-2.5 flex items-center gap-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-400/40 text-slate-300 hover:text-white text-xs font-mono active:scale-95 transition-all"
              >
                <span>⟳</span>
                <span className="hidden sm:inline">Reset</span>
              </button>

              {/* Center Selected (enabled only when target selected) */}
              <button
                type="button"
                onClick={onCenterSelected}
                disabled={!hasSelectedTarget}
                aria-label="Center Camera on Selected Target (C)"
                title={hasSelectedTarget ? 'Center Selected Target (C)' : 'No Target Selected'}
                className={`h-7 px-2.5 flex items-center gap-1 rounded-lg border text-xs font-mono transition-all ${
                  hasSelectedTarget
                    ? 'bg-cyan-500/20 hover:bg-cyan-500/30 border-cyan-400/50 text-cyan-200 hover:text-white cursor-pointer active:scale-95 shadow-[0_0_10px_rgba(56,189,248,0.2)]'
                    : 'bg-white/[0.02] border-white/5 text-slate-600 cursor-not-allowed opacity-50'
                }`}
              >
                <span>◎</span>
                <span className="hidden sm:inline">Center</span>
              </button>

              {/* Discover Action */}
              {onDiscover && (
                <button
                  type="button"
                  onClick={onDiscover}
                  aria-label="Discover something in the universe (D)"
                  title="Discover Something (D)"
                  className="h-7 px-2.5 flex items-center gap-1 rounded-lg bg-gradient-to-r from-cyan-950/60 to-blue-950/60 hover:from-cyan-900/80 hover:to-blue-900/80 border border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white text-xs font-mono active:scale-95 transition-all cursor-pointer"
                >
                  <span className="text-amber-300">✦</span>
                  <span className="hidden sm:inline">Discover</span>
                </button>
              )}

              {/* Compare Action (Phase U12) */}
              {onCompare && (
                <button
                  type="button"
                  onClick={onCompare}
                  aria-label="Open Cosmic Compare Mode"
                  title="Cosmic Compare Mode"
                  className="h-7 px-2.5 flex items-center gap-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/40 hover:border-purple-400 text-purple-200 hover:text-white text-xs font-mono active:scale-95 transition-all cursor-pointer"
                >
                  <span>⚖️</span>
                  <span className="hidden sm:inline">Compare</span>
                </button>
              )}

              {/* Timeline Action (Phase U13) */}
              {onOpenTimeline && (
                <button
                  type="button"
                  onClick={onOpenTimeline}
                  aria-label="Open Cosmic Timeline (T)"
                  title="Cosmic History Timeline"
                  className="h-7 px-2.5 flex items-center gap-1 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white text-xs font-mono active:scale-95 transition-all cursor-pointer"
                >
                  <span>⏳</span>
                  <span className="hidden sm:inline">Timeline</span>
                </button>
              )}

              {/* Keyboard Shortcuts Trigger */}
              <button
                type="button"
                onClick={() => setShowKeyboardHelp((prev) => !prev)}
                aria-label="Toggle Keyboard Controls Help"
                title="Keyboard Shortcuts (⌨)"
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white text-xs transition-colors"
              >
                ⌨
              </button>
            </div>
          </div>

          {/* Row 3: Educational Scientific Disclaimer & Keyboard Help Popover */}
          <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-1 border-t border-white/5">
            <span className="truncate">
              Illustrative educational visualization — not to physical scale.
            </span>
            <span className="hidden sm:inline tracking-wider uppercase text-slate-600">
              HUD V2.0 // ONLINE
            </span>
          </div>

          {/* Keyboard Shortcuts Popover Dropdown */}
          {showKeyboardHelp && (
            <div className="mt-2 p-3 rounded-xl bg-[#030612]/95 border border-cyan-500/30 text-xs font-mono text-slate-300 shadow-[0_10px_30px_rgba(0,0,0,0.9)] animate-in fade-in zoom-in-95 duration-100">
              <div className="flex items-center justify-between text-[11px] font-bold text-cyan-300 uppercase tracking-wider mb-2">
                <span>✦ Keyboard Observatory Shortcuts</span>
                <button
                  type="button"
                  onClick={() => setShowKeyboardHelp(false)}
                  className="text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">+</kbd>
                  <span className="text-slate-400">Zoom In</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">−</kbd>
                  <span className="text-slate-400">Zoom Out</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">R</kbd>
                  <span className="text-slate-400">Reset View</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">C</kbd>
                  <span className="text-slate-400">Center Target</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">D</kbd>
                  <span className="text-slate-400">Discover</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">ESC</kbd>
                  <span className="text-slate-400">Deselect</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-white">/</kbd>
                  <span className="text-slate-400">Universal Search</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
