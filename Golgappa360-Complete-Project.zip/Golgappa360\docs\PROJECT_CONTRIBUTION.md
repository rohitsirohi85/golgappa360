# EV SMART: Project Contribution & Implementation Realism Report
## Engineering Breakdown: Implemented vs Prototype vs Simulated vs Future Scope

> **Academic Rigor & Integrity Statement**  
> *To uphold the highest academic and professional standards, this document establishes clear, uncompromising boundaries regarding the operational state of every subsystem within EV SMART. No capability is overstated, and laboratory prototype or simulated elements are explicitly acknowledged.*

---

## 1. Classification Taxonomy

Each subsystem, module, and feature is classified strictly according to the following definitions:

| Classification | Definition |
| :--- | :--- |
| **`IMPLEMENTED`** | Production-ready, custom-written source code residing in the repository, executing within the Node.js backend, Python FastAPI service, or React frontend. |
| **`TESTED`** | Programmatically verified via automated unit/integration suites (202 test assertions), API performance benchmarks, or physical multimeter/oscilloscope testbench validation. |
| **`PROTOTYPE`** | Operational physical hardware circuit assembled in a laboratory testbed. Operates at scaled electrical ratings (single-phase 230V AC up to 16A or simulated low-voltage resistive loads). |
| **`SIMULATED`** | Software-generated data models, virtual load generators, or simulated multi-device fleets used to benchmark high-density concurrent traffic beyond physical breadboard count. |
| **`FUTURE SCOPE`** | Documented architectural designs, standard protocols, or industrial enhancements reserved for future industrial commercialization or subsequent research phases. |

---

## 2. Comprehensive Subsystem Audit Matrix

### A. Embedded IoT Hardware Subsystem

| Component / Feature | Classification | Technical Description & Implementation Details |
| :--- | :--- | :--- |
| **ESP32 Firmware Core** | `IMPLEMENTED` / `TESTED` | Custom C++ firmware using ESP-IDF / Arduino core with FreeRTOS dual-core task scheduling. Core 0 handles sensor reading & safety; Core 1 handles network stack. |
| **PZEM-004T v3.0 Sensor** | `PROTOTYPE` / `TESTED` | Interfaced via hardware UART2 (GPIO 16 RX, GPIO 17 TX). Reads Voltage (V), Current (A), Active Power (W), Energy (kWh), Frequency (Hz), and Power Factor ($\cos\phi$). |
| **DHT22 Temperature & Humidity**| `PROTOTYPE` / `TESTED` | Single-bus digital interface on GPIO 4. Monitors ambient and charger enclosure temperatures to detect thermal runaway. |
| **Active-Low Relay Actuation** | `PROTOTYPE` / `TESTED` | 30A 250V AC Songle optocoupled relay module driven via GPIO 26 through a 2N2222 transistor buffer. Energizes/de-energizes power to the EV socket. |
| **Emergency Stop Pushbutton** | `PROTOTYPE` / `TESTED` | Hardware interrupt (GPIO 34 pull-up). Triggers an immediate zero-latency relay disengagement at the ISR level. |
| **16x2 I2C Character Display** | `PROTOTYPE` / `TESTED` | Interfaced via I2C (SDA GPIO 21, SCL GPIO 22) displaying local status: IP address, Voltage, Current, and State. |
| **Autonomous Edge Thermal Cutoff** | `IMPLEMENTED` / `TESTED` | Physical safety logic executed every 100ms in FreeRTOS: If $T > 60^\circ\text{C}$ or $I > 32\text{A}$, relay is forced open locally, completely decoupled from cloud connectivity. |
| **Dual-Channel Telemetry (MQTT & REST)**| `IMPLEMENTED` / `TESTED` | Primary transmission over MQTT (TCP 1883) with automated failover to HTTP REST (`POST /api/iot/telemetry`) if the MQTT broker is unreachable. |
| **Multi-Charger Physical Deployment** | `SIMULATED` | 1 physical ESP32 prototype hardware bench is implemented; fleet expansion to 10+ chargers across multiple stations is simulated via `test-iot-flow.js` virtual device emitters. |
| **IEC 61851 Control Pilot (PWM)** | `FUTURE SCOPE` | Physical 1kHz $\pm 12\text{V}$ PWM control pilot signaling for SAE J1772 / Mennekes Type 2 handshake is documented but omitted in favor of direct relay switching for prototype safety. |

---

### B. Backend & Real-Time Infrastructure

| Component / Feature | Classification | Technical Description & Implementation Details |
| :--- | :--- | :--- |
| **Node.js / Express Architecture**| `IMPLEMENTED` / `TESTED` | Modular layered MVC pattern: Routers, Controllers, Services, Mongoose Models, Middleware. Health check response time: 14.86ms. |
| **MongoDB Database & ODM** | `IMPLEMENTED` / `TESTED` | Relational-like schema design in MongoDB with Mongoose: Stations, Chargers, Bookings, Sessions, Telemetry, Users, Invoices, Audits. Compound indexes on station-charger pairs. |
| **JWT Authentication & RBAC** | `IMPLEMENTED` / `TESTED` | HMAC-SHA256 signed JSON Web Tokens with bcrypt password hashing (10 salt rounds). Strict role-based permissions (`driver`, `operator`, `admin`). |
| **Real-Time WebSocket Gateway** | `IMPLEMENTED` / `TESTED` | Socket.IO engine mounted on HTTP server. Broadcasts `telemetry_update`, `charger_status_changed`, `charging_session_update`, and `emergency_alert` to room-subscribed clients. |
| **MQTT Broker Integration** | `IMPLEMENTED` / `TESTED` | Eclipse Mosquitto broker bridge integrated using `mqtt.js`. Ingests `ev/station/+/charger/+/telemetry` and publishes remote start/stop to `ev/station/+/charger/+/command`. |
| **Automated Integration Test Suite** | `TESTED` | 202 automated assertions across 6 test suites validating all API routes, edge cases, error codes, and concurrency without human intervention. |
| **Live Bank Payment Gateway** | `SIMULATED` | Simulated wallet and payment gateway with cryptographically verified mock transaction tokens (`TXN_MOCK_*`), wallet balance debit/credit, and PDF invoice generation. |
| **OCPP 2.0.1 Protocol Support** | `FUTURE SCOPE` | Standardized Open Charge Point Protocol WebSocket server is architecturally outlined in `docs/route-contracts.md` but not enabled in the current release. |

---

### C. Artificial Intelligence & Energy Optimization Subsystem

| Component / Feature | Classification | Technical Description & Implementation Details |
| :--- | :--- | :--- |
| **Python FastAPI Microservice** | `IMPLEMENTED` / `TESTED` | Uvicorn-driven asynchronous microservice running on port 8000. Sub-11ms response latency for all inference endpoints. |
| **24-Hour Demand Forecasting** | `IMPLEMENTED` / `TESTED` | Scikit-learn **Random Forest Regressor** trained on engineered time-series features (cyclical hour/day sine-cosine transforms, temperature, historical lag). Achieves $R^2 = 0.9902$, $\text{MAE} = 3.09\text{ kWh}$. |
| **Unsupervised Anomaly Detection**| `IMPLEMENTED` / `TESTED` | Scikit-learn **Isolation Forest** evaluating streaming 5-dimensional electrical vectors $[V, I, P, T, \text{PF}]$ to detect voltage sag, current harmonic spikes, and thermal runaway. |
| **Smart Dynamic Tariff Optimizer** | `IMPLEMENTED` / `TESTED` | Algorithmic tariff computation dynamically scaling charging rates based on forecasted grid load: Base Rate $\times$ Peak Demand Multiplier ($1.0\times$ off-peak up to $1.6\times$ critical peak). |
| **Predictive Charger Maintenance** | `IMPLEMENTED` / `TESTED` | Machine learning health scoring evaluating cumulative thermal cycles, relay switch counts, and anomaly frequency to assign maintenance alerts (`HEALTHY`, `WARNING`, `CRITICAL`). |
| **Dataset Source** | `SIMULATED` | Physics-calibrated synthetic dataset generated via `generate_data.py` modeling real-world charging behaviors, solar generation curves, and Indian grid tariff structures. |
| **Deep Reinforcement Learning (RL)**| `FUTURE SCOPE` | Multi-agent Deep Q-Networks (DQN) for real-time microgrid battery storage arbitration and renewable solar integration. |

---

### D. User Mobile Application & Admin Fleet Web Dashboard

| Component / Feature | Classification | Technical Description & Implementation Details |
| :--- | :--- | :--- |
| **Responsive Web/Mobile App** | `IMPLEMENTED` / `TESTED` | React 18 SPA optimized for mobile viewports (PWA-ready). Full station map search, slot reservation calendar, active charging HUD, live telemetry charts, digital wallet. |
| **Executive Admin Fleet Portal** | `IMPLEMENTED` / `TESTED` | Administrative web application featuring live multi-station fleet monitoring, charger control overrides, revenue and energy analytics (Recharts), dynamic tariff manager, and audit log explorer. |
| **Live Visual Telemetry Graphs** | `IMPLEMENTED` / `TESTED` | Real-time SVG charts streaming incoming voltage, current, and temperature points directly from WebSocket updates at 1-second intervals. |
| **Native iOS / Android App (App Stores)**| `FUTURE SCOPE` | Packaging the React PWA into native binary wrappers via Capacitor or React Native for distribution on Google Play Store and Apple App Store. |

---

## 3. Clear Summary of Academic Contribution

1. **Hardware-Software Synergy:** Demonstrated a functional end-to-end IoT loop from physical voltage/current sensors through a dual-core microcontroller to a cloud-hosted event pipeline and responsive UI.
2. **Autonomous Safety Coexistence:** Proved that cloud-driven IoT systems must decouple critical safety interlocks from network latency by implementing independent FreeRTOS thermal/current trip tasks on the edge.
3. **Data-Driven Smart Grid Operation:** Implemented and validated real ML models that translate low-level power telemetry into actionable operational intelligence (demand forecasting, dynamic pricing, and predictive maintenance).
4. **Resilient Dual-Protocol Architecture:** Established that combining MQTT pub/sub for low-overhead telemetry with REST failover provides maximum availability across unstable campus or municipal Wi-Fi networks.
