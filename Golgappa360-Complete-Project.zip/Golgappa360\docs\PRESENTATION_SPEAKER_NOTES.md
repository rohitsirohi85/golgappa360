# EV SMART: Presentation Speaker Notes & Defense Dialogue
## Complete Script, Technical Talking Points & Examiner Q&A for All 20 Slides

---

### Slide 1: Title Slide
- **Speaker Script:**  
  *"Good morning respected members of the evaluation committee. Today, I am proud to present 'EV SMART', an end-to-end IoT and Machine Learning platform engineered for smart Electric Vehicle charging station management and grid energy optimization. Before we dive into the technical details, I would like to highlight our academic disclaimer: this system has been constructed as a fully functioning laboratory prototype operating at single-phase 230V AC up to 16 amperes with galvanic isolation and hardware emergency cutoffs, demonstrating proof-of-concept for larger commercial microgrids."*
- **Key Technical Points:** Emphasize the end-to-end scope (hardware, transport, cloud, AI, user UI).
- **Anticipated Question:** *"Is this a theoretical simulation or does it have real hardware?"*
- **Examiner Answer:** *"It is a hybrid working implementation: we have designed, assembled, and programmed a real physical ESP32 testbed with PZEM-004T and DHT22 sensors driving an AC relay, while multi-charger network scaling is supported via automated simulated load emitters."*

---

### Slide 2: Introduction & Research Background
- **Speaker Script:**  
  *"The global transition toward electric mobility is occurring at an exponential pace. However, our municipal electrical distribution grids were never designed to accommodate massive, concurrent charging loads. Charging an EV is fundamentally different from typical household loads; a single level 2 AC charger draws as much power as multiple residential air conditioners combined. Without smart coordination, localized transformers experience severe phase unbalance, voltage sag, and thermal degradation. EV SMART was created to bridge this critical gap between the physical charger and grid-aware intelligence."*
- **Key Technical Points:** Cite transformer overload risks, concurrent charging demand curves, and the need for open-source telemetry.
- **Anticipated Question:** *"Why not just upgrade the utility transformers?"*
- **Examiner Answer:** *"Physical grid reinforcement is capital-intensive and takes years to deploy. Smart charging software and dynamic tariffs allow existing distribution assets to support up to 300% more EVs through intelligent peak-shaving and scheduled load distribution."*

---

### Slide 3: Problem Statement
- **Speaker Script:**  
  *"Our research identified five critical shortcomings in current charging systems. First, uncoordinated charging causes severe grid peak spikes. Second, network operators frequently suffer from telemetry blind spots, unable to view granular power quality or thermal metrics at the individual plug. Third, and most dangerously, many cloud-connected systems rely exclusively on remote servers to trip safety relays, creating a catastrophic hazard if Wi-Fi drops during an overcurrent event. Fourth, drivers suffer from phantom availability and queue congestion. Finally, flat-rate tariffs fail to incentivize drivers to charge during off-peak hours."*
- **Key Technical Points:** Clearly distinguish between electrical issues (grid spikes, safety risks) and software/operational issues (booking congestion, static tariffs).

---

### Slide 4: Project Objectives
- **Speaker Script:**  
  *"To solve these problems, we defined six concrete engineering objectives: first, engineer an ESP32-based hardware controller with precision AC energy and thermal metering; second, ensure autonomous edge safety with sub-50ms disconnects; third, implement a dual-channel MQTT and REST telemetry pipeline; fourth, train and deploy real-time machine learning models for 24-hour demand forecasting and anomaly detection; fifth, deliver intuitive, responsive web and mobile interfaces; and sixth, validate everything through rigorous automated testing."*
- **Key Technical Points:** Every objective directly maps to a delivered and tested module in the repository.

---

### Slide 5: Overall System Architecture
- **Speaker Script:**  
  *"Here we observe the four-tier architectural blueprint of EV SMART. At the physical edge, our ESP32 gathers sensor telemetry and controls the AC contactor. It transmits data via an Eclipse Mosquitto MQTT broker using TCP port 1883, with automatic HTTP REST failover. Our application tier consists of a clustered Node.js and Express backend handling business logic and MongoDB transactions, alongside an asynchronous Python FastAPI microservice dedicated to AI inference. Finally, our presentation tier uses React 18 with Socket.IO to deliver real-time, zero-refresh monitoring for both drivers and fleet administrators."*
- **Key Technical Points:** Emphasize the clean decoupling between the high-throughput Node.js I/O layer and the compute-heavy Python machine learning service.
- **Anticipated Question:** *"Why separate Node.js and Python instead of writing the entire backend in Python?"*
- **Examiner Answer:** *"Node.js provides an exceptional event-driven, non-blocking I/O runtime perfectly suited for thousands of concurrent WebSocket and MQTT telemetry streams. Python, on the other hand, is the gold standard for scientific computing and Scikit-learn machine learning. Decoupling them as microservices prevents heavy matrix calculations from blocking real-time WebSocket event loops."*

---

### Slide 6: IoT Hardware Layer & Sensors
- **Speaker Script:**  
  *"Looking at our physical hardware implementation: we selected the ESP32-WROOM-32 microcontroller for its dual 240MHz Xtensa cores and native Wi-Fi/BLE capabilities. For electrical sensing, we interfaced the PZEM-004T v3.0 module over hardware UART2. Unlike basic analog current clamps, the PZEM-004T features an onboard dedicated energy metering IC that computes true RMS voltage, current, active power, and power factor. Ambient and enclosure temperatures are tracked via a digital DHT22 sensor on GPIO 4. AC power to the load is switched via a 30A optocoupled relay driven through a 2N2222 transistor buffer. We also integrated an I2C 16x2 LCD for on-site diagnostics and a mechanical red emergency stop button wired to a hardware interrupt."*
- **Key Technical Points:** Hardware UART2 avoids software serial timing jitter; optocoupler ensures complete galvanic isolation between low-voltage 3.3V logic and 230V AC mains.

---

### Slide 7: Autonomous Edge Safety & FreeRTOS Decoupling
- **Speaker Script:**  
  *"One of our core engineering innovations is the total decoupling of safety from cloud connectivity. We leveraged the ESP32's dual cores using FreeRTOS. Core 0 is strictly dedicated to our high-priority safety task. Every 100 milliseconds, it samples the temperature and current. If the enclosure temperature exceeds 60 degrees Celsius or current exceeds 32 amperes, the relay is forced open in under 50 milliseconds. Core 1 handles network communication and MQTT serialization. If the cloud crashes, the Wi-Fi drops, or the router fails, the safety trip remains fully operational. Furthermore, our firmware features an internal SRAM ring-buffer storing up to 60 telemetry frames during network dropouts, preventing historical data loss."*
- **Key Technical Points:** Core pinning (`xTaskCreatePinnedToCore`), ISR emergency interrupt on GPIO 34, Ring-buffer queue FIFO mechanism.
- **Anticipated Question:** *"What happens if the relay contacts weld shut?"*
- **Examiner Answer:** *"In an industrial deployment, a secondary mechanical shunt trip breaker or Type B RCCB is installed upstream. In our prototype, the physical emergency stop button physically breaks control power to the relay coil, and persistent overcurrent triggers an audible buzzer warning."*

---

### Slide 8: Dual-Channel IoT Communication
- **Speaker Script:**  
  *"Reliable communication is vital in industrial IoT. We implemented a dual-channel architecture. The ESP32 primarily communicates via MQTT using Quality of Service 0/1 for minimal packet overhead and sub-50ms latency. However, in enterprise environments or certain Wi-Fi networks where TCP port 1883 is blocked by firewalls, our firmware automatically detects broker timeout and falls back to HTTP REST POST requests to port 5000. This ensures seamless telemetry continuity under diverse network conditions."*
- **Key Technical Points:** MQTT topic structure (`ev/station/:id/charger/:id/telemetry`), keep-alive ping intervals, REST failover retry counter.

---

### Slide 9: Backend Cloud Architecture & Streaming
- **Speaker Script:**  
  *"On the backend, our Node.js and Express server acts as the central orchestration engine. It connects directly to the MQTT broker via the `mqtt.js` client. As raw telemetry packets arrive, they pass through a validation and normalization pipeline. The server computes derived energy metrics, persists the telemetry to MongoDB, and simultaneously emits a `telemetry_update` event across our Socket.IO WebSocket server. This allows hundreds of connected browser clients to receive live 1Hz telemetry updates with average backend processing latencies of just 17.45 milliseconds."*
- **Key Technical Points:** Express middleware architecture, non-blocking asynchronous I/O, MongoDB indexed collections, room-based WebSocket broadcasting.

---

### Slide 10: Database Schema & Entity Relationships
- **Speaker Script:**  
  *"Our database is modeled in MongoDB using Mongoose schemas. We designed clean relational models: Users, Stations, Chargers, Bookings, ChargingSessions, Telemetry, and AuditLogs. To guarantee high query performance under high ingest rates, we established compound indexes on station and charger identifiers, as well as chronological indexes on telemetry timestamps. Overlapping booking slots are strictly prevented using MongoDB atomic find-and-modify queries."*
- **Key Technical Points:** NoSQL document flexibility paired with relational integrity constraints; TTL indexes for historical raw telemetry rolling retention.

---

### Slide 11: End-User Mobile Application
- **Speaker Script:**  
  *"Our driver mobile application was built using React 18, Vite, and Tailwind CSS, following modern Progressive Web App principles. Drivers can discover stations on an interactive map, view real-time connector availability, and book charging slots in advance. When arriving at a station, they initiate charging via a QR code workflow. During charging, our live cockpit displays an animated state-of-charge gauge, digital dials for voltage, current, and power, and real-time sparkline graphs. When charging concludes, the driver receives an itemized digital receipt with automated wallet balance deduction."*
- **Key Technical Points:** Single Page Application (SPA), responsive mobile viewports, component-based architecture, client-side WebSocket state management.

---

### Slide 12: Admin Fleet Management Dashboard
- **Speaker Script:**  
  *"For charging station operators and network administrators, we built an executive fleet management portal. The overview screen provides instant visibility into total energy delivered, active charging points, and live revenue. In the charger grid view, operators can inspect the status of every charger in the network. Clicking into any charger reveals raw sensor diagnostics, Wi-Fi signal strength, and firmware telemetry. Administrators also have central override capabilities, including the ability to issue a remote emergency disconnect across any active station."*
- **Key Technical Points:** Role-based UI rendering, administrative action authorization, remote command dispatch over MQTT.

---

### Slide 13: Operational & Energy Analytics
- **Speaker Script:**  
  *"Turning operational data into business intelligence, our analytics engine utilizes Node.js aggregation pipelines to compute comprehensive performance metrics. We visualize daily, weekly, and monthly energy throughput, peak demand factors, and revenue distributions. Additionally, our 24x7 station utilization heatmap correlates occupancy rates across every hour of every day of the week, allowing fleet managers to pinpoint exact grid bottleneck periods and plan infrastructure upgrades accordingly."*
- **Key Technical Points:** MongoDB `$aggregate`, `$facet`, and `$bucket` operators; time-bucketed energy integration $\sum P \cdot \Delta t$.

---

### Slide 14: AI Engine: 24-Hour Ahead Demand Forecasting
- **Speaker Script:**  
  *"Moving to our artificial intelligence layer: we engineered an asynchronous Python FastAPI microservice. To forecast station load 24 hours in advance, we trained a Scikit-learn Random Forest Regressor. We engineered cyclical features using sine and cosine transformations of the hour-of-day and day-of-week, alongside temperature and historical load lags. Evaluated on an 80/20 chronological train-test split, the model achieves an R-squared of 0.9902 and a Mean Absolute Error of 3.09 kilowatt-hours, serving predictions via REST API in just 10.93 milliseconds."*
- **Key Technical Points:** 100 decision trees, max depth tuned, no future data leakage, chronological split.
- **Anticipated Question:** *"Why Random Forest instead of an LSTM recurrent neural network?"*
- **Examiner Answer:** *"While LSTMs are effective for long-sequence raw waveform modeling, tabular charging data with engineered cyclical temporal features achieves exceptional convergence ($R^2=0.990$) with Random Forests at a fraction of the computational overhead. Furthermore, inference runs in under 11 milliseconds on standard CPU hardware without requiring dedicated GPU acceleration."*

---

### Slide 15: AI Engine: Anomaly Detection & Predictive Maintenance
- **Speaker Script:**  
  *"For electrical safety and equipment longevity, we implemented an unsupervised Isolation Forest model. It continuously evaluates 5-dimensional electrical vectors comprising voltage, current, active power, temperature, and power factor. By isolating anomaly clusters with a calibrated 5% contamination rate, the model detects subtle voltage sags, harmonic distortions, or contact degradation before a hardware failure occurs. We also compute a dynamic predictive maintenance index based on thermal cycling and relay operational counts."*
- **Key Technical Points:** Tree-based recursive partitioning, average path length scoring, multi-dimensional feature scaling via StandardScaler.

---

### Slide 16: Dynamic Tariff & Smart Grid Optimization
- **Speaker Script:**  
  *"To solve the grid peak-load problem, our platform links AI demand forecasting directly to dynamic pricing. Instead of static flat rates, our Dynamic Tariff Optimizer automatically scales the per-kWh charging tariff. During late-night off-peak periods, the price drops by 20% to incentivize overnight charging. During critical evening peak hours between 5 PM and 10 PM, the price increases by up to 1.6x. This economic mechanism effectively shifts discretionary charging demand away from grid stress periods without requiring coercive load shedding."*
- **Key Technical Points:** Price elasticity of demand in EV charging, time-of-use (TOU) tariff curves, automated consumer notifications.

---

### Slide 17: Cybersecurity, RBAC & Immutable Auditing
- **Speaker Script:**  
  *"Cybersecurity is paramount in modern energy infrastructure. Our system enforces stateless authorization using HMAC-SHA256 signed JSON Web Tokens with 24-hour expiration. Passwords are encrypted using bcrypt with 10 salt rounds. We hardened our HTTP endpoints using Helmet security headers, CORS domain whitelisting, and IP-based rate limiting of 100 requests per 15 minutes. Furthermore, all critical administrative actions—such as tariff modifications and emergency stops—are permanently recorded in an append-only, tamper-evident MongoDB audit log."*
- **Key Technical Points:** Mitigation of OWASP Top 10 vulnerabilities (Injection, Broken Authentication, Security Misconfigurations).

---

### Slide 18: Empirical Benchmarks & Test Results
- **Speaker Script:**  
  *"We subjected EV SMART to comprehensive empirical benchmarking on our physical testbench. All six automated integration test suites passed with a 100% success rate across 202 individual test assertions. In latency testing, our backend health check responded in 14.86ms, sensor surge ingestion in 17.45ms, and AI demand inference in 10.93ms. Our React frontend compiles into an optimized production bundle via Vite in just 1.10 seconds with zero warnings, demonstrating clean, production-grade code quality."*
- **Key Technical Points:** Supertest integration testing, automated mock emitter concurrency, reproducible benchmarking scripts.

---

### Slide 19: System Limitations & Boundary Conditions
- **Speaker Script:**  
  *"In accordance with academic rigor, we acknowledge our system limitations. First, our physical hardware operates at single-phase 230V AC up to 16A; high-voltage 400V DC fast charging was not built due to laboratory safety constraints. Second, we utilize custom JSON-over-MQTT instead of the full commercial OCPP 2.0.1 protocol. Third, our payment workflow operates in a simulated cryptographic sandbox. Finally, our machine learning models were trained on physics-calibrated synthetic EV distributions rather than multi-year utility smart meter logs."*
- **Key Technical Points:** Demonstrates academic honesty and deep awareness of commercial deployment challenges.

---

### Slide 20: Future Scope & Conclusion
- **Speaker Script:**  
  *"In conclusion, EV SMART proves that integrating open-source IoT hardware, event-driven cloud architecture, and predictive machine learning creates a highly resilient, cost-effective, and grid-friendly charging infrastructure. For future research, we plan to implement standardized OCPP 2.0.1 and ISO 15118 Plug & Charge, explore Vehicle-to-Grid bi-directional power flow, and compile our anomaly detection models for on-chip TinyML inference. Thank you for your attention, and I am now ready to answer any questions."*
- **Key Technical Points:** Strong summary of academic contributions, clear technical roadmap, confident closing.
