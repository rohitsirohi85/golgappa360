# Route Contracts — LyricLens AI

This document formalizes all route paths, access tiers, and discovery transitions in LyricLens AI.

---

## 1. Public Traversal & Discovery Routes

| Route Pattern | Component | Description | Discovery Ingress / Egress |
| :--- | :--- | :--- | :--- |
| `/` | `Home` | Hero discovery & trending showcases | ➔ `/search`, `/song/:id`, `/artist/:id` |
| `/search` | `Search` | Typo-tolerant catalog & lyrics engine | ➔ `/song/:id`, `/artist/:id`, `/album/:id` |
| `/song/:id` | `SongDetails` | Song metadata, interactive lyrics & DNA | ➔ `/artist/:id`, `/album/:id`, `/song/:id` (similar) |
| `/artist/:id` | `ArtistDetails` | Artist profile, tracks & discography | ➔ `/song/:id`, `/album/:id`, `/artist/:id` (similar) |
| `/album/:id` | `AlbumDetails` | Album packaging, tracklist & insights | ➔ `/artist/:id`, `/song/:id`, `/album/:id` (similar) |
| `/trending` | `Trending` | Live discovery charts & top songs | ➔ `/song/:id`, `/artist/:id` |
| `/ai-search` | `AiSearch` | Natural language memory query | ➔ `/song/:id` |

---

## 2. Authentication & User Management Routes

| Route Pattern | Component | Description |
| :--- | :--- | :--- |
| `/login` | `Login` | User session creation & demo sign-in |
| `/register` | `Register` | User account registration |
| `/forgot-password` | `ForgotPassword` | Password recovery dispatcher |
| `/reset-password` | `ResetPassword` | Token-based password reset |

---

## 3. Protected User Experience Routes

| Route Pattern | Component | Guard | Description |
| :--- | :--- | :--- | :--- |
| `/profile` | `Profile` | `ProtectedRoute` | User discovery stats & preferences |
| `/favorites` | `Favorites` | `ProtectedRoute` | Saved songs, artists, and albums |
| `/playlists` | `Playlists` | `ProtectedRoute` | User created & curated playlists |
| `/history` | `History` | `ProtectedRoute` | Search and discovery trail |
| `/analytics` | `Analytics` | `ProtectedRoute` | Listening and discovery analytics |
| `/settings` | `Settings` | `ProtectedRoute` | Account & appearance configuration |
| `/admin` | `Admin` | `AdminRoute` | Catalog & platform management |

---

## 4. Discovery Transition Contract

```
[Search Page / Home]
       │
       ▼
[Song Details Page: /song/:id]
       ├── Click Artist ───────────► [Artist Page: /artist/:id]
       ├── Click Album ────────────► [Album Page: /album/:id]
       ├── Click Similar Song ─────► [Song Page: /song/:similarId]
       └── Click Album Track ──────► [Song Page: /song/:trackId]

[Artist Details Page: /artist/:id]
       ├── Click Track ────────────► [Song Page: /song/:id]
       ├── Click Album ────────────► [Album Page: /album/:id]
       └── Click Similar Artist ───► [Artist Page: /artist/:similarId]

[Album Details Page: /album/:id]
       ├── Click Artist ───────────► [Artist Page: /artist/:id]
       ├── Click Track ────────────► [Song Page: /song/:trackId]
       └── Click Similar Album ────► [Album Page: /album/:similarId]
```
