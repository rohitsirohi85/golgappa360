import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export const SectionHeader = ({ title, subtitle, linkText = "See All", linkTo, icon: Icon }) => {
  return (
    <div className="flex items-end justify-between mb-6">
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Icon className="w-5 h-5" />
          </div>
        )}
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            {title}
          </h2>
          {subtitle && <p className="text-xs md:text-sm text-slate-400 mt-0.5">{subtitle}</p>}
        </div>
      </div>

      {linkTo && (
        <Link
          to={linkTo}
          className="group flex items-center gap-1 text-xs md:text-sm font-semibold text-purple-400 hover:text-purple-300 transition-colors shrink-0"
        >
          <span>{linkText}</span>
          <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      )}
    </div>
  );
};
