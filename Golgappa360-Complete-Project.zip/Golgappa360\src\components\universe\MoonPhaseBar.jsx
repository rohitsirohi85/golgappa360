import React from 'react';
import { MOON_PHASES } from '../../data/solarSystem.js';

/**
 * MoonPhaseBar — Educational Interactive Lunar Phase Controller (Phase U6)
 * 
 * Allows users to scrub through or select any of the 8 canonical moon phases,
 * dynamically illuminating the Moon's day/night optical terminator.
 */
export default function MoonPhaseBar({
  activePhaseIndex = 4, // Default to Full Moon (index 4)
  onSelectPhase,
  className = '',
}) {
  const currentPhase = MOON_PHASES[activePhaseIndex] || MOON_PHASES[4];

  return (
    <div
      className={`bg-[#020308]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-3 sm:p-4 shadow-[0_12px_40px_rgba(0,0,0,0.85)] max-w-xl mx-auto select-none ${className}`}
      aria-label="Moon phase simulator"
    >
      {/* Top Header & Active Phase readout */}
      <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-white/8 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="text-base leading-none">{currentPhase.symbol}</span>
          <span className="font-semibold text-white uppercase tracking-wider">
            {currentPhase.name}
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
            {currentPhase.illumination} ILLUMINATION
          </span>
        </div>

        <div className="text-[10px] text-slate-400 hidden sm:block">
          PHASE {activePhaseIndex + 1} OF 8
        </div>
      </div>

      {/* 8 Phase Quick Selection Buttons */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 sm:gap-2 mb-2">
        {MOON_PHASES.map((phase, idx) => {
          const isActive = idx === activePhaseIndex;
          return (
            <button
              key={phase.id}
              type="button"
              onClick={() => onSelectPhase(idx)}
              className={`flex flex-col items-center justify-center p-1.5 sm:p-2 rounded-xl transition-all cursor-pointer ${
                isActive
                  ? 'bg-cyan-500/20 border border-cyan-400/60 text-white shadow-[0_0_12px_rgba(6,182,212,0.35)] scale-105'
                  : 'bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 text-slate-400 hover:text-slate-200'
              }`}
              title={`${phase.name} (${phase.illumination} illuminated)`}
            >
              <span className="text-lg sm:text-xl leading-none">{phase.symbol}</span>
              <span className="text-[9px] font-mono mt-1 text-center truncate max-w-full">
                {phase.name.split(' ')[0]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Educational Explanation Caption */}
      <p className="text-[11px] font-sans text-slate-300/85 leading-snug">
        <span className="text-amber-300 font-semibold mr-1">✦ Orbit Observation:</span>
        {currentPhase.description}
      </p>
    </div>
  );
}
