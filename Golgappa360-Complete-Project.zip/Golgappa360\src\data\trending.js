export const moodCategories = [
  { id: "romantic", name: "Romantic", emoji: "❤️", count: 430, color: "from-rose-500/20 to-pink-600/30", border: "border-pink-500/30" },
  { id: "sad", name: "Sad", emoji: "😢", count: 580, color: "from-blue-600/20 to-indigo-700/30", border: "border-blue-500/30" },
  { id: "energetic", name: "Energetic", emoji: "🔥", count: 820, color: "from-amber-500/20 to-orange-600/30", border: "border-orange-500/30" },
  { id: "chill", name: "Chill", emoji: "🌙", count: 940, color: "from-teal-500/20 to-emerald-600/30", border: "border-teal-500/30" },
  { id: "heartbreak", name: "Heartbreak", emoji: "💔", count: 610, color: "from-purple-600/20 to-violet-800/30", border: "border-purple-500/30" },
  { id: "party", name: "Party", emoji: "🥳", count: 750, color: "from-fuchsia-500/20 to-pink-600/30", border: "border-fuchsia-500/30" }
];

export const trendingStats = {
  todaySongIds: ["song-1", "song-3", "song-4", "song-2"],
  weekSongIds: ["song-4", "song-1", "song-8", "song-6", "song-3"],
  risingSongIds: ["song-7", "song-3", "song-5"],
  mostSearchedArtists: [
    { name: "Luna Vance", searches: "142.8K", growth: "+24%", rank: 1, image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80" },
    { name: "Aarav Sen", searches: "128.4K", growth: "+18%", rank: 2, image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80" },
    { name: "Kabir Dhillon", searches: "99.1K", growth: "+31%", rank: 3, image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&auto=format&fit=crop&q=80" },
    { name: "The Midnight Echoes", searches: "87.3K", growth: "+12%", rank: 4, image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=100&auto=format&fit=crop&q=80" },
    { name: "Elena Rostova", searches: "46.2K", growth: "+8%", rank: 5, image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&auto=format&fit=crop&q=80" }
  ],
  mostSearchedGenres: [
    { genre: "Indie Folk & Acoustic", percentage: 32, count: "154,200", color: "bg-amber-500" },
    { genre: "Synthwave / Alt-Pop", percentage: 28, count: "135,000", color: "bg-purple-500" },
    { genre: "Punjabi Beats", percentage: 21, count: "101,200", color: "bg-rose-500" },
    { genre: "Electronic Dance", percentage: 12, count: "57,800", color: "bg-cyan-500" },
    { genre: "Neo-Classical", percentage: 7, count: "33,700", color: "bg-emerald-500" }
  ],
  dailySearchVolume: [
    { day: "Mon", count: 42000 },
    { day: "Tue", count: 48000 },
    { day: "Wed", count: 54000 },
    { day: "Thu", count: 51000 },
    { day: "Fri", count: 68000 },
    { day: "Sat", count: 79000 },
    { day: "Sun", count: 74000 }
  ]
};
