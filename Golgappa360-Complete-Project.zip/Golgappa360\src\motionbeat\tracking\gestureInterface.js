/**
 * GestureInterface
 * Standardized gesture data contract between HandTracker, Three.js VisualEngine,
 * and future Phase 3 music sequencer controllers.
 */

export class GestureInterface {
  constructor() {
    this.enabled = true; // Toggle gesture-driven controls
    this.mouseFallback = { x: 0, y: 0 };
    this.lastData = this.getEmptyData();
  }

  getEmptyData() {
    return {
      isTracking: false,
      enabled: this.enabled,
      mode: 'mouse', // 'hands' | 'mouse'
      handCount: 0,
      hands: [],
      primaryHand: null,
      secondaryHand: null,
      inferenceTimeMs: 0,
    };
  }

  setEnabled(val) {
    this.enabled = !!val;
  }

  setMouseFallback(x, y) {
    this.mouseFallback = { x, y };
  }

  /**
   * Transforms raw HandTracker results into the studio gesture contract
   */
  process(trackerResults, cameraActive) {
    if (!this.enabled || !cameraActive || !trackerResults || trackerResults.handCount === 0) {
      // Seamlessly fall back to mouse coordinates
      return {
        isTracking: cameraActive,
        enabled: this.enabled,
        mode: 'mouse',
        handCount: 0,
        hands: [],
        primaryHand: {
          id: 'mouse_sim',
          handedness: 'Right',
          position: { x: this.mouseFallback.x, y: this.mouseFallback.y, z: 0 },
          pinchDistance: 1.0,
          isPinching: false,
        },
        secondaryHand: null,
        inferenceTimeMs: trackerResults ? trackerResults.inferenceTimeMs : 0,
      };
    }

    const hands = trackerResults.hands || [];
    const primary = hands[0] || null;
    const secondary = hands[1] || null;

    const data = {
      isTracking: true,
      enabled: this.enabled,
      mode: 'hands',
      handCount: hands.length,
      hands,
      primaryHand: primary,
      secondaryHand: secondary,
      inferenceTimeMs: trackerResults.inferenceTimeMs || 0,
    };

    this.lastData = data;
    return data;
  }
}

export const gestureInterface = new GestureInterface();
