import React from 'react';

/**
 * EducationalNote — Scientific perspective callout
 * Explains that constellations are 2D line-of-sight alignments from Earth,
 * not physically close stellar groupings in 3D galactic space.
 */
export default function EducationalNote() {
  return (
    <div className="w-full max-w-5xl mx-auto rounded-3xl glass-surface border border-cyan-500/25 p-6 sm:p-8 bg-gradient-to-r from-cyan-950/25 via-slate-950/40 to-indigo-950/25 shadow-xl relative overflow-hidden">
      {/* Decorative Background Optics */}
      <div
        aria-hidden="true"
        className="absolute -right-20 -bottom-20 w-72 h-72 rounded-full bg-cyan-500/10 blur-[90px] pointer-events-none"
      />

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 text-left max-w-3xl">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-300 font-bold">
              FUNDAMENTAL ASTRONOMICAL PRINCIPLE // 3D PERSPECTIVE
            </span>
          </div>

          <blockquote className="text-sm sm:text-base text-slate-100 font-medium leading-relaxed">
            &ldquo;Constellations are apparent patterns seen from Earth. The stars within a constellation may be at very different distances from us and are not necessarily physically close to one another.&rdquo;
          </blockquote>

          <p className="text-xs font-mono text-slate-400 leading-normal">
            They are optical alignments across cosmic depth. For example, in Orion, <strong>Bellatrix</strong> is approximately <strong>250 light-years</strong> away, while the belt star <strong>Alnilam</strong> is roughly <strong>2,000 light-years</strong> distant—nearly eight times farther into deep space.
          </p>
        </div>

        {/* Visual Optical Axis Mini Diagram */}
        <div className="w-full md:w-auto shrink-0 flex items-center justify-center p-4 rounded-2xl bg-black/50 border border-white/10 text-center font-mono text-xs">
          <div className="flex flex-col items-center gap-1.5">
            <span className="text-[10px] uppercase tracking-wider text-slate-400">
              LINE-OF-SIGHT PROJECTION
            </span>
            <div className="flex items-center gap-2 text-cyan-300 font-bold">
              <span>EARTH 🌍</span>
              <span className="text-slate-500">───▸</span>
              <span>250 ly ✦</span>
              <span className="text-slate-600">┈┈┈▸</span>
              <span>2,000 ly ✦</span>
            </div>
            <span className="text-[9px] text-amber-300/80">
              2D PATTERN ≠ 3D CLUSTER
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
