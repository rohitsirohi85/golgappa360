import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Activity, Clock, CheckCircle2, Phone, MessageCircle, ArrowUpRight, Zap } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const ClassesPage = ({ onOpenTrial: propOnOpenTrial }) => {
  const outletCtx = useOutletContext();
  const onOpenTrial = propOnOpenTrial || outletCtx?.onOpenTrial;

  const [activeTab, setActiveTab] = useState(siteConfig.programs[0].id);

  const activeProgram =
    siteConfig.programs.find((p) => p.id === activeTab) || siteConfig.programs[0];

  const whatsAppProgramUrl = (progName) =>
    `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
      `Hello MOTION IS ART, I am interested in joining the ${progName} program.`
    )}`;

  return (
    <>
      <SEO
        title="Dance Programs & Disciplines"
        description="Explore 5 specialized dance curriculums at MOTION IS ART: Hip-Hop, Popping, Bollywood Fusion, Contemporary, and Urban Choreography. Foundations through masterclass levels."
      />

      <div className="pt-28 sm:pt-36 pb-24 sm:pb-32 bg-[#0B0B0F] text-[#F5F3F8]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          
          {/* Page Editorial Header */}
          <div className="pb-12 border-b border-white/[0.08] max-w-4xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ CURRICULUM ARCHITECTURE ]
            </span>
            <h1 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase">
              FIVE DISCIPLINES. <br />
              <span className="text-[#A78BFA]">ONE ARTISTIC STANDARD.</span>
            </h1>
            <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] leading-relaxed max-w-2xl font-sans">
              From underground street battles to avant-garde theater stages. Each curriculum is constructed around physiological foundation, musical pocket, and personal style.
            </p>
          </div>

          {/* Program Discipline Tabs */}
          <div className="mt-10 flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 border-b border-white/[0.08]">
            {siteConfig.programs.map((prog, idx) => {
              const isActive = prog.id === activeTab;
              return (
                <button
                  key={prog.id}
                  onClick={() => setActiveTab(prog.id)}
                  className={`flex-shrink-0 flex items-center gap-3 px-5 py-3 rounded-sm font-sans text-xs sm:text-sm tracking-wider uppercase font-semibold transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
                    isActive
                      ? 'bg-[#15151C] text-white border-b-2 border-[#8B5CF6] shadow-[0_4px_20px_rgba(139,92,246,0.15)]'
                      : 'text-[#A5A1B2] hover:text-[#F5F3F8] hover:bg-white/[0.03]'
                  }`}
                >
                  <span className={`font-mono text-[11px] ${isActive ? 'text-[#8B5CF6]' : 'opacity-60'}`}>
                    0{idx + 1}
                  </span>
                  <span>{prog.name}</span>
                  {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] animate-pulse" />}
                </button>
              );
            })}
          </div>

          {/* Active Program Deep Dive */}
          <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            
            {/* Visual Column */}
            <div className="lg:col-span-6 relative flex flex-col">
              <div className="relative w-full aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#15151C] shadow-2xl">
                <img
                  key={activeProgram.image}
                  src={activeProgram.image}
                  alt={`${activeProgram.name} dance discipline showcase photograph`}
                  loading="lazy"
                  className="w-full h-full object-cover object-center filter contrast-[1.1] brightness-[0.92] transition-all duration-500 scale-100 hover:scale-[1.02]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-[#0B0B0F]/30 to-transparent opacity-90 pointer-events-none" />
                <div className="film-grain absolute inset-0 pointer-events-none" />

                <div className="absolute top-5 left-5 right-5 flex items-center justify-between pointer-events-none z-10">
                  <span className="font-mono text-[10px] font-semibold text-white bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-sm border border-white/10 tracking-widest uppercase">
                    {activeProgram.badge}
                  </span>
                  <span className="font-mono text-[10px] text-[#A78BFA] bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-sm border border-[#8B5CF6]/30 uppercase tracking-wider flex items-center gap-1.5">
                    <Activity className="w-3 h-3 text-[#8B5CF6]" />
                    {activeProgram.tempoRange}
                  </span>
                </div>

                <div className="absolute bottom-6 left-6 right-6 z-10 pointer-events-none">
                  <span className="font-mono text-xs text-[#8B5CF6] uppercase tracking-widest block mb-1">
                    PROGRAM PROFILE // 0{siteConfig.programs.findIndex((p) => p.id === activeProgram.id) + 1}
                  </span>
                  <h3 className="font-display font-bold text-2xl sm:text-3xl text-white uppercase tracking-tight">
                    {activeProgram.subtitle}
                  </h3>
                </div>
              </div>

              {/* Energy Profile Badges */}
              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="p-4 rounded-sm bg-[#15151C] border border-white/[0.07] flex items-center gap-3">
                  <Zap className="w-4 h-4 text-[#8B5CF6] flex-shrink-0" />
                  <div>
                    <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Energy Profile</span>
                    <span className="font-sans text-xs font-semibold text-white">{activeProgram.intensity}</span>
                  </div>
                </div>
                <div className="p-4 rounded-sm bg-[#15151C] border border-white/[0.07] flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#8B5CF6] flex-shrink-0" />
                  <div>
                    <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">Schedule Window</span>
                    <span className="font-sans text-xs font-semibold text-white">{activeProgram.scheduleOverview}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Curriculum Description & Actions */}
            <div className="lg:col-span-6 flex flex-col justify-between p-6 sm:p-8 rounded-sm bg-[#15151C] border border-white/[0.08]">
              <div>
                <span className="font-mono text-xs text-[#8B5CF6] font-bold block mb-1">
                  DISCIPLINE BREAKDOWN
                </span>
                <h2 className="font-display font-bold text-3xl sm:text-4xl text-[#F5F3F8] uppercase tracking-tight">
                  {activeProgram.name}
                </h2>
                <p className="mt-2 text-sm sm:text-base font-medium text-[#A78BFA]">
                  {activeProgram.tagline}
                </p>

                <p className="mt-5 text-sm text-[#A5A1B2] leading-relaxed">
                  {activeProgram.description}
                </p>

                {/* Core Movement Syllabus */}
                <div className="mt-8">
                  <h3 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
                    CORE MOVEMENT SYLLABUS
                  </h3>
                  <div className="space-y-3">
                    {activeProgram.highlights.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] mt-0.5 flex-shrink-0" />
                        <span className="text-xs sm:text-sm text-[#F5F3F8] leading-snug">
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Progression Stages */}
                <div className="mt-8 pt-6 border-t border-white/[0.08]">
                  <h3 className="font-mono text-xs uppercase tracking-wider text-[#A5A1B2] font-semibold mb-3">
                    PROGRESSION STAGES
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {activeProgram.levels.map((lvl, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-sm bg-[#0B0B0F] border border-white/[0.08] text-xs font-mono text-[#F5F3F8]"
                      >
                        <span className="text-[#8B5CF6] font-bold">0{idx + 1}</span>
                        {lvl}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons for this specific program */}
              <div className="mt-8 pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <a
                  href={whatsAppProgramUrl(activeProgram.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-mono font-medium text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-sm transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>INQUIRE ABOUT {activeProgram.name.toUpperCase()}</span>
                </a>

                {onOpenTrial && (
                  <button
                    onClick={() => onOpenTrial(activeProgram.id)}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all rounded-sm shadow-[0_0_15px_-3px_rgba(139,92,246,0.5)]"
                  >
                    <span>BOOK TRIAL PASS</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                )}
              </div>

            </div>

          </div>

        </div>
      </div>
    </>
  );
};

export default ClassesPage;
