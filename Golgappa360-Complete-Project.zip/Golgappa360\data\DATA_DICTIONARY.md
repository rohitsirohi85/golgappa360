# SmartMess AI — Synthetic Dataset Dictionary & Generation Methodology

> **Academic & Ethical Disclaimer**: This dataset consists entirely of **synthetic benchmark data** generated for the SmartMess AI (MCA Major Project). It is mathematically modeled to simulate institutional hostel mess operations and does not represent real student or institutional metrics from any college or organization.

---

## 1. Schema & Data Dictionary

| Column Name | Data Type | Physical Unit | Domain / Permitted Values | Availability Phase | Description |
| :--- | :--- | :--- | :--- | :---: | :--- |
| `record_id` | String | Identifier | `REC-0001` to `REC-1000` | Pre-service | Unique surrogate key for each meal service observation. |
| `date` | Date (ISO 8601) | Calendar Date | `2025-11-01` to `2026-09-30` | Pre-service | Calendar date of the scheduled meal service. |
| `weekday` | String | Categorical | `Monday` to `Sunday` | Pre-service | Day of the week for capturing cyclical attendance patterns. |
| `is_weekend` | Integer | Binary Flag | `0` (Mon-Fri), `1` (Sat-Sun) | Pre-service | Indicator flag for weekend days when hostel dining drops. |
| `meal_type` | String | Categorical | `breakfast`, `lunch`, `dinner` | Pre-service | Designated service window for the meal. |
| `menu_category` | String | Categorical | `continental_light`, `rice_grains`, `roti_breads`, `curry_dal`, `special_feast` | Pre-service | Primary culinary composition category of the menu. |
| `weather_condition` | String | Categorical | `clear`, `overcast`, `rainy`, `extreme_heat`, `cold` | Pre-service | Weather forecast at the time of morning food preparation. |
| `expected_attendance` | Integer | Count | `400` to `1050` students | Pre-service | Projected student turnout based on roster & RSVP check-ins. |
| `food_prepared_kg` | Float (2 dec) | Kilograms (kg) | `164.98` to `750.00` kg | Pre-service | Total weight of all dishes cooked and staged in the kitchen. |
| `cost_per_kg` | Float (2 dec) | INR (₹) / kg | `₹48.00` to `₹185.00` / kg | Pre-service | Weighted average raw ingredient + cooking gas cost per kg. |
| `total_prepared_cost`| Float (2 dec) | INR (₹) | `₹14,000` to `₹95,000` | Pre-service | Budget spent on preparation: `food_prepared_kg * cost_per_kg`. |
| `food_waste_kg` | Float (2 dec) | Kilograms (kg) | `6.92` to `213.40` kg | **Post-service Target** | **Target variable**: Ground-truth total food waste discarded. |
| `food_waste_pct` | Float (2 dec) | Percentage (%) | `2.52%` to `33.45%` | Post-service Metric | Operational metric: `(food_waste_kg / food_prepared_kg) * 100`. |
| `total_wasted_cost` | Float (2 dec) | INR (₹) | `₹500` to `₹22,000` | Post-service Metric | Direct financial loss: `food_waste_kg * cost_per_kg`. |

---

## 2. Synthetic Value Generation Mechanics

The dataset is generated through a parametric stochastic model implemented in `scripts/generate_synthetic_dataset.py` with fixed random seed `42`.

### A. Calendar & Weather Simulation
1. **Chronological Sequencing**: 1,000 records span 334 consecutive days (~11 months from November 2025 to September 2026), generating exactly 3 service slots (`breakfast`, `lunch`, `dinner`) per calendar day.
2. **Seasonal Climate Model**: Weather conditions follow seasonal transition matrices (e.g. monsoon precipitation probability surges during June–September; extreme heat probability rises during April–May).

### B. Expected Attendance & Behavioral Drops
- Base attendance parameters for a 1,000-registered student hostel:
  - Breakfast: 580–780 students (morning skipping)
  - Lunch: 880–1,020 students (peak campus presence)
  - Dinner: 760–940 students
- **Behavioral Shifts**:
  - *Friday Dinners*: Attendance drops by 14% to 22% due to weekend home travel.
  - *Weekends (Sat/Sun)*: Turnout drops by 12% to 24% as students dine outside.
  - *Rainy Weather*: Turnout drops by 8% to 15% as day scholars leave campus early.
  - *Special Feasts*: Attendance surges by +6% to +14%.

### C. Kitchen Preparation Logic (`food_prepared_kg`)
- Calculated by simulating kitchen staff rules of thumb:
  $$\text{Portion}_{\text{base}} \in [0.34, 0.68]\,\text{kg/student}$$
  $$\text{Buffer} \in [4\%, 14\%]$$
  $$\text{food\_prepared\_kg} = \text{expected\_attendance} \times \text{Portion}_{\text{base}} \times (1 + \text{Buffer}) \times \mathcal{N}(1.0, 0.025)$$

### D. Actual Food Waste Generation (`food_waste_kg` — Target)
Waste comprises three additive components plus non-linear stochastic human eating noise:
1. **Unserved Kitchen Surplus**: Occurs when actual turnout falls below expected attendance (e.g., unexpected storms, weekend trips).
2. **Plate Discards**: 1.8% to 4.2% of consumed food is scraped off dining plates.
3. **Vessel / Pan Trimmings**: 1.5 to 3.5 kg of unavoidable starch and gravy residue adhering to large commercial cauldrons.
4. **Stochastic Appetite / Preference Shock**: Random disturbances reflecting dish spiciness, unliked recipes, or exam-period stress.

### E. Physical & Accounting Constraints Enforced
1. **Non-negativity**: All physical masses and financial amounts are strictly $> 0$.
2. **No Impossible Waste**: $\text{food\_waste\_kg} \le \text{food\_prepared\_kg}$ is strictly enforced.
3. **Financial Consistency**: $\text{total\_prepared\_cost} \equiv \text{round}(\text{food\_prepared\_kg} \times \text{cost\_per\_kg}, 2)$.
4. **Waste Percentage Bounds**: Bounded within realistic institutional mess boundaries ($2.52\%$ to $33.45\%$).

---

## 3. Prevention of Target Leakage

Target leakage occurs when features contain information that would only be available after the target event has occurred. 

In this dataset:
- **Pre-Service Features (Permissible for ML Model Training)**:
  `date`, `weekday`, `is_weekend`, `meal_type`, `menu_category`, `weather_condition`, `expected_attendance`, `food_prepared_kg`, `cost_per_kg`, `total_prepared_cost`.
  All these features are established **prior to cooking**.
- **Post-Service Operational Outcomes (Forbidden as ML Predictors)**:
  `food_waste_kg` (the target), `food_waste_pct`, and `total_wasted_cost`.
  Actual attendance headcounts and consumed masses are **never** included as predictor inputs.

---

## 4. Verification & Reproducibility Commands

To regenerate the exact dataset with seed 42:
```bash
python scripts/generate_synthetic_dataset.py --samples 1000 --seed 42 --output data/smartmess_sample.csv
```

To run the validation test suite:
```bash
python scripts/validate_dataset.py --input data/smartmess_sample.csv --report data/data_quality_summary.md --json-summary data/data_quality_summary.json
```
