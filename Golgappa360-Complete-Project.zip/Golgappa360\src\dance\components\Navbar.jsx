import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Sparkles } from 'lucide-react';
import { ACADEMY_CONFIG } from '../data/danceData';

export const Navbar = ({ onOpenTrial }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile drawer on escape
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileMenuOpen]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { label: 'Classes', href: '#programs' },
    { label: 'Our Story', href: '#about' },
    { label: 'Instructors', href: '#people' },
    { label: 'The Space', href: '#space' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e, href) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0B0B0F]/90 backdrop-blur-md border-b border-white/[0.08] py-4'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between">
          {/* Text-Based MOTION IS ART Original Logo */}
          <a
            href="#"
            className="group flex items-center gap-2.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded-sm py-1"
            aria-label="MOTION IS ART Homepage"
          >
            <div className="flex flex-col">
              <span className="font-display font-black tracking-[-0.04em] text-lg sm:text-xl uppercase text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors leading-none">
                MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
              </span>
              <span className="font-mono text-[9px] tracking-widest uppercase text-[#A5A1B2] mt-0.5 opacity-80">
                DANCE ACADEMY
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8" aria-label="Main Navigation">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-sm font-medium tracking-wide text-[#A5A1B2] hover:text-[#F5F3F8] transition-colors relative py-1 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#8B5CF6] transition-all duration-200 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Desktop Right Action */}
          <div className="hidden lg:flex items-center gap-4">
            <button
              onClick={onOpenTrial}
              className="relative inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all duration-200 rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.5)] hover:shadow-[0_0_25px_0_rgba(167,139,250,0.6)] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#8B5CF6] focus-visible:ring-offset-[#0B0B0F]"
            >
              <span>BOOK A TRIAL</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex items-center gap-3 lg:hidden">
            <button
              onClick={onOpenTrial}
              className="px-3 py-1.5 text-[11px] font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
            >
              TRIAL
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#F5F3F8] hover:text-[#A78BFA] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Accessible Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation"
          className="fixed inset-0 z-50 lg:hidden flex flex-col bg-[#0B0B0F]/98 backdrop-blur-xl animate-fade-in"
        >
          {/* Mobile Drawer Top Bar */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/[0.08]">
            <a
              href="#"
              onClick={(e) => {
                handleNavClick(e, '#');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="font-display font-black text-lg uppercase text-[#F5F3F8]"
            >
              MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
            </a>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 text-[#A5A1B2] hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
              aria-label="Close menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Mobile Drawer Navigation List */}
          <div className="flex-1 overflow-y-auto px-6 py-8 flex flex-col justify-between">
            <nav className="flex flex-col gap-6" aria-label="Mobile Menu Links">
              {navLinks.map((link, idx) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="group flex items-center justify-between text-2xl font-display font-bold text-[#F5F3F8] hover:text-[#A78BFA] transition-colors py-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded"
                >
                  <span className="flex items-center gap-3">
                    <span className="font-mono text-xs text-[#8B5CF6] opacity-75">
                      0{idx + 1}
                    </span>
                    {link.label}
                  </span>
                  <ArrowUpRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity text-[#8B5CF6]" />
                </a>
              ))}
            </nav>

            {/* Mobile Drawer Bottom Call-To-Action */}
            <div className="pt-8 mt-6 border-t border-white/[0.08] flex flex-col gap-4">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenTrial();
                }}
                className="w-full flex items-center justify-center gap-2 py-4 px-6 text-sm font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.6)]"
              >
                <span>BOOK A TRIAL CLASS</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between text-xs text-[#A5A1B2] font-mono pt-2">
                <span>{ACADEMY_CONFIG.contact.phone}</span>
                <span>METROPOLIS, NY</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
