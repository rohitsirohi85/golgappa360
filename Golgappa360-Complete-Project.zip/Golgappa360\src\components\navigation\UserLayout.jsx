import React from 'react';
import { useLocation } from 'react-router-dom';
import { useUI } from '../../context/UIContext';
import { UserBottomNavigation } from './UserBottomNavigation';
import { ToastContainer } from '../common/Toast';
import { Wifi, BatteryMedium, Signal, Smartphone, Maximize2, Tv, Camera, X } from 'lucide-react';

export const UserLayout = ({ children }) => {
  const location = useLocation();
  const {
    isDeviceFrame,
    setIsDeviceFrame,
    isPresentationMode,
    setIsPresentationMode,
    isScreenshotMode,
    setIsScreenshotMode,
  } = useUI();

  // If somehow accessed under /admin, do not render user framing or bottom nav
  const isAdminRoute = location.pathname.startsWith('/admin');

  // Determine whether to show bottom navigation on current screen
  const hideBottomNavRoutes = [
    '/splash',
    '/onboarding',
    '/login',
    '/register',
    '/booking-confirmation',
    '/charging-complete',
    '/bill',
    '/admin',
  ];

  const shouldShowBottomNav =
    !isAdminRoute &&
    !hideBottomNavRoutes.some((route) => location.pathname.startsWith(route));

  if (isAdminRoute) {
    return <>{children}</>;
  }

  return (
    <div
      className={`min-h-[100dvh] w-full bg-[#04060C] flex flex-col md:items-center md:justify-center text-slate-100 antialiased selection:bg-[#00F5A0]/20 selection:text-[#00F5A0] ${
        isPresentationMode ? 'text-base font-medium' : ''
      }`}
    >
      {/* Top Desktop Controls Bar (hidden during clean screenshot mode) */}
      {!isScreenshotMode && (
        <div className="hidden md:flex items-center justify-between w-full max-w-4xl px-4 py-2.5 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00F5A0] animate-pulse" />
            <span className="font-semibold text-slate-200 tracking-wide">
              EV SMART
            </span>
            <span className="text-slate-500">— Mobile Prototype</span>
            {isPresentationMode && (
              <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]/30">
                PROJECTOR / PRESENTATION MODE
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Presentation Mode Toggle */}
            <button
              onClick={() => setIsPresentationMode(!isPresentationMode)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all text-xs ${
                isPresentationMode
                  ? 'bg-[#38BDF8]/20 border-[#38BDF8] text-[#38BDF8]'
                  : 'bg-[#0D1527] hover:bg-[#16223D] border-white/10 text-slate-300'
              }`}
              title="Toggle projector-optimized Presentation Mode"
            >
              <Tv className="w-3.5 h-3.5" />
              <span>{isPresentationMode ? 'Presentation ON' : 'Presentation'}</span>
            </button>

            {/* Screenshot Mode Toggle */}
            <button
              onClick={() => setIsScreenshotMode(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0D1527] hover:bg-[#16223D] border border-white/10 text-slate-300 transition-all text-xs"
              title="Clean Screenshot Mode (hides desktop wrapper)"
            >
              <Camera className="w-3.5 h-3.5 text-[#00F5A0]" />
              <span>Clean Shot</span>
            </button>

            {/* Frame / Responsive Toggle */}
            <button
              onClick={() => setIsDeviceFrame(!isDeviceFrame)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0D1527] hover:bg-[#16223D] border border-white/10 text-slate-300 transition-all text-xs"
              title="Toggle between phone frame and full responsive view"
            >
              {isDeviceFrame ? (
                <>
                  <Maximize2 className="w-3.5 h-3.5 text-[#00F5A0]" />
                  <span>Responsive</span>
                </>
              ) : (
                <>
                  <Smartphone className="w-3.5 h-3.5 text-[#00F5A0]" />
                  <span>Phone Frame</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Floating Exit Button for Screenshot Mode */}
      {isScreenshotMode && (
        <button
          onClick={() => setIsScreenshotMode(false)}
          className="fixed top-3 right-3 z-[999] px-3 py-1.5 rounded-full bg-slate-900/90 border border-white/20 text-xs text-slate-300 hover:text-white flex items-center gap-1.5 shadow-lg backdrop-blur-md"
          title="Exit Clean Screenshot Mode"
        >
          <X className="w-3.5 h-3.5" />
          <span>Exit Clean Shot</span>
        </button>
      )}

      {/* Main Mobile Viewport Container */}
      <div
        className={`
          w-full min-h-[100dvh] transition-all duration-300 relative flex flex-col bg-[#070B19]
          ${
            isDeviceFrame
              ? 'md:min-h-0 md:max-w-[430px] md:h-[915px] md:my-4 md:rounded-[50px] md:border-[10px] md:border-[#1E283D] md:shadow-[0_25px_70px_rgba(0,0,0,0.85)] md:overflow-hidden'
              : 'max-w-md'
          }
        `}
      >
        {/* Device Status Bar - only shown on desktop device simulator */}
        <div className="hidden md:flex sticky top-0 z-50 px-6 pt-3 pb-1 items-center justify-between text-xs text-slate-300 font-medium select-none bg-[#070B19]/80 backdrop-blur-md">
          <span>09:41</span>

          {/* Dynamic Island / Speaker notch simulation */}
          <div className="w-24 h-4 bg-black/80 rounded-full flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-[#070B19] border border-white/10 ml-auto mr-1.5" />
          </div>

          <div className="flex items-center gap-1.5 text-slate-300">
            <Signal className="w-3 h-3 stroke-[2.5]" />
            <Wifi className="w-3 h-3 stroke-[2.5]" />
            <BatteryMedium className="w-4 h-4 stroke-[2.5] text-[#00F5A0]" />
          </div>
        </div>

        {/* User Screen Content */}
        <main
          className={`flex-1 flex flex-col overflow-y-auto no-scrollbar relative ${
            shouldShowBottomNav ? 'pb-24' : 'pb-6'
          }`}
        >
          {children}
        </main>

        {/* Global Toast Alert Layer */}
        <ToastContainer />

        {/* User Bottom Navigation (Never inside Admin) */}
        {shouldShowBottomNav && <UserBottomNavigation />}
      </div>
    </div>
  );
};

export default UserLayout;
