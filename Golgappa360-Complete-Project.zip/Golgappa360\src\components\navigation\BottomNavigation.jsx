import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, MapPin, Calendar, Zap, User } from 'lucide-react';
import { useEV } from '../../context/EVContext';

export const BottomNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isCharging } = useEV();

  const tabs = [
    { id: 'home', label: 'Home', icon: Home, route: '/home' },
    { id: 'stations', label: 'Stations', icon: MapPin, route: '/stations' },
    { id: 'bookings', label: 'Bookings', icon: Calendar, route: '/bookings' },
    { id: 'charging', label: 'Charging', icon: Zap, route: '/live-charging', isLive: isCharging },
    { id: 'profile', label: 'Profile', icon: User, route: '/profile' },
  ];

  // Check if current route matches tab
  const getIsActive = (route) => {
    if (route === '/home') {
      return location.pathname === '/' || location.pathname === '/home';
    }
    return location.pathname.startsWith(route);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070B19]/95 backdrop-blur-xl border-t border-white/[0.08] max-w-md mx-auto">
      <div className="flex items-center justify-around px-2 py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = getIsActive(tab.route);

          return (
            <button
              key={tab.id}
              onClick={() => navigate(tab.route)}
              className={`
                relative flex flex-col items-center justify-center flex-1 py-1 px-2 rounded-xl transition-all duration-200 select-none
                ${isActive ? 'text-[#00F5A0]' : 'text-slate-400 hover:text-slate-200'}
              `}
            >
              {/* Active ambient glow pill */}
              {isActive && (
                <span className="absolute -top-2 w-8 h-1 bg-[#00F5A0] rounded-full shadow-[0_0_12px_#00F5A0]" />
              )}

              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 stroke-[2.2]' : 'stroke-[1.8]'
                  }`}
                />

                {/* Pulse badge on Charging tab if session is live */}
                {tab.isLive && (
                  <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00F5A0] opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00F5A0]" />
                  </span>
                )}
              </div>

              <span
                className={`text-[11px] font-medium tracking-tight mt-1 transition-all ${
                  isActive ? 'font-semibold text-white' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
      {/* iOS style home indicator bar */}
      <div className="w-32 h-1 bg-white/20 rounded-full mx-auto mb-1 mt-0.5" />
    </nav>
  );
};
