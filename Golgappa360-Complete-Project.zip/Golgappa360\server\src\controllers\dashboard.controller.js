import { AnalyticsService } from '../services/analyticsService.js';
import { getDbStatus } from '../config/db.js';

export async function getSummary(req, res, next) {
  try {
    const { range = '30d', startDate, endDate, productId = 'all' } = req.query;
    const result = await AnalyticsService.getDashboardSummary({ range, startDate, endDate, productId });
    const dbStatus = getDbStatus();

    res.json({
      success: true,
      data: {
        ...result,
        dbStatus
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function getSalesTrend(req, res, next) {
  try {
    const { range = '30d', startDate, endDate, productId = 'all', granularity = 'daily' } = req.query;
    const result = await AnalyticsService.getSalesTrend({ range, startDate, endDate, productId, granularity });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}

export async function getHourlySales(req, res, next) {
  try {
    const { range = '30d', startDate, endDate, productId = 'all' } = req.query;
    const result = await AnalyticsService.getHourlySales({ range, startDate, endDate, productId });
    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
}
