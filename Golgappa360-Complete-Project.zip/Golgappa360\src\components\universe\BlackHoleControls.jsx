import React from 'react';
import { BLACK_HOLES_CATALOG } from '../../data/blackHoles.js';

/**
 * BlackHoleControls — Floating Control Deck for the Black Hole Experience (U7)
 * 
 * Provides:
 * - Play / Pause accretion disk rotation
 * - Reset view & camera
 * - Speed multipliers (0.5x, 1x, 2x)
 * - Toggles: Accretion Disk, Lensing, Photon Ring, Relativistic Jets, Hotspot Labels
 * - Target Black Hole Selector (Sagittarius A*, M87*, Cygnus X-1)
 */
export default function BlackHoleControls({
  currentObject,
  onSelectObject,
  isPlaying,
  onTogglePlay,
  speedFactor,
  onChangeSpeed,
  onResetView,
  showAccretionDisk,
  onToggleAccretionDisk,
  showLensing,
  onToggleLensing,
  showPhotonRing,
  onTogglePhotonRing,
  showJets,
  onToggleJets,
  showHotspots,
  onToggleHotspots,
  className = '',
}) {
  const hasJets = currentObject?.hasJets ?? false;

  return (
    <div
      className={`flex flex-wrap items-center gap-2 p-1.5 sm:p-2 rounded-2xl bg-[#030614]/85 backdrop-blur-xl border border-white/10 shadow-[0_10px_35px_rgba(0,0,0,0.7)] select-none text-xs font-mono text-slate-300 ${className}`}
      role="toolbar"
      aria-label="Black hole simulation controls"
    >
      {/* Target Black Hole Selector */}
      <div className="flex items-center gap-1 pr-2 border-r border-white/10">
        <span className="text-[10px] text-amber-400 font-semibold px-1 hidden sm:inline">TARGET:</span>
        <div className="flex items-center gap-1">
          {BLACK_HOLES_CATALOG.map((bh) => {
            const isCurrent = currentObject?.id === bh.id;
            return (
              <button
                key={bh.id}
                type="button"
                onClick={() => onSelectObject(bh)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-amber-500/25 border border-amber-400/60 text-amber-200 font-semibold shadow-[0_0_12px_rgba(245,158,11,0.35)]'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
                title={`Switch to ${bh.name}`}
              >
                {bh.name.replace(' (Messier 87)', '').replace(' (X-Ray Binary)', '')}
              </button>
            );
          })}
        </div>
      </div>

      {/* Play / Pause Rotation */}
      <button
        type="button"
        onClick={onTogglePlay}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
          isPlaying
            ? 'bg-amber-500/20 border-amber-400/40 text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.25)]'
            : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
        }`}
        title={isPlaying ? 'Pause disk rotation' : 'Resume disk rotation'}
        aria-label={isPlaying ? 'Pause disk rotation' : 'Resume disk rotation'}
      >
        <span>{isPlaying ? '⏸' : '▶'}</span>
        <span className="hidden sm:inline">{isPlaying ? 'Pause' : 'Resume'}</span>
      </button>

      {/* Rotation Speed Multiplier */}
      <button
        type="button"
        onClick={onChangeSpeed}
        className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        title="Cycle simulation speed (0.5x, 1x, 2x)"
      >
        <span className="text-amber-300 font-bold">{speedFactor}×</span>
      </button>

      {/* Reset View */}
      <button
        type="button"
        onClick={onResetView}
        className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        title="Reset camera and zoom"
        aria-label="Reset camera"
      >
        <span>⟳</span>
        <span className="hidden sm:inline">Reset</span>
      </button>

      {/* Separator */}
      <div className="hidden md:block w-px h-5 bg-white/10" />

      {/* Feature Toggles */}
      <div className="flex items-center gap-1 flex-wrap">
        {/* Toggle Accretion Disk */}
        <button
          type="button"
          onClick={onToggleAccretionDisk}
          className={`px-2.5 py-1.5 rounded-xl border text-[11px] transition-all cursor-pointer ${
            showAccretionDisk
              ? 'bg-orange-500/20 border-orange-400/40 text-orange-200'
              : 'bg-white/[0.02] border-white/5 text-slate-500 line-through'
          }`}
          title="Toggle Accretion Disk visibility"
        >
          Disk
        </button>

        {/* Toggle Gravitational Lensing */}
        <button
          type="button"
          onClick={onToggleLensing}
          className={`px-2.5 py-1.5 rounded-xl border text-[11px] transition-all cursor-pointer ${
            showLensing
              ? 'bg-cyan-500/20 border-cyan-400/40 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
              : 'bg-white/[0.02] border-white/5 text-slate-500 line-through'
          }`}
          title="Toggle Gravitational Lensing & Spacetime Curvature"
        >
          Lensing
        </button>

        {/* Toggle Photon Ring */}
        <button
          type="button"
          onClick={onTogglePhotonRing}
          className={`px-2.5 py-1.5 rounded-xl border text-[11px] transition-all cursor-pointer ${
            showPhotonRing
              ? 'bg-yellow-500/20 border-yellow-400/40 text-yellow-200'
              : 'bg-white/[0.02] border-white/5 text-slate-500 line-through'
          }`}
          title="Toggle Photon Ring visibility"
        >
          Photon Ring
        </button>

        {/* Toggle Relativistic Jets (if black hole supports them) */}
        {hasJets && (
          <button
            type="button"
            onClick={onToggleJets}
            className={`px-2.5 py-1.5 rounded-xl border text-[11px] transition-all cursor-pointer ${
              showJets
                ? 'bg-purple-500/20 border-purple-400/40 text-purple-200 shadow-[0_0_10px_rgba(168,85,247,0.2)]'
                : 'bg-white/[0.02] border-white/5 text-slate-500 line-through'
            }`}
            title="Toggle Bipolar Relativistic Plasma Jets"
          >
            Jets
          </button>
        )}

        {/* Toggle Hotspot Labels */}
        <button
          type="button"
          onClick={onToggleHotspots}
          className={`px-2.5 py-1.5 rounded-xl border text-[11px] transition-all cursor-pointer ${
            showHotspots
              ? 'bg-white/10 border-white/20 text-white'
              : 'bg-white/[0.02] border-white/5 text-slate-500'
          }`}
          title="Toggle Hotspot Labels HUD"
        >
          Labels
        </button>
      </div>
    </div>
  );
}
