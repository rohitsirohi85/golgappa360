import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AdminRoute } from '../components/AdminRoute';
import { AdminLoginScreen } from '../screens/AdminLoginScreen';
import { AdminDashboardScreen } from '../screens/AdminDashboardScreen';
import { AdminStationsScreen } from '../screens/AdminStationsScreen';
import { AdminStationDetailsScreen } from '../screens/AdminStationDetailsScreen';
import { AdminChargersScreen } from '../screens/AdminChargersScreen';
import { AdminChargerDetailsScreen } from '../screens/AdminChargerDetailsScreen';
import { AdminUsersScreen } from '../screens/AdminUsersScreen';
import { AdminUserDetailsScreen } from '../screens/AdminUserDetailsScreen';
import { AdminBookingsScreen } from '../screens/AdminBookingsScreen';
import { AdminSessionsScreen } from '../screens/AdminSessionsScreen';
import { AdminDevicesScreen } from '../screens/AdminDevicesScreen';
import { AdminEnergyScreen } from '../screens/AdminEnergyScreen';
import { AdminRevenueScreen } from '../screens/AdminRevenueScreen';
import { AdminAnalyticsScreen } from '../screens/AdminAnalyticsScreen';
import { AdminAIScreen } from '../screens/AdminAIScreen';
import { AdminAlertsScreen } from '../screens/AdminAlertsScreen';
import { AdminReportsScreen } from '../screens/AdminReportsScreen';
import { AdminSettingsScreen } from '../screens/AdminSettingsScreen';
import { AdminAuditLogsScreen } from '../screens/AdminAuditLogsScreen';

export const AdminRoutes = () => {
  return (
    <Routes>
      {/* Admin Portal Authentication */}
      <Route path="login" element={<AdminLoginScreen />} />

      {/* Redirect root /admin to /admin/dashboard */}
      <Route path="" element={<Navigate to="/admin/dashboard" replace />} />

      {/* 1. Core Command Dashboard */}
      <Route
        path="dashboard"
        element={
          <AdminRoute>
            <AdminDashboardScreen />
          </AdminRoute>
        }
      />

      {/* 2. Stations Fleet Management */}
      <Route
        path="stations"
        element={
          <AdminRoute>
            <AdminStationsScreen />
          </AdminRoute>
        }
      />
      <Route
        path="stations/:id"
        element={
          <AdminRoute>
            <AdminStationDetailsScreen />
          </AdminRoute>
        }
      />

      {/* 3. Chargers Fleet & Live Telemetry */}
      <Route
        path="chargers"
        element={
          <AdminRoute>
            <AdminChargersScreen />
          </AdminRoute>
        }
      />
      <Route
        path="chargers/:id"
        element={
          <AdminRoute>
            <AdminChargerDetailsScreen />
          </AdminRoute>
        }
      />

      {/* 4. User Accounts Management (Super Admin) */}
      <Route
        path="users"
        element={
          <AdminRoute requiredRole="admin">
            <AdminUsersScreen />
          </AdminRoute>
        }
      />
      <Route
        path="users/:id"
        element={
          <AdminRoute requiredRole="admin">
            <AdminUserDetailsScreen />
          </AdminRoute>
        }
      />

      {/* 5. Bookings & Charging Sessions */}
      <Route
        path="bookings"
        element={
          <AdminRoute>
            <AdminBookingsScreen />
          </AdminRoute>
        }
      />
      <Route
        path="sessions"
        element={
          <AdminRoute>
            <AdminSessionsScreen />
          </AdminRoute>
        }
      />

      {/* 6. IoT Hardware & Controllers (ESP32) */}
      <Route
        path="devices"
        element={
          <AdminRoute>
            <AdminDevicesScreen />
          </AdminRoute>
        }
      />

      {/* 7. Energy Monitoring & Revenue Analytics */}
      <Route
        path="energy"
        element={
          <AdminRoute>
            <AdminEnergyScreen />
          </AdminRoute>
        }
      />
      <Route
        path="revenue"
        element={
          <AdminRoute>
            <AdminRevenueScreen />
          </AdminRoute>
        }
      />

      {/* 8. Advanced Analytics & AI Insights */}
      <Route
        path="analytics"
        element={
          <AdminRoute>
            <AdminAnalyticsScreen />
          </AdminRoute>
        }
      />
      <Route
        path="ai"
        element={
          <AdminRoute>
            <AdminAIScreen />
          </AdminRoute>
        }
      />

      {/* 9. Safety Alerts & System Faults */}
      <Route
        path="alerts"
        element={
          <AdminRoute>
            <AdminAlertsScreen />
          </AdminRoute>
        }
      />

      {/* 10. Reports & Operational Exports */}
      <Route
        path="reports"
        element={
          <AdminRoute>
            <AdminReportsScreen />
          </AdminRoute>
        }
      />

      {/* 11. System Configuration & Audit Logs (Super Admin) */}
      <Route
        path="settings"
        element={
          <AdminRoute requiredRole="admin">
            <AdminSettingsScreen />
          </AdminRoute>
        }
      />
      <Route
        path="audit-logs"
        element={
          <AdminRoute requiredRole="admin">
            <AdminAuditLogsScreen />
          </AdminRoute>
        }
      />

      {/* Fallback inside /admin/* */}
      <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
    </Routes>
  );
};

export default AdminRoutes;
