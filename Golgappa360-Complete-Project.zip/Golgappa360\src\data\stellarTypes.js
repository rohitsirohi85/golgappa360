/**
 * STELLAR — Stellar Evolutionary Types Database ("The Stellar Family")
 * Distinguishes evolutionary structure, interior state, and scale
 * from spectral temperature classes O-B-A-F-G-K-M.
 */

export const STELLAR_FAMILIES = [
  {
    id: 'red-dwarf',
    name: 'Red Dwarf',
    subtitle: 'The Cosmic Marathon Runners',
    evolutionaryStage: 'Main Sequence (Low-Mass)',
    typicalSize: '≈ 0.08–0.60 × Sun',
    temperature: '≈ 2,400–3,700 K',
    lifetime: 'Up to trillions of years',
    density: '≈ 10–100 × Sun density',
    destiny: 'Gradual contraction into hypothetical blue/white dwarf',
    exampleStar: 'Proxima Centauri',
    colorHex: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.45)',
    visualColor: 'red-dwarf',
    shortExplanation:
      'The quiet workhorses of the cosmos. Because their entire interior is convective, they circulate hydrogen from core to surface and burn fuel with extreme frugality.',
    extendedDetails:
      'Red dwarfs make up roughly 70–80% of all stars in our galaxy. Their lifespans exceed the current 13.8-billion-year age of the universe by hundreds of times, meaning not a single red dwarf that ever formed has died of natural old age yet.',
  },
  {
    id: 'yellow-dwarf',
    name: 'Yellow Dwarf',
    subtitle: 'The Cradle of Life',
    evolutionaryStage: 'Main Sequence (Intermediate-Mass)',
    typicalSize: '≈ 0.9–1.15 × Sun',
    temperature: '≈ 5,300–6,000 K',
    lifetime: '≈ 9–10 billion years',
    density: '≈ 1.4 g/cm³ (Solar average)',
    destiny: 'Red giant phase followed by planetary nebula & white dwarf',
    exampleStar: 'Sun, Alpha Centauri A',
    colorHex: '#fbbf24',
    glowColor: 'rgba(251, 191, 36, 0.5)',
    visualColor: 'yellow',
    shortExplanation:
      'Balanced main-sequence stars fusing core hydrogen into helium through the proton-proton chain with calm, stable solar radiation over billions of years.',
    extendedDetails:
      'Yellow dwarfs maintain hydrostatic equilibrium between inward gravitational collapse and outward thermonuclear radiation pressure. After exhausting hydrogen, their cores contract while their outer atmospheres swell into red giants.',
  },
  {
    id: 'blue-giant',
    name: 'Blue Giant',
    subtitle: 'Incandescent Powerhouses',
    evolutionaryStage: 'Main Sequence or Early Post-Main Sequence',
    typicalSize: '≈ 5–15 × Sun',
    temperature: '≈ 10,000–30,000 K',
    lifetime: '≈ 10–100 million years',
    density: '≈ 0.01–0.1 × Sun density',
    destiny: 'Core-collapse supernova (Type II) or massive remnant',
    exampleStar: 'Spica, Bellatrix',
    colorHex: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.55)',
    visualColor: 'blue',
    shortExplanation:
      'Fiercely energetic stars burning through hydrogen at prodigious rates. They emit intense ionizing ultraviolet radiation and shed violent stellar winds.',
    extendedDetails:
      'Blue giants reside in the upper-left of the Hertzsprung-Russell diagram. Because luminosity scales roughly as the 3.5th power of stellar mass, a star with 10 times the Sun’s mass shines with thousands of times more light, living an ephemeral, fiery existence.',
  },
  {
    id: 'red-giant',
    name: 'Red Giant',
    subtitle: 'Swollen Stellar Elders',
    evolutionaryStage: 'Post-Main Sequence (Helium Shell Fusion)',
    typicalSize: '≈ 20–100 × Sun',
    temperature: '≈ 3,000–4,500 K',
    lifetime: '≈ 100–500 million years',
    density: 'Very low (outer envelope thinner than Earth air)',
    destiny: 'Puffs off outer envelopes into planetary nebula; core becomes white dwarf',
    exampleStar: 'Arcturus, Aldebaran',
    colorHex: '#fb923c',
    glowColor: 'rgba(251, 146, 60, 0.5)',
    visualColor: 'orange',
    shortExplanation:
      'An evolved star that has run out of core hydrogen. The core contracts and heats, igniting surrounding hydrogen/helium shells that push the outer layers out to immense sizes.',
    extendedDetails:
      'In roughly 5 billion years, our Sun will become a red giant, swelling to swallow Mercury, Venus, and possibly Earth. Although their cores reach tens of millions of Kelvin, their swollen surfaces cool to warm orange and red hues.',
  },
  {
    id: 'supergiant',
    name: 'Supergiant',
    subtitle: 'Colossi of the Cosmos',
    evolutionaryStage: 'Advanced High-Mass Evolution',
    typicalSize: '≈ 100–1,000+ × Sun',
    temperature: '≈ 3,500 K (Red) to 30,000 K (Blue)',
    lifetime: '≈ 3–15 million years',
    density: 'Near vacuum in outer envelope',
    destiny: 'Spectacular core-collapse supernova leaving neutron star or black hole',
    exampleStar: 'Betelgeuse, Rigel, Antares, Deneb',
    colorHex: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.55)',
    visualColor: 'red',
    shortExplanation:
      'The most physically colossal and radiant stars in the universe. Massive enough to sequentially fuse carbon, neon, oxygen, and silicon all the way up to iron.',
    extendedDetails:
      'Supergiants can be blue (like Rigel) or red (like Betelgeuse and Antares). Once their cores build up an iron core, nuclear fusion can no longer yield energy, triggering a catastrophic gravitational implosion in fractions of a second.',
  },
  {
    id: 'white-dwarf',
    name: 'White Dwarf',
    subtitle: 'The Degenerate Embers',
    evolutionaryStage: 'Stellar Remnant (Dead Core)',
    typicalSize: '≈ 0.008–0.02 × Sun (≈ Earth-sized)',
    temperature: '≈ 8,000–100,000 K (Cooling)',
    lifetime: 'Hundreds of billions to trillions of years',
    density: '≈ 1,000,000 g/cm³ (1 ton per cubic cm)',
    destiny: 'Slow cooling over trillions of years into a cold black dwarf',
    exampleStar: 'Sirius B, Procyon B',
    colorHex: '#f8fafc',
    glowColor: 'rgba(248, 250, 252, 0.65)',
    visualColor: 'white-dwarf',
    shortExplanation:
      'The exposed core of a dead low-to-medium mass star. Electron degeneracy pressure counteracts gravity, holding an entire solar mass in an Earth-sized volume.',
    extendedDetails:
      'White dwarfs no longer produce energy through nuclear fusion; they merely radiate residual thermal heat into space. Because of their small surface area, they cool at an agonizingly slow pace, remaining luminous for trillions of years.',
  },
  {
    id: 'neutron-star',
    name: 'Neutron Star',
    subtitle: 'Extreme Physics Incarnate',
    evolutionaryStage: 'Collapsed Supernova Remnant',
    typicalSize: '≈ 20 km diameter (City-sized)',
    temperature: '≈ 600,000–1,000,000+ K',
    lifetime: 'Practically eternal',
    density: '≈ 100 trillion g/cm³ (Entire Himalayas in a thimble)',
    destiny: 'Pulsar slowdown or merger (kilonova generating gold/platinum)',
    exampleStar: 'Crab Pulsar / PSR B1919+21',
    colorHex: '#c084fc',
    glowColor: 'rgba(192, 132, 252, 0.6)',
    visualColor: 'blue',
    shortExplanation:
      'Born in the supernova death of a massive star, electrons and protons are crushed together under incomprehensible gravity to form an ultra-dense sphere of pure neutrons.',
    extendedDetails:
      'A neutron star packs 1.4 to 2.1 times the mass of the Sun into a ball no wider than Manhattan. They rotate up to hundreds of times per second (pulsars), possess magnetic fields trillions of times stronger than Earth’s, and warp spacetime.',
  },
];
