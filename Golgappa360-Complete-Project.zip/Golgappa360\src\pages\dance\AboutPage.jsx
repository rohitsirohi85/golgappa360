import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Compass, Shield, Users, Layers, Award } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const AboutPage = ({ onOpenTrial }) => {
  const pillars = [
    {
      number: '01',
      title: 'Micro-Mechanics & Anatomical Truth',
      description:
        'We deconstruct the physics of weight transfer, rotational momentum, joint suspension, and deceleration. Dance is not rote mimicry; it is understanding skeletal lever systems so any choreography becomes accessible without strain.',
      tag: 'Anatomical Precision',
    },
    {
      number: '02',
      title: 'Artistic Identity Over Uniformity',
      description:
        'Commercial studios often homogenize dancers into identical clones. At MOTION IS ART, your natural idiosyncrasies, limb proportions, and personal rhythm are treated as your signature artistic advantage.',
      tag: 'Creative Agency',
    },
    {
      number: '03',
      title: 'The Cypher as Sacred Laboratory',
      description:
        'The cypher is where fear dissolves and innovation occurs in real time. We train dancers to listen to sub-frequencies, read live room energy, and improvise with unflinching confidence before audiences, judges, and cameras.',
      tag: 'Street Culture',
    },
  ];

  return (
    <>
      <SEO
        title="Our Story & Philosophy"
        description="The story and philosophy of MOTION IS ART. An urban dance academy blending underground street culture, anatomical precision, and avant-garde performance art."
      />

      <div className="pt-28 sm:pt-36 pb-24 sm:pb-32 bg-[#0B0B0F] text-[#F5F3F8]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          
          {/* Section Header */}
          <div className="pb-12 border-b border-white/[0.08] max-w-4xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ MANIFESTO & ORIGIN ]
            </span>
            <h1 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase">
              "EVERY MOVEMENT <br />
              <span className="text-[#A78BFA]">TELLS A STORY."</span>
            </h1>
            <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] leading-relaxed max-w-2xl font-sans">
              MOTION IS ART was founded at the crossroads of underground street culture and contemporary performance art. We train the body as an instrument of deliberate artistic rebellion.
            </p>
          </div>

          {/* Documentary Photography & Studio Narrative */}
          <div className="mt-16 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <div className="lg:col-span-5 relative">
              <div className="relative aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#15151C] shadow-2xl">
                <img
                  src="/images/dance/space-2.jpg"
                  alt="Atmospheric studio lighting and rehearsal space"
                  loading="lazy"
                  className="w-full h-full object-cover filter brightness-[0.88] contrast-[1.1]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-85" />
                <div className="film-grain absolute inset-0 pointer-events-none" />

                <div className="absolute bottom-6 left-6 right-6">
                  <span className="font-mono text-[10px] text-[#A78BFA] uppercase tracking-wider block mb-1">
                    STUDIO PHILOSOPHY
                  </span>
                  <p className="font-display font-bold text-lg text-[#F5F3F8] leading-snug">
                    The floor is a blank canvas. Your footwork is the ink.
                  </p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-6">
              {pillars.map((pillar) => (
                <div
                  key={pillar.number}
                  className="p-6 sm:p-7 rounded-sm bg-[#15151C] border border-white/[0.07] hover:border-[#8B5CF6]/40 transition-all duration-300"
                >
                  <div className="flex items-center justify-between gap-4 mb-3">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold text-[#8B5CF6]">
                        {pillar.number} //
                      </span>
                      <h3 className="font-display font-bold text-lg sm:text-xl text-[#F5F3F8]">
                        {pillar.title}
                      </h3>
                    </div>
                    <span className="font-mono text-[10px] uppercase text-[#A5A1B2] bg-white/[0.04] px-2.5 py-1 rounded border border-white/5">
                      {pillar.tag}
                    </span>
                  </div>
                  <p className="font-sans text-xs sm:text-sm text-[#A5A1B2] leading-relaxed">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </div>

          </div>

          {/* Studio Culture & Facility Preservation */}
          <div className="mt-20 pt-16 border-t border-white/[0.08] grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-sm bg-[#15151C] border border-white/[0.07]">
              <Layers className="w-5 h-5 text-[#8B5CF6] mb-4" />
              <h3 className="font-display font-bold text-lg text-white mb-2">Sprung Birch Flooring</h3>
              <p className="text-xs text-[#A5A1B2] leading-relaxed">
                4,200 sq ft of multi-layered sprung timber engineered with dual neoprene absorption pads to dampen joint stress by up to 64%.
              </p>
            </div>

            <div className="p-6 rounded-sm bg-[#15151C] border border-white/[0.07]">
              <Users className="w-5 h-5 text-[#8B5CF6] mb-4" />
              <h3 className="font-display font-bold text-lg text-white mb-2">12:1 Dancer Ratio</h3>
              <p className="text-xs text-[#A5A1B2] leading-relaxed">
                Every session is capped to preserve floor space and ensure individual feedback from resident faculty members.
              </p>
            </div>

            <div className="p-6 rounded-sm bg-[#15151C] border border-white/[0.07]">
              <Shield className="w-5 h-5 text-[#8B5CF6] mb-4" />
              <h3 className="font-display font-bold text-lg text-white mb-2">Zero Judgment Policy</h3>
              <p className="text-xs text-[#A5A1B2] leading-relaxed">
                Whether attending your first foundational groove or preparing for an international battle cypher, respect for the floor is paramount.
              </p>
            </div>
          </div>

          {/* Page CTA */}
          <div className="mt-16 p-8 rounded-sm bg-[#15151C] border border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-display font-bold text-xl text-white">READY TO EXPERIENCE THE FLOOR?</h3>
              <p className="text-xs text-[#A5A1B2] mt-1">
                Book a complimentary trial session or contact the studio coordinator directly.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Link
                to="/schedule"
                className="px-5 py-3 text-xs font-mono font-medium text-white bg-white/[0.08] hover:bg-white/[0.15] border border-white/10 rounded-sm"
              >
                VIEW TIMETABLE
              </Link>
              <Link
                to="/contact"
                className="px-5 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm"
              >
                CONTACT US
              </Link>
            </div>
          </div>

        </div>
      </div>
    </>
  );
};

export default AboutPage;
