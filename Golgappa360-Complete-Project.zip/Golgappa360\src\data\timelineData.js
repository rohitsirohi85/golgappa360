/**
 * STELLAR 2.0 — Cosmic Timeline Data Model (Phase U13)
 * 
 * Curated educational milestones from the Big Bang through the Sun's future:
 * - 01: Big Bang (~13.8 billion years ago)
 * - 02: First Atoms & Cosmic Dark Ages (~380,000 years after Big Bang)
 * - 03: First Stars (~100–200 million years after Big Bang)
 * - 04: Early Galaxies (~400–800 million years after Big Bang)
 * - 05: Milky Way Development (~10–13 billion years ago)
 * - 06: Solar System Formation (~4.6 billion years ago)
 * - 07: Early Earth Forms (~4.5 billion years ago)
 * - 08: Moon Formation (Giant Impact) (~4.5 billion years ago)
 * - 09: Present Day Universe (Now / 13.8 billion years after Big Bang)
 * - 10: Sun's Evolutionary Destiny (~5 billion years in the future)
 * 
 * SCIENTIFIC UX:
 * - Uses responsible wording ("approximately", "roughly", "about", "leading scientific model proposes").
 * - Spacing is optimized for educational exploration rather than linear time.
 * - DISCLAIMER: Illustrative educational visualization — not an exact chronological simulation.
 */

export const TIMELINE_ERAS = {
  PAST: 'PAST',
  PRESENT: 'PRESENT',
  FUTURE: 'FUTURE',
};

export const COSMIC_MILESTONES = [
  // -------------------------------------------------------------------------
  // 01 — BIG BANG
  // -------------------------------------------------------------------------
  {
    id: 'big-bang',
    order: 1,
    number: '01',
    title: 'The Big Bang',
    subtitle: 'Cosmic Genesis & Space Expansion',
    timeLabel: '~13.8 billion years ago',
    shortTime: '13.8 Bya',
    approxYearsAgo: 13.8e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Cosmic Dawn',
    badgeColor: 'border-rose-500/40 bg-rose-950/40 text-rose-300',
    accentColor: '#f43f5e',
    shortSummary: 'The observable universe began from an extremely hot, dense early state and expanded rapidly, bringing space and time into existence.',
    whatHappened: 'Astrophysicists estimate that approximately 13.8 billion years ago, all matter and energy in the observable universe expanded from an unimaginably hot, dense initial state. During cosmic inflation, space itself stretched exponentially, cooling the infant universe and laying the foundation for fundamental physical forces, subatomic particles, and gravitational clustering.',
    whyItMatters: 'Every fundamental particle, physical constant, and dimension of spacetime originated in this expansion. The Big Bang was not an explosion of matter into pre-existing empty space, but rather the rapid expansion of space itself everywhere simultaneously.',
    cosmicFact: 'The Cosmic Microwave Background (CMB) is the faint thermal glow left over from the hot early universe, still observable uniformly in every direction across deep space today.',
    visualType: 'big-bang',
    relatedObjectIds: ['andromeda-galaxy', 'sagittarius-a-star'],
    bridgeAction: {
      label: 'Explore Deep Galaxies',
      type: 'universe',
      description: 'Observe modern galactic structures born from cosmic inflation',
    },
  },

  // -------------------------------------------------------------------------
  // 02 — FIRST ATOMS & COSMIC DARK AGES
  // -------------------------------------------------------------------------
  {
    id: 'first-atoms',
    order: 2,
    number: '02',
    title: 'First Atoms & Dark Ages',
    subtitle: 'Recombination & The Cosmic Dark Ages',
    timeLabel: '~380,000 years after Big Bang',
    shortTime: '380k yr ABB',
    approxYearsAgo: 13.799e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Recombination Era',
    badgeColor: 'border-indigo-500/40 bg-indigo-950/40 text-indigo-300',
    accentColor: '#6366f1',
    shortSummary: 'As the cosmos cooled, electrons and nuclei bonded into neutral hydrogen and helium, freeing photons to travel and leaving the universe in darkness.',
    whatHappened: 'When the universe cooled to roughly 3,000 Kelvin, protons and electrons were finally able to bind together to form stable neutral atoms—an epoch called Recombination. Before this moment, light was trapped, constantly scattering off free electrons. With neutral atoms formed, photons were set free, and the universe entered the "Cosmic Dark Ages", a prolonged era before the first stars ignited.',
    whyItMatters: 'Neutral primordial gas provided the vast cosmic reservoirs of hydrogen and helium from which all subsequent generations of stars and interstellar nebulae condensed under gravitational attraction.',
    cosmicFact: 'The primordial universe was composed almost entirely of hydrogen (~75%) and helium (~25%), with trace amounts of lithium. All heavier elements were forged later inside stellar cores.',
    visualType: 'first-atoms',
    relatedObjectIds: ['orion-nebula', 'carina-nebula'],
    bridgeAction: {
      label: 'Explore Primordial Nebulae',
      type: 'nebulae',
      description: 'View vast molecular clouds echoing the early atomic gas',
    },
  },

  // -------------------------------------------------------------------------
  // 03 — FIRST STARS
  // -------------------------------------------------------------------------
  {
    id: 'first-stars',
    order: 3,
    number: '03',
    title: 'First Stars (Population III)',
    subtitle: 'Cosmic Dawn & Reionization',
    timeLabel: 'Hundreds of millions of years after Big Bang',
    shortTime: '~200 Mya ABB',
    approxYearsAgo: 13.6e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Cosmic Dawn',
    badgeColor: 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300',
    accentColor: '#06b6d4',
    shortSummary: 'Gravity collapsed primordial hydrogen clouds into the very first generation of colossal, brilliant blue-white stars, ending the Dark Ages.',
    whatHappened: 'Pervasive dark matter filaments funneled primordial gas into dense gravitational wells. Driven by immense pressure, nuclear fusion ignited the earliest generation of stars, known as Population III. Colossal in size—often tens to hundreds of times the mass of our Sun—they emitted intense ultraviolet radiation that reionized surrounding cosmic gas.',
    whyItMatters: 'These first stars were the universe’s earliest chemical factories. When they perished in cataclysmic supernova explosions, they seeded the cosmos with carbon, oxygen, silicon, and iron, making future rocky worlds possible.',
    cosmicFact: 'Because primordial gas lacked heavier elements that help clouds cool and fragment, Population III stars grew to immense proportions before ignition, burning through their fuel in just a few million years.',
    visualType: 'first-stars',
    relatedObjectIds: ['rigel', 'sirius', 'vega', 'betelgeuse'],
    bridgeAction: {
      label: 'Explore Stars Catalog',
      type: 'stars',
      description: 'Discover modern stellar classifications and descendants',
    },
  },

  // -------------------------------------------------------------------------
  // 04 — EARLY GALAXIES
  // -------------------------------------------------------------------------
  {
    id: 'early-galaxies',
    order: 4,
    number: '04',
    title: 'Early Galaxies',
    subtitle: 'Protogalactic Mergers & Cosmic Web',
    timeLabel: 'Roughly 400–800 million years after Big Bang',
    shortTime: '~500 Mya ABB',
    approxYearsAgo: 13.2e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Galactic Emergence',
    badgeColor: 'border-violet-500/40 bg-violet-950/40 text-violet-300',
    accentColor: '#8b5cf6',
    shortSummary: 'Stellar clusters and dense gas clouds collided and merged, forming the earliest irregular and spiral protogalaxies along dark matter scaffolding.',
    whatHappened: 'As the first stars grouped into dense stellar clusters, mutual gravitational attraction drew them together into protogalaxies. Frequent collisions and violent mergers triggered intense bursts of star formation, while supermassive black holes began anchoring galactic centers and regulating star birth through powerful relativistic jets.',
    whyItMatters: 'Galaxies serve as the fundamental gravitational habitats of the universe, organizing hundreds of billions of stars and perpetually recycling matter through stellar births, supernovae, and stellar winds.',
    cosmicFact: 'Deep-field observations by space telescopes show that the earliest galaxies were smaller, clumpier, and far more turbulent than mature spiral giants like the Milky Way or Andromeda.',
    visualType: 'early-galaxies',
    relatedObjectIds: ['andromeda-galaxy', 'triangulum-galaxy', 'large-magellanic-cloud'],
    bridgeAction: {
      label: 'Explore Galactic Structures',
      type: 'universe',
      description: 'Navigate spiral and elliptical galaxies across deep space',
    },
  },

  // -------------------------------------------------------------------------
  // 05 — MILKY WAY DEVELOPMENT
  // -------------------------------------------------------------------------
  {
    id: 'milky-way',
    order: 5,
    number: '05',
    title: 'Milky Way Development',
    subtitle: 'Evolution of Our Home Galaxy',
    timeLabel: 'Over billions of years (~10–13 billion years ago)',
    shortTime: '~11 Bya',
    approxYearsAgo: 11.0e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Galactic Evolution',
    badgeColor: 'border-sky-500/40 bg-sky-950/40 text-sky-300',
    accentColor: '#0ea5e9',
    shortSummary: 'Our home galaxy assembled over cosmic epochs through continuous star formation, stellar halo assembly, and ancient mergers with neighboring dwarf galaxies.',
    whatHappened: 'The Milky Way began as protogalactic fragments whose oldest globular clusters and stellar halo formed early in cosmic history. Over billions of years, our galaxy assimilated smaller neighboring dwarf galaxies (such as Gaia-Enceladus) and organized into a dynamic barred spiral disk spanning over 100,000 light-years.',
    whyItMatters: 'Successive stellar generations in the galactic disk enriched the interstellar medium with heavy elements, creating a "galactic habitable zone" with the chemical building blocks needed for planetary systems.',
    cosmicFact: 'The Milky Way currently contains an estimated 100 to 400 billion stars and is gravitationally anchored at its core by the supermassive black hole Sagittarius A*.',
    visualType: 'milky-way',
    relatedObjectIds: ['sagittarius-a-star', 'milky-way-core', 'pleiades', 'hercules-cluster'],
    bridgeAction: {
      label: 'Explore Central Black Hole',
      type: 'black-hole',
      targetId: 'sagittarius-a-star',
      description: 'Inspect Sagittarius A* at the heart of the Milky Way',
    },
  },

  // -------------------------------------------------------------------------
  // 06 — SOLAR SYSTEM FORMATION
  // -------------------------------------------------------------------------
  {
    id: 'solar-system-formation',
    order: 6,
    number: '06',
    title: 'Solar System Formation',
    subtitle: 'Solar Nebula & Protoplanetary Disk',
    timeLabel: '~4.6 billion years ago',
    shortTime: '4.6 Bya',
    approxYearsAgo: 4.6e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Solar Genesis',
    badgeColor: 'border-amber-500/40 bg-amber-950/40 text-amber-300',
    accentColor: '#f59e0b',
    shortSummary: 'A localized giant molecular cloud collapsed under its own gravity, igniting the proto-Sun and spinning out a protoplanetary disk of dust and gas.',
    whatHappened: 'A disturbance—likely a shockwave from a nearby core-collapse supernova—triggered the gravitational collapse of a cold interstellar gas cloud. Central mass gathered to form our proto-Sun, while conservation of angular momentum flattened surrounding matter into a spinning protoplanetary disk where dust grains collided to form planetesimals.',
    whyItMatters: 'Thermal gradients across the protoplanetary disk determined planet compositions: light volatile gases were driven outward to form gas and ice giants, while rocky silicate materials condensed close to the Sun into terrestrial planets.',
    cosmicFact: 'Roughly 99.86% of all mass in the Solar System is concentrated within the Sun alone, leaving just 0.14% distributed among all eight planets, moons, and asteroids.',
    visualType: 'solar-nebula',
    relatedObjectIds: ['sun', 'jupiter', 'saturn'],
    bridgeAction: {
      label: 'Explore Solar System',
      type: 'solar-system',
      targetId: 'sun',
      description: 'Enter the interactive 3D Solar System exploration view',
    },
  },

  // -------------------------------------------------------------------------
  // 07 — EARLY EARTH FORMS
  // -------------------------------------------------------------------------
  {
    id: 'earth-forms',
    order: 7,
    number: '07',
    title: 'Early Earth Forms',
    subtitle: 'Planetary Accretion & Core Differentiation',
    timeLabel: '~4.5 billion years ago',
    shortTime: '4.54 Bya',
    approxYearsAgo: 4.54e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Terrestrial Genesis',
    badgeColor: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300',
    accentColor: '#10b981',
    shortSummary: 'Accretion of rocky planetesimals built proto-Earth, undergoing intense radioactive heating and separating into a metallic core, mantle, and crust.',
    whatHappened: 'Rocky planetesimals in the inner disk accreted over tens of millions of years to build proto-Earth. Tremendous gravitational pressure, radioactive decay, and impact heating melted the planet, causing dense iron and nickel to sink into a liquid metallic dynamo core while lighter silicates floated to form the mantle and outer crust.',
    whyItMatters: 'Planetary differentiation generated Earth’s magnetic field, shielding our nascent atmosphere from harsh solar wind, while volcanic outgassing provided water vapor and carbon dioxide essential for early oceans.',
    cosmicFact: 'The earliest geological eon of Earth is named the Hadean (after Hades), reflecting the hellish conditions of ubiquitous magma oceans, volatile eruptions, and heavy asteroid bombardments.',
    visualType: 'early-earth',
    relatedObjectIds: ['earth', 'mars', 'venus', 'mercury'],
    bridgeAction: {
      label: 'Explore Earth System',
      type: 'earth',
      targetId: 'earth',
      description: 'Inspect Earth’s modern structure, atmosphere, and magnetosphere',
    },
  },

  // -------------------------------------------------------------------------
  // 08 — MOON FORMATION (GIANT IMPACT)
  // -------------------------------------------------------------------------
  {
    id: 'moon-formation',
    order: 8,
    number: '08',
    title: 'Moon Formation',
    subtitle: 'The Giant-Impact Hypothesis',
    timeLabel: '~4.5 billion years ago',
    shortTime: '4.5 Bya',
    approxYearsAgo: 4.5e9,
    era: TIMELINE_ERAS.PAST,
    eraLabel: 'Lunar Genesis',
    badgeColor: 'border-slate-400/40 bg-slate-900/60 text-slate-200',
    accentColor: '#cbd5e1',
    shortSummary: 'The leading scientific model proposes a Mars-sized protoplanet named Theia collided with early Earth, creating a debris ring that coalesced into the Moon.',
    whatHappened: 'Roughly 4.5 billion years ago, early Earth suffered an oblique collision with a Mars-sized protoplanet commonly designated Theia. The immense kinetic energy vaporized parts of both bodies, ejecting superheated mantle material into orbit. This debris disk coalesced rapidly under mutual gravity to assemble our Moon.',
    whyItMatters: 'The Moon’s gravitational presence stabilized Earth’s axial tilt, preventing extreme climate swings that would disrupt biological evolution, while generating substantial ocean tides.',
    cosmicFact: 'Apollo lunar rock samples verified that the Moon shares nearly identical oxygen isotope ratios with Earth’s mantle, providing key empirical support for the giant-impact model.',
    visualType: 'moon-impact',
    relatedObjectIds: ['moon', 'earth'],
    bridgeAction: {
      label: 'Explore Lunar Surface',
      type: 'moon',
      targetId: 'moon',
      description: 'Open the lunar observatory with interactive phase simulator',
    },
  },

  // -------------------------------------------------------------------------
  // 09 — PRESENT DAY
  // -------------------------------------------------------------------------
  {
    id: 'present-day',
    order: 9,
    number: '09',
    title: 'Present Day Universe',
    subtitle: 'The Modern Cosmos & Observable Reality',
    timeLabel: 'Present Day (Now)',
    shortTime: 'Today',
    approxYearsAgo: 0,
    era: TIMELINE_ERAS.PRESENT,
    eraLabel: 'Modern Cosmic Era',
    badgeColor: 'border-cyan-400/50 bg-cyan-950/60 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.3)]',
    accentColor: '#22d3ee',
    shortSummary: 'The modern universe spans billions of light-years, encompassing hundreds of billions of galaxies, our middle-aged Sun, and the thriving world of Earth.',
    whatHappened: 'Today, approximately 13.8 billion years after the Big Bang, the universe has expanded across tens of billions of light-years of observable space. Our Sun is a stable G-type main sequence star roughly 4.6 billion years old, fusing hydrogen steadily in hydrostatic equilibrium and providing life-sustaining energy to Earth.',
    whyItMatters: 'This is our vantage point in cosmic time. Through telescopes and scientific reasoning, human consciousness has become a way for the universe to know itself, measuring stars and galaxies across cosmic epochs.',
    cosmicFact: 'Because light travels at a finite speed (c ≈ 300,000 km/s), whenever we look at distant stars and galaxies through telescopes today, we are literally peering backwards into cosmic history.',
    visualType: 'present-universe',
    relatedObjectIds: ['sun', 'earth', 'moon', 'andromeda-galaxy', 'sirius', 'sagittarius-a-star'],
    bridgeAction: {
      label: 'Enter Present Universe',
      type: 'universe',
      description: 'Transition back into the interactive Universe Map',
    },
  },

  // -------------------------------------------------------------------------
  // 10 — SUN'S FUTURE
  // -------------------------------------------------------------------------
  {
    id: 'sun-future',
    order: 10,
    number: '10',
    title: "The Sun's Evolutionary Destiny",
    subtitle: 'Main Sequence → Red Giant → White Dwarf',
    timeLabel: '~5 billion years in the future',
    shortTime: '+5 Byr',
    approxYearsAgo: -5.0e9,
    era: TIMELINE_ERAS.FUTURE,
    eraLabel: 'Stellar Destiny',
    badgeColor: 'border-purple-500/40 bg-purple-950/40 text-purple-300',
    accentColor: '#a855f7',
    shortSummary: 'The Sun will deplete its core hydrogen, expand into a Red Giant, gently shed glowing planetary nebula shells, and leave behind a cooling White Dwarf.',
    whatHappened: 'In approximately 5 billion years, core hydrogen will deplete. The Sun will expand outward into a luminous Red Giant with a radius over 200 times its current size. Eventually, thermal helium pulses will cast off its outer envelope as a radiant Planetary Nebula, leaving behind an Earth-sized, ultra-dense White Dwarf core of carbon and oxygen.',
    whyItMatters: 'The Sun’s destiny exemplifies the life cycle of low-to-intermediate mass stars across the cosmos. It does not possess enough mass to explode as a supernova, become a neutron star, or collapse into a black hole.',
    cosmicFact: 'A White Dwarf packs roughly half the Sun’s entire mass into a sphere the size of Earth. A single teaspoon of white dwarf material would weigh approximately 5 metric tons on Earth.',
    visualType: 'sun-future',
    futureStages: [
      {
        id: 'sun-today',
        name: 'Main Sequence (Today)',
        time: 'Now to +5 Billion Years',
        desc: 'Fusing 600 million tons of hydrogen per second in stable hydrostatic equilibrium.',
        color: '#fbbf24',
      },
      {
        id: 'red-giant',
        name: 'Red Giant Stage',
        time: '+5 to +7 Billion Years',
        desc: 'Core contracts; outer convective envelope swells 200× in radius, engulfing inner planets.',
        color: '#ef4444',
      },
      {
        id: 'planetary-nebula',
        name: 'Planetary Nebula',
        time: 'Brief ~20,000 Year Phase',
        desc: 'Thermal pulses gently eject outer gas layers, fluorescing under intense ultraviolet light.',
        color: '#06b6d4',
      },
      {
        id: 'white-dwarf',
        name: 'White Dwarf Remnant',
        time: 'Hundreds of Billions of Years',
        desc: 'Degenerate carbon-oxygen stellar ember cooling across astronomical timescales.',
        color: '#e2e8f0',
      },
    ],
    relatedObjectIds: ['sun', 'sirius-b', 'ring-nebula', 'betelgeuse'],
    bridgeAction: {
      label: 'View Star Life Cycle',
      type: 'life-cycle',
      description: 'Explore full stellar evolution pathways in the Life Cycle explorer',
    },
  },
];

/**
 * Returns all timeline milestones
 */
export function getTimelineMilestones() {
  return COSMIC_MILESTONES;
}

/**
 * Returns a milestone by its unique ID
 */
export function getMilestoneById(id) {
  if (!id) return null;
  const clean = id.toLowerCase().trim();
  return COSMIC_MILESTONES.find((m) => m.id === clean) || null;
}

/**
 * Returns a milestone by index (0-based)
 */
export function getMilestoneByIndex(index) {
  const safeIndex = Math.max(0, Math.min(index, COSMIC_MILESTONES.length - 1));
  return COSMIC_MILESTONES[safeIndex];
}
