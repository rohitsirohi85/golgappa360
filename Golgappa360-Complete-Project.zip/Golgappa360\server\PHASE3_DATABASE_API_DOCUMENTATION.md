# Golgappa360 — Phase 3: MySQL Database Integration, Backend REST APIs & SQL Analytics Engine

## 1. Architectural Overview & Dual-Engine Strategy

**Golgappa360** implements an enterprise-grade, resilient **Dual-Engine Business Intelligence Architecture** designed specifically for small-business food analytics:

```
                  ┌────────────────────────────────────────────────────────┐
                  │          Vite + React Dark Glassmorphism UI            │
                  │   (#171717 canvas, rgba glass cards, sage & saffron)   │
                  └───────────────────────────┬────────────────────────────┘
                                              │ HTTP / JSON API
                                              ▼
                  ┌────────────────────────────────────────────────────────┐
                  │                 Node.js / Express API                  │
                  │  (Port 5000, CORS, Validation Middleware, Safe Errors)  │
                  └─────────────┬────────────────────────────┬─────────────┘
                                │                            │
                [MySQL Available & Auth'd]       [MySQL Offline / Fallback]
                                ▼                            ▼
                  ┌───────────────────────────┐┌───────────────────────────┐
                  │       MySQL 8.0 Engine    ││   Synthetic Data Engine   │
                  │  - 3NF Relational Schema  ││  - 6-Month In-Memory Store │
                  │  - Normalized Views (x4)  ││  - Exact Accounting Logic  │
                  │  - Parameterized Queries  ││  - Instant Zero-Config Boot│
                  └───────────────────────────┘└───────────────────────────┘
```

### Core Accounting Invariants (Guaranteed Across Both Engines)
1. **Gross Revenue**: `SUM(quantity_plates * unit_price)`
2. **Net Revenue**: `Gross Revenue − Discounts`
3. **Cost of Goods Sold (COGS)**: `SUM(quantity_plates * ingredient_cost_per_plate)`
4. **Gross Profit**: `Net Revenue − COGS`
5. **Gross Margin %**: `(Gross Profit ÷ Net Revenue) × 100`
6. **Operating Expenses**: `SUM(amount)` from `daily_expenses`
7. **Food Waste Cost**: `SUM(quantity * unit_cost)` from `inventory_transactions` where `transaction_type = 'WASTE'`
8. **Estimated Operating Profit**: `Gross Profit − Operating Expenses`

---

## 2. MySQL Relational Schema (`golgappa360`)

The database is normalized into **3rd Normal Form (3NF)** with strict foreign keys, cascade rules, check constraints, and performance indexes.

### Normalized Tables
1. **`products`** (Master Variety Catalog & BOM)
   - `product_id VARCHAR(30) PRIMARY KEY`
   - `product_name VARCHAR(100) NOT NULL`
   - `category VARCHAR(60) NOT NULL`
   - `selling_price DECIMAL(10, 2) NOT NULL CHECK (> 0)`
   - `ingredient_cost_per_plate DECIMAL(10, 2) NOT NULL CHECK (> 0)`
2. **`sales`** (Order Transaction Header)
   - `sale_id VARCHAR(30) PRIMARY KEY`
   - `sale_datetime DATETIME NOT NULL (INDEXED)`
   - `payment_method ENUM('UPI', 'Cash', 'Card') NOT NULL DEFAULT 'UPI'`
   - `discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (>= 0)`
3. **`sale_items`** (Order Line Item Details)
   - `sale_item_id VARCHAR(40) PRIMARY KEY`
   - `sale_id VARCHAR(30) NOT NULL, FOREIGN KEY REFERENCES sales(sale_id) ON DELETE CASCADE`
   - `product_id VARCHAR(30) NOT NULL, FOREIGN KEY REFERENCES products(product_id) ON DELETE RESTRICT`
   - `quantity_plates INT NOT NULL DEFAULT 1 CHECK (> 0)`
   - `unit_price DECIMAL(10, 2) NOT NULL CHECK (> 0)`
4. **`ingredients`** (Raw Material Inventory Master)
   - `ingredient_id VARCHAR(30) PRIMARY KEY`
   - `ingredient_name VARCHAR(100) NOT NULL`
   - `unit VARCHAR(20) NOT NULL`
   - `unit_cost DECIMAL(10, 2) NOT NULL CHECK (> 0)`
   - `reorder_level DECIMAL(10, 2) NOT NULL CHECK (>= 0)`
5. **`inventory_transactions`** (Stock Movement Ledger)
   - `transaction_id VARCHAR(40) PRIMARY KEY`
   - `transaction_date DATE NOT NULL (INDEXED)`
   - `ingredient_id VARCHAR(30) NOT NULL, FOREIGN KEY REFERENCES ingredients(ingredient_id) ON DELETE RESTRICT`
   - `transaction_type ENUM('PURCHASE', 'CONSUMPTION', 'WASTE') NOT NULL`
   - `quantity DECIMAL(10, 2) NOT NULL CHECK (> 0)`
   - `reference_id VARCHAR(50)`
6. **`daily_expenses`** (Operating Overhead Ledger)
   - `expense_id VARCHAR(40) PRIMARY KEY`
   - `expense_date DATE NOT NULL (INDEXED)`
   - `expense_category VARCHAR(60) NOT NULL`
   - `amount DECIMAL(10, 2) NOT NULL CHECK (> 0)`

---

## 3. Pre-Aggregated Analytical SQL Views

1. **`vw_dashboard_kpis`**:
   Computes overall platform metrics: `total_orders`, `total_plates_sold`, `gross_revenue`, `total_discounts`, `net_revenue`, `total_cogs`, `gross_profit`, and `gross_margin_pct`.
2. **`vw_product_performance`**:
   Menu engineering view grouping sales by product, calculating unit margins, volumes, net revenues, COGS, gross profits, and profit margins.
3. **`vw_daily_financial_summary`**:
   Daily time-series aggregation linking daily orders, plates, net revenue, COGS, gross profit, waste cost, operating expenses, and estimated operating profit.
4. **`vw_inventory_status`**:
   Calculates real-time on-hand ingredient stock:
   $$\text{Current Stock} = \sum(\text{PURCHASE}) - \sum(\text{CONSUMPTION}) - \sum(\text{WASTE})$$
   Computes inventory holding values and tags stock health: `'Critical'`, `'Low'`, or `'Healthy'`.

---

## 4. Master SQL Analytics Library (`server/sql/analytics_queries.sql`)

The repository includes **30 master queries** structured across **20 pedagogical MCA & BI categories**:

| Query | Category | Pedagogical Purpose |
|:---|:---|:---|
| **Q01** | Basic SELECT, WHERE & ORDER BY | Recent High-Value Orders (Filtering & Ordering) |
| **Q02** | Aggregate Functions | System-wide Totals (SUM, AVG, MIN, MAX, COUNT, AOV, ASP) |
| **Q03** | GROUP BY & HAVING | High-Volume Operational Days (daily net revenue > ₹12,000) |
| **Q04** | INNER JOIN | Order Itemization with Product BOM Margins |
| **Q05** | LEFT OUTER JOIN | Complete Ingredient Usage & Waste Exposure |
| **Q06** | Multi-Table Relational Linkage | Multi-Join Reconciliation (Sales, Items, Products, Ingredients) |
| **Q07** | Subqueries (Scalar) | Above-Average Revenue Orders Audit |
| **Q08** | Correlated Subquery | Products Exceeding Category Average Selling Price |
| **Q09** | Subqueries with IN / EXISTS | Ingredients with Recent Severe Waste Incidents |
| **Q10** | CASE Expressions | Hourly Footfall Segmentation (Early Afternoon, Peak Rush, Late Evening) |
| **Q11** | CASE Expressions | Dynamic Reorder Urgency Classification |
| **Q12** | Date/Time Functions | Peak Selling Hours of the Day (15:00 - 22:00 distribution) |
| **Q13** | Date/Time Functions | Day of Week Performance Profiling (Weekend vs Weekday surges) |
| **Q14** | Cumulative Running Totals | Window Function: Running Cumulative Revenue (`SUM() OVER`) |
| **Q15** | Window Ranking Functions | Product Popularity & Profit Ranking (`DENSE_RANK() OVER`) |
| **Q16** | Common Table Expressions (CTE) | Multi-Stage Customer Basket Size & Velocity Profiling |
| **Q17** | Common Table Expressions (CTE) | Ingredient Waste Cost Percentage Breakdown |
| **Q18** | Financial Profit & Loss (P&L) | Monthly Executive P&L (Net Revenue, COGS, Opex, Net Profit) |
| **Q19** | Inventory Control & Reorder | Actionable Reorder Alerts (Stock <= Reorder Level) |
| **Q20** | Discount Impact Analysis | Promotional Elasticity & Discount Erosion Rate |
| **Q21** | Payment Behavior Analysis | Digital vs Cash Penetration by Time of Day |
| **Q22** | Daily Gross Margin Trend | Daily Volatility Analysis of Gross Margin % |
| **Q23** | Peak 60-Minute Windows | Micro-Service Capacity & Velocity Window |
| **Q24** | Data Quality Reconciliation | Orphaned Order Items Check (Referential Integrity Check) |
| **Q25** | Data Quality Reconciliation | Negative/Zero Quantity Inventory Audit |
| **Q26** | View Integration: Executive | Complete 6-Month Executive Financial Summary |
| **Q27** | View Integration: Tableau | Top Varieties by Profit Contribution (Pareto BI Feed) |
| **Q28** | View Integration: Tableau | Daily Business Health Time-Series (Area Chart BI Feed) |
| **Q29** | View Integration: Tableau | Real-time Ingredient Gauge Feed |
| **Q30** | Window Moving Average | 7-Day Rolling Moving Average of Net Turnover |

---

## 5. Phase 3 Canonical REST API Specifications

All endpoints return a uniform JSON envelope:
```json
{
  "success": true,
  "data": { ... }
}
```

### 1. Dashboard Endpoints
- `GET /api/dashboard/summary`
  - **Query Params**: `range` (`today`, `7d`, `30d`, `90d`, `180d`, `all`), `startDate`, `endDate`, `productId`
  - **Returns**: High-level KPIs (`totalRevenue`, `grossProfit`, `grossMarginPct`, `totalOrders`, `totalPlatesSold`, `aov`, `cogs`, `operatingExpenses`, `operatingProfit`, `totalWasteCost`).
- `GET /api/dashboard/sales-trend`
  - **Query Params**: `range`, `startDate`, `endDate`, `productId`, `granularity` (`daily`, `monthly`)
  - **Returns**: Array of time points with date, dayOfWeek, revenue, cogs, gross profit, orders, and plates.
- `GET /api/dashboard/hourly-sales`
  - **Query Params**: `range`, `startDate`, `endDate`, `productId`
  - **Returns**: 8 hourly buckets (3 PM to 10 PM) with orders, plates, revenue, cogs, and footfall intensity.

### 2. Sales Endpoints
- `GET /api/sales`
  - **Query Params**: `page` (default 1), `limit` (default 50, max 500), `startDate`, `endDate`, `productId`, `paymentMethod`
  - **Returns**: Paginated sales records, total count, total pages, and unit margins.
- `GET /api/sales/product-performance`
  - **Query Params**: `range`, `startDate`, `endDate`
  - **Returns**: Product-level rankings sorted by net revenue and gross profit.
- `GET /api/sales/payment-breakdown`
  - **Query Params**: `range`, `startDate`, `endDate`
  - **Returns**: Payment method distribution (UPI vs Cash), order volume, and revenue shares.

### 3. Product Endpoints
- `GET /api/products`
  - **Query Params**: `category` (optional)
  - **Returns**: Catalog of products with selling prices, BOM ingredient costs, and margins.
- `GET /api/products/:id`
  - **Params**: `id` (e.g. `PROD-001`)
  - **Returns**: Detailed product record or 404 if not found.

### 4. Inventory Endpoints
- `GET /api/inventory/summary`
  - **Returns**: All 8 raw ingredients, current stock, reorder levels, runway days, status (`Healthy`, `Low`, `Critical`), and total holding value.
- `GET /api/inventory/transactions`
  - **Query Params**: `page`, `limit`, `type` (`PURCHASE`, `CONSUMPTION`, `WASTE`), `startDate`, `endDate`
  - **Returns**: Paginated stock transaction ledger.
- `POST /api/inventory/restock`
  - **Body**: `{ "ingredient_id": "ING-001", "quantity_added": 50, "notes": "Shipment arrived" }`
  - **Returns**: Updated inventory state.

### 5. Food Waste Endpoints
- `GET /api/waste/summary`
  - **Query Params**: `range`, `startDate`, `endDate`
  - **Returns**: Waste KPIs (`totalWasteCost`, `wasteRatePct`), breakdown by root cause reason, breakdown by ingredient, high-waste outlier dates, and actionable AI recommendations.
- `POST /api/waste/log`
  - **Body**: `{ "ingredient_id": "ING-001", "quantity": 15, "reason": "Broken Puris" }`
  - **Returns**: Confirmation and updated waste log.

### 6. Reports & Export Endpoints
- `GET /api/reports/dataset-summary`
  - **Returns**: Summary of all 6 downloadable analytical datasets with row counts, date ranges, and field definitions.
- `GET /api/reports/export/:datasetId`
  - **Params**: `sales`, `products`, `ingredients`, `inventory_transactions`, `daily_expenses`, `daily_sales_summary`
  - **Query Params**: `range`, `startDate`, `endDate`, `productId`
  - **Returns**: Direct RFC 4180 CSV file download (`Content-Type: text/csv; Content-Disposition: attachment`).

---

## 6. How to Seed, Connect, and Operate MySQL

### Step 1: Configure Credentials in `server/.env`
Create `server/.env` (copy from `server/.env.example`):
```env
PORT=5000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password_here
DB_NAME=golgappa360
```

### Step 2: Create Schema & Seed Data
Execute from project root:
```bash
# Method A: Via Node automated ETL script (reads Phase 2 CSVs & imports into MySQL)
node server/src/scripts/importData.js

# Method B: Via standard MySQL CLI client
mysql -u root -p < server/sql/schema.sql
mysql -u root -p golgappa360 < server/sql/seed.sql
```

### Step 3: Run Master SQL Analytics Queries
```bash
mysql -u root -p golgappa360 < server/sql/analytics_queries.sql
```

---

## 7. Automated Test Suite Execution Results

Executed automated test suite: `node server/test_phase3_endpoints.js`
- **Total Test Cases**: 19
- **Passed**: 19
- **Failed**: 0
- **Pass Rate**: 100.0%

| Test Case | Method & Route | Target Verification | Result |
|:---|:---|:---|:---|
| 1 | `GET /api/health` | System health & active DB mode | **PASS** |
| 2 | `GET /api/dashboard/summary` | Financial KPIs (Net Rev, COGS, Gross Profit) | **PASS** |
| 3 | `GET /api/dashboard/sales-trend` | Daily time-series breakdown | **PASS** |
| 4 | `GET /api/dashboard/sales-trend` | Monthly time-series breakdown | **PASS** |
| 5 | `GET /api/dashboard/hourly-sales` | 8 hourly service buckets | **PASS** |
| 6 | `GET /api/sales` | Pagination (`page=1&limit=10`) | **PASS** |
| 7 | `GET /api/sales/product-performance` | Product Pareto ranking | **PASS** |
| 8 | `GET /api/sales/payment-breakdown` | UPI vs Cash volume/revenue | **PASS** |
| 9 | `GET /api/products` | Complete catalog listing | **PASS** |
| 10 | `GET /api/products/PROD-001` | Single product details & BOM | **PASS** |
| 11 | `GET /api/inventory/summary` | 8 ingredients & holding valuation | **PASS** |
| 12 | `GET /api/inventory/transactions` | Paginated purchase movements | **PASS** |
| 13 | `GET /api/waste/summary` | Loss metrics & root causes | **PASS** |
| 14 | `GET /api/reports/dataset-summary` | Available datasets & schema | **PASS** |
| 15 | `GET /api/dashboard/summary?startDate=bad` | 400 Bad Request on invalid date | **PASS** |
| 16 | `GET /api/sales?page=-5` | 400 Bad Request on negative page | **PASS** |
| 17 | `GET /api/reports/export/sales` | RFC 4180 CSV export download | **PASS** |
| 18 | `POST /api/inventory/restock` | Inventory restock mutation | **PASS** |
| 19 | `POST /api/waste/log` | Waste event logging mutation | **PASS** |
