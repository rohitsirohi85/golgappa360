import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';
import { WASTE_COMPOSITION } from '../../data/mockWasteData';
import { PieChart as PieIcon } from 'lucide-react';

const CustomPieTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0];
    return (
      <div className="rounded-lg bg-white border border-[#E4EAE5] p-2.5 shadow-lg text-xs">
        <div className="font-semibold text-[#25332D] flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: data.payload.color }}></span>
          <span>{data.name}</span>
        </div>
        <div className="mt-1 font-mono text-[#16865B] font-bold">
          {data.value}% of total mess waste
        </div>
      </div>
    );
  }
  return null;
};

export const WasteCompositionDonut = () => {
  return (
    <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 shadow-xs flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-[#16865B]" />
            Waste Composition
          </h3>
          <span className="text-[10px] font-mono text-[#77847C] bg-[#F8FAF8] px-2 py-0.5 rounded border border-[#E4EAE5]">
            Food Category Breakdown
          </span>
        </div>
        <p className="text-xs text-[#77847C] mb-2">
          Starch/grains form the overwhelming bulk of discards
        </p>
      </div>

      <div className="h-48 w-full relative flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Tooltip content={<CustomPieTooltip />} />
            <Pie
              data={WASTE_COMPOSITION}
              cx="50%"
              cy="50%"
              innerRadius={52}
              outerRadius={75}
              paddingAngle={3}
              dataKey="value"
            >
              {WASTE_COMPOSITION.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} stroke="#FFFFFF" strokeWidth={2} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-xl font-bold font-mono text-[#25332D]">44%</span>
          <span className="text-[10px] text-[#77847C] uppercase tracking-wider">Rice / Grains</span>
        </div>
      </div>

      <div className="space-y-1.5 pt-3 border-t border-[#EEF2EF]">
        {WASTE_COMPOSITION.map((item) => (
          <div key={item.name} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
              <span className="text-[#77847C] text-[11px] truncate">{item.name}</span>
            </div>
            <span className="font-mono font-semibold text-[#25332D] text-xs">{item.value}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};
