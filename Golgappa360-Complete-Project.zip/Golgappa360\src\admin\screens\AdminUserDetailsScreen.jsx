import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  ArrowLeft,
  Users,
  Car,
  CalendarCheck,
  Zap,
  DollarSign,
  UserCheck,
  UserX,
  Clock,
  Shield,
} from 'lucide-react';

export const AdminUserDetailsScreen = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [message, setMessage] = useState('');

  const fetchUserDetails = async () => {
    try {
      setLoading(true);
      const res = await adminService.getUserDetails(id);
      setData(res);
    } catch (err) {
      console.error('Error fetching user detail:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserDetails();
  }, [id]);

  const handleToggleStatus = async () => {
    if (!data?.user) return;
    const newStatus = data.user.accountStatus === 'deactivated' ? 'active' : 'deactivated';
    setUpdating(true);
    setMessage('');
    try {
      await adminService.updateUserStatus(id, newStatus);
      setMessage(`User account status updated to ${newStatus}.`);
      setData((prev) => ({
        ...prev,
        user: { ...prev.user, accountStatus: newStatus },
      }));
    } catch (err) {
      setMessage(`Error: ${err.message}`);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout pageTitle="User Profile">
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading customer profile & telemetry history...</p>
        </div>
      </AdminLayout>
    );
  }

  const user = data?.user;
  const vehicles = data?.vehicles || [];
  const bookings = data?.bookings || [];
  const sessions = data?.sessions || [];
  const bills = data?.bills || [];

  const totalSpent = bills.reduce((acc, b) => acc + (b.totalAmount || 0), 0);
  const totalEnergy = sessions.reduce((acc, s) => acc + (s.energyConsumed || 0), 0);

  return (
    <AdminLayout
      pageTitle={user?.name || 'Customer Account'}
      subtitle={`Account Details • Registered ${new Date(user?.createdAt).toLocaleDateString()}`}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/admin/users"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Users</span>
        </Link>
      </div>

      {message && (
        <div className="mb-6 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
          {message}
        </div>
      )}

      {/* User Header Profile */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-extrabold text-2xl">
              {user?.name ? user.name[0].toUpperCase() : 'U'}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{user?.name}</h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{user?.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                  {user?.role}
                </span>
                <span
                  className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                    user?.accountStatus === 'deactivated'
                      ? 'bg-rose-500/20 text-rose-400'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {user?.accountStatus || 'active'}
                </span>
              </div>
            </div>
          </div>

          {user?.role !== 'admin' && (
            <button
              onClick={handleToggleStatus}
              disabled={updating}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 ${
                user?.accountStatus === 'deactivated'
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}
            >
              {user?.accountStatus === 'deactivated' ? (
                <>
                  <UserCheck className="w-4 h-4" />
                  <span>Reactivate Account</span>
                </>
              ) : (
                <>
                  <UserX className="w-4 h-4" />
                  <span>Deactivate Account</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* 4 Lifetime Summary Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800 text-center text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold">Total Sessions</span>
            <div className="text-xl font-black text-white mt-1">{sessions.length}</div>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold">Bookings Created</span>
            <div className="text-xl font-black text-white mt-1">{bookings.length}</div>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold">Energy Consumed</span>
            <div className="text-xl font-black text-emerald-400 mt-1 font-mono">
              {Math.round(totalEnergy * 10) / 10} kWh
            </div>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold">Total Spend</span>
            <div className="text-xl font-black text-white mt-1 font-mono">₹{totalSpent}</div>
          </div>
        </div>
      </div>

      {/* Vehicles Section */}
      <div className="mb-8">
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Car className="w-4 h-4 text-emerald-400" />
          <span>Registered Electric Vehicles ({vehicles.length})</span>
        </h3>
        {vehicles.length === 0 ? (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 text-center text-xs text-slate-500">
            No registered vehicles found for this user.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {vehicles.map((v) => (
              <div key={v._id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-white">{v.brand} {v.model}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    {v.connectorType || 'CCS2'}
                  </span>
                </div>
                <p className="text-xs font-mono text-emerald-400">{v.vehicleNumber || 'KA 01 EV 2026'}</p>
                <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400 flex justify-between">
                  <span>Battery Capacity:</span>
                  <span className="font-bold text-white">{v.batteryCapacity || 60} kWh</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Sessions */}
      <div>
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-emerald-400" />
          <span>User Charging History</span>
        </h3>
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                  <th className="py-3 px-6 font-bold">Session ID</th>
                  <th className="py-3 px-6 font-bold">Bay & Station</th>
                  <th className="py-3 px-6 font-bold">Energy</th>
                  <th className="py-3 px-6 font-bold">Duration</th>
                  <th className="py-3 px-6 font-bold">Amount</th>
                  <th className="py-3 px-6 font-bold">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {sessions.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="py-6 text-center text-slate-500">
                      No charging history available.
                    </td>
                  </tr>
                ) : (
                  sessions.map((s) => (
                    <tr key={s._id} className="hover:bg-slate-800/40">
                      <td className="py-3 px-6 font-mono text-slate-400">{s._id.slice(-6).toUpperCase()}</td>
                      <td className="py-3 px-6 font-medium text-white">{s.chargerId?.chargerNumber || 'CH-01'}</td>
                      <td className="py-3 px-6 font-mono text-emerald-400">{s.energyConsumed || 0} kWh</td>
                      <td className="py-3 px-6 text-slate-400">{s.duration || 45} mins</td>
                      <td className="py-3 px-6 font-mono font-bold text-white">₹{s.cost || 0}</td>
                      <td className="py-3 px-6 text-slate-500 text-[11px]">
                        {new Date(s.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminUserDetailsScreen;
