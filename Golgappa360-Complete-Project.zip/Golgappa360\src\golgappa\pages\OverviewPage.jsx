import React, { useState } from 'react';
import {
  IndianRupee,
  Utensils,
  TrendingUp,
  Trash2,
  PieChart as PieIcon,
  Clock,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  Calendar,
  Layers,
  ShoppingBag,
  Plus,
  RefreshCw,
  Sparkles,
  Flame,
  ArrowRight,
  MoreHorizontal,
  ChevronDown,
  Activity
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { useGolgappa } from '../context/GolgappaContext';
import { GlassCard, GlassPanel, GlassPill } from '../components/glass/GlassCard';
import { GlassButton } from '../components/glass/GlassControls';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';

export function OverviewPage() {
  const {
    overviewData,
    dateRange,
    setDateRange,
    searchQuery,
    handleRestockInventory,
    handleLogWaste,
    inventoryData,
    setActiveTab
  } = useGolgappa();

  const [activeCategoryFilter, setActiveCategoryFilter] = useState('All');
  const [varietySortBy, setVarietySortBy] = useState('popularity');
  const [isRestockModalOpen, setIsRestockModalOpen] = useState(false);
  const [isWasteModalOpen, setIsWasteModalOpen] = useState(false);
  const [selectedIngredient, setSelectedIngredient] = useState('1');
  const [restockQty, setRestockQty] = useState('');
  const [wasteQty, setWasteQty] = useState('');
  const [wasteReason, setWasteReason] = useState('Broken Puris (Transit/Handling)');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const kpis = overviewData?.kpis || {
    totalRevenue: 301655,
    totalPlatesSold: 8400,
    grossProfit: 217624,
    grossMarginPct: 72.1,
    totalWasteCost: 5154,
    wasteRatePct: 6.1,
    netEstimatedProfit: 212470,
    totalOrders: 4942,
    aov: 61.04
  };

  const dailySales = overviewData?.dailySalesChart || [];
  const hourlyProfile = overviewData?.hourlySalesProfile || [];
  const recentTransactions = overviewData?.recentTransactions || [];

  // Top varieties derived dynamically from real analytics
  const topVarieties = (overviewData?.productSalesDistribution && overviewData.productSalesDistribution.length > 0
    ? overviewData.productSalesDistribution
    : []
  ).map((p, idx) => {
    const plates = p.plates_sold !== undefined ? p.plates_sold : (p.plates || 0);
    const revenue = p.net_revenue !== undefined ? p.net_revenue : (p.revenue || 0);
    const margin = p.gross_margin_pct !== undefined ? p.gross_margin_pct : (p.margin || 72.0);
    return {
      id: p.product_id || idx + 1,
      name: p.product_name || p.name || 'Golgappa Variety',
      flavour: p.category || (idx === 0 ? 'Signature Teekha & Khatta Mix' : idx === 1 ? 'Fiery Green Chilli & Pudina' : 'Speciality Chaat'),
      plates,
      revenue,
      margin,
      sparkline: [
        Math.max(5, Math.round(plates * 0.08)),
        Math.max(10, Math.round(plates * 0.14)),
        Math.max(15, Math.round(plates * 0.22)),
        Math.max(25, Math.round(plates * 0.38)),
        Math.max(30, Math.round(plates * 0.48)),
        Math.max(45, Math.round(plates * 0.72)),
        Math.max(55, Math.round(plates * 0.95))
      ],
      color: p.color || (idx % 2 === 0 ? '#A7D78A' : '#EAB64B')
    };
  });

  // Filter transactions based on search query
  const filteredTransactions = recentTransactions.filter((txn) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      txn.id.toLowerCase().includes(q) ||
      txn.itemsSummary.toLowerCase().includes(q) ||
      txn.paymentMethod.toLowerCase().includes(q) ||
      txn.customerType.toLowerCase().includes(q)
    );
  });

  const handleRestockSubmit = async (e) => {
    e.preventDefault();
    if (!restockQty || Number(restockQty) <= 0) return;
    setIsSubmitting(true);
    await handleRestockInventory(selectedIngredient, Number(restockQty), 'Quick restock from Overview');
    setIsSubmitting(false);
    setIsRestockModalOpen(false);
    setRestockQty('');
  };

  const handleWasteSubmit = async (e) => {
    e.preventDefault();
    if (!wasteQty || Number(wasteQty) <= 0) return;
    setIsSubmitting(true);
    await handleLogWaste({
      ingredient_id: selectedIngredient,
      quantity: Number(wasteQty),
      reason: wasteReason
    });
    setIsSubmitting(false);
    setIsWasteModalOpen(false);
    setWasteQty('');
  };

  return (
    <div className="space-y-6">
      {/* ============================================================== */}
      {/* TOP SECTION: Hero Glass Card + Stacked Top-Right Cards          */}
      {/* (Direct visual translation of the reference image composition) */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Large Hero Card (matching reference's "Optimize Your Metrics" panel) */}
        <div className="lg:col-span-7 glass-card p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden group min-h-[360px]">
          {/* Ambient Warm Glow in Hero Region */}
          <div className="absolute top-0 left-0 w-80 h-80 bg-gradient-to-br from-[#EAB64B]/20 via-[#D98768]/15 to-transparent rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-[#A7D78A]/10 rounded-full blur-2xl pointer-events-none" />

          {/* Top content */}
          <div className="relative z-10 space-y-3 max-w-md">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#EAB64B] bg-[#EAB64B]/15 px-3 py-1 rounded-full border border-[#EAB64B]/30 inline-flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-[#EAB64B]" />
              Stall Sales Engine
            </span>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F5F4F1] tracking-tight leading-tight font-sans">
              Optimize <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F5F4F1] via-[#EAB64B] to-[#A7D78A]">
                Your Stall Metrics
              </span>
            </h2>

            <p className="text-xs text-[#B8B7B9] leading-relaxed max-w-sm">
              Live footfall surges, unit contribution margins, and automated food wastage audits for Karol Bagh Counter.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => setIsRestockModalOpen(true)}
                className="px-5 py-2.5 rounded-full bg-[#F5F4F1] hover:bg-white text-[#171717] font-bold text-xs tracking-tight shadow-lg transition-transform duration-150 hover:scale-[1.02] cursor-pointer"
              >
                Restock Now
              </button>
              <button
                onClick={() => setIsWasteModalOpen(true)}
                className="px-4 py-2.5 rounded-full bg-white/[0.08] hover:bg-white/[0.14] text-[#F5F4F1] font-semibold text-xs border border-white/15 transition-all cursor-pointer"
              >
                Log Spoilage
              </button>
            </div>
          </div>

          {/* Embedded Frosted Glass Pill Bar (Exact match to reference image's `76k | 1.5m | $3.6k | 47` bar) */}
          <div className="mt-8 relative z-10">
            <div className="bg-white/[0.08] backdrop-blur-2xl border border-white/15 rounded-3xl p-3 sm:p-4 shadow-xl flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
              {/* Metric 1: Revenue */}
              <div className="flex-1 min-w-[70px] text-center px-2">
                <p className="text-lg sm:text-xl font-extrabold text-[#F5F4F1] tracking-tight">
                  ₹{(kpis.totalRevenue / 1000).toFixed(1)}k
                </p>
                <div className="flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A7D78A]" />
                  <span className="text-[10px] text-[#929195] font-medium">Revenue</span>
                </div>
              </div>

              <div className="w-px h-8 bg-white/10" />

              {/* Metric 2: Plates */}
              <div className="flex-1 min-w-[70px] text-center px-2">
                <p className="text-lg sm:text-xl font-extrabold text-[#F5F4F1] tracking-tight">
                  {(kpis.totalPlatesSold / 1000).toFixed(1)}k
                </p>
                <div className="flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#EAB64B]" />
                  <span className="text-[10px] text-[#929195] font-medium">Plates Sold</span>
                </div>
              </div>

              <div className="w-px h-8 bg-white/10" />

              {/* Metric 3: Gross Profit */}
              <div className="flex-1 min-w-[70px] text-center px-2">
                <p className="text-lg sm:text-xl font-extrabold text-[#F5F4F1] tracking-tight">
                  ₹{(kpis.grossProfit / 1000).toFixed(1)}k
                </p>
                <div className="flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A7D78A]" />
                  <span className="text-[10px] text-[#929195] font-medium">Profit ({Number(kpis.grossMarginPct || 72).toFixed(0)}%)</span>
                </div>
              </div>

              <div className="w-px h-8 bg-white/10" />

              {/* Metric 4: Food Waste */}
              <div className="flex-1 min-w-[70px] text-center px-2">
                <p className="text-lg sm:text-xl font-extrabold text-[#E58B79] tracking-tight">
                  ₹{(kpis.totalWasteCost / 1000).toFixed(1)}k
                </p>
                <div className="flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E58B79]" />
                  <span className="text-[10px] text-[#929195] font-medium">Waste ({Number(kpis.wasteRatePct || 0.6).toFixed(1)}%)</span>
                </div>
              </div>

              {/* Arrow action button at end */}
              <button
                onClick={() => setActiveTab('sales')}
                className="w-8 h-8 rounded-full bg-white/[0.12] hover:bg-white/[0.22] text-[#F5F4F1] flex items-center justify-center shrink-0 border border-white/20 transition-all cursor-pointer ml-1"
                title="View Sales Engine"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Stacked Top-Right Cards (matching reference image's dual curves & latest sales card) */}
        <div className="lg:col-span-5 flex flex-col gap-5 justify-between">
          {/* Card 1: Active Footfall & Commuter Rush ("Active Users right now" style) */}
          <div className="glass-card p-5 flex flex-col justify-between flex-1 relative overflow-hidden">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-[#F5F4F1]">Rush Footfall Curve</span>
                  <span className="w-2 h-2 rounded-full bg-[#EAB64B] animate-ping" />
                </div>
                <p className="text-[11px] text-[#929195]">Commuter throughput per hour</p>
              </div>

              {/* Peak indicator badge */}
              <div className="px-2.5 py-1 rounded-full bg-white/[0.08] border border-white/12 text-[10px] font-bold text-[#A7D78A]">
                Peak: 625 plates/hr
              </div>
            </div>

            {/* Dual smooth curve lines in Recharts */}
            <div className="h-36 w-full -mb-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={hourlyProfile} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="greenGlow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#A7D78A" stopOpacity={0.25} />
                      <stop offset="95%" stopColor="#A7D78A" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="saffronGlow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EAB64B" stopOpacity={0.25} />
                      <stop offset="95%" stopColor="#EAB64B" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
                  <XAxis dataKey="hour" tick={{ fill: '#929195', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#929195', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(28,28,30,0.95)',
                      borderColor: 'rgba(255,255,255,0.15)',
                      borderRadius: '14px',
                      fontSize: '11px',
                      color: '#F5F4F1'
                    }}
                    formatter={(val, name) => [
                      name === 'plates' ? `${val} plates` : `₹${val}`,
                      name === 'plates' ? 'Plates' : 'Revenue'
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="plates"
                    stroke="#EAB64B"
                    strokeWidth={2.5}
                    fill="url(#saffronGlow)"
                    dot={{ r: 2.5, fill: '#EAB64B' }}
                    activeDot={{ r: 5, fill: '#EAB64B', stroke: '#171717', strokeWidth: 2 }}
                    name="Plates"
                  />
                  <Line
                    type="monotone"
                    dataKey="orders"
                    stroke="#A7D78A"
                    strokeWidth={2}
                    dot={false}
                    name="Orders"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Card 2: Latest Sales & Margin Velocity ("Latest Sales" in reference) */}
          <div className="glass-card p-5 flex items-center justify-between gap-4 flex-1">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-[#929195]">
                <span>Counter Velocity</span>
                <span className="text-[#A7D78A] font-bold text-[10px] bg-[#A7D78A]/15 px-1.5 py-0.5 rounded-md">
                  +14%
                </span>
              </div>
              <h3 className="text-3xl font-extrabold text-[#F5F4F1] tracking-tight">
                ₹{typeof kpis.aov === 'number' ? kpis.aov.toFixed(2) : kpis.aov}
              </h3>
              <p className="text-[11px] text-[#929195]">
                Average Order Value • 1.7 plates / bill
              </p>
            </div>

            {/* Side visual thumbnail card (mirroring reference backpack visual) */}
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-white/[0.08] to-white/[0.02] border border-white/12 flex flex-col items-center justify-center p-2 text-center shadow-inner shrink-0">
              <div className="w-8 h-8 rounded-full bg-[#EAB64B]/20 text-[#EAB64B] flex items-center justify-center mb-1">
                <Utensils className="w-4 h-4" />
              </div>
              <p className="text-[10px] font-bold text-[#F5F4F1] leading-tight line-clamp-1">
                Regular 6pc
              </p>
              <p className="text-[9px] text-[#A7D78A] font-semibold mt-0.5">
                Top Variety
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* MIDDLE SECTION: Daily Revenue vs Cost Breakdown                */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Daily Revenue Area Trendline */}
        <div className="lg:col-span-8 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1] tracking-tight">
                Daily Sales Trajectory & Margin Consistency
              </h3>
              <p className="text-xs text-[#929195]">
                Gross counter receipts vs direct raw material COGS
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2.5 py-1 rounded-full border border-[#A7D78A]/30">
                72.1% Gross Margin
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailySales} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="chartRevGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#A7D78A" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#A7D78A" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="chartCogsGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EAB64B" stopOpacity={0.20} />
                    <stop offset="95%" stopColor="#EAB64B" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="date" tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#929195', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(28,28,30,0.95)',
                    borderColor: 'rgba(255,255,255,0.15)',
                    borderRadius: '14px',
                    fontSize: '11px',
                    color: '#F5F4F1'
                  }}
                  formatter={(val) => `₹${val.toLocaleString('en-IN')}`}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#A7D78A"
                  strokeWidth={2.5}
                  fill="url(#chartRevGlow)"
                  name="Gross Revenue (₹)"
                />
                <Area
                  type="monotone"
                  dataKey="cogs"
                  stroke="#EAB64B"
                  strokeWidth={2}
                  fill="url(#chartCogsGlow)"
                  name="COGS Cost (₹)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Compact Inventory & Spoilage Drag Summary */}
        <div className="lg:col-span-4 glass-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-[#F5F4F1]">Stock Reserves Health</h3>
              <p className="text-xs text-[#929195]">Real-time ingredient runway</p>
            </div>
            <button
              onClick={() => setActiveTab('inventory')}
              className="text-xs font-bold text-[#A7D78A] hover:underline cursor-pointer"
            >
              Full Ledger →
            </button>
          </div>

          <div className="space-y-3.5 my-auto">
            {inventoryData?.ingredients?.slice(0, 4).map((ing) => {
              const isLow = ing.status === 'Low' || ing.status === 'Critical';
              return (
                <div key={ing.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#F5F4F1] truncate">{ing.name}</span>
                    <span className={`font-mono text-xs font-bold ${isLow ? 'text-[#EAB64B]' : 'text-[#A7D78A]'}`}>
                      {ing.current_stock} {ing.unit}
                    </span>
                  </div>
                  {/* Glass progress bar */}
                  <div className="w-full h-2 rounded-full bg-white/[0.08] overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isLow ? 'bg-[#EAB64B]' : 'bg-[#A7D78A]'
                      }`}
                      style={{
                        width: `${Math.min(100, (ing.current_stock / (ing.reorder_level * 1.5)) * 100)}%`
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
            <span className="text-[#929195]">Active Spoilage Rate</span>
            <span className="font-bold text-[#E58B79] bg-[#E58B79]/15 px-2 py-0.5 rounded-full border border-[#E58B79]/30">
              4.8% Drag
            </span>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* BOTTOM SECTION: Top Varieties in Period                         */}
      {/* (Direct visual translation of "Your top videos in this period") */}
      {/* ============================================================== */}
      <div className="glass-card p-5 sm:p-6 space-y-4">
        {/* Header row with dropdown selector matching reference */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] tracking-tight">
              Top Golgappa Varieties in this Period
            </h3>
            <p className="text-xs text-[#929195]">
              Ranked by plate volume, recipe margins & customer repeat orders
            </p>
          </div>

          {/* Popularity Dropdown Pill */}
          <div className="flex items-center gap-2">
            <div className="px-3.5 py-1.5 rounded-2xl bg-white/[0.08] border border-white/12 text-xs font-semibold text-[#F5F4F1] flex items-center gap-2">
              <span>Sort by:</span>
              <select
                value={varietySortBy}
                onChange={(e) => setVarietySortBy(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-[#A7D78A] focus:outline-hidden cursor-pointer"
              >
                <option value="popularity" className="bg-[#1C1C1E] text-white">Popularity & Volume</option>
                <option value="revenue" className="bg-[#1C1C1E] text-white">Gross Revenue (₹)</option>
                <option value="margin" className="bg-[#1C1C1E] text-white">Contribution Margin %</option>
              </select>
            </div>
          </div>
        </div>

        {/* Variety Glass Rows matching the video list rows in reference */}
        <div className="space-y-2.5">
          {topVarieties.map((item, idx) => (
            <div
              key={item.id}
              className="bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all duration-150 group"
            >
              {/* Product Info with Squircle Thumbnail */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-white/[0.12] to-white/[0.04] border border-white/15 flex items-center justify-center shrink-0 shadow-inner group-hover:border-[#A7D78A]/40 transition-colors">
                  <span className="font-extrabold text-sm text-[#EAB64B]">
                    0{idx + 1}
                  </span>
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-bold text-[#F5F4F1] truncate tracking-tight">
                    {item.name}
                  </h4>
                  <p className="text-xs text-[#929195] truncate mt-0.5">
                    {item.flavour}
                  </p>
                </div>
              </div>

              {/* Metrics with Colored Dots */}
              <div className="flex items-center gap-6 text-xs shrink-0 flex-wrap sm:flex-nowrap">
                {/* Plates Sold with yellow dot */}
                <div className="flex items-center gap-1.5 min-w-[90px]">
                  <span className="w-2 h-2 rounded-full bg-[#EAB64B]" />
                  <span className="font-bold text-[#F5F4F1]">{item.plates.toLocaleString('en-IN')}</span>
                  <span className="text-[#929195]">plates</span>
                </div>

                {/* Revenue generated */}
                <div className="flex items-center gap-1.5 min-w-[95px]">
                  <span className="w-2 h-2 rounded-full bg-[#A7D78A]" />
                  <span className="font-bold text-[#F5F4F1]">₹{item.revenue.toLocaleString('en-IN')}</span>
                </div>

                {/* Gross Margin % with pill */}
                <div className="min-w-[70px]">
                  <span className="text-[11px] font-bold text-[#A7D78A] bg-[#A7D78A]/15 px-2.5 py-1 rounded-full border border-[#A7D78A]/30">
                    {item.margin}% margin
                  </span>
                </div>

                {/* Mini Visual Curve / Sparkline */}
                <div className="w-16 h-6 hidden md:block">
                  <svg className="w-full h-full" viewBox="0 0 60 20" fill="none">
                    <path
                      d="M0 15 Q 15 5, 30 12 T 60 4"
                      stroke={item.color}
                      strokeWidth="2"
                      fill="none"
                      strokeLinecap="round"
                    />
                  </svg>
                </div>

                {/* Action button */}
                <button
                  onClick={() => setActiveTab('menu')}
                  className="p-1.5 rounded-xl hover:bg-white/10 text-[#929195] hover:text-[#F5F4F1] transition-colors"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============================================================== */}
      {/* RECENT LIVE INVOICES TABLE (Preserved Functionality)            */}
      {/* ============================================================== */}
      <div className="glass-card p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-[#F5F4F1] tracking-tight">
              Recent Counter Transactions Ledger
            </h3>
            <p className="text-xs text-[#929195]">
              Real-time invoice records with digital payment modes
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            {['All', 'UPI', 'Cash'].map((f) => (
              <button
                key={f}
                onClick={() => setActiveCategoryFilter(f)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeCategoryFilter === f
                    ? 'bg-white/20 text-[#F5F4F1] border border-white/25 shadow-xs'
                    : 'bg-white/[0.05] text-[#929195] hover:text-[#F5F4F1] border border-transparent'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#F5F4F1]">
            <thead className="bg-white/[0.04] text-[#929195] font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3 rounded-l-xl">Invoice</th>
                <th className="px-4 py-3">Time</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Items Ordered</th>
                <th className="px-4 py-3 text-center">Plates</th>
                <th className="px-4 py-3 text-right">Amount (₹)</th>
                <th className="px-4 py-3 text-center">Payment</th>
                <th className="px-4 py-3 text-center rounded-r-xl">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              {filteredTransactions
                .filter(t => activeCategoryFilter === 'All' || t.paymentMethod === activeCategoryFilter)
                .slice(0, 6)
                .map((txn) => (
                  <tr key={txn.id} className="hover:bg-white/[0.04] transition-colors">
                    <td className="px-4 py-3 font-mono font-medium text-[#A7D78A]">
                      {txn.id}
                    </td>
                    <td className="px-4 py-3 text-[#929195]">
                      {txn.time}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        txn.customerType === 'Dine-in'
                          ? 'bg-[#A7D78A]/15 text-[#A7D78A]'
                          : 'bg-[#EAB64B]/15 text-[#EAB64B]'
                      }`}>
                        {txn.customerType}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[#F5F4F1] font-medium max-w-xs truncate">
                      {txn.itemsSummary}
                    </td>
                    <td className="px-4 py-3 text-center font-bold">
                      {txn.totalPlates}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-[#F5F4F1]">
                      ₹{txn.amount.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant={txn.paymentMethod === 'UPI' ? 'success' : txn.paymentMethod === 'Cash' ? 'warning' : 'neutral'}
                        size="sm"
                      >
                        {txn.paymentMethod}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#A7D78A]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Restock Inventory Modal */}
      <Modal
        isOpen={isRestockModalOpen}
        onClose={() => setIsRestockModalOpen(false)}
        title="Restock Raw Material Inventory"
        subtitle="Log incoming mandi deliveries directly into counter reserve balances"
      >
        <form onSubmit={handleRestockSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Select Ingredient
            </label>
            <select
              value={selectedIngredient}
              onChange={(e) => setSelectedIngredient(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              {inventoryData?.ingredients?.map((ing) => (
                <option key={ing.id} value={ing.id}>
                  {ing.name} ({ing.unit}) — Current: {ing.current_stock}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Quantity Added
            </label>
            <input
              type="number"
              step="any"
              required
              min="0.1"
              placeholder="e.g. 500 pcs puris or 10 kg aloo"
              value={restockQty}
              onChange={(e) => setRestockQty(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setIsRestockModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#929195] hover:text-[#F5F4F1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#A7D78A] text-[#171717] hover:bg-[#96C679] transition-colors shadow-md"
            >
              {isSubmitting ? 'Updating...' : 'Confirm Restock'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Log Food Waste Modal */}
      <Modal
        isOpen={isWasteModalOpen}
        onClose={() => setIsWasteModalOpen(false)}
        title="Record Spoilage & Breakage Incident"
        subtitle="Maintain daily deduction audits for broken puris and souring water"
      >
        <form onSubmit={handleWasteSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Damaged / Discarded Material
            </label>
            <select
              value={selectedIngredient}
              onChange={(e) => setSelectedIngredient(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              {inventoryData?.ingredients?.map((ing) => (
                <option key={ing.id} value={ing.id}>
                  {ing.name} ({ing.unit})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Quantity Discarded
            </label>
            <input
              type="number"
              step="any"
              required
              min="0.1"
              placeholder="e.g. 50 puris or 2.5 L pani"
              value={wasteQty}
              onChange={(e) => setWasteQty(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-white/[0.06] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#F5F4F1] mb-1">
              Primary Reason
            </label>
            <select
              value={wasteReason}
              onChange={(e) => setWasteReason(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-white/15 text-xs bg-[#1E1E22] text-[#F5F4F1] focus:outline-hidden focus:border-[#A7D78A]"
            >
              <option value="Broken Puris (Transit/Handling)">Broken Puris (Transit/Handling)</option>
              <option value="Leftover Souring Flavoured Pani">Leftover Souring Flavoured Pani</option>
              <option value="Excess Boiled Potato Mash Souring">Excess Boiled Potato Mash Souring</option>
              <option value="Stale Tamarind Chutney">Stale Tamarind Chutney</option>
              <option value="Spillage / Contamination">Spillage / Counter Drop</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setIsWasteModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#929195] hover:text-[#F5F4F1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#E58B79] text-[#171717] hover:bg-[#D47A68] transition-colors shadow-md"
            >
              {isSubmitting ? 'Recording...' : 'Record Spoilage Entry'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
