import React from 'react';
import { CONSTELLATIONS_DATA } from '../../data/constellations';

/**
 * ConstellationCardGrid — "EXPLORE THE CONSTELLATIONS"
 * 6 interactive preview cards showcasing Orion, Ursa Major, Cassiopeia,
 * Scorpius, Leo, and Canis Major.
 * Clicking a card selects that constellation in the main sky map and scrolls up.
 */
export default function ConstellationCardGrid({
  selectedId,
  onSelectConstellation,
  onViewOnUniverseMap,
}) {
  const handleCardClick = (id) => {
    onSelectConstellation(id);
    const mapElement = document.getElementById('constellation-sky-map');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Main showcase star label for each constellation
  const getMainStarLabel = (constellation) => {
    switch (constellation.id) {
      case 'orion':
        return 'Betelgeuse & Rigel';
      case 'ursa-major':
        return 'Dubhe & Merak';
      case 'cassiopeia':
        return 'Schedar & Navi';
      case 'scorpius':
        return 'Antares & Shaula';
      case 'leo':
        return 'Regulus & Denebola';
      case 'canis-major':
        return 'Sirius & Adhara';
      default:
        return constellation.mainStars[0]?.name || 'Primary Star';
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 text-left">
      {/* Section Sub-Heading */}
      <div className="text-center max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-[0.25em] text-cyan-400 block mb-2">
          CURATED CELESTIAL PATTERNS
        </span>
        <h3 className="font-display text-2xl sm:text-3xl font-semibold text-white">
          EXPLORE THE CONSTELLATIONS
        </h3>
        <p className="font-sans text-sm text-slate-300 mt-2">
          Select any of the six featured constellations to project its complete star pattern, spectroscopic telemetry, and ancient lore onto the observatory canvas.
        </p>
      </div>

      {/* 6 Constellation Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CONSTELLATIONS_DATA.map((constellation) => {
          const isSelected = constellation.id === selectedId;
          const starMap = new Map();
          constellation.mainStars.forEach((s) => starMap.set(s.id, s));

          return (
            <div
              key={constellation.id}
              onClick={() => handleCardClick(constellation.id)}
              className={`group relative rounded-3xl p-6 glass-surface transition-all duration-500 cursor-pointer flex flex-col justify-between border ${
                isSelected
                  ? 'border-cyan-400/80 bg-cyan-950/30 shadow-[0_15px_40px_rgba(6,182,212,0.25)] -translate-y-1'
                  : 'border-white/10 hover:border-cyan-400/50 hover:bg-white/5 hover:-translate-y-1.5 hover:shadow-[0_20px_40px_rgba(0,0,0,0.6)]'
              }`}
              role="button"
              tabIndex={0}
              aria-label={`Select ${constellation.name}`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleCardClick(constellation.id);
                }
              }}
            >
              {/* Top Header & Abbreviation Badge */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span
                    className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: `${constellation.accentColor}20`,
                      color: constellation.accentColor,
                      border: `1px solid ${constellation.accentColor}40`,
                    }}
                  >
                    {constellation.abbreviation}
                  </span>

                  <span className="text-[11px] font-mono text-slate-400">
                    {constellation.areaSqDeg} SQ DEG
                  </span>
                </div>

                {/* Mini Star-Map SVG Preview */}
                <div className="relative w-full aspect-[16/9] rounded-2xl bg-[#020308]/70 border border-white/8 overflow-hidden mb-5 group-hover:border-cyan-500/30 transition-colors">
                  <svg
                    viewBox="0 0 1000 800"
                    className="w-full h-full p-2"
                  >
                    {/* Connecting Lines */}
                    {constellation.connectedStarPattern.map(([starAId, starBId], idx) => {
                      const starA = starMap.get(starAId);
                      const starB = starMap.get(starBId);
                      if (!starA || !starB) return null;

                      return (
                        <line
                          key={idx}
                          x1={starA.x}
                          y1={starA.y}
                          x2={starB.x}
                          y2={starB.y}
                          stroke={constellation.accentColor}
                          strokeWidth={isSelected ? 3.5 : 2}
                          strokeOpacity={isSelected ? 0.9 : 0.45}
                          className="group-hover:stroke-opacity-90 transition-all duration-300"
                        />
                      );
                    })}

                    {/* Star Nodes */}
                    {constellation.mainStars.map((s) => (
                      <g key={s.id}>
                        <circle
                          cx={s.x}
                          cy={s.y}
                          r={s.isFocal ? 12 : 7}
                          fill={s.colorHex}
                          opacity={0.4}
                          className="group-hover:opacity-75 transition-opacity"
                        />
                        <circle
                          cx={s.x}
                          cy={s.y}
                          r={s.isFocal ? 7 : 4}
                          fill="#ffffff"
                        />
                      </g>
                    ))}
                  </svg>

                  {/* Active Pin Dot */}
                  {isSelected && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[9px] font-mono bg-cyan-400 text-slate-950 font-bold uppercase tracking-wider">
                      ACTIVE ATLAS
                    </span>
                  )}
                </div>

                {/* Name & Titles */}
                <div className="mb-4">
                  <h4 className="font-display text-2xl font-semibold text-white group-hover:text-cyan-200 transition-colors">
                    {constellation.name}
                  </h4>
                  <p className="text-xs font-mono uppercase tracking-widest text-amber-300/90 font-medium">
                    “{constellation.commonTitle}”
                  </p>
                </div>

                {/* Metadata Properties */}
                <div className="space-y-1.5 text-xs font-mono border-t border-white/5 pt-3">
                  <div className="flex justify-between text-slate-400">
                    <span>HEMISPHERE:</span>
                    <span className="text-slate-200">{constellation.hemisphere.split(' ')[0]}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>BEST VIEWING:</span>
                    <span className="text-amber-300">{constellation.bestViewingSeason.split(' ')[0]}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>MAIN STARS:</span>
                    <span className="text-cyan-300 font-semibold">{getMainStarLabel(constellation)}</span>
                  </div>
                </div>
              </div>

              {/* Bottom Actions Bar */}
              <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                <span className="text-cyan-400 group-hover:text-cyan-300 font-semibold flex items-center gap-1.5">
                  <span>Explore Constellation</span>
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </span>
                <div className="flex items-center gap-2">
                  {onViewOnUniverseMap && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onViewOnUniverseMap(constellation.id);
                      }}
                      className="px-2 py-0.5 rounded text-[10px] bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-400/40 hover:border-cyan-400 transition-all cursor-pointer"
                      title={`View ${constellation.name} on the interactive Universe Map`}
                    >
                      Map ↗
                    </button>
                  )}
                  <span className="text-[10px] text-slate-500 uppercase">
                    {constellation.mainStars.length} STARS
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
