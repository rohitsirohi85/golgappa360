# EV SMART: Video Demonstration & Presentation Cue Sheet
## Timed 8-Minute End-to-End Walkthrough Script for Evaluators and Viva

---

## 1. Video Production Overview
- **Target Duration:** 7 to 8 Minutes
- **Video Resolution:** 1080p (1920x1080) at 60 FPS
- **Audio:** Clear directional condenser microphone, zero background noise, consistent vocal delivery
- **Layout:** Screen recording with Picture-in-Picture (PiP) hardware testbench camera feed in upper-right corner during live telemetry demos.

---

## 2. Timed Scene-by-Scene Cue Sheet

```
+------------------+--------------------------------------------------------------+
| TIMELINE         | SCENE & CONTENT                                              |
+------------------+--------------------------------------------------------------+
| 00:00 - 00:45    | Scene 1: Project Title, Problem Statement & Academic Context |
| 00:45 - 01:45    | Scene 2: Hardware Testbed & Circuit Assembly Walkthrough     |
| 01:45 - 03:15    | Scene 3: Driver Journey: Discovery, Booking & Live Charging  |
| 03:15 - 04:45    | Scene 4: Admin Fleet Dashboard, Telemetry & Safety Cutoff    |
| 04:45 - 06:15    | Scene 5: AI Microservice: Forecasting, Anomalies & Tariffs   |
| 06:15 - 07:15    | Scene 6: System Security, Audit Trail & Performance Metrics  |
| 07:15 - 08:00    | Scene 7: Limitations, Future Scope & Academic Conclusion     |
+------------------+--------------------------------------------------------------+
```

---

### Scene 1: Introduction, Problem Statement & Architecture (00:00 – 00:45)
- **Visual on Screen:** Title slide showing project name, architecture diagram animation, and academic prototype disclaimer banner.
- **Voiceover Script:**  
  *"Welcome to the demonstration of EV SMART, an end-to-end IoT and Machine Learning platform for Electric Vehicle charging station management and energy optimization. Modern EV charging faces two immense challenges: localized grid overload during peak charging hours, and the lack of real-time, edge-level telemetry and autonomous safety. EV SMART addresses this by uniting physical embedded controllers, high-speed cloud microservices, and predictive AI into a unified platform. Note that this is an academic laboratory prototype operating at single-phase AC levels."*
- **Visual Highlight:** Zoom in on the 4-tier architecture diagram showing the seamless connection between the ESP32 edge, cloud backend, AI engine, and user interfaces.

---

### Scene 2: Physical Hardware Testbed Walkthrough (00:45 – 01:45)
- **Visual on Screen:** Full camera view of the physical hardware testbench.
- **Components Pointed to:**  
  1. ESP32-WROOM-32 microcontroller  
  2. PZEM-004T v3.0 AC energy sensor connected via UART2  
  3. DHT22 temperature and humidity sensor  
  4. 30A optocoupled relay module wired to the load socket  
  5. Panel-mounted red Emergency Stop pushbutton  
  6. 16x2 I2C LCD showing local telemetry  
  7. Connected AC load (test lamp / heating element)
- **Voiceover Script:**  
  *"Here is our physical IoT edge prototype. At the center is an ESP32 dual-core microcontroller running custom FreeRTOS firmware. It interfaces with a PZEM-004T AC power sensor to measure true RMS voltage, current, active power, and power factor. Ambient and enclosure temperatures are monitored via this DHT22 sensor. AC mains power is switched to the EV socket via a 30A optocoupled relay. Crucially, we have engineered an independent FreeRTOS task running on Core 0 that continuously evaluates thermal thresholds: if the enclosure exceeds 60°C or current exceeds 32A, the relay is forced open in under 50 milliseconds, completely independent of cloud connectivity. For physical manual safety, this industrial emergency stop button immediately trips the circuit."*
- **Action:** Point with stylus to each component; show the LCD displaying real-time voltage (~230V).
- **Fallback / Backup:** If physical hardware is being shown remotely, play pre-recorded close-up B-roll of the breadboard assembly.

---

### Scene 3: Driver Journey: Discovery, Booking & Live Charging (01:45 – 03:15)
- **Visual on Screen:** Driver Mobile Application running in desktop responsive viewport.
- **Actions on Screen:**  
  1. Log in via Demo Driver button.
  2. Browse nearby charging stations on interactive map; show real-time "Available" badge on Downtown Station.
  3. Open slot reservation modal; select a 30-minute window; confirm booking.
  4. Launch active charging session via simulated QR scanner.
  5. The Active Charging Cockpit appears with circular SOC gauge and live dials.
  6. Bring in PiP camera showing physical relay clicking ON and test lamp illuminating.
  7. Observe live telemetry streaming on screen: Voltage (231V), Current (5.2A), Power (1.2 kW), Energy ticking upwards.
  8. Click "Stop Charging"; show receipt modal with itemized breakdown and wallet deduction.
- **Voiceover Script:**  
  *"Now let's experience the driver workflow. A driver logs into the mobile app and views nearby stations on this interactive map. We select Downtown Supercharger Hub and reserve a slot on Charger 1. Notice the booking engine immediately locks the slot to prevent conflicting reservations. When the driver arrives, they initiate the session. As the cloud dispatches the start command over MQTT, listen—the physical relay engages, the load illuminates, and the active session HUD begins streaming live telemetry. The voltage, current, and energy consumption update every single second via WebSockets without refreshing the page. When the driver clicks Stop, the relay instantly opens, the session finalizes, and an itemized receipt is generated with wallet settlement."*

---

### Scene 4: Admin Fleet Dashboard, Telemetry & Safety Cutoff (03:15 – 04:45)
- **Visual on Screen:** Admin Fleet Portal (`http://localhost:5173/admin`).
- **Actions on Screen:**  
  1. Show Executive Overview KPI cards: total energy delivered, active chargers, network uptime.
  2. Navigate to "Multi-Station Grid"; view live status badges across the fleet.
  3. Click on Charger 1 to open deep diagnostics: show real-time sensor metrics and RSSI signal.
  4. Demonstrate the Centralized Remote Emergency Stop button: click it and observe the physical relay trip instantly.
  5. Switch to "Fault Log" and show the `EMERGENCY_SHUTDOWN` event recorded with exact timestamp.
- **Voiceover Script:**  
  *"Switching to the perspective of the network operator, here is the executive Admin Fleet Dashboard. Operators have a bird's-eye view of network energy throughput, active revenue, and fleet health. In the charger grid, all charging points are tracked in real-time. If an operator spots an abnormal operating condition, they can open the charger diagnostics and trigger a remote override. Let's demonstrate the safety cutoff: clicking Emergency Stop transmits an immediate command over MQTT—the relay trips in milliseconds, and the incident is instantly logged in the central fault triage table with root cause categorization."*

---

### Scene 5: AI Microservice: Forecasting, Anomalies & Tariffs (04:45 – 06:15)
- **Visual on Screen:** Admin "AI Intelligence" navigation views.
- **Actions on Screen:**  
  1. Open "Demand Forecasting" chart: show historical load vs. Random Forest 24-hour prediction line. Highlight confidence bands.
  2. Open "Anomaly Detection" view: show scatter plot with green normal telemetry points and isolated red anomalous outliers.
  3. Open "Dynamic Tariffs": show hourly price curve scaling up during predicted peak demand hours.
- **Voiceover Script:**  
  *"Now we examine the intelligence tier. Running as a dedicated Python FastAPI microservice, our AI engine delivers predictive optimization. For grid load management, we deployed a scikit-learn Random Forest Regressor trained on cyclical temporal features, temperature, and historical demand. It predicts station load for the next 24 hours with an R-squared of 0.9902 and a Mean Absolute Error of just 3.09 kilowatt-hours. These predictions directly drive our Dynamic Tariff Optimizer, automatically raising per-unit rates during anticipated peak hours to incentivize off-peak charging. Simultaneously, an unsupervised Isolation Forest model analyzes real-time electrical telemetry vectors to flag anomalies such as voltage sags or harmonic distortion, providing true predictive maintenance before hardware fails."*

---

### Scene 6: Security, Audit Trail & Performance Benchmarks (06:15 – 07:15)
- **Visual on Screen:** Admin "Security & Audit" log view, followed by terminal showing passing automated test suites.
- **Actions on Screen:**  
  1. Scroll through the tamper-evident Audit Log showing actor emails, IP addresses, and encrypted action hashes.
  2. Display terminal showing `npm test` passing 202/202 assertions.
  3. Display performance benchmark table on screen.
- **Voiceover Script:**  
  *"Security and performance are paramount in critical infrastructure. Every administrative mutation—from tariff changes to emergency shutdowns—is recorded in this immutable, tamper-evident audit log. The system is fortified with bcrypt password hashing, JWT stateless authorization, Helmet security headers, and IP-based rate limiting. Under rigorous benchmarking, our Node.js backend handles sensor surges with an average latency of just 17.45 milliseconds, while our AI microservice returns inference in under 11 milliseconds. All six automated integration test suites pass with a 100% success rate across 202 assertions."*

---

### Scene 7: Limitations, Future Work & Academic Conclusion (07:15 – 08:00)
- **Visual on Screen:** Summary slide listing achievements, prototype boundaries, and future research vectors.
- **Voiceover Script:**  
  *"In conclusion, EV SMART validates that low-cost open hardware, event-driven cloud architecture, and edge safety can successfully converge with predictive machine learning to solve real-world EV charging challenges. As an academic laboratory prototype, the physical system is currently limited to single-phase AC charging up to 16A and uses a simulated payment sandbox. Future phases will incorporate full OCPP 2.0.1 compliance, ISO 15118 Plug & Charge, and Vehicle-to-Grid bi-directional power flow. Thank you for your time, and we now welcome any questions."*

---

## 3. Evaluator Q&A Preparedness Tips

| Examiner Question | Instant 10-Second Response |
| :--- | :--- |
| **"What if Wi-Fi disconnects during charging?"** | *"The ESP32 runs an autonomous FreeRTOS safety task on Core 0. The relay remains safe, local current/thermal limits are still enforced, and telemetry is cached in an SRAM ring-buffer until Wi-Fi reconnects."* |
| **"Why not run the AI directly on the ESP32?"** | *"Our Random Forest model requires tabular time-series features across multi-station aggregates. Running inference on an asynchronous cloud microservice maintains sub-11ms response times while reserving microcontroller memory for real-time safety."* |
| **"Is this certified for commercial public installation?"** | *"No, this is an academic research and laboratory prototype operating at scaled single-phase AC levels. Commercial deployment requires IEC 61851-1 Type B RCCB protection, CE/UL certification, and formal OCPP 2.0.1 compliance."* |
