import React from 'react';
import { CheckCircle2, AlertTriangle, AlertOctagon, HelpCircle } from 'lucide-react';

export const StatusBadge = ({ status, text }) => {
  const normalized = (status || '').toLowerCase();

  if (normalized === 'optimal' || normalized === 'low' || normalized === 'compliant') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
        <CheckCircle2 className="w-3.5 h-3.5 text-[#16865B]" />
        {text || 'Optimal (<10%)'}
      </span>
    );
  }

  if (normalized === 'moderate' || normalized === 'warning') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]">
        <AlertTriangle className="w-3.5 h-3.5 text-[#D97706]" />
        {text || 'Moderate (10-13%)'}
      </span>
    );
  }

  if (normalized === 'excessive' || normalized === 'critical' || normalized === 'over-prepared') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]">
        <AlertOctagon className="w-3.5 h-3.5 text-[#DC2626]" />
        {text || 'Excessive (>13%)'}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#F1F5F2] text-[#55635C] border border-[#E4EAE5]">
      <HelpCircle className="w-3.5 h-3.5 text-[#77847C]" />
      {text || status}
    </span>
  );
};
