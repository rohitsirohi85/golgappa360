import React from 'react';

/**
 * SolarSystemControls — HUD control deck for the interactive Solar System
 * 
 * Features:
 * - Back to Universe Map navigation button
 * - Play / Pause orbital motion & speed multiplier (0.5x, 1x, 2x)
 * - Orbit lines toggle (ON / OFF)
 * - Zoom in / out / reset view
 * - Quick planet navigation jump pills (Sun, Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune)
 */
export default function SolarSystemControls({
  onBackToUniverse,
  isPlaying,
  onTogglePlay,
  speedFactor,
  onChangeSpeed,
  showOrbits,
  onToggleOrbits,
  onZoomIn,
  onZoomOut,
  onResetView,
  onSelectPlanet,
  selectedPlanetId,
  planets = [],
  className = '',
}) {
  return (
    <div className={`flex flex-col gap-2.5 ${className}`}>
      {/* Top Primary Actions Bar */}
      <div className="flex flex-wrap items-center gap-2 bg-[#020308]/85 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.85)]">
        {/* Back to Universe Map Button */}
        <button
          type="button"
          onClick={onBackToUniverse}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-400/50 hover:border-cyan-300 text-cyan-200 hover:text-white text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.25)] group"
          title="Return to the full Universe Map"
        >
          <span className="text-cyan-400 group-hover:-translate-x-0.5 transition-transform">←</span>
          <span>UNIVERSE MAP</span>
        </button>

        <div className="h-4 w-[1px] bg-white/10 mx-0.5 hidden sm:block" />

        {/* Play / Pause Orbital Motion */}
        <button
          type="button"
          onClick={onTogglePlay}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-mono transition-all cursor-pointer ${
            isPlaying
              ? 'bg-white/[0.04] hover:bg-white/[0.08] border-white/10 text-slate-200'
              : 'bg-amber-500/20 border-amber-500/40 text-amber-200'
          }`}
          title={isPlaying ? 'Pause planetary orbits' : 'Resume planetary orbits'}
        >
          <span>{isPlaying ? '⏸' : '▶'}</span>
          <span className="hidden sm:inline">{isPlaying ? 'PAUSE' : 'PLAY'}</span>
        </button>

        {/* Orbit Speed Toggle */}
        <button
          type="button"
          onClick={onChangeSpeed}
          className="px-2.5 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer"
          title="Toggle orbit animation speed"
        >
          <span>{speedFactor}×</span>
        </button>

        {/* Show / Hide Orbits Toggle */}
        <button
          type="button"
          onClick={onToggleOrbits}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-mono transition-all cursor-pointer ${
            showOrbits
              ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
              : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle visibility of orbital path lines"
        >
          <span className="text-xs">○</span>
          <span className="hidden sm:inline">ORBITS</span>
          <span className="text-[10px] text-cyan-400 font-bold">{showOrbits ? 'ON' : 'OFF'}</span>
        </button>

        <div className="h-4 w-[1px] bg-white/10 mx-0.5 hidden sm:block" />

        {/* Zoom Controls */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onZoomIn}
            className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
            title="Zoom in (+)"
          >
            +
          </button>
          <button
            type="button"
            onClick={onZoomOut}
            className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
            title="Zoom out (−)"
          >
            −
          </button>
          <button
            type="button"
            onClick={onResetView}
            className="px-2.5 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer flex items-center gap-1"
            title="Reset Solar System view to center"
          >
            <span>⟲</span>
            <span className="hidden md:inline">RESET</span>
          </button>
        </div>
      </div>

      {/* Planet Quick-Selector Pills */}
      {planets.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 px-1 bg-[#020308]/75 backdrop-blur-md rounded-xl border border-white/5 max-w-full">
          {planets.map((p) => {
            const isSelected = selectedPlanetId === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => onSelectPlanet(p)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500/20 border border-cyan-400/50 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                    : 'bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 text-slate-300 hover:text-white'
                }`}
                title={`Focus on ${p.name}`}
              >
                <span style={{ color: p.colorHex || '#fbbf24' }}>
                  {p.symbol || (p.isSun ? '☀️' : '●')}
                </span>
                <span className="font-medium">{p.name}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
