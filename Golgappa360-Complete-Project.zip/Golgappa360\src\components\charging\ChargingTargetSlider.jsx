import React from 'react';
import { Target } from 'lucide-react';

export const ChargingTargetSlider = ({
  target = 80,
  onChange,
  min = 20,
  max = 100,
  step = 5,
}) => {
  return (
    <div className="bg-[#0D1527] rounded-2xl p-4 border border-white/10 select-none">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-[#00F5A0]/10 text-[#00F5A0]">
            <Target className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Charging Limit Target
          </span>
        </div>
        <div className="flex items-baseline">
          <span className="text-lg font-mono font-bold text-[#00F5A0]">{target}</span>
          <span className="text-xs font-bold text-[#00F5A0] ml-0.5">%</span>
        </div>
      </div>

      <div className="relative flex flex-col gap-2">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={target}
          onChange={(e) => onChange?.(Number(e.target.value))}
          className="w-full h-2 bg-[#1A2845] rounded-lg appearance-none cursor-pointer accent-[#00F5A0]"
        />

        <div className="flex justify-between text-[10px] text-slate-400 font-mono">
          <span>20% (Min)</span>
          <span className="text-[#00F5A0]/80">80% (Recommended Daily)</span>
          <span>100% (Trip)</span>
        </div>
      </div>
    </div>
  );
};
