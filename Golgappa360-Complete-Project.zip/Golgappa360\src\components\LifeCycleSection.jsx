import React, { useState } from 'react';
import SectionHeading from './SectionHeading';
import NebulaVisual from './LifeCycle/NebulaVisual';
import LifeCycleOverview from './LifeCycle/LifeCycleOverview';
import StageVisualizer from './LifeCycle/StageVisualizer';
import StageDetailPanel from './LifeCycle/StageDetailPanel';
import MassSelector from './LifeCycle/MassSelector';
import BranchingPath from './LifeCycle/BranchingPath';
import EvolutionTimeline from './LifeCycle/EvolutionTimeline';
import WhyMassMatters from './LifeCycle/WhyMassMatters';
import CosmicFacts from './LifeCycle/CosmicFacts';
import { LIFE_CYCLE_STAGES } from '../data/lifeCycleStages';

/**
 * LifeCycleSection — "THE LIFE OF A STAR"
 * Comprehensive Phase 4 Stellar Evolution Experience:
 * 1. Intro Section with Animated Nebula Visual
 * 2. 5-Stage Chronological Lifecycle Overview Track
 * 3. Central Morphing Stage Visualizer & Scientific Explanation Dossier
 * 4. Mass Selector ("CHOOSE A STAR": Low, Sun-Like, High Mass)
 * 5. "MASS WRITES THE ENDING" Interactive Branching Tree
 * 6. "NOT ALL STARS LIVE EQUALLY LONG" Comparative Timeline
 * 7. "WHY DOES MASS MATTER?" Educational Callout
 * 8. Rotating "COSMIC FACT" Panel
 */
export default function LifeCycleSection({ onSelectStarFromLifeCycle }) {
  // Current active lifecycle stage (default: 'molecular-cloud')
  const [activeStageId, setActiveStageId] = useState('molecular-cloud');

  // Current selected mass branch (default: 'sun-like')
  const [selectedMassTrack, setSelectedMassTrack] = useState('sun-like');

  const activeStage =
    LIFE_CYCLE_STAGES.find((s) => s.id === activeStageId) || LIFE_CYCLE_STAGES[0];

  const handleSelectStage = (stageId) => {
    setActiveStageId(stageId);
  };

  const handleSelectTrack = (trackId) => {
    setSelectedMassTrack(trackId);
    // Automatically preview the defining middle/late stage of that track
    if (trackId === 'high-mass') {
      setActiveStageId('supergiant');
    } else if (trackId === 'low-mass') {
      setActiveStageId('main-sequence');
    } else {
      setActiveStageId('red-giant');
    }
  };

  return (
    <section
      id="life-cycle"
      className="relative py-24 sm:py-32 overflow-hidden border-t border-white/5 scroll-mt-20"
    >
      {/* Background Soft Galactic Atmospheres */}
      <div
        aria-hidden="true"
        className="absolute top-1/4 -left-40 w-[650px] h-[650px] rounded-full bg-purple-950/25 blur-[160px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute top-1/2 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-950/20 blur-[150px] pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-10 left-1/3 w-[550px] h-[550px] rounded-full bg-amber-950/15 blur-[140px] pointer-events-none"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-24 sm:space-y-32">
        {/* 1. Cinematic Section Intro & Animated Nebula */}
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          <SectionHeading
            eyebrow="STELLAR EVOLUTION"
            title="EVERY STAR HAS A BEGINNING."
            subtitle="Stars are born inside enormous clouds of gas and dust. Over millions or billions of years, gravity, mass and nuclear fusion shape their destiny."
            align="center"
          />

          {/* Large Subtle Animated Nebula Visual */}
          <div className="w-full mt-10">
            <NebulaVisual />
          </div>
        </div>

        {/* 2. Interactive Life Cycle Overview Sequence */}
        <div>
          <LifeCycleOverview
            activeStageId={activeStageId}
            onSelectStage={handleSelectStage}
          />
        </div>

        {/* 3. Central Morphing Stage Visualizer & Scientific Explanation Dossier */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          <div className="lg:col-span-5 flex justify-center">
            <StageVisualizer stage={activeStage} />
          </div>

          <div className="lg:col-span-7">
            <StageDetailPanel
              stage={activeStage}
              onExploreStar={onSelectStarFromLifeCycle}
            />
          </div>
        </div>

        {/* 4. Mass Selector Control ("CHOOSE A STAR") */}
        <div>
          <MassSelector
            selectedMassTrack={selectedMassTrack}
            onSelectTrack={handleSelectTrack}
          />
        </div>

        {/* 5. Branching Evolutionary Path ("MASS WRITES THE ENDING.") */}
        <div>
          <BranchingPath
            activeStageId={activeStageId}
            selectedMassTrack={selectedMassTrack}
            onSelectStage={handleSelectStage}
          />
        </div>

        {/* 6. Chronological Lifetime Comparison ("NOT ALL STARS LIVE EQUALLY LONG.") */}
        <div>
          <EvolutionTimeline />
        </div>

        {/* 7. Dedicated Educational Callout ("WHY DOES MASS MATTER?") */}
        <div>
          <WhyMassMatters />
        </div>

        {/* 8. Rotating Cosmic Fact Panel */}
        <div>
          <CosmicFacts />
        </div>
      </div>
    </section>
  );
}
