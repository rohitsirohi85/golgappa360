import React, { useState, useEffect, useCallback } from 'react';
import { messApi } from '../services/messApiService';
import { EmptyState } from '../components/common/EmptyState';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { ErrorState } from '../components/common/ErrorState';
import {
  Database,
  Search,
  Download,
  CheckCircle,
  RefreshCw,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useMess } from '../context/MessContext';

export const DatasetExplorerPage = () => {
  const { setIsDemoModalOpen } = useMess();

  // Query and filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [mealFilter, setMealFilter] = useState('All');
  const [menuFilter, setMenuFilter] = useState('All');
  const [weatherFilter, setWeatherFilter] = useState('All');
  const [dayFilter, setDayFilter] = useState('All');
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  // API data states
  const [records, setRecords] = useState([]);
  const [totalRecords, setTotalRecords] = useState(1000);
  const [filteredCount, setFilteredCount] = useState(1000);
  const [totalPages, setTotalPages] = useState(67);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [downloadToast, setDownloadToast] = useState(false);

  const fetchRecords = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await messApi.getDataRecords({
        page: currentPage,
        page_size: pageSize,
        meal_type: mealFilter,
        menu_category: menuFilter,
        weather_condition: weatherFilter,
        weekday: dayFilter,
        search: searchTerm,
        sort_by: sortBy,
        sort_order: sortOrder,
      });

      setRecords(res.records || []);
      setTotalRecords(res.total_records || 1000);
      setFilteredCount(res.filtered_records || 0);
      setTotalPages(res.total_pages || 1);
    } catch (err) {
      console.error('Failed to fetch dataset records:', err);
      setError(err.message || 'Error querying dataset records from backend');
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, pageSize, mealFilter, menuFilter, weatherFilter, dayFilter, searchTerm, sortBy, sortOrder]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
    setCurrentPage(1);
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setMealFilter('All');
    setMenuFilter('All');
    setWeatherFilter('All');
    setDayFilter('All');
    setCurrentPage(1);
  };

  const handleDownloadCSV = () => {
    if (records.length === 0) return;
    const headers = Object.keys(records[0]).join(',');
    const rows = records.map((r) =>
      Object.values(r)
        .map((val) => {
          if (val === null || val === undefined) return '';
          const str = String(val);
          return str.includes(',') || str.includes('"') || str.includes('\n')
            ? `"${str.replace(/"/g, '""')}"`
            : str;
        })
        .join(',')
    ).join('\n');
    const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(`${headers}\n${rows}`);
    const link = document.createElement('a');
    link.setAttribute('href', csvContent);
    link.setAttribute('download', `smartmess_records_page_${currentPage}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadToast(true);
    setTimeout(() => setDownloadToast(false), 3000);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <Database className="w-5 h-5 text-[#16865B]" />
            Dataset Explorer
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              Live FastAPI Query: /api/data/records
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            Query and filter 1,000 synthetic mess observations stored on backend with multi-dimensional criteria.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchRecords}
            disabled={isLoading}
            className="p-2 rounded-lg bg-white border border-[#E4EAE5] text-[#77847C] hover:text-[#16865B] transition-colors cursor-pointer shadow-xs"
            title="Refresh records"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#16865B]' : ''}`} />
          </button>
          <button
            onClick={handleDownloadCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#16865B] hover:bg-[#126E4A] text-white transition-colors cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            Export Page CSV
          </button>
        </div>
      </div>

      {/* Download Toast Notification */}
      {downloadToast && (
        <div className="p-3 rounded-lg bg-[#E9F6EE] border border-[#C5E5D0] text-[#16865B] text-xs flex items-center gap-2 shadow-xs animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-[#16865B] shrink-0" />
          <span>
            Exported current view rows to CSV successfully.
          </span>
        </div>
      )}

      {/* Dataset Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-white border border-[#E4EAE5] shadow-xs">
          <span className="text-[11px] font-medium text-[#77847C] uppercase tracking-wider">
            Total Dataset Records
          </span>
          <div className="text-xl font-bold font-mono text-[#25332D] mt-1">
            {totalRecords.toLocaleString()}
          </div>
          <span className="text-[10px] text-[#77847C]">From smartmess_sample.csv</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E4EAE5] shadow-xs">
          <span className="text-[11px] font-medium text-[#77847C] uppercase tracking-wider">
            Filtered Matches
          </span>
          <div className="text-xl font-bold font-mono text-[#16865B] mt-1">
            {filteredCount.toLocaleString()}
          </div>
          <span className="text-[10px] text-[#77847C]">Active filter results</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E4EAE5] shadow-xs">
          <span className="text-[11px] font-medium text-[#77847C] uppercase tracking-wider">
            Current Page
          </span>
          <div className="text-xl font-bold font-mono text-[#D97706] mt-1">
            {currentPage} <span className="text-xs font-normal text-[#77847C]">/ {totalPages}</span>
          </div>
          <span className="text-[10px] text-[#77847C]">{pageSize} rows per page</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E4EAE5] shadow-xs">
          <span className="text-[11px] font-medium text-[#77847C] uppercase tracking-wider">
            FastAPI Backend Status
          </span>
          <div className="text-base font-bold font-mono text-[#16865B] mt-1 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#16865B] animate-pulse"></span>
            Online
          </div>
          <span className="text-[10px] text-[#77847C]">Port 8000 Connected</span>
        </div>
      </div>

      {/* Search & Multi-Filter Controls */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] p-4 space-y-3 shadow-xs">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#77847C]" />
            <input
              type="text"
              placeholder="Search keyword (e.g. Biryani, Rice, Rain, Saturday, REC-002)..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#25332D] placeholder-[#77847C] focus:outline-none focus:border-[#16865B] focus:bg-white transition-colors"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Meal Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Meal:</span>
              <select
                value={mealFilter}
                onChange={(e) => {
                  setMealFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Meals</option>
                <option value="breakfast">Breakfast</option>
                <option value="lunch">Lunch</option>
                <option value="dinner">Dinner</option>
              </select>
            </div>

            {/* Menu Category Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Menu:</span>
              <select
                value={menuFilter}
                onChange={(e) => {
                  setMenuFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Menus</option>
                <option value="continental_light">Light / Continental</option>
                <option value="rice_grains">Rice & Grains</option>
                <option value="roti_breads">Roti & Breads</option>
                <option value="curry_dal">Curry & Dal</option>
                <option value="special_feast">Special Feast</option>
              </select>
            </div>

            {/* Weather Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Weather:</span>
              <select
                value={weatherFilter}
                onChange={(e) => {
                  setWeatherFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Weather</option>
                <option value="clear">Clear</option>
                <option value="overcast">Overcast</option>
                <option value="rainy">Rainy</option>
                <option value="extreme_heat">Extreme Heat</option>
                <option value="cold">Cold</option>
              </select>
            </div>

            {/* Weekday Filter */}
            <div className="flex items-center gap-1.5 bg-[#F8FAF8] border border-[#E4EAE5] rounded-lg px-2.5 py-1.5 text-xs text-[#25332D]">
              <span className="text-[#77847C] text-[11px]">Day:</span>
              <select
                value={dayFilter}
                onChange={(e) => {
                  setDayFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-[#25332D] font-medium text-xs focus:outline-none cursor-pointer"
              >
                <option value="All">All Days</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
              </select>
            </div>

            {(searchTerm || mealFilter !== 'All' || menuFilter !== 'All' || weatherFilter !== 'All' || dayFilter !== 'All') && (
              <button
                onClick={handleResetFilters}
                className="px-2.5 py-1.5 rounded-lg bg-[#E4EAE5] hover:bg-[#D2DDD4] text-[#25332D] text-xs transition-colors cursor-pointer"
              >
                Reset
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Dataset Table */}
      <div className="rounded-xl bg-white border border-[#E4EAE5] shadow-xs overflow-hidden">
        {error ? (
          <div className="p-8">
            <ErrorState
              title="Failed to Load Dataset Records"
              message={error}
              onRetry={fetchRecords}
            />
          </div>
        ) : isLoading ? (
          <div className="p-6">
            <LoadingSkeleton type="table" />
          </div>
        ) : records.length === 0 ? (
          <div className="p-8">
            <EmptyState
              title="No Matching Records Found"
              description="No synthetic observations matched your filter parameters. Try clearing your filters."
              actionLabel="Reset Filters"
              onAction={handleResetFilters}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#E4EAE5] bg-[#F8FAF8] text-[#77847C] uppercase text-[11px] font-medium tracking-wider">
                  <th
                    onClick={() => handleSort('date')}
                    className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Row ID & Date</span>
                      <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Service & Day</th>
                  <th className="py-3 px-4">Menu Category</th>
                  <th
                    onClick={() => handleSort('expected_attendance')}
                    className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Attendance</span>
                      <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('food_prepared_kg')}
                    className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Prep (kg)</span>
                      <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('food_waste_kg')}
                    className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Waste (kg)</span>
                      <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('food_waste_pct')}
                    className="py-3 px-4 cursor-pointer hover:text-[#25332D] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Waste %</span>
                      <ArrowUpDown className="w-3 h-3 text-[#77847C]" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Weather Condition</th>
                  <th className="py-3 px-4 text-right">Batch Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF2EF]">
                {records.map((row) => (
                  <tr key={row.record_id} className="hover:bg-[#F8FAF8] transition-colors">
                    <td className="py-3 px-4 font-mono text-[#25332D] whitespace-nowrap">
                      <span className="text-[#16865B] font-semibold">{row.record_id}</span>
                      <div className="text-[10px] text-[#77847C]">{row.date}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-semibold text-[#25332D] capitalize">{row.meal_type}</span>
                      <div className="text-[10px] text-[#77847C]">{row.weekday}</div>
                    </td>
                    <td className="py-3 px-4 text-[#25332D]">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-[#F8FAF8] text-[#25332D] border border-[#E4EAE5]">
                        {row.menu_category.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#25332D] whitespace-nowrap font-medium">
                      {row.expected_attendance}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#25332D] whitespace-nowrap">
                      {row.food_prepared_kg} kg
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-[#B91C1C] whitespace-nowrap">
                      {row.food_waste_kg} kg
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold whitespace-nowrap">
                      <span
                        className={
                          row.food_waste_pct > 18
                            ? 'text-[#B91C1C]'
                            : row.food_waste_pct > 12
                            ? 'text-[#D97706]'
                            : 'text-[#16865B]'
                        }
                      >
                        {row.food_waste_pct}%
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="capitalize text-[#77847C] text-xs">{row.weather_condition}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#25332D] whitespace-nowrap">
                      ₹{row.total_prepared_cost.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Controls */}
        <div className="p-3 bg-[#F8FAF8] border-t border-[#E4EAE5] flex items-center justify-between text-xs px-5">
          <span className="text-[#77847C]">
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredCount)} of {filteredCount} entries
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1 || isLoading}
              className="p-1.5 rounded-lg border border-[#E4EAE5] text-[#77847C] hover:text-[#25332D] hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer bg-white shadow-2xs"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono text-[#25332D] text-xs px-2 font-medium">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages || isLoading}
              className="p-1.5 rounded-lg border border-[#E4EAE5] text-[#77847C] hover:text-[#25332D] hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer bg-white shadow-2xs"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
