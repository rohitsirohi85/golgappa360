import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  searchCelestialObjects,
  POPULAR_SUGGESTIONS,
  SEARCH_CATEGORIES,
  getRecentSearches,
  addRecentSearch,
  clearRecentSearches,
  removeRecentSearch,
  dispatchCelestialNavigation,
} from '../../services/searchService.js';
import {
  CATEGORY_LABELS,
  CATEGORY_SYMBOLS,
  getCelestialObjectById,
} from '../../data/celestialObjects.js';

/**
 * UniversalSearch — Global Astronomical Search Interface
 * 
 * Used across the main Navbar HUD, Universe Map canvas, and standalone discovery overlays.
 * Features:
 * - Instant autocomplete & typo-tolerant fuzzy matching
 * - Scientific aliases (e.g. Sol, Luna, Sgr A*, Dog Star, North Star)
 * - Category filter tabs (ALL, STARS, PLANETS, CONSTELLATIONS, NEBULAE, BLACK HOLES, GALAXIES, OTHER)
 * - Keyboard navigation (Hotkey '/', Escape, ArrowUp, ArrowDown, Enter)
 * - Recent search history (localStorage with clear button)
 * - Educational quick suggestions on empty state
 * - Smooth camera flight & global routing
 */
export default function UniversalSearch({
  variant = 'map', // 'map' | 'navbar' | 'modal'
  isOpen = false,
  onClose = null,
  onSelect = null,
  className = '',
  placeholder = 'Search the universe...',
}) {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [isDropdownOpen, setIsDropdownOpen] = useState(isOpen);
  const [activeIndex, setActiveIndex] = useState(0);
  const [recentSearches, setRecentSearches] = useState(() => getRecentSearches());

  const containerRef = useRef(null);
  const inputRef = useRef(null);
  const resultsListRef = useRef(null);

  // Sync external open state if provided
  useEffect(() => {
    if (variant === 'modal' || variant === 'navbar') {
      setIsDropdownOpen(isOpen);
      if (isOpen) {
        setTimeout(() => inputRef.current?.focus(), 50);
        setRecentSearches(getRecentSearches());
      }
    }
  }, [isOpen, variant]);

  // Global '/' keyboard shortcut to trigger search
  useEffect(() => {
    const handleGlobalKeyDown = (e) => {
      // Ignore if user is already typing in an input or textarea
      const targetTag = (e.target.tagName || '').toLowerCase();
      const isInput = targetTag === 'input' || targetTag === 'textarea' || e.target.isContentEditable;

      if (e.key === '/' && !isInput) {
        e.preventDefault();
        setIsDropdownOpen(true);
        setTimeout(() => {
          inputRef.current?.focus();
          inputRef.current?.select();
        }, 30);
      } else if (e.key === 'Escape' && isDropdownOpen) {
        handleClose();
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [isDropdownOpen]);

  // Close dropdown on outside click (for embedded map variant)
  useEffect(() => {
    if (variant === 'modal') return;

    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [variant]);

  // Query search results
  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    return searchCelestialObjects(query, activeCategory, 10);
  }, [query, activeCategory]);

  // Reset active index when query or results change
  useEffect(() => {
    setActiveIndex(0);
  }, [query, activeCategory]);

  // Scroll active item into view
  useEffect(() => {
    if (resultsListRef.current && searchResults.length > 0) {
      const activeEl = resultsListRef.current.children[activeIndex];
      if (activeEl) {
        activeEl.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [activeIndex, searchResults]);

  const handleClose = () => {
    setIsDropdownOpen(false);
    if (onClose) onClose();
  };

  const handleSelect = useCallback(
    (item) => {
      // Find full object if item is partial
      const fullObj = getCelestialObjectById(item.id) || item;
      addRecentSearch(fullObj);
      setRecentSearches(getRecentSearches());

      if (onSelect) {
        onSelect(fullObj);
      } else {
        dispatchCelestialNavigation(fullObj);
      }

      setQuery('');
      handleClose();
    },
    [onSelect]
  );

  const handleClearRecent = (e) => {
    e.stopPropagation();
    clearRecentSearches();
    setRecentSearches([]);
  };

  const handleRemoveRecentItem = (e, id) => {
    e.stopPropagation();
    removeRecentSearch(id);
    setRecentSearches(getRecentSearches());
  };

  // Keyboard navigation inside input
  const handleInputKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!isDropdownOpen) {
        setIsDropdownOpen(true);
        return;
      }
      if (searchResults.length > 0) {
        setActiveIndex((prev) => (prev + 1) % searchResults.length);
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (searchResults.length > 0) {
        setActiveIndex((prev) => (prev - 1 + searchResults.length) % searchResults.length);
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (searchResults.length > 0 && searchResults[activeIndex]) {
        handleSelect(searchResults[activeIndex]);
      } else if (query.trim()) {
        const firstMatch = searchCelestialObjects(query, 'ALL', 1)[0];
        if (firstMatch) {
          handleSelect(firstMatch);
        }
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      handleClose();
    }
  };

  // -------------------------------------------------------------
  // VARIANT: MODAL OVERLAY (Fullscreen on mobile / dialog on desktop)
  // -------------------------------------------------------------
  if (variant === 'modal') {
    if (!isOpen) return null;

    return (
      <div
        className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-[#020308]/85 backdrop-blur-xl animate-in fade-in duration-200"
        onClick={handleClose}
      >
        <div
          ref={containerRef}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-2xl bg-[#030612]/95 border border-white/15 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150"
        >
          {/* Header & Search Input */}
          <div className="relative p-4 border-b border-white/10 flex items-center gap-3">
            <span className="text-cyan-400 text-lg">✦</span>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleInputKeyDown}
              placeholder={placeholder}
              className="w-full bg-transparent text-white text-base sm:text-lg placeholder:text-slate-500 focus:outline-none font-sans"
              autoFocus
            />
            {query ? (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  inputRef.current?.focus();
                }}
                className="p-1 rounded text-slate-400 hover:text-white"
                aria-label="Clear query"
              >
                ✕
              </button>
            ) : (
              <span className="hidden sm:inline-block px-1.5 py-0.5 rounded border border-white/15 bg-white/5 text-[10px] font-mono text-slate-400">
                ESC
              </span>
            )}
            <button
              type="button"
              onClick={handleClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors ml-1"
              aria-label="Close search"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 px-4 py-2 border-b border-white/5 overflow-x-auto no-scrollbar bg-white/[0.01]">
            {SEARCH_CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1 rounded-full text-xs font-mono whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(56,189,248,0.3)]'
                      : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Body Content */}
          <div className="overflow-y-auto flex-grow p-3 divide-y divide-white/5">
            {/* If Query entered: show results */}
            {query.trim() ? (
              searchResults.length > 0 ? (
                <ul ref={resultsListRef} className="space-y-1">
                  {searchResults.map((item, idx) => {
                    const isActive = idx === activeIndex;
                    const symbol = item.category ? CATEGORY_SYMBOLS[item.category] || '●' : '●';
                    const categoryLabel = item.category
                      ? CATEGORY_LABELS[item.category] || item.category
                      : 'Object';

                    return (
                      <li key={item.id}>
                        <button
                          type="button"
                          onClick={() => handleSelect(item)}
                          onMouseEnter={() => setActiveIndex(idx)}
                          className={`w-full text-left px-3.5 py-2.5 rounded-xl flex items-center justify-between transition-colors ${
                            isActive
                              ? 'bg-cyan-500/15 border border-cyan-400/30 text-white'
                              : 'hover:bg-white/5 text-slate-300 border border-transparent'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <span
                              className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-sm bg-white/5 border border-white/10 flex-shrink-0"
                              style={{ color: item.colorHex || '#38bdf8' }}
                            >
                              {symbol}
                            </span>
                            <div className="truncate">
                              <div className="text-sm font-semibold text-white font-display flex items-center gap-2">
                                <span>{item.name}</span>
                                {item.commonName && item.commonName !== item.name && (
                                  <span className="text-xs text-slate-400 font-normal truncate">
                                    ({item.commonName})
                                  </span>
                                )}
                              </div>
                              <div className="text-xs font-mono text-slate-400 truncate">
                                {item.isConstellation
                                  ? `${item.bestViewingSeason || 'Visible worldwide'} · Constellation Pattern`
                                  : `${item.constellation || item.relatedConstellation || 'Deep Space'} · ${
                                      item.subtype || categoryLabel
                                    } ${item.distance ? `· ${item.distance}` : ''}`}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 border border-white/10 text-cyan-300">
                              {item.isConstellation ? 'Constellation' : item.subtype || categoryLabel}
                            </span>
                            <span className="text-slate-500 text-xs">↵</span>
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <div className="py-12 text-center">
                  <div className="text-3xl mb-2">🔭</div>
                  <h4 className="text-white font-display text-sm font-semibold mb-1">
                    No celestial target found for "{query}"
                  </h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4 font-mono">
                    Try searching for Sirius, Sagittarius A*, Betelgeuse, Orion, Mars, or Andromeda Galaxy.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {POPULAR_SUGGESTIONS.slice(0, 4).map((sug) => (
                      <button
                        key={sug.id}
                        type="button"
                        onClick={() => {
                          const obj = getCelestialObjectById(sug.id);
                          if (obj) handleSelect(obj);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-xs font-mono text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400/40 transition-colors"
                      >
                        {sug.name}
                      </button>
                    ))}
                  </div>
                </div>
              )
            ) : (
              // Empty query state: Recent Searches & Popular Suggestions
              <div className="space-y-5 p-2">
                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                      <span className="flex items-center gap-1.5">
                        <span>🕒</span> Recent Discoveries
                      </span>
                      <button
                        type="button"
                        onClick={handleClearRecent}
                        className="text-xs text-slate-500 hover:text-amber-300 transition-colors"
                      >
                        Clear All
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {recentSearches.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => {
                            const fullObj = getCelestialObjectById(item.id) || item;
                            handleSelect(fullObj);
                          }}
                          className="group inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/10 hover:border-cyan-400/40 hover:bg-cyan-500/10 cursor-pointer transition-all"
                        >
                          <span
                            className="text-xs font-bold"
                            style={{ color: item.colorHex || '#38bdf8' }}
                          >
                            ●
                          </span>
                          <span className="text-xs font-medium text-slate-200 group-hover:text-white">
                            {item.name}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => handleRemoveRecentItem(e, item.id)}
                            className="text-slate-500 hover:text-white text-xs pl-1"
                            title="Remove from history"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Popular Celestial Suggestions */}
                <div>
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                    ✦ Popular Celestial Destinations
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {POPULAR_SUGGESTIONS.map((sug) => (
                      <button
                        key={sug.id}
                        type="button"
                        onClick={() => {
                          const obj = getCelestialObjectById(sug.id);
                          if (obj) handleSelect(obj);
                        }}
                        className="text-left px-3.5 py-2.5 rounded-xl bg-white/[0.02] border border-white/8 hover:border-cyan-400/40 hover:bg-cyan-500/10 flex items-center justify-between transition-all group"
                      >
                        <div>
                          <div className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors">
                            {sug.name}
                          </div>
                          <div className="text-[10px] font-mono text-slate-400">{sug.label}</div>
                        </div>
                        <span className="text-slate-500 group-hover:text-cyan-400 text-xs transition-colors">
                          →
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer telemetry */}
          <div className="px-4 py-2 border-t border-white/10 flex items-center justify-between text-[10px] font-mono text-slate-500 bg-[#020308]/60">
            <div className="flex items-center gap-3">
              <span>↑↓ Navigate</span>
              <span>↵ Select</span>
              <span>ESC Close</span>
            </div>
            <span>STELLAR UNIVERSAL SEARCH 2.0</span>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VARIANT: NAVBAR COMPACT PILL (With desktop trigger & shortcut)
  // -------------------------------------------------------------
  if (variant === 'navbar') {
    return (
      <div className={`relative ${className}`}>
        {/* Desktop trigger pill */}
        <button
          type="button"
          onClick={() => setIsDropdownOpen(true)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 hover:border-cyan-400/40 text-slate-300 hover:text-white transition-all text-xs font-sans shadow-sm group"
          aria-label="Open celestial search"
        >
          <span className="text-slate-400 group-hover:text-cyan-300 transition-colors">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </span>
          <span className="text-slate-400 group-hover:text-slate-200">{placeholder}</span>
          <kbd className="hidden lg:inline-flex items-center justify-center px-1.5 py-0.5 rounded border border-white/15 bg-white/5 text-[10px] font-mono text-slate-400 group-hover:text-cyan-300">
            /
          </kbd>
        </button>

        {/* Modal display when open */}
        {isDropdownOpen && (
          <UniversalSearch
            variant="modal"
            isOpen={isDropdownOpen}
            onClose={() => setIsDropdownOpen(false)}
            onSelect={handleSelect}
            placeholder={placeholder}
          />
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // VARIANT: MAP HUD EMBEDDED
  // -------------------------------------------------------------
  return (
    <div ref={containerRef} className={`relative select-none ${className}`}>
      {/* Search Input Box */}
      <div className="relative flex items-center">
        {/* Search Icon */}
        <span className="absolute left-3 text-slate-400 pointer-events-none">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2.5"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </span>

        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsDropdownOpen(true);
          }}
          onFocus={() => setIsDropdownOpen(true)}
          onKeyDown={handleInputKeyDown}
          placeholder={placeholder}
          aria-label="Search celestial objects"
          className="w-full sm:w-72 lg:w-80 pl-9 pr-14 py-1.5 text-xs font-sans text-slate-100 bg-[#020308]/85 backdrop-blur-md rounded-lg border border-white/10 hover:border-white/20 focus:border-cyan-400/80 focus:bg-[#020308] focus:outline-none focus:ring-1 focus:ring-cyan-400/50 placeholder:text-slate-500 shadow-[0_4px_20px_rgba(0,0,0,0.6)] transition-all"
        />

        {/* Right shortcut or clear button */}
        <div className="absolute right-2.5 flex items-center gap-1">
          {query ? (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setIsDropdownOpen(false);
                inputRef.current?.focus();
              }}
              aria-label="Clear celestial search"
              className="text-slate-400 hover:text-white p-0.5 rounded transition-colors"
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          ) : (
            <kbd className="hidden sm:inline-flex items-center px-1 py-0.2 rounded border border-white/15 bg-white/5 text-[9px] font-mono text-slate-400">
              /
            </kbd>
          )}
        </div>
      </div>

      {/* Embedded Dropdown Menu */}
      {isDropdownOpen && (
        <div className="absolute left-0 right-0 sm:right-auto sm:w-88 lg:w-96 mt-1.5 bg-[#030612]/95 backdrop-blur-xl border border-white/15 rounded-xl shadow-[0_12px_40px_rgba(0,0,0,0.9)] overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
          {/* Quick Categories filter */}
          <div className="px-3 py-1.5 border-b border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            <span>CELESTIAL TARGETS</span>
            <span className="text-cyan-400">
              {query.trim() ? `${searchResults.length} FOUND` : 'INDEX ONLINE'}
            </span>
          </div>

          {/* Category Tabs for map embedded view */}
          <div className="flex items-center gap-1 px-2.5 py-1.5 border-b border-white/5 overflow-x-auto no-scrollbar bg-white/[0.01]">
            {SEARCH_CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-2 py-0.5 rounded-md text-[10px] font-mono whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                      : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Results List */}
          {query.trim() ? (
            searchResults.length > 0 ? (
              <ul ref={resultsListRef} className="max-h-72 overflow-y-auto divide-y divide-white/5 py-1">
                {searchResults.map((item, idx) => {
                  const isActive = idx === activeIndex;
                  const symbol = item.category ? CATEGORY_SYMBOLS[item.category] || '●' : '●';
                  const categoryLabel = item.category
                    ? CATEGORY_LABELS[item.category] || item.category
                    : 'Object';

                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => handleSelect(item)}
                        onMouseEnter={() => setActiveIndex(idx)}
                        className={`w-full text-left px-3 py-2 flex items-center justify-between transition-colors ${
                          isActive ? 'bg-cyan-500/15 text-white' : 'hover:bg-white/5 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span
                            className="font-bold text-xs flex-shrink-0"
                            style={{ color: item.colorHex || '#38bdf8' }}
                          >
                            {symbol}
                          </span>
                          <div className="truncate">
                            <div className="text-xs font-semibold font-display text-white truncate">
                              {item.name}
                            </div>
                            <div className="text-[10px] font-mono text-slate-400 truncate">
                              {item.isConstellation
                                ? (item.commonName ? `“${item.commonName}” · Constellation` : 'Constellation Region')
                                : `${item.constellation || item.relatedConstellation || 'Deep Space'} · ${item.subtype || categoryLabel}`}
                            </div>
                          </div>
                        </div>

                        <div className="flex-shrink-0 ml-2 text-right">
                          <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-mono font-medium bg-white/5 border border-white/10 text-cyan-300">
                            {item.isConstellation ? 'Constellation' : (item.spectralClass || categoryLabel)}
                          </span>
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <div className="p-3 text-center">
                <p className="text-xs text-slate-400">No celestial target found for "{query}"</p>
                <p className="text-[10px] font-mono text-slate-500 mt-1">
                  Try Sirius, Sagittarius A*, Mars, Pleiades, or Orion
                </p>
              </div>
            )
          ) : (
            // Empty query dropdown state: Recent Searches & Suggestions
            <div className="p-2 space-y-3 max-h-72 overflow-y-auto">
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between text-[9px] font-mono uppercase tracking-wider text-slate-400 mb-1 px-1">
                    <span>Recent Searches</span>
                    <button
                      type="button"
                      onClick={handleClearRecent}
                      className="text-[9px] text-slate-500 hover:text-amber-300"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {recentSearches.slice(0, 4).map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          const fullObj = getCelestialObjectById(item.id) || item;
                          handleSelect(fullObj);
                        }}
                        className="text-[11px] px-2 py-0.5 rounded bg-white/5 hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-400/30 text-slate-300 hover:text-white transition-colors"
                      >
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <div className="text-[9px] font-mono uppercase tracking-wider text-slate-400 mb-1 px-1">
                  ✦ Suggestions
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {POPULAR_SUGGESTIONS.map((sug) => (
                    <button
                      key={sug.id}
                      type="button"
                      onClick={() => {
                        const obj = getCelestialObjectById(sug.id);
                        if (obj) handleSelect(obj);
                      }}
                      className="text-left px-2 py-1.5 rounded-lg bg-white/[0.02] hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-400/30 text-slate-300 hover:text-white transition-all truncate"
                    >
                      <div className="text-[11px] font-medium truncate">{sug.name}</div>
                      <div className="text-[9px] font-mono text-slate-500 truncate">{sug.label}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
