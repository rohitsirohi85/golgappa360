# EV SMART — iPhone Mobile User Experience & Operational Guide

**App Release:** `EV-SMART-FINAL-RC1`  
**Target Device:** Apple iPhone (iOS Safari & Standalone PWA)  
**Classification:** User Guide & Demonstration Manual  

---

## 1. Introduction

EV SMART provides EV drivers with an intuitive, responsive mobile application for finding stations, reserving charging slots, monitoring live telemetry during charging, and managing automated billing.

This guide walks through every primary user flow on an Apple iPhone.

```
┌────────────────────────────────────────────────────────┐
│                   EV SMART IPHONE FLOW                 │
│                                                        │
│   [ 1. Discovery ] ──► [ 2. Reservation ] ──► [ 3. QR Check-In ]
│          │                                            │
│          ▼                                            ▼
│   Interactive Map                                Live Session Screen
│   Real-time Slots                                (kW, kWh, SoC, Temp)
│                                                       │
│   [ 5. History & Invoicing ] ◄── [ 4. Session Complete ]
└────────────────────────────────────────────────────────┘
```

---

## 2. Step-by-Step User Journey

### 2.1 Launch & Authentication
1. **Launch:** Tap the **EV Smart** icon on your iPhone home screen (or navigate to `http://192.168.29.23:5173` in Safari).
2. **Splash & Welcome Screen:** Displays the brand identity and tagline: *"Charge Smarter. Drive Further."*
3. **Login Options:**
   - **Demo Quick Access:** Tap **"Sign in as Demo Driver"** for instant 1-tap authentication.
   - **Standard Credentials:** Enter your email (`driver@evsmart.com`) and password (`password123`).
   - **New Registration:** Tap **Register** to create a driver account.

---

### 2.2 Finding & Selecting a Charging Station
1. **Interactive Station Map:**
   - Visual map displays nearby charging hubs with color-coded availability pins:
     - 🟢 **Green:** Available slots ready for immediate charging.
     - 🟡 **Yellow:** High demand / limited slots remaining.
     - 🔴 **Red:** All chargers currently occupied or reserved.
2. **Station Search & Filtering:**
   - Type location names in the search bar (e.g., "Tech Park", "City Center").
   - Filter by connector standard: **CCS2 (DC Fast)**, **Type 2 (AC Fast)**, or **CHAdeMO**.
3. **Station Details:**
   - Tap any station card to expand:
     - Full address and distance in kilometers.
     - Total number of charging bays and live availability (e.g., `2 / 4 Available`).
     - Power capacity (e.g., `60 kW DC Fast`).
     - Real-time tariff pricing (e.g., `₹12.50 / kWh`).

---

### 2.3 Reserving a Charging Slot
1. On the station detail sheet, tap **"Reserve a Slot"**.
2. Select your vehicle from your saved garage (e.g., *Tata Nexon EV* or *MG ZS EV*).
3. Select your preferred charging bay and start time.
4. Tap **"Confirm Reservation"**.
5. The charger status updates instantly in real time across the entire network to **"Reserved"**.

---

### 2.4 Charger Check-In (QR Code Scanning)
1. Upon arriving at the physical charging bay:
2. Tap the blue **"Scan QR to Charge"** button on the mobile home screen.
3. Align your iPhone camera with the QR code printed on the charger fascia (e.g., `CH-01`).
4. Alternatively, tap **"Manual Check-In"** and enter the charger ID (`CH-01`).
5. The hardware locks the connector pin and initiates the safety interlock check.

---

### 2.5 Live Charging Session Screen
Once charging commences, the app automatically transitions to the **Active Charging Dashboard**:

```
 ┌───────────────────────────────────────────────┐
 │                   CH-01                       │
 │           Fast DC Charger — Bay 2             │
 │                                               │
 │                     78%                       │
 │              [=== BATTERY SoC ===]            │
 │                                               │
 │  ⚡ Power: 48.2 kW     ⏱️ Duration: 00:24:18  │
 │  🔋 Energy: 18.4 kWh   🌡️ Cable Temp: 38.2°C  │
 │  💵 Current Cost: ₹230 🔌 Voltage: 395 V      │
 │                                               │
 │       [ 🛑 STOP CHARGING & PAY ]              │
 └───────────────────────────────────────────────┘
```

- **Live Animated Circular Gauge:** Visualizes battery State-of-Charge (SoC) increasing in real time.
- **Dynamic Telemetry:** Instantaneous updates delivered via WebSocket:
  - **Power Delivered:** Measured in kilowatts (kW).
  - **Energy Consumed:** Accrued kilowatt-hours (kWh).
  - **Hardware Temperature:** Monitored continuously for thermal safety.
  - **Accrued Cost:** Calculated based on the active station tariff.

---

### 2.6 Ending Session & Digital Invoice
1. When your vehicle has reached desired charge or when you choose to stop:
2. Tap the red **"Stop Charging"** button.
3. A confirmation prompt appears to prevent accidental touches. Tap **"Confirm Stop"**.
4. The backend concludes the hardware session, releases the connector lock, and generates a finalized digital receipt.
5. **Session Summary Modal:**
   - Duration of charge.
   - Total energy delivered (kWh).
   - Peak power achieved (kW).
   - Base energy charges + taxes.
   - Net bill amount.
6. Tap **"Download PDF Invoice"** to save or share your itemized receipt.

---

### 2.7 Driver Profile & Presentation Controls
Navigate to the **Profile** tab in the bottom navigation bar to access:
- **Vehicle Garage:** Add and manage electric vehicles.
- **Charging History:** Browse historical invoices and telemetry traces.
- **Presentation Mode:** Turn on high-contrast, large-font layout for stage presentations.
- **Clean Screenshot Mode:** Hide all developer debug notices for pristine documentation screenshots.

---

## 3. Best Practices for Mobile Demonstrations

1. **Keep Safari in Standalone Mode:** Always launch the app from the Home Screen PWA icon for the cleanest presentation without browser navigation chrome.
2. **Prevent iPhone Sleep:** Set Auto-Lock in iOS Settings (`Settings -> Display & Brightness -> Auto-Lock -> Never`) so the screen remains on during live telemetry demonstrations.
3. **Simulating Live Charging:** The backend simulator delivers real-time updates every 2 seconds. Watch the battery gauge and energy counters tick upward smoothly on your iPhone!
