import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { IntroSection } from './components/IntroSection';
import { ProgramsSection } from './components/ProgramsSection';
import { InstructorsSection } from './components/InstructorsSection';
import { StudioSection } from './components/StudioSection';
import { GallerySection } from './components/GallerySection';
import { FAQSection } from './components/FAQSection';
import { TrialCTA } from './components/TrialCTA';
import { Footer } from './components/Footer';
import { TrialBookingModal } from './components/TrialBookingModal';

export const MotionIsArtHome = () => {
  const [trialModalOpen, setTrialModalOpen] = useState(false);
  const [initialProgramForTrial, setInitialProgramForTrial] = useState(null);

  const handleOpenTrial = (programId = null) => {
    setInitialProgramForTrial(programId);
    setTrialModalOpen(true);
  };

  const handleCloseTrial = () => {
    setTrialModalOpen(false);
    setInitialProgramForTrial(null);
  };

  return (
    <div className="min-h-screen bg-[#0B0B0F] text-[#F5F3F8] selection:bg-[#8B5CF6]/30 selection:text-[#F5F3F8]">
      {/* Navigation */}
      <Navbar onOpenTrial={() => handleOpenTrial()} />

      {/* Main Page Flow */}
      <main id="main-content">
        {/* Hero Section with Signature Motion Field */}
        <HeroSection onOpenTrial={() => handleOpenTrial()} />

        {/* Editorial Statement & Philosophy Introduction */}
        <IntroSection onOpenTrial={() => handleOpenTrial()} />

        {/* Dance Programs Preview (5 Disciplines) */}
        <ProgramsSection onOpenTrial={(progId) => handleOpenTrial(progId)} />

        {/* The People / Master Faculty Profiles */}
        <InstructorsSection onOpenTrial={() => handleOpenTrial()} />

        {/* The Space / Studio Facility & Acoustics */}
        <StudioSection onOpenTrial={() => handleOpenTrial()} />

        {/* Movement Photography Gallery & Accessible Lightbox */}
        <GallerySection />

        {/* FAQ Section */}
        <FAQSection onOpenTrial={() => handleOpenTrial()} />

        {/* Pre-Footer Trial Class Call-To-Action */}
        <TrialCTA onOpenTrial={() => handleOpenTrial()} />
      </main>

      {/* Footer */}
      <Footer onOpenTrial={() => handleOpenTrial()} />

      {/* Interactive Trial Class Booking Voucher Modal */}
      <TrialBookingModal
        isOpen={trialModalOpen}
        onClose={handleCloseTrial}
        initialProgramId={initialProgramForTrial}
      />
    </div>
  );
};

export default MotionIsArtHome;
