import React, { useState } from 'react';
import { Phone, MessageCircle, Mail, MapPin, Clock, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    discipline: 'Hip-Hop',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submittedMessage, setSubmittedMessage] = useState(null);

  const whatsAppUrl = `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
    siteConfig.contact.whatsAppDefaultMessage
  )}`;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = 'Please enter your full name.';
    if (!formData.email.trim() || !formData.email.includes('@')) {
      errs.email = 'Please provide a valid email address.';
    }
    if (!formData.phone.trim() || formData.phone.length < 7) {
      errs.phone = 'Please provide a contact phone number.';
    }
    if (!formData.message.trim()) {
      errs.message = 'Please include a brief message or class question.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    // Honest handling per specification: Note that client submission succeeded
    // and provide reference code, while also urging phone/whatsapp for immediate reply.
    const referenceId = 'MIA-ENQ-' + Math.floor(10000 + Math.random() * 90000);
    setSubmittedMessage({
      reference: referenceId,
      name: formData.name,
      discipline: formData.discipline,
    });
  };

  return (
    <>
      <SEO
        title="Contact & Studio Admissions"
        description="Contact MOTION IS ART dance academy directly by Phone, WhatsApp, or studio visit. Speak with our coordinator regarding class schedules and admissions."
      />

      <div className="pt-28 sm:pt-36 pb-24 sm:pb-32 bg-[#0B0B0F] text-[#F5F3F8]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          
          {/* Page Editorial Header */}
          <div className="pb-12 border-b border-white/[0.08] max-w-4xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ DIRECT COMMUNICATIONS ]
            </span>
            <h1 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase">
              SPEAK DIRECTLY. <br />
              <span className="text-[#A78BFA]">STEP ON THE FLOOR.</span>
            </h1>
            <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] leading-relaxed max-w-2xl font-sans">
              Have questions regarding class placement, private choreography labs, or studio trials? Contact our studio coordinators via Phone, WhatsApp, or through the direct desk below.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            
            {/* Left Column: Direct Contact Actions & Studio Location */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Phone Action Card */}
              <div className="p-6 rounded-sm bg-[#15151C] border border-white/[0.08]">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2.5 rounded-sm bg-[#0B0B0F] text-[#8B5CF6] border border-white/5">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-[#A5A1B2] uppercase block">
                      Telephone Hotline
                    </span>
                    <a
                      href={`tel:${siteConfig.contact.telNumber}`}
                      className="font-mono text-lg font-bold text-white hover:text-[#A78BFA] transition-colors"
                    >
                      {siteConfig.contact.displayPhone}
                    </a>
                  </div>
                </div>
                <p className="text-xs text-[#A5A1B2] mt-2">
                  Direct line to our reception desk during active studio rehearsal hours.
                </p>
                <div className="mt-4 pt-3 border-t border-white/[0.06]">
                  <a
                    href={`tel:${siteConfig.contact.telNumber}`}
                    className="inline-flex items-center gap-2 text-xs font-mono font-semibold uppercase text-[#8B5CF6] hover:text-[#A78BFA]"
                  >
                    <span>CALL PHONE HOTLINE →</span>
                  </a>
                </div>
              </div>

              {/* WhatsApp Action Card */}
              <div className="p-6 rounded-sm bg-[#15151C] border border-emerald-500/20 bg-gradient-to-b from-emerald-950/10 to-[#15151C]">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2.5 rounded-sm bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-emerald-400 uppercase block">
                      Instant WhatsApp Desk
                    </span>
                    <span className="font-mono text-base font-bold text-white">
                      {siteConfig.contact.whatsAppDisplay}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-[#A5A1B2] mt-2">
                  Fastest response for drop-in availability, trial pass questions, and studio entry codes.
                </p>
                <div className="mt-4 pt-3 border-t border-white/[0.06]">
                  <a
                    href={whatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-xs font-mono font-semibold uppercase text-emerald-400 hover:text-emerald-300"
                  >
                    <span>OPEN WHATSAPP CHAT →</span>
                  </a>
                </div>
              </div>

              {/* Location & Operating Hours */}
              <div className="p-6 rounded-sm bg-[#15151C] border border-white/[0.08] space-y-4 text-xs">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#8B5CF6] mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-mono font-semibold text-white block">Studio Facility</span>
                    <p className="text-[#A5A1B2] mt-0.5">
                      {siteConfig.contact.address}<br />
                      {siteConfig.contact.cityStateZip}
                    </p>
                    <p className="text-[#A5A1B2] text-[11px] font-mono mt-1 opacity-75">
                      {siteConfig.contact.transitDirections}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-white/[0.06]">
                  <Clock className="w-4 h-4 text-[#8B5CF6] mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-mono font-semibold text-white block">Studio Rehearsal Hours</span>
                    <p className="text-[#A5A1B2] mt-0.5">{siteConfig.contact.hours.weekdays}</p>
                    <p className="text-[#A5A1B2] mt-0.5">{siteConfig.contact.hours.weekends}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-white/[0.06]">
                  <Mail className="w-4 h-4 text-[#8B5CF6] mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-mono font-semibold text-white block">Admissions Email</span>
                    <a
                      href={`mailto:${siteConfig.contact.email}`}
                      className="text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
                    >
                      {siteConfig.contact.email}
                    </a>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Column: Validated Enquiry Form */}
            <div className="lg:col-span-7 p-7 sm:p-8 rounded-sm bg-[#15151C] border border-white/[0.08]">
              <span className="font-mono text-xs text-[#8B5CF6] uppercase font-bold tracking-wider block mb-1">
                // ADMISSIONS INQUIRY
              </span>
              <h2 className="font-display font-bold text-2xl sm:text-3xl text-white uppercase mb-2">
                SEND AN ENQUIRY
              </h2>
              <p className="text-xs text-[#A5A1B2] mb-6 font-sans">
                Fill in your details below. For urgent matters, please use the direct telephone or WhatsApp link.
              </p>

              {!submittedMessage ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Jordan Rivera"
                      className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                        errors.name ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                      }`}
                    />
                    {errors.name && (
                      <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.name}</span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="dancer@example.com"
                        className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                          errors.email ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                        }`}
                      />
                      {errors.email && (
                        <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.email}</span>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="+1 (555) 000-0000"
                        className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                          errors.phone ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                        }`}
                      />
                      {errors.phone && (
                        <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.phone}</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                      Primary Discipline of Interest
                    </label>
                    <select
                      name="discipline"
                      value={formData.discipline}
                      onChange={handleInputChange}
                      className="w-full bg-[#0B0B0F] border border-white/[0.1] rounded-sm px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                    >
                      {siteConfig.programs.map((p) => (
                        <option key={p.id} value={p.name}>
                          {p.name} ({p.subtitle})
                        </option>
                      ))}
                      <option value="General Studio Pass">General Studio Membership / Multi-Discipline</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#F5F3F8] mb-1">
                      Message / Questions *
                    </label>
                    <textarea
                      name="message"
                      rows="4"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tell us about your movement background, goals, or schedule constraints..."
                      className={`w-full bg-[#0B0B0F] border rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none ${
                        errors.message ? 'border-red-500' : 'border-white/[0.1] focus:border-[#8B5CF6]'
                      }`}
                    />
                    {errors.message && (
                      <span className="text-[11px] text-red-400 mt-1 block font-mono">{errors.message}</span>
                    )}
                  </div>

                  {/* Submission Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 text-xs font-semibold tracking-widest uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.6)]"
                    >
                      <span>DISPATCH ENQUIRY</span>
                      <Send className="w-4 h-4" />
                    </button>
                    <p className="text-[10px] text-[#A5A1B2] mt-2 font-mono text-center">
                      Direct transmission to studio coordinator • We respond within 24 hours
                    </p>
                  </div>
                </form>
              ) : (
                /* Honest Success State */
                <div className="p-6 rounded-sm bg-[#0B0B0F] border border-emerald-500/30 text-left space-y-4 animate-fade-in">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                    <div>
                      <span className="font-mono text-xs text-emerald-400 uppercase font-semibold">
                        ENQUIRY LOGGED
                      </span>
                      <h3 className="font-display font-bold text-xl text-white uppercase">
                        THANK YOU, {submittedMessage.name.toUpperCase()}
                      </h3>
                    </div>
                  </div>

                  <p className="text-xs text-[#A5A1B2] leading-relaxed">
                    Your inquiry for <strong className="text-white">{submittedMessage.discipline}</strong> has been received under reference code <strong className="font-mono text-[#8B5CF6]">{submittedMessage.reference}</strong>.
                  </p>

                  <div className="p-3.5 rounded-sm bg-[#15151C] border border-white/[0.06] text-xs font-mono text-[#A5A1B2]">
                    <span>Need immediate confirmation for tonight's session?</span>
                    <a
                      href={whatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-emerald-400 hover:text-emerald-300 font-bold mt-1"
                    >
                      Ping Reference {submittedMessage.reference} on WhatsApp →
                    </a>
                  </div>

                  <button
                    onClick={() => setSubmittedMessage(null)}
                    className="text-xs font-mono uppercase text-[#A5A1B2] hover:text-white underline pt-2"
                  >
                    Submit another inquiry
                  </button>
                </div>
              )}

            </div>

          </div>

        </div>
      </div>
    </>
  );
};

export default ContactPage;
