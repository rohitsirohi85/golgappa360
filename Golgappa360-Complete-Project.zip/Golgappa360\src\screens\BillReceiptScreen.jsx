import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Download,
  Share2,
  Zap,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Button } from '../components/common/Button';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const BillReceiptScreen = () => {
  const navigate = useNavigate();
  const { completedSession } = useEV();
  const { showToast } = useUI();

  const bill = completedSession || {
    bookingId: 'EV20260924001',
    stationName: 'Green Valley EV Hub',
    chargerName: 'CH-01',
    energyUsed: 18.4,
    rate: 10,
    totalAmount: 184,
  };

  const handleDownload = () => {
    showToast('Digital Invoice downloaded (PDF format simulated)', 'success');
  };

  return (
    <div className="flex flex-col min-h-full justify-between pb-6 select-none bg-gradient-to-b from-[#070B19] via-[#0A1224] to-[#050811]">
      <div>
        <Header
          title="Digital Invoice"
          showBack
          onBack={() => navigate('/home')}
          rightAction={
            <button
              onClick={() => showToast('Invoice link copied', 'info')}
              className="p-2 rounded-xl bg-[#0D1527] border border-white/10 text-slate-300 hover:text-white"
            >
              <Share2 className="w-4 h-4" />
            </button>
          }
        />

        <div className="px-4 py-4 space-y-4">
          {/* Printable Ticket Shape Invoice Card */}
          <div className="bg-[#0D162B] border border-white/15 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
            {/* Top Logo / Invoice Header */}
            <div className="flex items-start justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-[#00F5A0]/15 border border-[#00F5A0]/40 text-[#00F5A0]">
                  <Zap className="w-5 h-5 fill-[#00F5A0]" />
                </div>
                <div>
                  <h2 className="text-base font-extrabold text-white tracking-wider uppercase">
                    EV SMART
                  </h2>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Official Tax Invoice
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-semibold uppercase">
                  Paid
                </span>
                <span className="text-[10px] text-slate-400 block mt-1 font-mono">
                  {bill.completedAt || '24 Sep 2026, 04:42 PM'}
                </span>
              </div>
            </div>

            {/* Booking & Station Meta */}
            <div className="py-3.5 space-y-2 border-b border-white/10 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Booking ID:</span>
                <span className="font-mono font-bold text-[#00F5A0]">
                  {bill.bookingId}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Station:</span>
                <span className="font-semibold text-white">
                  {bill.stationName}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Charger Bay:</span>
                <span className="font-mono font-bold text-cyan-300">
                  {bill.chargerName}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Vehicle:</span>
                <span className="text-slate-200">Tesla Model 3 (60 kWh)</span>
              </div>
            </div>

            {/* Bill Line Items Table */}
            <div className="py-3.5 border-b border-dashed border-white/15 space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                <span>Description</span>
                <span>Amount</span>
              </div>

              <div className="flex justify-between items-center text-white">
                <div>
                  <p className="font-semibold">Energy Consumption</p>
                  <p className="text-[11px] text-slate-400 font-mono">
                    {bill.energyUsed} kWh @ ₹{bill.rate}/kWh
                  </p>
                </div>
                <span className="font-mono font-bold">
                  ₹{Math.round(bill.energyUsed * bill.rate)}
                </span>
              </div>

              <div className="flex justify-between items-center text-slate-300 text-xs">
                <span>Station Service & Grid Fee</span>
                <span className="font-mono text-emerald-400">₹0 (Waived)</span>
              </div>

              <div className="flex justify-between items-center text-slate-300 text-xs">
                <span>GST (0% Green Mobility)</span>
                <span className="font-mono text-slate-400">₹0.00</span>
              </div>
            </div>

            {/* Total Row */}
            <div className="pt-3.5 flex items-baseline justify-between">
              <div>
                <span className="text-xs uppercase tracking-wide text-slate-400 font-semibold block">
                  Total Paid
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  Via Demo Wallet / Card
                </span>
              </div>
              <span className="text-2xl font-extrabold text-[#00F5A0] font-mono tracking-tight drop-shadow-[0_0_12px_rgba(0,245,160,0.3)]">
                ₹{bill.totalAmount}
              </span>
            </div>

            {/* Barcode/Footer graphic */}
            <div className="mt-4 pt-3 border-t border-white/10 text-center">
              <div className="flex justify-center gap-1 opacity-40 h-7 items-center">
                {[1,3,2,4,1,2,3,1,4,2,3,1,2,4,1,3,2,1,4,2,3,1].map((w, i) => (
                  <div
                    key={i}
                    style={{ width: `${w * 2}px` }}
                    className="h-full bg-white rounded-xs"
                  />
                ))}
              </div>
              <span className="text-[9px] font-mono text-slate-500 mt-1 block">
                EV-SMART-DIGITAL-HASH-20260924-001
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="px-4 space-y-2.5">
        <Button
          size="lg"
          fullWidth
          onClick={handleDownload}
          icon={Download}
        >
          Download Receipt
        </Button>

        <Button
          variant="secondary"
          fullWidth
          onClick={() => navigate('/history')}
        >
          View Charging History
        </Button>
      </div>
    </div>
  );
};
