import React, { useState, useEffect, useCallback } from 'react';
import {
  FlaskConical,
  BrainCircuit,
  Cpu,
  BarChart3,
  Sliders,
  Layers,
  Sparkles,
  Scale,
  RefreshCw,
  PieChart as PieChartIcon,
  GitBranch,
  ShieldCheck,
  Award,
  BookOpen,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import { messApi } from '../services/messApiService';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { ErrorState } from '../components/common/ErrorState';

export const ModelLabPage = () => {
  const [modelRegistry, setModelRegistry] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Active view: 'regression' | 'classification' | 'clustering' | 'pipeline' | 'glossary'
  const [activeTab, setActiveTab] = useState('regression');
  const [selectedRegressionKey, setSelectedRegressionKey] = useState('linear_regression');
  const [selectedClassifierKey, setSelectedClassifierKey] = useState('gaussian_nb');
  const [selectedClusterId, setSelectedClusterId] = useState('cluster_1');

  const fetchMetrics = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await messApi.getModelMetrics();
      setModelRegistry(data);
    } catch (err) {
      console.error('Failed to fetch model metrics:', err);
      setError(err.message || 'Unable to connect to /api/models/metrics');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <LoadingSkeleton type="stat-grid" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <LoadingSkeleton type="chart" />
          <LoadingSkeleton type="chart" />
        </div>
      </div>
    );
  }

  if (error || !modelRegistry) {
    return (
      <div className="py-12">
        <ErrorState
          title="Model Registry Offline"
          message={error || 'Failed to load machine learning benchmark metrics from backend.'}
          onRetry={fetchMetrics}
        />
      </div>
    );
  }

  const {
    model_version,
    split_metadata,
    feature_schema,
    regression_leaderboard,
    classification_leaderboard,
    clustering_summary,
  } = modelRegistry;

  // Prepare regression chart data
  const regressionChartData = Object.entries(regression_leaderboard)
    .filter(([key]) => key !== 'best_model')
    .map(([key, item]) => ({
      key,
      name: key === 'linear_regression' ? 'Linear Regression' : key === 'decision_tree_regressor' ? 'Decision Tree' : 'KNN Regressor',
      fullName: item.model_name,
      mae: item.metrics.mae_kg,
      rmse: item.metrics.rmse_kg,
      r2: Number((item.metrics.r2_score * 100).toFixed(1)),
      mse: item.metrics.mse,
      isBest: key === regression_leaderboard.best_model?.model_key,
    }));

  // Prepare classification chart data
  const classificationChartData = Object.entries(classification_leaderboard?.models || {}).map(([key, item]) => ({
    key,
    name: key === 'logistic_regression' ? 'Logistic Reg'
      : key === 'decision_tree_classifier' ? 'Decision Tree'
      : key === 'knn_classifier' ? 'KNN'
      : key === 'gaussian_nb' ? 'Gaussian NB'
      : 'SVM (RBF)',
    fullName: item.model_name,
    accuracy: Number((item.metrics.accuracy * 100).toFixed(1)),
    precision: Number((item.metrics.precision * 100).toFixed(1)),
    recall: Number((item.metrics.recall * 100).toFixed(1)),
    f1Score: Number((item.metrics.f1_score * 100).toFixed(1)),
    isBest: key === classification_leaderboard?.best_model?.model_key,
  }));

  // Selected regression model details
  const activeRegression = regression_leaderboard[selectedRegressionKey] || regression_leaderboard.linear_regression;

  // Selected classifier details
  const activeClassifier = classification_leaderboard?.models?.[selectedClassifierKey] || classification_leaderboard?.models?.gaussian_nb;

  // Silhouette score chart data
  const silhouetteData = Object.entries(clustering_summary?.silhouette_scores_evaluated || {}).map(([k, score]) => ({
    k: `k = ${k}`,
    clusters: Number(k),
    silhouette: Number(score.toFixed(4)),
    isOptimal: Number(k) === clustering_summary.optimal_k,
  }));

  const clusterProfiles = clustering_summary?.cluster_profiles || {};

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#25332D] tracking-tight flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-[#16865B]" />
            Machine Learning Model Laboratory
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
              {model_version}
            </span>
          </h2>
          <p className="text-xs text-[#77847C] mt-0.5">
            Empirical benchmarking of candidate algorithms trained on synthetic mess telemetry without target leakage.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={fetchMetrics}
            className="p-1.5 rounded-lg text-[#77847C] hover:text-[#16865B] bg-white transition-colors border border-[#E4EAE5] cursor-pointer shadow-xs"
            title="Refresh ML metrics"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-2 text-xs text-[#25332D] bg-white border border-[#E4EAE5] px-3 py-1.5 rounded-lg shadow-xs">
            <BrainCircuit className="w-4 h-4 text-[#16865B]" />
            <span className="font-mono text-[11px]">
              Split: {split_metadata.train_records} Train / {split_metadata.test_records} Test (Seed {split_metadata.random_seed})
            </span>
          </div>
        </div>
      </div>

      {/* Disclaimers & Top Summary Banner */}
      <div className="p-3.5 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs shadow-xs">
        <div className="flex items-center gap-2 text-[#16865B]">
          <ShieldCheck className="w-4 h-4 text-[#16865B] shrink-0" />
          <span>
            <strong className="text-[#16865B]">Reproducible Pipeline:</strong> Continuous variables scaled strictly on train split. Active Serving Model: <span className="font-semibold underline">{regression_leaderboard.best_model?.model_name}</span> (MAE: {regression_leaderboard.best_model?.mae_kg} kg, R²: {regression_leaderboard.best_model?.r2_score}).
          </span>
        </div>
        <div className="text-[11px] font-mono text-[#55635C]">
          Academic Evaluation: Synthetic Benchmark Telemetry
        </div>
      </div>

      {/* Tab Navigation Controls */}
      <div className="flex border-b border-[#E4EAE5] gap-1 overflow-x-auto pb-px">
        {[
          { id: 'regression', label: 'Regression Suite (Waste kg)', count: '3 Models' },
          { id: 'classification', label: 'Classification Suite (Risk Flag)', count: '5 Models' },
          { id: 'clustering', label: 'K-Means Clustering (Patterns)', count: `k=${clustering_summary.optimal_k}` },
          { id: 'pipeline', label: 'Feature Pipeline & Schema', count: `${feature_schema.numeric_features.length + feature_schema.categorical_features.length} Features` },
          { id: 'glossary', label: 'Metric Definitions Guide', count: '8 Concepts' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'bg-white text-[#16865B] border-t-2 border-[#16865B] border-x border-[#E4EAE5] shadow-xs'
                : 'text-[#77847C] hover:text-[#25332D] hover:bg-white/60'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                activeTab === tab.id ? 'bg-[#E9F6EE] text-[#16865B]' : 'bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* =====================================================================
          TAB 1: REGRESSION SUITE
      ===================================================================== */}
      {activeTab === 'regression' && (
        <div className="space-y-6">
          {/* Models Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(regression_leaderboard)
              .filter(([k]) => k !== 'best_model')
              .map(([key, m]) => {
                const isSelected = selectedRegressionKey === key;
                const isBest = key === regression_leaderboard.best_model?.model_key;
                return (
                  <div
                    key={key}
                    onClick={() => setSelectedRegressionKey(key)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-white border-[#16865B] shadow-md ring-1 ring-[#16865B]'
                        : 'bg-white border-[#E4EAE5] hover:border-[#D2DDD4] shadow-xs'
                    }`}
                  >
                    {isBest && (
                      <div className="absolute top-3 right-3 text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] flex items-center gap-1 font-semibold">
                        <Sparkles className="w-2.5 h-2.5" />
                        Best Serving Model
                      </div>
                    )}

                    <span className="text-[10px] font-mono text-[#77847C] uppercase tracking-wider block">
                      Target: actual_waste_kg
                    </span>
                    <h4 className="text-sm font-bold text-[#25332D] mt-1 pr-16 leading-snug">
                      {m.model_name}
                    </h4>

                    <div className="mt-4 grid grid-cols-2 gap-3 text-xs pt-3 border-t border-[#EEF2EF]">
                      <div>
                        <span className="text-[#77847C] text-[10px] uppercase font-semibold">MAE (kg)</span>
                        <div className="font-mono font-bold text-[#16865B] text-sm mt-0.5">
                          {m.metrics.mae_kg} kg
                        </div>
                      </div>
                      <div>
                        <span className="text-[#77847C] text-[10px] uppercase font-semibold">R² Score</span>
                        <div className="font-mono font-bold text-[#25332D] text-sm mt-0.5">
                          {m.metrics.r2_score}
                        </div>
                      </div>
                      <div>
                        <span className="text-[#77847C] text-[10px] uppercase font-semibold">RMSE (kg)</span>
                        <div className="font-mono font-medium text-[#77847C] text-xs mt-0.5">
                          {m.metrics.rmse_kg} kg
                        </div>
                      </div>
                      <div>
                        <span className="text-[#77847C] text-[10px] uppercase font-semibold">MSE</span>
                        <div className="font-mono font-medium text-[#77847C] text-xs mt-0.5">
                          {m.metrics.mse}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between text-[11px] text-[#77847C] pt-2 border-t border-[#EEF2EF]">
                      <span className="text-[#77847C] font-mono text-[10px]">Test Samples: {m.test_sample_count}</span>
                      <span className={`text-xs font-semibold ${isSelected ? 'text-[#16865B]' : 'text-[#77847C]'}`}>
                        {isSelected ? 'Inspecting' : 'Select'} →
                      </span>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* Regression Deep Dive & Benchmark Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Model Architecture & Specs */}
            <div className="lg:col-span-5 rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                <div>
                  <span className="text-[10px] font-mono text-[#16865B] uppercase tracking-wider font-semibold">
                    Algorithm Specification
                  </span>
                  <h3 className="text-base font-bold text-[#25332D] mt-0.5">
                    {activeRegression.model_name}
                  </h3>
                </div>
                <div className="p-2 rounded-lg bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                  <Cpu className="w-5 h-5 text-[#16865B]" />
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C] font-semibold uppercase text-[10px]">Artifact File:</span>
                  <p className="text-[#16865B] font-mono text-xs mt-1 break-all">
                    {activeRegression.artifact_file}
                  </p>
                </div>

                {/* Model Selection Rationale */}
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C] font-semibold uppercase text-[10px]">Model Selection Rationale:</span>
                  <p className="text-[#25332D] mt-1 leading-relaxed">
                    {selectedRegressionKey === 'linear_regression'
                      ? 'Selected as the active serving pipeline due to having the lowest test MAE (20.50 kg) and highest R² (0.5134). Ordinary Least Squares models continuous meal portions smoothly without tree-based step discontinuities.'
                      : selectedRegressionKey === 'decision_tree_regressor'
                      ? 'Decision Tree (depth=5) achieves MAE 23.26 kg. It captures categorical feast splits well but produces higher variance (RMSE 30.06 kg) on out-of-fold attendance values.'
                      : 'KNN Regressor (k=7) achieves MAE 23.28 kg by averaging nearest meal records in standardized space, but suffers when test points fall outside training clusters.'}
                  </p>
                </div>

                {/* Feature Importance Section */}
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[#77847C] font-semibold uppercase text-[10px]">
                      Gini Feature Importance (MDI)
                    </span>
                    <span className="text-[10px] font-mono text-[#77847C]">
                      {activeRegression.feature_importance ? 'Supported (Decision Tree)' : 'Not Applicable'}
                    </span>
                  </div>

                  {activeRegression.feature_importance ? (
                    <div className="space-y-2 pt-1">
                      <p className="text-[11px] text-[#77847C] leading-snug">
                        Calculated from Mean Decrease in Impurity (Gini MDI) from fitted DecisionTreeRegressor:
                      </p>
                      <div className="space-y-1.5 font-mono text-xs pt-1">
                        {activeRegression.feature_importance.map((f) => (
                          <div key={f.feature} className="flex justify-between items-center py-0.5 border-b border-[#EEF2EF] last:border-0">
                            <span className="text-[#25332D] font-sans text-[11px]">{f.feature}:</span>
                            <span className="text-[#16865B] font-bold">{f.importance}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-[#77847C] text-[11px] mt-1 leading-relaxed">
                      {activeRegression.feature_importance_note ||
                        'Feature importance is not supported for Ordinary Least Squares or KNN. OLS relies on continuous linear coefficients; KNN relies on Euclidean neighbor distance.'}
                    </p>
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between text-[11px] text-[#77847C] border-t border-[#EEF2EF]">
                  <span>Target: Continuous kg discard</span>
                  <span className="font-mono text-[#16865B] font-bold">R² = {activeRegression.metrics.r2_score}</span>
                </div>
              </div>
            </div>

            {/* Regression Benchmark Bar Chart */}
            <div className="lg:col-span-7 rounded-xl bg-white border border-[#E4EAE5] p-5 flex flex-col justify-between shadow-xs">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-[#16865B]" />
                    Regression Error Metrics Comparison (Held-Out 200 Test Records)
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                    Lower MAE / RMSE is better
                  </span>
                </div>
                <p className="text-xs text-[#77847C] mb-4">
                  Comparative Mean Absolute Error (MAE) and Root Mean Squared Error (RMSE) in kilograms across candidate regressors.
                </p>
              </div>

              <div className="h-64 sm:h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={regressionChartData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
                    <XAxis
                      dataKey="name"
                      stroke="#D2DDD4"
                      tick={{ fill: '#77847C', fontSize: 11 }}
                      axisLine={{ stroke: '#E4EAE5' }}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#D2DDD4"
                      unit=" kg"
                      tick={{ fill: '#77847C', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      formatter={(val, name) => [`${val} kg`, name === 'mae' ? 'MAE (Mean Absolute Error)' : 'RMSE (Root Mean Squared)']}
                      contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E4EAE5', color: '#25332D', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', color: '#77847C' }} />
                    <Bar dataKey="mae" name="MAE (kg)" fill="#16865B" radius={[4, 4, 0, 0]} maxBarSize={32} />
                    <Bar dataKey="rmse" name="RMSE (kg)" fill="#0284C7" radius={[4, 4, 0, 0]} maxBarSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-3 pt-3 border-t border-[#EEF2EF] flex items-center justify-between text-[11px] text-[#77847C]">
                <span>Active Model: Ordinary Least Squares (MAE: 20.50 kg)</span>
                <span className="font-mono text-[#16865B] font-semibold">Variance Explained: 51.34%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: CLASSIFICATION SUITE
      ===================================================================== */}
      {activeTab === 'classification' && (
        <div className="space-y-6">
          {/* Classifiers Leaderboard Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {Object.entries(classification_leaderboard?.models || {}).map(([key, item]) => {
              const isSelected = selectedClassifierKey === key;
              const isBest = key === classification_leaderboard?.best_model?.model_key;
              return (
                <div
                  key={key}
                  onClick={() => setSelectedClassifierKey(key)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-white border-[#16865B] shadow-md ring-1 ring-[#16865B]'
                      : 'bg-white border-[#E4EAE5] hover:border-[#D2DDD4] shadow-xs'
                  }`}
                >
                  {isBest && (
                    <div className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0] inline-flex items-center gap-1 font-semibold mb-1">
                      <Sparkles className="w-2.5 h-2.5" />
                      Best Recall
                    </div>
                  )}
                  <h4 className="text-xs font-bold text-[#25332D] leading-tight truncate" title={item.model_name}>
                    {item.model_name}
                  </h4>
                  <div className="mt-3 space-y-1 font-mono text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-[#77847C] font-sans">Accuracy:</span>
                      <span className="text-[#25332D] font-bold">{(item.metrics.accuracy * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#77847C] font-sans">Recall:</span>
                      <span className="text-[#16865B] font-bold">{(item.metrics.recall * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#77847C] font-sans">F1-Score:</span>
                      <span className="text-[#0284C7] font-semibold">{(item.metrics.f1_score * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                  <div className="mt-2 pt-2 border-t border-[#EEF2EF] text-right">
                    <span className={`text-[10px] font-semibold ${isSelected ? 'text-[#16865B]' : 'text-[#77847C]'}`}>
                      {isSelected ? 'Active' : 'Select'} →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Deep Dive: Confusion Matrix & Comparison Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Confusion Matrix Display */}
            <div className="lg:col-span-6 rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                <div>
                  <span className="text-[10px] font-mono text-[#16865B] uppercase tracking-wider font-semibold">
                    Contingency Analysis
                  </span>
                  <h3 className="text-base font-bold text-[#25332D] mt-0.5">
                    Confusion Matrix: {activeClassifier.model_name}
                  </h3>
                </div>
                <div className="text-xs font-mono px-2.5 py-1 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                  N = 200 Test Samples
                </div>
              </div>

              {/* 2x2 Matrix */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                {/* True Negative */}
                <div className="p-4 rounded-xl bg-[#E9F6EE] border border-[#C5E5D0] text-center">
                  <span className="text-[10px] uppercase font-semibold text-[#16865B] block mb-1">
                    True Negatives (TN)
                  </span>
                  <div className="text-2xl font-bold font-mono text-[#16865B]">
                    {activeClassifier.confusion_matrix.true_negative}
                  </div>
                  <span className="text-[10px] text-[#55635C]">Correctly classified Normal Waste</span>
                </div>

                {/* False Positive */}
                <div className="p-4 rounded-xl bg-[#FFFBEB] border border-[#FDE68A] text-center">
                  <span className="text-[10px] uppercase font-semibold text-[#B45309] block mb-1">
                    False Positives (FP)
                  </span>
                  <div className="text-2xl font-bold font-mono text-[#D97706]">
                    {activeClassifier.confusion_matrix.false_positive}
                  </div>
                  <span className="text-[10px] text-[#92400E]">Type I Error: False Alarm</span>
                </div>

                {/* False Negative */}
                <div className="p-4 rounded-xl bg-[#FEF2F2] border border-[#FECACA] text-center">
                  <span className="text-[10px] uppercase font-semibold text-[#B91C1C] block mb-1">
                    False Negatives (FN)
                  </span>
                  <div className="text-2xl font-bold font-mono text-[#DC2626]">
                    {activeClassifier.confusion_matrix.false_negative}
                  </div>
                  <span className="text-[10px] text-[#991B1B]">Type II Error: Missed Overage</span>
                </div>

                {/* True Positive */}
                <div className="p-4 rounded-xl bg-[#F0FDF4] border border-[#BBF7D0] text-center">
                  <span className="text-[10px] uppercase font-semibold text-[#15803D] block mb-1">
                    True Positives (TP)
                  </span>
                  <div className="text-2xl font-bold font-mono text-[#15803D]">
                    {activeClassifier.confusion_matrix.true_positive}
                  </div>
                  <span className="text-[10px] text-[#166534]">Correctly identified High Risk</span>
                </div>
              </div>

              {/* Feature Importance Display */}
              {activeClassifier.feature_importance ? (
                <div className="p-3.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#25332D] uppercase text-[10px]">
                      Gini MDI Feature Importance:
                    </span>
                    <span className="text-[#77847C] font-mono text-[10px]">DecisionTree Impurity</span>
                  </div>
                  <div className="space-y-1 font-mono text-xs">
                    {activeClassifier.feature_importance.map((f) => (
                      <div key={f.feature} className="flex justify-between items-center py-0.5 border-b border-[#EEF2EF] last:border-0">
                        <span className="text-[#25332D] font-sans text-[11px]">{f.feature}:</span>
                        <span className="text-[#16865B] font-bold">{f.importance}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-[11px] text-[#77847C]">
                  {activeClassifier.feature_importance_note ||
                    'Feature importance (MDI) is not applicable to this classifier architecture.'}
                </div>
              )}

              <div className="pt-2 text-xs text-[#77847C] border-t border-[#EEF2EF] flex items-center justify-between">
                <span>Total Positive Ground Truth: 62</span>
                <span className="font-mono text-[#16865B] font-semibold">
                  Recall: {(activeClassifier.metrics.recall * 100).toFixed(1)}% • F1: {(activeClassifier.metrics.f1_score * 100).toFixed(1)}%
                </span>
              </div>
            </div>

            {/* Classification Comparison Chart */}
            <div className="lg:col-span-6 rounded-xl bg-white border border-[#E4EAE5] p-5 flex flex-col justify-between shadow-xs">
              <div>
                <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2 mb-1">
                  <BarChart3 className="w-4 h-4 text-[#16865B]" />
                  Accuracy, Recall & F1-Score Trade-Offs
                </h3>
                <p className="text-xs text-[#77847C] mb-4">
                  Gaussian Naive Bayes prioritizes Recall (83.9%), catching critical waste spikes, whereas Logistic Regression prioritizes overall Accuracy (79.5%).
                </p>
              </div>

              <div className="h-64 sm:h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={classificationChartData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
                    <XAxis
                      dataKey="name"
                      stroke="#D2DDD4"
                      tick={{ fill: '#77847C', fontSize: 10 }}
                      axisLine={{ stroke: '#E4EAE5' }}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#D2DDD4"
                      unit="%"
                      domain={[0, 100]}
                      tick={{ fill: '#77847C', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      formatter={(val, name) => [`${val}%`, name === 'accuracy' ? 'Accuracy' : name === 'recall' ? 'Recall (Sensitivity)' : 'F1-Score']}
                      contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E4EAE5', color: '#25332D', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', color: '#77847C' }} />
                    <Bar dataKey="accuracy" name="Accuracy" fill="#0284C7" radius={[4, 4, 0, 0]} maxBarSize={22} />
                    <Bar dataKey="recall" name="Recall" fill="#0D9488" radius={[4, 4, 0, 0]} maxBarSize={22} />
                    <Bar dataKey="f1Score" name="F1-Score" fill="#16865B" radius={[4, 4, 0, 0]} maxBarSize={22} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] text-[11px] text-[#25332D] space-y-1">
                <span className="font-semibold text-[#25332D] block">Selection Rationale:</span>
                <p className="text-[#77847C]">
                  For mess management, <strong>Gaussian Naive Bayes</strong> is selected as best because missing a high-waste event (Type II error) is far more costly than a false alarm. It achieves 83.9% recall and the highest F1-score (65.8%).
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: CLUSTERING (K-MEANS)
      ===================================================================== */}
      {activeTab === 'clustering' && (
        <div className="space-y-6">
          {/* Silhouette Optimization Curve & Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Silhouette Scores Chart */}
            <div className="lg:col-span-7 rounded-xl bg-white border border-[#E4EAE5] p-5 flex flex-col justify-between shadow-xs">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
                    <PieChartIcon className="w-4 h-4 text-[#16865B]" />
                    Silhouette Score Analysis for Optimal Cluster Count (k)
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                    Optimal: k = {clustering_summary.optimal_k} (Score: {clustering_summary.chosen_k_silhouette_score})
                  </span>
                </div>
                <p className="text-xs text-[#77847C] mb-4">
                  Evaluating cluster cohesion and separation across continuous features: attendance, prepared weight, waste, and financial cost.
                </p>
              </div>

              <div className="h-60 sm:h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={silhouetteData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
                    <XAxis
                      dataKey="k"
                      stroke="#D2DDD4"
                      tick={{ fill: '#77847C', fontSize: 11 }}
                      axisLine={{ stroke: '#E4EAE5' }}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#D2DDD4"
                      domain={[0.25, 0.45]}
                      tick={{ fill: '#77847C', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      formatter={(val) => [val, 'Silhouette Coefficient']}
                      contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E4EAE5', color: '#25332D', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="silhouette"
                      name="Silhouette Score"
                      stroke="#16865B"
                      strokeWidth={3}
                      dot={{ r: 5, fill: '#16865B', stroke: '#FFFFFF', strokeWidth: 2 }}
                      activeDot={{ r: 7 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="pt-3 border-t border-[#EEF2EF] flex items-center justify-between text-[11px] text-[#77847C]">
                <span>Peak cluster separation achieved at k = 3</span>
                <span className="font-mono text-[#16865B] font-semibold">Optimal Coefficient: 0.4093</span>
              </div>
            </div>

            {/* Clustering Artifacts & Scaled Features */}
            <div className="lg:col-span-5 rounded-xl bg-white border border-[#E4EAE5] p-5 space-y-4 shadow-xs">
              <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#16865B]" />
                Clustering Methodology & Hyperparameters
              </h3>

              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C] font-semibold uppercase text-[10px]">Algorithm:</span>
                  <div className="text-[#25332D] font-bold text-sm mt-0.5">Scikit-learn K-Means (k=3)</div>
                  <span className="text-[#77847C] text-[11px]">Initialization: k-means++, Random State: 42</span>
                </div>

                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C] font-semibold uppercase text-[10px]">Standardized Input Features:</span>
                  <ul className="mt-1 space-y-1 font-mono text-[#16865B] text-xs">
                    {clustering_summary.features_scaled.map((f) => (
                      <li key={f} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#16865B]"></span>
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                  <span className="text-[#77847C] font-semibold uppercase text-[10px]">Artifact Files:</span>
                  <div className="font-mono text-[11px] text-[#25332D] mt-1 break-all">
                    {clustering_summary.artifact_files.model}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Dynamic Cluster Profiles Cards */}
          <div>
            <h3 className="text-sm font-semibold text-[#25332D] mb-3 flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-[#16865B]" />
              Observed Cluster Profiles & Operational Characteristics
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(clusterProfiles).map(([cKey, p]) => {
                const isSelected = selectedClusterId === cKey;
                return (
                  <div
                    key={cKey}
                    onClick={() => setSelectedClusterId(cKey)}
                    className={`p-5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white border-[#16865B] shadow-md ring-1 ring-[#16865B]'
                        : 'bg-white border-[#E4EAE5] hover:border-[#D2DDD4] shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-[#EEF2EF]">
                      <span className="text-xs font-mono font-bold text-[#16865B]">
                        Cluster #{p.cluster_id}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                          p.risk_assessment === 'Low'
                            ? 'bg-[#E9F6EE] text-[#16865B] border-[#C5E5D0]'
                            : 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]'
                        }`}
                      >
                        {p.risk_assessment} Risk
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-[#25332D] mt-2 leading-snug">
                      {p.profile_description}
                    </h4>
                    <span className="text-xs text-[#77847C]">
                      {p.record_count} Records ({p.percentage_of_dataset}% of dataset)
                    </span>

                    {/* Observed Averages */}
                    <div className="mt-4 space-y-2 pt-3 border-t border-[#EEF2EF] text-xs">
                      <div className="flex justify-between items-center">
                        <span className="text-[#77847C]">Avg Food Prepared:</span>
                        <span className="font-mono text-[#25332D] font-semibold">{p.observed_averages.food_prepared_kg} kg</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#77847C]">Avg Food Waste:</span>
                        <span className="font-mono text-[#B91C1C] font-bold">{p.observed_averages.actual_waste_kg} kg</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#77847C]">Waste Ratio:</span>
                        <span className="font-mono text-[#D97706] font-semibold">{p.observed_averages.waste_ratio_percentage}%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#77847C]">Avg Attendance:</span>
                        <span className="font-mono text-[#25332D]">{p.observed_averages.expected_attendance}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#77847C]">Avg Total Cost:</span>
                        <span className="font-mono text-[#16865B] font-semibold">₹{p.observed_averages.total_prepared_cost_inr.toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Top Categories */}
                    <div className="mt-4 pt-3 border-t border-[#EEF2EF] text-[11px] text-[#77847C]">
                      <span className="font-semibold text-[#25332D] block mb-1">Dominant Slots:</span>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(p.top_represented_categories?.meal_types || {}).map(([meal, count]) => (
                          <span key={meal} className="px-2 py-0.5 rounded bg-[#F8FAF8] text-[#25332D] font-mono text-[10px] border border-[#E4EAE5]">
                            {meal}: {count}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: FEATURE PIPELINE & SCHEMA
      ===================================================================== */}
      {activeTab === 'pipeline' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Continuous Predictors */}
            <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-4 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                <h3 className="text-sm font-semibold text-[#25332D] flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#16865B]" />
                  Continuous Numerical Features
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                  StandardScaler Fitted on Train Set
                </span>
              </div>

              <div className="space-y-2 text-xs">
                {feature_schema.numeric_features.map((feat) => (
                  <div key={feat} className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[#25332D] font-semibold">{feat}</span>
                      <div className="text-[10px] text-[#77847C]">Zero Target Leakage Enforced</div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E9F6EE] text-[#16865B] border border-[#C5E5D0]">
                      float64 / int64
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Categorical Predictors */}
            <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-4 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#EEF2EF]">
                <h3 className="text-sm font-semibold text-[#25332D] flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-[#0284C7]" />
                  Nominal Categorical Features
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F8FAF8] text-[#77847C] border border-[#E4EAE5]">
                  OneHotEncoder (handle_unknown='ignore')
                </span>
              </div>

              <div className="space-y-2 text-xs">
                {feature_schema.categorical_features.map((feat) => (
                  <div key={feat} className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[#25332D] font-semibold">{feat}</span>
                      <div className="text-[10px] text-[#77847C]">Transformed to sparse one-hot columns</div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E0F2FE] text-[#0284C7] border border-[#BAE6FD]">
                      nominal string
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Targets & Split Integrity */}
          <div className="p-5 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
            <h3 className="text-sm font-semibold text-[#25332D] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#16865B]" />
              Target Isolation & Leakage Prevention Rules
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-2">
              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                <span className="text-[#77847C] font-semibold block uppercase text-[10px]">Regression Target:</span>
                <div className="font-mono font-bold text-[#16865B] mt-1">{feature_schema.target_regression}</div>
                <p className="text-[#77847C] text-[11px] mt-1">Held-out during training and never permitted as an input feature.</p>
              </div>
              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                <span className="text-[#77847C] font-semibold block uppercase text-[10px]">Classification Target:</span>
                <div className="font-mono font-bold text-[#0284C7] mt-1">{feature_schema.target_classification} (High Waste)</div>
                <p className="text-[#77847C] text-[11px] mt-1">Binary label computed using threshold {feature_schema.high_waste_threshold_kg} kg.</p>
              </div>
              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
                <span className="text-[#77847C] font-semibold block uppercase text-[10px]">Train / Test Partition:</span>
                <div className="font-mono font-bold text-[#25332D] mt-1">800 Train / 200 Test Records</div>
                <p className="text-[#77847C] text-[11px] mt-1">Stratified 80/20 split with fixed random seed 42.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 5: METRICS GLOSSARY & EXPLANATIONS GUIDE
      ===================================================================== */}
      {activeTab === 'glossary' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] space-y-1 shadow-xs">
            <h3 className="text-sm font-bold text-[#25332D] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#16865B]" />
              Evaluation Metrics Guide & Mathematical Definitions
            </h3>
            <p className="text-xs text-[#77847C]">
              Clear academic explanations of every performance metric used across the SmartMess AI machine learning laboratory.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Regression Metrics */}
            <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
              <h4 className="font-bold text-[#16865B] text-sm flex items-center gap-1.5">
                <Scale className="w-4 h-4" />
                Regression Metrics (Waste kg Estimation)
              </h4>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">MAE (Mean Absolute Error):</span>
                <p className="text-[#55635C] leading-relaxed">
                  The average magnitude of absolute error between predicted food waste and actual recorded food waste in kilograms:
                </p>
                <div className="font-mono text-[#16865B] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  MAE = (1 / n) · Σ |y_actual - y_pred|
                </div>
                <p className="text-[#77847C] text-[11px] pt-1">
                  An MAE of <strong>20.50 kg</strong> means forecasts deviate on average by approximately 20.5 kg from kitchen scale measurements.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">RMSE (Root Mean Squared Error):</span>
                <p className="text-[#55635C] leading-relaxed">
                  The square root of the average squared differences. Because errors are squared, RMSE heavily penalizes large outlier blunders:
                </p>
                <div className="font-mono text-[#0284C7] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  RMSE = √[ (1 / n) · Σ (y_actual - y_pred)² ]
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">R² Score (Coefficient of Determination):</span>
                <p className="text-[#55635C] leading-relaxed">
                  The proportion of variance in actual food waste explained by the input predictors compared to a naive mean predictor:
                </p>
                <div className="font-mono text-[#16865B] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  R² = 1 - [ Σ (y_actual - y_pred)² / Σ (y_actual - y_mean)² ]
                </div>
                <p className="text-[#77847C] text-[11px] pt-1">
                  Linear Regression achieves <strong>0.5134</strong>, successfully capturing over half the variance in food waste without target leakage.
                </p>
              </div>
            </div>

            {/* Classification & Clustering Metrics */}
            <div className="p-4 rounded-xl bg-white border border-[#E4EAE5] space-y-3 shadow-xs">
              <h4 className="font-bold text-[#0284C7] text-sm flex items-center gap-1.5">
                <Award className="w-4 h-4" />
                Classification & Clustering Metrics
              </h4>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">Accuracy:</span>
                <p className="text-[#55635C] leading-relaxed">
                  Overall ratio of correct predictions (both normal and high waste) over total instances:
                </p>
                <div className="font-mono text-[#0284C7] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  Accuracy = (TP + TN) / (TP + TN + FP + FN)
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">Precision vs. Recall (Sensitivity):</span>
                <p className="text-[#55635C] leading-relaxed">
                  <strong>Precision</strong> [TP / (TP + FP)] measures accuracy when flagging high risk. <strong>Recall</strong> [TP / (TP + FN)] measures what fraction of actual high-waste crises were caught. In kitchen operations, high recall is vital to prevent undetected overages.
                </p>
                <div className="font-mono text-[#0D9488] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  Recall = TP / (TP + FN)  •  Precision = TP / (TP + FP)
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">F1-Score:</span>
                <p className="text-[#55635C] leading-relaxed">
                  The harmonic mean of Precision and Recall. Balances false alarms and missed events:
                </p>
                <div className="font-mono text-[#16865B] bg-white px-2 py-1 rounded text-[11px] border border-[#E4EAE5]">
                  F1-Score = 2 · (Precision · Recall) / (Precision + Recall)
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5] space-y-1">
                <span className="font-semibold text-[#25332D] block">Silhouette Score (Clustering):</span>
                <p className="text-[#55635C] leading-relaxed">
                  Measures cluster cohesion versus separation from -1.0 to +1.0. A score of <strong>0.4093</strong> at k=3 confirms distinct institutional meal service profiles.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
