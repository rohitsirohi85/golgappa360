import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  DollarSign,
  TrendingUp,
  Building2,
  Receipt,
  CreditCard,
  RefreshCw,
  ArrowUpRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const AdminRevenueScreen = () => {
  const [data, setData] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchRevenueData = async () => {
    try {
      setLoading(true);
      const [revRes, statsRes] = await Promise.all([
        adminService.getRevenueAnalytics(),
        adminService.getStats(),
      ]);
      setData(revRes);
      setStats(statsRes);
    } catch (err) {
      console.error('Error fetching revenue analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRevenueData();
  }, []);

  const dailyRevenue = data?.dailyRevenue || [];
  const revenueByStation = data?.revenueByStation || [];

  return (
    <AdminLayout
      pageTitle="Revenue & Tariff Analytics"
      subtitle="Fleet-wide billing receipts, daily financial collections & station revenue contribution"
    >
      {/* 4 Financial KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Today's Revenue</span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            ₹{stats?.revenue?.today || 0}
          </div>
          <span className="text-xs text-slate-400">Current calendar day</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">This Week</span>
          <div className="text-2xl font-black text-white font-mono">
            ₹{stats?.revenue?.thisWeek || 0}
          </div>
          <span className="text-xs text-slate-400">7-day gross billing</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">This Month</span>
          <div className="text-2xl font-black text-white font-mono">
            ₹{stats?.revenue?.thisMonth || 0}
          </div>
          <span className="text-xs text-slate-400">Month-to-date collections</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Avg Ticket / Session</span>
          <div className="text-2xl font-black text-sky-400 font-mono">
            ₹{stats?.revenue?.averagePerSession || 184}
          </div>
          <span className="text-xs text-slate-400">Average bill value</span>
        </div>
      </div>

      {/* Row 1: 7-Day Revenue Area Chart */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-base font-bold text-white">Daily Revenue Collections (INR)</h3>
              <p className="text-xs text-slate-500">Gross billing receipts generated across all station hubs</p>
            </div>
          </div>
          <button
            onClick={fetchRevenueData}
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-4 h-4 text-emerald-400" />
          </button>
        </div>

        <div className="h-72 w-full">
          {dailyRevenue.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyRevenue}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit=" ₹" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#revenueGrad)"
                  name="Gross Revenue (₹)"
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              Loading financial trends...
            </div>
          )}
        </div>
      </div>

      {/* Row 2: Station Revenue Contribution Table */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Station Revenue Breakdown</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Gross Realized</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                <th className="py-3 px-6 font-bold">Station Hub</th>
                <th className="py-3 px-6 font-bold">Base Energy Rate</th>
                <th className="py-3 px-6 font-bold text-center">Invoiced Sessions</th>
                <th className="py-3 px-6 font-bold text-right">Total Revenue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {revenueByStation.map((st) => (
                <tr key={st.stationId} className="hover:bg-slate-800/40">
                  <td className="py-3 px-6 font-semibold text-white">{st.name}</td>
                  <td className="py-3 px-6 font-mono text-slate-400">₹{st.ratePerKwh}/kWh</td>
                  <td className="py-3 px-6 text-center font-mono text-slate-300">{st.billCount}</td>
                  <td className="py-3 px-6 text-right font-mono font-bold text-emerald-400">
                    ₹{st.revenue}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminRevenueScreen;
