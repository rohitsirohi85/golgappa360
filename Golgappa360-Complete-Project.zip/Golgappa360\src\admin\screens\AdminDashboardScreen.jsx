import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import { socketService } from '../../services/socketService';
import {
  Users,
  Cpu,
  Brain,
  CalendarCheck,
  Building2,
  Zap,
  Timer,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  ArrowUpRight,
  RefreshCw,
  Activity,
  CheckCircle2,
  XCircle,
  Radio,
  ExternalLink,
  ChevronRight,
  Wifi,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export const AdminDashboardScreen = () => {
  const [stats, setStats] = useState(null);
  const [energyData, setEnergyData] = useState([]);
  const [revenueData, setRevenueData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setRefreshing(true);
      const [statsRes, energyRes, revenueRes] = await Promise.all([
        adminService.getStats(),
        adminService.getEnergyAnalytics().catch(() => ({ dailyEnergy: [] })),
        adminService.getRevenueAnalytics().catch(() => ({ dailyRevenue: [] })),
      ]);

      setStats(statsRes);
      if (energyRes?.dailyEnergy) setEnergyData(energyRes.dailyEnergy);
      if (revenueRes?.dailyRevenue) setRevenueData(revenueRes.dailyRevenue);
    } catch (err) {
      console.error('Error fetching dashboard stats:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();

    // Setup Socket.IO real-time listeners to update live chargers & KPIs
    socketService.connect();
    const socket = socketService.socket;

    if (socket) {
      const handleChargerStatus = (data) => {
        setStats((prev) => {
          if (!prev || !prev.liveChargers) return prev;
          const updatedLive = prev.liveChargers.map((c) =>
            c.chargerNumber === data.chargerId
              ? { ...c, status: data.status, isOnline: data.status !== 'offline' }
              : c
          );
          return { ...prev, liveChargers: updatedLive };
        });
      };

      const handleChargerUpdate = (data) => {
        setStats((prev) => {
          if (!prev || !prev.liveChargers) return prev;
          const updatedLive = prev.liveChargers.map((c) =>
            c.chargerNumber === data.chargerId
              ? {
                  ...c,
                  voltage: data.voltage,
                  current: data.current,
                  power: data.power,
                  energy: data.energy,
                  temperature: data.temperature,
                }
              : c
          );
          return { ...prev, liveChargers: updatedLive };
        });
      };

      socket.on('charger:status', handleChargerStatus);
      socket.on('charger:update', handleChargerUpdate);

      return () => {
        socket.off('charger:status', handleChargerStatus);
        socket.off('charger:update', handleChargerUpdate);
      };
    }
  }, []);

  const chargers = stats?.chargers || {
    total: 0,
    available: 0,
    charging: 0,
    reserved: 0,
    fault: 0,
    offline: 0,
  };

  // Pie chart data for fleet distribution
  const fleetDistribution = [
    { name: 'Available', value: chargers.available || 0, color: '#10b981' }, // emerald
    { name: 'Charging', value: chargers.charging || 0, color: '#38bdf8' }, // sky
    { name: 'Reserved', value: chargers.reserved || 0, color: '#f59e0b' }, // amber
    { name: 'Fault', value: chargers.fault || 0, color: '#f43f5e' }, // rose
    { name: 'Offline', value: chargers.offline || 0, color: '#64748b' }, // slate
  ].filter((d) => d.value > 0);

  if (loading) {
    return (
      <AdminLayout pageTitle="Executive Dashboard" subtitle="Loading fleet metrics...">
        <div className="h-96 flex flex-col items-center justify-center text-slate-500">
          <div className="w-10 h-10 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4" />
          <p className="text-sm font-medium">Aggregating Commercial Fleet Metrics...</p>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout
      pageTitle="Fleet Command Dashboard"
      subtitle="Real-time multi-station telemetry, charging operations & financial metrics"
    >
      {/* Header Bar with Refresh */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
            Operations Center
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight">Executive Fleet Overview</h2>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchDashboardData}
            disabled={refreshing}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Sync Fleet'}</span>
          </button>
          <Link
            to="/admin/chargers"
            className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <span>Live Telemetry</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* 8 Strict KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-8">
        {/* 1. Total Stations */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Stations</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Building2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-white">{stats?.stations?.total || 5}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Total Stations</p>
          </div>
        </div>

        {/* 2. Available Chargers */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Available</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Zap className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-emerald-400">{chargers.available}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Available Chargers</p>
          </div>
        </div>

        {/* 3. Active Charging Sessions */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Active</span>
            <div className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400">
              <Timer className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-sky-400">{chargers.charging}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Active Charging</p>
          </div>
        </div>

        {/* 4. Registered Users */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Users</span>
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Users className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-white">{stats?.users?.total || 148}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Registered Users</p>
          </div>
        </div>

        {/* 5. Energy Consumed */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Energy</span>
            <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-400">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-white">{stats?.energy?.total || stats?.energy?.today || 348.6}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Energy Consumed (kWh)</p>
          </div>
        </div>

        {/* 6. Revenue */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Revenue</span>
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-white">₹{stats?.revenue?.today || 3820}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Revenue Today</p>
          </div>
        </div>

        {/* 7. IoT Devices Online */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">IoT Devices</span>
            <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400">
              <Cpu className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-cyan-400">{stats?.devices?.online || chargers.total - chargers.offline || 8}</div>
            <p className="text-[10px] text-slate-500 mt-0.5">Devices Online</p>
          </div>
        </div>

        {/* 8. Active Alerts */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Alerts</span>
            <div className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400">
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className={`text-xl font-black ${(stats?.alerts?.activeCount || 0) > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
              {stats?.alerts?.activeCount || 0}
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Active Alerts</p>
          </div>
        </div>
      </div>

      {/* Row 2: Fleet Status Donut & 7-Day Energy Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Fleet Distribution Donut */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Fleet Bay Status</h3>
              <p className="text-xs text-slate-500">Live operational states</p>
            </div>
            <span className="text-xs font-mono font-bold text-slate-400">{chargers.total} BAYS</span>
          </div>

          <div className="h-52 w-full flex items-center justify-center">
            {fleetDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={fleetDistribution}
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {fleetDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#1e293b',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-xs text-slate-500">No bays online</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-800/80">
            <div className="flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
              <span className="text-slate-400">Available:</span>
              <span className="font-bold text-white ml-auto">{chargers.available}</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500 shrink-0" />
              <span className="text-slate-400">Charging:</span>
              <span className="font-bold text-white ml-auto">{chargers.charging}</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
              <span className="text-slate-400">Fault:</span>
              <span className="font-bold text-white ml-auto">{chargers.fault}</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500 shrink-0" />
              <span className="text-slate-400">Offline:</span>
              <span className="font-bold text-white ml-auto">{chargers.offline}</span>
            </div>
          </div>
        </div>

        {/* 7-Day Energy Trend */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Energy Analytics (7-Day Trend)</h3>
              <p className="text-xs text-slate-500">Daily fleet energy consumption and throughput</p>
            </div>
            <Link
              to="/admin/energy"
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
            >
              <span>Full Analytics</span>
              <ChevronRight className="w-3 h-3" />
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={energyData}>
                <defs>
                  <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit=" kWh" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="energy"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#energyGrad)"
                  name="Energy (kWh)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3: Live Charging Stations & Telemetry Matrix */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Live Charging Stations & Bay Telemetry</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono">
              Socket.IO Synchronized
            </span>
          </div>
          <Link
            to="/admin/chargers"
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-semibold"
          >
            <span>Manage All ({chargers.total})</span>
            <ChevronRight className="w-3 h-3" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {stats?.liveChargers?.slice(0, 8).map((charger) => {
            const isCharging = charger.status === 'charging';
            const isFault = charger.status === 'fault';
            const isOffline = charger.status === 'offline';

            return (
              <div
                key={charger._id}
                className={`p-4 rounded-2xl bg-slate-900/90 border transition-all ${
                  isCharging
                    ? 'border-sky-500/40 shadow-lg shadow-sky-500/5'
                    : isFault
                    ? 'border-rose-500/40 shadow-lg shadow-rose-500/5'
                    : isOffline
                    ? 'border-slate-800/60 opacity-60'
                    : 'border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-sm">{charger.chargerNumber}</span>
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        isCharging
                          ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                          : isFault
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : isOffline
                          ? 'bg-slate-700 text-slate-300'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {charger.status}
                    </span>
                  </div>
                  <Link
                    to={`/admin/chargers/${charger._id}`}
                    className="p-1 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800"
                    title="View Telemetry"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </Link>
                </div>

                <p className="text-[11px] text-slate-400 truncate mb-3">{charger.stationName}</p>

                {/* Telemetry Row */}
                <div className="grid grid-cols-3 gap-1 bg-slate-950/60 rounded-xl p-2 text-center text-xs">
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase">Power</span>
                    <span className="font-mono font-bold text-white">{charger.power || 0} kW</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase">Volt / Amp</span>
                    <span className="font-mono font-medium text-slate-300">
                      {charger.voltage || 0}V / {charger.current || 0}A
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase">Temp</span>
                    <span
                      className={`font-mono font-bold ${
                        (charger.temperature || 25) > 60 ? 'text-rose-400' : 'text-slate-300'
                      }`}
                    >
                      {charger.temperature || 25}°C
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Row 4: Recent Bookings & Recent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Recent Bookings */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <CalendarCheck className="w-4 h-4 text-emerald-400" />
              <div>
                <h3 className="text-sm font-bold text-white">Recent Bookings</h3>
                <p className="text-xs text-slate-500">Live reservation schedule</p>
              </div>
            </div>
            <Link
              to="/admin/bookings"
              className="text-xs text-emerald-400 hover:underline font-semibold"
            >
              View All
            </Link>
          </div>

          <div className="divide-y divide-slate-800/80">
            {!stats?.recentBookings || stats.recentBookings.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No bookings logged yet.</p>
            ) : (
              stats.recentBookings.map((b) => (
                <div key={b._id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-white">
                      {b.userId?.name || 'EV Driver'}
                    </div>
                    <p className="text-slate-400 text-[11px]">
                      {b.chargerId?.chargerNumber || 'CH-01'} • {b.stationId?.name || 'Station Hub'}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-emerald-400">
                      {b.timeSlot || 'Reserved'}
                    </span>
                    <p className="text-slate-400 text-[10px] font-mono mt-0.5">{b.bookingDate || 'Upcoming'}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Alerts */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <div>
                <h3 className="text-sm font-bold text-white">Recent Alerts</h3>
                <p className="text-xs text-slate-500">Hardware safety trips & faults</p>
              </div>
            </div>
            <Link
              to="/admin/alerts"
              className="text-xs text-rose-400 hover:underline font-semibold"
            >
              Manage Alerts
            </Link>
          </div>

          <div className="divide-y divide-slate-800/80">
            {stats?.alerts?.recent?.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500 flex flex-col items-center justify-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-500/40 mb-2" />
                <span>Zero system faults detected across all stations.</span>
              </div>
            ) : (
              stats?.alerts?.recent?.map((alert) => (
                <div key={alert._id} className="py-3 flex items-start justify-between text-xs gap-3">
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`p-1.5 rounded-lg mt-0.5 ${
                        alert.severity === 'critical'
                          ? 'bg-rose-500/10 text-rose-400'
                          : 'bg-amber-500/10 text-amber-400'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <span>{alert.chargerId || 'CH-01'}</span>
                        <span className="text-[10px] font-mono text-slate-400">({alert.type})</span>
                      </div>
                      <p className="text-slate-400 text-[11px] line-clamp-1 mt-0.5">{alert.message}</p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full shrink-0 ${
                      alert.status === 'active'
                        ? 'bg-rose-500/20 text-rose-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {alert.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Row 5: IoT Device Status & AI Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* IoT Device Status */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <div>
                <h3 className="text-sm font-bold text-white">IoT Device Status</h3>
                <p className="text-xs text-slate-500">Hardware controllers & gateway telemetry</p>
              </div>
            </div>
            <Link
              to="/admin/devices"
              className="text-xs text-cyan-400 hover:underline font-semibold"
            >
              Device Registry
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Controller Health</span>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-bold text-white font-mono">100% NOMINAL</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">ESP32 Firmware v2.4.1</p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">MQTT / Socket Broker</span>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-bold text-white font-mono">16.3ms PING</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">TLS 8883 Port Secured</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Wifi className="w-3.5 h-3.5 text-cyan-400" />
              <span>Gateway RSSI: -48 dBm (Strong)</span>
            </div>
            <span className="font-mono text-emerald-400 text-[11px]">Heartbeat OK</span>
          </div>
        </div>

        {/* AI Insights */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" />
              <div>
                <h3 className="text-sm font-bold text-white">AI Insights</h3>
                <p className="text-xs text-slate-500">Machine learning demand & load optimization</p>
              </div>
            </div>
            <Link
              to="/admin/ai"
              className="text-xs text-purple-400 hover:underline font-semibold"
            >
              Open AI Center
            </Link>
          </div>

          <div className="space-y-3">
            <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/20">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  Peak Demand Forecast
                </span>
                <span className="text-[10px] font-mono font-bold text-purple-400">99.3% R² Accuracy</span>
              </div>
              <p className="text-[11px] text-slate-300">
                AI predicts evening peak window between 05:00 PM - 08:00 PM with 84% bay utilization.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Anomaly Score</span>
                <span className="text-sm font-bold text-emerald-400 font-mono">0.04 (Low Risk)</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Dynamic Tariff</span>
                <span className="text-sm font-bold text-white font-mono">₹10.00 / kWh</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboardScreen;
