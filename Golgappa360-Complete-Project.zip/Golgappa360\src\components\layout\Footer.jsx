import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUp, ArrowRight, Phone, MessageCircle, Mail, MapPin, Clock, Send, Check } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';

const InstagramIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

const YoutubeIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
    <polygon points="10 15 15 12 10 9 10 15"/>
  </svg>
);

const SpotifyIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <path d="M8 14.5c2.5-1 5.5-1 8 0" />
    <path d="M7 12c3-1.2 7-1.2 10 0" />
    <path d="M6.5 9.5c3.5-1.5 8.5-1.5 12 0" />
  </svg>
);

export const Footer = ({ onOpenTrial }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) return;
    setNewsletterSubscribed(true);
    setNewsletterEmail('');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsAppUrl = `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
    siteConfig.contact.whatsAppDefaultMessage
  )}`;

  return (
    <footer
      className="relative bg-[#07070A] border-t border-white/[0.08] text-[#A5A1B2] pt-20 pb-12 overflow-hidden"
      aria-label="Footer & Academy Contact Directory"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Top Directory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-16 border-b border-white/[0.08]">
          
          {/* Brand Manifesto & Verified Contact Information */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <Link
                to="/"
                onClick={scrollToTop}
                className="font-display font-bold text-2xl uppercase tracking-tight text-[#F5F3F8] hover:text-[#A78BFA] transition-colors block"
              >
                MOTION<span className="text-[#8B5CF6]">.</span>IS<span className="text-[#8B5CF6]">.</span>ART
              </Link>
              <span className="font-mono text-[10px] tracking-widest text-[#8B5CF6] uppercase block mt-1">
                {siteConfig.academy.tagline}
              </span>
              <p className="mt-4 text-xs sm:text-sm text-[#A5A1B2] leading-relaxed max-w-sm">
                {siteConfig.academy.studioDescription}
              </p>
            </div>

            {/* Direct Contact Links */}
            <div className="mt-8 pt-6 border-t border-white/[0.06] text-xs font-mono space-y-2 text-[#A5A1B2]">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#8B5CF6] flex-shrink-0" />
                <a
                  href={`tel:${siteConfig.contact.telNumber}`}
                  className="hover:text-white transition-colors"
                >
                  {siteConfig.contact.displayPhone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <a
                  href={whatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300 text-emerald-400/90 transition-colors"
                >
                  WhatsApp: {siteConfig.contact.whatsAppDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#8B5CF6] flex-shrink-0" />
                <a
                  href={`mailto:${siteConfig.contact.email}`}
                  className="hover:text-white transition-colors"
                >
                  {siteConfig.contact.email}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#8B5CF6] flex-shrink-0" />
                <span>{siteConfig.contact.address}, {siteConfig.contact.cityStateZip}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-[#8B5CF6] flex-shrink-0" />
                <span>{siteConfig.contact.hours.weekdays}</span>
              </div>
            </div>
          </div>

          {/* Site Navigation Links */}
          <div className="lg:col-span-2">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              PAGES
            </h4>
            <ul className="space-y-2.5 text-xs font-medium">
              {siteConfig.navigation.links.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    onClick={scrollToTop}
                    className="hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Programs Quick Index */}
          <div className="lg:col-span-3">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              DISCIPLINES
            </h4>
            <ul className="space-y-2.5 text-xs">
              {siteConfig.programs.map((prog) => (
                <li key={prog.id}>
                  <Link
                    to="/classes"
                    onClick={scrollToTop}
                    className="hover:text-white transition-colors flex items-center justify-between group"
                  >
                    <span>{prog.name}</span>
                    <span className="font-mono text-[10px] text-[#A5A1B2] group-hover:text-[#8B5CF6]">
                      {prog.badge}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Cypher Newsletter Bulletin */}
          <div className="lg:col-span-3">
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-bold mb-4">
              CYPHER BULLETIN
            </h4>
            <p className="text-xs text-[#A5A1B2] mb-4 leading-relaxed">
              Receive monthly studio updates, masterclass dates, and rehearsal archives.
            </p>

            {newsletterSubscribed ? (
              <div className="p-3.5 rounded-sm bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center gap-2">
                <Check className="w-4 h-4 flex-shrink-0" />
                <span>Added to studio guest bulletin.</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                    className="w-full bg-[#15151C] border border-white/[0.1] rounded-sm px-3.5 py-2.5 text-xs text-white placeholder-[#A5A1B2]/50 focus:outline-none focus:border-[#8B5CF6]"
                  />
                  <button
                    type="submit"
                    className="absolute right-1 top-1 bottom-1 px-3 bg-[#8B5CF6] hover:bg-[#A78BFA] text-white rounded-sm transition-colors"
                    aria-label="Subscribe to bulletin"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-[10px] font-mono text-[#A5A1B2] block opacity-70">
                  Zero spam. Unsubscribe anytime.
                </span>
              </form>
            )}

            {/* Social Channels */}
            <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center gap-3">
              <a
                href={siteConfig.socialLinks.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="Instagram"
              >
                <InstagramIcon className="w-4 h-4" />
              </a>
              <a
                href={siteConfig.socialLinks.youtube.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="YouTube"
              >
                <YoutubeIcon className="w-4 h-4" />
              </a>
              <a
                href={siteConfig.socialLinks.spotify.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-sm bg-white/[0.04] hover:bg-[#8B5CF6] hover:text-white transition-colors text-[#A5A1B2]"
                aria-label="Spotify"
              >
                <SpotifyIcon className="w-4 h-4" />
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Back-to-Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-[#A5A1B2]">
          <div>
            <span>© {new Date().getFullYear()} {siteConfig.academy.legalName}. All Rights Reserved.</span>
          </div>

          <div className="flex items-center gap-6">
            <Link to="/contact" className="hover:text-white transition-colors">
              Studio Enquiries
            </Link>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 text-[#F5F3F8] hover:text-[#A78BFA] transition-colors py-1"
            >
              <span>BACK TO TOP</span>
              <ArrowUp className="w-3.5 h-3.5 text-[#8B5CF6]" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
