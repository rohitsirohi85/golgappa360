import React from 'react';

/**
 * SunCallout — Cinematic educational spotlight
 * “THE SUN IS NOT AN AVERAGE STAR IN EVERY WAY.”
 * “The Sun is a G-type main-sequence star — a relatively ordinary star in
 * mass and temperature, but extraordinary to us because it powers life on Earth.”
 */
export default function SunCallout({ onExploreSun }) {
  return (
    <div className="w-full relative rounded-3xl overflow-hidden bg-[#060710]/80 border border-amber-500/20 p-8 sm:p-12 lg:p-16 text-center select-none shadow-[0_20px_60px_rgba(0,0,0,0.7)] backdrop-blur-xl">
      {/* Background Solar Flare & Atmosphere */}
      <div
        aria-hidden="true"
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[300px] bg-gradient-to-r from-amber-500/15 via-yellow-400/20 to-amber-600/10 blur-[110px] pointer-events-none"
      />

      {/* Orbit Rings */}
      <div
        aria-hidden="true"
        className="absolute inset-4 rounded-3xl border border-amber-500/10 pointer-events-none"
      />

      <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center">
        {/* Emblem */}
        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-200 flex items-center justify-center mb-6 shadow-[0_0_25px_rgba(251,191,36,0.6)] border border-amber-200">
          <span className="text-slate-950 text-xl font-bold">☉</span>
        </div>

        {/* Small Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>SOLAR PERSPECTIVE</span>
        </div>

        {/* Cinematic Main Heading */}
        <h3 className="font-display text-2xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-6 leading-tight">
          THE SUN IS NOT AN AVERAGE STAR{' '}
          <span className="bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 bg-clip-text text-transparent">
            IN EVERY WAY.
          </span>
        </h3>

        {/* Core Narrative Paragraph */}
        <p className="font-sans text-base sm:text-lg lg:text-xl text-amber-100/90 leading-relaxed font-normal mb-8 max-w-2xl">
          The Sun is a G-type main-sequence star — a relatively ordinary star in mass and temperature,
          but extraordinary to us because it powers life on Earth.
        </p>

        {/* Scientific Context Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-2xl mb-8 text-xs font-mono">
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-amber-500/20 text-center">
            <span className="text-amber-400 font-bold text-sm sm:text-base block mb-0.5">TOP 15%</span>
            <span className="text-slate-300">More massive than 85% of galaxy stars</span>
          </div>
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-amber-500/20 text-center">
            <span className="text-yellow-300 font-bold text-sm sm:text-base block mb-0.5">4.6 BILLION YR</span>
            <span className="text-slate-300">Continuous uninterrupted luminosity</span>
          </div>
          <div className="p-3 rounded-xl bg-[#020308]/60 border border-amber-500/20 text-center">
            <span className="text-cyan-300 font-bold text-sm sm:text-base block mb-0.5">G2V CLASS</span>
            <span className="text-slate-300">Optimal radiation for photosynthesis</span>
          </div>
        </div>

        {/* Quick Trigger */}
        {onExploreSun && (
          <button
            type="button"
            onClick={onExploreSun}
            className="px-6 py-3 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-semibold font-mono text-xs tracking-wider shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:shadow-[0_0_30px_rgba(245,158,11,0.45)] hover:-translate-y-0.5 transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
          >
            Explore the Sun in Catalog →
          </button>
        )}
      </div>
    </div>
  );
}
