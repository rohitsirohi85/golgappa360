import React from 'react';
import { STARS_DATA } from '../../data/stars';

/**
 * RealStarsExamples — "MEET THE REAL STARS"
 * Reuses existing star database records to showcase real astronomical examples
 * categorized under their spectral classifications.
 * Clicking any example smoothly scrolls to Stars Explorer and opens the star dossier!
 */
export default function RealStarsExamples({ onSelectStar }) {
  // Highlighted catalog exemplars
  const targetIds = [
    'sun',
    'sirius',
    'vega',
    'betelgeuse',
    'rigel',
    'proxima-centauri',
    'antares',
    'deneb',
  ];

  const exampleStars = STARS_DATA.filter((star) => targetIds.includes(star.id));

  const handleClick = (star) => {
    if (onSelectStar) {
      onSelectStar(star);
    } else {
      const explorer = document.getElementById('stars');
      if (explorer) {
        explorer.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-cyan-500/20 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>CATALOG EXEMPLARS</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          MEET THE REAL STARS
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/80 leading-relaxed max-w-2xl mx-auto">
          Every theoretical classification corresponds to awe-inspiring celestial bodies in our night sky.
          Click any star to inspect its complete observational dossier in the Stars Explorer.
        </p>
      </div>

      {/* Exemplar Grid */}
      <div className="w-full grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {exampleStars.map((star) => (
          <button
            key={star.id}
            type="button"
            onClick={() => handleClick(star)}
            className="group relative flex flex-col justify-between text-left p-5 sm:p-6 rounded-2xl glass-surface-interactive border border-white/10 hover:border-cyan-400/50 transition-all duration-300 hover:-translate-y-1 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 overflow-hidden shadow-lg"
          >
            {/* Spectral Glow Tint */}
            <div
              aria-hidden="true"
              className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-2xl opacity-10 group-hover:opacity-30 transition-opacity duration-300 pointer-events-none"
              style={{ backgroundColor: star.colorHex }}
            />

            <div>
              {/* Spectral Class Chip */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest bg-white/5 border border-white/10 text-cyan-300">
                  <span
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: star.colorHex, boxShadow: `0 0 6px ${star.colorHex}` }}
                  />
                  <span>CLASS {star.spectralClass}</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {star.type.split(' ')[0]}
                </span>
              </div>

              {/* Star Name & Moniker */}
              <h4 className="font-display text-xl sm:text-2xl font-semibold text-white group-hover:text-cyan-200 transition-colors mb-1">
                {star.name}
              </h4>
              <p className="text-xs font-mono text-slate-400 truncate mb-4">
                {star.constellation}
              </p>
            </div>

            {/* Bottom Telemetry & CTA */}
            <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300 font-medium">{star.temperature}</span>
              <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">
                Inspect ↗
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
