import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Calendar, Clock, User, Layers, ArrowUpRight, MessageCircle } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const SchedulePage = ({ onOpenTrial: propOnOpenTrial }) => {
  const outletCtx = useOutletContext();
  const onOpenTrial = propOnOpenTrial || outletCtx?.onOpenTrial;

  const [selectedDay, setSelectedDay] = useState('Monday');

  const activeDaySchedule =
    siteConfig.schedule.find((s) => s.day === selectedDay) || siteConfig.schedule[0];

  const whatsAppSlotUrl = (className, time) =>
    `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
      `Hello MOTION IS ART, I would like to reserve a slot in the ${className} class (${selectedDay} ${time}).`
    )}`;

  return (
    <>
      <SEO
        title="Weekly Class Timetable"
        description="Weekly studio schedule for MOTION IS ART. Morning, evening, and weekend classes across all 5 disciplines with instructor and level details."
      />

      <div className="pt-28 sm:pt-36 pb-24 sm:pb-32 bg-[#0B0B0F] text-[#F5F3F8]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          
          {/* Page Editorial Header */}
          <div className="pb-12 border-b border-white/[0.08] max-w-4xl">
            <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-3">
              [ WEEKLY STUDIO TIMETABLE ]
            </span>
            <h1 className="editorial-headline text-4xl sm:text-6xl lg:text-7xl text-[#F5F3F8] uppercase">
              SEVEN DAYS. <br />
              <span className="text-[#A78BFA]">ON THE FLOOR.</span>
            </h1>
            <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] leading-relaxed max-w-2xl font-sans">
              Find your training rhythm. Filter our weekly schedule by day to review session times, resident faculty leaders, and difficulty tiers.
            </p>
          </div>

          {/* Responsive Day Filter Bar */}
          <div className="mt-10 flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 border-b border-white/[0.08]">
            {siteConfig.schedule.map((dayObj) => {
              const isSelected = dayObj.day === selectedDay;
              return (
                <button
                  key={dayObj.day}
                  onClick={() => setSelectedDay(dayObj.day)}
                  className={`flex-shrink-0 px-5 py-3 rounded-sm font-sans text-xs sm:text-sm tracking-wider uppercase font-semibold transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
                    isSelected
                      ? 'bg-[#15151C] text-white border-b-2 border-[#8B5CF6] shadow-[0_4px_20px_rgba(139,92,246,0.15)]'
                      : 'text-[#A5A1B2] hover:text-[#F5F3F8] hover:bg-white/[0.03]'
                  }`}
                >
                  <span>{dayObj.day}</span>
                  <span className="ml-2 font-mono text-[10px] opacity-60">
                    ({dayObj.slots.length})
                  </span>
                </button>
              );
            })}
          </div>

          {/* Timetable Slots (Responsive Card & Row Layout) */}
          <div className="mt-8 space-y-4">
            {activeDaySchedule.slots.map((slot, idx) => (
              <div
                key={idx}
                className="group p-5 sm:p-6 rounded-sm bg-[#15151C] border border-white/[0.08] hover:border-[#8B5CF6]/50 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                {/* Left: Time & Room */}
                <div className="flex items-center gap-4 md:w-1/4">
                  <div className="p-3 rounded-sm bg-[#0B0B0F] border border-white/5 text-[#8B5CF6] flex-shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono text-sm sm:text-base font-bold text-white block">
                      {slot.time}
                    </span>
                    <span className="font-mono text-[10px] uppercase text-[#A5A1B2] flex items-center gap-1 mt-0.5">
                      <Layers className="w-3 h-3 text-[#8B5CF6]" />
                      {slot.room}
                    </span>
                  </div>
                </div>

                {/* Middle: Class Name, Level, Instructor */}
                <div className="flex-1 md:px-6">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-[10px] font-semibold text-[#8B5CF6] uppercase bg-white/[0.04] px-2 py-0.5 rounded border border-white/5">
                      {slot.level}
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-lg sm:text-xl text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors">
                    {slot.class}
                  </h3>
                  <p className="text-xs text-[#A5A1B2] mt-1 flex items-center gap-1.5 font-medium">
                    <User className="w-3 h-3 text-[#8B5CF6]" />
                    Lead Mentor: {slot.instructor}
                  </p>
                </div>

                {/* Right: Booking Actions */}
                <div className="flex items-center gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-white/[0.06]">
                  <a
                    href={whatsAppSlotUrl(slot.class, slot.time)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-mono font-medium text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 rounded-sm transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WHATSAPP</span>
                  </a>

                  {onOpenTrial && (
                    <button
                      onClick={() => onOpenTrial()}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#A78BFA] rounded-sm transition-colors shadow-[0_0_12px_rgba(139,92,246,0.3)]"
                    >
                      <span>TRIAL SLOT</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Studio Schedule Protocol Note */}
          <div className="mt-12 p-6 rounded-sm bg-[#15151C] border border-white/[0.07] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs font-mono text-[#A5A1B2]">
              <p>⏱ Studio doors unlock 20 minutes prior to morning call.</p>
              <p>👟 Clean indoor sneakers required for street disciplines.</p>
            </div>
            <a
              href={`tel:${siteConfig.contact.telNumber}`}
              className="text-xs font-mono font-bold text-[#8B5CF6] hover:text-[#A78BFA] uppercase transition-colors"
            >
              Need Schedule Guidance? Call {siteConfig.contact.displayPhone} →
            </a>
          </div>

        </div>
      </div>
    </>
  );
};

export default SchedulePage;
