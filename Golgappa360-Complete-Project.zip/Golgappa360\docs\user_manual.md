# Golgappa360 — Operational User Manual & System Guide

> **Master of Computer Applications (MCA) Major Capstone Project**  
> **Application:** Golgappa360 Business Intelligence & Sales Analytics Dashboard  
> **Target Enterprise:** Local Indian Golgappa / Pani Puri Stall Operations  
> **Design Theme:** Dark Glassmorphism SaaS Interface

---

## 1. Getting Started & Dashboard Overview

Golgappa360 provides a modern, touch-friendly analytics interface designed for stall owners, kitchen managers, and business consultants. The interface features a dark charcoal canvas (`#171717`) with translucent glass cards, sage-green profitability highlights, and saffron accents.

### 1.1 Accessing the Application
- Open your browser (Google Chrome, Microsoft Edge, Safari, or Firefox).
- Navigate to: `http://localhost:5173`.
- The dashboard loads in **Overview** mode by default.

### 1.2 Layout Navigation & Controls
- **Sidebar Rail (Left):** Hover to expand or click icons to switch between the 7 functional modules:
  1. **Overview:** Executive summary, revenue velocity, and quick action modals.
  2. **Sales Analytics:** Hourly rush patterns, daily/weekly/monthly trends, and payment mix.
  3. **Products:** Menu pricing, unit Bill of Materials (BOM) costing, and profit contribution margins.
  4. **Inventory:** Real-time raw material balances, safety thresholds, and restock logging.
  5. **Waste Analysis:** Food spoilage auditing, crushed puri counts, and shrinkage prevention.
  6. **Reports & Data Hub:** Download Tableau-ready CSVs and copy production MySQL queries.
  7. **Settings:** Stall branding, target margin goals, and MySQL connection testing.
- **Top Bar Controls:**
  - **Date Range Dropdown:** Switch between `Today`, `Last 7 Days`, `Last 30 Days`, `Last 90 Days`, and `All 6 Months`.
  - **Product Filter:** Filter the entire dashboard by specific varieties (`Classic Golgappa`, `Spicy Pani Puri`, `Sweet Pani Puri`, `Special Golgappa`, `Dahi Puri`).
  - **Global Search:** Instant real-time filtering for items, ingredients, and queries.

---

## 2. Walkthrough of Functional Modules

### 2.1 Overview Dashboard
1. **Executive KPI Bar:**
   - Displays Net Turnover, Plates Sold, Gross Profit, Food Waste Cost, and Average Order Value (AOV).
2. **Revenue Velocity Time-Series:**
   - Visualizes day-to-day revenue trajectory alongside the 7-day rolling moving average.
3. **Hourly Service Profile:**
   - Highlights commuter footfall distribution across the operational window (3:00 PM to 10:00 PM).
4. **Quick Action Modals:**
   - Click **+ Restock** to immediately record fresh ingredient deliveries from the mandi.
   - Click **+ Log Waste** to register spoiled flavoured pani or crushed puris during transit.

---

### 2.2 Sales Analytics Engine
1. **Multi-Period Granularity Toggle:**
   - Click **Daily**, **Weekly**, or **Monthly** tabs to adjust the aggregation scale of revenue and plate volume.
2. **Commuter Rush Heatmap:**
   - Identifies the critical 6:00 PM – 8:00 PM evening peak where over $58\%$ of daily turnover is generated.
3. **Payment Method Breakdown:**
   - Monitors the digital transformation ratio: UPI QR payments vs. physical cash tenders.

---

### 2.3 Menu & Product Economics
1. **Unit Recipe COGS Derivation:**
   - Displays the precise recipe costing: 6 suji puris (₹2.10) + potato-chana mash (₹1.80) + spiced mint water (₹3.20) + seasoning/dona (₹1.30) = **₹8.40 standard plate cost**.
   - Selling at ₹30 generates a benchmark **72.0% gross margin**.
2. **Add New Variety Modal:**
   - Click **+ Add Menu Item** to simulate new seasonal items (e.g. *Hing & Jeera Special*). Enforces financial validation: Cost Price cannot equal or exceed Selling Price.

---

### 2.4 Inventory & Raw Material Control
1. **Ingredient Runway Gauge:**
   - Tracks current on-hand stock against safety reorder thresholds:
     - **Critical (< 50% threshold):** Immediate reorder required.
     - **Low Stock (<= threshold):** Reorder before evening service.
     - **Healthy:** Sufficient stock for upcoming operations.
2. **Mandi Supply Restock Tool:**
   - Select ingredient, enter quantity received, and add optional supplier notes.

---

### 2.5 Food Waste & Spoilage Auditing
1. **Root Cause Analysis:**
   - Breaks down food loss by source:
     - *Crushed Puris (Transit/Storage):* 42.0% of waste loss.
     - *Souring Flavoured Mint Pani:* 35.3% of waste loss.
     - *Boiled Potato Mash Fermentation:* 22.7% of waste loss.
2. **Data-Driven Waste Recommendations:**
   - Displays actionable guidance: switching from soft burlap sacks to cushioned plastic crates (saves ₹2,450/month) and implementing staged two-batch pani mixing (saves ₹1,800/month).

---

### 2.6 Reports & BI Hub
1. **Tableau CSV Datasets:**
   - Download the 6 certified star-schema CSV exports:
     - `tableau_sales.csv`
     - `tableau_products.csv`
     - `tableau_inventory.csv`
     - `tableau_daily_summary.csv`
     - `tableau_expenses.csv`
     - `tableau_data_dictionary.csv`
   - Click **Download All 6 Datasets** to download the complete BI bundle.
2. **Calculated Fields & Excel Workflows:**
   - Access copy-paste ready Tableau formulas and Excel Pivot Table guides.
3. **Production SQL Library:**
   - Browse 30 documented queries across 6 operational categories and copy SQL with a single click.

---

### 2.7 System Configuration & Settings
1. **Stall Profile:** Update stall name, owner name, location, and UPI VPA.
2. **Database Diagnostics:** Test connections to local MySQL instances and view active driver status (`MySQL 8.0 Live` vs. `Synthetic Store Active`).

---

## 3. Frequently Asked Questions (FAQ) & Troubleshooting

### Q: Why does the dashboard show "Synthetic Store Active" instead of MySQL?
**A:** If local MySQL credentials are not configured in `server/.env`, the system automatically switches to the built-in synthetic store to maintain 100% uptime without crashes. To connect to MySQL, copy `server/.env.example` to `server/.env`, add your MySQL password, and run `node server/src/scripts/importData.js`.

### Q: Can the CSV exports be opened directly in Microsoft Excel?
**A:** Yes. All files use RFC 4180 standard UTF-8 formatting. For best results, use **Data > From Text/CSV** in Excel to preserve date formats.

### Q: Are the numbers in the Tableau CSV files identical to the web dashboard?
**A:** Yes. The platform guarantees exact arithmetic parity ($₹0.00$ variance) across SQL views, the web frontend, and all exported CSVs.
