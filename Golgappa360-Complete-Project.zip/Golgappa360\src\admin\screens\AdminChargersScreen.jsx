import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import { socketService } from '../../services/socketService';
import { useAuth } from '../../context/AuthContext';
import {
  Zap,
  Search,
  Filter,
  Play,
  Square,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  Radio,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Power,
  SlidersHorizontal,
} from 'lucide-react';

export const AdminChargersScreen = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [chargers, setChargers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const fetchChargers = async () => {
    try {
      setLoading(true);
      const data = await adminService.getChargers(statusFilter);
      if (Array.isArray(data)) {
        setChargers(data);
      }
    } catch (err) {
      console.error('Error fetching chargers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChargers();

    socketService.connect();
    const socket = socketService.socket;
    if (socket) {
      const handleStatus = (data) => {
        setChargers((prev) =>
          prev.map((c) =>
            c.chargerNumber === data.chargerId
              ? { ...c, status: data.status, isOnline: data.status !== 'offline' }
              : c
          )
        );
      };

      const handleUpdate = (data) => {
        setChargers((prev) =>
          prev.map((c) =>
            c.chargerNumber === data.chargerId
              ? {
                  ...c,
                  voltage: data.voltage,
                  current: data.current,
                  power: data.power,
                  energy: data.energy,
                  temperature: data.temperature,
                }
              : c
          )
        );
      };

      socket.on('charger:status', handleStatus);
      socket.on('charger:update', handleUpdate);

      return () => {
        socket.off('charger:status', handleStatus);
        socket.off('charger:update', handleUpdate);
      };
    }
  }, [statusFilter]);

  const handleControl = async (id, action) => {
    setActionLoading(true);
    setToastMessage('');
    try {
      await adminService.controlCharger(id, action);
      setToastMessage(`Dispatched "${action}" command successfully.`);
      fetchChargers();
    } catch (err) {
      setToastMessage(`Control failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredChargers = chargers.filter((c) => {
    const matchesSearch =
      c.chargerNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.stationId?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.connectorType?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <AdminLayout
      pageTitle="Charger Fleet & Live Telemetry"
      subtitle="Fleet-wide charger bay status, real-time sensor metrics & remote operational dispatch"
    >
      {/* Toast Alert */}
      {toastMessage && (
        <div className="mb-4 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between">
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage('')} className="text-slate-400 hover:text-white">
            &times;
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Bay (e.g. CH-01), Station, Connector..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            {['all', 'available', 'charging', 'fault', 'offline'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 rounded-lg capitalize font-semibold transition-colors ${
                  statusFilter === status
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchChargers}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Refresh Fleet</span>
        </button>
      </div>

      {/* Chargers Table & List */}
      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading live charger fleet telemetry...</p>
        </div>
      ) : filteredChargers.length === 0 ? (
        <div className="h-64 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-slate-500 text-xs">
          <Zap className="w-10 h-10 mb-2 text-slate-700" />
          <p>No chargers found matching selected criteria.</p>
        </div>
      ) : (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-950/40">
                  <th className="py-4 px-6 font-bold">Bay / ID</th>
                  <th className="py-4 px-6 font-bold">Station Hub</th>
                  <th className="py-4 px-6 font-bold">Type & Power</th>
                  <th className="py-4 px-6 font-bold">Status</th>
                  <th className="py-4 px-6 font-bold text-center">Power</th>
                  <th className="py-4 px-6 font-bold text-center">Volt / Amp</th>
                  <th className="py-4 px-6 font-bold text-center">Temp</th>
                  <th className="py-4 px-6 font-bold text-center">Total Energy</th>
                  <th className="py-4 px-6 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredChargers.map((c) => {
                  const isCharging = c.status === 'charging';
                  const isFault = c.status === 'fault';
                  const isOffline = c.status === 'offline';

                  return (
                    <tr
                      key={c._id}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* Bay / ID */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-2.5 h-2.5 rounded-full ${
                              isCharging
                                ? 'bg-sky-400 animate-pulse'
                                : isFault
                                ? 'bg-rose-400 animate-ping'
                                : isOffline
                                ? 'bg-slate-600'
                                : 'bg-emerald-400'
                            }`}
                          />
                          <Link
                            to={`/admin/chargers/${c._id}`}
                            className="font-extrabold text-white group-hover:text-emerald-400 transition-colors text-sm"
                          >
                            {c.chargerNumber}
                          </Link>
                        </div>
                      </td>

                      {/* Station */}
                      <td className="py-4 px-6">
                        <span className="font-semibold text-white block">
                          {c.stationId?.name || 'EV Hub'}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {c.stationId?.city || 'Local'}
                        </span>
                      </td>

                      {/* Type & Power */}
                      <td className="py-4 px-6">
                        <span className="font-medium text-slate-200 block">
                          {c.chargerType || 'Fast Charger'}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {c.connectorType} • {c.powerRating}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-6">
                        <span
                          className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-full ${
                            isCharging
                              ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                              : isFault
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : isOffline
                              ? 'bg-slate-700 text-slate-300'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {c.status}
                        </span>
                      </td>

                      {/* Power (kW) */}
                      <td className="py-4 px-6 text-center font-mono font-bold text-white">
                        {c.power || 0} kW
                      </td>

                      {/* Voltage & Current */}
                      <td className="py-4 px-6 text-center font-mono text-slate-400">
                        {c.voltage || 0}V / {c.current || 0}A
                      </td>

                      {/* Temperature */}
                      <td className="py-4 px-6 text-center">
                        <span
                          className={`font-mono font-semibold ${
                            (c.temperature || 25) > 60
                              ? 'text-rose-400 font-bold'
                              : (c.temperature || 25) > 45
                              ? 'text-amber-400'
                              : 'text-slate-300'
                          }`}
                        >
                          {c.temperature || 25}°C
                        </span>
                      </td>

                      {/* Total Energy Delivered */}
                      <td className="py-4 px-6 text-center font-mono font-medium text-emerald-400">
                        {c.energy || 0} kWh
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link
                            to={`/admin/chargers/${c._id}`}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                            title="Inspect Details"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Link>

                          {isAdmin && (
                            <>
                              <button
                                onClick={() => handleControl(c._id, 'start')}
                                disabled={actionLoading || isCharging}
                                title="Force Start"
                                className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 disabled:opacity-30"
                              >
                                <Play className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleControl(c._id, 'stop')}
                                disabled={actionLoading || !isCharging}
                                title="Emergency Stop"
                                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 disabled:opacity-30"
                              >
                                <Square className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleControl(c._id, 'maintenance')}
                                disabled={actionLoading}
                                title="Set Maintenance"
                                className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 disabled:opacity-30"
                              >
                                <Wrench className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminChargersScreen;
