/**
 * Re-export the single unified MessContext from src/smartmess/context/MessContext
 * to guarantee a single React Context singleton across the entire app.
 */
export * from '../smartmess/context/MessContext';
