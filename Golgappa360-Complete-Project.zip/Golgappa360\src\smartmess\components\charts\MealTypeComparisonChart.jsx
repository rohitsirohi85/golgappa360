import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import { MEAL_TYPE_COMPARISON } from '../../data/mockWasteData';
import { Utensils } from 'lucide-react';

const CustomMealTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="rounded-lg bg-white border border-[#E4EAE5] p-3 shadow-lg text-xs space-y-1.5 min-w-[190px]">
        <div className="font-semibold text-[#25332D] border-b border-[#EEF2EF] pb-1 flex justify-between items-center">
          <span>{data.mealType} Service</span>
          <span className="text-[10px] font-mono text-[#16865B]">Avg {data.avgAttendance} students</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Total Prepared:</span>
          <span className="font-mono text-[#25332D]">{data.preparedKg.toLocaleString()} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D]">
          <span className="text-[#77847C]">Total Waste:</span>
          <span className="font-mono font-semibold text-[#B91C1C]">{data.wastedKg.toLocaleString()} kg</span>
        </div>
        <div className="flex justify-between text-[#25332D] border-t border-[#EEF2EF] pt-1">
          <span className="text-[#77847C]">Waste Ratio:</span>
          <span className="font-mono font-bold text-[#D97706]">{data.wastePercentage}%</span>
        </div>
      </div>
    );
  }
  return null;
};

export const MealTypeComparisonChart = ({ data: propData }) => {
  const chartData = (propData && propData.length > 0)
    ? propData.map((item) => {
        const type = (item.meal_type || item.mealType || 'Meal').charAt(0).toUpperCase() + (item.meal_type || item.mealType || 'Meal').slice(1);
        const color = type === 'Breakfast' ? '#16865B' : type === 'Lunch' ? '#0D9488' : '#4F46E5';
        return {
          mealType: type,
          preparedKg: Math.round(item.prepared_kg !== undefined ? item.prepared_kg : item.preparedKg),
          wastedKg: Math.round(item.waste_kg !== undefined ? item.waste_kg : item.wastedKg),
          wastePercentage: item.waste_pct !== undefined ? item.waste_pct : item.wastePercentage,
          avgAttendance: Math.round(item.avg_attendance !== undefined ? item.avg_attendance : (item.avgAttendance || 700)),
          color,
          fill: color,
        };
      })
    : MEAL_TYPE_COMPARISON;

  return (
    <div className="rounded-xl bg-white border border-[#E4EAE5] p-5 shadow-xs">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-sm font-semibold text-[#25332D] tracking-tight flex items-center gap-2">
            <Utensils className="w-4 h-4 text-[#16865B]" />
            Meal-Type Waste Distribution
          </h3>
          <p className="text-xs text-[#77847C] mt-0.5">
            Aggregated waste comparison across service slots from FastAPI backend
          </p>
        </div>

        <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#16865B] bg-[#E9F6EE] px-2.5 py-1 rounded-md border border-[#C5E5D0]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#16865B]"></span>
          <span>Backend Aggregated Data</span>
        </div>
      </div>

      <div className="h-64 sm:h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#EEF2EF" vertical={false} />
            <XAxis
              dataKey="mealType"
              stroke="#D2DDD4"
              tick={{ fill: '#77847C', fontSize: 11 }}
              axisLine={{ stroke: '#E4EAE5' }}
              tickLine={false}
            />
            <YAxis
              stroke="#D2DDD4"
              tick={{ fill: '#77847C', fontSize: 11 }}
              unit=" kg"
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomMealTooltip />} />
            <Legend
              verticalAlign="top"
              align="right"
              wrapperStyle={{ paddingBottom: '12px', fontSize: '11px', color: '#77847C' }}
              iconSize={8}
            />
            <Bar
              dataKey="preparedKg"
              name="Prepared Food (kg)"
              fill="#EEF2EF"
              stroke="#E4EAE5"
              radius={[4, 4, 0, 0]}
              maxBarSize={36}
            />
            <Bar
              dataKey="wastedKg"
              name="Wasted Food (kg)"
              radius={[4, 4, 0, 0]}
              maxBarSize={36}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3 pt-3 border-t border-[#EEF2EF] grid grid-cols-2 sm:grid-cols-3 gap-2 text-center text-xs">
        {chartData.map((m) => (
          <div key={m.mealType} className="p-2.5 rounded-lg bg-[#F8FAF8] border border-[#E4EAE5]">
            <span className="text-[11px] text-[#77847C] block">{m.mealType}</span>
            <span className="font-mono font-bold text-[#25332D] text-xs mt-0.5 block">
              {m.wastePercentage}%
            </span>
            <span className="text-[10px] text-[#77847C] font-mono">
              {m.wastedKg.toLocaleString()} kg waste
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
