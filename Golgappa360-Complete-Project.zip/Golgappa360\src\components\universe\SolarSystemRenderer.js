/**
 * STELLAR 2.0 — Interactive Solar System Canvas 2D Engine
 * 
 * High-performance, cinematic 60fps renderer for the Solar System:
 * - Central Sun with dynamic thermonuclear corona & flares
 * - All 8 major planets with authentic visual signatures:
 *   - Mercury (craters, slate-grey, iron core)
 *   - Venus (sulfur amber cloud shrouds, atmospheric limb)
 *   - Earth (blue marble oceans, continents, cloud swirls, cyan limb & Moon)
 *   - Mars (rust red, dark terrain, polar ice cap)
 *   - Jupiter (banded gas belts, Great Red Spot)
 *   - Saturn (golden sphere with 3D tilted ring system & Cassini gap)
 *   - Uranus (aquamarine ice giant with tilted ring)
 *   - Neptune (cobalt blue with supersonic storm streaks)
 * - Orbital trajectory lines with toggle support
 * - Dynamic Sun-illuminated day/night terminator shading
 * - Smooth camera navigation, zoom, pan, hover, and selection reticle
 * 
 * DISCLAIMER: Illustrative educational visualization — distances and sizes are not to scale.
 */

// Cache of pre-generated background stars for the solar system scene
let solarBackgroundStars = null;

function getSolarBackgroundStars() {
  if (solarBackgroundStars && solarBackgroundStars.length === 240) {
    return solarBackgroundStars;
  }
  const stars = [];
  for (let i = 0; i < 240; i++) {
    stars.push({
      x: (Math.random() - 0.5) * 3600,
      y: (Math.random() - 0.5) * 3600,
      radius: Math.random() * 1.3 + 0.4,
      baseAlpha: Math.random() * 0.65 + 0.25,
      twinkleSpeed: Math.random() * 0.002 + 0.001,
      twinklePhase: Math.random() * Math.PI * 2,
      color: Math.random() > 0.8 ? '#93c5fd' : Math.random() > 0.85 ? '#fde68a' : '#ffffff',
    });
  }
  solarBackgroundStars = stars;
  return stars;
}

/**
 * Calculates the current world coordinates of a planet given time and speed factor.
 */
export function getPlanetWorldPosition(planet, time, speedFactor = 1.0) {
  if (!planet.orbitRadius || planet.orbitRadius === 0) {
    return { x: 0, y: 0, angle: 0 };
  }
  const initialAngle = planet.initialAngle || 0;
  const currentAngle = initialAngle + (time * 0.0006 * planet.orbitSpeed * speedFactor) % (Math.PI * 2);
  return {
    x: Math.cos(currentAngle) * planet.orbitRadius,
    y: Math.sin(currentAngle) * planet.orbitRadius,
    angle: currentAngle,
  };
}

/**
 * Converts world coordinates to screen pixel coordinates.
 */
export function worldToSolarScreen(worldX, worldY, camera, width, height) {
  return {
    x: width / 2 + (worldX - camera.x) * camera.zoom,
    y: height / 2 + (worldY - camera.y) * camera.zoom,
  };
}

/**
 * Converts screen pixel coordinates to world coordinates.
 */
export function solarScreenToWorld(screenX, screenY, camera, width, height) {
  return {
    x: (screenX - width / 2) / camera.zoom + camera.x,
    y: (screenY - height / 2) / camera.zoom + camera.y,
  };
}

/**
 * Layer 1: Draw deep space background, nebula haze, and distant stars.
 */
export function drawSolarBackground(ctx, width, height, camera, time = 0) {
  // 1. Deep space near-black gradient matching U1 (#020308 -> #050711)
  const bgGrad = ctx.createRadialGradient(
    width / 2 - camera.x * camera.zoom * 0.15,
    height / 2 - camera.y * camera.zoom * 0.15,
    50,
    width / 2,
    height / 2,
    Math.max(width, height)
  );
  bgGrad.addColorStop(0, '#070b18');
  bgGrad.addColorStop(0.5, '#04060d');
  bgGrad.addColorStop(1, '#020308');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. Subtle solar nebula / zodiacal light dust haze around the ecliptic plane
  const sunScreen = worldToSolarScreen(0, 0, camera, width, height);
  const zodiacalGrad = ctx.createRadialGradient(
    sunScreen.x,
    sunScreen.y,
    10,
    sunScreen.x,
    sunScreen.y,
    Math.min(width, height) * 0.95
  );
  zodiacalGrad.addColorStop(0, 'rgba(251, 191, 36, 0.08)');
  zodiacalGrad.addColorStop(0.3, 'rgba(56, 189, 248, 0.03)');
  zodiacalGrad.addColorStop(0.7, 'rgba(99, 102, 241, 0.015)');
  zodiacalGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
  ctx.fillStyle = zodiacalGrad;
  ctx.fillRect(0, 0, width, height);

  // 3. Parallax starfield
  const stars = getSolarBackgroundStars(width, height);
  for (let i = 0; i < stars.length; i++) {
    const s = stars[i];
    // Parallax factor
    const sx = width / 2 + (s.x - camera.x * 0.1) * camera.zoom * 0.7;
    const sy = height / 2 + (s.y - camera.y * 0.1) * camera.zoom * 0.7;

    if (sx < -20 || sx > width + 20 || sy < -20 || sy > height + 20) continue;

    const twinkle = Math.sin(time * s.twinkleSpeed + s.twinklePhase);
    const alpha = Math.max(0.1, Math.min(1.0, s.baseAlpha + twinkle * 0.25));

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.arc(sx, sy, s.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

/**
 * Layer 2: Draw planetary orbital tracks with optional highlights.
 */
export function drawSolarOrbits(ctx, width, height, camera, planets, showOrbits, hoveredId, selectedId) {
  if (!showOrbits) return;

  const sunScreen = worldToSolarScreen(0, 0, camera, width, height);

  for (const planet of planets) {
    if (!planet.orbitRadius || planet.orbitRadius === 0) continue;

    const screenRadius = planet.orbitRadius * camera.zoom;
    if (screenRadius < 2) continue;

    const isHovered = hoveredId === planet.id;
    const isSelected = selectedId === planet.id;

    ctx.save();
    ctx.beginPath();
    ctx.arc(sunScreen.x, sunScreen.y, screenRadius, 0, Math.PI * 2);

    if (isSelected) {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 6;
    } else if (isHovered) {
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 4]);
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 4;
    } else {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 0.8;
      ctx.setLineDash([2, 5]);
    }

    ctx.stroke();
    ctx.restore();
  }
}

/**
 * Layer 3: Draw central Sun with luminous corona and pulsing thermonuclear convection.
 */
export function drawCentralSun(ctx, width, height, camera, sunObject, time = 0, isHovered = false, isSelected = false) {
  const sunScreen = worldToSolarScreen(0, 0, camera, width, height);
  const baseR = (sunObject?.visualRadius || 30) * Math.min(1.8, Math.max(0.65, camera.zoom * 0.95));
  const r = Math.max(14, baseR);

  ctx.save();

  // 1. Huge outer atmospheric corona halo
  const pulse = Math.sin(time * 0.0025) * 4;
  const outerCoronaGrad = ctx.createRadialGradient(
    sunScreen.x,
    sunScreen.y,
    r * 0.8,
    sunScreen.x,
    sunScreen.y,
    r * 3.5 + pulse
  );
  outerCoronaGrad.addColorStop(0, 'rgba(251, 191, 36, 0.45)');
  outerCoronaGrad.addColorStop(0.35, 'rgba(245, 158, 11, 0.22)');
  outerCoronaGrad.addColorStop(0.7, 'rgba(234, 88, 12, 0.08)');
  outerCoronaGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
  ctx.fillStyle = outerCoronaGrad;
  ctx.beginPath();
  ctx.arc(sunScreen.x, sunScreen.y, r * 3.5 + pulse, 0, Math.PI * 2);
  ctx.fill();

  // 2. Solar spicules / flare rays
  const flareCount = 12;
  ctx.save();
  ctx.translate(sunScreen.x, sunScreen.y);
  ctx.rotate(time * 0.0003);
  for (let i = 0; i < flareCount; i++) {
    const angle = (i * Math.PI * 2) / flareCount;
    const flareLen = r * 1.8 + Math.sin(time * 0.004 + i) * 6;
    const flareGrad = ctx.createRadialGradient(0, 0, r * 0.9, 0, 0, flareLen);
    flareGrad.addColorStop(0, 'rgba(254, 240, 138, 0.35)');
    flareGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
    ctx.strokeStyle = flareGrad;
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(Math.cos(angle) * (r * 0.9), Math.sin(angle) * (r * 0.9));
    ctx.lineTo(Math.cos(angle) * flareLen, Math.sin(angle) * flareLen);
    ctx.stroke();
  }
  ctx.restore();

  // 3. Mid photosphere chromosphere glow
  const midGrad = ctx.createRadialGradient(
    sunScreen.x,
    sunScreen.y,
    r * 0.3,
    sunScreen.x,
    sunScreen.y,
    r * 1.35
  );
  midGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
  midGrad.addColorStop(0.4, 'rgba(254, 240, 138, 0.9)');
  midGrad.addColorStop(0.75, 'rgba(251, 191, 36, 0.85)');
  midGrad.addColorStop(1, 'rgba(234, 88, 12, 0.5)');
  ctx.fillStyle = midGrad;
  ctx.beginPath();
  ctx.arc(sunScreen.x, sunScreen.y, r * 1.35, 0, Math.PI * 2);
  ctx.fill();

  // 4. Solid luminous solar disk
  const coreGrad = ctx.createRadialGradient(
    sunScreen.x - r * 0.25,
    sunScreen.y - r * 0.25,
    r * 0.1,
    sunScreen.x,
    sunScreen.y,
    r
  );
  coreGrad.addColorStop(0, '#ffffff');
  coreGrad.addColorStop(0.4, '#fef08a');
  coreGrad.addColorStop(0.75, '#fbbf24');
  coreGrad.addColorStop(1, '#ea580c');
  ctx.fillStyle = coreGrad;
  ctx.beginPath();
  ctx.arc(sunScreen.x, sunScreen.y, r, 0, Math.PI * 2);
  ctx.fill();

  // 5. Sun label & telemetry badge
  ctx.font = '600 11px ui-monospace, SFMono-Regular, Menlo, monospace';
  ctx.fillStyle = '#fde68a';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  ctx.shadowColor = '#000000';
  ctx.shadowBlur = 4;
  ctx.fillText('☀️ SUN // SOL', sunScreen.x, sunScreen.y + r + 10);

  ctx.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
  ctx.fillStyle = 'rgba(253, 230, 138, 0.7)';
  ctx.fillText('G2V Yellow Dwarf', sunScreen.x, sunScreen.y + r + 24);

  // Selection / Hover highlights for Sun
  if (isSelected || isHovered) {
    ctx.strokeStyle = isSelected ? '#38bdf8' : '#fbbf24';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(sunScreen.x, sunScreen.y, r + 18, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Layer 4: Draw individual planets with distinct visual surfaces and lighting.
 */
export function drawPlanets(
  ctx,
  width,
  height,
  camera,
  planets,
  time = 0,
  speedFactor = 1.0,
  hoveredId = null,
  selectedId = null
) {
  const sunScreen = worldToSolarScreen(0, 0, camera, width, height);

  for (const planet of planets) {
    if (!planet.orbitRadius || planet.orbitRadius === 0) continue;

    const pos = getPlanetWorldPosition(planet, time, speedFactor);
    const screen = worldToSolarScreen(pos.x, pos.y, camera, width, height);

    // Skip if far off screen
    if (
      screen.x < -100 ||
      screen.x > width + 100 ||
      screen.y < -100 ||
      screen.y > height + 100
    ) {
      continue;
    }

    // Dynamic scale radius
    const baseR = planet.visualRadius * Math.min(2.0, Math.max(0.65, camera.zoom * 0.9));
    const r = Math.max(4.5, baseR);

    // Light direction: unit vector pointing from Sun to Planet
    const dx = screen.x - sunScreen.x;
    const dy = screen.y - sunScreen.y;
    const dist = Math.hypot(dx, dy) || 1;
    const sunDirX = -dx / dist; // Vector pointing towards Sun
    const sunDirY = -dy / dist;

    const isHovered = hoveredId === planet.id;
    const isSelected = selectedId === planet.id;

    ctx.save();

    // ==================================================
    // SATURN BACK RINGS (rendered before sphere for 3D depth)
    // ==================================================
    if (planet.id === 'saturn') {
      drawSaturnRings(ctx, screen.x, screen.y, r, 'back', isSelected, isHovered);
    }

    // ==================================================
    // PLANET ATMOSPHERIC GLOW
    // ==================================================
    const glowGrad = ctx.createRadialGradient(
      screen.x,
      screen.y,
      r * 0.7,
      screen.x,
      screen.y,
      r * 2.2
    );
    glowGrad.addColorStop(0, planet.glowColor || 'rgba(56, 189, 248, 0.4)');
    glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = glowGrad;
    ctx.beginPath();
    ctx.arc(screen.x, screen.y, r * 2.2, 0, Math.PI * 2);
    ctx.fill();

    // ==================================================
    // PLANET BODY & CUSTOM SIGNATURE
    // ==================================================
    ctx.save();
    ctx.beginPath();
    ctx.arc(screen.x, screen.y, r, 0, Math.PI * 2);
    ctx.clip(); // Clip all surface drawings to sphere

    switch (planet.id) {
      // --------------------------------------------------
      // 1. MERCURY: Cratered slate-grey iron surface
      // --------------------------------------------------
      case 'mercury': {
        const mercGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.45,
          screen.y + sunDirY * r * 0.45,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        mercGrad.addColorStop(0, '#cbd5e1');
        mercGrad.addColorStop(0.5, '#64748b');
        mercGrad.addColorStop(1, '#1e293b');
        ctx.fillStyle = mercGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Crater stipples
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(screen.x - r * 0.25, screen.y - r * 0.2, r * 0.18, 0, Math.PI * 2);
        ctx.arc(screen.x + r * 0.3, screen.y + r * 0.25, r * 0.15, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 2. VENUS: Dense sulfur-amber swirl clouds
      // --------------------------------------------------
      case 'venus': {
        const venusGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.45,
          screen.y + sunDirY * r * 0.45,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        venusGrad.addColorStop(0, '#fef08a');
        venusGrad.addColorStop(0.45, '#eab308');
        venusGrad.addColorStop(0.85, '#a16207');
        venusGrad.addColorStop(1, '#451a03');
        ctx.fillStyle = venusGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Sulfuric cloud wave streaks
        ctx.fillStyle = 'rgba(254, 240, 138, 0.4)';
        ctx.beginPath();
        ctx.ellipse(screen.x, screen.y - r * 0.3, r * 0.85, r * 0.3, 0.3, 0, Math.PI * 2);
        ctx.ellipse(screen.x, screen.y + r * 0.35, r * 0.8, r * 0.25, -0.2, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 3. EARTH: Blue marble oceans, continents, cloud swirls
      // --------------------------------------------------
      case 'earth': {
        // Deep blue ocean base
        const oceanGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.4,
          screen.y + sunDirY * r * 0.4,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        oceanGrad.addColorStop(0, '#38bdf8');
        oceanGrad.addColorStop(0.4, '#0284c7');
        oceanGrad.addColorStop(0.8, '#0369a1');
        oceanGrad.addColorStop(1, '#082f49');
        ctx.fillStyle = oceanGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Green / Emerald Continents
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        // Africa / Eurasia rough patch
        ctx.ellipse(screen.x - r * 0.15, screen.y - r * 0.15, r * 0.45, r * 0.55, 0.4, 0, Math.PI * 2);
        // Americas patch
        ctx.ellipse(screen.x + r * 0.35, screen.y + r * 0.2, r * 0.3, r * 0.5, -0.3, 0, Math.PI * 2);
        ctx.fill();

        // White weather cloud swirls
        ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.beginPath();
        ctx.ellipse(screen.x - r * 0.2, screen.y - r * 0.4, r * 0.6, r * 0.15, 0.2, 0, Math.PI * 2);
        ctx.ellipse(screen.x + r * 0.1, screen.y + r * 0.3, r * 0.65, r * 0.18, -0.15, 0, Math.PI * 2);
        ctx.ellipse(screen.x, screen.y, r * 0.4, r * 0.12, 0.5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 4. MARS: Rust-red, dark Syrtis Major, polar ice cap
      // --------------------------------------------------
      case 'mars': {
        const marsGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.45,
          screen.y + sunDirY * r * 0.45,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        marsGrad.addColorStop(0, '#f87171');
        marsGrad.addColorStop(0.45, '#dc2626');
        marsGrad.addColorStop(0.85, '#991b1b');
        marsGrad.addColorStop(1, '#450a0a');
        ctx.fillStyle = marsGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Dark volcanic basalt terrain
        ctx.fillStyle = 'rgba(69, 10, 10, 0.65)';
        ctx.beginPath();
        ctx.ellipse(screen.x + r * 0.1, screen.y + r * 0.1, r * 0.55, r * 0.35, 0.2, 0, Math.PI * 2);
        ctx.fill();

        // North polar ice cap
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(screen.x, screen.y - r * 0.78, r * 0.32, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 5. JUPITER: Giant gas giant with banded stripes & Red Spot
      // --------------------------------------------------
      case 'jupiter': {
        const jupGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.4,
          screen.y + sunDirY * r * 0.4,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        jupGrad.addColorStop(0, '#fef3c7');
        jupGrad.addColorStop(0.4, '#d97706');
        jupGrad.addColorStop(0.85, '#92400e');
        jupGrad.addColorStop(1, '#451a03');
        ctx.fillStyle = jupGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Horizontal atmospheric gas bands
        const bandColors = [
          'rgba(180, 83, 9, 0.7)',
          'rgba(254, 243, 199, 0.5)',
          'rgba(146, 64, 14, 0.75)',
          'rgba(253, 230, 138, 0.5)',
          'rgba(120, 53, 15, 0.7)',
        ];
        for (let b = 0; b < bandColors.length; b++) {
          const by = screen.y - r + (b + 0.5) * (r * 2 / bandColors.length);
          ctx.fillStyle = bandColors[b];
          ctx.fillRect(screen.x - r, by - r * 0.16, r * 2, r * 0.32);
        }

        // Great Red Spot in southern hemisphere
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.ellipse(screen.x + r * 0.35, screen.y + r * 0.3, r * 0.3, r * 0.2, 0.1, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fca5a5';
        ctx.beginPath();
        ctx.ellipse(screen.x + r * 0.35, screen.y + r * 0.3, r * 0.15, r * 0.1, 0.1, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 6. SATURN: Golden gas giant sphere
      // --------------------------------------------------
      case 'saturn': {
        const satGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.4,
          screen.y + sunDirY * r * 0.4,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        satGrad.addColorStop(0, '#fef08a');
        satGrad.addColorStop(0.4, '#fcd34d');
        satGrad.addColorStop(0.8, '#d97706');
        satGrad.addColorStop(1, '#78350f');
        ctx.fillStyle = satGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Subtle soft bands
        ctx.fillStyle = 'rgba(180, 83, 9, 0.35)';
        ctx.fillRect(screen.x - r, screen.y - r * 0.3, r * 2, r * 0.25);
        ctx.fillRect(screen.x - r, screen.y + r * 0.15, r * 2, r * 0.2);
        break;
      }

      // --------------------------------------------------
      // 7. URANUS: Aquamarine / cyan ice giant
      // --------------------------------------------------
      case 'uranus': {
        const uraGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.45,
          screen.y + sunDirY * r * 0.45,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        uraGrad.addColorStop(0, '#a5f3fc');
        uraGrad.addColorStop(0.45, '#67e8f9');
        uraGrad.addColorStop(0.85, '#0891b2');
        uraGrad.addColorStop(1, '#164e63');
        ctx.fillStyle = uraGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Faint icy polar haze
        ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
        ctx.beginPath();
        ctx.ellipse(screen.x, screen.y, r * 0.8, r * 0.4, 1.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      // --------------------------------------------------
      // 8. NEPTUNE: Azure / cobalt blue ice giant & storms
      // --------------------------------------------------
      case 'neptune': {
        const nepGrad = ctx.createRadialGradient(
          screen.x + sunDirX * r * 0.45,
          screen.y + sunDirY * r * 0.45,
          r * 0.1,
          screen.x,
          screen.y,
          r
        );
        nepGrad.addColorStop(0, '#60a5fa');
        nepGrad.addColorStop(0.45, '#2563eb');
        nepGrad.addColorStop(0.85, '#1e40af');
        nepGrad.addColorStop(1, '#0f172a');
        ctx.fillStyle = nepGrad;
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

        // Supersonic cirrus cloud streaks
        ctx.fillStyle = 'rgba(191, 219, 254, 0.65)';
        ctx.beginPath();
        ctx.ellipse(screen.x - r * 0.1, screen.y - r * 0.3, r * 0.65, r * 0.1, 0.2, 0, Math.PI * 2);
        ctx.ellipse(screen.x + r * 0.2, screen.y + r * 0.25, r * 0.55, r * 0.08, -0.15, 0, Math.PI * 2);
        ctx.fill();

        // Dark Spot
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.ellipse(screen.x - r * 0.2, screen.y + r * 0.1, r * 0.25, r * 0.16, 0.1, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      default: {
        ctx.fillStyle = planet.colorHex || '#94a3b8';
        ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);
      }
    }

    // ==================================================
    // SUN-ILLUMINATED TERMINATOR NIGHT SHADOW
    // ==================================================
    // The side facing away from the Sun is cloaked in deep shadow
    const shadowGrad = ctx.createRadialGradient(
      screen.x - sunDirX * r * 0.7,
      screen.y - sunDirY * r * 0.7,
      r * 0.2,
      screen.x,
      screen.y,
      r * 1.05
    );
    shadowGrad.addColorStop(0, 'rgba(2, 3, 8, 0.95)');
    shadowGrad.addColorStop(0.6, 'rgba(2, 3, 8, 0.7)');
    shadowGrad.addColorStop(1, 'rgba(2, 3, 8, 0)');
    ctx.fillStyle = shadowGrad;
    ctx.fillRect(screen.x - r, screen.y - r, r * 2, r * 2);

    ctx.restore(); // Restore clip

    // ==================================================
    // SATURN FRONT RINGS (drawn over planet for 3D depth)
    // ==================================================
    if (planet.id === 'saturn') {
      drawSaturnRings(ctx, screen.x, screen.y, r, 'front', isSelected, isHovered);
    }

    // ==================================================
    // URANUS ICE RING (subtle vertical tilt ring)
    // ==================================================
    if (planet.id === 'uranus') {
      ctx.save();
      ctx.strokeStyle = 'rgba(165, 243, 252, 0.4)';
      ctx.lineWidth = 1.0;
      ctx.beginPath();
      ctx.ellipse(screen.x, screen.y, r * 0.55, r * 1.85, 0.2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // ==================================================
    // EARTH'S MOON (LUNA)
    // ==================================================
    if (planet.id === 'earth') {
      const moonDist = r * 2.4;
      const moonAngle = time * 0.003;
      const mx = screen.x + Math.cos(moonAngle) * moonDist;
      const my = screen.y + Math.sin(moonAngle) * (moonDist * 0.6);

      // Moon orbit line
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 0.6;
      ctx.setLineDash([2, 3]);
      ctx.beginPath();
      ctx.ellipse(screen.x, screen.y, moonDist, moonDist * 0.6, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Moon sphere
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.arc(mx, my, Math.max(2, r * 0.24), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // ==================================================
    // PLANET NAME & SYMBOL LABEL
    // ==================================================
    drawPlanetLabel(ctx, screen.x, screen.y, r, planet, isHovered, isSelected);

    // ==================================================
    // HOVER RING & SELECTION RETICLE
    // ==================================================
    if (isHovered && !isSelected) {
      drawPlanetHoverRing(ctx, screen.x, screen.y, r);
    }
    if (isSelected) {
      drawPlanetReticle(ctx, screen.x, screen.y, r, time);
    }

    ctx.restore();
  }
}

/**
 * Draws Saturn's magnificent tilted ring system with 3D front/back clipping.
 */
function drawSaturnRings(ctx, sx, sy, r, pass = 'both', isSelected = false, isHovered = false) {
  const tilt = -0.38; // ~22 degrees tilt
  const ringInner = r * 1.45;
  const ringGap = r * 1.85;
  const ringOuter = r * 2.35;
  const yRatio = 0.38; // Flattening ratio

  ctx.save();
  ctx.translate(sx, sy);
  ctx.rotate(tilt);

  // Clip pass:
  // 'back': only draw above y = 0 (behind planet)
  // 'front': only draw below y = 0 (in front of planet)
  if (pass === 'back') {
    ctx.beginPath();
    ctx.rect(-ringOuter * 1.5, -ringOuter * 1.5, ringOuter * 3, ringOuter * 1.5);
    ctx.clip();
  } else if (pass === 'front') {
    ctx.beginPath();
    ctx.rect(-ringOuter * 1.5, 0, ringOuter * 3, ringOuter * 1.5);
    ctx.clip();
  }

  // 1. Outer A-Ring
  ctx.strokeStyle = isSelected
    ? 'rgba(56, 189, 248, 0.7)'
    : isHovered
    ? 'rgba(253, 230, 138, 0.85)'
    : 'rgba(252, 211, 77, 0.45)';
  ctx.lineWidth = ringOuter - ringGap;
  ctx.beginPath();
  ctx.ellipse(0, 0, (ringOuter + ringGap) / 2, ((ringOuter + ringGap) / 2) * yRatio, 0, 0, Math.PI * 2);
  ctx.stroke();

  // 2. Cassini Division dark gap line
  ctx.strokeStyle = 'rgba(2, 3, 8, 0.85)';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.ellipse(0, 0, ringGap, ringGap * yRatio, 0, 0, Math.PI * 2);
  ctx.stroke();

  // 3. Inner B-Ring (Brighter and denser)
  ctx.strokeStyle = isSelected
    ? 'rgba(56, 189, 248, 0.85)'
    : isHovered
    ? 'rgba(254, 240, 138, 0.95)'
    : 'rgba(253, 230, 138, 0.75)';
  ctx.lineWidth = ringGap - ringInner;
  ctx.beginPath();
  ctx.ellipse(0, 0, (ringGap + ringInner) / 2, ((ringGap + ringInner) / 2) * yRatio, 0, 0, Math.PI * 2);
  ctx.stroke();

  // 4. Subtle C-Ring (Crepe ring, faint inner)
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.2)';
  ctx.lineWidth = ringInner * 0.18;
  ctx.beginPath();
  ctx.ellipse(0, 0, ringInner * 0.9, (ringInner * 0.9) * yRatio, 0, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}

/**
 * Renders planet text label with astronomical symbol and distance.
 */
function drawPlanetLabel(ctx, sx, sy, r, planet, isHovered, isSelected) {
  const labelY = sy + r + (planet.id === 'saturn' ? 16 : 10);

  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';

  if (isSelected) {
    // Selected highlight pill
    ctx.font = '600 11px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.fillStyle = '#38bdf8';
    ctx.shadowColor = '#0284c7';
    ctx.shadowBlur = 6;
    ctx.fillText(`${planet.symbol || '●'} ${planet.name.toUpperCase()}`, sx, labelY);

    ctx.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.fillStyle = 'rgba(224, 242, 254, 0.75)';
    ctx.shadowBlur = 0;
    ctx.fillText(planet.distanceFromSun || '', sx, labelY + 14);
  } else if (isHovered) {
    // Hover glow
    ctx.font = '600 11px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.fillStyle = '#fbbf24';
    ctx.shadowColor = '#d97706';
    ctx.shadowBlur = 5;
    ctx.fillText(`${planet.symbol || '●'} ${planet.name}`, sx, labelY);
  } else {
    // Subtle default label
    ctx.font = '500 10px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.fillStyle = 'rgba(226, 232, 240, 0.7)';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 3;
    ctx.fillText(`${planet.symbol || '●'} ${planet.name}`, sx, labelY);
  }

  ctx.restore();
}

/**
 * Draws hover ring around planet.
 */
function drawPlanetHoverRing(ctx, sx, sy, r) {
  ctx.save();
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.6)';
  ctx.lineWidth = 1.2;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.arc(sx, sy, r + 7, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

/**
 * Draws active scientific targeting reticle on selected planet.
 */
function drawPlanetReticle(ctx, sx, sy, r, time = 0) {
  const reticleR = r + 12;
  const bracketLen = 6;

  ctx.save();
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.5;
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 6;

  // 1. Pulsing radar circle
  const pulse = Math.sin(time * 0.005) * 2;
  ctx.beginPath();
  ctx.arc(sx, sy, reticleR + pulse, 0, Math.PI * 2);
  ctx.setLineDash([4, 4]);
  ctx.stroke();

  // 2. Corner Target Brackets
  ctx.setLineDash([]);
  const corners = [
    { x: sx - reticleR, y: sy - reticleR, dx: 1, dy: 1 },
    { x: sx + reticleR, y: sy - reticleR, dx: -1, dy: 1 },
    { x: sx - reticleR, y: sy + reticleR, dx: 1, dy: -1 },
    { x: sx + reticleR, y: sy + reticleR, dx: -1, dy: -1 },
  ];

  for (const c of corners) {
    ctx.beginPath();
    ctx.moveTo(c.x, c.y + c.dy * bracketLen);
    ctx.lineTo(c.x, c.y);
    ctx.lineTo(c.x + c.dx * bracketLen, c.y);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Hit test for Solar System: tests if screen coordinates hit the Sun or any of the 8 planets.
 */
export function hitTestSolarObject(
  screenX,
  screenY,
  solarObjects,
  camera,
  width,
  height,
  time = 0,
  speedFactor = 1.0,
  hitRadius = 26
) {
  // 1. Check Planets first (outer to inner)
  for (let i = solarObjects.length - 1; i >= 0; i--) {
    const obj = solarObjects[i];
    if (obj.isSun || obj.id === 'sun') continue;

    const pos = getPlanetWorldPosition(obj, time, speedFactor);
    const screen = worldToSolarScreen(pos.x, pos.y, camera, width, height);

    const baseR = obj.visualRadius * Math.min(2.0, Math.max(0.65, camera.zoom * 0.9));
    const effectiveRadius = Math.max(hitRadius, baseR + 10);

    const dist = Math.hypot(screenX - screen.x, screenY - screen.y);
    if (dist <= effectiveRadius) {
      return obj;
    }
  }

  // 2. Check Central Sun at (0, 0)
  const sunObj = solarObjects.find((o) => o.isSun || o.id === 'sun');
  if (sunObj) {
    const sunScreen = worldToSolarScreen(0, 0, camera, width, height);
    const sunBaseR = (sunObj.visualRadius || 30) * Math.min(1.8, Math.max(0.65, camera.zoom * 0.95));
    const effectiveSunR = Math.max(hitRadius, sunBaseR + 8);

    const dist = Math.hypot(screenX - sunScreen.x, screenY - sunScreen.y);
    if (dist <= effectiveSunR) {
      return sunObj;
    }
  }

  return null;
}
