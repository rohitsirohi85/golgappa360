import React from 'react';
import SectionHeading from '../SectionHeading';

/**
 * ConstellationHeader — Cinematic section intro with HUD visual accents
 * Eyebrow: "NIGHT SKY ATLAS"
 * Heading: "MAP THE NIGHT SKY."
 * Description: "Across cultures and centuries, people have connected distant stars into patterns called constellations."
 */
export default function ConstellationHeader() {
  return (
    <div className="flex flex-col items-center text-center max-w-4xl mx-auto relative">
      {/* HUD Telemetry Badges */}
      <div className="inline-flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-cyan-950/30 border border-cyan-500/30 text-[11px] font-mono tracking-widest text-cyan-300 uppercase mb-6 backdrop-blur-md shadow-sm">
        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]" />
        <span>CELESTIAL ATLAS // J2026.5 EQUATORIAL PROJECTION</span>
      </div>

      <SectionHeading
        eyebrow="NIGHT SKY ATLAS"
        title="MAP THE NIGHT SKY."
        subtitle="Across cultures and centuries, people have connected distant stars into patterns called constellations."
        align="center"
      />

      {/* Subtle Night Sky Visual Accents & Scientific HUD Lines */}
      <div className="w-full mt-6 flex items-center justify-center gap-4 text-xs font-mono text-slate-400">
        <div className="h-px flex-1 max-w-[120px] bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent" />
        <span className="flex items-center gap-2 text-cyan-400/80">
          <span className="text-[10px]">RA 00h—24h</span>
          <span className="text-slate-600">/</span>
          <span className="text-[10px]">DEC −90°—+90°</span>
        </span>
        <div className="h-px flex-1 max-w-[120px] bg-gradient-to-l from-transparent via-cyan-500/30 to-transparent" />
      </div>
    </div>
  );
}
