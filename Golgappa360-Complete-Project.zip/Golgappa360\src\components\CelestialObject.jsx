import React, { useState } from 'react';

/**
 * CelestialObject — High-fidelity cinematic glowing star/sun sphere
 * Featuring multi-layered coronal halos, animated plasma convection texture,
 * limb-darkening, solar flares, and observatory telemetry rings.
 */
export default function CelestialObject({ className = '' }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Outer Cosmic Corona Atmosphere (Huge soft glowing aura) */}
      <div
        aria-hidden="true"
        className="absolute -inset-10 sm:-inset-16 rounded-full bg-gradient-to-tr from-amber-500/25 via-yellow-400/20 to-cyan-500/15 blur-[65px] sm:blur-[90px] animate-pulse-glow pointer-events-none"
      />

      {/* Secondary Violet/Cyan Ionization Glow */}
      <div
        aria-hidden="true"
        className="absolute -inset-6 sm:-inset-10 rounded-full bg-gradient-to-br from-indigo-500/20 via-purple-600/15 to-amber-500/20 blur-[45px] sm:blur-[60px] pointer-events-none"
      />

      {/* Observatory Telemetry & Orbital Magnetic Field Rings */}
      <div
        aria-hidden="true"
        className="absolute w-[340px] h-[340px] sm:w-[460px] sm:h-[460px] lg:w-[540px] lg:h-[540px] rounded-full border border-cyan-400/15 border-dashed animate-slow-orbit pointer-events-none flex items-center justify-center"
      >
        {/* Orbital node marker */}
        <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cyan-400 shadow-[0_0_12px_#38bdf8] border border-white" />
        <div className="absolute -bottom-1 left-1/3 w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_10px_#fbbf24]" />
      </div>

      <div
        aria-hidden="true"
        className="absolute w-[300px] h-[300px] sm:w-[410px] sm:h-[410px] lg:w-[490px] lg:h-[490px] rounded-full border border-violet-400/10 animate-reverse-orbit pointer-events-none"
      >
        {/* Ticks on perimeter */}
        <div className="absolute top-1/2 -right-1 w-2 h-[1px] bg-cyan-400/40" />
        <div className="absolute top-1/2 -left-1 w-2 h-[1px] bg-cyan-400/40" />
      </div>

      {/* Main Celestial Body Container */}
      <div
        className={`relative w-[240px] h-[240px] sm:w-[320px] sm:h-[320px] md:w-[360px] md:h-[360px] lg:w-[420px] lg:h-[420px] rounded-full animate-float-slow transition-transform duration-700 ease-out ${
          isHovered ? 'scale-105' : 'scale-100'
        }`}
      >
        {/* Radial Coronal Flares and Light Rays */}
        <div
          aria-hidden="true"
          className="absolute -inset-4 rounded-full bg-[radial-gradient(circle_at_50%_50%,rgba(254,240,138,0.45)_0%,rgba(245,158,11,0.25)_45%,rgba(234,88,12,0.1)_65%,transparent_80%)] animate-pulse-glow pointer-events-none"
        />

        {/* Photosphere / Star Sphere */}
        <div className="relative w-full h-full rounded-full overflow-hidden shadow-[0_0_60px_rgba(245,158,11,0.45),inset_0_0_50px_rgba(255,255,255,0.7)]">
          {/* Base 3D Volumetric Plasma Gradient */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              background: `radial-gradient(circle at 35% 32%, #ffffff 0%, #fff7ed 8%, #fef08a 22%, #fbbf24 42%, #f59e0b 60%, #d97706 75%, #9a3412 88%, #431407 100%)`,
            }}
          />

          {/* Animated Surface Granulation / Convection Texture Layer 1 */}
          <div
            className="absolute inset-0 rounded-full opacity-65 mix-blend-color-burn animate-slow-orbit"
            style={{
              background: `radial-gradient(circle at 40% 40%, transparent 20%, rgba(154,52,18,0.8) 70%, #431407 100%),
                           repeating-conic-gradient(from 0deg at 50% 50%, rgba(245,158,11,0.3) 0deg, rgba(234,88,12,0.4) 15deg, rgba(245,158,11,0.2) 30deg, transparent 45deg)`,
            }}
          />

          {/* Animated Convection Texture Layer 2 (Cross-directional) */}
          <div
            className="absolute inset-0 rounded-full opacity-55 mix-blend-overlay animate-reverse-orbit"
            style={{
              background: `radial-gradient(circle at 60% 65%, rgba(255,255,255,0.8) 0%, transparent 40%),
                           repeating-radial-gradient(circle at 50% 50%, rgba(254,240,138,0.3) 0px, transparent 8px, rgba(249,115,22,0.3) 16px)`,
            }}
          />

          {/* Solar Flare / Convective Hotspots */}
          <div
            className="absolute top-[22%] left-[28%] w-16 h-16 sm:w-24 sm:h-24 rounded-full bg-white/70 blur-md animate-pulse-glow"
          />
          <div
            className="absolute bottom-[30%] right-[25%] w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-amber-200/50 blur-md"
          />

          {/* Atmospheric Limb Darkening & Rim Scattering (Blue Rayleigh Rim) */}
          <div
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              boxShadow: `
                inset 0 0 45px 12px rgba(67, 20, 7, 0.95),
                inset 0 0 15px 4px rgba(56, 189, 248, 0.45),
                0 0 35px 6px rgba(251, 191, 36, 0.5)
              `,
            }}
          />
        </div>

        {/* Floating Telemetry Coordinates Tag */}
        <div className="absolute -bottom-3 sm:-bottom-5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full glass-surface border border-white/10 flex items-center gap-2 whitespace-nowrap shadow-xl">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] font-mono tracking-widest text-slate-300">
            SPECTRAL G2V // 5778 K
          </span>
        </div>

        {/* Astronomical Reticle Brackets (NASA Observatory Vibe) */}
        <div
          aria-hidden="true"
          className="absolute -top-3 -left-3 w-4 h-4 border-t border-l border-cyan-400/50 pointer-events-none"
        />
        <div
          aria-hidden="true"
          className="absolute -top-3 -right-3 w-4 h-4 border-t border-r border-cyan-400/50 pointer-events-none"
        />
        <div
          aria-hidden="true"
          className="absolute -bottom-3 -left-3 w-4 h-4 border-b border-l border-cyan-400/50 pointer-events-none"
        />
        <div
          aria-hidden="true"
          className="absolute -bottom-3 -right-3 w-4 h-4 border-b border-r border-cyan-400/50 pointer-events-none"
        />
      </div>
    </div>
  );
}
