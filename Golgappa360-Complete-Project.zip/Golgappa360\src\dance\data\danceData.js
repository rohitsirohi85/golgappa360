/**
 * MOTION IS ART — Dance Academy Configuration & Content Data
 * All business information, program details, faculty profiles, and media assets
 * are centralized here for easy customization.
 */

export const ACADEMY_CONFIG = {
  brandName: 'MOTION IS ART',
  shortName: 'MIA',
  tagline: 'YOUR BODY. YOUR RHYTHM. YOUR ART.',
  coreStatement: 'Every movement tells a story.',
  supportingCopy: 'Discover your movement. Build your style. Find your people.',
  contact: {
    email: 'admissions@motionisart.dance',
    phone: '+1 (555) 382-6684',
    address: 'Studio Bay 04, The Arts Warehouse District',
    city: 'Metropolis, NY 10013',
    hours: 'Mon – Fri: 08:00 – 22:30 | Sat – Sun: 09:00 – 21:00',
    emergencyContact: 'concierge@motionisart.dance'
  },
  stats: [
    { value: '05', label: 'Disciplined Programs', suffix: '' },
    { value: '18+', label: 'Master Artists', suffix: '' },
    { value: '4,200', label: 'Sq Ft Sprung Timber', suffix: 'ft²' },
    { value: '12:1', label: 'Max Dancer Ratio', suffix: '' }
  ]
};

export const DANCE_PROGRAMS = [
  {
    id: 'hip-hop',
    name: 'Hip-Hop',
    subtitle: 'Groove Architecture & Street Dynamics',
    tagline: 'Raw bounce, polyrhythmic musicality, and authentic street cyphers.',
    image: '/images/dance/hiphop.jpg',
    tempoRange: '85 – 110 BPM',
    intensity: 'High Energy',
    levels: ['Foundation (Beg)', 'Street Mechanics (Int)', 'Cypher Intensive (Adv)'],
    description: 'Explore the foundations of authentic hip-hop dance — from Old School party grooves and 90s social dances to intricate contemporary bounce and polyrhythmic pocket work. Build physical stamina, weight shifts, and freestyle confidence in an open, judgment-free cypher.',
    highlights: [
      'Authentic foundational groove & bounce mechanics',
      'Musical polyrhythms and sub-bass pocket timing',
      'Freestyle cypher psychology and solo storytelling',
      'Crew synchronicity and battle etiquette'
    ],
    schedulePreview: 'Mon / Wed / Fri — 18:30 & 20:00',
    leadInstructor: 'Aria Vance',
    badge: 'Flagship Program'
  },
  {
    id: 'popping',
    name: 'Popping',
    subtitle: 'Muscular Isolation & Geometric Illusion',
    tagline: 'Hits, dime stops, waving, strobing, and cinematic robotic flow.',
    image: '/images/dance/popping.jpg',
    tempoRange: '95 – 125 BPM (Electro-Funk)',
    intensity: 'Precision Focused',
    levels: ['Muscle Control (Beg)', 'Illusion Concepts (Int)', 'Masterclass Isolation (Adv)'],
    description: 'Deconstruct body mechanics through the art of contraction and release. Master hit strength, gliding, liquid waving, strobing, and dime stops. Transform your physical body into a living visual frequency matching intricate funk and synth basslines.',
    highlights: [
      'Contraction & relaxation kinetics (The Pop / Hit)',
      'Floating, gliding, and weightless ground illusions',
      'Liquid waving, ticking, and strobing frequency control',
      'Robotics, animation storytelling, and micro-movements'
    ],
    schedulePreview: 'Tue / Thu — 19:00 | Sat — 14:00',
    leadInstructor: 'Marcus "Apex" Chen',
    badge: 'Signature Style'
  },
  {
    id: 'bollywood',
    name: 'Bollywood Fusion',
    subtitle: 'Theatrical Expression & Urban Fusion',
    tagline: 'High-octane cinematic storytelling infused with modern footwork and lyricism.',
    image: '/images/dance/bollywood.jpg',
    tempoRange: '100 – 135 BPM',
    intensity: 'Vibrant & Theatrical',
    levels: ['Rhythm & Mudra (Beg)', 'Contemporary Fusion (Int)', 'Stage Ensemble (Adv)'],
    description: 'A cutting-edge contemporary evolution of Indian cinematic dance. We combine the expressive facial dynamism (abhinaya) and rhythmic footwork of Indian semi-classical and folk traditions with modern urban choreography, sharp isolations, and theatrical staging.',
    highlights: [
      'Expressive theatrical storytelling & emotional resonance',
      'Intricate semi-classical mudras blended with urban flow',
      'Dynamic speed changes and dramatic crescendo staging',
      'Cinematic ensemble choreographies ready for the lens'
    ],
    schedulePreview: 'Wed / Fri — 17:30 | Sun — 11:30',
    leadInstructor: 'Devika S.',
    badge: 'Cultural Innovation'
  },
  {
    id: 'contemporary',
    name: 'Contemporary',
    subtitle: 'Weight Dynamics, Release & Floor Flow',
    tagline: 'Floorwork, release technique, emotional narrative, and effortless momentum.',
    image: '/images/dance/contemporary.jpg',
    tempoRange: 'Fluid / Freeform Tempo',
    intensity: 'Expressive Depth',
    levels: ['Floor Anatomy (Beg)', 'Release & Momentum (Int)', 'Repertoire Laboratory (Adv)'],
    description: 'Break free from rigid geometries. Our contemporary program emphasizes floorwork transitions, gravity surrender, dynamic suspension, and organic breath-driven movement. Learn to utilize momentum rather than muscular strain to generate effortless power.',
    highlights: [
      'Seamless floorwork spirals and impactless landings',
      'Release technique and kinetic momentum conservation',
      'Partnering weight exchange and counterbalances',
      'Emotional narrative composition and improvisational scores'
    ],
    schedulePreview: 'Mon / Thu — 10:00 & 18:00',
    leadInstructor: 'Elena Rostova',
    badge: 'Artistic Core'
  },
  {
    id: 'urban-choreo',
    name: 'Urban Choreography',
    subtitle: 'Visual Musicality & Ensemble Staging',
    tagline: 'Micro-musicality, speed control, cinematic formations, and stage presence.',
    image: '/images/dance/urban-choreo.jpg',
    tempoRange: '70 – 130 BPM (Varied)',
    intensity: 'High Precision',
    levels: ['Musicality 101 (Beg)', 'Set Piece Dynamics (Int)', 'Pro Performance Crew (Adv)'],
    description: 'The pinnacle of modern dance performance. Urban Choreography challenges dancers to interpret micro-sounds, hi-hat rolls, vocal nuances, and sonic textures with razor-sharp physical precision. Develop camera awareness, ensemble stagecraft, and lightning-fast retention.',
    highlights: [
      'Texture differentiation: soft accents vs. razor stops',
      'Complex formation shifts and stage geometry',
      'Speed changes: half-time grooves into double-time bursts',
      'On-camera performance execution and video archive shoots'
    ],
    schedulePreview: 'Tue / Fri — 20:30 | Sat — 16:30',
    leadInstructor: 'Aria Vance',
    badge: 'Performance Crew'
  }
];

export const INSTRUCTORS = [
  {
    id: 'elena-rostova',
    name: 'Elena Rostova',
    role: 'Head of Contemporary & Flow Mechanics',
    discipline: 'Contemporary & Floorwork',
    image: '/images/dance/instructor-1.jpg',
    quote: 'Gravity is not a boundary to fight; it is the most dependable partner you will ever dance with.',
    experience: '12 Years Studio Practice',
    focusTags: ['Floor Mechanics', 'Release Technique', 'Spine Articulation', 'Improvisation'],
    bioPlaceholder: 'Specializes in low-impact kinetic transitions, weight suspension, and breath-directed flow architectures. Guest master practitioner at international contemporary dance summits.'
  },
  {
    id: 'marcus-chen',
    name: 'Marcus "Apex" Chen',
    role: 'Resident Artist — Popping & Animation',
    discipline: 'Popping, Boogaloo & Robotics',
    image: '/images/dance/instructor-2.jpg',
    quote: 'The hit is only as powerful as the stillness that precedes it.',
    experience: '14 Years Street & Battle Practice',
    focusTags: ['Hits & Snaps', 'Dime Stops', 'Floating & Gliding', 'Liquid Illusion'],
    bioPlaceholder: 'Veteran of premier international street cyphers and animation dance exhibitions. Renowned for surgical isolations and deep preservation of West Coast funk heritage.'
  },
  {
    id: 'aria-vance',
    name: 'Aria Vance',
    role: 'Director of Urban Choreography',
    discipline: 'Urban Choreography & Hip-Hop',
    image: '/images/dance/instructor-3.jpg',
    quote: 'Anyone can hit a beat; great artists let the silence between beats breathe through their limbs.',
    experience: '10 Years Choreography & Creative Direction',
    focusTags: ['Micro-Musicality', 'Formation Staging', 'Camera Execution', 'Speed Dynamics'],
    bioPlaceholder: 'Creative director for experimental visual albums and world-tour performance sets. Combines street authenticity with cinematic visual pacing.'
  },
  {
    id: 'devika-s',
    name: 'Devika S.',
    role: 'Master Faculty — Contemporary Bollywood Fusion',
    discipline: 'Bollywood Fusion & Theatrical Movement',
    image: '/images/dance/instructor-4.jpg',
    quote: 'Every gesture is a word; every sequence is an ancient chapter retold in modern rhythm.',
    experience: '11 Years Classical & Commercial Stage',
    focusTags: ['Abhinaya Expression', 'Semi-Classical Footwork', 'Stage Charisma', 'Urban Fusion'],
    bioPlaceholder: 'Cross-disciplinary movement artist trained in classical Indian dance traditions and contemporary European release technique. Pioneers modern South Asian theatrical choreographies.'
  }
];

export const STUDIO_FEATURES = [
  {
    id: 'flooring',
    title: 'Dual-Cushion Sprung Timber',
    category: 'Kinetic Preservation',
    desc: '4,200 sq ft of multi-layered Siberian birch with custom neoprene absorption pads that dampen joint stress by up to 64% during repetitive impact work.',
    metric: '64% Less Joint Stress'
  },
  {
    id: 'acoustics',
    title: 'Acoustically Tuned Meyer Sound Arrays',
    category: 'Sonic Immersion',
    desc: 'Linear-response architectural subwoofers tuned to prevent ear fatigue while delivering physical sub-bass clarity so dancers feel every 32nd-note subdivision.',
    metric: 'Zero Resonant Echo'
  },
  {
    id: 'lighting',
    title: 'Cinematic Directional Rig',
    category: 'Visual Staging',
    desc: 'Adjustable high-CRI continuous daylight skylights and programmable tungsten spotlight arrays designed specifically for live rehearsal and archival filming.',
    metric: '98+ CRI Natural Color'
  },
  {
    id: 'environment',
    title: 'Medical-Grade HEPA Climate Flow',
    category: 'Performance Sanctuary',
    desc: 'Continuous fresh air exchange cycle every 7 minutes, maintaining 20°C ambient room temperature and optimal humidity to keep muscles warm without overheating.',
    metric: '7 Min Air Cycle'
  }
];

export const GALLERY_ITEMS = [
  {
    id: 'gal-1',
    src: '/images/dance/gallery-1.jpg',
    alt: 'Dancer silhouette in motion during evening rehearsal',
    caption: 'Kinetic Silhouette // Night Cypher',
    category: 'Light & Shadow',
    aspect: 'tall'
  },
  {
    id: 'gal-2',
    src: '/images/dance/gallery-2.jpg',
    alt: 'Contemporary dancer leaping in mid-air suspension',
    caption: 'Zero Gravity // Release Laboratory',
    category: 'Contemporary',
    aspect: 'wide'
  },
  {
    id: 'gal-3',
    src: '/images/dance/gallery-3.jpg',
    alt: 'Stage performance lighting and dramatic atmosphere',
    caption: 'Stagecraft // The Grand Showcase',
    category: 'Performance',
    aspect: 'square'
  },
  {
    id: 'gal-4',
    src: '/images/dance/gallery-4.jpg',
    alt: 'Studio rehearsal session with dancers focused in unison',
    caption: 'Synchronicity // Urban Choreography Collective',
    category: 'Ensemble',
    aspect: 'tall'
  },
  {
    id: 'gal-5',
    src: '/images/dance/gallery-5.jpg',
    alt: 'Live festival and dance performance energy',
    caption: 'Electric Frequency // Weekend Cypher Session',
    category: 'Community',
    aspect: 'wide'
  },
  {
    id: 'gal-6',
    src: '/images/dance/gallery-6.jpg',
    alt: 'Expressive movement study in architectural studio space',
    caption: 'Architectural Movement // Morning Study',
    category: 'Studio Atmosphere',
    aspect: 'square'
  }
];

export const FAQ_ITEMS = [
  {
    q: 'Do I need prior dance experience to attend a trial class?',
    a: 'Not at all. Every discipline offers Level 01 (Foundation) classes specifically designed for complete beginners with zero previous dance background. Our instructors break down physical mechanics step-by-step.'
  },
  {
    q: 'What should I wear and bring to my trial session?',
    a: 'Wear comfortable, non-restrictive athletic attire (oversized t-shirt, sweatpants, or breathable activewear). Bring clean, dry indoor sneakers for street styles, or dance socks/bare feet for Contemporary. We provide water stations and changing lockers.'
  },
  {
    q: 'How does the Trial Class booking work?',
    a: 'Select your preferred discipline and session date using the "Book a Trial" button. You will receive an instant digital Trial Pass voucher and studio arrival briefing. Trial passes are valid for 14 days.'
  },
  {
    q: 'Can I switch disciplines after joining?',
    a: 'Yes. Academy memberships grant full cross-discipline flexibility, allowing you to train in Popping on Tuesday and Contemporary on Thursday.'
  }
];
