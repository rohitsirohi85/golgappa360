import React from 'react';

/**
 * StarEmptyState — Rendered when search or filter returns zero matches
 * Clean astronomical observation empty state:
 * - NO STELLAR MATCH
 * - “No stars in our current catalog match your search.”
 * - “Clear Search”
 * - Glowing celestial visual
 */
export default function StarEmptyState({ onReset }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 sm:py-24 text-center select-none w-full max-w-md mx-auto">
      {/* Small Glowing Celestial Visual */}
      <div className="relative w-24 h-24 mb-6 flex items-center justify-center">
        {/* Soft Radial Cosmic Glow */}
        <div className="absolute inset-0 rounded-full bg-cyan-500/15 blur-xl animate-pulse-glow" />

        {/* Orbit Ring Guides */}
        <div className="absolute inset-1 rounded-full border border-cyan-400/25 border-dashed animate-slow-orbit" />
        <div className="absolute inset-4 rounded-full border border-indigo-400/20 animate-reverse-orbit" />

        {/* Outer Telemetry Reticle Frame */}
        <div className="absolute inset-0 border border-white/10 rounded-2xl" />

        {/* Glowing Star Icon Core */}
        <div className="relative w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-indigo-500 flex items-center justify-center shadow-[0_0_20px_#38bdf8]">
          <span className="text-white text-base font-bold">✦</span>
        </div>
      </div>

      {/* Heading */}
      <h3 className="font-display text-2xl font-semibold tracking-tight text-white mb-2">
        NO STELLAR MATCH
      </h3>

      {/* Subtext */}
      <p className="font-sans text-sm text-slate-400 mb-6 max-w-sm leading-relaxed">
        No stars in our current catalog match your search.
      </p>

      {/* Clear Search Action Button */}
      {onReset && (
        <button
          type="button"
          onClick={onReset}
          className="px-6 py-2.5 rounded-full glass-surface border border-cyan-400/40 text-cyan-300 hover:text-white hover:bg-cyan-500/20 text-xs font-mono tracking-wider transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 shadow-[0_0_15px_rgba(56,189,248,0.2)]"
        >
          Clear Search
        </button>
      )}
    </div>
  );
}
