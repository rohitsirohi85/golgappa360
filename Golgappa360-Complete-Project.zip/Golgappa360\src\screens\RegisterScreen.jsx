import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone, Lock, Car, BatteryCharging, Zap } from 'lucide-react';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { Header } from '../components/common/Header';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';

export const RegisterScreen = () => {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { showToast } = useUI();

  const [fullName, setFullName] = useState('Suman');
  const [email, setEmail] = useState('suman@example.com');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [password, setPassword] = useState('password123');
  const [confirmPassword, setConfirmPassword] = useState('password123');
  const [vehicleType, setVehicleType] = useState('Electric Car / SUV');
  const [vehicleModel, setVehicleModel] = useState('Tesla Model 3');
  const [batteryCapacity, setBatteryCapacity] = useState('60');

  const handleRegister = (e) => {
    e.preventDefault();
    if (!fullName || !email) {
      showToast('Please fill all required fields', 'error');
      return;
    }
    if (password !== confirmPassword) {
      showToast('Passwords do not match', 'error');
      return;
    }

    register({
      fullName,
      email,
      phone,
      vehicleModel,
      batteryCapacity,
    });

    showToast('Account & vehicle registered successfully!', 'success');
    navigate('/home');
  };

  return (
    <div className="min-h-full flex flex-col justify-between pb-6 select-none">
      <Header title="Create Account" showBack onBack={() => navigate('/login')} />

      <form onSubmit={handleRegister} className="px-6 py-4 space-y-4">
        {/* Intro */}
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Register with EV Smart ⚡
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure your EV specifications for tailored charging times.
          </p>
        </div>

        {/* Personal Details */}
        <div className="space-y-3 pt-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#00F5A0]">
            1. Personal Details
          </span>

          <Input
            label="Full Name"
            placeholder="e.g. Suman"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            icon={User}
            required
          />

          <Input
            label="Email Address"
            type="email"
            placeholder="suman@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            icon={Mail}
            required
          />

          <Input
            label="Mobile Number"
            type="tel"
            placeholder="+91 98765 43210"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            icon={Phone}
            required
          />

          <Input
            label="Password"
            type="password"
            placeholder="Create password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            icon={Lock}
            required
          />

          <Input
            label="Confirm Password"
            type="password"
            placeholder="Confirm password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            icon={Lock}
            required
          />
        </div>

        {/* Vehicle Specification Details */}
        <div className="space-y-3 pt-4 border-t border-white/10">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#00E5FF]">
            2. Electric Vehicle Profile
          </span>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-300">Vehicle Type</label>
            <select
              value={vehicleType}
              onChange={(e) => setVehicleType(e.target.value)}
              className="w-full rounded-xl bg-[#0D1527] text-white text-sm border border-white/10 px-3.5 py-2.5 outline-none focus:border-[#00F5A0]"
            >
              <option value="Electric Car / SUV">Electric Car / SUV</option>
              <option value="Electric 2-Wheeler">Electric 2-Wheeler</option>
              <option value="Commercial EV">Commercial EV Fleet</option>
            </select>
          </div>

          <Input
            label="Vehicle Model"
            placeholder="e.g. Tesla Model 3"
            value={vehicleModel}
            onChange={(e) => setVehicleModel(e.target.value)}
            icon={Car}
            helperText="Example: Tesla Model 3, Tata Nexon EV, Hyundai Ioniq 5"
            required
          />

          <Input
            label="Battery Capacity (kWh)"
            type="number"
            placeholder="60"
            value={batteryCapacity}
            onChange={(e) => setBatteryCapacity(e.target.value)}
            icon={BatteryCharging}
            helperText="Used to estimate charging times & rates"
            required
          />
        </div>

        {/* Action Button */}
        <div className="pt-4">
          <Button type="submit" size="lg" fullWidth>
            Create Account
          </Button>
        </div>

        {/* Existing account link */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-400">
            Already have an account?{' '}
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="text-[#00F5A0] font-semibold hover:underline"
            >
              Login
            </button>
          </p>
        </div>
      </form>
    </div>
  );
};
