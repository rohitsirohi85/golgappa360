/**
 * STELLAR 2.0 — Cosmic Discovery Engine
 * 
 * Curated discovery pool, weighted random selection, memory tracking (localStorage),
 * and educational discovery rationales ("Why this object?").
 * 
 * DISCLAIMER: Curated UX selection mechanism for educational exploration.
 * Does not represent physical astronomical rarity or real-time event tracking.
 */

import {
  ALL_SEARCHABLE_OBJECTS,
  CELESTIAL_CATEGORIES,
} from '../data/celestialObjects.js';

export const DISCOVERY_HISTORY_STORAGE_KEY = 'stellar_recent_discoveries';
export const DISCOVERY_COUNT_STORAGE_KEY = 'stellar_session_discovery_count';
export const MAX_DISCOVERY_HISTORY = 10;

/**
 * Curated "Why this object?" educational discovery rationales
 * Based strictly on verified object catalog data
 */
export const DISCOVERY_REASONS = {
  // Black Holes
  'sagittarius-a-star': 'The supermassive gravitational anchor residing at the dynamical core of our Milky Way galaxy, verified by the Event Horizon Telescope.',
  'm87-star': 'A colossal 6.5-billion-solar-mass black hole unleashes a 5,000-light-year relativistic jet and produced humanity’s historic first direct black hole image.',
  'cygnus-x1': 'The first confirmed stellar-mass black hole discovered in 1964, bound in an intense X-ray binary dance with a blue supergiant.',

  // Pulsars & Neutron Stars
  'crab-pulsar': 'A city-sized superdense neutron star remnant of the historic SN 1054 supernova, spinning 30 times each second to power the Crab Nebula.',
  'vela-pulsar': 'A rapidly rotating magnetized neutron star sweeping radio and gamma-ray synchrotron beams across space like a cosmic lighthouse.',

  // Nebulae
  'orion-nebula': 'The closest massive stellar nursery to Earth, where thousands of nascent protostars and protoplanetary discs are actively forming.',
  'ring-nebula': 'A classic glowing planetary nebula shell cast off by a dying intermediate-mass star, leaving behind an incandescent central white dwarf.',
  'crab-nebula': 'The expanding synchrotron gas remnant of the 1054 CE supernova recorded by ancient Chinese and Arab astronomers.',

  // Star Clusters
  'pleiades': 'The legendary "Seven Sisters" open star cluster, blazing with youthful luminous blue B-type stars veiled in reflection nebulae.',
  'hercules-cluster': 'A breathtaking globular swarm containing hundreds of thousands of ancient stars tightly packed into a sphere 145 light-years across.',

  // Galaxies
  'andromeda-galaxy': 'Our majestic spiral neighbour spanning 220,000 light-years and harbouring approximately one trillion stars, bound on a future orbital merger with the Milky Way.',
  'triangulum-galaxy': 'The third-largest member of our Local Group, an active spiral galaxy teeming with giant stellar nurseries.',

  // Solar System Planets
  'sun': 'The central thermonuclear furnace of our planetary system, fusing 600 million tons of hydrogen each second and binding all planetary orbits.',
  'mercury': 'The closest planet to the Sun, racing in an eccentric orbit with scorching 430°C days and freezing −180°C nights.',
  'venus': 'A runaway greenhouse world veiled in dense carbon dioxide and sulfuric acid clouds with surface pressures equivalent to 900m ocean depth.',
  'earth': 'The dynamic water world and cradle of all known life, shielded by a geomagnetic dipole dynamo and an active hydrosphere.',
  'moon': 'Earth’s tidally synchronized natural satellite featuring ancient volcanic basalt seas (maria) and heavy impact cratering.',
  'mars': 'The iron-oxide Red Planet hosting the solar system’s tallest volcano (Olympus Mons) and vast dried river channels.',
  'jupiter': 'The gas giant titan containing more mass than all other planets combined, flanked by an iconic centuries-old Great Red Spot storm.',
  'saturn': 'The ringed jewel of our solar system, encircled by thousands of shimmering ringlets of pure water ice and rocky fragments.',
  'uranus': 'An icy turquoise giant with an extreme 97.8° axial tilt, rolling along its orbital plane like a cosmic barrel.',
  'neptune': 'A tempestuous ice giant where supersonic methane winds rage at up to 2,100 km/h in the outer perimeter of our planetary system.',

  // Supergiants & Giants
  'betelgeuse': 'A colossal red supergiant in Orion pulsing on the brink of a future core-collapse supernova, so gigantic it would swallow Mars and Jupiter.',
  'rigel': 'A piercing blue supergiant radiating tens of thousands of times more luminosity than our Sun from the southern foot of Orion.',
  'aldebaran': 'The glaring orange giant representing the "Eye of the Bull" in Taurus, having exhausted hydrogen in its core.',
  'antares': 'The searing red supergiant heart of Scorpius, serving in antiquity as the celestial rival of Mars.',

  // Bright & Distinct Stars
  'sirius': 'The brightest star in Earth’s night sky, blazing with piercing white-blue brilliance only 8.6 light-years away.',
  'sirius-b': 'The historic white dwarf companion to Sirius A, compressing the mass of the Sun into a sphere smaller than Earth.',
  'polaris': 'The famous North Star, an essential navigational anchor aligned closely with Earth’s northern rotational axis.',
  'proxima-centauri': 'A faint red dwarf flare star reigning as the closest known individual star to our Solar System at 4.24 light-years.',
  'vega': 'A radiant zero-magnitude reference star in Lyra, which served as Earth’s northern pole star 14,000 years ago.',

  // Constellations
  'orion': 'One of the most recognizable constellations visible from both hemispheres, anchored by Betelgeuse, Rigel, and the three belt stars.',
  'ursa-major': 'The Great Bear constellation, renowned for the Big Dipper asterism which guides skywatchers directly toward Polaris.',
  'canis-major': 'The Greater Dog constellation trailing Orion across the winter skies, home to dazzling Sirius.',
  'scorpius': 'A magnificent zodiacal scorpion pattern curling across the Milky Way plane, dominated by the supergiant Antares.',
  'cassiopeia': 'A distinct celestial W-shaped pattern in the northern circumpolar sky representing the mythological queen of Ethiopia.',
  'leo': 'A prominent springtime zodiac constellation marked by the distinctive sickle asterism and blue-white Regulus.',
};

/**
 * Assigns selection weights to balance curiosity across diverse cosmic classes
 * High weights for rare/exotic phenomena; medium weights for standard stars.
 */
function getDiscoveryWeight(obj) {
  if (!obj || !obj.category) return 1.0;

  switch (obj.category) {
    case CELESTIAL_CATEGORIES.BLACK_HOLE:
      return 3.5;
    case CELESTIAL_CATEGORIES.PULSAR:
    case CELESTIAL_CATEGORIES.NEUTRON_STAR:
      return 3.2;
    case CELESTIAL_CATEGORIES.NEBULA:
      return 3.0;
    case CELESTIAL_CATEGORIES.GALAXY:
      return 3.0;
    case CELESTIAL_CATEGORIES.STAR_CLUSTER:
      return 2.8;
    case CELESTIAL_CATEGORIES.WHITE_DWARF:
      return 2.6;
    case CELESTIAL_CATEGORIES.PLANET:
    case CELESTIAL_CATEGORIES.NATURAL_SATELLITE:
      return 2.4;
    case CELESTIAL_CATEGORIES.CONSTELLATION:
      return 2.2;
    case CELESTIAL_CATEGORIES.STAR:
      // Give supergiants and named bright stars a bit more weight than dim dwarfs
      if (obj.subtype?.toLowerCase().includes('supergiant') || obj.id === 'sirius' || obj.id === 'sun') {
        return 2.0;
      }
      return 1.4;
    default:
      return 1.0;
  }
}

// In-memory fallback for non-browser or test environments
let inMemoryHistory = [];
let inMemoryCount = 0;

/**
 * Retrieves the list of recently discovered object IDs from localStorage
 */
export function getRecentDiscoveries() {
  if (typeof window === 'undefined') return inMemoryHistory;
  try {
    const raw = localStorage.getItem(DISCOVERY_HISTORY_STORAGE_KEY);
    if (!raw) return inMemoryHistory;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : inMemoryHistory;
  } catch (err) {
    console.warn('Failed to parse stellar_recent_discoveries', err);
    return inMemoryHistory;
  }
}

/**
 * Adds an object ID to the recent discovery memory
 */
export function recordDiscovery(objectId) {
  if (!objectId) return;
  inMemoryHistory = [objectId, ...inMemoryHistory.filter((id) => id !== objectId)].slice(0, MAX_DISCOVERY_HISTORY);
  inMemoryCount++;

  if (typeof window === 'undefined') return;
  try {
    const current = getRecentDiscoveries().filter((id) => id !== objectId);
    const updated = [objectId, ...current].slice(0, MAX_DISCOVERY_HISTORY);
    localStorage.setItem(DISCOVERY_HISTORY_STORAGE_KEY, JSON.stringify(updated));

    // Increment session discovery count
    const sessionCount = getSessionDiscoveryCount() + 1;
    localStorage.setItem(DISCOVERY_COUNT_STORAGE_KEY, sessionCount.toString());
  } catch (err) {
    console.warn('Failed to record discovery in localStorage', err);
  }
}

/**
 * Returns session discovery counter
 */
export function getSessionDiscoveryCount() {
  if (typeof window === 'undefined') return inMemoryCount;
  try {
    const raw = localStorage.getItem(DISCOVERY_COUNT_STORAGE_KEY);
    return raw ? parseInt(raw, 10) || inMemoryCount : inMemoryCount;
  } catch {
    return inMemoryCount;
  }
}

/**
 * Clears recent discovery history
 */
export function clearDiscoveryHistory() {
  inMemoryHistory = [];
  inMemoryCount = 0;
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(DISCOVERY_HISTORY_STORAGE_KEY);
  } catch (err) {
    console.warn('Failed to clear discovery history', err);
  }
}

/**
 * Returns an educational discovery explanation for an object
 */
export function getDiscoveryExplanation(obj) {
  if (!obj) return 'Selected from the STELLAR discovery catalog.';

  if (DISCOVERY_REASONS[obj.id]) {
    return DISCOVERY_REASONS[obj.id];
  }

  if (obj.interestingFact) {
    return obj.interestingFact;
  }

  if (obj.description) {
    // Extract first sentence
    const firstSentence = obj.description.split('. ')[0];
    return firstSentence.endsWith('.') ? firstSentence : `${firstSentence}.`;
  }

  return `Selected because it represents an intriguing example of a ${obj.subtype || obj.category || 'celestial object'}.`;
}

/**
 * Smart weighted random object selection from existing project data
 * 
 * @param {string} categoryFilter - 'ALL' | 'STARS' | 'PLANETS' | 'BLACK_HOLES' | 'NEBULAE' | 'GALAXIES' | 'CONSTELLATIONS'
 * @param {string|null} currentObjectId - ID of currently viewed object to exclude
 * @returns {object|null} Selected celestial object
 */
export function selectCuratedDiscovery(categoryFilter = 'ALL', currentObjectId = null) {
  const allObjects = ALL_SEARCHABLE_OBJECTS.filter(Boolean);
  if (!allObjects || allObjects.length === 0) return null;

  // 1. Filter by category if requested
  let candidates = allObjects.filter((obj) => {
    if (!obj || !obj.id) return false;
    if (currentObjectId && obj.id === currentObjectId) return false;

    if (!categoryFilter || categoryFilter === 'ALL') return true;

    switch (categoryFilter) {
      case 'STARS':
        return obj.category === CELESTIAL_CATEGORIES.STAR || obj.category === CELESTIAL_CATEGORIES.WHITE_DWARF;
      case 'PLANETS':
        return obj.category === CELESTIAL_CATEGORIES.PLANET || obj.category === CELESTIAL_CATEGORIES.NATURAL_SATELLITE || obj.isSun;
      case 'BLACK_HOLES':
        return obj.category === CELESTIAL_CATEGORIES.BLACK_HOLE;
      case 'NEBULAE':
        return obj.category === CELESTIAL_CATEGORIES.NEBULA;
      case 'GALAXIES':
        return obj.category === CELESTIAL_CATEGORIES.GALAXY;
      case 'CONSTELLATIONS':
        return obj.category === CELESTIAL_CATEGORIES.CONSTELLATION || obj.isConstellation;
      case 'OTHER':
        return (
          obj.category === CELESTIAL_CATEGORIES.PULSAR ||
          obj.category === CELESTIAL_CATEGORIES.NEUTRON_STAR ||
          obj.category === CELESTIAL_CATEGORIES.STAR_CLUSTER
        );
      default:
        return true;
    }
  });

  if (candidates.length === 0) {
    candidates = allObjects;
  }

  // 2. Exclude recently discovered objects to avoid immediate repetition
  const recentHistory = getRecentDiscoveries();
  const freshCandidates = candidates.filter((obj) => !recentHistory.includes(obj.id));

  // If pool of fresh candidates is large enough, pick from fresh ones
  const finalPool = freshCandidates.length > 0 ? freshCandidates : candidates;

  // 3. Weighted random selection
  const weights = finalPool.map(getDiscoveryWeight);
  const totalWeight = weights.reduce((sum, w) => sum + w, 0);

  let randomVal = Math.random() * totalWeight;
  for (let i = 0; i < finalPool.length; i++) {
    randomVal -= weights[i];
    if (randomVal <= 0) {
      const selected = finalPool[i];
      recordDiscovery(selected.id);
      return selected;
    }
  }

  // Fallback
  const fallback = finalPool[Math.floor(Math.random() * finalPool.length)] || allObjects[0];
  if (fallback) {
    recordDiscovery(fallback.id);
  }
  return fallback;
}
