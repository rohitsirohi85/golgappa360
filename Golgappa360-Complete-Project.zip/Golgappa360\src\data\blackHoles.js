/**
 * STELLAR 2.0 — Black Hole Database & Scientific Architecture (U7)
 * 
 * Verified astronomical records, relativistic visual features, and educational
 * data for the dedicated Black Hole exploration experience.
 * 
 * DISCLAIMER: Scientific visualization — not to scale.
 * Illustrative educational visualization.
 */

import { CELESTIAL_CATEGORIES } from './categories.js';

export const BLACK_HOLE_TYPES = {
  STELLAR: {
    id: 'stellar',
    label: 'Stellar-Mass Black Hole',
    massRange: '3 – 100 M☉',
    description: 'Formed by the catastrophic gravitational collapse of massive stars at the end of their thermonuclear lives.',
    visualScale: 0.85,
    diskWidth: 2.2,
    hasCompanionWind: true,
  },
  INTERMEDIATE: {
    id: 'intermediate',
    label: 'Intermediate-Mass Black Hole',
    massRange: '100 – 100,000 M☉',
    description: 'Hypothetical and rare mid-range black holes, potentially seeded by runaway stellar collisions in dense star clusters.',
    visualScale: 1.0,
    diskWidth: 2.5,
    hasCompanionWind: false,
  },
  SUPERMASSIVE: {
    id: 'supermassive',
    label: 'Supermassive Black Hole',
    massRange: 'Millions to Billions M☉',
    description: 'Enormous gravitational anchors residing at the dynamic centers of almost all massive galaxies, shaping galactic evolution.',
    visualScale: 1.25,
    diskWidth: 2.9,
    hasCompanionWind: false,
  },
};

/**
 * Educational Hotspot Features on the Black Hole visualization
 */
export const BLACK_HOLE_FEATURES = {
  'event-horizon': {
    id: 'event-horizon',
    name: 'EVENT HORIZON',
    title: 'Event Horizon',
    shortDescription: 'The event horizon is the boundary beyond which light cannot escape a black hole.',
    detailedDescription: 'Defined by the Schwarzschild radius (r_s = 2GM/c²). Inside this boundary, the escape velocity exceeds the speed of light in vacuum (c ≈ 300,000 km/s). Any matter, radiation, or information that crosses this threshold can never return, inevitably moving toward the central singularity.',
    color: '#000000',
    accentColor: '#f59e0b',
    symbol: '🕳️',
    tag: 'BOUNDARY OF NO RETURN',
  },
  'accretion-disk': {
    id: 'accretion-disk',
    name: 'ACCRETION DISK',
    title: 'Relativistic Accretion Disk',
    shortDescription: 'Superheated material orbiting the black hole can form a bright accretion disk.',
    detailedDescription: 'Gaseous matter and interstellar plasma spiral down toward the black hole along Keplerian orbits. Differential friction between adjacent gas layers heats the inner plasma to millions of degrees Kelvin, producing intense synchrotron radiation and soft X-rays. Due to relativistic Doppler boosting, the approaching limb of the disk appears significantly brighter than the receding limb.',
    color: '#f97316',
    accentColor: '#fdba74',
    symbol: '🪐',
    tag: 'SUPERHEATED PLASMA',
  },
  'photon-ring': {
    id: 'photon-ring',
    name: 'PHOTON RING',
    title: 'Photon Ring / Sphere',
    shortDescription: 'A thin, intense ring of light formed by photons that orbit the black hole multiple times before escaping to our eyes.',
    detailedDescription: 'Located at approximately 1.5 times the Schwarzschild radius (r = 3GM/c² for non-spinning black holes). At this radius, photons graze the black hole along unstable circular orbits. Rays that execute one, two, or multiple complete orbits before deflecting toward our line of sight create a sharp, luminous ring framing the black hole shadow.',
    color: '#fef08a',
    accentColor: '#fde047',
    symbol: '◉',
    tag: 'TRAPPED LIGHT GEODESICS',
  },
  'gravitational-lensing': {
    id: 'gravitational-lensing',
    name: 'GRAVITATIONAL LENSING',
    title: 'Gravitational Lensing & Spacetime Distortion',
    shortDescription: 'Extreme spacetime curvature bends light paths from background stars around the event horizon, creating curved arcs and rings.',
    detailedDescription: 'In accordance with Einstein’s General Theory of Relativity, the concentrated mass of a black hole severely warps the geometry of spacetime. Light rays travelling from stars positioned behind the black hole are bent around the event horizon, producing distorted Einstein rings and projecting a secondary mirrored image of the back of the accretion disk above and below the central shadow.',
    color: '#38bdf8',
    accentColor: '#67e8f9',
    symbol: '◎',
    tag: 'WARPED SPACETIME',
  },
  'relativistic-jets': {
    id: 'relativistic-jets',
    name: 'RELATIVISTIC JETS',
    title: 'Bipolar Relativistic Jets',
    shortDescription: 'Beams of ionized matter accelerated to relativistic speeds along the rotation axis by twisted magnetic fields.',
    detailedDescription: 'When intense magnetic fields trapped within the accretion disk are wound into tight helical funnels by the black hole’s frame-dragging spin (the Blandford-Znajek mechanism), high-energy plasma is collimated and accelerated to over 99% the speed of light along the rotational poles, punching vast cavities through intergalactic space.',
    color: '#a855f7',
    accentColor: '#c084fc',
    symbol: '⚡',
    tag: 'COLLIMATED BEAMS',
  },
};

/**
 * Verified Catalog of Explorable Black Holes
 */
export const BLACK_HOLES_CATALOG = [
  {
    id: 'sagittarius-a-star',
    name: 'Sagittarius A*',
    commonName: 'Milky Way Central Supermassive Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Supermassive Black Hole',
    blackHoleType: 'supermassive',
    constellation: 'Sagittarius',
    hostGalaxy: 'Milky Way Galaxy',
    distance: '≈ 26,670 light-years',
    mass: '≈ 4.297 million × Sun',
    eventHorizonRadius: '≈ 12.7 million km (0.08 AU)',
    spinParameter: 'a* ≈ 0.90 (High Spin)',
    accretionDiskTemp: '≈ 10¹¹ K (Hot, thin RIAF flow)',
    hasJets: false,
    description: 'The supermassive gravitational behemoth residing at the dynamical heart of our Milky Way galaxy. In 2022, the Event Horizon Telescope collaborated across world observatories to resolve its shadow, confirming a searing ring of synchrotron light encircling the event horizon.',
    interestingFact: 'Stars near Sagittarius A*, like S2, whip around it at speeds reaching 8% of the speed of light during their closest orbital periastron.',
    visualColor: '#f59e0b',
    colorHex: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.45)',
    sizeClass: 'black-hole',
    x: 480,
    y: 60,
    tier: 1,
    baseRadius: 10,
    relatedConstellation: 'Sagittarius',
  },
  {
    id: 'm87-star',
    name: 'M87* (Messier 87)',
    commonName: 'First Ever Directly Imaged Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Supermassive Black Hole with Relativistic Jet',
    blackHoleType: 'supermassive',
    constellation: 'Virgo',
    hostGalaxy: 'Messier 87 (Virgo A Elliptical Galaxy)',
    distance: '≈ 53.5 million light-years',
    mass: '≈ 6.5 billion × Sun',
    eventHorizonRadius: '≈ 19.2 billion km (≈ 128 AU, larger than Pluto\'s orbit)',
    spinParameter: 'a* ≈ 0.90 ± 0.05',
    accretionDiskTemp: '≈ 10¹² K (Ultra-relativistic magnetized flow)',
    hasJets: true,
    description: 'The legendary cosmic monster at the core of giant elliptical galaxy Messier 87. In April 2019, humanity captured its historic first direct image of a black hole shadow, surrounded by an asymmetric ring of warped synchrotron emission and unleashing a 5,000-light-year relativistic jet into the Virgo Cluster.',
    interestingFact: 'Its event horizon is so colossal (over 38 billion km across) that our entire Solar System out past Neptune and Pluto could fit inside it multiple times.',
    visualColor: '#ea580c',
    colorHex: '#ea580c',
    glowColor: 'rgba(234, 88, 12, 0.5)',
    sizeClass: 'black-hole',
    x: -150,
    y: 110,
    tier: 2,
    baseRadius: 11,
    relatedConstellation: 'Virgo',
  },
  {
    id: 'cygnus-x1',
    name: 'Cygnus X-1',
    commonName: 'First Confirmed Stellar-Mass Black Hole',
    category: CELESTIAL_CATEGORIES.BLACK_HOLE,
    subtype: 'Stellar-Mass Black Hole (X-Ray Binary)',
    blackHoleType: 'stellar',
    constellation: 'Cygnus',
    hostGalaxy: 'Milky Way Galaxy',
    distance: '≈ 7,300 light-years',
    mass: '≈ 21.2 × Sun',
    eventHorizonRadius: '≈ 63 km',
    spinParameter: 'a* > 0.95 (Near Extreme Kerr Limit)',
    accretionDiskTemp: '≈ 10⁷ K (Intense soft X-rays)',
    companionStar: 'HDE 226868 (Blue Supergiant O9.7Iab)',
    hasJets: true,
    description: 'The first widely accepted black hole candidate discovered in 1964. Locked in a furious binary dance with blue supergiant companion star HDE 226868, it siphons stellar wind onto an incandescent relativistic accretion disk generating intense X-rays.',
    interestingFact: 'Stephen Hawking famously made a friendly scientific bet with physicist Kip Thorne in 1974 that Cygnus X-1 was not a black hole, finally conceding defeat in 1990.',
    visualColor: '#38bdf8',
    colorHex: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    sizeClass: 'black-hole',
    x: 390,
    y: -300,
    tier: 2,
    baseRadius: 7,
    relatedConstellation: 'Cygnus',
  },
];

/**
 * Educational Overview Content for Black Holes
 */
export const BLACK_HOLE_EDUCATIONAL_OVERVIEW = {
  title: 'WHAT IS A BLACK HOLE?',
  leadSentence: 'A black hole is an astronomical object with gravity so strong that, beyond its event horizon, light cannot escape.',
  principles: [
    {
      title: 'Event Horizon',
      text: 'The mathematical surface enclosing the black hole where escape velocity equals c. Beyond it, causality flows irreversibly inward.',
    },
    {
      title: 'Accretion Disk',
      text: 'A rotating disk of superheated matter heated by gravitational friction, radiating intensely across radio, visible, and X-ray spectra.',
    },
    {
      title: 'Photon Ring',
      text: 'A narrow, ultra-bright ring formed by photons trapped in unstable circular orbits before escaping into deep space.',
    },
    {
      title: 'Gravitational Lensing',
      text: 'Massive gravitational curvature bends light rays from background stars and the rear accretion disk into Einstein arcs.',
    },
  ],
  disclaimer: 'Scientific visualization — not to scale. Illustrative educational visualization.',
};
