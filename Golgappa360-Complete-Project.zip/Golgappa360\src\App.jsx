import React from 'react';
import { GolgappaApp } from './golgappa/GolgappaApp';

export default function App() {
  return <GolgappaApp />;
}
