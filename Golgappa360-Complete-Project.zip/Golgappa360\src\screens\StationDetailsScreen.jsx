import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  MapPin,
  Star,
  Share2,
  ChevronRight,
  Zap,
  Sparkles,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { ChargerCard } from '../components/stations/ChargerCard';
import { useEV } from '../context/EVContext';
import { useUI } from '../context/UIContext';

export const StationDetailsScreen = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { stations, selectedStation, setSelectedStation, selectedCharger, setSelectedCharger } = useEV();
  const { showToast } = useUI();

  // Find station by URL param or fall back to selected
  const station = stations.find((s) => s.id === id) || selectedStation || stations[0];
  const [activeCharger, setActiveCharger] = useState(
    selectedCharger?.status === 'Available' ? selectedCharger : station.chargers[0]
  );

  const handleSelectCharger = (charger) => {
    setActiveCharger(charger);
    setSelectedCharger(charger);
    showToast(`Selected ${charger.name} (${charger.power})`, 'info');
  };

  const handleBookCharger = () => {
    if (!activeCharger || activeCharger.status !== 'Available') {
      showToast('Please select an available charger to proceed', 'error');
      return;
    }
    setSelectedStation(station);
    setSelectedCharger(activeCharger);
    // Flow: Station Details -> Charger Selection (Screen 8)
    navigate(`/select-charger/${station.id}/${activeCharger.id}`);
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header
        title={station.name}
        showBack
        rightAction={
          <button
            onClick={() => showToast('Station link copied to clipboard', 'success')}
            className="p-2 rounded-xl bg-[#0D1527] border border-white/10 text-slate-300 hover:text-white"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        }
      />

      <div className="px-4 py-3 space-y-4">
        {/* Main Station Summary Card */}
        <Card className="bg-gradient-to-br from-[#131E35] to-[#0A1224]">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                {station.name}
              </h2>
              <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                <div className="flex items-center gap-1 text-amber-400 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{station.rating}</span>
                  <span className="text-slate-500 font-normal">
                    ({station.reviewsCount || 142})
                  </span>
                </div>
                <span>•</span>
                <div className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#00F5A0]" />
                  <span>{station.distance}</span>
                </div>
                <span>•</span>
                <span className="text-emerald-400 font-semibold">
                  {station.openHours}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-[#00F5A0]/10 border border-[#00F5A0]/30 text-[#00F5A0]">
              <Zap className="w-5 h-5 fill-[#00F5A0]" />
            </div>
          </div>

          {/* Address Section */}
          <div className="mt-3.5 pt-3 border-t border-white/10 text-xs text-slate-300">
            <span className="text-[10px] uppercase tracking-wide text-slate-400 block font-semibold mb-1">
              Address
            </span>
            <p className="leading-relaxed text-slate-200">{station.address}</p>
          </div>

          {/* Amenities & Connectors */}
          <div className="mt-3.5 pt-3 border-t border-white/10">
            <span className="text-[10px] uppercase tracking-wide text-slate-400 block font-semibold mb-2">
              Station Amenities
            </span>
            <div className="flex flex-wrap gap-1.5">
              {station.amenities?.map((item, idx) => (
                <span
                  key={idx}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-[#070B19] border border-white/5 text-slate-300"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </Card>

        {/* AI Smart Charging Recommended Window (Section 18, 33) */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-indigo-950/40 border border-purple-500/30 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Smart Charging • Demand Insight
              </span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
              AI Recommendation
            </span>
          </div>

          <div className="flex items-center justify-between pt-0.5">
            <div>
              <p className="text-[11px] text-slate-400">Estimated Lower-Demand Period:</p>
              <p className="text-sm font-black text-emerald-400">02:00 PM – 04:00 PM</p>
            </div>
            <div className="text-right">
              <p className="text-[11px] text-slate-400">Historical Availability:</p>
              <p className="text-xs font-bold text-purple-300">4 Chargers Available</p>
            </div>
          </div>

          <p className="text-[10px] text-slate-400 leading-relaxed border-t border-purple-900/40 pt-2">
            Based on historical station activity; actual real-time availability may differ upon arrival.
          </p>
        </div>

        {/* Chargers Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Available Chargers
              </h3>
              <span className="text-xs text-slate-400">
                Select a charger to reserve or initiate session
              </span>
            </div>
            <span className="text-xs font-semibold text-[#00F5A0]">
              {station.availableChargers}/{station.chargers?.length} Ready
            </span>
          </div>

          <div className="space-y-3">
            {station.chargers?.map((charger) => (
              <ChargerCard
                key={charger.id}
                charger={charger}
                isSelected={activeCharger?.id === charger.id}
                onSelect={handleSelectCharger}
                onView={() => {
                  showToast(`${charger.name} is currently charging. Est. ${charger.estimatedAvailable} remaining.`, 'info');
                }}
              />
            ))}
          </div>
        </div>

        {/* Primary CTA Book Charger */}
        <div className="sticky bottom-4 pt-2">
          <Button
            size="lg"
            fullWidth
            onClick={handleBookCharger}
            disabled={!activeCharger || activeCharger.status !== 'Available'}
            icon={ChevronRight}
            iconPosition="right"
          >
            Book {activeCharger?.name || 'Charger'}
          </Button>
        </div>
      </div>
    </div>
  );
};
