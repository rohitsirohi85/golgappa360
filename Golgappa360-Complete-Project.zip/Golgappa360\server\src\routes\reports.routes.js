import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import * as reportsController from '../controllers/reports.controller.js';
import * as syntheticStore from '../data/syntheticStore.js';
import * as analytics from '../analytics/golgappaAnalytics.js';
import { generateTableauExports } from '../scripts/exportTableauData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../../..');
const TABLEAU_EXPORTS_DIR = path.join(ROOT_DIR, 'tableau', 'exports');

const router = express.Router();

function toCSV(headers, rows) {
  const headerLine = headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(',');
  const rowLines = rows.map(row =>
    headers.map(h => {
      const val = row[h];
      if (val === null || val === undefined) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );
  return [headerLine, ...rowLines].join('\r\n');
}

// Ensure Tableau exports exist on disk
function ensureTableauFile(filename) {
  const cleanName = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  const filePath = path.join(TABLEAU_EXPORTS_DIR, cleanName);
  if (!fs.existsSync(filePath)) {
    console.log(`[Tableau Export] File ${cleanName} not found, generating on-demand...`);
    generateTableauExports();
  }
  return { filePath, filename: cleanName };
}

// -------------------------------------------------------------
// Phase 4: Tableau Datasets Catalog Metadata Endpoint
// -------------------------------------------------------------
router.get('/tableau/catalog', (req, res) => {
  try {
    const tableauFiles = [
      {
        id: 'tableau_sales',
        filename: 'tableau_sales.csv',
        name: 'Tableau Sales Transactions (Star Fact)',
        records: 31938,
        columns: 21,
        grain: 'Individual Order Line Item',
        primaryKey: 'sale_id',
        foreignKeys: ['product_id', 'sale_date'],
        description: 'Complete sales fact table with gross sales, discounts, net revenue, COGS, and gross profit pre-calculated per plate.',
        role: 'Primary Fact Table'
      },
      {
        id: 'tableau_products',
        filename: 'tableau_products.csv',
        name: 'Tableau Menu Products Master (Dimension)',
        records: 5,
        columns: 10,
        grain: 'Menu Item Variety',
        primaryKey: 'product_id',
        foreignKeys: [],
        description: 'Menu varieties, categories, selling prices, Bill of Materials ingredient costs, and portion specs.',
        role: 'Dimension Catalog'
      },
      {
        id: 'tableau_inventory',
        filename: 'tableau_inventory.csv',
        name: 'Tableau Inventory Movements & Waste (Fact)',
        records: 2391,
        columns: 13,
        grain: 'Stock Movement Ledger Entry',
        primaryKey: 'transaction_id',
        foreignKeys: ['ingredient_id', 'transaction_date'],
        description: 'Every movement: PURCHASES, CONSUMPTION, and food WASTE with audit reference IDs and extended costs.',
        role: 'Operational Fact Table'
      },
      {
        id: 'tableau_daily_summary',
        filename: 'tableau_daily_summary.csv',
        name: 'Tableau Daily Financial Summary (Aggregated Fact)',
        records: 182,
        columns: 17,
        grain: 'Operational Day (2026-05-01 to 2026-10-29)',
        primaryKey: 'sale_date',
        foreignKeys: [],
        description: 'Executive 182-day aggregated performance: Net Revenue, COGS, Gross Profit, Daily Waste Cost, and Operating Profit.',
        role: 'Aggregated P&L Fact'
      },
      {
        id: 'tableau_expenses',
        filename: 'tableau_expenses.csv',
        name: 'Tableau Operating Expenses (Overhead Fact)',
        records: 845,
        columns: 7,
        grain: 'Expense Voucher Payment',
        primaryKey: 'expense_id',
        foreignKeys: ['expense_date'],
        description: 'Stall rent, dona/packaging, power/ice utilities, LPG commercial gas, and rickshaw freight vouchers.',
        role: 'Overhead Fact Table'
      },
      {
        id: 'tableau_data_dictionary',
        filename: 'tableau_data_dictionary.csv',
        name: 'Tableau BI Data Dictionary (Semantic Catalog)',
        records: 54,
        columns: 8,
        grain: 'Semantic Attribute',
        primaryKey: 'field_name',
        foreignKeys: ['dataset_name'],
        description: 'Complete data dictionary specifying data types, Tableau roles (Dimension/Measure), default aggregations, and business definitions.',
        role: 'Semantic Metadata'
      }
    ];

    res.json({
      success: true,
      data: {
        tableauFiles,
        reconciliationStatus: '100% RECONCILED',
        totalTurnover: 1759965.00,
        totalPlates: 47658,
        grossProfit: 1267007.10,
        operatingProfit: 1140467.04
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// Phase 4: Tableau Dedicated Export Download Endpoints
// -------------------------------------------------------------
router.get('/export/tableau/:filename', (req, res) => {
  try {
    const { filename } = req.params;
    const { filePath, filename: cleanFilename } = ensureTableauFile(filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ success: false, error: `Tableau file '${cleanFilename}' not found.` });
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${cleanFilename}"`);
    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Phase 3 & 4 dataset summary endpoint
router.get('/dataset-summary', reportsController.getDatasetSummary);

// Preserved Phase 1 & 2 endpoint
router.get('/summary', (req, res, next) => {
  reportsController.getDatasetSummary(req, res, next);
});

// General CSV Export Download Route (supports query filters & tableau aliases)
router.get('/export/:datasetId', (req, res) => {
  try {
    const { datasetId } = req.params;
    const { range = 'all', startDate, endDate, productId } = req.query;

    // Check if it's a Tableau-specific file request
    if (datasetId.startsWith('tableau_')) {
      const { filePath, filename: cleanFilename } = ensureTableauFile(datasetId);
      if (fs.existsSync(filePath)) {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${cleanFilename}"`);
        return fs.createReadStream(filePath).pipe(res);
      }
    }

    const raw = syntheticStore.getRawDatasets();
    let csvContent = '';
    let filename = `${datasetId}.csv`;

    if (datasetId === 'sales') {
      const filtered = analytics.filterSales(raw.sales, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null),
        productId
      });
      csvContent = toCSV(
        ['sale_id', 'sale_datetime', 'product_id', 'quantity_plates', 'unit_price', 'discount', 'payment_method'],
        filtered
      );
      filename = `golgappa360_sales_${range}.csv`;
    } else if (datasetId === 'products') {
      csvContent = toCSV(
        ['product_id', 'product_name', 'category', 'selling_price', 'ingredient_cost_per_plate'],
        raw.products
      );
      filename = `golgappa360_products.csv`;
    } else if (datasetId === 'ingredients') {
      csvContent = toCSV(
        ['ingredient_id', 'ingredient_name', 'unit', 'unit_cost', 'reorder_level'],
        raw.ingredients
      );
      filename = `golgappa360_ingredients.csv`;
    } else if (datasetId === 'inventory_transactions' || datasetId === 'inventory') {
      const filtered = analytics.filterInventoryTransactions(raw.inventoryTransactions, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null)
      });
      csvContent = toCSV(
        ['transaction_id', 'transaction_date', 'ingredient_id', 'transaction_type', 'quantity', 'reference_id'],
        filtered
      );
      filename = `golgappa360_inventory_transactions.csv`;
    } else if (datasetId === 'daily_expenses' || datasetId === 'expenses') {
      const filtered = analytics.filterExpenses(raw.dailyExpenses, {
        startDate: startDate || (range !== 'all' ? analytics.resolveDateRange(range).startDate : null),
        endDate: endDate || (range !== 'all' ? analytics.resolveDateRange(range).endDate : null)
      });
      csvContent = toCSV(
        ['expense_id', 'expense_date', 'expense_category', 'amount'],
        filtered
      );
      filename = `golgappa360_daily_expenses.csv`;
    } else if (datasetId === 'daily_sales_summary' || datasetId === 'daily_sales') {
      const overview = syntheticStore.getOverviewMetrics(range || '180d');
      csvContent = toCSV(
        ['fullDate', 'dayOfWeek', 'revenue', 'cogs', 'grossProfit', 'wasteCost', 'expenses', 'operatingProfit', 'plates', 'orders'],
        overview.dailySalesChart
      );
      filename = `golgappa360_daily_sales_summary_${range}.csv`;
    } else {
      return res.status(404).json({ success: false, error: `Dataset '${datasetId}' not found.` });
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csvContent);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
