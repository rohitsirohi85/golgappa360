import { api } from './api';
import { MOCK_STATIONS } from '../data/mockStations';

export const stationService = {
  getStations: async (filters = {}) => {
    try {
      let queryParams = new URLSearchParams();
      if (filters.city) queryParams.append('city', filters.city);
      if (filters.available) queryParams.append('available', 'true');
      if (filters.search) queryParams.append('search', filters.search);

      const qs = queryParams.toString() ? `?${queryParams.toString()}` : '';
      const data = await api.get(`/stations${qs}`);

      if (Array.isArray(data) && data.length > 0) {
        return data.map((st) => ({
          id: st._id,
          name: st.name,
          tag: st.amenities?.[0] || 'Fast Charging Hub',
          address: st.address,
          city: st.city,
          distance: `${(1.2 + Math.random() * 2).toFixed(1)} km`,
          distanceNum: 1.2,
          rating: st.rating || 4.7,
          reviewsCount: 142,
          totalChargers: st.totalChargers || st.chargers?.length || 4,
          availableChargers: st.availableChargers || 2,
          chargingSpeed: st.chargers?.[0]?.powerRating ? `${st.chargers[0].powerRating} Fast` : 'Fast Charging',
          maxPower: st.chargers?.[0]?.powerRating || '60 kW',
          ratePerKwh: st.pricePerKwh || 10,
          openHours: st.openingHours || 'Open 24/7',
          amenities: st.amenities || ['Café', 'Restrooms', 'Free Wi-Fi', '24/7 Security'],
          connectorsSupported: ['CCS2', 'Type 2 AC'],
          chargers: (st.chargers || []).map((ch, idx) => ({
            id: ch._id,
            name: ch.chargerNumber || `Charger 0${idx + 1}`,
            type: ch.chargerType || 'Fast Charger',
            power: ch.powerRating || '60 kW',
            connector: ch.connectorType || 'CCS2',
            status: ch.status === 'available' ? 'Available' : ch.status === 'charging' ? 'Charging' : 'Fault',
            rate: ch.pricePerKwh || st.pricePerKwh || 10,
            estimatedTime: '35–45 min',
            estimatedAvailable: ch.status === 'charging' ? '25 min' : undefined,
          })),
        }));
      }
      return [...MOCK_STATIONS];
    } catch (err) {
      console.warn('Backend getStations fallback to mock data:', err.message);
      return [...MOCK_STATIONS];
    }
  },

  getStationById: async (id) => {
    try {
      if (id && id.match(/^[0-9a-fA-F]{24}$/)) {
        const st = await api.get(`/stations/${id}`);
        return {
          id: st._id,
          name: st.name,
          address: st.address,
          distance: '1.2 km',
          rating: st.rating || 4.7,
          openHours: st.openingHours,
          pricePerKwh: st.pricePerKwh,
          amenities: st.amenities,
          chargers: (st.chargers || []).map((ch, idx) => ({
            id: ch._id,
            name: ch.chargerNumber || `Charger 0${idx + 1}`,
            type: ch.chargerType,
            power: ch.powerRating,
            connector: ch.connectorType,
            status: ch.status === 'available' ? 'Available' : ch.status === 'charging' ? 'Charging' : 'Fault',
            rate: ch.pricePerKwh || 10,
          })),
        };
      }
      return MOCK_STATIONS.find((s) => s.id === id) || MOCK_STATIONS[0];
    } catch (err) {
      return MOCK_STATIONS.find((s) => s.id === id) || MOCK_STATIONS[0];
    }
  },

  searchStations: async (query) => {
    return stationService.getStations({ search: query });
  },
};
