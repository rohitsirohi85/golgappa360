# EV SMART — Physical iPhone Local Setup & Demonstration Guide

**Document Version:** `1.0.0-RC1`  
**App Version:** `EV-SMART-FINAL-RC1`  
**Target Hardware:** Apple iPhone (iOS 15.0 or later)  
**Host Workstation:** Windows 10/11 running Node.js 20+  

---

## 1. Overview

EV SMART is built to deliver a seamless native-like mobile experience on physical iPhones. This guide provides exact instructions for running the mobile application on your physical iPhone over local Wi-Fi without needing an Apple Developer account or Xcode compilation.

Two access pathways are supported:
1. **High-Performance Progressive Web App (PWA):** Instant launch in iOS Safari with "Add to Home Screen" support (Recommended for live demonstrations and examiner testing).
2. **Expo Native Mobile Wrapper:** Using the Expo CLI and Expo Go iOS app.

---

## 2. Prerequisites & Network Verification

1. **Same Wi-Fi Network:** Ensure your host computer (running the backend and Vite dev server) and your physical iPhone are connected to the exact same Wi-Fi router or hotspot.
2. **Determine Host LAN IP:**
   - Open PowerShell on your computer and run:
     ```powershell
     ipconfig
     ```
   - Look for the **IPv4 Address** under your active Wi-Fi adapter (in this environment: `192.168.29.23`).
3. **Verify Port Availability:**
   - Frontend Vite Port: `5173`
   - Backend Express API Port: `5000`
   - Python ML Service Port: `8000`

---

## 3. Host Server Configuration (Already Verified)

The project has already been configured to bind to all network interfaces (`0.0.0.0`):

### 3.1 Vite Server (`vite.config.js`)
```javascript
export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // Listens on 0.0.0.0
    port: 5173,
  },
});
```

### 3.2 Dynamic LAN CORS (`backend/src/server.js`)
The backend automatically permits private LAN subnets (`192.168.x.x`, `10.x.x.x`, `172.16-31.x.x`):
```javascript
// Automatically allows your iPhone's origin in development and staging
if (/^https?:\/\/(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+)(:\d+)?$/.test(origin)) {
  return callback(null, true);
}
```

### 3.3 Dynamic Base URL Resolution (`src/services/api.js`)
When accessed on your iPhone via `http://192.168.29.23:5173`, the frontend automatically routes API calls to `http://192.168.29.23:5000/api` without requiring manual reconfiguration.

---

## 4. Step-by-Step iPhone PWA Installation

### Step 1: Start Services on Host Workstation
Ensure the backend and frontend are running:
```powershell
# Terminal 1 - Node.js Backend
cd d:\antigravty\backend
npm start

# Terminal 2 - Frontend Development Server
cd d:\antigravty
npm run dev
```

### Step 2: Open Safari on iPhone
1. Open **Mobile Safari** on your iPhone.
2. In the URL bar, type:
   ```text
   http://192.168.29.23:5173
   ```
   *(Replace with your current workstation IPv4 if changed)*
3. Tap **Go**. The EV SMART login / dashboard screen will load instantly.

### Step 3: Add to Home Screen (Standalone App Mode)
For an authentic native app experience without Safari URL bars or browser controls:
1. Tap the **Share** button (box with an upward arrow) at the bottom center of Safari.
2. Scroll down and tap **"Add to Home Screen"** (`+` icon).
3. The app title will default to **EV Smart**. Tap **Add** in the top right corner.
4. An EV SMART app icon will now appear on your iPhone home screen!
5. Tap the new home screen icon to launch the app in **Fullscreen Standalone PWA Mode**.

---

## 5. Live Demonstration & Presentation Features

The mobile interface includes dedicated examiner demonstration controls located on the **Profile / Settings** screen:

1. **Presentation Mode:**
   - Increases font weights, tightens spacing, and elevates contrast ratios for optimal visibility on lecture projectors and external monitors.
2. **Clean Screenshot Mode:**
   - Hides floating debug badges, simulated network indicators, and notification pings, providing immaculate UI visuals for academic reports, presentation slides, and dissertation documentation.
3. **Demo Reset & Quick Seed:**
   - Seamlessly populate realistic charging stations, chargers, and historical telemetry data using the backend demo utility scripts:
     ```powershell
     cd d:\antigravty\backend
     npm run seed-demo-data
     ```

---

## 6. Alternative: Expo Native Mobile Setup

If you wish to test with the Expo mobile toolchain:

1. Install **Expo Go** from the Apple App Store on your iPhone.
2. In your host project root:
   ```powershell
   npx expo start --lan
   ```
3. A QR code will display in the terminal.
4. Open the iOS **Camera app** on your iPhone, point it at the terminal QR code, and tap the **"Open in Expo Go"** banner.

---

## 7. Troubleshooting & Network Verification

### Issue A: iPhone Safari says "Server Stopped Responding" or "Cannot Open Page"
- **Cause 1: Windows Defender Firewall is blocking inbound connections.**
  - **Fix:** Open PowerShell as Administrator and run:
    ```powershell
    New-NetFirewallRule -DisplayName "EV-Smart Vite Dev" -Direction Inbound -LocalPort 5173 -Protocol TCP -Action Allow
    New-NetFirewallRule -DisplayName "EV-Smart Node API" -Direction Inbound -LocalPort 5000 -Protocol TCP -Action Allow
    ```
- **Cause 2: Wi-Fi Router has "Client Isolation" / "AP Isolation" enabled.**
  - **Explanation:** Some university, office, or public Wi-Fi networks prevent wireless devices from talking directly to one another.
  - **Fix:** Use your iPhone's **Personal Hotspot** and connect your laptop to the iPhone hotspot. Check your laptop's new IP via `ipconfig` (typically `172.20.10.x`) and navigate to `http://172.20.10.x:5173` on the iPhone.

### Issue B: UI Loads, but API calls fail or spin indefinitely
- **Verify Backend Reachability:** On your iPhone Safari, open:
  ```text
  http://192.168.29.23:5000/api/health
  ```
  You should immediately receive a JSON response:
  ```json
  {
    "status": "OK",
    "app": "EV Smart Backend API",
    "MongoDB": "OK",
    "IoT": "OK",
    "ML": "OK"
  }
  ```
- If the `/api/health` URL does not respond from your iPhone, review the Windows Firewall rule for port `5000`.

### Issue C: iOS Safari Security Warning
- Safari may display an insecure connection warning because the local development server uses HTTP rather than HTTPS. This is standard for local LAN IP addresses. Tap **Continue** or **Advanced -> Proceed** to proceed.

---

## 8. Summary Checklist for Viva Demonstration

- [x] Host laptop and iPhone connected to same Wi-Fi
- [x] Host IPv4 verified (`192.168.29.23`)
- [x] Node.js backend active (`http://192.168.29.23:5000/api/health`)
- [x] Vite dev server active (`http://192.168.29.23:5173`)
- [x] Standalone PWA installed on iPhone Home Screen
- [x] Demo dataset seeded (`npm run seed-demo-data`)
- [x] Presentation Mode tested and verified
