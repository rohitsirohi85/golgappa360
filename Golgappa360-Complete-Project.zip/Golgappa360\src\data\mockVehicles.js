export const DEFAULT_VEHICLE = {
  id: 'veh_01',
  make: 'Tesla',
  model: 'Model 3',
  year: 2024,
  licensePlate: 'KA 01 EV 2026',
  batteryCapacity: 60, // kWh
  currentBattery: 78,  // %
  currentRange: 312,   // km
  maxRange: 440,       // km
  connector: 'CCS2',
  chargingSpeedSupport: 'Up to 170 kW DC',
  health: '98%',
  image: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=600&q=80',
};

export const VEHICLE_TYPES = [
  { id: 'car', label: 'Electric Car / SUV' },
  { id: '2w', label: 'Electric 2-Wheeler' },
  { id: 'commercial', label: 'Commercial Fleet' },
];
