import express from 'express';
import * as inventoryController from '../controllers/inventory.controller.js';
import { validateDateRange, validatePagination } from '../middleware/validateQuery.js';
import * as syntheticStore from '../data/syntheticStore.js';

const router = express.Router();

router.get('/summary', inventoryController.getSummary);
router.get('/transactions', validateDateRange, validatePagination, inventoryController.getTransactions);

// Preserved Phase 1 & 2 base endpoint
router.get('/', (req, res, next) => {
  inventoryController.getSummary(req, res, next);
});

router.post('/restock', (req, res) => {
  try {
    const { ingredient_id, quantity_added } = req.body;
    if (!ingredient_id || !quantity_added) {
      return res.status(400).json({ success: false, error: 'Ingredient ID and quantity are required.' });
    }
    const invData = syntheticStore.getInventoryData();
    res.json({ success: true, data: invData });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
