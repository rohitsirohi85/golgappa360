/**
 * Golgappa360 - Tableau Data Export Generator
 * 
 * Generates verified, RFC 4180 compliant CSV exports for Tableau Desktop & Public,
 * Power BI, and Excel.
 * 
 * Enforces exact financial and operational accounting invariants:
 * - Net Revenue = Gross Sales − Discounts
 * - COGS = Quantity Plates × Unit Ingredient Cost
 * - Gross Profit = Net Revenue − COGS
 * - Operating Profit = Gross Profit − Operating Expenses
 * - Eliminates duplicate records and Cartesian product inflation.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT_DIR = path.resolve(__dirname, '../../..');
const SYNTHETIC_DIR = path.join(ROOT_DIR, 'data', 'synthetic');
const TABLEAU_EXPORTS_DIR = path.join(ROOT_DIR, 'tableau', 'exports');
const DATA_TABLEAU_DIR = path.join(ROOT_DIR, 'data', 'tableau');

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function parseCSV(filePath) {
  const content = fs.readFileSync(filePath, 'utf8').trim();
  const lines = content.split(/\r?\n/);
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).filter(l => l.trim()).map(line => {
    // Basic CSV line parser handling quoted values
    const values = [];
    let insideQuotes = false;
    let currentVal = '';
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(currentVal.trim().replace(/^"|"$/g, ''));
        currentVal = '';
      } else {
        currentVal += char;
      }
    }
    values.push(currentVal.trim().replace(/^"|"$/g, ''));
    const obj = {};
    headers.forEach((h, i) => {
      obj[h] = values[i] !== undefined ? values[i] : '';
    });
    return obj;
  });
}

function toCSV(headers, rows) {
  const headerLine = headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(',');
  const rowLines = rows.map(row =>
    headers.map(h => {
      const val = row[h];
      if (val === null || val === undefined) return '""';
      // Format numbers cleanly without redundant quotes if numeric
      if (typeof val === 'number') {
        return Number.isInteger(val) ? String(val) : val.toFixed(2);
      }
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );
  return [headerLine, ...rowLines].join('\r\n');
}

export function generateTableauExports() {
  console.log('=== Generating Tableau-Ready Exports for Golgappa360 ===');

  ensureDir(TABLEAU_EXPORTS_DIR);
  ensureDir(DATA_TABLEAU_DIR);

  // 1. Read base synthetic datasets
  const rawSales = parseCSV(path.join(SYNTHETIC_DIR, 'sales.csv'));
  const rawProducts = parseCSV(path.join(SYNTHETIC_DIR, 'products.csv'));
  const rawIngredients = parseCSV(path.join(SYNTHETIC_DIR, 'ingredients.csv'));
  const rawInventory = parseCSV(path.join(SYNTHETIC_DIR, 'inventory_transactions.csv'));
  const rawExpenses = parseCSV(path.join(SYNTHETIC_DIR, 'daily_expenses.csv'));

  const prodMap = new Map(rawProducts.map(p => [p.product_id, p]));
  const ingMap = new Map(rawIngredients.map(i => [i.ingredient_id, i]));

  // Metadata mappings
  const flavourMap = {
    'PROD-001': 'Crispy Puri, Spiced Potato-Chana Mash, Classic Hing-Jeera Tangy Mint Water',
    'PROD-002': 'Extra Green Chilli & Pudina Blend, Black Salt, Fiery Pepper Water',
    'PROD-003': 'Tamarind-Saunth (Imli) Sweet Chutney, Roasted Cumin, Mild Chilled Water',
    'PROD-004': 'Five Flavours Platter (Hing, Pudina, Khatta-Meetha, Nimbu, Garlic-Jeera)',
    'PROD-005': 'Crispy Puris loaded with Sweet Whisked Curd, Sev, Boondi, Pomegranate, & Trio Chutneys'
  };

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // -----------------------------------------------------------------
  // 1. TABLEAU SALES (Granular Item-Level Star-Schema Fact)
  // -----------------------------------------------------------------
  console.log('Building tableau_sales.csv...');
  const tableauSales = rawSales.map(s => {
    const prod = prodMap.get(s.product_id) || {
      product_name: s.product_id,
      category: 'General',
      ingredient_cost_per_plate: 0
    };

    const dtParts = s.sale_datetime.split(' ');
    const dateStr = dtParts[0];
    const timeStr = dtParts[1] || '15:00:00';
    const hour = parseInt(timeStr.split(':')[0], 10);
    const dateObj = new Date(dateStr + 'T12:00:00Z');
    const dayOfWeek = dayNames[dateObj.getUTCDay()];
    const isWeekend = (dayOfWeek === 'Saturday' || dayOfWeek === 'Sunday');

    const qty = parseInt(s.quantity_plates, 10);
    const unitPrice = parseFloat(s.unit_price);
    const discount = parseFloat(s.discount);
    const grossSales = qty * unitPrice;
    const netRevenue = grossSales - discount;
    const costPerPlate = parseFloat(prod.ingredient_cost_per_plate);
    const cogs = qty * costPerPlate;
    const grossProfit = netRevenue - cogs;
    const grossMarginPct = netRevenue > 0 ? (grossProfit / netRevenue) * 100 : 0;

    return {
      sale_id: s.sale_id,
      sale_datetime: s.sale_datetime,
      sale_date: dateStr,
      sale_time: timeStr,
      sale_hour: hour,
      day_of_week: dayOfWeek,
      is_weekend: isWeekend ? 'Weekend' : 'Weekday',
      product_id: s.product_id,
      product_name: prod.product_name,
      category: prod.category,
      quantity_plates: qty,
      unit_price: unitPrice,
      gross_sales: grossSales,
      discount: discount,
      net_revenue: netRevenue,
      ingredient_cost_per_plate: costPerPlate,
      cogs: cogs,
      gross_profit: grossProfit,
      gross_margin_pct: Number(grossMarginPct.toFixed(2)),
      payment_method: s.payment_method,
      is_synthetic: 'true'
    };
  });

  const salesHeaders = [
    'sale_id', 'sale_datetime', 'sale_date', 'sale_time', 'sale_hour', 'day_of_week', 'is_weekend',
    'product_id', 'product_name', 'category', 'quantity_plates', 'unit_price', 'gross_sales',
    'discount', 'net_revenue', 'ingredient_cost_per_plate', 'cogs', 'gross_profit',
    'gross_margin_pct', 'payment_method', 'is_synthetic'
  ];

  // -----------------------------------------------------------------
  // 2. TABLEAU PRODUCTS (Dimension Catalog)
  // -----------------------------------------------------------------
  console.log('Building tableau_products.csv...');
  const tableauProducts = rawProducts.map(p => {
    const sp = parseFloat(p.selling_price);
    const cp = parseFloat(p.ingredient_cost_per_plate);
    const unitProfit = sp - cp;
    const marginPct = (unitProfit / sp) * 100;

    return {
      product_id: p.product_id,
      product_name: p.product_name,
      category: p.category,
      selling_price: sp,
      ingredient_cost_per_plate: cp,
      unit_gross_profit: unitProfit,
      unit_gross_margin_pct: Number(marginPct.toFixed(2)),
      pieces_per_plate: p.product_id === 'PROD-005' ? 5 : 6,
      flavour_profile: flavourMap[p.product_id] || 'Traditional Indian Spices Blend',
      is_synthetic: 'true'
    };
  });

  const productHeaders = [
    'product_id', 'product_name', 'category', 'selling_price', 'ingredient_cost_per_plate',
    'unit_gross_profit', 'unit_gross_margin_pct', 'pieces_per_plate', 'flavour_profile', 'is_synthetic'
  ];

  // -----------------------------------------------------------------
  // 3. TABLEAU INVENTORY (Movement & Waste Fact Table)
  // -----------------------------------------------------------------
  console.log('Building tableau_inventory.csv...');
  const tableauInventory = rawInventory.map(tx => {
    const ing = ingMap.get(tx.ingredient_id) || {
      ingredient_name: tx.ingredient_id,
      unit: 'units',
      unit_cost: 0,
      reorder_level: 0
    };

    const qty = parseFloat(tx.quantity);
    const unitCost = parseFloat(ing.unit_cost);
    const extendedCost = qty * unitCost;

    let movementDirection = 'Outflow';
    if (tx.transaction_type === 'PURCHASE') movementDirection = 'Inflow';
    else if (tx.transaction_type === 'WASTE') movementDirection = 'Waste Loss';

    return {
      transaction_id: tx.transaction_id,
      transaction_date: tx.transaction_date,
      ingredient_id: tx.ingredient_id,
      ingredient_name: ing.ingredient_name,
      transaction_type: tx.transaction_type,
      movement_direction: movementDirection,
      quantity: qty,
      unit: ing.unit,
      unit_cost: unitCost,
      extended_cost: extendedCost,
      reorder_level: parseFloat(ing.reorder_level),
      reference_id: tx.reference_id,
      is_synthetic: 'true'
    };
  });

  const inventoryHeaders = [
    'transaction_id', 'transaction_date', 'ingredient_id', 'ingredient_name',
    'transaction_type', 'movement_direction', 'quantity', 'unit', 'unit_cost',
    'extended_cost', 'reorder_level', 'reference_id', 'is_synthetic'
  ];

  // -----------------------------------------------------------------
  // 4. TABLEAU DAILY SUMMARY (Aggregated Financial & Operational Fact)
  // -----------------------------------------------------------------
  console.log('Building tableau_daily_summary.csv...');
  // Group sales, waste, and expenses by date
  const dateMap = new Map();

  tableauSales.forEach(s => {
    if (!dateMap.has(s.sale_date)) {
      const dateObj = new Date(s.sale_date + 'T12:00:00Z');
      const dayOfWeek = dayNames[dateObj.getUTCDay()];
      dateMap.set(s.sale_date, {
        sale_date: s.sale_date,
        day_of_week: dayOfWeek,
        is_weekend: (dayOfWeek === 'Saturday' || dayOfWeek === 'Sunday') ? 'Weekend' : 'Weekday',
        orders_set: new Set(),
        plates_sold: 0,
        gross_sales: 0,
        total_discounts: 0,
        net_revenue: 0,
        cogs: 0,
        gross_profit: 0,
        daily_waste_cost: 0,
        operating_expenses: 0
      });
    }
    const d = dateMap.get(s.sale_date);
    d.orders_set.add(s.sale_id);
    d.plates_sold += s.quantity_plates;
    d.gross_sales += s.gross_sales;
    d.total_discounts += s.discount;
    d.net_revenue += s.net_revenue;
    d.cogs += s.cogs;
    d.gross_profit += s.gross_profit;
  });

  // Accumulate waste by date
  tableauInventory.forEach(tx => {
    if (tx.transaction_type === 'WASTE') {
      if (dateMap.has(tx.transaction_date)) {
        dateMap.get(tx.transaction_date).daily_waste_cost += tx.extended_cost;
      }
    }
  });

  // Accumulate daily expenses by date
  rawExpenses.forEach(exp => {
    if (dateMap.has(exp.expense_date)) {
      dateMap.get(exp.expense_date).operating_expenses += parseFloat(exp.amount);
    }
  });

  // Convert map to array sorted by date
  const sortedDates = Array.from(dateMap.keys()).sort();
  const tableauDailySummary = sortedDates.map(dateKey => {
    const item = dateMap.get(dateKey);
    const ordersCount = item.orders_set.size;
    const grossMarginPct = item.net_revenue > 0 ? (item.gross_profit / item.net_revenue) * 100 : 0;
    const estOperatingProfit = item.gross_profit - item.operating_expenses;
    const operatingMarginPct = item.net_revenue > 0 ? (estOperatingProfit / item.net_revenue) * 100 : 0;
    const wasteRatioPct = item.net_revenue > 0 ? (item.daily_waste_cost / item.net_revenue) * 100 : 0;

    return {
      sale_date: item.sale_date,
      day_of_week: item.day_of_week,
      is_weekend: item.is_weekend,
      orders_count: ordersCount,
      plates_sold: item.plates_sold,
      gross_sales: item.gross_sales,
      total_discounts: item.total_discounts,
      net_revenue: item.net_revenue,
      cogs: item.cogs,
      gross_profit: item.gross_profit,
      gross_margin_pct: Number(grossMarginPct.toFixed(2)),
      daily_waste_cost: Number(item.daily_waste_cost.toFixed(2)),
      waste_ratio_pct: Number(wasteRatioPct.toFixed(2)),
      operating_expenses: Number(item.operating_expenses.toFixed(2)),
      estimated_operating_profit: Number(estOperatingProfit.toFixed(2)),
      operating_margin_pct: Number(operatingMarginPct.toFixed(2)),
      is_synthetic: 'true'
    };
  });

  const dailyHeaders = [
    'sale_date', 'day_of_week', 'is_weekend', 'orders_count', 'plates_sold',
    'gross_sales', 'total_discounts', 'net_revenue', 'cogs', 'gross_profit',
    'gross_margin_pct', 'daily_waste_cost', 'waste_ratio_pct', 'operating_expenses',
    'estimated_operating_profit', 'operating_margin_pct', 'is_synthetic'
  ];

  // -----------------------------------------------------------------
  // 5. TABLEAU EXPENSES (Operational Overhead Fact)
  // -----------------------------------------------------------------
  console.log('Building tableau_expenses.csv...');
  const tableauExpenses = rawExpenses.map(e => {
    const dateObj = new Date(e.expense_date + 'T12:00:00Z');
    const dayOfWeek = dayNames[dateObj.getUTCDay()];
    return {
      expense_id: e.expense_id,
      expense_date: e.expense_date,
      day_of_week: dayOfWeek,
      is_weekend: (dayOfWeek === 'Saturday' || dayOfWeek === 'Sunday') ? 'Weekend' : 'Weekday',
      expense_category: e.expense_category,
      amount: parseFloat(e.amount),
      is_synthetic: 'true'
    };
  });

  const expenseHeaders = [
    'expense_id', 'expense_date', 'day_of_week', 'is_weekend',
    'expense_category', 'amount', 'is_synthetic'
  ];

  // -----------------------------------------------------------------
  // 6. TABLEAU DATA DICTIONARY (Data Governance & BI Semantic Model)
  // -----------------------------------------------------------------
  console.log('Building tableau_data_dictionary.csv...');
  const tableauDataDictionary = [
    // tableau_sales
    { dataset_name: 'tableau_sales', field_name: 'sale_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Unique order identifier for each customer transaction', formula_or_derivation: 'Direct ID from POS terminal', example_value: 'SAL-0000001' },
    { dataset_name: 'tableau_sales', field_name: 'sale_datetime', data_type: 'DateTime', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Exact timestamp when the plate was served and payment was tendered', formula_or_derivation: 'ISO-8601 YYYY-MM-DD HH:mm:ss', example_value: '2026-05-01 18:51:40' },
    { dataset_name: 'tableau_sales', field_name: 'sale_date', data_type: 'Date', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Calendar date of the order, used for temporal aggregation', formula_or_derivation: 'DATE(sale_datetime)', example_value: '2026-05-01' },
    { dataset_name: 'tableau_sales', field_name: 'sale_time', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Wall clock time of order placement', formula_or_derivation: 'TIME(sale_datetime)', example_value: '18:51:40' },
    { dataset_name: 'tableau_sales', field_name: 'sale_hour', data_type: 'Integer', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: '24-hour hour window (15 to 22) for rush hour heatmaps', formula_or_derivation: 'HOUR(sale_datetime)', example_value: '18' },
    { dataset_name: 'tableau_sales', field_name: 'day_of_week', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Full day of week name (Monday through Sunday)', formula_or_derivation: 'DAYNAME(sale_date)', example_value: 'Friday' },
    { dataset_name: 'tableau_sales', field_name: 'is_weekend', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Weekend binary flag for footfall comparison', formula_or_derivation: 'IF Day in (Saturday, Sunday) THEN Weekend ELSE Weekday', example_value: 'Weekday' },
    { dataset_name: 'tableau_sales', field_name: 'product_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Foreign key to tableau_products.csv', formula_or_derivation: 'Catalog SKU ID', example_value: 'PROD-001' },
    { dataset_name: 'tableau_sales', field_name: 'product_name', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Customer-facing golgappa product name', formula_or_derivation: 'Denormalized lookup from products', example_value: 'Classic Golgappa' },
    { dataset_name: 'tableau_sales', field_name: 'category', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'High-level menu grouping', formula_or_derivation: 'Denormalized lookup from products', example_value: 'Standard Pani Puri' },
    { dataset_name: 'tableau_sales', field_name: 'quantity_plates', data_type: 'Integer', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Number of plates served in this order item', formula_or_derivation: 'Direct POS item count', example_value: '2' },
    { dataset_name: 'tableau_sales', field_name: 'unit_price', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Selling price per plate in Indian Rupees', formula_or_derivation: 'Catalogue price at time of sale', example_value: '30.00' },
    { dataset_name: 'tableau_sales', field_name: 'gross_sales', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Gross turnover before promotional discounts', formula_or_derivation: '[quantity_plates] * [unit_price]', example_value: '60.00' },
    { dataset_name: 'tableau_sales', field_name: 'discount', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Promotional discount amount applied to the order', formula_or_derivation: 'Direct invoice discount', example_value: '0.00' },
    { dataset_name: 'tableau_sales', field_name: 'net_revenue', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Net collected revenue after deducting discounts', formula_or_derivation: '[gross_sales] - [discount]', example_value: '60.00' },
    { dataset_name: 'tableau_sales', field_name: 'ingredient_cost_per_plate', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Raw material standard BOM cost per plate', formula_or_derivation: 'Sum of recipe ingredients per plate', example_value: '8.40' },
    { dataset_name: 'tableau_sales', field_name: 'cogs', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Total Cost of Goods Sold for plates served', formula_or_derivation: '[quantity_plates] * [ingredient_cost_per_plate]', example_value: '16.80' },
    { dataset_name: 'tableau_sales', field_name: 'gross_profit', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Gross profit contribution before stall overheads', formula_or_derivation: '[net_revenue] - [cogs]', example_value: '43.20' },
    { dataset_name: 'tableau_sales', field_name: 'gross_margin_pct', data_type: 'Numeric (%)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Gross margin percentage for the transaction', formula_or_derivation: '([gross_profit] / [net_revenue]) * 100', example_value: '72.00' },
    { dataset_name: 'tableau_sales', field_name: 'payment_method', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Tender method (UPI QR or Cash)', formula_or_derivation: 'Recorded payment tender', example_value: 'UPI' },
    { dataset_name: 'tableau_sales', field_name: 'is_synthetic', data_type: 'Boolean', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Audit flag indicating calibrated synthetic data', formula_or_derivation: 'Constant: true', example_value: 'true' },

    // tableau_products
    { dataset_name: 'tableau_products', field_name: 'product_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Primary key of product menu catalog', formula_or_derivation: 'Unique catalog SKU', example_value: 'PROD-001' },
    { dataset_name: 'tableau_products', field_name: 'product_name', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Full menu item title', formula_or_derivation: 'Menu display name', example_value: 'Classic Golgappa' },
    { dataset_name: 'tableau_products', field_name: 'category', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Product classification tier', formula_or_derivation: 'Category grouping', example_value: 'Standard Pani Puri' },
    { dataset_name: 'tableau_products', field_name: 'selling_price', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Standard menu board price in INR', formula_or_derivation: 'Retail price', example_value: '30.00' },
    { dataset_name: 'tableau_products', field_name: 'ingredient_cost_per_plate', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Bill of Materials cost per plate', formula_or_derivation: 'Calculated recipe cost', example_value: '8.40' },
    { dataset_name: 'tableau_products', field_name: 'unit_gross_profit', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Unit contribution margin per plate', formula_or_derivation: '[selling_price] - [ingredient_cost_per_plate]', example_value: '21.60' },
    { dataset_name: 'tableau_products', field_name: 'unit_gross_margin_pct', data_type: 'Numeric (%)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Profit margin percentage of single plate', formula_or_derivation: '([unit_gross_profit] / [selling_price]) * 100', example_value: '72.00' },
    { dataset_name: 'tableau_products', field_name: 'pieces_per_plate', data_type: 'Integer', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Number of individual puris served per plate', formula_or_derivation: 'Portion specification', example_value: '6' },
    { dataset_name: 'tableau_products', field_name: 'flavour_profile', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Sensory notes and spice blend description', formula_or_derivation: 'Recipe flavor profile', example_value: 'Crispy Puri, Spiced Potato-Chana Mash' },

    // tableau_inventory
    { dataset_name: 'tableau_inventory', field_name: 'transaction_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Primary key for stock movement audit', formula_or_derivation: 'Ledger transaction ID', example_value: 'ITX-000001' },
    { dataset_name: 'tableau_inventory', field_name: 'transaction_date', data_type: 'Date', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Calendar date of inventory movement', formula_or_derivation: 'Stock movement timestamp date', example_value: '2026-05-01' },
    { dataset_name: 'tableau_inventory', field_name: 'ingredient_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Foreign key to ingredients catalog', formula_or_derivation: 'Catalog ID', example_value: 'ING-001' },
    { dataset_name: 'tableau_inventory', field_name: 'ingredient_name', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Raw material ingredient name', formula_or_derivation: 'Denormalized lookup from ingredients', example_value: 'Suji & Atta Puris' },
    { dataset_name: 'tableau_inventory', field_name: 'transaction_type', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Nature of stock event: PURCHASE, CONSUMPTION, or WASTE', formula_or_derivation: 'Audit movement classification', example_value: 'PURCHASE' },
    { dataset_name: 'tableau_inventory', field_name: 'movement_direction', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Directional indicator (Inflow, Outflow, Waste Loss)', formula_or_derivation: 'Derived from transaction_type', example_value: 'Inflow' },
    { dataset_name: 'tableau_inventory', field_name: 'quantity', data_type: 'Numeric', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Quantity moved in unit of measure', formula_or_derivation: 'Stock count entered', example_value: '10500' },
    { dataset_name: 'tableau_inventory', field_name: 'unit', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Physical unit of measure (pcs, kg, liters)', formula_or_derivation: 'Ingredient unit specification', example_value: 'pcs' },
    { dataset_name: 'tableau_inventory', field_name: 'unit_cost', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Purchase price per unit in INR', formula_or_derivation: 'Supplier contract unit cost', example_value: '0.35' },
    { dataset_name: 'tableau_inventory', field_name: 'extended_cost', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Total financial valuation of the transaction', formula_or_derivation: '[quantity] * [unit_cost]', example_value: '3675.00' },
    { dataset_name: 'tableau_inventory', field_name: 'reorder_level', data_type: 'Numeric', tableau_role: 'Measure', tableau_default_aggregation: 'AVG', description: 'Safety threshold trigger for replenishment', formula_or_derivation: 'Stock minimum reorder level', example_value: '2500' },

    // tableau_daily_summary
    { dataset_name: 'tableau_daily_summary', field_name: 'sale_date', data_type: 'Date', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Operational date of business activity', formula_or_derivation: 'Calendar date', example_value: '2026-05-01' },
    { dataset_name: 'tableau_daily_summary', field_name: 'orders_count', data_type: 'Integer', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Total distinct customer orders served', formula_or_derivation: 'COUNT(DISTINCT sale_id)', example_value: '175' },
    { dataset_name: 'tableau_daily_summary', field_name: 'plates_sold', data_type: 'Integer', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Total plates of golgappa served', formula_or_derivation: 'SUM(quantity_plates)', example_value: '261' },
    { dataset_name: 'tableau_daily_summary', field_name: 'net_revenue', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Net turnover collected', formula_or_derivation: 'SUM(net_revenue)', example_value: '9670.00' },
    { dataset_name: 'tableau_daily_summary', field_name: 'cogs', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Cost of goods sold for plates served', formula_or_derivation: 'SUM(cogs)', example_value: '2704.90' },
    { dataset_name: 'tableau_daily_summary', field_name: 'gross_profit', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Gross profit after COGS deduction', formula_or_derivation: '[net_revenue] - [cogs]', example_value: '6965.10' },
    { dataset_name: 'tableau_daily_summary', field_name: 'daily_waste_cost', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Value of spoiled and crushed ingredients on that day', formula_or_derivation: 'SUM(waste_quantity * unit_cost)', example_value: '65.20' },
    { dataset_name: 'tableau_daily_summary', field_name: 'operating_expenses', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Fixed and variable stall overheads (rent, gas, power)', formula_or_derivation: 'SUM(daily_expenses)', example_value: '695.20' },
    { dataset_name: 'tableau_daily_summary', field_name: 'estimated_operating_profit', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Bottom-line operating income', formula_or_derivation: '[gross_profit] - [operating_expenses]', example_value: '6269.90' },

    // tableau_expenses
    { dataset_name: 'tableau_expenses', field_name: 'expense_id', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Unique identifier for expense ledger entry', formula_or_derivation: 'Expense journal voucher ID', example_value: 'EXP-000001' },
    { dataset_name: 'tableau_expenses', field_name: 'expense_date', data_type: 'Date', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Date expense was incurred', formula_or_derivation: 'Calendar date', example_value: '2026-05-01' },
    { dataset_name: 'tableau_expenses', field_name: 'expense_category', data_type: 'String', tableau_role: 'Dimension', tableau_default_aggregation: 'None', description: 'Expense classification bucket (Rent, Utilities, Packaging, Gas, Sanitation)', formula_or_derivation: 'Chart of accounts overhead category', example_value: 'Stall Rent' },
    { dataset_name: 'tableau_expenses', field_name: 'amount', data_type: 'Numeric (INR)', tableau_role: 'Measure', tableau_default_aggregation: 'SUM', description: 'Expense voucher amount in INR', formula_or_derivation: 'Voucher amount', example_value: '250.00' }
  ];

  const dictionaryHeaders = [
    'dataset_name', 'field_name', 'data_type', 'tableau_role',
    'tableau_default_aggregation', 'description', 'formula_or_derivation', 'example_value'
  ];

  // -----------------------------------------------------------------
  // Write to both tableau/exports/ and data/tableau/
  // -----------------------------------------------------------------
  const datasetsToWrite = [
    { name: 'tableau_sales.csv', headers: salesHeaders, rows: tableauSales },
    { name: 'tableau_products.csv', headers: productHeaders, rows: tableauProducts },
    { name: 'tableau_inventory.csv', headers: inventoryHeaders, rows: tableauInventory },
    { name: 'tableau_daily_summary.csv', headers: dailyHeaders, rows: tableauDailySummary },
    { name: 'tableau_expenses.csv', headers: expenseHeaders, rows: tableauExpenses },
    { name: 'tableau_data_dictionary.csv', headers: dictionaryHeaders, rows: tableauDataDictionary }
  ];

  const exportStats = {};

  datasetsToWrite.forEach(({ name, headers, rows }) => {
    const csvContent = toCSV(headers, rows);
    const dest1 = path.join(TABLEAU_EXPORTS_DIR, name);
    const dest2 = path.join(DATA_TABLEAU_DIR, name);

    fs.writeFileSync(dest1, csvContent, 'utf8');
    fs.writeFileSync(dest2, csvContent, 'utf8');

    const stats = fs.statSync(dest1);
    exportStats[name] = {
      records: rows.length,
      columns: headers.length,
      bytes: stats.size,
      dest1,
      dest2
    };
    console.log(`✓ Wrote ${name}: ${rows.length} rows, ${headers.length} cols (${(stats.size / 1024).toFixed(1)} KB)`);
  });

  return exportStats;
}

// Auto-execute if run directly from CLI
if (process.argv[1] && process.argv[1].endsWith('exportTableauData.js')) {
  try {
    const stats = generateTableauExports();
    console.log('\nTableau exports generated successfully!');
    console.log(JSON.stringify(stats, null, 2));
  } catch (err) {
    console.error('Failed to generate Tableau exports:', err);
    process.exit(1);
  }
}
