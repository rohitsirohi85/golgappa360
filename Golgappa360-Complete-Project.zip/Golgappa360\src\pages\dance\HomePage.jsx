import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Link, useOutletContext } from 'react-router-dom';
import { Phone, MessageCircle, ArrowRight, ArrowUpRight, Compass, Calendar, Users, Camera, ShieldCheck, Clock, MapPin } from 'lucide-react';
import { siteConfig } from '../../config/siteConfig';
import { SEO } from '../../components/common/SEO';

export const HomePage = ({ onOpenTrial: propOnOpenTrial }) => {
  const outletCtx = useOutletContext();
  const onOpenTrial = propOnOpenTrial || outletCtx?.onOpenTrial;

  const heroRef = useRef(null);
  const visualRef = useRef(null);
  const spotlightRef = useRef(null);

  // Motion Field state
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  const targetPos = useRef({ x: 0, y: 0, px: 50, py: 50 });
  const currentPos = useRef({ x: 0, y: 0, px: 50, py: 50 });
  const animFrameId = useRef(null);
  const isPointerInside = useRef(false);

  // Check touch devices and reduced-motion preference
  useEffect(() => {
    const touchCheck = window.matchMedia('(hover: none) and (pointer: coarse)').matches;
    setIsTouchDevice(touchCheck);

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(motionQuery.matches);

    const handleMotionChange = (e) => setPrefersReducedMotion(e.matches);
    motionQuery.addEventListener('change', handleMotionChange);

    return () => motionQuery.removeEventListener('change', handleMotionChange);
  }, []);

  // Motion Field animation loop with restrained easing
  const updateMotion = useCallback(() => {
    if (prefersReducedMotion || isTouchDevice) return;

    const factor = 0.055;
    currentPos.current.x += (targetPos.current.x - currentPos.current.x) * factor;
    currentPos.current.y += (targetPos.current.y - currentPos.current.y) * factor;
    currentPos.current.px += (targetPos.current.px - currentPos.current.px) * factor;
    currentPos.current.py += (targetPos.current.py - currentPos.current.py) * factor;

    // Shift hero dancer image by max 9px for subtle organic depth
    if (visualRef.current) {
      const shiftX = (currentPos.current.x * 8).toFixed(2);
      const shiftY = (currentPos.current.y * 6).toFixed(2);
      visualRef.current.style.transform = `translate3d(${shiftX}px, ${shiftY}px, 0)`;
    }

    // Move soft violet spotlight
    if (spotlightRef.current) {
      const posX = currentPos.current.px.toFixed(1);
      const posY = currentPos.current.py.toFixed(1);
      spotlightRef.current.style.background = `radial-gradient(650px circle at ${posX}% ${posY}%, rgba(139, 92, 246, 0.22), transparent 70%)`;
    }

    const delta =
      Math.abs(targetPos.current.x - currentPos.current.x) +
      Math.abs(targetPos.current.y - currentPos.current.y);

    if (isPointerInside.current || delta > 0.005) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    } else {
      animFrameId.current = null;
    }
  }, [prefersReducedMotion, isTouchDevice]);

  const handlePointerMove = (e) => {
    if (isTouchDevice || prefersReducedMotion || !heroRef.current) return;

    const rect = heroRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const normX = (clientX / rect.width) * 2 - 1;
    const normY = (clientY / rect.height) * 2 - 1;

    const pctX = (clientX / rect.width) * 100;
    const pctY = (clientY / rect.height) * 100;

    targetPos.current = {
      x: Math.max(-1, Math.min(1, normX)),
      y: Math.max(-1, Math.min(1, normY)),
      px: Math.max(0, Math.min(100, pctX)),
      py: Math.max(0, Math.min(100, pctY)),
    };

    isPointerInside.current = true;
    if (!animFrameId.current) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    }
  };

  const handlePointerLeave = () => {
    if (isTouchDevice || prefersReducedMotion) return;
    targetPos.current = { x: 0, y: 0, px: 50, py: 50 };
    isPointerInside.current = false;
    if (!animFrameId.current) {
      animFrameId.current = requestAnimationFrame(updateMotion);
    }
  };

  useEffect(() => {
    return () => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
      }
    };
  }, []);

  const whatsAppUrl = `https://wa.me/${siteConfig.contact.whatsAppNumber}?text=${encodeURIComponent(
    siteConfig.contact.whatsAppDefaultMessage
  )}`;

  return (
    <>
      <SEO
        title="Urban Movement Sanctuary"
        description="Official homepage for MOTION IS ART. Call or WhatsApp our studio coordinator directly to explore contemporary urban dance classes, weekly schedules, and trial passes."
      />

      <div className="bg-[#0B0B0F] text-[#F5F3F8] overflow-hidden">
        
        {/* ====================================================================
            HERO SECTION WITH SIGNATURE MOTION FIELD & PROMINENT CONTACT CONSOLE
            ==================================================================== */}
        <section
          ref={heroRef}
          onPointerMove={handlePointerMove}
          onPointerLeave={handlePointerLeave}
          className="relative min-h-[92vh] lg:min-h-[96vh] flex flex-col justify-between pt-28 sm:pt-36 pb-12 sm:pb-16 bg-[#0B0B0F] overflow-hidden"
          aria-label="Academy Hero and Contact Console"
        >
          {/* Signature Motion Field Spotlight (Responsive & Reduced-Motion Aware) */}
          <div
            ref={spotlightRef}
            className="pointer-events-none absolute inset-0 z-0 transition-opacity duration-700"
            style={{
              background:
                isTouchDevice || prefersReducedMotion
                  ? 'radial-gradient(800px circle at 75% 40%, rgba(139, 92, 246, 0.18), transparent 75%)'
                  : 'radial-gradient(650px circle at 50% 50%, rgba(139, 92, 246, 0.22), transparent 70%)',
            }}
          />

          {/* Architectural Grid Lines */}
          <div className="pointer-events-none absolute inset-0 z-0 flex justify-between max-w-7xl mx-auto px-6 opacity-10">
            <div className="w-[1px] h-full bg-white/30" />
            <div className="w-[1px] h-full bg-white/20 hidden md:block" />
            <div className="w-[1px] h-full bg-white/20 hidden lg:block" />
            <div className="w-[1px] h-full bg-white/30" />
          </div>

          {/* Main Hero Grid */}
          <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 w-full flex-1 flex flex-col justify-center">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              
              {/* Left Column: Editorial Headline, Supporting Copy, and Direct Contact Console */}
              <div className="lg:col-span-7 flex flex-col z-20">
                {/* Brand Category Tag */}
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#15151C] border border-white/[0.08] w-fit mb-6 sm:mb-8">
                  <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
                  <span className="font-mono text-[10px] sm:text-[11px] font-semibold tracking-wider uppercase text-[#A5A1B2]">
                    {siteConfig.homepage.badge}
                  </span>
                </div>

                {/* The Headline (Stable, Rock-Solid, Unshaken) */}
                <h1 className="editorial-headline text-[#F5F3F8] tracking-[-0.04em] text-5xl sm:text-7xl xl:text-[5.25rem] leading-[0.92] uppercase select-text">
                  <span className="block">YOUR BODY.</span>
                  <span className="block text-[#A78BFA]">YOUR RHYTHM.</span>
                  <span className="block">YOUR ART.</span>
                </h1>

                {/* Supporting Copy */}
                <p className="mt-6 text-sm sm:text-base text-[#A5A1B2] max-w-xl font-normal leading-relaxed">
                  {siteConfig.homepage.supportingCopy}
                </p>

                {/* -------------------------------------------------------------
                    PROMINENT CONTACT ACTION CONSOLE (SECTION 4 REQUIREMENT)
                    ------------------------------------------------------------- */}
                <div className="mt-8 p-5 sm:p-6 rounded-sm bg-[#15151C] border border-white/[0.09] max-w-xl shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
                  <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/[0.06]">
                    <div>
                      <span className="font-mono text-[10px] uppercase tracking-widest text-[#8B5CF6] font-semibold block">
                        DIRECT STUDIO HOTLINE //
                      </span>
                      <span className="font-mono text-sm sm:text-base font-bold text-white tracking-wider">
                        {siteConfig.contact.displayPhone}
                      </span>
                    </div>
                    <div className="text-right hidden sm:block">
                      <span className="font-mono text-[9px] text-[#A5A1B2] block">COORDINATOR DESK</span>
                      <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1 justify-end">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        AVAILABLE NOW
                      </span>
                    </div>
                  </div>

                  {/* Dual Action Buttons: Call Now + WhatsApp */}
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Call Now Action */}
                    <a
                      href={`tel:${siteConfig.contact.telNumber}`}
                      className="group inline-flex items-center justify-center gap-2.5 px-5 py-3.5 text-xs font-semibold tracking-wider uppercase text-white bg-[#8B5CF6] hover:bg-[#A78BFA] transition-all rounded-sm shadow-[0_0_20px_-3px_rgba(139,92,246,0.6)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
                    >
                      <Phone className="w-4 h-4 transition-transform group-hover:scale-110" />
                      <span>CALL NOW</span>
                    </a>

                    {/* WhatsApp Action */}
                    <a
                      href={whatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group inline-flex items-center justify-center gap-2.5 px-5 py-3.5 text-xs font-semibold tracking-wider uppercase text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 transition-all rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                    >
                      <MessageCircle className="w-4 h-4 transition-transform group-hover:scale-110" />
                      <span>MESSAGE ON WHATSAPP</span>
                    </a>
                  </div>

                  {/* Restrained Secondary CTA */}
                  <div className="mt-4 pt-3 border-t border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="font-mono text-[10px] text-[#A5A1B2]">
                      New to the studio?
                    </span>
                    <Link
                      to="/classes"
                      className="inline-flex items-center gap-1 text-xs font-medium text-[#A78BFA] hover:text-white transition-colors group"
                    >
                      <span>Explore Dance Classes</span>
                      <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </div>
                </div>

              </div>

              {/* Right Column: Signature Hero Dancer Visual with Motion Field */}
              <div className="lg:col-span-5 relative flex items-center justify-center">
                <div className="relative w-full max-w-[440px] aspect-[4/5] rounded-sm overflow-hidden border border-white/[0.1] bg-[#15151C] shadow-2xl">
                  
                  {/* Subtle Organic 3D Depth Shift */}
                  <div
                    ref={visualRef}
                    className="absolute inset-0 w-full h-full will-change-transform transition-transform duration-100 ease-out"
                    style={{ transform: 'translate3d(0, 0, 0)' }}
                  >
                    <img
                      src={siteConfig.homepage.heroVisual}
                      alt={siteConfig.homepage.heroVisualAlt}
                      loading="eager"
                      fetchPriority="high"
                      className="w-full h-full object-cover object-center filter contrast-[1.08] brightness-[0.96]"
                    />
                  </div>

                  {/* Dark Vignette & Film Grain */}
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#0B0B0F] via-transparent to-transparent opacity-90" />
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-[#0B0B0F]/60 via-transparent to-transparent" />
                  <div className="film-grain absolute inset-0 pointer-events-none" />

                  {/* Frame Metadata */}
                  <div className="absolute top-4 left-4 z-10 pointer-events-none">
                    <span className="font-mono text-[9px] text-white/80 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-white/10 uppercase tracking-widest">
                      ARCHIVE // KINETIC VOL. 04
                    </span>
                  </div>

                  {!isTouchDevice && !prefersReducedMotion && (
                    <div className="absolute bottom-4 right-4 z-10 pointer-events-none">
                      <span className="font-mono text-[9px] text-white/60 bg-black/60 backdrop-blur-sm px-2 py-1 rounded border border-white/5 uppercase tracking-wider flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] animate-pulse" />
                        MOTION FIELD ACTIVE
                      </span>
                    </div>
                  )}

                  <div className="absolute bottom-4 left-4 z-10 pointer-events-none max-w-[260px]">
                    <p className="font-sans text-xs text-white font-medium leading-tight">
                      "{siteConfig.academy.coreStatement}"
                    </p>
                    <span className="font-mono text-[9px] text-[#A5A1B2] mt-0.5 block tracking-wider uppercase">
                      {siteConfig.academy.name}
                    </span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Hero Bottom Bar: Studio Address & Direct Hours */}
          <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 w-full mt-10 pt-5 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-[#A5A1B2]">
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
              <span>{siteConfig.contact.address}, {siteConfig.contact.cityStateZip}</span>
            </div>
            <div className="flex items-center gap-4">
              <span>⏱ {siteConfig.contact.hours.weekdays}</span>
              <span className="hidden md:inline">•</span>
              <span className="hidden md:inline">7 DAYS ACTIVE</span>
            </div>
          </div>
        </section>

        {/* ====================================================================
            CLEAR NAVIGATION PORTALS TO SEPARATE PAGES (SECTION 4 REQUIREMENT)
            ==================================================================== */}
        <section
          className="py-20 sm:py-28 bg-[#15151C]/60 border-t border-white/[0.08]"
          aria-label="Academy Sections Directory"
        >
          <div className="max-w-7xl mx-auto px-5 sm:px-8">
            
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/[0.08]">
              <div>
                <span className="font-mono text-xs font-semibold tracking-widest uppercase text-[#8B5CF6] block mb-2">
                  [ EXPLORE THE ACADEMY ]
                </span>
                <h2 className="editorial-headline text-3xl sm:text-5xl text-[#F5F3F8] uppercase">
                  EVERY SECTION HAS <br />
                  <span className="text-[#A78BFA]">ITS OWN FLOOR.</span>
                </h2>
              </div>
              <p className="text-xs sm:text-sm text-[#A5A1B2] max-w-md leading-relaxed font-sans">
                Detailed curriculum breakdowns, weekly timetables, faculty dossiers, and studio admissions reside in dedicated sections.
              </p>
            </div>

            {/* 4 Clean Asymmetrical Portal Cards */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {siteConfig.homepage.portalHighlights.map((portal, idx) => (
                <Link
                  key={portal.link}
                  to={portal.link}
                  className="group relative flex flex-col justify-between p-6 sm:p-7 rounded-sm bg-[#15151C] border border-white/[0.08] hover:border-[#8B5CF6]/50 transition-all duration-300 hover:-translate-y-1"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-mono text-[10px] text-[#8B5CF6] tracking-wider uppercase font-bold">
                        0{idx + 1} // {portal.tag}
                      </span>
                      <ArrowUpRight className="w-4 h-4 text-[#A5A1B2] group-hover:text-[#8B5CF6] transition-colors" />
                    </div>

                    <h3 className="font-display font-bold text-xl text-[#F5F3F8] group-hover:text-[#A78BFA] transition-colors mb-2">
                      {portal.title}
                    </h3>
                    <p className="text-xs text-[#A5A1B2] leading-relaxed">
                      {portal.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs font-semibold text-[#8B5CF6] group-hover:text-[#A78BFA]">
                    <span>{portal.ctaText}</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </div>
                </Link>
              ))}
            </div>

            {/* Quick Link Strip to About & Contact */}
            <div className="mt-10 p-6 rounded-sm bg-[#0B0B0F] border border-white/[0.07] flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-[#8B5CF6] flex-shrink-0" />
                <span className="text-xs text-[#A5A1B2] font-mono">
                  {siteConfig.academy.registrationNote}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <Link
                  to="/about"
                  className="text-xs font-mono uppercase text-white hover:text-[#A78BFA] transition-colors underline"
                >
                  Our Philosophy →
                </Link>
                <Link
                  to="/contact"
                  className="text-xs font-mono uppercase text-white hover:text-[#A78BFA] transition-colors underline"
                >
                  Full Enquiries →
                </Link>
              </div>
            </div>

          </div>
        </section>

      </div>
    </>
  );
};

export default HomePage;
