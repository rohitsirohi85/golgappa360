export const playlists = [
  {
    id: "pl-1",
    title: "Late Night Memory Drive",
    description: "Atmospheric synths and introspective indie tracks for when the highway is all yours.",
    coverUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
    songIds: ["song-1", "song-3", "song-6"],
    curator: "LyricLens Editorial",
    followers: "48.2K",
    isUserCreated: false
  },
  {
    id: "pl-2",
    title: "Monsoon & Melancholy",
    description: "Gentle acoustic strings, bittersweet Hindi poetry, and the sound of distant rain.",
    coverUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
    songIds: ["song-2", "song-7", "song-5"],
    curator: "LyricLens Editorial",
    followers: "91.4K",
    isUserCreated: false
  },
  {
    id: "pl-3",
    title: "High Octane Punjabi Energy",
    description: "Heavy 808s and anthemic dhol drops engineered to fuel workouts and road trips.",
    coverUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
    songIds: ["song-4", "song-3", "song-6"],
    curator: "LyricLens Editorial",
    followers: "63.7K",
    isUserCreated: false
  },
  {
    id: "pl-4",
    title: "My Rainy Midnight Recollections",
    description: "Personal curated list of lyrics that hit too close to home.",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
    songIds: ["song-2", "song-1", "song-8"],
    curator: "You",
    followers: "Private",
    isUserCreated: true
  },
  {
    id: "pl-5",
    title: "Deep Focus & Ambient Peace",
    description: "Minimalist neo-classical melodies that quiet the mind and inspire creation.",
    coverUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
    songIds: ["song-5", "song-1"],
    curator: "LyricLens Editorial",
    followers: "35.1K",
    isUserCreated: false
  }
];
