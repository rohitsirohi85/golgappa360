# Golgappa360 — Professional Tableau Dashboard Build Guide

This guide provides a comprehensive step-by-step tutorial for building **four enterprise-grade analytics dashboards** in **Tableau Desktop / Public**, styled in the signature **Dark Glassmorphism** design theme.

---

## 1. Visual Identity & Tableau Design Tokens

To replicate the Golgappa360 dark glassmorphism dashboard in Tableau:

| Design Token | Hex Code / RGBA | Tableau Application |
|:---|:---:|:---|
| **Canvas Background** | `#171717` | Dashboard > Format > Dashboard Shading > More Colors `#171717` |
| **Container / Card Shading** | `#262628` | Worksheet Shading / Container Background `#262628` |
| **Card Borders** | `#3D3D42` | Container Border > 1px solid `#3D3D42` |
| **Primary Data Series (Sage Green)** | `#A7D78A` | Line series, primary bar charts, positive margins |
| **Accent & Highlight (Saffron Orange)**| `#EAB64B` | Secondary comparison bars, peak rush highlights, key KPIs |
| **Warning & Waste (Terracotta)** | `#D98768` | Waste loss bars, operating expense trends, critical alerts |
| **Primary Text & Headings** | `#F5F4F1` | Title font (Segoe UI or Inter Bold, 14–18pt, `#F5F4F1`) |
| **Secondary & Value Labels** | `#B8B7B9` | Axis titles, KPI values, legend descriptions |
| **Muted Axis & Gridlines** | `#3A3A3E` | Sheet Grid Lines / Zero Lines > Thin dotted `#3A3A3E` |

> [!TIP]
> **Custom Tableau Color Palette Configuration:**
> You can add the Golgappa360 palette directly to your `Preferences.tps` file in `Documents/My Tableau Repository`:
> ```xml
> <color-palette name="Golgappa360 Dark Theme" type="regular">
>   <color>#A7D78A</color>
>   <color>#EAB64B</color>
>   <color>#D98768</color>
>   <color>#7BC0C0</color>
>   <color>#A594F9</color>
>   <color>#F5F4F1</color>
>   <color>#929195</color>
> </color-palette>
> ```

---

## 2. Dashboard 1 — Executive Business Overview

**Target Audience:** Stall Owner (Rajesh Sharma) & MCA Project Evaluator.  
**Objective:** High-level executive pulse: total turnover, plate volume, gross margin efficiency, daily time-series, and payment distribution.

```
┌────────────────────────────────────────────────────────────────────────┐
│  GOLGAPPA360 — EXECUTIVE OVERVIEW            [ Range: Last 30 Days ▼ ] │
├──────────────┬──────────────┬──────────────┬──────────────┬────────────┤
│ Total Revenue│  Plates Sold │ Gross Profit │ Gross Margin │    AOV     │
│  ₹17,59,965  │    47,658    │  ₹12,67,007  │    72.0%     │   ₹55.11   │
├──────────────┴──────────────┴──────────────┼──────────────┴────────────┤
│ Worksheet 1: Daily Revenue Trend (Area)    │ Worksheet 3: Top Products │
│ [Date] vs [Net Revenue] & [7-Day MA]       │ Bar Chart: Sales & Margin │
├────────────────────────────────────────────┼───────────────────────────┤
│ Worksheet 2: Sales by Weekday (Bar)        │ Worksheet 4: Payment Mix  │
│ [Day of Week] vs [Net Revenue]             │ Donut Chart: UPI vs Cash  │
└────────────────────────────────────────────┴───────────────────────────┘
```

### Worksheet Specifications

#### Sheet 1.1: KPI Scorecards (5 Distinct Metric Cards)
- **Data Source:** `tableau_sales`
- **Fields:**
  - Card A: `[Net Revenue]` (Text, formatted `₹ #,##0.00`, 22pt Bold `#F5F4F1`)
  - Card B: `[Total Plates Sold]` (Text, formatted `#,##0 plates`, 22pt Bold `#A7D78A`)
  - Card C: `[Gross Profit]` (Text, formatted `₹ #,##0.00`, 22pt Bold `#EAB64B`)
  - Card D: `[Gross Margin %]` (Text, formatted `72.0%`, 22pt Bold `#A7D78A`)
  - Card E: `[Average Order Value]` (Text, formatted `₹ 55.11`, 22pt Bold `#F5F4F1`)
- **Card Formatting:** Shading `#262628`, corner radius 12px, border `#3D3D42`.

#### Sheet 1.2: Daily Revenue Time-Series with 7-Day Moving Average
- **Columns:** `[Sale Date]` (Continuous Day: `DAY([sale_date])`)
- **Rows:** Dual Axis:
  - Axis 1: `[Net Revenue]` (Marks: Area Chart, Color `#A7D78A` with 35% opacity)
  - Axis 2: `[Rolling 7-Day Revenue]` (Marks: Line Chart, Color `#EAB64B`, Size: 3px)
- **Formatting:** Synchronize Axis. Hide right header. Zero line `#3A3A3E`.

#### Sheet 1.3: Revenue by Day of Week
- **Columns:** `[Day of Week]` (Sorted manually: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday)
- **Rows:** `[Net Revenue]`
- **Color:** `[is_weekend]` (`#EAB64B` for Weekend, `#A7D78A` for Weekday)
- **Label:** `[Net Revenue]` on Mark Labels (Format: Currency K: `₹ #,##0,"K"`).

#### Sheet 1.4: Product Revenue Contribution
- **Columns:** `[Net Revenue]`
- **Rows:** `[Product Name]` (Sorted descending by `[Net Revenue]`)
- **Color:** `[Gross Margin %]` (Sequential Sage green palette)
- **Tooltip:** Include `[Plates Sold]`, `[Net Revenue]`, `[Gross Profit]`, and `[Margin %]`.

#### Sheet 1.5: Tender Method Breakdown (UPI vs Cash)
- **Marks:** Pie / Donut Chart
- **Color:** `[Payment Method]` (UPI: `#A7D78A`, Cash: `#EAB64B`)
- **Angle:** `[Net Revenue]`
- **Center Label (Donut Hole):** Total Revenue `₹1.76M`.

---

## 3. Dashboard 2 — Sales & Footfall Analytics

**Target Audience:** Operations Manager & Marketing Strategy.  
**Objective:** Understand hourly traffic spikes (3 PM to 10 PM), commuter rushes, product category elasticities, and volume-versus-revenue dynamics.

### Worksheet Specifications

#### Sheet 2.1: Hourly Footfall & Revenue Heatmap
- **Columns:** `[Sale Hour]` (Continuous integer 15 to 22, alias display: `3 PM` to `10 PM`)
- **Rows:** `[Day of Week]` (Monday through Sunday)
- **Marks:** Square
- **Color:** `[Net Revenue]` or `[Total Plates Sold]` (Palette: Dark charcoal to Vibrant Saffron `#EAB64B`)
- **Insight Highlight:** The 6 PM – 8 PM window displays vibrant heat, evidencing the evening commuter surge.

#### Sheet 2.2: Category Performance & Plate Mix
- **Columns:** `[Category]`
- **Rows:** `[Total Plates Sold]`
- **Color:** `[Category]`
- **Marks:** Packed Bubble or Stacked Bar.

#### Sheet 2.3: Quantity vs. Revenue Scatter Plot (Price Elasticity)
- **Columns:** `[Total Plates Sold]` (Measure)
- **Rows:** `[Net Revenue]` (Measure)
- **Detail:** `[Product Name]`
- **Size:** `[Gross Profit]`
- **Color:** `[Category]`
- **Analytics Line:** Add Trend Line and Reference Line at Average Plates.

#### Sheet 2.4: Multi-Period Granularity Switcher
- Create a Parameter `[Granularity Selector]`: `"Daily"`, `"Weekly"`, `"Monthly"`.
- Use a calculated date:
  ```tableau
  CASE [Granularity Selector]
    WHEN "Daily" THEN DATETRUNC('day', [Sale Date])
    WHEN "Weekly" THEN DATETRUNC('week', [Sale Date])
    WHEN "Monthly" THEN DATETRUNC('month', [Sale Date])
  END
  ```
- Drag this field to Columns to allow instant time-horizon shifting.

---

## 4. Dashboard 3 — Inventory Runway & Food Waste Audit

**Target Audience:** Kitchen Operations & Food Safety Auditor.  
**Objective:** Track raw material consumption, monitor low-stock thresholds, pinpoint shrinkage, and audit food waste costs.

### Worksheet Specifications

#### Sheet 3.1: Current Stock vs. Reorder Level (Gauge / Bullet Chart)
- **Data Source:** `tableau_inventory`
- **Rows:** `[Ingredient Name]`
- **Columns:** `[Quantity]` where `[Transaction Type] = 'CONSUMPTION'` vs `'PURCHASE'`
- **Reference Line:** Per-Cell Reference Line set to `[Reorder Level]`.
- **Alert Color:** Calculated field `[Stock Health Status]`:
  - Critical (< 50% reorder level): `#D98768` (Terracotta)
  - Low Stock (<= reorder level): `#EAB64B` (Saffron)
  - Healthy: `#A7D78A` (Sage Green)

#### Sheet 3.2: Food Waste Cost by Ingredient
- **Filter:** `[Transaction Type] = 'WASTE'`
- **Columns:** `[Extended Cost]` (SUM)
- **Rows:** `[Ingredient Name]` (Sorted descending)
- **Color:** `#D98768` (Terracotta)
- **Finding:** Suji & Atta Puris and Mint Pani represent over 77% of all recorded waste losses.

#### Sheet 3.3: Consumption vs. Waste Ratio Dual Bar
- **Rows:** `[Ingredient Name]`
- **Columns:** Measure Values (`[Consumption Volume]` and `[Waste Volume]`)
- **Marks:** Clustered Bar or Stacked Bar.

#### Sheet 3.4: Daily Waste Loss Trend
- **Data Source:** `tableau_daily_summary`
- **Columns:** `[Sale Date]`
- **Rows:** `[Daily Waste Cost]`
- **Marks:** Bar Chart with reference line at Average Daily Waste (₹63.88).

---

## 5. Dashboard 4 — Financial Expenses & Operating Profitability

**Target Audience:** Business Owner & Financial Controller.  
**Objective:** Distinguish Gross Profit from Bottom-Line Operating Profit, track overhead categories, and audit stall viability.

```
┌────────────────────────────────────────────────────────────────────────┐
│  GOLGAPPA360 — EXECUTIVE P&L & OPERATING PROFITABILITY                 │
├────────────────────────────────────────────────────────────────────────┤
│ Net Revenue: ₹17,59,965   COGS: ₹4,92,958   Gross Profit: ₹12,67,007   │
│ Operating Expenses: ₹1,26,540     ESTIMATED OPERATING PROFIT: ₹11,40,467│
├────────────────────────────────────────┬───────────────────────────────┤
│ Worksheet 4.1: Monthly P&L Waterfall   │ Worksheet 4.3: Expense Pareto │
│ Revenue -> COGS -> Gross -> Opex -> Net│ Stacked Bar by Category       │
├────────────────────────────────────────┼───────────────────────────────┤
│ Worksheet 4.2: Operating Margin Trend  │ Worksheet 4.4: Variety Margin │
│ Daily Gross Profit vs Total Overheads  │ Unit Margin % by Variety      │
└────────────────────────────────────────┴───────────────────────────────┘
```

### Accounting Definitions & Guardrails
- **Gross Profit:** Net Revenue − COGS (Ingredient costs). Total: **₹1,267,007.10** (71.99%).
- **Operating Overheads:** Stall rent, electricity/ice, LPG gas, packaging donas, rickshaw freight. Total: **₹126,540.06**.
- **Estimated Operating Profit:** Gross Profit − Operating Expenses. Total: **₹1,140,467.04** (64.80%).
- *Guardrail:* Do **not** deduct inventory purchases as operating expenses. Inventory purchases are balance-sheet assets; only consumed/sold goods (COGS) and actual overhead vouchers belong on the P&L!

### Worksheet Specifications

#### Sheet 4.1: Operating Expenses by Category (Donut / Pareto Chart)
- **Data Source:** `tableau_expenses`
- **Angle:** `SUM([Amount])`
- **Color:** `[Expense Category]`
  - Stall Rent: `#A7D78A`
  - Packaging & Disposables: `#EAB64B`
  - Utilities & Ice Blocks: `#7BC0C0`
  - LPG Gas Commercial Cylinders: `#D98768`
  - Sanitation & Freight: `#A594F9`
- **Center Label:** Total Overheads `₹126,540`.

#### Sheet 4.2: Gross Profit vs. Operating Expenses Time-Series
- **Data Source:** `tableau_daily_summary`
- **Columns:** `[Sale Date]`
- **Rows:** Dual Axis:
  - Axis 1: `[Gross Profit]` (Area Chart, `#A7D78A`, 25% opacity)
  - Axis 2: `[Operating Expenses]` (Line Chart, `#D98768`, 2px solid)
- **Synchronization:** Enabled. Demonstrates high operating leverage: overheads are stable at ~₹695/day while gross profit scales with footfall.

#### Sheet 4.3: Product Unit Contribution Margin Comparison
- **Data Source:** `tableau_products`
- **Columns:** `[Product Name]`
- **Rows:** Dual Bar:
  - `[Selling Price]` (Height of bar)
  - `[Ingredient Cost Per Plate]` (Embedded baseline)
- **Label:** `[Unit Gross Margin %]` displayed at bar apex.

---

## 6. Tableau Interactivity & User Experience Configuration

### 1. Global Date Filter Across All Sheets
1. Place `[Sale Date]` on Filters shelf in Sheet 1.2.
2. Right-click the filter pill > **Apply to Worksheets > All Using Related Data Sources**.
3. In Dashboard 1, click the container dropdown > **Filters > Date (Range of Dates)**.
4. Style: Slider with custom text entries in `#F5F4F1`.

### 2. Dashboard Filter Actions (One-Click Cross-Filtering)
1. Go to **Dashboard > Actions > Add Action > Filter**.
2. **Action 1 (Product Filter):**
   - Source Sheet: `Sheet 1.4 (Product Contribution)`
   - Target Sheets: All sheets in Dashboard 1
   - Run Action On: **Select**
   - Clearing the selection will: **Show all values**
   - *Result:* Clicking "Classic Golgappa" instantly filters the trend line, KPI cards, and weekday chart to Classic Golgappa!
3. **Action 2 (Weekday Highlight):**
   - Source Sheet: `Sheet 1.3 (Sales by Weekday)`
   - Target Sheets: All sheets
   - Run Action On: **Hover** (Highlight Action)

### 3. Custom Hover Tooltips (Glassmorphism Tooltip Design)
In Worksheet Marks card, click **Tooltip** and insert HTML-styled plain text:
```
<Sheet Name>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Variety:       <Product Name>
Category:      <Category>
────────────────────────────────────────
Plates Served: <SUM(Quantity Plates)> plates
Net Revenue:   <SUM(Net Revenue)>
Gross Margin:  <[Gross Margin %]>
Profit Contrib:<SUM(Gross Profit)>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
Set tooltip background to Dark `#262628` with white text.

### 4. Device Layouts & Responsive Previews
1. In the Dashboard panel, click **Device Preview**.
2. **Default Layout:** 1366 × 768 px (Fixed Desktop 16:9).
3. **Tablet Layout:** 1024 × 768 px. Reorganize cards into 2 columns.
4. **Phone Layout:** 375 × 812 px. Stack cards vertically in a single scrollable container.

### 5. Tableau Story Points (Presentation Mode for Project Review)
Create a Tableau Story named **"Golgappa360 Executive Walkthrough"**:
- **Story Point 1:** *Business Health & Turnover* (Embeds Dashboard 1).
- **Story Point 2:** *Rush Hour Footfall & Variety Elasticity* (Embeds Dashboard 2).
- **Story Point 3:** *Shrinkage Audit & Raw Material Runway* (Embeds Dashboard 3).
- **Story Point 4:** *Bottom-Line P&L & Stall Viability* (Embeds Dashboard 4).
