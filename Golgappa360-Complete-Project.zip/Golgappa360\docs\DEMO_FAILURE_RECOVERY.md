# EV SMART: Demonstration Failure Recovery & Contingency Runbook
## Rapid Diagnostic Guide & Fallback Methods for Live Viva & Presentation Scenarios

---

## 1. Overview
During live academic evaluations or viva voce demonstrations, physical hardware or network anomalies can occasionally arise. This runbook details instant symptom identification, root causes, quick fixes, and controlled fallback demonstration methods for all 7 critical failure vectors.

---

## 2. Failure Recovery Matrix

### Scenario 1: Backend Server Not Starting
- **Symptom:** Terminal throws `EADDRINUSE: address already in use :::5000` or fails to bind.
- **Likely Cause:** A previously running background daemon or orphaned Node.js process is occupying port 5000.
- **Quick Fix:**
  ```powershell
  # Kill process occupying port 5000
  Stop-Process -Id (Get-NetTCPConnection -LocalPort 5000).OwningProcess -Force
  # Restart backend
  cd d:\antigravty\backend; node src/server.js
  ```
- **Fallback Demo Method:** Use the static demo responses cached in the frontend or launch the backup daemon with `PORT=5001`.

---

### Scenario 2: MongoDB Database Unavailable
- **Symptom:** Backend logs `MongooseServerSelectionError: connect ECONNREFUSED 127.0.0.1:27017`.
- **Likely Cause:** Local MongoDB Community service was stopped or crashed after a system reboot.
- **Quick Fix:**
  ```powershell
  # Start MongoDB service
  Start-Service -Name MongoDB
  # Or start mongod manually
  mongod --dbpath "C:\Program Files\MongoDB\Server\7.0\data"
  ```
- **Fallback Demo Method:** If local MongoDB cannot be restarted, update `MONGODB_URI` in `.env` to a cloud MongoDB Atlas cluster URI or start the ephemeral Docker container:
  ```bash
  docker run -d -p 27017:27017 --name evsmart-mongo mongo:7
  ```

---

### Scenario 3: Physical ESP32 Offline or Not Connecting to Wi-Fi
- **Symptom:** Admin Dashboard shows charger status `OFFLINE`; no hardware clicks occur.
- **Likely Cause:** College or venue Wi-Fi network requires a captive portal login, or the 2.4 GHz SSID changed.
- **Quick Fix:**
  1. Turn on a mobile smartphone Wi-Fi hotspot matching the SSID/password configured in `firmware/include/config.h`.
  2. Press the `EN / RST` hardware button on the ESP32 breadboard.
  3. Verify the local 16x2 LCD displays a valid IP address.
- **Fallback Demo Method (Controlled Software Demonstration):**
  If physical hardware is unavailable or Wi-Fi is strictly restricted, use the built-in virtual device simulation:
  ```bash
  # Trigger controlled demo charging cycle via API
  curl -X POST http://127.0.0.1:5000/api/demo/run-cycle -H "Content-Type: application/json" -d '{"energyConsumed": 18.4}'
  ```
  This executes the complete booking $\to$ live telemetry $\to$ bill $\to$ AI pipeline on screen without physical hardware.

---

### Scenario 4: MQTT Broker Unavailable
- **Symptom:** Backend logs `[MQTT Bridge Error]: connect ECONNREFUSED 127.0.0.1:1883`.
- **Likely Cause:** Mosquitto service is not running or port 1883 is blocked.
- **Quick Fix:**
  ```powershell
  Start-Service -Name mosquitto
  # Or start standalone broker
  mosquitto -p 1883 -v
  ```
- **Fallback Demo Method:** The ESP32 firmware features automatic HTTP REST fallback! If MQTT fails, the microcontroller autonomously switches to HTTP `POST /api/sensors/readings` to ingest telemetry.

---

### Scenario 5: Mobile App Cannot Connect from Physical iPhone
- **Symptom:** iPhone Safari displays `Could not connect to server` when opening the app.
- **Likely Cause:** iPhone is on a different Wi-Fi network (cellular data) or Windows Defender Firewall is blocking inbound connections on port 5173 / 5000.
- **Quick Fix:**
  1. Ensure both the PC and iPhone are connected to the exact same Wi-Fi network or mobile hotspot.
  2. Open the URL using the computer's LAN IP address: `http://192.168.29.23:5173`.
  3. Allow Node.js through Windows Firewall:
     ```powershell
     New-NetFirewallRule -DisplayName "EV Smart Vite" -Direction Inbound -LocalPort 5173 -Protocol TCP -Action Allow
     New-NetFirewallRule -DisplayName "EV Smart Backend" -Direction Inbound -LocalPort 5000 -Protocol TCP -Action Allow
     ```
- **Fallback Demo Method:** Toggle "Phone Frame" simulator directly in the desktop browser via the top navbar button.

---

### Scenario 6: Python AI / ML Microservice Unavailable
- **Symptom:** Admin AI tab shows `AI Service Temporarily Unavailable (Fallback Active)`.
- **Likely Cause:** Python Uvicorn process on port 8000 was terminated.
- **Quick Fix:**
  ```powershell
  cd d:\antigravty\ml-service
  python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
  ```
- **Fallback Demo Method:** The Node.js backend has a high-reliability mathematical regression fallback (`mlClient.js`). It automatically provides deterministic load estimates with 95% confidence intervals and envelope anomaly scoring, ensuring the system never crashes.

---

### Scenario 7: Payment Gateway Webhook Unavailable
- **Symptom:** Driver checkout modal shows payment pending.
- **Likely Cause:** External internet access down or webhook timeout.
- **Quick Fix:** Tap "Pay with Pre-loaded Demo Wallet" directly in the driver modal.
- **Fallback Demo Method:** All payments operate in a cryptographically signed sandbox simulation (`[DEMO / SIMULATION]`). The backend automatically issues mock transaction IDs (`TXN_MOCK_*`) and generates printable Tax Invoices instantly.
