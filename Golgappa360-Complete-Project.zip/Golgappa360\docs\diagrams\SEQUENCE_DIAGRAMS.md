# EV SMART: Architectural Sequence Diagrams
## Detailed End-to-End Execution Sequences Across Key System Workflows

---

## 1. Slot Reservation & Conflict-Prevention Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Driver as EV Driver (App)
    participant API as Node.js Backend
    participant DB as MongoDB Database

    Driver->>API: POST /api/bookings {chargerId, startTime, endTime}
    Note over API: Extract JWT & verify driver identity
    API->>DB: findOne({chargerId, status: "CONFIRMED", overlapCondition})
    alt Slot is already occupied
        DB-->>API: Existing Confirmed Booking Found
        API-->>Driver: HTTP 409 Conflict: "Time slot already reserved"
    else Slot is available
        DB-->>API: null (No overlapping reservation)
        API->>DB: create({userId, chargerId, startTime, endTime, status: "CONFIRMED"})
        DB-->>API: Booking Document Saved
        API-->>Driver: HTTP 201 Created {bookingId, status: "CONFIRMED"}
        Driver->>Driver: Render Booking Confirmation Badge & Calendar Event
    end
```

---

## 2. Live Charging Session & 1Hz Telemetry Streaming Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Driver as EV Driver
    participant App as Driver Mobile App
    participant WS as Socket.IO Gateway
    participant Backend as Node.js Core Backend
    participant MQTT as Mosquitto MQTT Broker
    participant ESP32 as ESP32 Hardware Node
    participant Relay as 30A AC Relay

    Driver->>App: Scan Station QR Code
    App->>Backend: POST /api/sessions/start {chargerId}
    Backend->>Backend: Verify wallet balance (>= ₹100 reserve)
    Backend->>MQTT: Publish: ev/station/1/charger/1/command {"action": "START"}
    MQTT->>ESP32: Deliver START Command
    ESP32->>Relay: Assert GPIO 26 LOW (Engage Relay)
    Relay-->>ESP32: Contacts Closed (AC Power Flowing)
    ESP32-->>MQTT: Publish Status: "CHARGING"
    Backend->>App: HTTP 200 OK {sessionId, status: "ACTIVE"}
    App->>WS: Join Room "charger_1" & "session_123"

    loop Every 1 Second (1 Hz Telemetry Streaming)
        ESP32->>ESP32: Read PZEM-004T (V, I, P, E) & DHT22 (T)
        ESP32->>MQTT: Publish: ev/station/1/charger/1/telemetry {V:231, I:15.8, P:3.65, T:34.2}
        MQTT->>Backend: Ingest Telemetry Payload
        Backend->>Backend: Compute incremental energy & update session
        Backend->>WS: io.to("charger_1").emit("telemetry_update", payload)
        WS-->>App: Receive telemetry_update
        App->>App: Update Circular SOC Gauge, Sparkline Graphs & Cost Counter
    end
```

---

## 3. Session Stop, Wallet Settlement & Invoicing Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Driver as EV Driver
    participant App as Driver Mobile App
    participant Backend as Node.js Core Backend
    participant MQTT as Mosquitto MQTT Broker
    participant ESP32 as ESP32 Controller
    participant DB as MongoDB Database

    Driver->>App: Tap "Stop Charging" Button
    App->>Backend: POST /api/sessions/stop {sessionId}
    Backend->>MQTT: Publish: ev/station/1/charger/1/command {"action": "STOP"}
    MQTT->>ESP32: Deliver STOP Command
    ESP32->>ESP32: Assert GPIO 26 HIGH (Open Relay Contacts)
    ESP32-->>MQTT: Publish Status: "AVAILABLE"
    
    Backend->>DB: Update Session: status = "COMPLETED", endTime = Date.now()
    Backend->>Backend: Compute Final Bill: (Energy * Dynamic Tariff) + Platform Fee + GST
    Backend->>DB: Atomic Update: User.findOneAndUpdate({_id: userId, balance: {$gte: bill}}, {$inc: {balance: -bill}})
    Backend->>DB: Create Invoice Record & Transaction Ledger Entry
    Backend-->>App: HTTP 200 OK {invoice: {totalKWh: 14.8, bill: ₹178.50, txnId: "TXN_MOCK_9921"}}
    App->>App: Display Itemized Digital Receipt Modal & Download Invoice CTA
```

---

## 4. Autonomous Edge Fault Cutoff & Admin Triage Sequence

```mermaid
sequenceDiagram
    autonumber
    participant Sensor as DHT22 / PZEM Sensors
    participant Core0 as ESP32 Core 0 (FreeRTOS Safety Task)
    participant Relay as 30A AC Relay
    participant Core1 as ESP32 Core 1 (Network Task)
    participant MQTT as Mosquitto MQTT Broker
    participant Backend as Node.js Core Backend
    actor Admin as Fleet Admin Dashboard

    Sensor->>Core0: Enclosure Temp = 63.8°C (Threshold > 60°C breached!)
    Note over Core0: Autonomous Edge Trip triggered in <50ms without cloud!
    Core0->>Relay: Assert GPIO 26 HIGH (Force Relay Open Instantly)
    Relay-->>Core0: AC Power Disconnected
    Core0->>Core0: Sound Audible Alarm Buzzer & Update Local LCD
    Core0->>Core1: Push Emergency Alert to FreeRTOS Queue
    Core1->>MQTT: Publish: ev/station/1/charger/1/fault {"fault": "OVER_TEMP", "val": 63.8}
    MQTT->>Backend: Deliver Fault Event
    Backend->>Backend: Transition Charger Status to "FAULTED"
    Backend->>Backend: Log Entry to Immutable AuditLogs Collection
    Backend->>Admin: WebSocket: emergency_alert {chargerId: 1, reason: "Thermal Cutoff 63.8°C"}
    Admin->>Admin: Play Alert Chime & Highlight Red in Fleet Status Grid
```
