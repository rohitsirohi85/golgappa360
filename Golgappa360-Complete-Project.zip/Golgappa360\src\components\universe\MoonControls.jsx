import React from 'react';

/**
 * MoonControls — Interactive HUD controls for Moon Exploration (Phase U6)
 * 
 * Features:
 * - Back to Earth navigation
 * - Back to Solar System navigation
 * - Back to Universe Map navigation
 * - Rotation play/pause
 * - Zoom & Reset view controls
 */
export default function MoonControls({
  onBackToEarth,
  onBackToSolarSystem,
  onBackToUniverse,
  isRotating,
  onToggleRotation,
  onZoomIn,
  onZoomOut,
  onResetView,
  className = '',
}) {
  return (
    <div className={`flex flex-wrap items-center gap-2 bg-[#020308]/85 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.85)] ${className}`}>
      {/* Back to Earth */}
      <button
        type="button"
        onClick={onBackToEarth}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/90 border border-cyan-400/60 text-cyan-200 hover:text-white text-xs font-mono font-medium transition-all cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.25)] group"
        title="Return to Earth exploration"
      >
        <span className="text-cyan-400 group-hover:-translate-x-0.5 transition-transform">←</span>
        <span>EARTH</span>
      </button>

      {/* Back to Solar System */}
      <button
        type="button"
        onClick={onBackToSolarSystem}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-amber-400/40 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer"
        title="Return to Solar System"
      >
        <span>🪐</span>
        <span className="hidden sm:inline">SOLAR SYSTEM</span>
      </button>

      {/* Back to Universe */}
      {onBackToUniverse && (
        <button
          type="button"
          onClick={onBackToUniverse}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 text-slate-400 hover:text-white text-xs font-mono transition-all cursor-pointer"
          title="Return to full Universe Map"
        >
          <span>🌌</span>
          <span>UNIVERSE</span>
        </button>
      )}

      <div className="h-4 w-[1px] bg-white/10 mx-0.5 hidden sm:block" />

      {/* Rotation Play / Pause */}
      <button
        type="button"
        onClick={onToggleRotation}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-mono transition-all cursor-pointer ${
          isRotating
            ? 'bg-white/[0.04] hover:bg-white/[0.08] border-white/10 text-slate-200'
            : 'bg-amber-500/20 border-amber-500/40 text-amber-200'
        }`}
        title={isRotating ? 'Pause Moon rotation' : 'Resume Moon rotation'}
      >
        <span>{isRotating ? '⏸' : '▶'}</span>
        <span className="hidden sm:inline">{isRotating ? 'PAUSE' : 'PLAY'}</span>
      </button>

      {/* Zoom Controls */}
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={onZoomIn}
          className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
          title="Zoom in (+)"
        >
          +
        </button>
        <button
          type="button"
          onClick={onZoomOut}
          className="w-8 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white flex items-center justify-center text-sm font-mono transition-all cursor-pointer"
          title="Zoom out (−)"
        >
          −
        </button>
        <button
          type="button"
          onClick={onResetView}
          className="px-2.5 h-8 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white text-xs font-mono transition-all cursor-pointer flex items-center gap-1"
          title="Reset Moon view"
        >
          <span>⟲</span>
          <span className="hidden md:inline">RESET</span>
        </button>
      </div>
    </div>
  );
}
