import React, { useState } from 'react';

/**
 * TemperatureColorGuide — "WHY ARE STARS DIFFERENT COLORS?"
 * Visualizes Wien's Law of blackbody thermal radiation:
 * BLUE (30,000 K+) -> WHITE (10,000 K) -> YELLOW (6,000 K) -> ORANGE (4,000 K) -> RED (3,000 K)
 */
export default function TemperatureColorGuide() {
  const [activeTempIndex, setActiveTempIndex] = useState(2); // Default to Yellow (6,000 K)

  const steps = [
    {
      temp: '30,000 K+',
      colorLabel: 'BLUE',
      wavelength: '≈ 100–250 nm (UV & Blue)',
      example: 'Rigel, Spica, Zeta Puppis',
      hex: '#00d2ff',
      glow: 'rgba(0, 210, 255, 0.6)',
      explanation: 'Extremely high thermal kinetic energy causes electrons to radiate predominantly in ultra-short, high-frequency blue and ultraviolet wavelengths.',
    },
    {
      temp: '10,000 K',
      colorLabel: 'WHITE',
      wavelength: '≈ 300–450 nm (Blue & Visible White)',
      example: 'Sirius A, Vega',
      hex: '#f8fafc',
      glow: 'rgba(248, 250, 252, 0.6)',
      explanation: 'Radiates across the entire human visual spectrum evenly, creating a pure diamond-white optical appearance to the naked human eye.',
    },
    {
      temp: '6,000 K',
      colorLabel: 'YELLOW',
      wavelength: '≈ 500–550 nm (Peak Green/Yellow)',
      example: 'Sun, Alpha Centauri A',
      hex: '#fbbf24',
      glow: 'rgba(251, 191, 36, 0.6)',
      explanation: 'Peaks directly in the yellow-green visual band. Our Sun sits squarely here, providing the optimal spectral envelope for terrestrial vision.',
    },
    {
      temp: '4,000 K',
      colorLabel: 'ORANGE',
      wavelength: '≈ 600–650 nm (Orange & Red)',
      example: 'Arcturus, Aldebaran',
      hex: '#fb923c',
      glow: 'rgba(251, 146, 60, 0.6)',
      explanation: 'Moderate thermal energies shift the peak emission toward longer orange wavelengths as surface atmospheric gases expand and cool.',
    },
    {
      temp: '3,000 K',
      colorLabel: 'RED',
      wavelength: '≈ 700–900 nm (Near-Infrared & Red)',
      example: 'Betelgeuse, Proxima Centauri',
      hex: '#ef4444',
      glow: 'rgba(239, 68, 68, 0.6)',
      explanation: 'Coolest stellar surfaces emit predominantly infrared and deep visible red photons, giving dying supergiants and red dwarfs their garnet glow.',
    },
  ];

  const currentStep = steps[activeTempIndex];

  return (
    <div className="w-full flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-cyan-500/20 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>THERMAL RADIATION PHYSICS</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          WHY ARE STARS DIFFERENT COLORS?
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/85 leading-relaxed max-w-2xl mx-auto">
          A star’s surface temperature strongly influences the color of light it emits.
          Governed by Planck and Wien’s laws, hotter stars radiate high-energy blue photons, while cooler stars radiate low-energy red photons.
        </p>
      </div>

      {/* Main Interactive Spectrum Guide Container */}
      <div className="w-full p-6 sm:p-8 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
        {/* Continuous Gradient Thermal Bar */}
        <div className="relative mb-8">
          <div className="h-4 sm:h-5 w-full rounded-full bg-gradient-to-r from-[#00d2ff] via-[#f8fafc] via-[#fbbf24] via-[#fb923c] to-[#ef4444] shadow-[0_0_25px_rgba(56,189,248,0.35)]" />

          {/* Interactive Steps Markers */}
          <div className="grid grid-cols-5 gap-1 sm:gap-2 mt-4">
            {steps.map((step, idx) => {
              const isActive = activeTempIndex === idx;
              return (
                <button
                  key={step.temp}
                  type="button"
                  onClick={() => setActiveTempIndex(idx)}
                  className={`flex flex-col items-center p-2 rounded-xl transition-all duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                    isActive
                      ? 'bg-white/10 scale-105 border border-white/20 shadow-lg'
                      : 'hover:bg-white/5 opacity-70 hover:opacity-100'
                  }`}
                >
                  <span
                    className="font-display text-xs sm:text-base font-bold"
                    style={{ color: step.hex }}
                  >
                    {step.temp}
                  </span>
                  <span className="text-[10px] sm:text-xs font-mono text-slate-300 uppercase tracking-wider mt-0.5">
                    {step.colorLabel}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Temperature Physics Dossier */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center p-5 sm:p-6 rounded-2xl bg-[#020308]/60 border border-white/8">
          <div className="md:col-span-4 flex flex-col items-start">
            <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 mb-1">
              SELECTED REGIME:
            </span>
            <div
              className="font-display text-2xl sm:text-3xl font-semibold"
              style={{ color: currentStep.hex }}
            >
              {currentStep.temp} — {currentStep.colorLabel}
            </div>
            <div className="mt-2 text-xs font-mono text-cyan-300">
              Peak: {currentStep.wavelength}
            </div>
            <div className="mt-1 text-xs font-mono text-slate-400">
              Stars: <strong className="text-white">{currentStep.example}</strong>
            </div>
          </div>

          <div className="md:col-span-8 border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6">
            <h5 className="text-xs font-mono uppercase tracking-widest text-slate-300 mb-2 font-semibold">
              RADIATION MECHANISM:
            </h5>
            <p className="font-sans text-sm text-slate-200/90 leading-relaxed font-normal">
              {currentStep.explanation}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
