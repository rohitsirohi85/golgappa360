import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  MapPin,
  Moon,
  Globe,
  Fingerprint,
  Lock,
  HelpCircle,
  LogOut,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { Header } from '../components/common/Header';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';

export const SettingsScreen = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { showToast } = useUI();

  // Settings toggles
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(true);
  const [darkModeEnabled, setDarkModeEnabled] = useState(true);
  const [biometricsEnabled, setBiometricsEnabled] = useState(true);
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  const handleToggle = (setter, currentValue, name) => {
    setter(!currentValue);
    showToast(`${name} ${!currentValue ? 'enabled' : 'disabled'}`, 'info');
  };

  const handleLogout = () => {
    logout();
    showToast('Signed out of EV Smart', 'info');
    navigate('/login');
  };

  return (
    <div className="flex flex-col min-h-full pb-6 select-none">
      <Header title="Settings & Preferences" showBack onBack={() => navigate(-1)} />

      <div className="px-4 py-4 space-y-5">
        {/* General Toggles */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            System & Permissions
          </span>

          <div className="bg-[#0D1527] rounded-2xl border border-white/5 divide-y divide-white/5 overflow-hidden">
            {/* Notifications Toggle */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/5 text-slate-300">
                  <Bell className="w-4 h-4 text-[#00F5A0]" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Push Notifications
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Slot alerts & charging progress
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleToggle(setNotificationsEnabled, notificationsEnabled, 'Notifications')
                }
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  notificationsEnabled ? 'bg-[#00F5A0]' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`bg-[#050811] w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Location Toggle */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/5 text-slate-300">
                  <MapPin className="w-4 h-4 text-[#00E5FF]" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Location Services
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Automatic nearest station detection
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleToggle(setLocationEnabled, locationEnabled, 'Location Services')
                }
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  locationEnabled ? 'bg-[#00F5A0]' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`bg-[#050811] w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    locationEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/5 text-slate-300">
                  <Moon className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Dark Mode (OLED Neon)
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Energy saving high contrast
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleToggle(setDarkModeEnabled, darkModeEnabled, 'Dark Mode')
                }
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  darkModeEnabled ? 'bg-[#00F5A0]' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`bg-[#050811] w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    darkModeEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Biometric Login */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/5 text-slate-300">
                  <Fingerprint className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Biometric Unlock
                  </span>
                  <span className="text-[10px] text-slate-400">
                    FaceID or Fingerprint auth
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleToggle(setBiometricsEnabled, biometricsEnabled, 'Biometric Login')
                }
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  biometricsEnabled ? 'bg-[#00F5A0]' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`bg-[#050811] w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    biometricsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Language & Regional */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Language
          </span>

          <div className="bg-[#0D1527] rounded-2xl border border-white/5 p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-white/5 text-slate-300">
                <Globe className="w-4 h-4 text-blue-400" />
              </div>
              <span className="text-xs font-semibold text-white">App Language</span>
            </div>

            <select
              value={selectedLanguage}
              onChange={(e) => {
                setSelectedLanguage(e.target.value);
                showToast(`Language switched to ${e.target.value}`, 'info');
              }}
              className="bg-[#131E35] text-white text-xs border border-white/10 rounded-xl px-2.5 py-1.5 outline-none focus:border-[#00F5A0]"
            >
              <option value="English">English</option>
              <option value="Hindi">हिंदी (Hindi)</option>
              <option value="Kannada">ಕನ್ನಡ (Kannada)</option>
              <option value="Tamil">தமிழ் (Tamil)</option>
            </select>
          </div>
        </div>

        {/* Legal & Support */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Support & Privacy
          </span>

          <div className="bg-[#0D1527] rounded-2xl border border-white/5 divide-y divide-white/5 overflow-hidden">
            <button
              onClick={() => setIsPrivacyModalOpen(true)}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Lock className="w-4 h-4 text-slate-400" />
                <span>Privacy Policy</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => setIsHelpModalOpen(true)}
              className="w-full flex items-center justify-between p-3.5 text-xs text-slate-200 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <HelpCircle className="w-4 h-4 text-slate-400" />
                <span>Help & Customer Support</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
        </div>

        {/* Commercial Admin Access */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Commercial Fleet Platform
          </span>
          <div className="bg-[#0D1527] rounded-2xl border border-emerald-500/20 overflow-hidden">
            <button
              onClick={() => navigate('/admin/dashboard')}
              className="w-full flex items-center justify-between p-3.5 text-xs text-emerald-400 hover:bg-emerald-500/10 transition-colors"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-white">Open Admin Dashboard & Fleet Portal</span>
              </div>
              <ChevronRight className="w-4 h-4 text-emerald-400" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <div className="pt-2">
          <Button
            size="lg"
            variant="danger"
            fullWidth
            onClick={handleLogout}
            icon={LogOut}
          >
            Logout
          </Button>
        </div>
      </div>

      {/* Help Modal */}
      <Modal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
        title="24/7 EV Smart Support"
        subtitle="We're here to assist you with slots, stations and billing."
      >
        <div className="space-y-3 text-xs text-slate-300">
          <div className="p-3 rounded-xl bg-[#070B19] border border-white/5">
            <span className="text-slate-400 block font-semibold mb-0.5">Toll-Free Helpline</span>
            <span className="text-base font-bold text-[#00F5A0] font-mono">1800-419-EV-SMART</span>
          </div>

          <div className="p-3 rounded-xl bg-[#070B19] border border-white/5">
            <span className="text-slate-400 block font-semibold mb-0.5">Emergency Assistance Email</span>
            <span className="font-mono text-white">support@evsmart-charging.com</span>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            Emergency technician dispatch available at all flagship hubs including Green Valley EV Hub and City Center Station.
          </p>

          <Button fullWidth onClick={() => setIsHelpModalOpen(false)}>
            Close
          </Button>
        </div>
      </Modal>

      {/* Privacy Modal */}
      <Modal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
        title="Privacy & Data Protection"
        subtitle="How EV Smart protects your telematics and telemetry."
      >
        <div className="space-y-3 text-xs text-slate-300">
          <p className="leading-relaxed">
            Your EV vehicle telemetry (battery capacity, charging curve, power readings) is encrypted end-to-end and used strictly for energy load balancing and slot reservation optimization.
          </p>
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>GDPR & ISO 27001 EV Cyber Compliance</span>
          </div>
          <Button fullWidth onClick={() => setIsPrivacyModalOpen(false)}>
            I Understand
          </Button>
        </div>
      </Modal>
    </div>
  );
};
