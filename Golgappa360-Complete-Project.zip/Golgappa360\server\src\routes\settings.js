import express from 'express';
import { mockStore } from '../data/mockStore.js';
import { testConnection, getDbStatus } from '../config/db.js';

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const dbStatus = getDbStatus();
    res.json({
      success: true,
      data: {
        stall: mockStore.stallSettings,
        database: dbStatus
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/stall', (req, res) => {
  try {
    const updates = req.body;
    mockStore.stallSettings = {
      ...mockStore.stallSettings,
      ...updates
    };
    res.json({ success: true, data: mockStore.stallSettings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/test-db', async (req, res) => {
  try {
    const { host, port, user, password, database } = req.body;
    const testResult = await testConnection({
      host: host || 'localhost',
      port: port ? Number(port) : 3306,
      user: user || 'root',
      password: password !== undefined ? password : '',
      database: database || 'golgappa360_db'
    });

    res.json(testResult);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reset-demo', (req, res) => {
  try {
    mockStore.reset();
    res.json({ success: true, message: 'All demo datasets reloaded to fresh 30-day baseline.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
