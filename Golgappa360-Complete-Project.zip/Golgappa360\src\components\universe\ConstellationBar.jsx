import React from 'react';
import { CONSTELLATIONS_DATA } from '../../data/constellations.js';

/**
 * ConstellationBar — Quick Navigation Pills for Featured Constellations
 * 
 * Provides instantaneous camera flight to:
 * Orion, Ursa Major, Cassiopeia, Canis Major, Scorpius, and Leo.
 */
export default function ConstellationBar({
  selectedConstellationId = null,
  onSelectConstellation,
  className = '',
}) {
  return (
    <div
      className={`flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 select-none ${className}`}
      role="region"
      aria-label="Constellation Quick Selector"
    >
      <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded-lg bg-[#020308]/85 backdrop-blur-md border border-white/10 text-[11px] font-mono text-slate-400">
        <span className="text-cyan-400 text-xs">✨</span>
        <span className="uppercase tracking-wider font-semibold text-slate-300">Constellations</span>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        {CONSTELLATIONS_DATA.map((c) => {
          const isSelected = selectedConstellationId === c.id;

          return (
            <button
              key={c.id}
              type="button"
              onClick={() => onSelectConstellation(isSelected ? null : c.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all shrink-0 cursor-pointer border flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-cyan-500/25 text-white border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.35)]'
                  : 'bg-[#020308]/80 text-slate-300 border-white/10 hover:border-cyan-400/40 hover:text-white hover:bg-white/5'
              }`}
              title={`Explore ${c.name} (${c.commonTitle})`}
            >
              <span
                className="w-1.5 h-1.5 rounded-full"
                style={{
                  backgroundColor: c.accentColor || '#38bdf8',
                  boxShadow: isSelected ? `0 0 6px ${c.accentColor || '#38bdf8'}` : 'none',
                }}
              />
              <span>{c.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
