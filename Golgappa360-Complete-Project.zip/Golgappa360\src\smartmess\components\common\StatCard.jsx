import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

export const StatCard = ({
  title,
  value,
  unit,
  delta,
  trend, // 'up' | 'down' | 'neutral'
  subtext,
  icon: Icon,
  syntheticBenchmark = false,
}) => {
  const isPositiveWaste = trend === 'down' && (title.toLowerCase().includes('waste') || title.toLowerCase().includes('prepared'));
  const isGoodTrend = isPositiveWaste || (trend === 'up' && (title.toLowerCase().includes('saved') || title.toLowerCase().includes('mitigated') || title.toLowerCase().includes('meals')));

  return (
    <div className="relative rounded-xl bg-white border border-[#E4EAE5] p-5 transition-all duration-150 hover:border-[#D2DDD4]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <span className="text-xs font-medium text-[#77847C]">
            {title}
          </span>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-[#25332D] font-mono tracking-tight">
              {value}
            </span>
            {unit && (
              <span className="text-xs font-medium text-[#77847C]">
                {unit}
              </span>
            )}
          </div>
        </div>

        {Icon && (
          <div className="p-2 rounded-lg bg-[#E9F6EE] text-[#16865B] shrink-0">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      {(delta || subtext) && (
        <div className="mt-4 flex items-center justify-between text-xs pt-3 border-t border-[#E4EAE5]">
          <div className="flex items-center gap-1.5">
            {delta && (
              <span
                className={`inline-flex items-center text-xs font-medium px-1.5 py-0.5 rounded ${
                  isGoodTrend
                    ? 'bg-[#E9F6EE] text-[#16865B]'
                    : 'bg-[#FEF2F2] text-[#B91C1C]'
                }`}
              >
                {trend === 'down' ? (
                  <ArrowDownRight className="w-3 h-3 mr-0.5" />
                ) : (
                  <ArrowUpRight className="w-3 h-3 mr-0.5" />
                )}
                {delta}
              </span>
            )}
            {subtext && <span className="text-[#77847C] text-[11px] truncate">{subtext}</span>}
          </div>

          {syntheticBenchmark && (
            <span className="text-[10px] font-mono text-[#77847C]/70" title="Synthetic benchmark observation">
              [SIM]
            </span>
          )}
        </div>
      )}
    </div>
  );
};
