import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

export function StatCard({
  title,
  value,
  subvalue,
  change,
  isPositive = true,
  icon: Icon,
  iconColor = 'text-[#A7D78A]',
  iconBg = 'bg-white/[0.08]',
  accentColor = '#A7D78A',
  badgeText
}) {
  return (
    <div className="glass-card p-5 hover:border-white/20 hover:-translate-y-0.5 hover:shadow-[0_16px_45px_rgba(0,0,0,0.30)] transition-all duration-200 relative overflow-hidden group">
      {/* Subtle top indicator bar */}
      {accentColor && (
        <div
          className="absolute top-0 left-0 right-0 h-0.5 opacity-80"
          style={{ backgroundColor: accentColor }}
        />
      )}

      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-[#929195] font-sans">
            {title}
          </p>
          <h3 className="text-2xl lg:text-3xl font-bold text-[#F5F4F1] mt-1.5 tracking-tight font-sans">
            {value}
          </h3>
        </div>

        {Icon && (
          <div className={`w-10 h-10 rounded-xl ${iconBg} ${iconColor} flex items-center justify-center shrink-0 border border-white/10 transition-transform duration-200 group-hover:scale-105 shadow-inner`}>
            <Icon className="w-4.5 h-4.5" />
          </div>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-sans">
        {change !== undefined && (
          <div className={`inline-flex items-center gap-1 font-semibold ${isPositive ? 'text-[#A7D78A]' : 'text-[#E58B79]'}`}>
            {isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
            <span>{change}</span>
            <span className="text-[#929195] font-normal ml-0.5">vs last month</span>
          </div>
        )}

        {badgeText && (
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/[0.08] text-[#B8B7B9] border border-white/10">
            {badgeText}
          </span>
        )}

        {subvalue && !badgeText && (
          <span className="text-[#B8B7B9] font-medium ml-auto">
            {subvalue}
          </span>
        )}
      </div>
    </div>
  );
}
