import { api } from './api';
import { MOCK_BOOKINGS } from '../data/mockBookings';

export const bookingService = {
  getMyBookings: async () => {
    try {
      const data = await api.get('/bookings/my');
      if (Array.isArray(data) && data.length > 0) {
        return data.map((b) => ({
          id: b._id,
          stationId: b.stationId?._id || b.stationId,
          stationName: b.stationId?.name || 'Green Valley EV Hub',
          stationAddress: b.stationId?.address || 'Silicon Gateway, Sector 5',
          chargerId: b.chargerId?._id || b.chargerId,
          chargerName: b.chargerId?.chargerNumber || 'Charger 01',
          power: b.chargerId?.powerRating || '60 kW',
          connector: b.chargerId?.connectorType || 'CCS2',
          date: b.bookingDate,
          time: `${b.startTime} – ${b.endTime}`,
          rate: b.chargerId?.pricePerKwh || 10,
          estimatedCost: `₹${b.estimatedCost || 180}`,
          status: b.status === 'confirmed' ? 'Confirmed' : b.status === 'completed' ? 'Completed' : 'Cancelled',
          createdAt: b.createdAt,
        }));
      }
      return [...MOCK_BOOKINGS];
    } catch (err) {
      console.warn('Backend getMyBookings fallback:', err.message);
      return [...MOCK_BOOKINGS];
    }
  },

  createBooking: async (bookingData) => {
    try {
      const payload = {
        stationId: bookingData.stationId,
        chargerId: bookingData.chargerId,
        vehicleId: bookingData.vehicleId,
        bookingDate: bookingData.date || '24 Sep 2026',
        startTime: (bookingData.time || '04:00 PM – 05:00 PM').split('–')[0]?.trim() || '04:00 PM',
        endTime: (bookingData.time || '04:00 PM – 05:00 PM').split('–')[1]?.trim() || '05:00 PM',
        estimatedCost: bookingData.estimatedCost ? Number(bookingData.estimatedCost) : 180,
      };

      const data = await api.post('/bookings', payload);
      return {
        id: data._id,
        stationId: data.stationId?._id || data.stationId,
        stationName: data.stationId?.name || bookingData.stationName,
        stationAddress: data.stationId?.address || bookingData.stationAddress,
        chargerId: data.chargerId?._id || data.chargerId,
        chargerName: data.chargerId?.chargerNumber || bookingData.chargerName,
        power: data.chargerId?.powerRating || '60 kW',
        connector: data.chargerId?.connectorType || 'CCS2',
        date: data.bookingDate,
        time: `${data.startTime} – ${data.endTime}`,
        rate: data.chargerId?.pricePerKwh || 10,
        status: 'Confirmed',
        createdAt: data.createdAt,
      };
    } catch (err) {
      console.warn('Backend createBooking fallback to local:', err.message);
      return {
        id: `EV${Date.now()}`,
        status: 'Confirmed',
        createdAt: new Date().toISOString(),
        ...bookingData,
      };
    }
  },

  cancelBooking: async (bookingId, reason = 'Cancelled by user') => {
    try {
      if (bookingId && bookingId.match(/^[0-9a-fA-F]{24}$/)) {
        await api.put(`/bookings/${bookingId}/cancel`, { reason });
      }
      return { success: true, bookingId, status: 'Cancelled' };
    } catch (err) {
      console.warn('Backend cancelBooking fallback:', err.message);
      return { success: true, bookingId, status: 'Cancelled' };
    }
  },
};
