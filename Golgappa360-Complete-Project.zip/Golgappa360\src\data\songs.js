export const songs = [
  {
    id: "song-1",
    title: "Midnight Highway Drive",
    artist: "The Midnight Echoes",
    artistId: "art-1",
    album: "Neon Afterglow",
    albumId: "alb-1",
    year: 2023,
    genre: "Synthwave",
    language: "English",
    duration: "3:48",
    durationSec: 228,
    plays: "1.4M",
    coverUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 96,
    matchingSnippet: "Neon lights reflected in the windshield glass, racing down an empty boulevard",
    lyrics: [
      { type: "verse", lines: [
        "Headlights cutting through the velvet haze",
        "Counting down the exits of our forgotten days",
        "Your silence humming like an engine drone",
        "We're travelling together but we feel alone"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Neon lights reflected in the windshield glass",
        "Racing down an empty boulevard too fast",
        "If I remember the lyrics to our favorite tune",
        "Will the echoes bring me back to you beneath the moon?"
      ]}
    ],
    songDNA: {
      mood: "Chill & Nostalgic",
      energy: 65,
      danceability: 58,
      romance: 72,
      sadness: 45,
      acousticness: 20,
      tempo: "112 BPM"
    },
    moodCategory: "Chill",
    description: "An atmospheric retro-synth pop anthem featuring driving drum machines and yearning vocals for late-night drives."
  },
  {
    id: "song-2",
    title: "Bheegi Baarish Ki Dhun",
    artist: "Aarav Sen",
    artistId: "art-2",
    album: "Bheegi Shaam",
    albumId: "alb-2",
    year: 2022,
    genre: "Indie Folk",
    language: "Hindi",
    duration: "4:12",
    durationSec: 252,
    plays: "3.2M",
    coverUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 94,
    matchingSnippet: "Ek bheegi shaam mein jab tum yaad aate ho, khidki pe barasti boondon se baatein hoti hain",
    lyrics: [
      { type: "verse", lines: [
        "Khamosh kamre mein ek chai ki pyaali",
        "Puraani kitaabon mein dhoondi nishaani",
        "Hawaein jo aayi hain chhu ke badan ko",
        "Phir se suna gayi teri kahani"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Ek bheegi shaam mein jab tum yaad aate ho",
        "Khidki pe barasti boondon se baatein hoti hain",
        "Koshish toh ki thi bhool jaane ki magar",
        "Har saans mein teri hi aahatein hoti hain"
      ]}
    ],
    songDNA: {
      mood: "Sad & Melancholic",
      energy: 35,
      danceability: 25,
      romance: 88,
      sadness: 92,
      acousticness: 85,
      tempo: "76 BPM"
    },
    moodCategory: "Sad",
    description: "Heartfelt acoustic ballad capturing the ache of monsoon longing and memories of lost companionship."
  },
  {
    id: "song-3",
    title: "Electric Mirage",
    artist: "Luna Vance",
    artistId: "art-3",
    album: "Velvet Static",
    albumId: "alb-3",
    year: 2024,
    genre: "Alt-Pop",
    language: "English",
    duration: "3:15",
    durationSec: 195,
    plays: "4.8M",
    coverUrl: "https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 91,
    matchingSnippet: "Spinning in velvet shadows with a ghost on the floor",
    lyrics: [
      { type: "verse", lines: [
        "Flicker like a broken strobe light in the dark",
        "You always know precisely how to leave your mark",
        "A chemical whisper sliding down my spine",
        "Tasting the vertigo of your sweet design"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Spinning in velvet shadows with a ghost on the floor",
        "Electric mirage whispering give me more",
        "I hear your pulse inside the stereo hum",
        "Waiting for the heartbreak rhythm to come"
      ]}
    ],
    songDNA: {
      mood: "Energetic & Dark",
      energy: 88,
      danceability: 82,
      romance: 60,
      sadness: 30,
      acousticness: 10,
      tempo: "128 BPM"
    },
    moodCategory: "Energetic",
    description: "A bass-heavy alt-pop banger with dark sensual undertones and infectious rhythmic cadence."
  },
  {
    id: "song-4",
    title: "Chandigarh De Raah",
    artist: "Kabir Dhillon",
    artistId: "art-4",
    album: "Virasat Beats",
    albumId: "alb-4",
    year: 2023,
    genre: "Punjabi Pop",
    language: "Punjabi",
    duration: "3:30",
    durationSec: 210,
    plays: "5.1M",
    coverUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 89,
    matchingSnippet: "Gaddi vich beat baje Chandigarh de raah te, akhan vich supne te yaaran da sahara",
    lyrics: [
      { type: "verse", lines: [
        "Suraj chadhya pind ton shehar val nu tur pe",
        "Dilan vich josh te sir te pagg sajje",
        "Maa di duawan da saya naal khada ae",
        "Mehnat da mull rab aape paave"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Gaddi vich beat baje Chandigarh de raah te",
        "Akhan vich supne te yaaran da sahara",
        "Zindagi da safar jivein jhanjhar da shankaar",
        "Har mod te labhde nawa nazara"
      ]}
    ],
    songDNA: {
      mood: "Party & Swagger",
      energy: 95,
      danceability: 90,
      romance: 40,
      sadness: 15,
      acousticness: 15,
      tempo: "135 BPM"
    },
    moodCategory: "Party",
    description: "High-octane Punjabi anthem blending authentic dhol loops with hard trap kicks and anthemic hook."
  },
  {
    id: "song-5",
    title: "Whispers of Winter Sun",
    artist: "Elena Rostova",
    artistId: "art-5",
    album: "Shadows in White",
    albumId: "alb-5",
    year: 2021,
    genre: "Neo-Classical",
    language: "Instrumental",
    duration: "4:40",
    durationSec: 280,
    plays: "1.9M",
    coverUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 86,
    matchingSnippet: "[Instrumental Piano Motif - Delicate ascending snow melody]",
    lyrics: [
      { type: "verse", lines: [
        "(Soft ambient snow soundscape)",
        "(Gentle felted upright piano melody in D minor)",
        "(Cello enters with slow swell)"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "(Cascading piano arpeggios representing gentle sunlight breaking through morning frost)"
      ]}
    ],
    songDNA: {
      mood: "Peaceful & Chill",
      energy: 20,
      danceability: 10,
      romance: 65,
      sadness: 60,
      acousticness: 98,
      tempo: "64 BPM"
    },
    moodCategory: "Chill",
    description: "Soothing felt piano patterns accompanied by ambient tape hiss and rich cello undertones."
  },
  {
    id: "song-6",
    title: "Cyber City Pulse",
    artist: "Neon Drift",
    artistId: "art-6",
    album: "Neon Afterglow",
    albumId: "alb-1",
    year: 2024,
    genre: "Electronic",
    language: "English",
    duration: "3:55",
    durationSec: 235,
    plays: "2.7M",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 92,
    matchingSnippet: "Neon circuits overload when the bassline drops tonight",
    lyrics: [
      { type: "verse", lines: [
        "Grid lines humming through the synthetic floor",
        "Hologram reflections running out the door"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Neon circuits overload when the bassline drops tonight",
        "Lost inside the laser beams and fractured strobe light"
      ]}
    ],
    songDNA: {
      mood: "Energetic & High Voltage",
      energy: 94,
      danceability: 92,
      romance: 25,
      sadness: 10,
      acousticness: 5,
      tempo: "132 BPM"
    },
    moodCategory: "Energetic",
    description: "Futuristic electronic dance track with soaring sawtooth synth leads and thumping four-on-the-floor groove."
  },
  {
    id: "song-7",
    title: "Tears in the Coffee Cup",
    artist: "Aarav Sen",
    artistId: "art-2",
    album: "Bheegi Shaam",
    albumId: "alb-2",
    year: 2022,
    genre: "Indie Folk",
    language: "English",
    duration: "3:35",
    durationSec: 215,
    plays: "1.8M",
    coverUrl: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 95,
    matchingSnippet: "Cold brew turning bitter like the last goodbye we said in May",
    lyrics: [
      { type: "verse", lines: [
        "Corner table at the cafe down on 5th street",
        "Watching strangers hurry on the rainy concrete"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Cold brew turning bitter like the last goodbye we said in May",
        "Watching all our promises quietly wash away"
      ]}
    ],
    songDNA: {
      mood: "Heartbreak",
      energy: 30,
      danceability: 35,
      romance: 80,
      sadness: 95,
      acousticness: 90,
      tempo: "80 BPM"
    },
    moodCategory: "Heartbreak",
    description: "Poignant heartbreak acoustic ballad about lingering grief after sudden separation."
  },
  {
    id: "song-8",
    title: "Echoes of You & Me",
    artist: "Luna Vance",
    artistId: "art-3",
    album: "Velvet Static",
    albumId: "alb-3",
    year: 2024,
    genre: "Alt-Pop",
    language: "English",
    duration: "3:22",
    durationSec: 202,
    plays: "3.5M",
    coverUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 93,
    matchingSnippet: "Every love song on the dial turns into your voice again",
    lyrics: [
      { type: "verse", lines: [
        "You wore my oversized denim jacket in the snow",
        "We mapped out galaxies nobody else could know"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Every love song on the dial turns into your voice again",
        "How did we cross the line between lovers and old friends?"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Longing",
      energy: 55,
      danceability: 60,
      romance: 94,
      sadness: 70,
      acousticness: 40,
      tempo: "95 BPM"
    },
    moodCategory: "Romantic",
    description: "Lush dream-pop romance tracking nostalgic memories of young love in the winter."
  },
  {
    id: "song-9",
    title: "Tu Hi Meri Subah",
    artist: "Arijit Singh",
    artistId: "art-7",
    album: "Sufi Nights & City Lights",
    albumId: "alb-6",
    year: 2024,
    genre: "Bollywood",
    language: "Hindi",
    duration: "4:32",
    durationSec: 272,
    plays: "9.8M",
    coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 98,
    matchingSnippet: "Tu hi meri subah hai tu hi mera jahaan, tere bina adhoora har ek karwaan",
    lyrics: [
      { type: "verse", lines: [
        "Dhoop ki tarah tu aayi meri zameen pe",
        "Khwaab naye bikhre palkon ki lakeeron pe"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Tu hi meri subah hai tu hi mera jahaan",
        "Tere bina adhoora har ek karwaan",
        "Jab se mile hain do dil ke kinare",
        "Roshan huye hain sabhi mehtaab taare"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Devotional",
      energy: 58,
      danceability: 42,
      romance: 98,
      sadness: 30,
      acousticness: 60,
      tempo: "84 BPM"
    },
    moodCategory: "Romantic",
    description: "Soul-stirring Hindi romantic ballad celebrated for soaring vocals and symphonic strings."
  },
  {
    id: "song-10",
    title: "Khoya Hua Sitara",
    artist: "Arijit Singh",
    artistId: "art-7",
    album: "Sufi Nights & City Lights",
    albumId: "alb-6",
    year: 2024,
    genre: "Bollywood",
    language: "Hindi",
    duration: "4:45",
    durationSec: 285,
    plays: "8.4M",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 96,
    matchingSnippet: "Aasman mein dhoondha tujhko jaise khoya hua sitara, tanhaiyon ne humko phir se pukara",
    lyrics: [
      { type: "verse", lines: [
        "Andheri raaton ka yeh silsila na toota",
        "Haathon se tere wafa ka daaman chhoota"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Aasman mein dhoondha tujhko jaise khoya hua sitara",
        "Tanhaiyon ne humko phir se pukara",
        "Tu chala gaya toh roothi roothi si bahaarein",
        "Sooni padi hain dil ki sabhi rahguzaarein"
      ]}
    ],
    songDNA: {
      mood: "Heartbreak & Melancholy",
      energy: 40,
      danceability: 30,
      romance: 75,
      sadness: 98,
      acousticness: 70,
      tempo: "72 BPM"
    },
    moodCategory: "Heartbreak",
    description: "A deeply moving separation song characterized by melancholic sarangi flourishes and emotional crescendos."
  },
  {
    id: "song-11",
    title: "Lover's Boulevard",
    artist: "Diljit Dosanjh",
    artistId: "art-8",
    album: "Ghost Town Roar",
    albumId: "alb-7",
    year: 2023,
    genre: "Punjabi Pop",
    language: "Punjabi",
    duration: "3:18",
    durationSec: 198,
    plays: "12.4M",
    coverUrl: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 97,
    matchingSnippet: "Teri akhiyan da jaadu saanu le gaya lutt ke, lover's boulevard utte dil ditta sut ke",
    lyrics: [
      { type: "verse", lines: [
        "Suit tera kaala te jutti tillay wali",
        "Gabru di jind kitti tere naal pyari"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Teri akhiyan da jaadu saanu le gaya lutt ke",
        "Lover's boulevard utte dil ditta sut ke",
        "Hass ke jadon vi tu takk laindi ae",
        "Zindagi gulabi jivein kashmiri chai ae"
      ]}
    ],
    songDNA: {
      mood: "Party & Romantic",
      energy: 92,
      danceability: 96,
      romance: 88,
      sadness: 10,
      acousticness: 20,
      tempo: "124 BPM"
    },
    moodCategory: "Party",
    description: "Infectious Punjabi dance-romance groove with bouncy basslines and addictive melodic hooks."
  },
  {
    id: "song-12",
    title: "Pind Ton Vegas",
    artist: "Diljit Dosanjh",
    artistId: "art-8",
    album: "Ghost Town Roar",
    albumId: "alb-7",
    year: 2023,
    genre: "Punjabi Pop",
    language: "Punjabi",
    duration: "3:40",
    durationSec: 220,
    plays: "10.1M",
    coverUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 90,
    matchingSnippet: "Pind ton leke Vegas tak danka baje, sardari da geet har mod utte saje",
    lyrics: [
      { type: "verse", lines: [
        "Dollar'an di chamak te mehnat da purna",
        "Kade vi ni sikhya kise moore jhukna"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Pind ton leke Vegas tak danka baje",
        "Sardari da geet har mod utte saje"
      ]}
    ],
    songDNA: {
      mood: "Energetic & Swagger",
      energy: 96,
      danceability: 94,
      romance: 30,
      sadness: 5,
      acousticness: 10,
      tempo: "130 BPM"
    },
    moodCategory: "Energetic",
    description: "High-flying swagger anthem highlighting the global triumph of Punjabi heritage and hustle."
  },
  {
    id: "song-13",
    title: "Paper Lanterns & Lavender",
    artist: "Taylor Swift",
    artistId: "art-9",
    album: "Midnight Poet",
    albumId: "alb-8",
    year: 2024,
    genre: "Pop",
    language: "English",
    duration: "3:52",
    durationSec: 232,
    plays: "18.6M",
    coverUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 99,
    matchingSnippet: "Floating paper lanterns lighting up your lavender haze, we were young and tangled in a golden maze",
    lyrics: [
      { type: "verse", lines: [
        "I kept your vintage cardigan draped across my chair",
        "The scent of October still lingering there"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Floating paper lanterns lighting up your lavender haze",
        "We were young and tangled in a golden maze",
        "They whisper in the hallways that forever doesn't stay",
        "But I remember loving you like it was yesterday"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Nostalgic",
      energy: 62,
      danceability: 68,
      romance: 96,
      sadness: 50,
      acousticness: 35,
      tempo: "118 BPM"
    },
    moodCategory: "Romantic",
    description: "Cinematic pop masterpiece featuring nostalgic storytelling, sweeping synths, and bittersweet hooks."
  },
  {
    id: "song-14",
    title: "The Autumn Letter",
    artist: "Taylor Swift",
    artistId: "art-9",
    album: "Midnight Poet",
    albumId: "alb-8",
    year: 2024,
    genre: "Indie Folk",
    language: "English",
    duration: "4:05",
    durationSec: 245,
    plays: "14.2M",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 94,
    matchingSnippet: "Writing an autumn letter in the porch light gleam, lost inside the wreckage of an old sweet dream",
    lyrics: [
      { type: "verse", lines: [
        "Crisp maple leaves spiraling to the floor",
        "Your footprints fading away from my door"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Writing an autumn letter in the porch light gleam",
        "Lost inside the wreckage of an old sweet dream"
      ]}
    ],
    songDNA: {
      mood: "Sad & Acoustic",
      energy: 38,
      danceability: 45,
      romance: 84,
      sadness: 90,
      acousticness: 92,
      tempo: "82 BPM"
    },
    moodCategory: "Sad",
    description: "Intimate indie folk ballad with acoustic guitar picking and reflective poetry about unkept vows."
  },
  {
    id: "song-15",
    title: "Chennai Thunder Beat",
    artist: "Anirudh Ravichander",
    artistId: "art-10",
    album: "Madras Cyberpunk",
    albumId: "alb-9",
    year: 2025,
    genre: "Tamil Pop",
    language: "Tamil",
    duration: "3:25",
    durationSec: 205,
    plays: "11.2M",
    coverUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 95,
    matchingSnippet: "Vaathi kooda kooda vaa, Chennai thunder beat adikkuthu paarada",
    lyrics: [
      { type: "verse", lines: [
        "Kadal kaathu veesuthu Marina karaiyila",
        "Bass drop aaguthu namma ullaarula"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Vaathi kooda kooda vaa, Chennai thunder beat adikkuthu paarada",
        "Theru muzhuka namma paattu dhaan ketkuthu koodada"
      ]}
    ],
    songDNA: {
      mood: "Party & High Energy",
      energy: 98,
      danceability: 96,
      romance: 20,
      sadness: 5,
      acousticness: 8,
      tempo: "140 BPM"
    },
    moodCategory: "Party",
    description: "Electrifying Tamil mass track combining local kuthu percussion with modern synth leads."
  },
  {
    id: "song-16",
    title: "Kanave Kanave Vaa",
    artist: "Anirudh Ravichander",
    artistId: "art-10",
    album: "Madras Cyberpunk",
    albumId: "alb-9",
    year: 2025,
    genre: "Tamil Pop",
    language: "Tamil",
    duration: "4:02",
    durationSec: 242,
    plays: "8.9M",
    coverUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 92,
    matchingSnippet: "Kanave kanave vizhigalil thondrum nizhale, un ninaivil tholaikiren ennaiye",
    lyrics: [
      { type: "verse", lines: [
        "Iravu neram nilaavin oliyil",
        "Un mugam kanden manadhin aazhathil"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Kanave kanave vizhigalil thondrum nizhale",
        "Un ninaivil tholaikiren ennaiye"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Ambient",
      energy: 60,
      danceability: 52,
      romance: 92,
      sadness: 55,
      acousticness: 45,
      tempo: "90 BPM"
    },
    moodCategory: "Romantic",
    description: "Melodious Tamil dream pop ballad with acoustic guitar chords and poignant melodic hooks."
  },
  {
    id: "song-17",
    title: "Fuego en la Playa",
    artist: "Bad Bunny",
    artistId: "art-11",
    album: "Verano Sin Fin",
    albumId: "alb-10",
    year: 2024,
    genre: "Reggaeton",
    language: "Spanish",
    duration: "3:20",
    durationSec: 200,
    plays: "21.5M",
    coverUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 96,
    matchingSnippet: "Bailando bajo la luna con fuego en la playa, olvidando las penas mientras la ola estalla",
    lyrics: [
      { type: "verse", lines: [
        "La noche está caliente y el bajo retumba",
        "Nadie se preocupa si el mundo se derrumba"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Bailando bajo la luna con fuego en la playa",
        "Olvidando las penas mientras la ola estalla",
        "Si me miras así ya no tengo salida",
        "Bebiendo coco frío celebrando la vida"
      ]}
    ],
    songDNA: {
      mood: "Party & Energetic",
      energy: 94,
      danceability: 98,
      romance: 70,
      sadness: 10,
      acousticness: 15,
      tempo: "105 BPM"
    },
    moodCategory: "Party",
    description: "Tropical reggaeton anthem packed with Caribbean sunshine, deep 808 dembow, and sensual energy."
  },
  {
    id: "song-18",
    title: "Noche de Lluvia en San Juan",
    artist: "Bad Bunny",
    artistId: "art-11",
    album: "Verano Sin Fin",
    albumId: "alb-10",
    year: 2024,
    genre: "Latin Trap",
    language: "Spanish",
    duration: "3:42",
    durationSec: 222,
    plays: "15.3M",
    coverUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 91,
    matchingSnippet: "Manejando por el expreso pensando en tu llamada que nunca llegó",
    lyrics: [
      { type: "verse", lines: [
        "Las luces de la ciudad se borran con el agua",
        "Fumando lento para calmar la nostalgia"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Manejando por el expreso pensando en tu llamada que nunca llegó",
        "El reloj sigue marcando las tres y mi corazón se congeló"
      ]}
    ],
    songDNA: {
      mood: "Heartbreak & Sad",
      energy: 55,
      danceability: 70,
      romance: 65,
      sadness: 92,
      acousticness: 30,
      tempo: "88 BPM"
    },
    moodCategory: "Heartbreak",
    description: "Moody Latin trap track detailing solitary late night highway contemplation after unrequited love."
  },
  {
    id: "song-19",
    title: "Rooh Ki Sadaa",
    artist: "AR Rahman",
    artistId: "art-12",
    album: "Infinite Monsoon",
    albumId: "alb-11",
    year: 2022,
    genre: "World",
    language: "Hindi",
    duration: "5:10",
    durationSec: 310,
    plays: "7.1M",
    coverUrl: "https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 94,
    matchingSnippet: "Rooh ki sadaa sun le re maula, bikhre huye dil ko sukoon de re maula",
    lyrics: [
      { type: "verse", lines: [
        "Sehra mein bhatke tishna tishna safar",
        "Teri rehmat ki chaav dhoondhe nazar"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Rooh ki sadaa sun le re maula",
        "Bikhre huye dil ko sukoon de re maula"
      ]}
    ],
    songDNA: {
      mood: "Peaceful & Sufi",
      energy: 48,
      danceability: 35,
      romance: 80,
      sadness: 50,
      acousticness: 75,
      tempo: "78 BPM"
    },
    moodCategory: "Chill",
    description: "Sublime spiritual composition blending Sufi qawwali sensibilities with ambient orchestral sound design."
  },
  {
    id: "song-20",
    title: "Saawariya Re",
    artist: "AR Rahman",
    artistId: "art-12",
    album: "Infinite Monsoon",
    albumId: "alb-11",
    year: 2022,
    genre: "Film Score",
    language: "Tamil",
    duration: "4:38",
    durationSec: 278,
    plays: "6.4M",
    coverUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 90,
    matchingSnippet: "Mazhai kaala poove en kaadhal solla vaa, nenjukkul eeram thandhu ponadhaaga vaa",
    lyrics: [
      { type: "verse", lines: [
        "Kaatrin idhayam un paerai sonnadho",
        "Kanneer thuligal muththukkalaai aaanadho"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Mazhai kaala poove en kaadhal solla vaa",
        "Nenjukkul eeram thandhu ponadhaaga vaa"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Orchestral",
      energy: 52,
      danceability: 40,
      romance: 95,
      sadness: 60,
      acousticness: 80,
      tempo: "86 BPM"
    },
    moodCategory: "Romantic",
    description: "Lyrical monsoon romance featuring flute solos, orchestral strings, and sublime choral layering."
  },
  {
    id: "song-21",
    title: "Bulería Del Futuro",
    artist: "Rosalía",
    artistId: "art-13",
    album: "Velvet Static",
    albumId: "alb-3",
    year: 2024,
    genre: "Flamenco",
    language: "Spanish",
    duration: "2:58",
    durationSec: 178,
    plays: "8.2M",
    coverUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 93,
    matchingSnippet: "Con las palmas rompo el silencio de la madrugada, clavando espinas en la noche estrellada",
    lyrics: [
      { type: "verse", lines: [
        "Canta la voz honda desde el pecho herido",
        "Buscando el eco de lo que se ha perdido"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Con las palmas rompo el silencio de la madrugada",
        "Clavando espinas en la noche estrellada"
      ]}
    ],
    songDNA: {
      mood: "Energetic & Passionate",
      energy: 86,
      danceability: 88,
      romance: 75,
      sadness: 40,
      acousticness: 45,
      tempo: "122 BPM"
    },
    moodCategory: "Energetic",
    description: "Pioneering avant-garde flamenco beat featuring rhythmic handclaps, synthetic sub-bass, and passionate melisma."
  },
  {
    id: "song-22",
    title: "Ennodum Nee Illai",
    artist: "Sid Sriram",
    artistId: "art-14",
    album: "Madras Cyberpunk",
    albumId: "alb-9",
    year: 2023,
    genre: "Carnatic",
    language: "Tamil",
    duration: "4:28",
    durationSec: 268,
    plays: "9.5M",
    coverUrl: "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 95,
    matchingSnippet: "Ennodum nee illai enge sendraayo, un kural ketka vizhi imaigal thudikkuthey",
    lyrics: [
      { type: "verse", lines: [
        "Kaalam kadandhu pogum vazhiyil",
        "Thaniye nindru alaiyum nilalil"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Ennodum nee illai enge sendraayo",
        "Un kural ketka vizhi imaigal thudikkuthey"
      ]}
    ],
    songDNA: {
      mood: "Heartbreak & Soul",
      energy: 42,
      danceability: 38,
      romance: 88,
      sadness: 96,
      acousticness: 65,
      tempo: "74 BPM"
    },
    moodCategory: "Heartbreak",
    description: "Vocal tour-de-force tracking emotional desolation through intricate Carnatic gamakas and modern R&B chords."
  },
  {
    id: "song-23",
    title: "Kasoor Humara",
    artist: "Prateek Kuhad",
    artistId: "art-15",
    album: "Cold Winter Letters",
    albumId: "alb-12",
    year: 2023,
    genre: "Indie Folk",
    language: "Hindi",
    duration: "3:24",
    durationSec: 204,
    plays: "7.8M",
    coverUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 96,
    matchingSnippet: "Kya yeh kasoor humara tha jo tum door huye, bina kahe sab baatein majboor huye",
    lyrics: [
      { type: "verse", lines: [
        "Choti si khidki se dhoop aati hai",
        "Teri yaadon ki khushboo le aati hai"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Kya yeh kasoor humara tha jo tum door huye",
        "Bina kahe sab baatein majboor huye"
      ]}
    ],
    songDNA: {
      mood: "Sad & Melodic",
      energy: 30,
      danceability: 40,
      romance: 85,
      sadness: 94,
      acousticness: 95,
      tempo: "80 BPM"
    },
    moodCategory: "Sad",
    description: "Gentle acoustic guitar confession capturing innocence, unspoken sorrow, and quiet winter afternoons."
  },
  {
    id: "song-24",
    title: "Blinding Crimson Sky",
    artist: "The Weeknd",
    artistId: "art-16",
    album: "Neon Afterglow",
    albumId: "alb-1",
    year: 2024,
    genre: "Synthpop",
    language: "English",
    duration: "3:30",
    durationSec: 210,
    plays: "24.1M",
    coverUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 98,
    matchingSnippet: "Running through the crimson lights under city sirens, I can feel your heart beating in the dark",
    lyrics: [
      { type: "verse", lines: [
        "City streets are drowning in a bloody glow",
        "There's nowhere left for us to go"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Running through the crimson lights under city sirens",
        "I can feel your heart beating in the dark",
        "Nobody's watching while the night falls apart",
        "You took the bullet straight through my heart"
      ]}
    ],
    songDNA: {
      mood: "Energetic & Nostalgic",
      energy: 91,
      danceability: 89,
      romance: 68,
      sadness: 45,
      acousticness: 12,
      tempo: "134 BPM"
    },
    moodCategory: "Energetic",
    description: "Pounding 80s synthpop anthem with soaring falsetto and cinematic analog arpeggiators."
  },
  {
    id: "song-25",
    title: "After Dark Mirage",
    artist: "The Weeknd",
    artistId: "art-16",
    album: "Velvet Static",
    albumId: "alb-3",
    year: 2023,
    genre: "R&B",
    language: "English",
    duration: "3:45",
    durationSec: 225,
    plays: "19.3M",
    coverUrl: "https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 92,
    matchingSnippet: "In the after dark mirage where promises turn to dust",
    lyrics: [
      { type: "verse", lines: [
        "Champagne spilling on the penthouse tile",
        "Faking a photograph and trying to smile"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "In the after dark mirage where promises turn to dust",
        "Trading all our dreams for momentary lust"
      ]}
    ],
    songDNA: {
      mood: "Chill & Dark",
      energy: 60,
      danceability: 65,
      romance: 55,
      sadness: 72,
      acousticness: 25,
      tempo: "92 BPM"
    },
    moodCategory: "Chill",
    description: "Hypnotic R&B groove built around warm Rhodes chords, deep 808 sub, and soulful falsetto."
  },
  {
    id: "song-26",
    title: "Coffee & Cold Rain",
    artist: "Prateek Kuhad",
    artistId: "art-15",
    album: "Cold Winter Letters",
    albumId: "alb-12",
    year: 2023,
    genre: "Indie Folk",
    language: "English",
    duration: "2:54",
    durationSec: 174,
    plays: "5.4M",
    coverUrl: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 94,
    matchingSnippet: "Coffee and cold rain falling on the terrace sill, time is running forward while my mind stands still",
    lyrics: [
      { type: "verse", lines: [
        "Two cups poured but nobody is home",
        "Wandering through old text messages alone"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Coffee and cold rain falling on the terrace sill",
        "Time is running forward while my mind stands still"
      ]}
    ],
    songDNA: {
      mood: "Chill & Sad",
      energy: 25,
      danceability: 30,
      romance: 70,
      sadness: 90,
      acousticness: 96,
      tempo: "76 BPM"
    },
    moodCategory: "Chill",
    description: "Quiet fingerpicked ballad perfect for rainy morning listening and bittersweet reflection."
  },
  {
    id: "song-27",
    title: "Lover's Golden Hour",
    artist: "Taylor Swift",
    artistId: "art-9",
    album: "Midnight Poet",
    albumId: "alb-8",
    year: 2024,
    genre: "Pop",
    language: "English",
    duration: "3:38",
    durationSec: 218,
    plays: "16.8M",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 95,
    matchingSnippet: "Golden hour shining through the kitchen blinds, leaving all our yesterday worries behind",
    lyrics: [
      { type: "verse", lines: [
        "You laughed with sugar on your cheek",
        "It made the world around us feel so sweet"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Golden hour shining through the kitchen blinds",
        "Leaving all our yesterday worries behind",
        "Can I go where you go, darling, will you stay?",
        "Watching sunset melt into a starry bay"
      ]}
    ],
    songDNA: {
      mood: "Romantic & Warm",
      energy: 65,
      danceability: 72,
      romance: 99,
      sadness: 15,
      acousticness: 40,
      tempo: "108 BPM"
    },
    moodCategory: "Romantic",
    description: "Warm acoustic pop love song capturing golden sunsets and lasting tenderness."
  },
  {
    id: "song-28",
    title: "Malang Dilbar",
    artist: "Arijit Singh",
    artistId: "art-7",
    album: "Sufi Nights & City Lights",
    albumId: "alb-6",
    year: 2024,
    genre: "Sufi",
    language: "Hindi",
    duration: "5:02",
    durationSec: 302,
    plays: "7.9M",
    coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 92,
    matchingSnippet: "Tere ishq mein hue hum malang dilbar, har zarra zarra gaaye tera naghma",
    lyrics: [
      { type: "verse", lines: [
        "Duniya ke taane sab bhula diye",
        "Tere dar pe aake sar jhuka diye"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Tere ishq mein hue hum malang dilbar",
        "Har zarra zarra gaaye tera naghma"
      ]}
    ],
    songDNA: {
      mood: "Devotional & Passionate",
      energy: 70,
      danceability: 50,
      romance: 92,
      sadness: 40,
      acousticness: 55,
      tempo: "98 BPM"
    },
    moodCategory: "Romantic",
    description: "Spiritual ecstasy expressed through passionate tabla beats and commanding vocal improvisations."
  },
  {
    id: "song-29",
    title: "Aura De Noche",
    artist: "Rosalía",
    artistId: "art-13",
    album: "Velvet Static",
    albumId: "alb-3",
    year: 2024,
    genre: "Avant-Pop",
    language: "Spanish",
    duration: "3:10",
    durationSec: 190,
    plays: "6.7M",
    coverUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 90,
    matchingSnippet: "Brilla la joya en la oscuridad, nada se compara con tu lealtad",
    lyrics: [
      { type: "verse", lines: [
        "El motor ruge como una fiera",
        "Corriendo por toda la carretera"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Brilla la joya en la oscuridad",
        "Nada se compara con tu lealtad"
      ]}
    ],
    songDNA: {
      mood: "Energetic & Modern",
      energy: 84,
      danceability: 90,
      romance: 60,
      sadness: 20,
      acousticness: 25,
      tempo: "115 BPM"
    },
    moodCategory: "Energetic",
    description: "Avant-garde vocal experiments over syncopated Spanish trap beats."
  },
  {
    id: "song-30",
    title: "Marakkuma Nenjam",
    artist: "AR Rahman",
    artistId: "art-12",
    album: "Infinite Monsoon",
    albumId: "alb-11",
    year: 2022,
    genre: "Film Score",
    language: "Tamil",
    duration: "4:15",
    durationSec: 255,
    plays: "8.7M",
    coverUrl: "https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 97,
    matchingSnippet: "Marakkuma nenjam un ninaivai marakkuma, kaalam sendraalum idhayam valikkuma",
    lyrics: [
      { type: "verse", lines: [
        "Oru nodi kooda unnai piriyavillai",
        "En vaazhkaiyil un pol uravu illai"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Marakkuma nenjam un ninaivai marakkuma",
        "Kaalam sendraalum idhayam valikkuma"
      ]}
    ],
    songDNA: {
      mood: "Sad & Poignant",
      energy: 45,
      danceability: 35,
      romance: 90,
      sadness: 95,
      acousticness: 70,
      tempo: "76 BPM"
    },
    moodCategory: "Sad",
    description: "Heart-wrenching Tamil composition that achieved viral immortality through haunting chorus hooks."
  },
  {
    id: "song-31",
    title: "Chandigarh Nights Out",
    artist: "Kabir Dhillon",
    artistId: "art-4",
    album: "Virasat Beats",
    albumId: "alb-4",
    year: 2023,
    genre: "Hip-Hop",
    language: "Punjabi",
    duration: "3:12",
    durationSec: 192,
    plays: "4.3M",
    coverUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 88,
    matchingSnippet: "Yaaran di toli nikli gehri route te, bass hille sheher saara",
    lyrics: [
      { type: "verse", lines: [
        "Sector athara ch gaddi slow kiti",
        "Puri vibe yaaran naal khalo kiti"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "Yaaran di toli nikli gehri route te",
        "Bass hille sheher saara"
      ]}
    ],
    songDNA: {
      mood: "Party & Trap",
      energy: 96,
      danceability: 95,
      romance: 35,
      sadness: 10,
      acousticness: 10,
      tempo: "136 BPM"
    },
    moodCategory: "Party",
    description: "Hard Punjabi trap banger capturing nocturnal street culture and thunderous sound systems."
  },
  {
    id: "song-32",
    title: "Silence of the Pines",
    artist: "Elena Rostova",
    artistId: "art-5",
    album: "Shadows in White",
    albumId: "alb-5",
    year: 2021,
    genre: "Ambient",
    language: "Instrumental",
    duration: "4:18",
    durationSec: 258,
    plays: "2.1M",
    coverUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
    matchPercentage: 89,
    matchingSnippet: "[Ambient Tape Loop Motif - Wind whispering through alpine pine trees]",
    lyrics: [
      { type: "verse", lines: [
        "(Soft wind chimes and distant bird call soundscapes)",
        "(Muted classical harp arpeggio over analog synth drone)"
      ]},
      { type: "chorus", highlighted: true, lines: [
        "(Strings resolve with slow warm reverberation)"
      ]}
    ],
    songDNA: {
      mood: "Chill & Ambient",
      energy: 18,
      danceability: 10,
      romance: 50,
      sadness: 40,
      acousticness: 99,
      tempo: "60 BPM"
    },
    moodCategory: "Chill",
    description: "Meditative neo-classical soundscape composed for nocturnal focus and deep relaxation."
  }
];
