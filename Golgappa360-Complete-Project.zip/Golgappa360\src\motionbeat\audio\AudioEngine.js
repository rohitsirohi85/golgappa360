/**
 * MotionBeat Web Audio Engine (High-Performance Scheduler)
 * Rock-solid look-ahead scheduler based on AudioContext.currentTime,
 * persistent bus architecture, and real-time spectral analyser.
 */
export class AudioEngine {
  constructor() {
    this.audioCtx = null;
    this.masterGain = null;
    this.analyser = null;
    this.isPlaying = false;
    this.bpm = 124;
    this.volume = 0.75;
    this.isMuted = false;
    this.previousVolume = 0.75;

    // Pattern & Rhythmic State
    this.currentPatternId = 'cyber-pulse';
    this.currentStep = 0;
    this.schedulerTimer = null;
    this.nextStepTime = 0;

    // High-reliability scheduler lookahead settings (Chris Wilson 2-clocks standard)
    this.lookaheadMs = 25;       // Interval at which we check upcoming notes
    this.scheduleAheadSec = 0.25; // 250ms audio buffer lookahead prevents stutter under CPU load

    // Persistent Audio Graph Nodes (reduces garbage collection pauses)
    this.kickGain = null;
    this.snareFilter = null;
    this.snareGain = null;
    this.hihatFilter = null;
    this.hihatGain = null;
    this.bassFilter = null;
    this.bassGain = null;
    this.leadFilter = null;
    this.leadGain = null;

    // Analyser data buffers
    this.fftSize = 512;
    this.frequencyData = null;
    this.timeDomainData = null;

    // Transient detection
    this.lastBass = 0;
    this.kickThreshold = 0.45;

    // White noise buffer for snares and hihats
    this.noiseBuffer = null;

    // Preset rhythms (16 steps: 0 = off, 1 = normal, 2 = accent)
    this.patterns = {
      'cyber-pulse': {
        name: 'Cyber Pulse',
        genre: 'Cyberpunk Drive',
        bpm: 124,
        kick:  [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1],
        snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
        hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2],
        bass:  [60, 0, 60, 0, 60, 63, 60, 0, 58, 0, 58, 60, 63, 65, 63, 60],
        lead:  [72, 0, 75, 72, 0, 79, 0, 75, 77, 0, 72, 75, 84, 82, 79, 75],
      },
      'deep-hyperspace': {
        name: 'Deep Hyperspace',
        genre: 'Atmospheric Void',
        bpm: 96,
        kick:  [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
        snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
        hihat: [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
        bass:  [48, 0, 0, 48, 0, 51, 0, 0, 46, 0, 0, 46, 0, 48, 51, 0],
        lead:  [0, 67, 0, 70, 72, 0, 75, 0, 0, 67, 72, 0, 79, 0, 75, 72],
      },
      'glitch-matrix': {
        name: 'Glitch Matrix',
        genre: 'Fast Neuro Break',
        bpm: 138,
        kick:  [1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0],
        snare: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0],
        hihat: [1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2],
        bass:  [55, 55, 0, 58, 0, 60, 60, 0, 53, 0, 55, 58, 62, 60, 58, 55],
        lead:  [79, 82, 0, 84, 79, 0, 86, 84, 82, 0, 79, 82, 87, 86, 84, 79],
      }
    };
  }

  init() {
    if (this.audioCtx) return;

    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    this.audioCtx = new AudioContextClass();

    // 1. Master Output Path
    this.masterGain = this.audioCtx.createGain();
    this.masterGain.gain.setValueAtTime(this.volume, this.audioCtx.currentTime);

    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = this.fftSize;
    this.analyser.smoothingTimeConstant = 0.82;
    this.analyser.minDecibels = -90;
    this.analyser.maxDecibels = -10;

    this.masterGain.connect(this.analyser);
    this.analyser.connect(this.audioCtx.destination);

    // 2. Persistent Channel Busses (Persistent graph eliminates GC pauses)
    // Snare Bus
    this.snareFilter = this.audioCtx.createBiquadFilter();
    this.snareFilter.type = 'bandpass';
    this.snareFilter.frequency.setValueAtTime(1600, this.audioCtx.currentTime);
    this.snareFilter.Q.setValueAtTime(1.8, this.audioCtx.currentTime);

    this.snareGain = this.audioCtx.createGain();
    this.snareGain.gain.setValueAtTime(0, this.audioCtx.currentTime);
    this.snareFilter.connect(this.snareGain);
    this.snareGain.connect(this.masterGain);

    // Hi-hat Bus
    this.hihatFilter = this.audioCtx.createBiquadFilter();
    this.hihatFilter.type = 'highpass';
    this.hihatFilter.frequency.setValueAtTime(8500, this.audioCtx.currentTime);

    this.hihatGain = this.audioCtx.createGain();
    this.hihatGain.gain.setValueAtTime(0, this.audioCtx.currentTime);
    this.hihatFilter.connect(this.hihatGain);
    this.hihatGain.connect(this.masterGain);

    // Bass Bus
    this.bassFilter = this.audioCtx.createBiquadFilter();
    this.bassFilter.type = 'lowpass';
    this.bassFilter.frequency.setValueAtTime(600, this.audioCtx.currentTime);
    this.bassFilter.Q.setValueAtTime(3.5, this.audioCtx.currentTime);

    this.bassGain = this.audioCtx.createGain();
    this.bassGain.gain.setValueAtTime(0.4, this.audioCtx.currentTime);
    this.bassFilter.connect(this.bassGain);
    this.bassGain.connect(this.masterGain);

    // Lead Bus
    this.leadFilter = this.audioCtx.createBiquadFilter();
    this.leadFilter.type = 'bandpass';
    this.leadFilter.frequency.setValueAtTime(1400, this.audioCtx.currentTime);
    this.leadFilter.Q.setValueAtTime(2.2, this.audioCtx.currentTime);

    this.leadGain = this.audioCtx.createGain();
    this.leadGain.gain.setValueAtTime(0.25, this.audioCtx.currentTime);
    this.leadFilter.connect(this.leadGain);
    this.leadGain.connect(this.masterGain);

    // 3. Pre-allocated buffers
    const bufferLength = this.analyser.frequencyBinCount;
    this.frequencyData = new Uint8Array(bufferLength);
    this.timeDomainData = new Uint8Array(bufferLength);

    // 1-second persistent noise buffer
    const sampleRate = this.audioCtx.sampleRate;
    const noiseLength = sampleRate * 1;
    this.noiseBuffer = this.audioCtx.createBuffer(1, noiseLength, sampleRate);
    const output = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseLength; i++) {
      output[i] = Math.random() * 2 - 1;
    }
  }

  async resumeContext() {
    if (!this.audioCtx) {
      this.init();
    }
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
  }

  play() {
    this.resumeContext();
    if (this.isPlaying) return;

    this.isPlaying = true;
    this.currentStep = 0;
    this.nextStepTime = this.audioCtx.currentTime + 0.05;

    this.schedulerTimer = setInterval(() => {
      this.scheduler();
    }, this.lookaheadMs);
  }

  pause() {
    this.isPlaying = false;
    if (this.schedulerTimer) {
      clearInterval(this.schedulerTimer);
      this.schedulerTimer = null;
    }
  }

  toggle() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
    return this.isPlaying;
  }

  scheduler() {
    if (!this.isPlaying || !this.audioCtx) return;

    // Resynchronize if main thread was stalled
    if (this.nextStepTime < this.audioCtx.currentTime - 0.15) {
      this.nextStepTime = this.audioCtx.currentTime + 0.05;
    }

    // Schedule all upcoming steps within the 250ms ahead window
    while (this.nextStepTime < this.audioCtx.currentTime + this.scheduleAheadSec) {
      this.scheduleStep(this.currentStep, Math.max(this.nextStepTime, this.audioCtx.currentTime));
      this.advanceStep();
    }
  }

  advanceStep() {
    const secondsPer16th = (60.0 / this.bpm) / 4.0;
    this.nextStepTime += secondsPer16th;
    this.currentStep = (this.currentStep + 1) % 16;
  }

  scheduleStep(step, time) {
    const pattern = this.patterns[this.currentPatternId] || this.patterns['cyber-pulse'];

    // 1. Kick Drum
    if (pattern.kick[step] > 0) {
      this.triggerKick(time, pattern.kick[step] > 1 ? 1.0 : 0.85);
    }

    // 2. Snare / Clap
    if (pattern.snare[step] > 0) {
      this.triggerSnare(time, pattern.snare[step] > 1 ? 0.9 : 0.7);
    }

    // 3. Hi-Hat
    if (pattern.hihat[step] > 0) {
      this.triggerHihat(time, pattern.hihat[step] > 1 ? 0.6 : 0.35);
    }

    // 4. Synth Bass
    if (pattern.bass[step] > 0) {
      this.triggerBass(time, pattern.bass[step]);
    }

    // 5. Synth Lead / Arp
    if (pattern.lead[step] > 0) {
      this.triggerLead(time, pattern.lead[step]);
    }
  }

  // Synthesize Sub Kick with punchy exponential drop
  triggerKick(time, velocity = 0.8) {
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, time);
    osc.frequency.exponentialRampToValueAtTime(32, time + 0.16);

    gain.gain.setValueAtTime(velocity, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.28);
  }

  // Synthesize Snare / Snap
  triggerSnare(time, velocity = 0.7) {
    if (!this.noiseBuffer) return;

    // Noise burst through persistent snare bus
    const noiseSource = this.audioCtx.createBufferSource();
    noiseSource.buffer = this.noiseBuffer;

    const noiseGain = this.audioCtx.createGain();
    noiseGain.gain.setValueAtTime(velocity * 0.75, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);

    noiseSource.connect(this.snareFilter);
    this.snareGain.gain.setValueAtTime(1.0, time);

    noiseSource.start(time);
    noiseSource.stop(time + 0.19);

    // Tonal body
    const osc = this.audioCtx.createOscillator();
    const oscGain = this.audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(190, time);
    osc.frequency.exponentialRampToValueAtTime(80, time + 0.1);

    oscGain.gain.setValueAtTime(velocity * 0.5, time);
    oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.14);

    osc.connect(oscGain);
    oscGain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.14);
  }

  // Synthesize Hi-Hat
  triggerHihat(time, velocity = 0.4) {
    if (!this.noiseBuffer) return;

    const source = this.audioCtx.createBufferSource();
    source.buffer = this.noiseBuffer;

    const gain = this.audioCtx.createGain();
    gain.gain.setValueAtTime(velocity, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.045);

    source.connect(this.hihatFilter);
    this.hihatGain.gain.setValueAtTime(1.0, time);

    source.start(time);
    source.stop(time + 0.05);
  }

  // Synthesize Cyber Saw Bassline
  triggerBass(time, midiNote) {
    const freq = 440 * Math.pow(2, (midiNote - 69) / 12);

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, time);

    this.bassFilter.frequency.setValueAtTime(800, time);
    this.bassFilter.frequency.exponentialRampToValueAtTime(220, time + 0.18);

    gain.gain.setValueAtTime(0.38, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.2);

    osc.connect(this.bassFilter);

    osc.start(time);
    osc.stop(time + 0.21);
  }

  // Synthesize Ethereal Lead Arpeggio
  triggerLead(time, midiNote) {
    const freq = 440 * Math.pow(2, (midiNote - 69) / 12);

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, time);

    gain.gain.setValueAtTime(0.22, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.28);

    osc.connect(this.leadFilter);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  setBpm(newBpm) {
    this.bpm = Math.max(50, Math.min(220, Math.round(newBpm)));
  }

  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.audioCtx) {
      if (!this.isMuted) {
        this.masterGain.gain.setTargetAtTime(this.volume, this.audioCtx.currentTime, 0.02);
      }
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.audioCtx) {
      if (this.isMuted) {
        this.previousVolume = this.volume;
        this.masterGain.gain.setTargetAtTime(0, this.audioCtx.currentTime, 0.02);
      } else {
        this.masterGain.gain.setTargetAtTime(this.volume, this.audioCtx.currentTime, 0.02);
      }
    }
    return this.isMuted;
  }

  setPattern(patternId) {
    if (this.patterns[patternId]) {
      this.currentPatternId = patternId;
      if (this.patterns[patternId].bpm) {
        this.bpm = this.patterns[patternId].bpm;
      }
    }
  }

  getAudioData() {
    if (!this.analyser || !this.isPlaying) {
      return {
        rawFrequency: this.frequencyData || new Uint8Array(256),
        rawTimeDomain: this.timeDomainData || new Uint8Array(256),
        bass: 0,
        mid: 0,
        treble: 0,
        energy: 0,
        kickBeat: false,
        isPlaying: false,
      };
    }

    this.analyser.getByteFrequencyData(this.frequencyData);
    this.analyser.getByteTimeDomainData(this.timeDomainData);

    // Bass: bins 1 to 7 (~80 - 600 Hz)
    let bassSum = 0;
    const bassCount = 7;
    for (let i = 1; i <= bassCount; i++) {
      bassSum += this.frequencyData[i];
    }
    const bass = (bassSum / bassCount) / 255.0;

    // Mid: bins 8 to 40 (~680 - 3400 Hz)
    let midSum = 0;
    const midCount = 33;
    for (let i = 8; i < 8 + midCount; i++) {
      midSum += this.frequencyData[i];
    }
    const mid = (midSum / midCount) / 255.0;

    // Treble: bins 41 to 140 (~3500 - 12000 Hz)
    let trebleSum = 0;
    const trebleCount = 100;
    for (let i = 41; i < 41 + trebleCount; i++) {
      trebleSum += this.frequencyData[i];
    }
    const treble = (trebleSum / trebleCount) / 255.0;

    // Overall energy (RMS)
    let energySum = 0;
    for (let i = 0; i < this.frequencyData.length; i++) {
      energySum += this.frequencyData[i];
    }
    const energy = (energySum / this.frequencyData.length) / 255.0;

    const kickBeat = (bass - this.lastBass) > 0.18 && bass > this.kickThreshold;
    this.lastBass = bass;

    return {
      rawFrequency: this.frequencyData,
      rawTimeDomain: this.timeDomainData,
      bass,
      mid,
      treble,
      energy,
      kickBeat,
      isPlaying: this.isPlaying,
    };
  }

  dispose() {
    this.pause();
    if (this.audioCtx) {
      try {
        this.audioCtx.close();
      } catch (e) {
        // ignore
      }
      this.audioCtx = null;
    }
  }
}

export const audioEngine = new AudioEngine();
