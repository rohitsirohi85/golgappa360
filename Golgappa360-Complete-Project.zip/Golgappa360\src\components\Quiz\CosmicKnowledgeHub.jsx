import React, { useState } from 'react';
import { COSMIC_FACTS } from '../../data/cosmicFacts';
import { STARS_DATA } from '../../data/stars';

/**
 * CosmicKnowledgeHub — "ONE MORE THING…" Random Cosmic Facts Terminal
 * Features:
 * - Dynamic randomized fact discovery with smooth slide/fade animations
 * - Fact index counter ("FACT 07 / 25")
 * - Category badge & scientific highlight metric
 * - Connection to existing Stars Explorer modal if fact links to a cataloged star
 */
export default function CosmicKnowledgeHub({ onExploreStar }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const currentFact = COSMIC_FACTS[currentIndex] || COSMIC_FACTS[0];

  // Resolve related star if present in STARS_DATA
  const relatedStar = currentFact.relatedStarId
    ? STARS_DATA.find((s) => s.id === currentFact.relatedStarId)
    : null;

  const handleNextFact = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setTimeout(() => {
      // Pick next sequential or pseudorandom fact
      setCurrentIndex((prev) => (prev + 1) % COSMIC_FACTS.length);
      setIsAnimating(false);
    }, 200);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 text-center pt-16 border-t border-white/5">
      {/* Section Sub-Heading */}
      <div>
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-950/40 border border-indigo-500/30 text-[11px] font-mono uppercase tracking-[0.2em] text-indigo-300 mb-3">
          <span>✦</span>
          <span>COSMIC KNOWLEDGE HUB</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold text-white tracking-tight">
          ONE MORE THING…
        </h3>
        <p className="font-sans text-sm text-slate-300 mt-2 max-w-lg mx-auto">
          The universe is full of facts stranger than fiction.
        </p>
      </div>

      {/* Premium Fact Card */}
      <div
        className={`relative rounded-3xl glass-surface border border-white/10 p-6 sm:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-left transition-all duration-300 overflow-hidden ${
          isAnimating ? 'opacity-0 scale-98 translate-y-2' : 'opacity-100 scale-100 translate-y-0'
        }`}
      >
        {/* Subtle Background Glow */}
        <div
          aria-hidden="true"
          className="absolute -right-20 -bottom-20 w-64 h-64 rounded-full bg-cyan-500/10 blur-[100px] pointer-events-none"
        />

        {/* Card Header Strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-6 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <span className="text-xl" role="img" aria-hidden="true">
              {currentFact.icon}
            </span>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-cyan-950/40 text-cyan-300 border border-cyan-400/30 uppercase tracking-widest font-semibold">
              {currentFact.category}
            </span>
          </div>

          <span className="text-xs font-mono text-slate-400">
            FACT <strong className="text-white">{String(currentIndex + 1).padStart(2, '0')}</strong> / {String(COSMIC_FACTS.length).padStart(2, '0')}
          </span>
        </div>

        {/* Fact Title */}
        <h4 className="font-display text-xl sm:text-2xl lg:text-3xl font-semibold text-white mb-4 leading-snug">
          {currentFact.title}
        </h4>

        {/* Fact Description */}
        <p className="font-sans text-base sm:text-lg text-slate-200/90 leading-relaxed font-normal mb-6">
          {currentFact.fact}
        </p>

        {/* Highlight Metric Pill */}
        {currentFact.highlight && (
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#020308]/60 border border-white/8 text-xs font-mono text-amber-300 mb-8">
            <span className="text-cyan-400">⚡</span>
            <span>KEY ASTROPHYSICAL TAKEAWAY:</span>
            <strong className="text-white">{currentFact.highlight}</strong>
          </div>
        )}

        {/* Footer Actions: Related Star Link & Another Fact Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-6 border-t border-white/10">
          {/* Related Star Connection if Available */}
          {relatedStar ? (
            <button
              type="button"
              onClick={() => onExploreStar && onExploreStar(relatedStar)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 text-cyan-200 text-xs font-mono font-semibold transition-all cursor-pointer shadow-sm group"
            >
              <span
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: relatedStar.colorHex }}
              />
              <span>EXPLORE {relatedStar.name.toUpperCase()} IN CATALOG</span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </button>
          ) : (
            <div className="text-xs font-mono text-slate-500 hidden sm:block">
              CURATED OBSERVATORY KNOWLEDGE
            </div>
          )}

          {/* "ANOTHER FACT →" Primary Button */}
          <button
            type="button"
            onClick={handleNextFact}
            className="px-6 py-2.5 rounded-full bg-white/10 hover:bg-cyan-500/20 text-white hover:text-cyan-200 border border-white/20 hover:border-cyan-400/60 font-mono text-xs uppercase tracking-wider font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 group self-end sm:self-auto w-full sm:w-auto"
          >
            <span>ANOTHER FACT</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </div>
      </div>
    </div>
  );
}
