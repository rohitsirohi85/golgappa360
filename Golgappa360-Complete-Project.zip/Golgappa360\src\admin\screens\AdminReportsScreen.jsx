import React, { useState, useEffect } from 'react';
import AdminLayout from '../components/AdminLayout';
import { adminService } from '../services/adminService';
import {
  Download,
  Calendar,
  FileSpreadsheet,
  Printer,
  TrendingUp,
  DollarSign,
  Zap,
  Building2,
  CheckCircle2,
} from 'lucide-react';

export const AdminReportsScreen = () => {
  const [sessions, setSessions] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('7days'); // 'today' | '7days' | '30days' | 'all'

  useEffect(() => {
    const loadReportData = async () => {
      try {
        setLoading(true);
        const [sessRes, statsRes] = await Promise.all([
          adminService.getSessions(),
          adminService.getStats(),
        ]);
        if (Array.isArray(sessRes)) setSessions(sessRes);
        setStats(statsRes);
      } catch (err) {
        console.error('Error loading reports:', err);
      } finally {
        setLoading(false);
      }
    };
    loadReportData();
  }, []);

  const totalSessions = sessions.length;
  const totalEnergy = sessions.reduce((acc, s) => acc + (s.energyConsumed || 0), 0);
  const totalRevenue = sessions.reduce((acc, s) => acc + (s.cost || 0), 0);

  // Helper to trigger browser CSV download
  const downloadCSV = (filename, content) => {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportSessionsCSV = () => {
    const headers = ['SessionID', 'Customer', 'Station', 'Bay', 'Energy_kWh', 'Duration_min', 'Amount_INR', 'Date'];
    const rows = sessions.map((s) => [
      s._id,
      `"${s.userId?.name || 'EV Driver'}"`,
      `"${s.stationId?.name || 'EV Hub'}"`,
      s.chargerId?.chargerNumber || 'CH-01',
      s.energyConsumed || 0,
      s.duration || 45,
      s.cost || 0,
      `"${new Date(s.createdAt).toISOString()}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    downloadCSV(`ev-smart-sessions-report-${Date.now()}.csv`, csvContent);
  };

  const handleExportFleetSummaryCSV = () => {
    const headers = ['Metric', 'Value'];
    const rows = [
      ['Total Stations', stats?.stations?.total || 4],
      ['Total Charger Bays', stats?.chargers?.total || 11],
      ['Available Bays', stats?.chargers?.available || 7],
      ['Charging Bays', stats?.chargers?.charging || 2],
      ['Total Energy Delivered (kWh)', Math.round(totalEnergy * 10) / 10],
      ['Gross Revenue (INR)', totalRevenue],
      ['Active System Alerts', stats?.alerts?.activeCount || 0],
      ['Report Generated At', new Date().toISOString()],
    ];

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    downloadCSV(`ev-smart-fleet-summary-${Date.now()}.csv`, csvContent);
  };

  return (
    <AdminLayout
      pageTitle="Reports & Data Export"
      subtitle="Generate audit-ready fleet operations summaries and download formatted CSV datasets"
    >
      {/* Export Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Sessions Export Card */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-400 w-fit mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Charging Sessions Ledger Export</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Export complete transaction history including customer identity, station name, bay ID, energy delivered (kWh), duration, and billing total.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-500">{totalSessions} records available</span>
            <button
              onClick={handleExportSessionsCSV}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download CSV</span>
            </button>
          </div>
        </div>

        {/* Fleet Summary Export Card */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="p-3 rounded-2xl bg-sky-500/10 text-sky-400 w-fit mb-4">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Fleet Performance & Financial Summary</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Executive-level summary of total stations, chargers, active faults, total energy throughput, and commercial revenue generation.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-500">Live network snapshot</span>
            <button
              onClick={handleExportFleetSummaryCSV}
              className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Summary CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Printable Report Summary Container */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 print:bg-white print:text-black">
        <div className="flex items-center justify-between pb-6 border-b border-slate-800 mb-6">
          <div>
            <h3 className="text-base font-bold text-white">Fleet Operations Audit Summary</h3>
            <p className="text-xs text-slate-400">Generated on {new Date().toLocaleDateString()}</p>
          </div>
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 print:hidden"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Delivered</span>
            <div className="text-xl font-black text-emerald-400 mt-1 font-mono">
              {Math.round(totalEnergy * 10) / 10} kWh
            </div>
          </div>
          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Revenue</span>
            <div className="text-xl font-black text-white mt-1 font-mono">₹{totalRevenue}</div>
          </div>
          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Sessions</span>
            <div className="text-xl font-black text-white mt-1 font-mono">{totalSessions}</div>
          </div>
          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Avg Dispense</span>
            <div className="text-xl font-black text-sky-400 mt-1 font-mono">
              {totalSessions ? Math.round((totalEnergy / totalSessions) * 10) / 10 : 18.4} kWh
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-500 text-center pt-4 border-t border-slate-800/60">
          EV Smart Commercial Fleet Management Platform • Proprietary Confidential Report
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminReportsScreen;
