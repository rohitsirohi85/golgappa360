import React from 'react';

/**
 * BranchingPath — "MASS WRITES THE ENDING."
 * High-fidelity interactive branching diagram visualizing the fork between:
 * - Low / Medium Mass path (Red Giant -> Planetary Nebula -> White Dwarf)
 * - High Mass path (Supergiant -> Supernova -> Neutron Star / Black Hole)
 * Automatically adapts between rich 2-column desktop branching tree and
 * seamless vertical mobile journey without horizontal overflow.
 */
export default function BranchingPath({
  activeStageId,
  selectedMassTrack = 'sun-like',
  onSelectStage,
}) {
  const isHighMassActive = selectedMassTrack === 'high-mass';
  const isMediumMassActive = selectedMassTrack === 'sun-like' || selectedMassTrack === 'low-mass';

  return (
    <div className="w-full flex flex-col items-center select-none">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full glass-surface border border-cyan-500/20 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>THE BIFURCATION POINT</span>
        </div>
        <h3 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-white mb-3">
          MASS WRITES THE ENDING.
        </h3>
        <p className="font-sans text-sm sm:text-base text-slate-300/80 leading-relaxed max-w-2xl mx-auto">
          A star's initial birth mass permanently seals its fate. Low and medium-mass stars expire in glowing planetary nebulae, while massive stars detonate in supernovae.
        </p>
      </div>

      {/* Main Branching Tree Container */}
      <div className="w-full p-6 sm:p-8 lg:p-12 rounded-3xl glass-surface border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden">
        {/* Origin Node: MAIN SEQUENCE (Center Top) */}
        <div className="flex flex-col items-center mb-8 sm:mb-12">
          <button
            type="button"
            onClick={() => onSelectStage('main-sequence')}
            className={`px-6 py-3.5 rounded-2xl glass-surface border transition-all duration-300 cursor-pointer flex items-center gap-3 ${
              activeStageId === 'main-sequence'
                ? 'border-amber-400 bg-amber-500/15 shadow-[0_0_25px_rgba(251,191,36,0.4)] scale-105'
                : 'border-white/15 hover:border-amber-400/50 hover:bg-white/5'
            }`}
          >
            <span className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24] animate-pulse" />
            <div className="text-left">
              <span className="font-display text-base sm:text-lg font-semibold text-white block">
                MAIN SEQUENCE
              </span>
              <span className="text-[10px] font-mono text-amber-300">
                STABLE HYDROGEN FUSION CORE
              </span>
            </div>
          </button>

          {/* Stem Line */}
          <div className="w-[2px] h-8 bg-gradient-to-b from-amber-400 to-white/20 mt-2" />
        </div>

        {/* Branching Grid: Left (Low/Medium Mass) vs Right (High Mass) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16 relative">
          {/* Connecting Branch Overhead Line (Desktop) */}
          <div
            aria-hidden="true"
            className="hidden md:block absolute -top-8 left-[25%] right-[25%] h-[2px] bg-gradient-to-r from-amber-400 via-white/20 to-rose-500"
          />

          {/* LEFT BRANCH: LOW / MEDIUM MASS (≈ 0.5–8 M☉) */}
          <div
            className={`flex flex-col rounded-2xl p-5 sm:p-6 transition-all duration-500 ${
              isMediumMassActive
                ? 'bg-amber-500/[0.04] border border-amber-400/30 shadow-[0_0_30px_rgba(245,158,11,0.1)]'
                : 'border border-white/5 opacity-70'
            }`}
          >
            {/* Branch Header */}
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <h4 className="font-display font-semibold text-lg sm:text-xl text-white">
                  LOW / MEDIUM MASS
                </h4>
              </div>
              <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                &lt; 8 M☉ (Sun-Like)
              </span>
            </div>

            {/* Stage Step 1: Red Giant */}
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => onSelectStage('red-giant')}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 cursor-pointer border ${
                  activeStageId === 'red-giant'
                    ? 'bg-orange-500/20 border-orange-400 shadow-[0_0_20px_rgba(249,115,22,0.35)] scale-[1.02]'
                    : 'glass-surface border-white/10 hover:border-orange-400/40 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-display font-semibold text-base text-white">
                    01. RED GIANT
                  </span>
                  <span className="text-xs font-mono text-orange-400">≈ 100 Myr</span>
                </div>
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                  The star expands dramatically as hydrogen in its core is exhausted.
                </p>
              </button>

              <div className="flex justify-center text-slate-500 font-mono text-xs">↓</div>

              {/* Stage Step 2: Planetary Nebula */}
              <button
                type="button"
                onClick={() => onSelectStage('planetary-nebula')}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 cursor-pointer border ${
                  activeStageId === 'planetary-nebula'
                    ? 'bg-cyan-500/20 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.35)] scale-[1.02]'
                    : 'glass-surface border-white/10 hover:border-cyan-400/40 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-display font-semibold text-base text-white">
                    02. PLANETARY NEBULA
                  </span>
                  <span className="text-xs font-mono text-cyan-300">≈ 30,000 yr</span>
                </div>
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                  Outer layers are gently released into space, creating a glowing shell of gas.
                </p>
              </button>

              <div className="flex justify-center text-slate-500 font-mono text-xs">↓</div>

              {/* Stage Step 3: White Dwarf */}
              <button
                type="button"
                onClick={() => onSelectStage('white-dwarf')}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 cursor-pointer border ${
                  activeStageId === 'white-dwarf'
                    ? 'bg-white/20 border-white shadow-[0_0_25px_rgba(255,255,255,0.4)] scale-[1.02]'
                    : 'glass-surface border-white/10 hover:border-white/40 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-display font-semibold text-base text-white">
                    03. WHITE DWARF
                  </span>
                  <span className="text-xs font-mono text-slate-300">Trillions of yr</span>
                </div>
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                  The remaining hot core becomes a dense white dwarf and slowly cools over time.
                </p>
              </button>
            </div>
          </div>

          {/* RIGHT BRANCH: HIGH MASS (> 8 M☉) */}
          <div
            className={`flex flex-col rounded-2xl p-5 sm:p-6 transition-all duration-500 ${
              isHighMassActive
                ? 'bg-rose-500/[0.04] border border-rose-400/30 shadow-[0_0_30px_rgba(244,63,94,0.1)]'
                : 'border border-white/5 opacity-70'
            }`}
          >
            {/* Branch Header */}
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <h4 className="font-display font-semibold text-lg sm:text-xl text-white">
                  HIGH MASS
                </h4>
              </div>
              <span className="text-[10px] font-mono text-rose-300 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                &gt; 8 M☉ (Supergiants)
              </span>
            </div>

            {/* Stage Step 1: Supergiant */}
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => onSelectStage('supergiant')}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 cursor-pointer border ${
                  activeStageId === 'supergiant'
                    ? 'bg-rose-500/20 border-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.35)] scale-[1.02]'
                    : 'glass-surface border-white/10 hover:border-rose-400/40 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-display font-semibold text-base text-white">
                    01. SUPERGIANT
                  </span>
                  <span className="text-xs font-mono text-rose-300">≈ a few Myr</span>
                </div>
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                  Massive stars evolve rapidly and can fuse increasingly heavier elements in their cores.
                </p>
              </button>

              <div className="flex justify-center text-slate-500 font-mono text-xs">↓</div>

              {/* Stage Step 2: Supernova */}
              <button
                type="button"
                onClick={() => onSelectStage('supernova')}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 cursor-pointer border ${
                  activeStageId === 'supernova'
                    ? 'bg-red-600/25 border-rose-400 shadow-[0_0_25px_rgba(225,29,72,0.45)] scale-[1.02]'
                    : 'glass-surface border-white/10 hover:border-rose-400/40 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-display font-semibold text-base text-white flex items-center gap-1.5">
                    <span>02. SUPERNOVA</span>
                    <span className="text-rose-400">⚡</span>
                  </span>
                  <span className="text-xs font-mono text-rose-400 font-bold">DETONATION</span>
                </div>
                <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                  A massive star can end its life in an enormous catastrophic stellar explosion.
                </p>
              </button>

              <div className="flex justify-center text-slate-500 font-mono text-xs">↓</div>

              {/* Forked Endpoints: Neutron Star vs Black Hole */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => onSelectStage('neutron-star')}
                  className={`text-left p-3.5 rounded-xl transition-all duration-300 cursor-pointer border ${
                    activeStageId === 'neutron-star'
                      ? 'bg-indigo-500/25 border-indigo-400 shadow-[0_0_15px_rgba(129,140,248,0.4)] scale-[1.02]'
                      : 'glass-surface border-white/10 hover:border-indigo-400/40 hover:bg-white/5'
                  }`}
                >
                  <span className="font-display font-semibold text-xs sm:text-sm text-white block mb-0.5">
                    NEUTRON STAR
                  </span>
                  <p className="font-sans text-[11px] text-slate-300/80 leading-relaxed line-clamp-3">
                    An extremely dense collapsed stellar core.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectStage('black-hole')}
                  className={`text-left p-3.5 rounded-xl transition-all duration-300 cursor-pointer border ${
                    activeStageId === 'black-hole'
                      ? 'bg-cyan-500/25 border-cyan-400 shadow-[0_0_15px_rgba(56,189,248,0.4)] scale-[1.02]'
                      : 'glass-surface border-white/10 hover:border-cyan-400/40 hover:bg-white/5'
                  }`}
                >
                  <span className="font-display font-semibold text-xs sm:text-sm text-white block mb-0.5">
                    BLACK HOLE
                  </span>
                  <p className="font-sans text-[11px] text-slate-300/80 leading-relaxed line-clamp-3">
                    If mass &gt; 3 M☉, gravity collapses it into a singularity.
                  </p>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
