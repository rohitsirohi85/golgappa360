# Data Contracts — LyricLens AI

This document formalizes the canonical data contracts and schemas for the core entities in LyricLens AI.

---

## 1. Song Entity (`Song`)

Represents an individual audio track with metadata, lyric stanzas, and acoustic DNA attributes.

```typescript
interface Song {
  id: string;                         // Unique ID (e.g. "song-1")
  title: string;                      // Song title
  artist: string;                     // Primary artist name
  artistId: string;                   // Associated artist ID (e.g. "art-1")
  album: string;                      // Associated album title
  albumId: string;                    // Associated album ID (e.g. "alb-1")
  year: number;                       // Release year (e.g. 2023)
  genre: string;                      // Primary genre (e.g. "Synthwave", "Indie Folk")
  language: string;                   // Language of lyrics (e.g. "English", "Hindi", "Punjabi")
  duration: string;                   // Formatted MM:SS (e.g. "3:48")
  durationSec: number;                // Duration in total seconds (e.g. 228)
  plays: string;                      // Display play count (e.g. "4.8M")
  coverUrl: string;                   // High-resolution artwork URL
  matchPercentage?: number;           // Search match score (0-100)
  matchingSnippet: string;            // Representative hook line for discovery
  lyrics: LyricStanza[];              // Structured stanzas
  songDNA: SongDNA;                   // Acoustic & emotional metrics
  description: string;                // Short track summary/backstory
}

interface LyricStanza {
  type: "verse" | "chorus" | "bridge" | "hook" | "outro";
  highlighted?: boolean;              // Highlighted memory hook for discovery
  lines: string[];                    // Individual lyric lines (fictional/sample only)
}

interface SongDNA {
  mood: string;                       // Primary emotional tag (e.g. "Nostalgic & Melancholic")
  energy: number;                     // 0-100 percentage
  danceability: number;               // 0-100 percentage
  romance: number;                    // 0-100 percentage
  sadness: number;                    // 0-100 percentage
  acousticness: number;               // 0-100 percentage
  tempo: string;                      // Estimated tempo (e.g. "108 BPM", "85 BPM")
}
```

---

## 2. Artist Entity (`Artist`)

Represents a music artist, vocalist, or producer profile.

```typescript
interface Artist {
  id: string;                         // Unique ID (e.g. "art-1")
  name: string;                       // Artist display name
  genres: string[];                   // Primary genres (e.g. ["Synthwave", "Dream Pop"])
  languages: string[];                // Languages performed in
  image: string;                      // Square profile avatar URL
  banner: string;                     // Wide backdrop banner URL
  bio: string;                        // Full biography / artist description
  monthlyListeners: number;           // Estimated monthly listener count
  verified: boolean;                  // Verified platform badge
  formedYear: number;                 // Debut or established year
  origin: string;                     // City/Country of origin
  songCount?: number;                 // Total songs in catalog
  albumCount?: number;                // Total albums in catalog
}
```

---

## 3. Album Entity (`Album`)

Represents a cohesive studio release, EP, or single compilation.

```typescript
interface Album {
  id: string;                         // Unique ID (e.g. "alb-1")
  title: string;                      // Album title
  artist: string;                     // Primary artist name
  artistId: string;                   // Associated artist ID
  year: number;                       // Release year
  coverUrl: string;                   // Album cover artwork URL
  genres: string[];                   // Genres encompassed
  trackCount: number;                 // Total number of tracks
  duration: string;                   // Total running time (e.g. "38 min 40 sec")
  releaseDate: string;                // Full date string (e.g. "November 14, 2023")
  description: string;                // Album concept / liner notes
}
```

---

## 4. Album Insights Entity (`AlbumInsights`)

Computed on demand from album metadata and its associated song tracks.

```typescript
interface AlbumInsights {
  releaseYear: number;
  totalTracks: number;
  averagePopularity: string;          // Average play count / popularity rating
  mainGenre: string;                  // Most prominent genre across tracks
  primaryLanguage: string;            // Most prominent language across tracks
  averageDuration: string;            // Average track length (MM:SS)
}
```
