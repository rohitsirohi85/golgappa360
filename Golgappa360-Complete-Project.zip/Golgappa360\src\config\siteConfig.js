/**
 * ============================================================================
 * MOTION IS ART — CENTRAL SITE CONFIGURATION
 * ============================================================================
 * 
 * IMPORTANT FOR SITE OWNERS & ADMINISTRATORS:
 * This single file controls all business data, contact numbers, navigation links,
 * dance programs, instructor profiles, weekly timetable, gallery assets, and SEO.
 * 
 * You do NOT need to edit React components to update business information!
 * Simply change the values below and run `npm run build`.
 * 
 * ============================================================================
 */

export const siteConfig = {
  // --------------------------------------------------------------------------
  // 1. ACADEMY INFORMATION
  // --------------------------------------------------------------------------
  academy: {
    name: 'MOTION IS ART',
    shortName: 'MIA',
    legalName: 'Motion Is Art Dance Academy LLC',
    tagline: 'Dance is movement, expression, identity, and art.',
    coreStatement: 'Every movement tells a story.',
    establishedYear: '2022',
    studioDescription:
      'A contemporary urban dance academy blending underground street culture, anatomical precision, and avant-garde performance art.',
    registrationNote:
      'Registered independent arts institution. All trial bookings and admissions are coordinated directly by the studio management.',
  },

  // --------------------------------------------------------------------------
  // 2. CONTACT & MESSAGING (CONFIGURABLE ACTION TARGETS)
  // --------------------------------------------------------------------------
  contact: {
    // Phone Contact (Uses tel: link on the website)
    // Placeholder format for public presentation
    displayPhone: '+1 (555) 382-6684',
    // Raw international number format (digits only with optional + for RFC 3966)
    telNumber: '+15553826684',

    // WhatsApp Contact (Uses https://wa.me/ URL)
    // International format digits ONLY (no spaces, dashes, or + sign)
    whatsAppNumber: '15553826684',
    whatsAppDisplay: '+1 (555) 382-6684',
    // Pre-filled message when user taps the WhatsApp button
    whatsAppDefaultMessage:
      'Hello MOTION IS ART team, I would like to inquire about classes, schedules, and trial sessions.',

    // Email Contact
    email: 'admissions@motionisart.dance',
    supportEmail: 'concierge@motionisart.dance',

    // Physical Studio Location (Placeholder - replace with verified address)
    address: 'Studio Bay 04, The Arts Warehouse District',
    cityStateZip: 'Metropolis, NY 10013',
    country: 'United States',
    transitDirections: 'Subway: Metro Line 2/3 to Arts District Station, Exit C',

    // Studio Operational Hours
    hours: {
      weekdays: 'Monday – Friday: 08:30 – 22:30',
      weekends: 'Saturday – Sunday: 09:30 – 21:00',
      summary: 'Open 7 days a week for rehearsals, classes & open cyphers',
    },

    // Optional Google Maps Embed URL (leave empty string if none)
    mapEmbedUrl: '',
  },

  // --------------------------------------------------------------------------
  // 3. NAVIGATION (MULTI-PAGE ROUTES)
  // --------------------------------------------------------------------------
  navigation: {
    links: [
      { label: 'Home', path: '/' },
      { label: 'Classes', path: '/classes' },
      { label: 'About', path: '/about' },
      { label: 'Instructors', path: '/instructors' },
      { label: 'Schedule', path: '/schedule' },
      { label: 'Gallery', path: '/gallery' },
      { label: 'Contact', path: '/contact' },
    ],
    // Primary CTAs in the header
    actions: {
      callCta: 'Call Now',
      whatsAppCta: 'WhatsApp',
      trialCta: 'Book a Trial',
    },
  },

  // --------------------------------------------------------------------------
  // 4. SOCIAL MEDIA CHANNELS
  // --------------------------------------------------------------------------
  socialLinks: {
    instagram: {
      label: 'Instagram',
      url: 'https://instagram.com',
      handle: '@motionisart.dance',
    },
    youtube: {
      label: 'YouTube',
      url: 'https://youtube.com',
      handle: 'MOTION IS ART Official',
    },
    spotify: {
      label: 'Spotify',
      url: 'https://spotify.com',
      handle: 'MIA Studio Cypher Tracks',
    },
    vimeo: {
      label: 'Vimeo',
      url: 'https://vimeo.com',
      handle: 'Motion Is Art Film Archive',
    },
  },

  // --------------------------------------------------------------------------
  // 5. HOMEPAGE SPECIFIC CONTENT
  // --------------------------------------------------------------------------
  homepage: {
    badge: 'CONTEMPORARY URBAN MOVEMENT ACADEMY',
    headline: 'YOUR BODY.\nYOUR RHYTHM.\nYOUR ART.',
    supportingCopy:
      'Discover your movement. Build your style. Find your people. An urban dance academy dedicated to raw physical expression, street authenticity, and disciplined technique.',
    heroVisual: '/images/dance/hero-dancer.jpg',
    heroVisualAlt: 'Contemporary urban dancer captured in mid-air expressive leap',
    
    // Quick contact teaser card
    contactCard: {
      tag: 'DIRECT STUDIO DESK',
      title: 'NEED CLASS GUIDANCE OR TRIAL ENROLLMENT?',
      description:
        'Speak directly with our studio coordinator. We will help you select the exact discipline and level matching your experience.',
    },

    // Curated quick portals to main pages
    portalHighlights: [
      {
        title: 'Dance Disciplines',
        description: 'Explore 5 specialized curriculums from Hip-Hop and Popping to Contemporary and Bollywood Fusion.',
        link: '/classes',
        ctaText: 'View All Classes',
        tag: 'CURRICULUM',
      },
      {
        title: 'Weekly Timetable',
        description: 'Browse scheduled morning, evening, and weekend class slots with instructor and level details.',
        link: '/schedule',
        ctaText: 'View Timetable',
        tag: 'TIMETABLE',
      },
      {
        title: 'The Artists',
        description: 'Meet our resident choreographers, battle champions, and movement researchers.',
        link: '/instructors',
        ctaText: 'Meet Faculty',
        tag: 'FACULTY',
      },
      {
        title: 'Movement Archive',
        description: 'Visual documentation of studio rehearsals, masterclasses, and stagecraft showcases.',
        link: '/gallery',
        ctaText: 'Open Archive',
        tag: 'GALLERY',
      },
    ],
  },

  // --------------------------------------------------------------------------
  // 6. DANCE PROGRAMS & DISCIPLINES
  // --------------------------------------------------------------------------
  programs: [
    {
      id: 'hip-hop',
      name: 'Hip-Hop',
      subtitle: 'Groove Architecture & Street Dynamics',
      tagline: 'Raw bounce, polyrhythmic musicality, and authentic street cyphers.',
      image: '/images/dance/hiphop.jpg',
      tempoRange: '85 – 110 BPM',
      intensity: 'High Energy',
      levels: ['Foundation (Beg)', 'Street Mechanics (Int)', 'Cypher Intensive (Adv)'],
      description:
        'Deconstruct party grooves, 90s social foundations, contemporary bounce, and polyrhythmic pocket work. Build physical stamina, weight shifts, and freestyle confidence in an open cypher.',
      highlights: [
        'Authentic foundational groove & bounce mechanics',
        'Musical polyrhythms and sub-bass pocket timing',
        'Freestyle cypher psychology and solo storytelling',
        'Crew synchronicity and battle etiquette',
      ],
      scheduleOverview: 'Mon / Wed / Fri evenings',
      badge: 'Flagship Style',
    },
    {
      id: 'popping',
      name: 'Popping',
      subtitle: 'Muscular Isolation & Geometric Illusion',
      tagline: 'Hits, dime stops, waving, strobing, and cinematic robotic flow.',
      image: '/images/dance/popping.jpg',
      tempoRange: '95 – 125 BPM (Electro-Funk)',
      intensity: 'Precision Focused',
      levels: ['Muscle Control (Beg)', 'Illusion Concepts (Int)', 'Masterclass Isolation (Adv)'],
      description:
        'Deconstruct body mechanics through contraction and release kinetics. Master hit power, floating, liquid waving, strobing, and dime stops to transform into a living visual frequency.',
      highlights: [
        'Contraction & relaxation kinetics (The Pop / Hit)',
        'Floating, gliding, and weightless ground illusions',
        'Liquid waving, ticking, and frequency modulation',
        'Robotics, animation concepts, and micro-movements',
      ],
      scheduleOverview: 'Tue / Thu evenings & Sat afternoon',
      badge: 'Signature Style',
    },
    {
      id: 'bollywood',
      name: 'Bollywood Fusion',
      subtitle: 'Theatrical Expression & Urban Fusion',
      tagline: 'High-octane cinematic storytelling infused with modern footwork and lyricism.',
      image: '/images/dance/bollywood.jpg',
      tempoRange: '100 – 135 BPM',
      intensity: 'Vibrant & Theatrical',
      levels: ['Rhythm & Mudra (Beg)', 'Contemporary Fusion (Int)', 'Stage Ensemble (Adv)'],
      description:
        'A cutting-edge contemporary evolution of Indian cinematic dance, blending expressive abhinaya facial dynamism and semi-classical footwork with modern urban grooves.',
      highlights: [
        'Expressive theatrical storytelling & emotional resonance',
        'Intricate semi-classical mudras blended with urban flow',
        'Dynamic speed shifts and dramatic crescendo staging',
        'Cinematic ensemble choreographies ready for the lens',
      ],
      scheduleOverview: 'Wed / Fri evenings & Sun morning',
      badge: 'Cultural Innovation',
    },
    {
      id: 'contemporary',
      name: 'Contemporary',
      subtitle: 'Weight Dynamics, Release & Floor Flow',
      tagline: 'Floorwork, release technique, emotional narrative, and effortless momentum.',
      image: '/images/dance/contemporary.jpg',
      tempoRange: 'Fluid / Freeform Tempo',
      intensity: 'Expressive Depth',
      levels: ['Floor Anatomy (Beg)', 'Release & Momentum (Int)', 'Repertoire Laboratory (Adv)'],
      description:
        'Break free from rigid geometries. Emphasizes seamless floorwork transitions, gravity surrender, dynamic suspension, and organic breath-driven movement.',
      highlights: [
        'Seamless floorwork spirals and impactless landings',
        'Release technique and kinetic momentum conservation',
        'Partnering weight exchange and counterbalances',
        'Emotional narrative composition and improvisational scores',
      ],
      scheduleOverview: 'Mon / Thu morning & evening slots',
      badge: 'Artistic Core',
    },
    {
      id: 'urban-choreo',
      name: 'Urban Choreography',
      subtitle: 'Visual Musicality & Ensemble Staging',
      tagline: 'Micro-musicality, speed control, cinematic formations, and stage presence.',
      image: '/images/dance/urban-choreo.jpg',
      tempoRange: '70 – 130 BPM (Varied)',
      intensity: 'High Precision',
      levels: ['Musicality 101 (Beg)', 'Set Piece Dynamics (Int)', 'Pro Performance Crew (Adv)'],
      description:
        'The pinnacle of modern dance performance. Challenges dancers to interpret micro-sounds, hi-hat rolls, and vocal textures with razor-sharp physical precision and stage geometry.',
      highlights: [
        'Texture differentiation: soft accents vs. razor stops',
        'Complex formation shifts and stage geometry',
        'Speed changes: half-time grooves into double-time bursts',
        'On-camera performance execution and video archives',
      ],
      scheduleOverview: 'Tue / Fri late evenings & Sat afternoon',
      badge: 'Performance Crew',
    },
  ],

  // --------------------------------------------------------------------------
  // 7. INSTRUCTORS & FACULTY (PLACEHOLDER PROFILES)
  // --------------------------------------------------------------------------
  instructors: [
    {
      id: 'elena-rostova',
      name: 'Elena Rostova',
      role: 'Head of Contemporary & Flow Mechanics',
      discipline: 'Contemporary & Floorwork',
      image: '/images/dance/instructor-1.jpg',
      quote: 'Gravity is not a boundary to fight; it is the most dependable partner you will ever dance with.',
      experience: '12 Years Studio Practice',
      focusTags: ['Floor Mechanics', 'Release Technique', 'Spine Articulation', 'Improvisation'],
      bioPlaceholder:
        'Specializes in low-impact kinetic transitions, weight suspension, and breath-directed flow architectures. Conducts masterclasses globally.',
    },
    {
      id: 'marcus-chen',
      name: 'Marcus "Apex" Chen',
      role: 'Resident Artist — Popping & Animation',
      discipline: 'Popping, Boogaloo & Robotics',
      image: '/images/dance/instructor-2.jpg',
      quote: 'The hit is only as powerful as the stillness that precedes it.',
      experience: '14 Years Street & Battle Practice',
      focusTags: ['Hits & Snaps', 'Dime Stops', 'Floating & Gliding', 'Liquid Illusion'],
      bioPlaceholder:
        'Veteran of premier international street cyphers and animation exhibitions. Celebrated for surgical isolations and deep West Coast funk heritage.',
    },
    {
      id: 'aria-vance',
      name: 'Aria Vance',
      role: 'Director of Urban Choreography',
      discipline: 'Urban Choreography & Hip-Hop',
      image: '/images/dance/instructor-3.jpg',
      quote: 'Anyone can hit a beat; great artists let the silence between beats breathe through their limbs.',
      experience: '10 Years Choreography & Direction',
      focusTags: ['Micro-Musicality', 'Formation Staging', 'Camera Execution', 'Speed Dynamics'],
      bioPlaceholder:
        'Creative director for visual albums and performance sets. Blends underground authenticity with crisp visual staging.',
    },
    {
      id: 'devika-s',
      name: 'Devika S.',
      role: 'Master Faculty — Contemporary Bollywood Fusion',
      discipline: 'Bollywood Fusion & Theatrical Movement',
      image: '/images/dance/instructor-4.jpg',
      quote: 'Every gesture is a word; every sequence is an ancient chapter retold in modern rhythm.',
      experience: '11 Years Classical & Commercial Stage',
      focusTags: ['Abhinaya Expression', 'Semi-Classical Footwork', 'Stage Charisma', 'Urban Fusion'],
      bioPlaceholder:
        'Cross-disciplinary movement artist bridging Indian dance traditions and contemporary release technique. Pioneers South Asian theatrical staging.',
    },
  ],

  // --------------------------------------------------------------------------
  // 8. WEEKLY CLASS TIMETABLE
  // --------------------------------------------------------------------------
  schedule: [
    {
      day: 'Monday',
      slots: [
        { time: '10:00 – 11:30', class: 'Contemporary Floorwork', instructor: 'Elena Rostova', level: 'Level 01 (Foundation)', room: 'Studio 1' },
        { time: '18:30 – 19:45', class: 'Hip-Hop Foundation Bounce', instructor: 'Aria Vance', level: 'Level 01 (Foundation)', room: 'Studio 1' },
        { time: '20:00 – 21:30', class: 'Urban Choreography Set Piece', instructor: 'Aria Vance', level: 'Level 02 (Intermediate)', room: 'Main Stage' },
      ],
    },
    {
      day: 'Tuesday',
      slots: [
        { time: '18:30 – 19:45', class: 'Popping Hits & Dime Stops', instructor: 'Marcus Chen', level: 'Level 01 (Foundation)', room: 'Studio 2' },
        { time: '20:00 – 21:30', class: 'Robotics & Animation Flow', instructor: 'Marcus Chen', level: 'Level 02 (Intermediate)', room: 'Studio 2' },
      ],
    },
    {
      day: 'Wednesday',
      slots: [
        { time: '18:00 – 19:15', class: 'Bollywood Fusion Rhythms', instructor: 'Devika S.', level: 'Level 01 (Foundation)', room: 'Main Stage' },
        { time: '19:30 – 21:00', class: 'Hip-Hop Groove & Cypher', instructor: 'Aria Vance', level: 'Open Cypher', room: 'Main Stage' },
      ],
    },
    {
      day: 'Thursday',
      slots: [
        { time: '10:00 – 11:30', class: 'Contemporary Momentum & Release', instructor: 'Elena Rostova', level: 'Level 02 (Intermediate)', room: 'Studio 1' },
        { time: '19:00 – 20:30', class: 'Popping Gliding & Floating', instructor: 'Marcus Chen', level: 'Level 02 (Intermediate)', room: 'Studio 2' },
      ],
    },
    {
      day: 'Friday',
      slots: [
        { time: '18:00 – 19:15', class: 'Bollywood Theatrical Staging', instructor: 'Devika S.', level: 'Level 02 (Intermediate)', room: 'Main Stage' },
        { time: '19:30 – 21:00', class: 'Urban Choreography Masterclass', instructor: 'Aria Vance', level: 'Level 03 (Advanced)', room: 'Main Stage' },
        { time: '21:00 – 22:30', class: 'Open Community Friday Cypher', instructor: 'All Faculty', level: 'All Levels Welcome', room: 'Main Stage' },
      ],
    },
    {
      day: 'Saturday',
      slots: [
        { time: '11:30 – 13:00', class: 'Contemporary Laboratory', instructor: 'Elena Rostova', level: 'Level 03 (Advanced)', room: 'Studio 1' },
        { time: '14:00 – 15:30', class: 'Popping Masterclass Intensive', instructor: 'Marcus Chen', level: 'Level 03 (Advanced)', room: 'Studio 2' },
        { time: '16:30 – 18:00', class: 'Urban Performance Crew Rehearsal', instructor: 'Aria Vance', level: 'Crew Members', room: 'Main Stage' },
      ],
    },
    {
      day: 'Sunday',
      slots: [
        { time: '11:00 – 12:30', class: 'Bollywood Fusion Choreography', instructor: 'Devika S.', level: 'All Levels', room: 'Main Stage' },
        { time: '14:00 – 16:00', class: 'Guest Artist Master Workshops', instructor: 'Guest Artists', level: 'All Levels', room: 'Main Stage' },
      ],
    },
  ],

  // --------------------------------------------------------------------------
  // 9. GALLERY ASSETS
  // --------------------------------------------------------------------------
  gallery: [
    {
      id: 'gal-1',
      src: '/images/dance/gallery-1.jpg',
      alt: 'Dancer silhouette in motion during evening rehearsal',
      caption: 'Kinetic Silhouette // Night Cypher',
      category: 'Light & Shadow',
      aspect: 'tall',
    },
    {
      id: 'gal-2',
      src: '/images/dance/gallery-2.jpg',
      alt: 'Contemporary dancer leaping in mid-air suspension',
      caption: 'Zero Gravity // Release Laboratory',
      category: 'Contemporary',
      aspect: 'wide',
    },
    {
      id: 'gal-3',
      src: '/images/dance/gallery-3.jpg',
      alt: 'Stage performance lighting and dramatic atmosphere',
      caption: 'Stagecraft // The Grand Showcase',
      category: 'Performance',
      aspect: 'square',
    },
    {
      id: 'gal-4',
      src: '/images/dance/gallery-4.jpg',
      alt: 'Studio rehearsal session with dancers focused in unison',
      caption: 'Synchronicity // Urban Choreography Collective',
      category: 'Ensemble',
      aspect: 'tall',
    },
    {
      id: 'gal-5',
      src: '/images/dance/gallery-5.jpg',
      alt: 'Live festival and dance performance energy',
      caption: 'Electric Frequency // Weekend Cypher Session',
      category: 'Community',
      aspect: 'wide',
    },
    {
      id: 'gal-6',
      src: '/images/dance/gallery-6.jpg',
      alt: 'Expressive movement study in architectural studio space',
      caption: 'Architectural Movement // Morning Study',
      category: 'Studio Atmosphere',
      aspect: 'square',
    },
  ],

  // --------------------------------------------------------------------------
  // 10. VISUAL DESIGN TOKENS
  // --------------------------------------------------------------------------
  theme: {
    colors: {
      deepBlack: '#0B0B0F',
      charcoal: '#15151C',
      surface: '#14141B',
      surfaceElevated: '#1B1B26',
      electricViolet: '#8B5CF6',
      lightViolet: '#A78BFA',
      offWhite: '#F5F3F8',
      secondaryText: '#A5A1B2',
      borderSubtle: 'rgba(255, 255, 255, 0.08)',
    },
    fonts: {
      display: "'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif",
      body: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      mono: "'JetBrains Mono', monospace",
    },
  },

  // --------------------------------------------------------------------------
  // 11. SEO & METADATA
  // --------------------------------------------------------------------------
  SEO: {
    siteTitle: 'MOTION IS ART — Premium Urban Dance Academy',
    titleTemplate: '%s | MOTION IS ART',
    defaultDescription:
      'MOTION IS ART is an urban contemporary dance academy blending street culture and experimental digital art. Classes in Hip-Hop, Popping, Bollywood Fusion, Contemporary, and Urban Choreography.',
    canonicalBase: 'https://motionisart.dance',
    ogImage: '/images/dance/hero-dancer.jpg',
    twitterCard: 'summary_large_image',
  },
};

export default siteConfig;
