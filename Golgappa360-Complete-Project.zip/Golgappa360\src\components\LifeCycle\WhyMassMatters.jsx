import React from 'react';

/**
 * WhyMassMatters — Cinematic educational callout
 * "WHY DOES MASS MATTER?"
 * "A star's mass is one of the most important factors controlling its
 * temperature, brightness, lifetime and final fate."
 * Visual comparisons:
 * - LOW MASS (LONG LIFE)
 * - SUN-LIKE (BILLIONS OF YEARS)
 * - HIGH MASS (SHORTER LIFE)
 */
export default function WhyMassMatters() {
  const cards = [
    {
      title: 'LOW MASS',
      subtitle: 'LONG LIFE',
      massLabel: '< 0.5 M☉',
      lifetime: 'Trillions of Years',
      color: '#ef4444',
      glow: 'rgba(239, 68, 68, 0.45)',
      description: 'Slow, frugal thermonuclear fusion. Fuses 100% of its hydrogen. Will outlast every other object in the galaxy.',
    },
    {
      title: 'SUN-LIKE',
      subtitle: 'BILLIONS OF YEARS',
      massLabel: '≈ 1.0 M☉',
      lifetime: '≈ 10 Billion Years',
      color: '#fbbf24',
      glow: 'rgba(251, 191, 36, 0.45)',
      description: 'The golden astronomical equilibrium. Generates steady radiation supporting habitable planetary systems for eons.',
    },
    {
      title: 'HIGH MASS',
      subtitle: 'SHORTER LIFE',
      massLabel: '> 8 M☉',
      lifetime: 'Millions of Years',
      color: '#38bdf8',
      glow: 'rgba(56, 189, 248, 0.5)',
      description: 'Blisteringly hot and intensely radiant. Burns through vast fuel reserves in a cosmological blink, dying in supernovae.',
    },
  ];

  return (
    <div className="w-full relative rounded-3xl overflow-hidden glass-surface border border-white/10 p-8 sm:p-12 lg:p-14 text-center select-none shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
      {/* Background Radial Glow */}
      <div
        aria-hidden="true"
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-rose-500/10 via-amber-400/10 to-cyan-500/15 blur-[120px] pointer-events-none"
      />

      <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center">
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full glass-surface border border-cyan-500/20 text-cyan-400 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span>FUNDAMENTAL ASTROPHYSICAL PRINCIPLE</span>
        </div>

        {/* Heading */}
        <h3 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-4">
          WHY DOES MASS MATTER?
        </h3>

        {/* Text */}
        <p className="font-sans text-base sm:text-lg text-slate-300/90 leading-relaxed font-normal mb-10 max-w-2xl">
          A star's mass is one of the most important factors controlling its temperature, brightness, lifetime and final fate.
        </p>

        {/* Three Glowing Stellar Illustrations */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full text-left">
          {cards.map((card) => (
            <div
              key={card.title}
              className="p-5 sm:p-6 rounded-2xl glass-surface border border-white/10 hover:border-white/20 transition-all duration-300 hover:-translate-y-1"
            >
              {/* Glowing Orb Illustration */}
              <div className="relative w-12 h-12 rounded-full mb-4 flex items-center justify-center">
                <div
                  className="absolute inset-0 rounded-full blur-md opacity-75"
                  style={{ backgroundColor: card.color }}
                />
                <div
                  className="relative w-8 h-8 rounded-full shadow-lg"
                  style={{
                    backgroundColor: card.color,
                    boxShadow: `0 0 15px ${card.glow}`,
                  }}
                />
              </div>

              {/* Title & Subtitle */}
              <h4 className="font-display text-lg font-semibold text-white mb-0.5">
                {card.title}
              </h4>
              <div
                className="text-xs font-mono font-semibold tracking-wider mb-2"
                style={{ color: card.color }}
              >
                {card.subtitle}
              </div>

              <div className="text-[11px] font-mono text-slate-400 mb-3">
                Mass: <strong className="text-white">{card.massLabel}</strong>
              </div>

              <p className="font-sans text-xs text-slate-300/80 leading-relaxed">
                {card.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
