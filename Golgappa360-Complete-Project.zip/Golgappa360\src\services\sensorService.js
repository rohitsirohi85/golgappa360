import { api } from './api';

export const sensorService = {
  recordReading: async (sensorData) => {
    return api.post('/sensors/readings', sensorData);
  },

  getLatestReading: async (chargerId = 'CH-01') => {
    try {
      return await api.get(`/sensors/${chargerId}/latest`);
    } catch (err) {
      return null;
    }
  },

  getHistory: async (chargerId = 'CH-01', limit = 20) => {
    try {
      return await api.get(`/sensors/${chargerId}/history?limit=${limit}`);
    } catch (err) {
      return [];
    }
  },

  getDevicesStatus: async () => {
    try {
      return await api.get('/devices/status');
    } catch (err) {
      return [];
    }
  },

  sendCommand: async (deviceId = 'ESP32-CH01', command = 'START') => {
    try {
      return await api.post(`/devices/${deviceId}/command`, { command });
    } catch (err) {
      return null;
    }
  },
};
