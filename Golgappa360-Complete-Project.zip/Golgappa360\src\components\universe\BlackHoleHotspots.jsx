import React, { useState } from 'react';
import {
  BLACK_HOLE_FEATURES,
  BLACK_HOLE_EDUCATIONAL_OVERVIEW,
} from '../../data/blackHoles.js';

/**
 * BlackHoleHotspots — Interactive Information & Educational Deck (U7)
 * 
 * Allows users to inspect:
 * - EVENT HORIZON
 * - ACCRETION DISK
 * - PHOTON RING
 * - GRAVITATIONAL LENSING
 * - RELATIVISTIC JETS
 * 
 * Displays short, scientifically sound educational explanations.
 * Includes a collapsible "WHAT IS A BLACK HOLE?" educational card.
 */
export default function BlackHoleHotspots({
  activeHotspotId,
  onSelectHotspot,
  currentObject,
  className = '',
}) {
  const [showOverview, setShowOverview] = useState(false);
  const featureList = Object.values(BLACK_HOLE_FEATURES).filter(
    (f) => f.id !== 'relativistic-jets' || (currentObject?.hasJets ?? false)
  );

  const activeFeature = activeHotspotId
    ? BLACK_HOLE_FEATURES[activeHotspotId] || BLACK_HOLE_FEATURES['event-horizon']
    : BLACK_HOLE_FEATURES['event-horizon'];

  return (
    <aside
      className={`select-none flex flex-col gap-2.5 max-w-sm w-full ${className}`}
      aria-label="Black hole scientific information and features"
    >
      {/* 1. Feature Hotspot Pill Selectors */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#030614]/85 backdrop-blur-xl border border-white/10 overflow-x-auto no-scrollbar shadow-lg">
        {featureList.map((feat) => {
          const isSelected = activeFeature.id === feat.id;
          return (
            <button
              key={feat.id}
              type="button"
              onClick={() => onSelectHotspot(feat.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono font-medium whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-amber-500/25 border border-amber-400/60 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                  : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <span>{feat.symbol}</span>
              <span className="text-[11px]">{feat.name}</span>
            </button>
          );
        })}
      </div>

      {/* 2. Active Feature Educational Card */}
      <div className="p-4 rounded-2xl bg-[#030614]/90 backdrop-blur-2xl border border-white/12 shadow-[0_15px_40px_rgba(0,0,0,0.8)] animate-in fade-in duration-200">
        <div className="flex items-center justify-between pb-2 border-b border-white/8 mb-2.5">
          <div className="flex items-center gap-2">
            <span className="text-base">{activeFeature.symbol}</span>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-amber-400 font-semibold block">
                {activeFeature.tag}
              </span>
              <h3 className="text-sm font-sans font-bold text-white tracking-wide">
                {activeFeature.title}
              </h3>
            </div>
          </div>
          <span className="text-[10px] font-mono text-slate-500 bg-white/5 px-2 py-0.5 rounded-full border border-white/5">
            RELATIVISTIC FEATURE
          </span>
        </div>

        {/* Short Key Fact */}
        <p className="text-xs sm:text-sm font-sans font-medium text-amber-100/90 leading-relaxed bg-amber-500/[0.06] p-2.5 rounded-xl border border-amber-500/20 mb-2.5">
          "{activeFeature.shortDescription}"
        </p>

        {/* Detailed Scientific Explanation */}
        <p className="text-xs font-sans text-slate-300 leading-relaxed font-normal">
          {activeFeature.detailedDescription}
        </p>
      </div>

      {/* 3. Collapsible Educational Overview: WHAT IS A BLACK HOLE? */}
      <div className="rounded-2xl bg-[#030614]/85 backdrop-blur-xl border border-white/10 overflow-hidden shadow-lg">
        <button
          type="button"
          onClick={() => setShowOverview((prev) => !prev)}
          className="w-full px-4 py-2.5 flex items-center justify-between text-left hover:bg-white/[0.03] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <span className="text-cyan-400 font-bold text-xs font-mono">✦</span>
            <span className="text-xs font-mono font-bold tracking-wider text-slate-200">
              {BLACK_HOLE_EDUCATIONAL_OVERVIEW.title}
            </span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {showOverview ? '▲ Close' : '▼ Read'}
          </span>
        </button>

        {showOverview && (
          <div className="px-4 pb-3.5 pt-1 border-t border-white/8 animate-in fade-in duration-150">
            <p className="text-xs font-sans text-slate-300 leading-relaxed mb-3">
              {BLACK_HOLE_EDUCATIONAL_OVERVIEW.leadSentence}
            </p>
            <div className="space-y-2">
              {BLACK_HOLE_EDUCATIONAL_OVERVIEW.principles.map((p) => (
                <div key={p.title} className="text-[11px] font-sans">
                  <span className="font-semibold text-amber-300 font-mono">
                    {p.title}:{' '}
                  </span>
                  <span className="text-slate-300">{p.text}</span>
                </div>
              ))}
            </div>

            {/* Scientific Disclaimer */}
            <div className="mt-3 pt-2.5 border-t border-white/8 text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
              <span className="text-amber-400">ℹ</span>
              <span>{BLACK_HOLE_EDUCATIONAL_OVERVIEW.disclaimer}</span>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
