// Test script for Phase 3 API endpoints
import http from 'http';

const BASE_URL = 'http://localhost:5000';

async function request(path) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url);
  const status = res.status;
  const contentType = res.headers.get('content-type') || '';
  let data;
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }
  return { status, data, contentType };
}

async function runTests() {
  console.log('--- Starting Phase 3 Endpoint Verification ---');
  let passed = 0;
  let failed = 0;

  async function test(name, fn) {
    try {
      await fn();
      console.log(`[PASS] ${name}`);
      passed++;
    } catch (err) {
      console.error(`[FAIL] ${name}: ${err.message}`);
      failed++;
    }
  }

  // 1. Health
  await test('GET /api/health', async () => {
    const res = await request('/api/health');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (res.data.status !== 'healthy') throw new Error(`Not healthy`);
    if (!res.data.database) throw new Error('Missing database status');
    console.log(`       Active Data Source: ${res.data.database.activeDataSource}`);
  });

  // 2. Dashboard Summary
  await test('GET /api/dashboard/summary', async () => {
    const res = await request('/api/dashboard/summary?range=30d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.kpis) throw new Error('Invalid summary structure');
    const { totalRevenue, totalOrders, totalPlatesSold, grossProfit, grossMarginPct, operatingProfit } = res.data.data.kpis;
    if (typeof totalRevenue !== 'number' || typeof grossProfit !== 'number') throw new Error('KPIs not numbers');
    console.log(`       Revenue: ₹${totalRevenue.toFixed(2)}, Orders: ${totalOrders}, Plates: ${totalPlatesSold}, Gross Profit: ₹${grossProfit.toFixed(2)} (${grossMarginPct.toFixed(1)}%)`);
  });

  // 3. Dashboard Sales Trend (daily & monthly)
  await test('GET /api/dashboard/sales-trend (daily)', async () => {
    const res = await request('/api/dashboard/sales-trend?range=30d&granularity=daily');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.trend)) throw new Error('Invalid trend structure');
    console.log(`       Daily trend points: ${res.data.data.trend.length}`);
  });

  await test('GET /api/dashboard/sales-trend (monthly)', async () => {
    const res = await request('/api/dashboard/sales-trend?range=180d&granularity=monthly');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.trend)) throw new Error('Invalid trend structure');
    console.log(`       Monthly trend points: ${res.data.data.trend.length}`);
  });

  // 4. Dashboard Hourly Sales
  await test('GET /api/dashboard/hourly-sales', async () => {
    const res = await request('/api/dashboard/hourly-sales?range=30d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.hourly)) throw new Error('Invalid hourly structure');
    console.log(`       Hourly buckets: ${res.data.data.hourly.length}`);
  });

  // 5. Sales list with pagination
  await test('GET /api/sales (page 1, limit 10)', async () => {
    const res = await request('/api/sales?page=1&limit=10');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.pagination || !Array.isArray(res.data.data.sales)) throw new Error('Invalid sales structure');
    if (res.data.data.sales.length !== 10) throw new Error(`Expected 10 items, got ${res.data.data.sales.length}`);
    console.log(`       Total sales records: ${res.data.data.pagination.total}`);
  });

  // 6. Sales Product Performance
  await test('GET /api/sales/product-performance', async () => {
    const res = await request('/api/sales/product-performance?range=30d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.products)) throw new Error('Invalid performance structure');
    console.log(`       Products ranked: ${res.data.data.products.length} (Top: ${res.data.data.products[0].product_name})`);
  });

  // 7. Sales Payment Breakdown
  await test('GET /api/sales/payment-breakdown', async () => {
    const res = await request('/api/sales/payment-breakdown?range=30d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.paymentBreakdown)) throw new Error('Invalid payment structure');
    console.log(`       Payment methods: ${res.data.data.paymentBreakdown.map(p => `${p.method || p.name}: ${p.orderCount || p.count}`).join(', ')}`);
  });

  // 8. Products list
  await test('GET /api/products', async () => {
    const res = await request('/api/products');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !Array.isArray(res.data.data.products)) throw new Error('Invalid products structure');
    console.log(`       Total products: ${res.data.data.products.length}`);
  });

  // 9. Single Product by ID
  await test('GET /api/products/PROD-001', async () => {
    const res = await request('/api/products/PROD-001');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || res.data.data.product.product_id !== 'PROD-001') throw new Error('Product mismatch');
    console.log(`       Product: ${res.data.data.product.product_name} (Price: ₹${res.data.data.product.selling_price})`);
  });

  // 10. Inventory Summary
  await test('GET /api/inventory/summary', async () => {
    const res = await request('/api/inventory/summary');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.ingredients) throw new Error('Invalid inventory summary');
    console.log(`       Inventory ingredients: ${res.data.data.ingredients.length}`);
  });

  // 11. Inventory Transactions (paginated)
  await test('GET /api/inventory/transactions', async () => {
    const res = await request('/api/inventory/transactions?page=1&limit=5&type=PURCHASE');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.pagination || !Array.isArray(res.data.data.transactions)) throw new Error('Invalid transactions structure');
    console.log(`       Total purchase txs: ${res.data.data.pagination.total}`);
  });

  // 12. Waste Summary
  await test('GET /api/waste/summary', async () => {
    const res = await request('/api/waste/summary?range=30d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.kpis) throw new Error('Invalid waste structure');
    console.log(`       Waste cost: ₹${res.data.data.kpis.totalWasteCost}`);
  });

  // 13. Reports Dataset Summary
  await test('GET /api/reports/dataset-summary', async () => {
    const res = await request('/api/reports/dataset-summary');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.data.success || !res.data.data.datasets) throw new Error('Invalid dataset summary');
    console.log(`       Available datasets: ${res.data.data.datasets.map(d => d.id).join(', ')}`);
  });

  // 14. Validation Edge Cases
  await test('Validation: Invalid Date Format Handling', async () => {
    const res = await request('/api/dashboard/summary?startDate=bad-date');
    if (res.status !== 400) throw new Error(`Expected status 400, got ${res.status}`);
    if (!res.data.error.includes('YYYY-MM-DD')) throw new Error('Expected date format error message');
  });

  await test('Validation: Negative Page Pagination Handling', async () => {
    const res = await request('/api/sales?page=-5');
    if (res.status !== 400) throw new Error(`Expected status 400, got ${res.status}`);
    if (!res.data.error.includes('Must be an integer >= 1')) throw new Error('Expected pagination error message');
  });

  // 15. CSV Export
  await test('GET /api/reports/export/sales (CSV format)', async () => {
    const res = await request('/api/reports/export/sales?range=7d');
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!res.contentType.includes('text/csv')) throw new Error(`Expected text/csv, got ${res.contentType}`);
    if (!res.data.includes('"sale_id"') || !res.data.includes('"sale_datetime"')) throw new Error('Missing CSV headers');
    console.log(`       CSV export verified (${res.data.split('\n').length} lines)`);
  });

  // 16. Inventory Restock Mutation
  await test('POST /api/inventory/restock', async () => {
    const res = await fetch(`${BASE_URL}/api/inventory/restock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ingredient_id: 'ING-001', quantity_added: 50, notes: 'Fresh shipment' })
    });
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    if (!json.success) throw new Error('Restock failed');
    console.log(`       Restock success: ${json.success}`);
  });

  // 17. Waste Log Mutation
  await test('POST /api/waste/log', async () => {
    const res = await fetch(`${BASE_URL}/api/waste/log`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ingredient_id: 'ING-001', quantity: 10, reason: 'Broken Puris' })
    });
    if (res.status !== 201) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    if (!json.success || !json.data.logged) throw new Error('Waste log failed');
    console.log(`       Waste log recorded: ${json.data.logged}`);
  });

  console.log(`\n========================================`);
  console.log(`Verification Complete: ${passed} Passed, ${failed} Failed`);
  console.log(`========================================`);
}

runTests().catch(console.error);
