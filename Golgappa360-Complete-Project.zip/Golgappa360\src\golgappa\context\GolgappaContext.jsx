import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import * as api from '../services/api';
import {
  fallbackCategories,
  fallbackMenuItems,
  fallbackIngredients,
  fallbackDailySalesChart,
  fallbackHourlySales,
  fallbackRecentTransactions
} from '../data/clientFallbackStore';

const GolgappaContext = createContext(null);

const VALID_TABS = ['overview', 'sales', 'menu', 'inventory', 'waste', 'reports', 'settings'];

function getInitialTab() {
  if (typeof window !== 'undefined' && window.location.hash) {
    const hash = window.location.hash.replace('#', '').toLowerCase();
    if (VALID_TABS.includes(hash)) return hash;
  }
  return 'overview';
}

export function GolgappaProvider({ children }) {
  const [activeTab, setActiveTabState] = useState(getInitialTab);
  const [dateRange, setDateRange] = useState('30d');
  const [selectedProduct, setSelectedProduct] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [backendOnline, setBackendOnline] = useState(false);
  const [dbStatus, setDbStatus] = useState({ isConnected: false, lastError: null });
  const [notifications, setNotifications] = useState([]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const setActiveTab = useCallback((tabId) => {
    setActiveTabState(tabId);
    if (typeof window !== 'undefined') {
      window.history.pushState(null, '', `#${tabId}`);
    }
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      if (VALID_TABS.includes(hash)) {
        setActiveTabState(hash);
      }
    };
    window.addEventListener('hashchange', handlePopState);
    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('hashchange', handlePopState);
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  const isFiltered = dateRange !== '30d' || selectedProduct !== 'all' || searchQuery.trim() !== '';

  const resetFilters = useCallback(() => {
    setDateRange('30d');
    setSelectedProduct('all');
    setSearchQuery('');
  }, []);

  // Core Data States
  const [overviewData, setOverviewData] = useState({
    kpis: {
      totalRevenue: 301655,
      totalPlatesSold: 8400,
      grossProfit: 217624,
      grossMarginPct: 72.1,
      totalWasteCost: 5154,
      wasteRatePct: 6.1,
      netEstimatedProfit: 212470,
      totalOrders: 4942,
      aov: 61.04
    },
    productSalesDistribution: [
      { name: 'Regular Golgappa', plates: 3528, revenue: 105840, share: 42, color: '#A7D78A' },
      { name: 'Spicy Teekha Puri', plates: 1680, revenue: 58800, share: 20, color: '#EAB64B' },
      { name: 'Dahi Puri Deluxe', plates: 1008, revenue: 60480, share: 12, color: '#D98768' },
      { name: 'Sweet Meetha Puri', plates: 1176, revenue: 41160, share: 14, color: '#7BC0C0' },
      { name: 'Hing & Jeera Special', plates: 672, revenue: 26880, share: 8, color: '#A594F9' },
    ],
    dailySalesChart: fallbackDailySalesChart,
    hourlySalesProfile: fallbackHourlySales,
    recentTransactions: fallbackRecentTransactions,
    activeLowStockCount: 1
  });

  const [salesAnalytics, setSalesAnalytics] = useState(null);
  const [menuData, setMenuData] = useState({
    items: fallbackMenuItems,
    categories: fallbackCategories,
    highlights: {
      topRevenueItem: fallbackMenuItems[0],
      topMarginItem: fallbackMenuItems[5],
      bottomItem: fallbackMenuItems[5],
      averageMargin: 72.6
    }
  });

  const [inventoryData, setInventoryData] = useState({
    ingredients: fallbackIngredients,
    ledger: [],
    lowStockCount: 1,
    totalInventoryValue: 7120
  });

  const [wasteData, setWasteData] = useState({
    kpis: {
      totalWasteCost: 5154,
      totalIncidents: 90,
      avgDailyWaste: 172,
      wasteRatePct: 4.8
    },
    wasteByReason: [
      { reason: 'Broken Puris (Transit/Handling)', count: 30, totalCost: 2165, percentage: 42.0 },
      { reason: 'Leftover Souring Flavoured Pani', count: 30, totalCost: 1820, percentage: 35.3 },
      { reason: 'Excess Boiled Potato Mash Souring', count: 30, totalCost: 1169, percentage: 22.7 }
    ],
    wasteByIngredient: [
      { ingredient: 'Suji & Atta Puris', quantity: 6185, unit: 'pcs', cost: 2165, share: 42.0 },
      { ingredient: 'Spicy Teekha & Pudina Pani', quantity: 72.8, unit: 'liters', cost: 1820, share: 35.3 },
      { ingredient: 'Boiled Potato Mash', quantity: 48.7, unit: 'kg', cost: 1169, share: 22.7 }
    ],
    highWasteDays: [
      { date: '2026-10-26', dayOfWeek: 'Sunday', wasteCost: 290, platesSold: 440, revenue: 15950, wasteRatioPct: 6.4 },
      { date: '2026-10-19', dayOfWeek: 'Sunday', wasteCost: 275, platesSold: 432, revenue: 15680, wasteRatioPct: 6.1 },
      { date: '2026-10-25', dayOfWeek: 'Saturday', wasteCost: 260, platesSold: 410, revenue: 14800, wasteRatioPct: 6.2 },
      { date: '2026-10-18', dayOfWeek: 'Saturday', wasteCost: 240, platesSold: 395, revenue: 14250, wasteRatioPct: 5.9 },
      { date: '2026-10-20', dayOfWeek: 'Monday', wasteCost: 198, platesSold: 195, revenue: 6920, wasteRatioPct: 9.8 }
    ],
    recommendations: [
      {
        id: 'REC-01',
        title: 'Adopt Cushioned Food-Grade Crates for Puri Logistics',
        impact: 'High',
        potentialSavings: '₹2,450 / month',
        finding: 'Transit and storage breakage accounts for 42% of all stall food wastage (avg 112 puris crushed daily).',
        action: 'Replace soft burlap bags with stacked rigid food-grade plastic bins with bubble liners.'
      },
      {
        id: 'REC-02',
        title: 'Implement Staged Pani Mixing (Split Batching)',
        impact: 'High',
        potentialSavings: '₹1,800 / month',
        finding: 'Weekdays (especially Tuesdays and Wednesdays) consistently leave 2.5L to 3.2L of oxidized, souring mint pani unsold at 10 PM.',
        action: 'Cap initial 3 PM batch at 18 Liters. Prepare the remaining 8 Liters only if 6 PM footfall reaches 150 plates.'
      },
      {
        id: 'REC-03',
        title: 'Two-Stage Potato Boiling Schedule',
        impact: 'Medium',
        potentialSavings: '₹950 / month',
        finding: 'Boiled potato-vatana mash loses moisture and develops slight fermentation aroma by 9 PM on warm days.',
        action: 'Boil 65% of required potatoes at 2:30 PM. Boil remaining 35% at 6:30 PM for peak dinner orders.'
      },
      {
        id: 'REC-04',
        title: 'Chilled Curd Temperature Monitoring',
        impact: 'Medium',
        potentialSavings: '₹750 / month',
        finding: 'Dahi Puri curd souring occurs rapidly if the counter ice tub temperature rises above 10°C.',
        action: 'Use insulated secondary ice sleeves around dahi clay matkas during peak outdoor hours.'
      }
    ],
    logs: []
  });

  const [reportsData, setReportsData] = useState(null);
  const [stallSettings, setStallSettings] = useState({
    stallName: 'Sharma Ji Golgappa Center',
    tagline: 'Specialist in 5 Flavours of Puris & Delhi Royal Chaat',
    ownerName: 'Rajesh Sharma',
    location: 'Block 12, Main Market, Karol Bagh, New Delhi',
    establishedYear: 2018,
    currencySymbol: '₹',
    defaultPlatePieces: 6,
    lowStockThresholdAlert: 20,
    wasteWarningThresholdPct: 5.0,
    targetGrossMarginPct: 70.0,
    upiVpa: 'sharmagolgappa@icici'
  });

  // Fetch initial notifications
  const refreshNotifications = useCallback((inv) => {
    const list = [];
    const lowStockItems = (inv?.ingredients || fallbackIngredients).filter(i => i.status === 'Low' || i.status === 'Critical');
    lowStockItems.forEach(item => {
      list.push({
        id: `notif-stock-${item.code}`,
        type: 'warning',
        title: `Low Stock: ${item.name}`,
        message: `Current balance is ${item.current_stock} ${item.unit} (Threshold: ${item.minimum_threshold} ${item.unit}). Runway: ${item.daysRunway || 1} days.`,
        timestamp: 'Just now'
      });
    });

    list.push({
      id: 'notif-peak-hour',
      type: 'info',
      title: 'Evening Rush Approaching (5:00 PM - 8:30 PM)',
      message: 'Peak commuter footfall window expects ~580 plates served. Verify chilled Teekha Pani refills.',
      timestamp: '15 mins ago'
    });

    list.push({
      id: 'notif-waste-rate',
      type: 'alert',
      title: 'Puri Breakage Loss Notice',
      message: 'Puris breakage rate averaged 42% of waste cost this week. Review plastic storage bin recommendation.',
      timestamp: '2 hours ago'
    });

    setNotifications(list);
  }, []);

  // Fetch all endpoints
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      // 1. Health & DB
      const health = await api.fetchHealth().catch(() => null);
      if (health) {
        setBackendOnline(true);
        setDbStatus(health.database || { isConnected: false });
      } else {
        setBackendOnline(false);
      }

      // 2. Overview
      const ov = await api.fetchOverview(dateRange, selectedProduct).catch(() => null);
      if (ov?.data) {
        if (ov.data.kpis) {
          const opProf = ov.data.kpis.operatingProfit ?? ov.data.kpis.netEstimatedProfit ?? 0;
          ov.data.kpis.operatingProfit = opProf;
          ov.data.kpis.netEstimatedProfit = opProf;
        }
        setOverviewData(ov.data);
      }

      // 3. Sales Analytics
      const sa = await api.fetchSalesAnalytics(dateRange, selectedProduct).catch(() => null);
      if (sa?.data) {
        setSalesAnalytics(sa.data);
      }

      // 4. Menu
      const mn = await api.fetchMenuItems(dateRange).catch(() => null);
      if (mn?.data) {
        setMenuData(mn.data);
      }

      // 5. Inventory
      const inv = await api.fetchInventory().catch(() => null);
      if (inv?.data) {
        setInventoryData(inv.data);
        refreshNotifications(inv.data);
      } else {
        refreshNotifications(null);
      }

      // 6. Waste
      const wst = await api.fetchWasteData(dateRange).catch(() => null);
      if (wst?.data) {
        setWasteData(wst.data);
      }

      // 7. Reports
      const rep = await api.fetchReportsSummary().catch(() => null);
      if (rep?.data) {
        setReportsData(rep.data);
      }

      // 8. Settings
      const st = await api.fetchSettings().catch(() => null);
      if (st?.data?.stall) {
        setStallSettings(st.data.stall);
      }
    } catch (err) {
      console.warn('Backend loading note, using resilient client fallback:', err);
    } finally {
      setLoading(false);
    }
  }, [dateRange, selectedProduct, refreshNotifications]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Mutations
  const handleAddMenuItem = async (item) => {
    try {
      if (backendOnline) {
        const res = await api.createMenuItem(item);
        if (res.data) {
          setMenuData(prev => ({
            ...prev,
            items: [...prev.items, res.data]
          }));
          return { success: true };
        }
      }
      // Local fallback mutation
      const newItem = {
        id: menuData.items.length + 1,
        item_code: `SPEC-${(menuData.items.length + 1).toString().padStart(2, '0')}`,
        name: item.name,
        category_name: item.category_name || 'Flavoured Specials',
        flavour_profile: item.flavour_profile || 'Custom Spice Blend',
        pieces_per_plate: Number(item.pieces_per_plate) || 6,
        selling_price: Number(item.selling_price),
        cost_price: Number(item.cost_price),
        margin_pct: Number((((item.selling_price - item.cost_price) / item.selling_price) * 100).toFixed(1)),
        unitMargin: Number((item.selling_price - item.cost_price).toFixed(2)),
        totalUnitsSold: 0,
        totalRevenue: 0,
        totalCost: 0,
        grossProfit: 0,
        grossMarginPct: Number((((item.selling_price - item.cost_price) / item.selling_price) * 100).toFixed(1)),
        is_active: true,
        popularity_score: 50,
        description: item.description
      };
      setMenuData(prev => ({ ...prev, items: [...prev.items, newItem] }));
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const handleRestockInventory = async (ingredientId, qty, notes) => {
    try {
      if (backendOnline) {
        await api.restockInventory(ingredientId, qty, notes);
      }
      setInventoryData(prev => {
        const updated = prev.ingredients.map(ing => {
          if (ing.id === Number(ingredientId)) {
            const newStock = ing.current_stock + Number(qty);
            return {
              ...ing,
              current_stock: newStock,
              status: newStock <= ing.minimum_threshold ? 'Low' : 'Optimal'
            };
          }
          return ing;
        });
        return {
          ...prev,
          ingredients: updated,
          lowStockCount: updated.filter(i => i.status === 'Low' || i.status === 'Critical').length
        };
      });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const handleLogWaste = async (wasteEntry) => {
    try {
      if (backendOnline) {
        await api.logWaste(wasteEntry);
      }
      setWasteData(prev => {
        const ing = inventoryData.ingredients.find(i => i.id === Number(wasteEntry.ingredient_id)) || inventoryData.ingredients[0];
        const cost = Number((Number(wasteEntry.quantity) * (ing.unit_cost || 10)).toFixed(2));
        const newLog = {
          id: `WST-${Date.now().toString().slice(-4)}`,
          date: wasteEntry.date || new Date().toISOString().slice(0, 10),
          ingredient_name: ing.name,
          quantity: Number(wasteEntry.quantity),
          unit: ing.unit,
          unit_cost: ing.unit_cost,
          estimated_cost: cost,
          reason: wasteEntry.reason,
          severity: cost > 150 ? 'High' : 'Normal',
          recommendation: wasteEntry.recommendation || 'Tune batch schedule to daily rush profile.'
        };
        return {
          ...prev,
          logs: [newLog, ...(prev.logs || [])],
          kpis: {
            ...prev.kpis,
            totalWasteCost: prev.kpis.totalWasteCost + cost
          }
        };
      });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const handleTestDatabase = async (config) => {
    try {
      if (backendOnline) {
        const res = await api.testDbConnection(config);
        if (res.serverAccessible) {
          setDbStatus({ isConnected: true, lastError: null });
        }
        return res;
      }
      return {
        success: false,
        message: 'Backend server is starting or offline. Please run "npm start" inside server/.'
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const handleResetDemoData = async () => {
    try {
      if (backendOnline) {
        await api.resetDemoData();
      }
      await loadData();
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  return (
    <GolgappaContext.Provider
      value={{
        activeTab,
        setActiveTab,
        dateRange,
        setDateRange,
        selectedProduct,
        setSelectedProduct,
        searchQuery,
        setSearchQuery,
        isFiltered,
        resetFilters,
        loading,
        backendOnline,
        dbStatus,
        notifications,
        isNotificationsOpen,
        setIsNotificationsOpen,
        overviewData,
        salesAnalytics,
        menuData,
        inventoryData,
        wasteData,
        reportsData,
        stallSettings,
        setStallSettings,
        loadData,
        handleAddMenuItem,
        handleRestockInventory,
        handleLogWaste,
        handleTestDatabase,
        handleResetDemoData
      }}
    >
      {children}
    </GolgappaContext.Provider>
  );
}

export function useGolgappa() {
  const context = useContext(GolgappaContext);
  if (!context) {
    throw new Error('useGolgappa must be used within a GolgappaProvider');
  }
  return context;
}
