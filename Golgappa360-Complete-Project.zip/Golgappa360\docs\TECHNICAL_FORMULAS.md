# EV SMART: Technical Mathematical Formulas & Engineering Equations
## Complete Formulations Across Electrical, Analytics, Financial & Machine Learning Domains

---

## 1. Electrical Power & Energy Equations

The physical IoT subsystem samples AC electrical waveforms at 1 Hz via the PZEM-004T v3.0 metering module.

### A. Instantaneous Root Mean Square (RMS) Voltage & Current
$$V_{\text{rms}} = \sqrt{\frac{1}{T} \int_{0}^{T} v(t)^2 \, dt}$$
$$I_{\text{rms}} = \sqrt{\frac{1}{T} \int_{0}^{T} i(t)^2 \, dt}$$
Where $T$ is the fundamental AC power period ($20\text{ ms}$ at $50\text{ Hz}$).

---

### B. Active, Apparent & Reactive Power

#### 1. Active Real Power ($P$) [Watts / kW]:
$$P = V_{\text{rms}} \times I_{\text{rms}} \times \cos(\phi)$$
Where $\cos(\phi)$ is the Power Factor ($\text{PF}$), representing the phase angle displacement between voltage and current.

#### 2. Apparent Power ($S$) [Volt-Amperes / kVA]:
$$S = V_{\text{rms}} \times I_{\text{rms}}$$

#### 3. Reactive Power ($Q$) [Volt-Amperes Reactive / kVAR]:
$$Q = \sqrt{S^2 - P^2} = V_{\text{rms}} \times I_{\text{rms}} \times \sin(\phi)$$

#### 4. Power Factor ($\text{PF}$):
$$\text{PF} = \frac{P}{S} = \cos(\phi) \quad (0.0 \le \text{PF} \le 1.0)$$

---

### C. Numerical Integration of Active Energy ($E$)

Energy accumulated over a charging session of duration $T_{\text{session}}$ is computed via continuous integration:
$$E = \int_{0}^{T_{\text{session}}} P(t) \, dt$$

In the Node.js backend pipeline, this is evaluated using discrete numerical integration (Trapezoidal Rule) across incoming 1Hz telemetry packets:
$$\Delta E_k = \left( \frac{P_k + P_{k-1}}{2} \right) \times \left( \frac{t_k - t_{k-1}}{3600 \times 1000} \right) \quad [\text{kWh}]$$

Total accumulated session energy:
$$E_{\text{total}} = \sum_{k=1}^{N} \Delta E_k \quad [\text{kWh}]$$

---

## 2. Operational & Fleet Analytics Formulas

### A. Charger Utilization Rate ($\%$)
Measures the proportion of time a charger actively delivers electrical energy over an observation window $T_{\text{window}}$ (e.g., 24 hours):
$$\text{Utilization Rate } (\%) = \left( \frac{\sum_{i=1}^{M} T_{\text{active}, i}}{T_{\text{window}}} \right) \times 100$$
Where $T_{\text{active}, i}$ is the duration of charging session $i$ within the window.

---

### B. Station Load Factor ($\text{LF}$)
Reflects the efficiency of electrical capacity usage relative to peak demand:
$$\text{LF} = \frac{P_{\text{avg}}}{P_{\text{peak}}} = \frac{\frac{1}{T} \int_{0}^{T} P_{\text{station}}(t) \, dt}{\max_{t \in [0, T]} P_{\text{station}}(t)}$$
A Load Factor closer to $1.0$ indicates steady, flat grid consumption, whereas a low $\text{LF}$ signifies severe peak spikes.

---

### C. Peak Demand Factor ($\text{PDF}$)
Measures station instantaneous power demand relative to rated transformer capacity $C_{\text{transformer}}$:
$$\text{PDF} = \frac{\sum_{j=1}^{K} P_{\text{charger}, j}}{C_{\text{transformer}}}$$
When $\text{PDF} > 0.85$, the system triggers peak-shaving alerts and scales dynamic tariffs.

---

### D. Equipment Health & Degradation Index ($H_c$)
Proxy metric evaluating charger physical wear based on thermal cycles, relay actuations, and electrical stress:
$$H_c = 100 - \left[ \alpha \left(\frac{N_{\text{cycles}}}{N_{\text{rated}}}\right) + \beta \left(\frac{\int \max(0, T_{\text{enc}} - T_{\text{threshold}}) \, dt}{\theta_{\text{max}}}\right) + \gamma N_{\text{anomalies}} \right]$$
- $\alpha = 30$, $\beta = 40$, $\gamma = 30$ (Weighting coefficients)
- $N_{\text{cycles}}$: Cumulative relay switch open/close cycles
- $N_{\text{rated}}$: Rated relay endurance ($100,000$ operations)
- $T_{\text{enc}}$: Enclosure temperature; $T_{\text{threshold}} = 45^\circ\text{C}$
- Health Categories:
  - $H_c \ge 80$: **HEALTHY** (Green)
  - $50 \le H_c < 80$: **WARNING** (Yellow)
  - $H_c < 50$: **CRITICAL MAINTENANCE REQUIRED** (Red)

---

## 3. Financial & Dynamic Tariff Formulas

### A. Total Charging Session Billing
$$\text{Bill}_{\text{total}} = \left( E_{\text{delivered}} \times \text{Tariff}_{\text{dynamic}} \right) + \text{Fee}_{\text{platform}} + \text{Tax}_{\text{GST}}$$

Where:
$$\text{Tariff}_{\text{dynamic}} = \text{Rate}_{\text{base}} \times M_{\text{demand}}(t)$$
$$\text{Tax}_{\text{GST}} = \left( E_{\text{delivered}} \times \text{Tariff}_{\text{dynamic}} + \text{Fee}_{\text{platform}} \right) \times 0.18 \quad (18\% \text{ GST})$$

---

### B. Dynamic Peak Multiplier ($M_{\text{demand}}$)
The dynamic price multiplier is computed based on forecasted station demand $D_{\text{forecast}}(t)$ relative to nominal capacity $C_{\text{nominal}}$:
$$M_{\text{demand}}(t) = \text{clamp}\left( 1.0 + \kappa \cdot \left(\frac{D_{\text{forecast}}(t) - D_{\text{avg}}}{C_{\text{nominal}}}\right), \, 0.8, \, 1.6 \right)$$
- $\kappa = 0.75$ (Elasticity sensitivity factor)
- Minimum Multiplier: $0.8\times$ (Off-Peak incentive during $00:00 - 06:00$)
- Standard Multiplier: $1.0\times$ (Normal hours)
- Maximum Multiplier: $1.6\times$ (Critical peak surge suppression during $17:00 - 22:00$)

---

## 4. Machine Learning & Feature Engineering Formulations

### A. Cyclical Temporal Encodings (Sine & Cosine)
To ensure continuous circular transitions between $23:59$ and $00:00$, and between Sunday and Monday:

#### 1. Hour of Day ($h \in [0, 23]$):
$$\text{hour\_sin} = \sin\left(\frac{2\pi \cdot h}{24}\right), \quad \text{hour\_cos} = \cos\left(\frac{2\pi \cdot h}{24}\right)$$

#### 2. Day of Week ($d \in [0, 6]$):
$$\text{dow\_sin} = \sin\left(\frac{2\pi \cdot d}{7}\right), \quad \text{dow\_cos} = \cos\left(\frac{2\pi \cdot d}{7}\right)$$

---

### B. Standard Feature Normalization (Z-Score)
For anomaly detection input vectors:
$$z_i = \frac{x_i - \mu_i}{\sigma_i}$$
Where $\mu_i$ is feature mean and $\sigma_i$ is standard deviation.

---

### C. Demand Forecast Model Evaluation Metrics

#### 1. Mean Absolute Error ($\text{MAE}$):
$$\text{MAE} = \frac{1}{N} \sum_{i=1}^{N} |y_i - \hat{y}_i| = 3.09\text{ kWh}$$

#### 2. Root Mean Squared Error ($\text{RMSE}$):
$$\text{RMSE} = \sqrt{\frac{1}{N} \sum_{i=1}^{N} (y_i - \hat{y}_i)^2} = 4.41\text{ kWh}$$

#### 3. Coefficient of Determination ($R^2$):
$$R^2 = 1 - \frac{\sum_{i=1}^{N} (y_i - \hat{y}_i)^2}{\sum_{i=1}^{N} (y_i - \bar{y})^2} = 0.9902$$

---

### D. Isolation Forest Anomaly Scoring
The anomaly score $s(x, n)$ for an electrical telemetry vector $x = [V, I, P, T, \text{PF}]$ over an ensemble of $t$ isolation trees:
$$s(x, n) = 2^{-\frac{E(h(x))}{c(n)}}$$
Where:
- $E(h(x))$: Average path length to isolate sample $x$ across all trees.
- $c(n)$: Average path length of unsuccessful search in a Binary Search Tree (BST) of size $n$:
  $$c(n) = 2 \ln(n - 1) + 0.5772156649 \text{ (Euler-Mascheroni constant)} - \frac{2(n - 1)}{n}$$
- Decision Rule:
  - If $s(x, n) \to 1.0 \implies$ Definite electrical anomaly (voltage sag, surge, overtemperature).
  - If $s(x, n) < 0.5 \implies$ Normal operational telemetry.
